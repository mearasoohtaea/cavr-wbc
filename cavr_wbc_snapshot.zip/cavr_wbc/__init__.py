"""Infrastructure for the CAVR-WBC research project.

Only the model-independent STEP-01 interfaces live here at present.  A robot,
simulator, controller, and WBC have not yet been fixed for this repository.
"""

__all__ = ["__version__"]

__version__ = "0.1.0-dev"

