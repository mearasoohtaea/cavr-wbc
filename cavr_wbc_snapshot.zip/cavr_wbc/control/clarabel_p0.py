"""Independent Clarabel production backend for the frozen STEP-02C audit.

The production path assembles the physical QP directly.  It deliberately does
not import or call the independent lexicographic reference implementation.
The physical decision is ``[qdd, tau, lambda]`` and Clarabel receives the same
frozen dimensionless coordinate system used by STEP-02R.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Any, Iterable

import clarabel
import numpy as np
import scipy.sparse as sp

from cavr_wbc.control.fixed_support_qp import PhysicalSnapshot, QpSolveResult
from cavr_wbc.control.scaled_fixed_support_qp import (
    validate_original_witness,
    variable_scales,
)


@dataclass(frozen=True)
class ClarabelP0Settings:
    max_iter: int = 500
    tol_gap_abs: float = 5e-11
    tol_gap_rel: float = 5e-11
    tol_feas: float = 5e-11
    tol_infeas_abs: float = 5e-11
    tol_infeas_rel: float = 5e-11
    equilibrate_enable: bool = True
    presolve_enable: bool = True
    iterative_refinement_enable: bool = True
    verbose: bool = False


@dataclass(frozen=True)
class P0PhysicalAssembly:
    equality: np.ndarray
    equality_rhs: np.ndarray
    inequality: np.ndarray
    inequality_upper: np.ndarray
    equality_labels: tuple[str, ...]
    inequality_labels: tuple[str, ...]


def assemble_p0_constraints_original(
    snapshot: PhysicalSnapshot,
    rho: Iterable[float],
    *,
    fixed_task_output: Iterable[float] | None = None,
    fixed_task_normalized_tolerance: float = 1e-8,
) -> P0PhysicalAssembly:
    """Build the production P0 constraints in original physical units."""

    health = np.asarray(tuple(rho), dtype=float)
    if health.shape != (snapshot.nu,):
        raise ValueError("rho shape must match actuator count")
    if np.any((health < 0.0) | (health > 1.0)):
        raise ValueError("rho values must lie in [0, 1]")
    if fixed_task_normalized_tolerance < 0.0:
        raise ValueError("fixed-task tolerance must be non-negative")

    n = snapshot.decision_dimension
    qdd_end = snapshot.nv
    tau_start = qdd_end
    tau_end = tau_start + snapshot.nu
    force_start = tau_end

    dynamics = np.hstack(
        (
            snapshot.mass_matrix,
            -snapshot.selection_matrix,
            -snapshot.contact_jacobian.T,
        )
    )
    contact = np.zeros((snapshot.nlambda, n), dtype=float)
    contact[:, :qdd_end] = snapshot.contact_jacobian
    equality = np.vstack((dynamics, contact))
    equality_rhs = np.concatenate(
        (-snapshot.bias_force, -snapshot.contact_acceleration_bias)
    )
    equality_labels = tuple(
        [f"p0_dynamics[{index}]" for index in range(snapshot.nv)]
        + [
            f"p0_contact_acceleration[{index}]"
            for index in range(snapshot.nlambda)
        ]
    )

    bounds = health * snapshot.torque_scales
    torque_map = np.zeros((snapshot.nu, n), dtype=float)
    torque_map[:, tau_start:tau_end] = np.eye(snapshot.nu)
    paired_torque = np.empty((2 * snapshot.nu, n), dtype=float)
    paired_torque[0::2] = torque_map
    paired_torque[1::2] = -torque_map
    inequality_parts = [paired_torque]
    upper_parts = [np.repeat(bounds, 2)]
    inequality_labels_list = []
    for actuator in range(snapshot.nu):
        inequality_labels_list.extend(
            (
                f"p0_torque_upper[{actuator}]",
                f"p0_torque_lower[{actuator}]",
            )
        )

    contact_rows: list[np.ndarray] = []
    contact_upper: list[float] = []
    signs = ((1.0, 1.0), (1.0, -1.0), (-1.0, 1.0), (-1.0, -1.0))
    for foot, foot_name in enumerate(snapshot.foot_names):
        first = force_start + 3 * foot
        for face, (sign_x, sign_y) in enumerate(signs):
            row = np.zeros(n, dtype=float)
            row[first : first + 3] = (
                sign_x,
                sign_y,
                -float(snapshot.friction_mu[foot]),
            )
            contact_rows.append(row)
            contact_upper.append(0.0)
            inequality_labels_list.append(f"p0_friction[{foot_name},{face}]")
        normal_lower = np.zeros(n, dtype=float)
        normal_lower[first + 2] = -1.0
        contact_rows.append(normal_lower)
        contact_upper.append(0.0)
        inequality_labels_list.append(f"p0_normal_lower[{foot_name}]")
        normal_upper = np.zeros(n, dtype=float)
        normal_upper[first + 2] = 1.0
        contact_rows.append(normal_upper)
        contact_upper.append(float(snapshot.normal_force_upper[foot]))
        inequality_labels_list.append(f"p0_normal_upper[{foot_name}]")
    inequality_parts.append(np.vstack(contact_rows))
    upper_parts.append(np.asarray(contact_upper, dtype=float))

    if fixed_task_output is not None:
        target = np.asarray(tuple(fixed_task_output), dtype=float)
        if target.shape != (snapshot.task_dimension,):
            raise ValueError("fixed task output has the wrong dimension")
        task_rows = np.zeros((snapshot.task_dimension, n), dtype=float)
        task_rows[:, :qdd_end] = snapshot.task_matrix
        tolerance = fixed_task_normalized_tolerance * snapshot.task_scales
        centered_target = target - snapshot.task_bias
        paired_task = np.empty((2 * snapshot.task_dimension, n), dtype=float)
        paired_task[0::2] = task_rows
        paired_task[1::2] = -task_rows
        upper_task = np.empty(2 * snapshot.task_dimension, dtype=float)
        upper_task[0::2] = centered_target + tolerance
        upper_task[1::2] = -centered_target + tolerance
        inequality_parts.append(paired_task)
        upper_parts.append(upper_task)
        for task_index in range(snapshot.task_dimension):
            inequality_labels_list.extend(
                (
                    f"p0_fixed_task_upper[{task_index}]",
                    f"p0_fixed_task_lower[{task_index}]",
                )
            )

    return P0PhysicalAssembly(
        equality=equality,
        equality_rhs=equality_rhs,
        inequality=np.vstack(inequality_parts),
        inequality_upper=np.concatenate(upper_parts),
        equality_labels=equality_labels,
        inequality_labels=tuple(inequality_labels_list),
    )


def _row_scaling(matrix: np.ndarray, rhs: np.ndarray) -> np.ndarray:
    magnitudes = np.maximum(np.max(np.abs(matrix), axis=1), np.abs(rhs))
    return np.divide(
        1.0,
        magnitudes,
        out=np.ones_like(magnitudes),
        where=magnitudes > 0.0,
    )


class ClarabelP0Production:
    """STEP-02C production P0 and B1-soft solver using direct Clarabel."""

    def __init__(
        self,
        snapshot: PhysicalSnapshot,
        rho: Iterable[float],
        settings: ClarabelP0Settings,
        *,
        secondary_task_fix_normalized_tolerance: float,
        fixed_task_numerical_guard_fraction: float,
    ) -> None:
        self.snapshot = snapshot
        self.rho = np.asarray(tuple(rho), dtype=float)
        self.settings = settings
        self.secondary_task_fix_normalized_tolerance = float(
            secondary_task_fix_normalized_tolerance
        )
        self.fixed_task_numerical_guard_fraction = float(
            fixed_task_numerical_guard_fraction
        )
        if not 0.0 <= self.fixed_task_numerical_guard_fraction < 1.0:
            raise ValueError("fixed-task numerical guard must lie in [0, 1)")
        self.variable_scales = variable_scales(snapshot)
        self.qdd = slice(0, snapshot.nv)
        self.tau = slice(snapshot.nv, snapshot.nv + snapshot.nu)
        self.contact_force = slice(
            snapshot.nv + snapshot.nu, snapshot.decision_dimension
        )
        self.accepted_settings: dict[str, Any] | None = None

    def _objective(
        self,
        desired_task: np.ndarray | None,
        torque_regularization_weight: float,
    ) -> tuple[np.ndarray, np.ndarray]:
        if torque_regularization_weight < 0.0:
            raise ValueError("torque regularization weight must be non-negative")
        n = self.snapshot.decision_dimension
        hessian = np.zeros((n, n), dtype=float)
        linear = np.zeros(n, dtype=float)
        if desired_task is not None:
            desired = np.asarray(desired_task, dtype=float)
            if desired.shape != (self.snapshot.task_dimension,):
                raise ValueError("desired task has the wrong dimension")
            weighted_map = (
                np.sqrt(self.snapshot.task_weights)[:, None]
                * self.snapshot.task_matrix
                / self.snapshot.task_scales[:, None]
            )
            weighted_offset = np.sqrt(self.snapshot.task_weights) * (
                self.snapshot.task_bias - desired
            ) / self.snapshot.task_scales
            hessian[self.qdd, self.qdd] = 2.0 * (
                weighted_map.T @ weighted_map
            )
            linear[self.qdd] = 2.0 * weighted_map.T @ weighted_offset
        if torque_regularization_weight:
            diagonal = (
                2.0
                * torque_regularization_weight
                / np.square(self.snapshot.torque_scales)
            )
            tau_indices = np.arange(self.tau.start, self.tau.stop)
            hessian[tau_indices, tau_indices] += diagonal
        return hessian, linear

    def _problem(
        self,
        desired_task: np.ndarray | None,
        torque_regularization_weight: float,
        fixed_task_output: np.ndarray | None,
    ) -> tuple[
        sp.csc_matrix,
        np.ndarray,
        sp.csc_matrix,
        np.ndarray,
        list[Any],
        P0PhysicalAssembly,
        np.ndarray,
        np.ndarray,
    ]:
        physical = assemble_p0_constraints_original(
            self.snapshot,
            self.rho,
            fixed_task_output=fixed_task_output,
            fixed_task_normalized_tolerance=(
                self.secondary_task_fix_normalized_tolerance
                * (1.0 - self.fixed_task_numerical_guard_fraction)
            ),
        )
        equality_scaled_variables = (
            physical.equality * self.variable_scales[None, :]
        )
        inequality_scaled_variables = (
            physical.inequality * self.variable_scales[None, :]
        )
        equality_row_scales = _row_scaling(
            equality_scaled_variables, physical.equality_rhs
        )
        inequality_row_scales = _row_scaling(
            inequality_scaled_variables, physical.inequality_upper
        )
        equality = equality_row_scales[:, None] * equality_scaled_variables
        inequality = inequality_row_scales[:, None] * inequality_scaled_variables
        constraint_matrix = sp.csc_matrix(np.vstack((equality, inequality)))
        constraint_rhs = np.concatenate(
            (
                equality_row_scales * physical.equality_rhs,
                inequality_row_scales * physical.inequality_upper,
            )
        )
        cones: list[Any] = [
            clarabel.ZeroConeT(equality.shape[0]),
            clarabel.NonnegativeConeT(inequality.shape[0]),
        ]
        hessian, linear = self._objective(
            desired_task, torque_regularization_weight
        )
        scaled_hessian = (
            self.variable_scales[:, None]
            * hessian
            * self.variable_scales[None, :]
        )
        scaled_linear = self.variable_scales * linear
        return (
            sp.triu(sp.csc_matrix(scaled_hessian), format="csc"),
            scaled_linear,
            constraint_matrix,
            constraint_rhs,
            cones,
            physical,
            equality_row_scales,
            inequality_row_scales,
        )

    def _solver_settings(self) -> Any:
        settings = clarabel.DefaultSettings()
        for field in self.settings.__dataclass_fields__:
            setattr(settings, field, getattr(self.settings, field))
        self.accepted_settings = {
            field: getattr(settings, field)
            for field in self.settings.__dataclass_fields__
        }
        return settings

    @staticmethod
    def _failed_result(method: str, status: str, raw: Any | None) -> QpSolveResult:
        return QpSolveResult(
            method=method,
            status=status,
            status_val=-1,
            success=False,
            qdd=None,
            tau=None,
            contact_force=None,
            task_output=None,
            task_objective=None,
            torque_regularizer=None,
            normalized_task_residual=None,
            validation={
                "available": False,
                "solver_dual_objective": (
                    None if raw is None else getattr(raw, "obj_val_dual", None)
                ),
                "duality_gap": (
                    None
                    if raw is None or not hasattr(raw, "obj_val_dual")
                    else abs(float(raw.obj_val) - float(raw.obj_val_dual))
                ),
            },
            iterations=0 if raw is None else int(raw.iterations),
            solve_time_s=0.0 if raw is None else float(raw.solve_time),
            setup_time_s=0.0,
            primal_residual=math.inf if raw is None else float(raw.r_prim),
            dual_residual=math.inf if raw is None else float(raw.r_dual),
            solver_objective=None if raw is None else float(raw.obj_val),
        )

    def _solve(
        self,
        *,
        method: str,
        desired_task: np.ndarray | None,
        torque_regularization_weight: float,
        fixed_task_output: np.ndarray | None = None,
    ) -> QpSolveResult:
        try:
            P, q, A, b, cones, _, _, _ = self._problem(
                desired_task,
                torque_regularization_weight,
                fixed_task_output,
            )
            raw = clarabel.DefaultSolver(
                P, q, A, b, cones, self._solver_settings()
            ).solve()
        except Exception as exc:
            return self._failed_result(
                method, f"exception:{type(exc).__name__}:{exc}", None
            )

        status = str(raw.status)
        if status != "Solved" or raw.x is None or not np.isfinite(raw.x).all():
            return self._failed_result(method, status, raw)

        physical = np.asarray(raw.x, dtype=float) * self.variable_scales
        qdd = physical[self.qdd].copy()
        tau = physical[self.tau].copy()
        contact_force = physical[self.contact_force].copy()
        task_output = self.snapshot.task_matrix @ qdd + self.snapshot.task_bias
        normalized_residual = (
            None
            if desired_task is None
            else (task_output - desired_task) / self.snapshot.task_scales
        )
        task_objective = (
            None
            if normalized_residual is None
            else float(
                np.sum(
                    self.snapshot.task_weights * np.square(normalized_residual)
                )
            )
        )
        torque_regularizer = float(
            np.sum(np.square(tau / self.snapshot.torque_scales))
        )
        validation = validate_original_witness(
            self.snapshot,
            self.rho,
            qdd,
            tau,
            contact_force,
            fixed_task_output=fixed_task_output,
        )
        dual_objective = getattr(raw, "obj_val_dual", None)
        validation["solver_dual_objective"] = (
            None if dual_objective is None else float(dual_objective)
        )
        validation["duality_gap"] = (
            None
            if dual_objective is None
            else abs(float(raw.obj_val) - float(dual_objective))
        )
        return QpSolveResult(
            method=method,
            status=status,
            status_val=1,
            success=True,
            qdd=qdd,
            tau=tau,
            contact_force=contact_force,
            task_output=task_output,
            task_objective=task_objective,
            torque_regularizer=torque_regularizer,
            normalized_task_residual=normalized_residual,
            validation=validation,
            iterations=int(raw.iterations),
            solve_time_s=float(raw.solve_time),
            setup_time_s=0.0,
            primal_residual=float(raw.r_prim),
            dual_residual=float(raw.r_dual),
            solver_objective=float(raw.obj_val),
        )

    def solve_stage_a(self, desired_task: Iterable[float]) -> QpSolveResult:
        return self._solve(
            method="P0_CLARABEL_PRODUCTION_STAGE_A",
            desired_task=np.asarray(tuple(desired_task), dtype=float),
            torque_regularization_weight=0.0,
        )

    def solve_stage_b(
        self, projected_task: Iterable[float], lambda_tau: float
    ) -> QpSolveResult:
        return self._solve(
            method="P0_CLARABEL_PRODUCTION_STAGE_B",
            desired_task=None,
            torque_regularization_weight=lambda_tau,
            fixed_task_output=np.asarray(tuple(projected_task), dtype=float),
        )

    def solve_b1_soft(
        self, desired_task: Iterable[float], lambda_tau: float
    ) -> QpSolveResult:
        return self._solve(
            method="B1_SOFT_CLARABEL_PRODUCTION",
            desired_task=np.asarray(tuple(desired_task), dtype=float),
            torque_regularization_weight=lambda_tau,
        )

    def audit_problem(
        self,
        *,
        desired_task: Iterable[float] | None = None,
        torque_regularization_weight: float = 0.0,
        fixed_task_output: Iterable[float] | None = None,
    ) -> dict[str, Any]:
        desired = (
            None
            if desired_task is None
            else np.asarray(tuple(desired_task), dtype=float)
        )
        fixed = (
            None
            if fixed_task_output is None
            else np.asarray(tuple(fixed_task_output), dtype=float)
        )
        P, q, A, b, _, physical, equality_scales, inequality_scales = (
            self._problem(desired, torque_regularization_weight, fixed)
        )
        return {
            "variable_scales": self.variable_scales.tolist(),
            "original_equality_labels": list(physical.equality_labels),
            "original_equality_matrix": physical.equality.tolist(),
            "original_equality_rhs": physical.equality_rhs.tolist(),
            "original_inequality_labels": list(physical.inequality_labels),
            "original_inequality_matrix": physical.inequality.tolist(),
            "original_inequality_upper": physical.inequality_upper.tolist(),
            "equality_row_scaling": equality_scales.tolist(),
            "inequality_row_scaling": inequality_scales.tolist(),
            "scaled_conic_A": A.toarray().tolist(),
            "scaled_conic_b": b.tolist(),
            "scaled_P": P.toarray().tolist(),
            "scaled_q": q.tolist(),
            "external_fixed_task_tolerance": (
                self.secondary_task_fix_normalized_tolerance
            ),
            "internal_fixed_task_tolerance": (
                self.secondary_task_fix_normalized_tolerance
                * (1.0 - self.fixed_task_numerical_guard_fraction)
            ),
            "fixed_task_numerical_guard_fraction": (
                self.fixed_task_numerical_guard_fraction
            ),
        }
