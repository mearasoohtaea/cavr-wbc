"""Dynamic, contact-aware whole-body controllers for the E2-B DEV panel.

The controller in this module deliberately works on the public MuJoCo state
only.  A decision vector is ``[qdd, tau, lambda]`` and every solve enforces
the articulated-body dynamics, four-point contact kinematics, torque health
limits, normal-force/friction limits, and conservative joint-limit
acceleration bounds.  B1/B2/B3/P0 share this assembly; their differences are
only the frozen objective/decomposition specified by E2-B.

``solve_callback`` is an optional audit/logger hook with the following
signature::

    callback(stage: str, payload: dict[str, Any], solve: Callable[[], dict])
        -> dict[str, Any]

The callback is called once with ``stage='before'`` and once with
``stage='after'`` for *each* OSQP invocation.  It may call ``solve`` exactly
once and return its dictionary.  The default callback executes OSQP directly.
This makes solver-call accounting explicit without exposing any hidden solver
state to the independent evaluator.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Iterable, Mapping

import mujoco
import numpy as np
import osqp
import scipy.sparse as sp
import os
from time import perf_counter, thread_time

from cavr_wbc.platforms.go2_mujoco import FOOT_NAMES, extract_actuator_joint_map
from cavr_wbc.control.step12_validation import (
    AcceptanceConfig, ValidationConfigurationError, assembly_snapshot,
    compiled_model_metadata, immutable_copy, osqp_status_name,
    stage1_witness, validate_candidate, validate_l0_mapping,
)


SolveCallback = Callable[[str, dict[str, Any], Callable[[], dict[str, Any]]], dict[str, Any]]


@dataclass(frozen=True)
class DynamicWBCConfig:
    """Frozen common timing and physical constants for E2-B."""

    physics_dt: float = 0.001
    wbc_dt: float = 0.002
    supervisor_dt: float = 0.020
    backup_horizon: float = 1.0
    friction_mu: float = 0.6
    normal_force_upper: float = 350.0
    joint_limit_margin: float = 0.02
    torque_regularization: float = 1e-4
    task_regularization: float = 1.0
    hqp_tolerance: float = 2e-4
    osqp_eps_abs: float = 1e-7
    osqp_eps_rel: float = 1e-7
    osqp_max_iter: int = 20000
    # B2 stage two has a fixed realtime budget.  This is an execution budget,
    # not a task/constraint relaxation; stage-one remains the declared
    # deterministic fallback when stage two cannot finish inside it.
    b2_stage2_max_iter: int = 256
    b2_stage2_budget_s: float = 0.005
    deadline_s: float = 0.020


def _as_array(value: Any, length: int, *, default: float = 0.0) -> np.ndarray:
    if value is None:
        return np.full(length, default, dtype=float)
    arr = np.asarray(value, dtype=float).reshape(-1)
    if arr.size != length:
        raise ValueError(f"expected length {length}, received {arr.size}")
    if not np.isfinite(arr).all():
        raise ValueError("non-finite target/health value")
    return arr.copy()


class DynamicWBC:
    """Contact-aware dynamic WBC with B1/B2/B3/P0 interfaces."""

    def __init__(
        self,
        model: mujoco.MjModel,
        cfg: DynamicWBCConfig | Mapping[str, Any] | None = None,
        solve_callback: SolveCallback | None = None,
        *,
        acceptance_config: AcceptanceConfig | None = None,
    ) -> None:
        self.model = model
        if cfg is None:
            self.cfg = DynamicWBCConfig()
        elif isinstance(cfg, DynamicWBCConfig):
            self.cfg = cfg
        else:
            fields = {k: v for k, v in dict(cfg).items() if k in DynamicWBCConfig.__dataclass_fields__}
            self.cfg = DynamicWBCConfig(**fields)
        self.solve_callback = solve_callback
        self.nv, self.nu = int(model.nv), int(model.nu)
        self._mapping = tuple(extract_actuator_joint_map(model))
        if len(self._mapping) != self.nu:
            raise ValueError("compiled actuator mapping does not match model.nu")
        self._dof_for_actuator = np.asarray([e.dof_index for e in self._mapping], dtype=int)
        self._healthy_limits = np.asarray([e.joint_torque_limit for e in self._mapping], dtype=float)
        self._foot_geom_ids = tuple(self._find_foot_geom(name) for name in FOOT_NAMES)
        if any(g < 0 for g in self._foot_geom_ids):
            raise ValueError("four named foot geoms are required by E2-B")
        self.acceptance_config = acceptance_config
        self.l0_mapping = None
        if acceptance_config is not None:
            if not isinstance(acceptance_config, AcceptanceConfig):
                raise ValidationConfigurationError("acceptance_config must come from load_acceptance_config")
            self.l0_mapping = validate_l0_mapping(
                acceptance_config,
                compiled_model_metadata(model, self._mapping, FOOT_NAMES, self._foot_geom_ids),
            )
            for key, frozen in (("osqp_eps_abs", 1e-7), ("osqp_eps_rel", 1e-7), ("hqp_tolerance", 2e-4), ("deadline_s", 0.02), ("backup_horizon", 1.0)):
                if getattr(self.cfg, key) != frozen:
                    raise ValidationConfigurationError(f"STEP12 controller {key} differs from frozen definition")
        self.last_stage1_snapshot: Mapping[str, Any] | None = None
        self.last_stage2_snapshot: Mapping[str, Any] | None = None
        self.last_stage1_witness: Mapping[str, Any] | None = None
        # OSQP workspaces are deliberately owned by the controller instance.
        # The online path only updates numeric vectors in a workspace whose
        # sparse structure has already been frozen.  A separate cache entry is
        # used for B2 stage two because that stage has its additional task-band
        # rows.  Keeping the workspaces here (rather than in ``compute``)
        # makes warm-start/reuse auditable and avoids an unconditional setup on
        # every supervisor tick.
        self._solver_cache: dict[tuple[Any, ...], dict[str, Any]] = {}
        self.solver_setup_calls = 0
        self.solver_calls = 0
        self.real_optimizer_calls = 0
        self.callback_injections = 0
        self.solver_ledger: list[dict[str, Any]] = []
        self._last_solver_timings: dict[str, float | bool] = {}

        # The online architecture keeps the two HQP structures resident.  A
        # dynamic QP still receives fresh numeric values every tick, but the
        # CSC indices/indptr and all numeric work buffers are allocated once.
        # This is intentionally separate from ``_solver_cache``: OSQP owns a
        # factorization cache, while these buffers are our fixed assembly
        # contract and are also used by deterministic test doubles.
        self._n_contacts = 4 * 3
        self._n_task = 6 + self.nu
        self._nq = self.nv + self.nu + self._n_contacts
        self._n_physical_rows = (self.nv + self._n_contacts + self.nv + self.nu + 4 * 5)
        self._structures = self._build_fixed_structures()
        self._objective_blocks = self._allocate_objective_blocks(self._n_task, self._nq)

        # B3 reference-governor buffers.  The matrix and gain are frozen by
        # the protocol; only the public target vector is copied into the
        # preallocated memory on each call.
        self._b3_reference_matrix = np.eye(6, dtype=float) / (1.0 + 0.25 * float(self.cfg.backup_horizon))
        self._b3_weight_multiplier = np.concatenate((np.full(6, 2.0), np.ones(self.nu)))
        self._b3_reference_memory = np.zeros(6, dtype=float)
        self._b3_weight_memory = np.ones(self._n_task, dtype=float)
        self._b2_stage2_weights = np.full(self._n_task, 1e-6, dtype=float)
        self._hqp_tolerance = np.full(self._n_task, float(self.cfg.hqp_tolerance), dtype=float)

    def _build_fixed_structures(self) -> dict[str, dict[str, Any]]:
        """Allocate fixed B1/B2 numeric buffers exactly once.

        Every column in ``A`` is represented explicitly (including zeros) so
        OSQP can update ``Ax`` without a sparse pattern rebuild.  Stage two
        has the additional fixed task-band rows; no ``vstack`` is needed on
        the realtime path.
        """
        P = sp.diags(np.ones(self._nq, dtype=float), format="csc")
        n1, n2 = self._n_physical_rows, self._n_physical_rows + self._n_task
        a1 = self._fixed_csc(np.zeros((n1, self._nq), dtype=float))
        a2 = self._fixed_csc(np.zeros((n2, self._nq), dtype=float))
        return {
            "stage1": {
                "P": P.copy(), "A": a1,
                "p_values": np.zeros(P.nnz, dtype=float),
                "a_values": np.zeros(a1.nnz, dtype=float),
                "dense_values": np.zeros((n1, self._nq), dtype=float),
                "q": np.zeros(self._nq, dtype=float),
                "l": np.zeros(n1, dtype=float), "u": np.zeros(n1, dtype=float),
                "band_dense": np.zeros((self._n_task, self._nq), dtype=float),
            },
            "stage2": {
                "P": P.copy(), "A": a2,
                "p_values": np.zeros(P.nnz, dtype=float),
                "a_values": np.zeros(a2.nnz, dtype=float),
                "dense_values": np.zeros((n2, self._nq), dtype=float),
                "q": np.zeros(self._nq, dtype=float),
                "l": np.zeros(n2, dtype=float), "u": np.zeros(n2, dtype=float),
                "band_dense": np.zeros((self._n_task, self._nq), dtype=float),
            },
        }

    def _find_foot_geom(self, name: str) -> int:
        gid = int(mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_GEOM, name))
        if gid >= 0:
            return gid
        token = name.lower()
        for i in range(self.model.ngeom):
            candidate = mujoco.mj_id2name(self.model, mujoco.mjtObj.mjOBJ_GEOM, i)
            if candidate and token in candidate.lower():
                return int(i)
        return -1

    def _selection(self, data: mujoco.MjData) -> np.ndarray:
        """Return compiled actuator moment map B(q), not a hard-coded leg map."""
        B = np.zeros((self.nv, self.nu), dtype=float)
        for a in range(self.nu):
            adr = int(data.moment_rowadr[a])
            nnz = int(data.moment_rownnz[a])
            for j in range(nnz):
                k = adr + j
                B[int(data.moment_colind[k]), a] = float(data.actuator_moment[k])
        return B

    def _contacts(self, data: mujoco.MjData) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        points: list[np.ndarray] = []
        jacobians: list[np.ndarray] = []
        jdot_vel: list[np.ndarray] = []
        for gid in self._foot_geom_ids:
            body = int(self.model.geom_bodyid[gid])
            # The geometry centre is deterministic even when a contact is not
            # currently active; the four rows remain present in every solve.
            point = np.asarray(data.geom_xpos[gid], dtype=float).copy()
            jp = np.zeros((3, self.nv), dtype=float)
            jr = np.zeros((3, self.nv), dtype=float)
            mujoco.mj_jac(self.model, data, jp, jr, point, body)
            jp_dot = np.zeros((3, self.nv), dtype=float)
            jr_dot = np.zeros((3, self.nv), dtype=float)
            mujoco.mj_jacDot(self.model, data, jp_dot, jr_dot, point, body)
            points.append(point)
            jacobians.append(jp)
            jdot_vel.append(jp_dot @ np.asarray(data.qvel, dtype=float))
        J = np.vstack(jacobians)
        return np.vstack(points), J, np.concatenate(jdot_vel)

    def _health(self, health: Iterable[float] | float) -> np.ndarray:
        if np.isscalar(health):
            h = np.ones(self.nu, dtype=float)
            # The E2-B fault is FR_thigh; scalar health is its capacity.
            fr = next((i for i, e in enumerate(self._mapping) if e.actuator_name == "FR_thigh"), 1)
            h[fr] = float(health)
        else:
            h = _as_array(health, self.nu, default=1.0)
        if np.any((h < 0.0) | (h > 1.0)):
            raise ValueError("health must lie in [0, 1]")
        return h

    def _task_map(self, target: Mapping[str, Any]) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        # The original task contract is represented by base acceleration
        # (roll/pitch/height/forward terms are supplied by the task manager)
        # plus all actuated-joint accelerations.
        T = np.zeros((6 + self.nu, self.nv), dtype=float)
        T[:6, :6] = np.eye(6)
        for i, dof in enumerate(self._dof_for_actuator):
            T[6 + i, dof] = 1.0
        desired, weights = self._task_values(target)
        return T, desired, weights

    def _task_values(self, target):
        """Original desired/weights construction; no discarded task matrix."""
        desired = np.concatenate(
            (
                _as_array(target.get("desired_base_accel", target.get("base_accel")), 6),
                _as_array(target.get("desired_joint_accel", target.get("joint_accel")), self.nu),
            )
        )
        weights = _as_array(target.get("task_weights"), 6 + self.nu, default=1.0)
        if np.any(weights <= 0.0):
            raise ValueError("task weights must be positive")
        return desired, weights

    def _allocate_objective_blocks(self, nrow, nq):
        return dict(A_task=np.zeros((nrow, nq), dtype=float),
                    torque_eye=np.eye(self.nu), ridge_eye=np.eye(nq))

    def _objective(self, T, desired, weights, nq, ts, tw, q):
        """Same products and two ordered additions; only static blocks reused."""
        blocks = getattr(self, '_objective_blocks', None)
        if blocks is None or blocks['A_task'].shape != (T.shape[0], nq) or blocks['torque_eye'].shape != (self.nu, self.nu):
            blocks = self._allocate_objective_blocks(T.shape[0], nq)
            self._objective_blocks = blocks
        A_task = blocks['A_task']
        # Entire variable selector is replaced every call; fixed zero columns stay zero.
        A_task[:, :self.nv] = T
        W = np.sqrt(weights)
        H = A_task.T @ (W[:, None] * W[:, None] * A_task)
        np.copyto(q, -(A_task.T @ (weights * desired)))
        H[ts, ts] += tw * blocks['torque_eye']
        H += 1e-9 * blocks['ridge_eye']
        return H

    def _joint_accel_bounds(self, data: mujoco.MjData) -> tuple[np.ndarray, np.ndarray]:
        lo = np.full(self.nv, -np.inf, dtype=float)
        hi = np.full(self.nv, np.inf, dtype=float)
        dt = float(self.cfg.wbc_dt)
        for j in range(self.model.njnt):
            if not bool(self.model.jnt_limited[j]):
                continue
            qadr, dadr = int(self.model.jnt_qposadr[j]), int(self.model.jnt_dofadr[j])
            q, v = float(data.qpos[qadr]), float(data.qvel[dadr])
            lower, upper = map(float, self.model.jnt_range[j])
            margin = float(self.cfg.joint_limit_margin)
            # Constant-acceleration one-step bound keeps q + v*dt + .5*a*dt²
            # inside the frozen joint range.
            lo[dadr] = 2.0 * (lower + margin - q - v * dt) / (dt * dt)
            hi[dadr] = 2.0 * (upper - margin - q - v * dt) / (dt * dt)
        return lo, hi

    def _problem(
        self,
        data: mujoco.MjData,
        health: np.ndarray,
        target: Mapping[str, Any],
        *,
        task_weights: np.ndarray | None = None,
        torque_weight: float | None = None,
        fixed_task: np.ndarray | None = None,
        physical: Mapping[str, Any] | None = None,
        stage2: bool = False,
    ) -> tuple[sp.csc_matrix, np.ndarray, sp.csc_matrix, np.ndarray, np.ndarray, dict[str, Any]]:
        """Assemble one QP while optionally reusing the physical linearization.

        B2's two HQP stages share the same state, contacts, articulated mass,
        actuator moment map and joint-limit bounds.  Recomputing those values
        for stage two wastes a substantial part of the online budget and, in
        particular, duplicates the four-foot Jacobian calls.  ``physical`` is
        the metadata returned by stage one; it is read-only and is only used
        for this same-state stage-two assembly.  Objective and constraint
        numeric values are still rebuilt, so the two stages remain genuine
        independent QPs with the complete physical rows in each stage.
        """
        m = self.cfg
        wall, cpu = perf_counter(), thread_time()
        self.assembly_subblocks = {}
        def mark(name):
            nonlocal wall, cpu
            end, endcpu = perf_counter(), thread_time()
            self.assembly_subblocks[name] = dict(wall_ms=(end-wall)*1000., thread_cpu_ms=(endcpu-cpu)*1000.)
            wall, cpu = end, endcpu
        structure = self._structures["stage2" if stage2 else "stage1"]
        T, desired, weights = self._task_map(target)
        if task_weights is not None:
            weights = np.asarray(task_weights, dtype=float)
        if fixed_task is not None:
            desired = np.asarray(fixed_task, dtype=float).reshape(-1)
        mark('task_values')
        if physical is None:
            points, Jc, jdotv = self._contacts(data)
            M = np.zeros((self.nv, self.nv), dtype=float)
            mujoco.mj_fullM(self.model, data, M)
            bias = np.asarray(data.qfrc_bias, dtype=float).copy()
            B = self._selection(data)
            qlo, qhi = self._joint_accel_bounds(data)
        else:
            # No mutable arrays are changed below; preserving these arrays by
            # reference avoids copies on the stage-two realtime path.
            points = physical["points"]
            Jc = physical["Jc"]
            jdotv = physical["jdotv"]
            M = physical["M"]
            bias = physical["bias"]
            B = physical["B"]
            qlo = physical["qdd_lo"]
            qhi = physical["qdd_hi"]
        mark('current_physics_contacts_mass_bias_selection_bounds')
        nlambda = Jc.shape[0]
        nq = self.nv + self.nu + nlambda
        qs, ts, ls = slice(0, self.nv), slice(self.nv, self.nv + self.nu), slice(self.nv + self.nu, nq)

        # Positive semidefinite weighted task objective + torque regularizer.
        q = structure["q"]
        tw = float(m.torque_regularization if torque_weight is None else torque_weight)
        H = self._objective(T, desired, weights, nq, ts, tw, q)
        # T is a one-hot selector, so the weighted task Hessian, torque
        # regularizer and 1e-9 ridge are all diagonal.  Preserve that exact
        # fixed diagonal CSC pattern instead of passing dense explicit zeros
        # through OSQP's numeric factorization/update path.
        # Fill the preallocated diagonal objective instead of constructing a
        # sparse matrix on every supervisor tick.
        np.copyto(structure["p_values"], np.diag(H))
        P = structure["P"]
        np.copyto(P.data, structure["p_values"])
        mark('objective_products_and_CSC')

        if physical is not None:
            # The second HQP stage changes only the objective and adds its
            # task-band rows in compute(); all physical constraints and
            # bounds are exactly those just assembled for stage one.
            meta = dict(physical)
            meta.update(T=T, desired=desired, weights=weights)
            A = structure["A"]
            nphys = self._n_physical_rows
            # Stage two owns a larger fixed matrix.  Copy only numeric values
            # from the stage-one physical rows and leave task-band rows for
            # ``compute`` to fill in place.
            stage_values = A.data.reshape((self._n_physical_rows + self._n_task, self._nq), order="F")
            physical_values = physical["constraint_A"].data.reshape((nphys, self._nq), order="F")
            np.copyto(stage_values[:nphys, :], physical_values)
            stage_values[nphys:, :] = 0.0
            np.copyto(structure["l"][:nphys], physical["constraint_l"])
            np.copyto(structure["u"][:nphys], physical["constraint_u"])
            structure["l"][nphys:] = 0.0
            structure["u"][nphys:] = 0.0
            mark('constraints_same_state_stage2')
            return P, q, A, structure["l"], structure["u"], meta

        # Fill a resident dense numeric view, then copy only its values into
        # the resident CSC data.  This removes per-cycle sparse assembly and
        # preserves a stable OSQP index structure.
        dense = structure["dense_values"]
        dense.fill(0.0)
        row = 0
        # M qdd + bias = B tau + Jc' lambda.
        dense[row:row + self.nv, qs] = M
        dense[row:row + self.nv, ts] = -B
        dense[row:row + self.nv, ls] = -Jc.T
        lower = structure["l"]; upper = structure["u"]
        np.copyto(lower[row:row + self.nv], -bias); np.copyto(upper[row:row + self.nv], -bias)
        row += self.nv
        dense[row:row + nlambda, qs] = Jc
        np.copyto(lower[row:row + nlambda], -jdotv); np.copyto(upper[row:row + nlambda], -jdotv)
        row += nlambda
        np.fill_diagonal(dense[row:row + self.nv, qs], 1.0)
        np.copyto(lower[row:row + self.nv], qlo); np.copyto(upper[row:row + self.nv], qhi)
        row += self.nv
        tau_lim = health * self._healthy_limits
        np.fill_diagonal(dense[row:row + self.nu, ts], 1.0)
        np.copyto(lower[row:row + self.nu], -tau_lim); np.copyto(upper[row:row + self.nu], tau_lim)
        row += self.nu
        for foot in range(4):
            base = ls.start + 3 * foot
            mu = float(m.friction_mu)
            for sx, sy in ((1, 1), (1, -1), (-1, 1), (-1, -1)):
                dense[row, base:base + 3] = (sx, sy, -mu)
                lower[row] = -np.inf; upper[row] = 0.0; row += 1
            dense[row, base + 2] = 1.0
            lower[row] = -np.inf; upper[row] = float(m.normal_force_upper); row += 1
        A = structure["A"]
        np.copyto(structure["a_values"], dense.reshape(-1, order="F"))
        np.copyto(A.data, structure["a_values"])
        l, u = lower, upper
        meta = {"M": M, "bias": bias, "B": B, "Jc": Jc, "jdotv": jdotv, "points": points, "T": T, "desired": desired, "weights": weights, "tau_lim": tau_lim, "qdd_lo": qlo, "qdd_hi": qhi}
        meta.update(friction_mu=float(m.friction_mu), normal_force_upper=float(m.normal_force_upper))
        meta.update(constraint_A=A, constraint_l=l, constraint_u=u)
        mark('constraints_and_current_metadata')
        return P, q, A, l, u, meta

    @staticmethod
    def _fixed_csc(matrix: Any, *, upper: bool = False) -> sp.csc_matrix:
        """Store a dense numeric matrix with a frozen CSC sparsity pattern.

        ``scipy.sparse.csc_matrix(dense)`` drops zero entries, so the pattern
        can change with every MuJoCo state and force an OSQP setup.  Explicit
        zero-valued entries are intentional here: they freeze the structure
        while numeric ``Px``/``Ax`` updates carry the live state.
        """
        if sp.issparse(matrix):
            arr = np.asarray(matrix.toarray(), dtype=float)
        else:
            arr = np.asarray(matrix, dtype=float)
        nrow, ncol = arr.shape
        if upper:
            chunks = [arr[: min(col + 1, nrow), col] for col in range(ncol)]
            data = np.concatenate(chunks) if chunks else np.empty(0, dtype=float)
            indices = np.concatenate([np.arange(min(col + 1, nrow), dtype=np.int32) for col in range(ncol)]) if chunks else np.empty(0, dtype=np.int32)
            indptr = np.concatenate(([0], np.cumsum([len(c) for c in chunks], dtype=np.int32)))
        else:
            data = np.asarray(arr, dtype=float).reshape(-1, order="F")
            indices = np.tile(np.arange(nrow, dtype=np.int32), ncol)
            indptr = np.arange(0, nrow * ncol + 1, nrow, dtype=np.int32)
        return sp.csc_matrix((data, indices, indptr), shape=(nrow, ncol))

    @staticmethod
    def _workspace_key(problem: Mapping[str, Any]) -> tuple[Any, ...]:
        """Return a stable key for an OSQP sparse structure.

        OSQP's ``update`` API requires identical dimensions and index
        structure.  Numeric values are intentionally excluded from the key;
        they are supplied through ``Px``, ``Ax``, ``q``, ``l`` and ``u`` on
        subsequent calls.  The index/indptr bytes make accidental structure
        changes visible instead of silently reusing an incompatible problem.
        """
        P = problem["P"].tocsc(copy=False)
        A = problem["A"].tocsc(copy=False)
        P.sort_indices(); A.sort_indices()
        return (
            P.shape, A.shape,
            P.indptr.tobytes(), P.indices.tobytes(),
            A.indptr.tobytes(), A.indices.tobytes(),
            int(P.nnz), int(A.nnz),
        )

    def _default_solve(self, problem: dict[str, Any], *, max_iter_override: int | None = None) -> dict[str, Any]:
        """Solve one problem using a persistent, warm-started OSQP workspace."""
        P = problem["P"].tocsc(copy=False)
        A = problem["A"].tocsc(copy=False)
        P.sort_indices(); A.sort_indices()
        key = self._workspace_key({"P": P, "A": A})
        cache = self._solver_cache.get(key)
        setup_time = 0.0
        update_time = 0.0
        warm_started = False
        native_dll = os.environ.get("CAVR_WBC_NATIVE_OSQP_DLL")
        max_iter = int(max_iter_override if max_iter_override is not None else self.cfg.osqp_max_iter)
        if cache is None:
            t_setup = perf_counter()
            if native_dll:
                from cavr_wbc.control.native_osqp import NativeOSQP
                solver = NativeOSQP(
                    P, A, np.asarray(problem["q"], dtype=float),
                    np.asarray(problem["l"], dtype=float), np.asarray(problem["u"], dtype=float),
                    eps_abs=self.cfg.osqp_eps_abs, eps_rel=self.cfg.osqp_eps_rel,
                    max_iter=max_iter,
                )
                native = True
            else:
                solver = osqp.OSQP()
                solver.setup(
                    P=P, q=np.asarray(problem["q"], dtype=float),
                    A=A, l=np.asarray(problem["l"], dtype=float),
                    u=np.asarray(problem["u"], dtype=float),
                    eps_abs=self.cfg.osqp_eps_abs,
                    eps_rel=self.cfg.osqp_eps_rel,
                    max_iter=max_iter,
                    polish=True, verbose=False,
                )
                native = False
            setup_time = perf_counter() - t_setup
            self.solver_setup_calls += 1
            cache = {"solver": solver, "last_x": None, "last_y": None,
                     "setup_count": self.solver_setup_calls, "native": native}
            self._solver_cache[key] = cache
        else:
            solver = cache["solver"]
            t_update = perf_counter()
            if cache.get("native", False):
                solver.update(
                    np.asarray(P.data, dtype=float), np.asarray(A.data, dtype=float),
                    np.asarray(problem["q"], dtype=float), np.asarray(problem["l"], dtype=float),
                    np.asarray(problem["u"], dtype=float),
                )
            else:
                # The arrays are copied by OSQP; no mutable sparse object escapes
                # this call.  This is the only numeric update in the online path.
                solver.update(
                    Px=np.asarray(P.data, dtype=float),
                    Ax=np.asarray(A.data, dtype=float),
                    q=np.asarray(problem["q"], dtype=float),
                    l=np.asarray(problem["l"], dtype=float),
                    u=np.asarray(problem["u"], dtype=float),
                )
            update_time = perf_counter() - t_update
            if cache.get("last_x") is not None or cache.get("last_y") is not None:
                if cache.get("native", False):
                    solver.last_x = cache.get("last_x")
                    solver.last_y = cache.get("last_y")
                else:
                    solver.warm_start(x=cache.get("last_x"), y=cache.get("last_y"))
                warm_started = True
        t_solve = perf_counter()
        if cache.get("native", False):
            raw = solver.solve(warm_start=warm_started)
        else:
            raw = solver.solve(raise_error=False)
        solve_wall = perf_counter() - t_solve
        if cache.get("native", False):
            if raw.get("x") is not None:
                cache["last_x"] = np.asarray(raw["x"], dtype=float).copy()
            if raw.get("y") is not None:
                cache["last_y"] = np.asarray(raw["y"], dtype=float).copy()
        else:
            if raw.x is not None:
                cache["last_x"] = np.asarray(raw.x, dtype=float).copy()
            if getattr(raw, "y", None) is not None:
                cache["last_y"] = np.asarray(raw.y, dtype=float).copy()
        info = raw.info if not cache.get("native", False) else None
        self._last_solver_timings = {
            "setup_time_s": float(setup_time),
            "update_time_s": float(update_time),
            "solve_wall_time_s": float(solve_wall if cache.get("native", False) else info.solve_time),
            "solve_time_s": float(raw.get("solve_time_s", 0.0) if cache.get("native", False) else info.solve_time),
            "workspace_reused": bool(cache["setup_count"] != self.solver_setup_calls or update_time > 0.0),
            "warm_started": bool(warm_started),
        }
        if cache.get("native", False):
            out = dict(raw)
            out.update({"solve_wall_time_s": float(solve_wall), "setup_time_s": float(setup_time),
                        "update_time_s": float(update_time), "workspace_reused": bool(update_time > 0.0),
                        "warm_started": bool(warm_started)})
            return out
        return {
            "x": None if raw.x is None else np.asarray(raw.x, dtype=float),
            "status": str(info.status), "status_val": int(info.status_val),
            "iterations": int(info.iter), "solve_time_s": float(info.solve_time),
            "solve_wall_time_s": float(solve_wall), "setup_time_s": float(setup_time),
            "update_time_s": float(update_time), "workspace_reused": bool(update_time > 0.0),
            "warm_started": bool(warm_started), "primal_residual": float(info.prim_res),
            "dual_residual": float(info.dual_res),
        }

    def _invoke(self, problem: dict[str, Any], stage: str, *, max_iter_override: int | None = None) -> dict[str, Any]:
        call_index = self.solver_calls + 1
        payload = {"stage": stage, "P": problem["P"], "q": problem["q"], "A": problem["A"], "l": problem["l"], "u": problem["u"], "solver_call_index": call_index}
        solved = False
        solved_result: dict[str, Any] | None = None

        def solve_once() -> dict[str, Any]:
            nonlocal solved, solved_result
            if solved:
                raise RuntimeError("solve_callback invoked solve() more than once")
            solved = True
            self.solver_calls += 1
            self.real_optimizer_calls += 1
            out = self._default_solve(problem, max_iter_override=max_iter_override)
            out["solver_call_index"] = self.solver_calls
            out["real_optimizer_called"] = True
            out["callback_injection"] = False
            out["status_class"] = osqp_status_name(out.get("status_val"))
            solved_result = out
            self.solver_ledger.append({
                "solver_call_index": self.solver_calls,
                "stage": stage,
                "status": out.get("status"),
                "status_val": out.get("status_val"),
                "iterations": out.get("iterations"),
                "workspace_reused": out.get("workspace_reused", False),
                "warm_started": out.get("warm_started", False),
                "setup_time_s": out.get("setup_time_s", 0.0),
                "update_time_s": out.get("update_time_s", 0.0),
                "solve_time_s": out.get("solve_time_s", 0.0),
                "solve_wall_time_s": out.get("solve_wall_time_s", 0.0),
                "primal_residual": out.get("primal_residual"),
                "dual_residual": out.get("dual_residual"),
                "real_optimizer_called": True,
                "callback_injection": False,
                "status_class": out["status_class"],
            })
            return out

        if self.solve_callback is None:
            out = solve_once()
        else:
            out = self.solve_callback("before", payload, solve_once)
            # A logger may choose not to call the supplied thunk.  In that
            # case perform the one ordinary solve here, preserving the exact
            # before/after callback contract and complete accounting.
            if out is None:
                # A pure logging hook may call the thunk and return None; use
                # the captured result rather than invoking the solver twice.
                out = solved_result if solved else solve_once()
            elif not solved:
                # Explicit callback result is accepted for deterministic test
                # doubles, but remains an auditable callback-managed call.
                solved = True
                self.solver_calls += 1
                self.callback_injections += 1
                out = dict(out)
                out.update(solver_call_index=self.solver_calls, real_optimizer_called=False,
                           callback_injection=True, status_class=osqp_status_name(out.get("status_val")))
                # A branch injection has no optimizer residual, iterations or
                # solve time, even when a test hook supplied synthetic values.
                for key in ("primal_residual", "dual_residual", "iterations", "solve_time_s", "solve_wall_time_s", "setup_time_s", "update_time_s"):
                    out[key] = None
                self.solver_ledger.append({
                    "solver_call_index": self.solver_calls,
                    "stage": stage,
                    "status": out.get("status"),
                    "status_val": out.get("status_val"),
                    "solve_wall_time_s": None,
                    "solve_time_s": None,
                    "setup_time_s": None,
                    "update_time_s": None,
                    "iterations": None,
                    "primal_residual": out.get("primal_residual"),
                    "dual_residual": out.get("dual_residual"),
                    "callback_managed": True,
                    "real_optimizer_called": False,
                    "callback_injection": True,
                    "status_class": out["status_class"],
                })
        if not isinstance(out, dict):
            raise TypeError("solve_callback must return a dictionary")
        # A callback that records before/after itself may return the solve
        # result.  Otherwise emit the mandatory after hook here.
        if self.solve_callback is not None:
            self.solve_callback("after", {**payload, "result": out, "solver_call_index": self.solver_calls}, lambda: out)
        return out

    def _decode(self, out: dict[str, Any], meta: dict[str, Any], method: str) -> dict[str, Any]:
        x = out.get("x")
        ok = out.get("status_val") == 1 and x is not None and np.asarray(x).shape == (self.nv + self.nu + 12,) and np.isfinite(x).all()
        result: dict[str, Any] = {
            "method": method, "status": out.get("status", "unknown"), "status_val": out.get("status_val"),
            "raw_status": out.get("status"), "raw_status_val": out.get("status_val"),
            "status_class": osqp_status_name(out.get("status_val")),
            "real_optimizer_called": out.get("real_optimizer_called", False),
            "callback_injection": out.get("callback_injection", False),
            "success": bool(ok), "solver_calls": 1, "solver_call_index": out.get("solver_call_index"),
            "workspace_reused": bool(out.get("workspace_reused", False)), "warm_started": bool(out.get("warm_started", False)),
            "setup_time_s": out.get("setup_time_s"), "update_time_s": out.get("update_time_s"),
            "solve_time_s": out.get("solve_time_s"), "solve_wall_time_s": out.get("solve_wall_time_s"),
            "primal_residual": out.get("primal_residual"), "dual_residual": out.get("dual_residual"),
            "iterations": out.get("iterations"), "qdd": None, "tau": None,
            "contact_force": None, "task_output": None, "validation": {},
            "command_status": "VALID_COMMAND" if ok else "NO_VALID_COMMAND",
        }
        if not ok:
            return result
        x = np.asarray(x, dtype=float)
        qdd = x[:self.nv]; tau = x[self.nv:self.nv + self.nu]; lam = x[self.nv + self.nu:]
        dyn = meta["M"] @ qdd + meta["bias"] - meta["B"] @ tau - meta["Jc"].T @ lam
        con = meta["Jc"] @ qdd + meta["jdotv"]
        margin = meta["tau_lim"] - np.abs(tau)
        result.update({"qdd": qdd, "tau": tau, "contact_force": lam, "task_output": meta["T"] @ qdd, "validation": {"dynamics_residual_inf": float(np.max(np.abs(dyn))), "contact_acceleration_residual_inf": float(np.max(np.abs(con))), "min_torque_margin": float(np.min(margin)), "joint_limit_qdd_lower_violation": float(np.max(np.maximum(meta["qdd_lo"] - qdd, 0.0))), "joint_limit_qdd_upper_violation": float(np.max(np.maximum(qdd - meta["qdd_hi"], 0.0)))}})
        return result

    def _validated_decode(self, out: dict[str, Any], snapshot: Mapping[str, Any], method: str) -> dict[str, Any]:
        """Apply independent V1 before exposing any executable candidate."""
        result = self._decode(out, snapshot["meta"], method)
        validation = validate_candidate(out, snapshot, self.acceptance_config)
        result.update(validation=validation, v1_valid=bool(validation["pass"]),
                      success=bool(validation["pass"]), command_status=validation["command_status"])
        if not validation["pass"]:
            for field in ("qdd", "tau", "contact_force", "task_output"):
                result[field] = None
            result["p1_status"] = "NOT_RUN_NO_VALID_COMMAND"
        return result

    def compute(self, data: mujoco.MjData, method: str, health: Iterable[float] | float, target: Mapping[str, Any] | None = None) -> dict[str, Any]:
        """Compute one dynamic command for B1/B2/B3/P0.

        ``target`` is public task data.  Returned ``tau`` is in actuator order
        and N*m, while qdd/contact forces are in MuJoCo generalized ordering.
        """
        method = str(method).upper()
        self.last_stage1_snapshot = None
        self.last_stage2_snapshot = None
        self.last_stage1_witness = None
        requested_method = method
        if method == "P1":
            method = "P0"
        if method not in {"B1", "B2", "B3", "P0"}:
            raise ValueError("DynamicWBC supports B1, B2, B3 and P0")
        target = dict(target or {})
        h = self._health(health)
        if method == "B3":
            # Fixed reference-governor matrix/weights.  The online update only
            # writes public target values into resident buffers; horizon,
            # weights and memory dimensions never change.
            base = _as_array(target.get("desired_base_accel", target.get("base_accel")), 6)
            self._b3_reference_memory[:] = self._b3_reference_matrix @ base
            target["desired_base_accel"] = self._b3_reference_memory
            base_weights = _as_array(target.get("task_weights"), self._n_task, default=1.0)
            np.multiply(base_weights, self._b3_weight_multiplier, out=self._b3_weight_memory)
            target["task_weights"] = self._b3_weight_memory
        if method == "P0":
            # Joint-task projection is a deterministic acceleration projection
            # using the same one-step joint-limit bounds as the physical QP.
            qlo, qhi = self._joint_accel_bounds(data)
            jtarget = _as_array(target.get("desired_joint_accel", target.get("joint_accel")), self.nu)
            target["desired_joint_accel"] = np.clip(jtarget, qlo[self._dof_for_actuator], qhi[self._dof_for_actuator])
        P, q, A, l, u, meta = self._problem(data, h, target, task_weights=(np.asarray(target["task_weights"], dtype=float) if "task_weights" in target else None))
        problem = {"P": P, "q": q, "A": A, "l": l, "u": u}
        if self.acceptance_config is not None:
            self.last_stage1_snapshot = assembly_snapshot(problem, meta, stage="stage1")
        stage1_out = self._invoke(problem, method + "_stage1")
        if self.acceptance_config is not None:
            self.last_stage1_snapshot = immutable_copy({**self.last_stage1_snapshot, "x": stage1_out.get("x"), "raw_result": stage1_out})
            first = self._validated_decode(self.last_stage1_snapshot["raw_result"], self.last_stage1_snapshot, method)
            self.last_stage1_snapshot = immutable_copy({**self.last_stage1_snapshot, "validation": first["validation"]})
        else:
            first = self._decode(stage1_out, meta, method)
        if method != "B2" or not first["success"]:
            first["method"] = requested_method
            if method == "B2":
                first["stage2_dispatch"] = "NOT_RUN_NO_VALID_COMMAND"
            return first
        # B2 is a genuine two-stage HQP: preserve the stage-A task output up
        # to the frozen normalized tolerance, then minimize torque.
        achieved = np.asarray(first["task_output"], dtype=float)
        # Reuse stage-one physical linearization.  This leaves both solves
        # fully constrained, while avoiding duplicate MuJoCo Jacobian/mass
        # extraction and joint-limit work in B2's second HQP stage.
        P2, q2, A2, l2, u2, meta2 = self._problem(
            data, h, target, task_weights=self._b2_stage2_weights,
            torque_weight=1.0, fixed_task=achieved, physical=meta,
            stage2=True,
        )
        # Add a fixed task band; the second solve still contains all physical
        # rows and therefore cannot bypass contact, friction, or torque limits.
        nphysical = self._n_physical_rows
        stage2_values = self._structures["stage2"]["A"].data.reshape(
            (nphysical + self._n_task, self._nq), order="F"
        )
        # The fixed full CSC layout is column-major: write each task-band row
        # into the resident matrix without allocating a sparse concatenation.
        band_dense = self._structures["stage2"]["band_dense"]
        band_dense.fill(0.0)
        band_dense[:, :self.nv] = meta2["T"]
        np.copyto(stage2_values[nphysical:, :], band_dense)
        tol = self._hqp_tolerance
        np.copyto(l2[nphysical:], achieved - tol); np.copyto(u2[nphysical:], achieved + tol)
        meta2.update(band_center=achieved, band_tolerance=tol)
        problem2 = {"P": P2, "q": q2, "A": A2, "l": l2, "u": u2}
        if self.acceptance_config is not None:
            self.last_stage2_snapshot = assembly_snapshot(problem2, meta2, stage="stage2")
            self.last_stage1_witness = immutable_copy(stage1_witness(self.last_stage1_snapshot, self.last_stage2_snapshot, self.acceptance_config))
        stage2_out = self._invoke(
            problem2,
            "B2_stage2",
            max_iter_override=int(self.cfg.b2_stage2_max_iter),
        )
        if self.acceptance_config is not None:
            self.last_stage2_snapshot = immutable_copy({**self.last_stage2_snapshot, "x": stage2_out.get("x"), "raw_result": stage2_out})
            second = self._validated_decode(self.last_stage2_snapshot["raw_result"], self.last_stage2_snapshot, method)
            self.last_stage2_snapshot = immutable_copy({**self.last_stage2_snapshot, "validation": second["validation"]})
        else:
            second = self._decode(stage2_out, meta2, method)
        second["solver_calls"] = 2
        second["hqp_stage1"] = dict(first)
        second["method"] = requested_method
        budget_s = float(self.cfg.b2_stage2_budget_s)
        timings = [stage2_out.get(key) for key in ("solve_wall_time_s", "setup_time_s", "update_time_s")]
        stage2_wall_s = None if any(value is None for value in timings) else float(sum(timings))
        stage2_budget_exceeded = stage2_wall_s is not None and stage2_wall_s > budget_s
        stage2_class = osqp_status_name(stage2_out.get("status_val"))
        if (not second["success"]) or stage2_budget_exceeded:
            # Keep the stage-2 status visible while returning the already
            # validated stage-1 command exactly once.  This is a deterministic
            # fallback, never a second solve and never a claim that stage two
            # solved.
            fallback = dict(first)
            fallback["method"] = requested_method
            fallback["solver_calls"] = 2
            fallback["hqp_stage1"] = dict(first)
            fallback["fallback_used"] = True
            fallback["fallback_source"] = "B2_stage1_validated_solution"
            fallback["stage2_status"] = stage2_out.get("status", "unknown")
            fallback["stage2_status_val"] = stage2_out.get("status_val")
            fallback["stage2_iterations"] = stage2_out.get("iterations")
            fallback["stage2_wall_time_s"] = stage2_wall_s
            fallback["stage2_budget_s"] = budget_s
            fallback["stage2_budget_exceeded"] = stage2_budget_exceeded
            fallback["stage2_validation"] = second["validation"]
            fallback["stage2_raw_result"] = {k: v for k, v in stage2_out.items() if k not in ("x", "y")}
            fallback["stage2_real_optimizer_called"] = stage2_out.get("real_optimizer_called", False)
            fallback["stage2_callback_injection"] = stage2_out.get("callback_injection", False)
            fallback["stage2_fallback_reason"] = (
                "budget_exceeded" if stage2_budget_exceeded else
                stage2_class if stage2_out.get("status_val") != 1 else "stage2_candidate_invalid"
            )
            fallback["fallback_trigger"] = fallback["stage2_fallback_reason"]
            # The top-level status is deliberately the stage-2 status so
            # status_3/primal infeasible cannot be mistaken for a solved HQP.
            fallback["status"] = stage2_out.get("status", "unknown")
            fallback["status_val"] = stage2_out.get("status_val")
            fallback["raw_status"] = stage2_out.get("status")
            fallback["raw_status_val"] = stage2_out.get("status_val")
            fallback["status_class"] = stage2_class
            for field in ("real_optimizer_called", "callback_injection", "primal_residual", "dual_residual", "iterations", "solve_time_s", "solve_wall_time_s", "setup_time_s", "update_time_s", "solver_call_index"):
                fallback[field] = stage2_out.get(field)
            fallback["returned_command_source"] = "stage1"
            fallback["stage2_success"] = False
            fallback["success"] = True
            return fallback
        second["fallback_used"] = False
        second["returned_command_source"] = "stage2"
        return second
