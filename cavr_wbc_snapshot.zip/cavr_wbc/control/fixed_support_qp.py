"""Shared fixed-support physical QP for the STEP-02 equivalence audit.

The implementation is intentionally limited to zero-velocity snapshot states
with four fixed Go2 foot contacts.  It is not a walking controller or a safety
certificate.
"""

from __future__ import annotations

from dataclasses import dataclass
import contextlib
import io
import math
from typing import Any, Iterable

import mujoco
import numpy as np
import osqp
import scipy.sparse as sp

from cavr_wbc.models import ActuatorHealthModel
from cavr_wbc.platforms.go2_mujoco import (
    FOOT_NAMES,
    extract_actuator_joint_map,
    extract_healthy_torque_limits,
)


@dataclass(frozen=True)
class SolverSettings:
    eps_abs: float = 1e-8
    eps_rel: float = 1e-8
    max_iter: int = 100000
    polish: bool = True
    scaling: int = 10
    adaptive_rho: bool = True
    verbose: bool = False


@dataclass(frozen=True)
class ContactTemplate:
    foot_names: tuple[str, ...]
    geom_ids: tuple[int, ...]
    body_ids: tuple[int, ...]
    local_points: np.ndarray
    nominal_world_points: np.ndarray
    friction_mu: np.ndarray


@dataclass(frozen=True)
class PhysicalSnapshot:
    snapshot_id: str
    qpos: np.ndarray
    qvel: np.ndarray
    mass_matrix: np.ndarray
    bias_force: np.ndarray
    selection_matrix: np.ndarray
    contact_jacobian: np.ndarray
    contact_world_points: np.ndarray
    contact_acceleration_bias: np.ndarray
    task_matrix: np.ndarray
    task_bias: np.ndarray
    task_scales: np.ndarray
    task_weights: np.ndarray
    torque_scales: np.ndarray
    foot_names: tuple[str, ...]
    friction_mu: np.ndarray
    normal_force_upper: np.ndarray

    @property
    def nv(self) -> int:
        return int(self.mass_matrix.shape[0])

    @property
    def nu(self) -> int:
        return int(self.selection_matrix.shape[1])

    @property
    def nlambda(self) -> int:
        return int(self.contact_jacobian.shape[0])

    @property
    def task_dimension(self) -> int:
        return int(self.task_matrix.shape[0])

    @property
    def decision_dimension(self) -> int:
        return self.nv + self.nu + self.nlambda


@dataclass
class QpSolveResult:
    method: str
    status: str
    status_val: int
    success: bool
    qdd: np.ndarray | None
    tau: np.ndarray | None
    contact_force: np.ndarray | None
    task_output: np.ndarray | None
    task_objective: float | None
    torque_regularizer: float | None
    normalized_task_residual: np.ndarray | None
    validation: dict[str, Any]
    iterations: int
    solve_time_s: float
    setup_time_s: float
    primal_residual: float
    dual_residual: float
    solver_objective: float | None


def build_contact_template(
    model: mujoco.MjModel, data: mujoco.MjData
) -> ContactTemplate:
    """Freeze actual nominal contact points and model-combined friction."""

    names: list[str] = []
    geom_ids: list[int] = []
    body_ids: list[int] = []
    local_points: list[np.ndarray] = []
    world_points: list[np.ndarray] = []
    friction: list[float] = []
    for name in FOOT_NAMES:
        geom_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_GEOM, name)
        matches = [
            data.contact[index]
            for index in range(data.ncon)
            if int(data.contact[index].geom1) == geom_id
            or int(data.contact[index].geom2) == geom_id
        ]
        if len(matches) != 1:
            raise ValueError(
                f"Expected one nominal contact for {name}, observed {len(matches)}"
            )
        contact = matches[0]
        body_id = int(model.geom_bodyid[geom_id])
        world = np.asarray(contact.pos, dtype=float).copy()
        rotation = np.asarray(data.xmat[body_id], dtype=float).reshape(3, 3)
        local = rotation.T @ (world - data.xpos[body_id])
        names.append(name)
        geom_ids.append(geom_id)
        body_ids.append(body_id)
        local_points.append(local)
        world_points.append(world)
        friction.append(float(contact.friction[0]))
    return ContactTemplate(
        foot_names=tuple(names),
        geom_ids=tuple(geom_ids),
        body_ids=tuple(body_ids),
        local_points=np.vstack(local_points),
        nominal_world_points=np.vstack(world_points),
        friction_mu=np.asarray(friction, dtype=float),
    )


def actuator_selection_matrix(
    model: mujoco.MjModel, data: mujoco.MjData
) -> np.ndarray:
    """Reconstruct the exact sparse actuator-moment transpose B(q)."""

    matrix = np.zeros((model.nv, model.nu), dtype=float)
    for actuator in range(model.nu):
        address = int(data.moment_rowadr[actuator])
        count = int(data.moment_rownnz[actuator])
        for offset in range(count):
            position = address + offset
            dof = int(data.moment_colind[position])
            matrix[dof, actuator] = float(data.actuator_moment[position])
    return matrix


def contact_points_and_jacobian(
    model: mujoco.MjModel,
    data: mujoco.MjData,
    template: ContactTemplate,
) -> tuple[np.ndarray, np.ndarray]:
    points: list[np.ndarray] = []
    jacobians: list[np.ndarray] = []
    for body_id, local in zip(template.body_ids, template.local_points):
        rotation = np.asarray(data.xmat[body_id], dtype=float).reshape(3, 3)
        point = np.asarray(data.xpos[body_id], dtype=float) + rotation @ local
        jacobian = np.zeros((3, model.nv), dtype=float)
        rotational = np.zeros((3, model.nv), dtype=float)
        mujoco.mj_jac(model, data, jacobian, rotational, point, body_id)
        points.append(point)
        jacobians.append(jacobian)
    return np.vstack(points), np.vstack(jacobians)


def task_matrix(
    model: mujoco.MjModel,
    posture_actuator_names: tuple[str, str] = ("FR_thigh", "RL_thigh"),
) -> np.ndarray:
    """Build the frozen 6D base + two joint acceleration task map."""

    matrix = np.zeros((8, model.nv), dtype=float)
    matrix[:6, :6] = np.eye(6)
    mapping = {entry.actuator_name: entry for entry in extract_actuator_joint_map(model)}
    for row, name in enumerate(posture_actuator_names, start=6):
        matrix[row, mapping[name].dof_index] = 1.0
    return matrix


def build_physical_snapshot(
    model: mujoco.MjModel,
    template: ContactTemplate,
    snapshot_id: str,
    qpos: Iterable[float],
    *,
    task_scales: Iterable[float],
    task_weights: Iterable[float],
    normal_force_upper: float,
) -> PhysicalSnapshot:
    data = mujoco.MjData(model)
    data.qpos[:] = np.asarray(tuple(qpos), dtype=float)
    data.qvel[:] = 0.0
    data.ctrl[:] = 0.0
    mujoco.mj_forward(model, data)
    mass = np.zeros((model.nv, model.nv), dtype=float)
    mujoco.mj_fullM(model, data, mass)
    points, jacobian = contact_points_and_jacobian(model, data, template)
    scales = np.asarray(tuple(task_scales), dtype=float)
    weights = np.asarray(tuple(task_weights), dtype=float)
    if scales.shape != (8,) or weights.shape != (8,):
        raise ValueError("STEP-02 task scales and weights must have length 8")
    if np.any(scales <= 0.0) or np.any(weights <= 0.0):
        raise ValueError("task scales and weights must be strictly positive")
    return PhysicalSnapshot(
        snapshot_id=snapshot_id,
        qpos=data.qpos.copy(),
        qvel=data.qvel.copy(),
        mass_matrix=mass,
        bias_force=data.qfrc_bias.copy(),
        selection_matrix=actuator_selection_matrix(model, data),
        contact_jacobian=jacobian,
        contact_world_points=points,
        contact_acceleration_bias=np.zeros(jacobian.shape[0], dtype=float),
        task_matrix=task_matrix(model),
        task_bias=np.zeros(8, dtype=float),
        task_scales=scales,
        task_weights=weights,
        torque_scales=extract_healthy_torque_limits(model),
        foot_names=template.foot_names,
        friction_mu=template.friction_mu.copy(),
        normal_force_upper=np.full(len(template.foot_names), normal_force_upper),
    )


def snapshot_geometry_validation(
    model: mujoco.MjModel,
    template: ContactTemplate,
    qpos: Iterable[float],
    *,
    joint_limit_margin_rad: float,
    maximum_contact_displacement_m: float,
    required_actual_foot_contacts: int,
) -> dict[str, Any]:
    data = mujoco.MjData(model)
    data.qpos[:] = np.asarray(tuple(qpos), dtype=float)
    data.qvel[:] = 0.0
    mujoco.mj_forward(model, data)
    points, _ = contact_points_and_jacobian(model, data, template)
    displacement = np.linalg.norm(points - template.nominal_world_points, axis=1)
    margins = []
    joint_ranges = []
    for joint_id in range(model.njnt):
        if not bool(model.jnt_limited[joint_id]):
            continue
        address = int(model.jnt_qposadr[joint_id])
        value = float(data.qpos[address])
        lower, upper = (float(item) for item in model.jnt_range[joint_id])
        margins.append(min(value - lower, upper - value))
        joint_ranges.append(
            {
                "joint_id": joint_id,
                "joint_name": mujoco.mj_id2name(
                    model, mujoco.mjtObj.mjOBJ_JOINT, joint_id
                ),
                "qpos": value,
                "range": [lower, upper],
                "margin": min(value - lower, upper - value),
            }
        )
    contacting_feet = set()
    for contact_index in range(data.ncon):
        contact = data.contact[contact_index]
        for name, geom_id in zip(template.foot_names, template.geom_ids):
            if int(contact.geom1) == geom_id or int(contact.geom2) == geom_id:
                contacting_feet.add(name)
    minimum_margin = min(margins)
    valid = (
        minimum_margin >= joint_limit_margin_rad
        and float(np.max(displacement)) <= maximum_contact_displacement_m
        and len(contacting_feet) == required_actual_foot_contacts
        and np.isfinite(data.qpos).all()
    )
    return {
        "valid": bool(valid),
        "minimum_joint_limit_margin_rad": minimum_margin,
        "maximum_contact_point_displacement_m": float(np.max(displacement)),
        "contact_point_displacements_m": displacement.tolist(),
        "actual_contacting_feet": sorted(contacting_feet),
        "joint_ranges": joint_ranges,
        "velocity_limits_available": False,
    }


def generate_snapshot_panel(
    model: mujoco.MjModel,
    template: ContactTemplate,
    *,
    perturbation_max_rad: float,
    joint_limit_margin_rad: float,
    maximum_contact_displacement_m: float,
    required_actual_foot_contacts: int,
) -> list[dict[str, Any]]:
    data = mujoco.MjData(model)
    home_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_KEY, "home")
    mujoco.mj_resetDataKeyframe(model, data, home_id)
    data.qvel[:] = 0.0
    data.ctrl[:] = 0.0
    mujoco.mj_forward(model, data)
    q_home = data.qpos.copy()
    _, jacobian = contact_points_and_jacobian(model, data, template)
    _, singular_values, right = np.linalg.svd(jacobian, full_matrices=True)
    rank = int(np.linalg.matrix_rank(jacobian))
    nullspace = right[rank:].T
    joint_dofs = np.arange(6, model.nv)
    panel = [
        {
            "snapshot_id": "home_nominal",
            "qpos": q_home.tolist(),
            "qvel": np.zeros(model.nv).tolist(),
            "generalized_perturbation": np.zeros(model.nv).tolist(),
            "generator": "official_home_keyframe",
        }
    ]
    for basis_index in range(2):
        direction = nullspace[:, basis_index].copy()
        sign_anchor = int(np.argmax(np.abs(direction)))
        if direction[sign_anchor] < 0.0:
            direction *= -1.0
        maximum_joint = float(np.max(np.abs(direction[joint_dofs])))
        if maximum_joint <= 0.0:
            raise ValueError("Selected contact-nullspace direction has no joint motion")
        direction *= perturbation_max_rad / maximum_joint
        for sign, label in ((1.0, "plus"), (-1.0, "minus")):
            delta = sign * direction
            qpos = q_home.copy()
            mujoco.mj_integratePos(model, qpos, delta, 1.0)
            panel.append(
                {
                    "snapshot_id": f"contact_nullspace_{basis_index}_{label}",
                    "qpos": qpos.tolist(),
                    "qvel": np.zeros(model.nv).tolist(),
                    "generalized_perturbation": delta.tolist(),
                    "generator": "nominal_contact_jacobian_nullspace",
                }
            )
    for item in panel:
        item["pre_method_geometry_validation"] = snapshot_geometry_validation(
            model,
            template,
            item["qpos"],
            joint_limit_margin_rad=joint_limit_margin_rad,
            maximum_contact_displacement_m=maximum_contact_displacement_m,
            required_actual_foot_contacts=required_actual_foot_contacts,
        )
    metadata = {
        "contact_jacobian_rank": rank,
        "contact_jacobian_singular_values": singular_values.tolist(),
        "nullspace_dimension": int(nullspace.shape[1]),
    }
    for item in panel:
        item["panel_generator_metadata"] = metadata
    return panel


def friction_violation(
    contact_force: np.ndarray, friction_mu: np.ndarray
) -> np.ndarray:
    forces = np.asarray(contact_force, dtype=float).reshape(-1, 3)
    return np.abs(forces[:, 0]) + np.abs(forces[:, 1]) - friction_mu * forces[:, 2]


class FixedSupportPhysicalQp:
    """One physical-constraint source shared by B1, P0, and B1-LEX."""

    def __init__(
        self,
        snapshot: PhysicalSnapshot,
        rho: Iterable[float],
        settings: SolverSettings,
        *,
        secondary_task_fix_normalized_tolerance: float,
    ) -> None:
        self.snapshot = snapshot
        self.rho = np.asarray(tuple(rho), dtype=float)
        self.settings = settings
        self.secondary_task_fix_normalized_tolerance = float(
            secondary_task_fix_normalized_tolerance
        )
        if self.rho.shape != (snapshot.nu,):
            raise ValueError("rho shape must match actuator count")
        if np.any(self.rho < 0.0) or np.any(self.rho > 1.0):
            raise ValueError("rho values must lie in [0, 1]")
        self.qdd_slice = slice(0, snapshot.nv)
        self.tau_slice = slice(snapshot.nv, snapshot.nv + snapshot.nu)
        self.lambda_slice = slice(snapshot.nv + snapshot.nu, snapshot.decision_dimension)
        self.constraint_matrix, self.lower, self.upper = self._physical_constraints()

    def _physical_constraints(self) -> tuple[sp.csc_matrix, np.ndarray, np.ndarray]:
        s = self.snapshot
        n = s.decision_dimension
        # The friction constraints have a zero right-hand side. Algebraic row scaling
        # leaves the feasible set unchanged while preventing OSQP's global
        # relative stopping test from using the ~150 N gravity/force scale as
        # the admissible residual for friction rows.
        zero_rhs_numerical_scale = 10.0
        rows: list[np.ndarray] = []
        lower: list[float] = []
        upper: list[float] = []

        dynamics = np.zeros((s.nv, n), dtype=float)
        dynamics[:, self.qdd_slice] = s.mass_matrix
        dynamics[:, self.tau_slice] = -s.selection_matrix
        dynamics[:, self.lambda_slice] = -s.contact_jacobian.T
        rows.extend(dynamics)
        lower.extend((-s.bias_force).tolist())
        upper.extend((-s.bias_force).tolist())

        contact = np.zeros((s.nlambda, n), dtype=float)
        contact[:, self.qdd_slice] = s.contact_jacobian
        rows.extend(contact)
        lower.extend((-s.contact_acceleration_bias).tolist())
        upper.extend((-s.contact_acceleration_bias).tolist())

        torque_bound = self.rho * s.torque_scales
        for actuator in range(s.nu):
            row = np.zeros(n, dtype=float)
            row[self.tau_slice.start + actuator] = 1.0
            rows.append(row)
            lower.append(float(-torque_bound[actuator]))
            upper.append(float(torque_bound[actuator]))

        for foot in range(len(s.foot_names)):
            base = self.lambda_slice.start + 3 * foot
            mu = float(s.friction_mu[foot])
            for sx, sy in ((1.0, 1.0), (1.0, -1.0), (-1.0, 1.0), (-1.0, -1.0)):
                row = np.zeros(n, dtype=float)
                row[base] = sx
                row[base + 1] = sy
                row[base + 2] = -mu
                rows.append(zero_rhs_numerical_scale * row)
                lower.append(-np.inf)
                upper.append(0.0)
            normal = np.zeros(n, dtype=float)
            normal[base + 2] = 1.0
            rows.append(normal)
            lower.append(0.0)
            upper.append(float(s.normal_force_upper[foot]))
        return sp.csc_matrix(np.vstack(rows)), np.asarray(lower), np.asarray(upper)

    def _objective(
        self,
        desired_task: np.ndarray | None,
        torque_regularization_weight: float,
    ) -> tuple[sp.csc_matrix, np.ndarray]:
        s = self.snapshot
        n = s.decision_dimension
        hessian = np.zeros((n, n), dtype=float)
        linear = np.zeros(n, dtype=float)
        if desired_task is not None:
            desired = np.asarray(desired_task, dtype=float)
            if desired.shape != (s.task_dimension,):
                raise ValueError("desired task has the wrong dimension")
            transform = (
                np.sqrt(s.task_weights)[:, None]
                * (s.task_matrix / s.task_scales[:, None])
            )
            offset = np.sqrt(s.task_weights) * (
                (s.task_bias - desired) / s.task_scales
            )
            hessian[self.qdd_slice, self.qdd_slice] += 2.0 * (
                transform.T @ transform
            )
            linear[self.qdd_slice] += 2.0 * (transform.T @ offset)
        if torque_regularization_weight < 0.0:
            raise ValueError("torque regularization weight must be non-negative")
        if torque_regularization_weight > 0.0:
            diagonal = 2.0 * torque_regularization_weight / np.square(
                s.torque_scales
            )
            indices = np.arange(self.tau_slice.start, self.tau_slice.stop)
            hessian[indices, indices] += diagonal
        return sp.triu(sp.csc_matrix(hessian), format="csc"), linear

    def _solve(
        self,
        *,
        method: str,
        desired_task: np.ndarray | None,
        torque_regularization_weight: float,
        fixed_task_output: np.ndarray | None = None,
        warm_start: QpSolveResult | None = None,
    ) -> QpSolveResult:
        P, q = self._objective(desired_task, torque_regularization_weight)
        A = self.constraint_matrix
        lower = self.lower
        upper = self.upper
        if fixed_task_output is not None:
            target = np.asarray(fixed_task_output, dtype=float)
            if target.shape != (self.snapshot.task_dimension,):
                raise ValueError("fixed task output has the wrong dimension")
            task_rows = np.zeros(
                (self.snapshot.task_dimension, self.snapshot.decision_dimension),
                dtype=float,
            )
            task_rows[:, self.qdd_slice] = (
                self.snapshot.task_matrix / self.snapshot.task_scales[:, None]
            )
            tolerance = np.full(
                self.snapshot.task_dimension,
                self.secondary_task_fix_normalized_tolerance,
            )
            rhs = (
                target - self.snapshot.task_bias
            ) / self.snapshot.task_scales
            A = sp.vstack((A, sp.csc_matrix(task_rows)), format="csc")
            lower = np.concatenate((lower, rhs - tolerance))
            upper = np.concatenate((upper, rhs + tolerance))

        solver = osqp.OSQP()
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                solver.setup(
                    P=P,
                    q=q,
                    A=A,
                    l=lower,
                    u=upper,
                    eps_abs=self.settings.eps_abs,
                    eps_rel=self.settings.eps_rel,
                    max_iter=self.settings.max_iter,
                    polishing=self.settings.polish,
                    scaling=self.settings.scaling,
                    adaptive_rho=self.settings.adaptive_rho,
                    verbose=self.settings.verbose,
                )
                if warm_start is not None:
                    if not warm_start.success:
                        raise ValueError("warm-start result must be successful")
                    solver.warm_start(
                        x=np.concatenate(
                            (
                                warm_start.qdd,
                                warm_start.tau,
                                warm_start.contact_force,
                            )
                        )
                    )
                raw = solver.solve(raise_error=False)
        except Exception as exc:
            return QpSolveResult(
                method=method,
                status=f"exception:{type(exc).__name__}:{exc}",
                status_val=-1,
                success=False,
                qdd=None,
                tau=None,
                contact_force=None,
                task_output=None,
                task_objective=None,
                torque_regularizer=None,
                normalized_task_residual=None,
                validation={"available": False},
                iterations=0,
                solve_time_s=0.0,
                setup_time_s=0.0,
                primal_residual=math.inf,
                dual_residual=math.inf,
                solver_objective=None,
            )

        info = raw.info
        status_val = int(info.status_val)
        success = status_val == 1 and raw.x is not None and np.isfinite(raw.x).all()
        if not success:
            return QpSolveResult(
                method=method,
                status=str(info.status),
                status_val=status_val,
                success=False,
                qdd=None,
                tau=None,
                contact_force=None,
                task_output=None,
                task_objective=None,
                torque_regularizer=None,
                normalized_task_residual=None,
                validation={"available": False},
                iterations=int(info.iter),
                solve_time_s=float(info.solve_time),
                setup_time_s=float(info.setup_time),
                primal_residual=float(info.prim_res),
                dual_residual=float(info.dual_res),
                solver_objective=float(info.obj_val),
            )

        x = np.asarray(raw.x, dtype=float)
        qdd = x[self.qdd_slice].copy()
        tau = x[self.tau_slice].copy()
        contact_force = x[self.lambda_slice].copy()
        task_output = self.snapshot.task_matrix @ qdd + self.snapshot.task_bias
        normalized_residual = (
            None
            if desired_task is None
            else (task_output - np.asarray(desired_task)) / self.snapshot.task_scales
        )
        task_objective = (
            None
            if normalized_residual is None
            else float(
                np.sum(self.snapshot.task_weights * np.square(normalized_residual))
            )
        )
        torque_regularizer = float(
            np.sum(np.square(tau / self.snapshot.torque_scales))
        )
        validation = self.validate_witness(
            qdd, tau, contact_force, fixed_task_output=fixed_task_output
        )
        return QpSolveResult(
            method=method,
            status=str(info.status),
            status_val=status_val,
            success=True,
            qdd=qdd,
            tau=tau,
            contact_force=contact_force,
            task_output=task_output,
            task_objective=task_objective,
            torque_regularizer=torque_regularizer,
            normalized_task_residual=normalized_residual,
            validation=validation,
            iterations=int(info.iter),
            solve_time_s=float(info.solve_time),
            setup_time_s=float(info.setup_time),
            primal_residual=float(info.prim_res),
            dual_residual=float(info.dual_res),
            solver_objective=float(info.obj_val),
        )

    def solve_b1_soft(
        self, desired_task: Iterable[float], lambda_tau: float
    ) -> QpSolveResult:
        return self._solve(
            method="B1_SOFT",
            desired_task=np.asarray(tuple(desired_task), dtype=float),
            torque_regularization_weight=lambda_tau,
        )

    def solve_p0_stage1(self, desired_task: Iterable[float]) -> QpSolveResult:
        return self._solve(
            method="P0_STAGE1",
            desired_task=np.asarray(tuple(desired_task), dtype=float),
            torque_regularization_weight=0.0,
        )

    def solve_p0_stage2(
        self,
        projected_task: Iterable[float],
        lambda_tau: float,
        *,
        warm_start: QpSolveResult | None = None,
    ) -> QpSolveResult:
        return self._solve(
            method="P0_STAGE2",
            desired_task=None,
            torque_regularization_weight=lambda_tau,
            fixed_task_output=np.asarray(tuple(projected_task), dtype=float),
            warm_start=warm_start,
        )

    def solve_b1_lex_stage_a(self, desired_task: Iterable[float]) -> QpSolveResult:
        return self._solve(
            method="B1_LEX_STAGE_A",
            desired_task=np.asarray(tuple(desired_task), dtype=float),
            torque_regularization_weight=0.0,
        )

    def solve_b1_lex_stage_b(
        self,
        primary_task_output: Iterable[float],
        lambda_tau: float,
        *,
        warm_start: QpSolveResult | None = None,
    ) -> QpSolveResult:
        return self._solve(
            method="B1_LEX_STAGE_B",
            desired_task=None,
            torque_regularization_weight=lambda_tau,
            fixed_task_output=np.asarray(tuple(primary_task_output), dtype=float),
            warm_start=warm_start,
        )

    def validate_witness(
        self,
        qdd: np.ndarray,
        tau: np.ndarray,
        contact_force: np.ndarray,
        *,
        fixed_task_output: np.ndarray | None = None,
        active_tolerance: float = 1e-6,
    ) -> dict[str, Any]:
        s = self.snapshot
        dynamics = (
            s.mass_matrix @ qdd
            + s.bias_force
            - s.selection_matrix @ tau
            - s.contact_jacobian.T @ contact_force
        )
        contact = s.contact_jacobian @ qdd + s.contact_acceleration_bias
        bound = self.rho * s.torque_scales
        torque_violation = np.maximum(np.abs(tau) - bound, 0.0)
        forces = contact_force.reshape(-1, 3)
        friction = friction_violation(contact_force, s.friction_mu)
        normal_lower = np.maximum(-forces[:, 2], 0.0)
        normal_upper = np.maximum(forces[:, 2] - s.normal_force_upper, 0.0)
        health_output = np.asarray(
            ActuatorHealthModel().apply(tau, self.rho, s.torque_scales).u_health
        )
        task_value = s.task_matrix @ qdd + s.task_bias
        fixed_task_error = (
            None
            if fixed_task_output is None
            else (task_value - fixed_task_output) / s.task_scales
        )
        friction_margin = s.friction_mu * forces[:, 2] - (
            np.abs(forces[:, 0]) + np.abs(forces[:, 1])
        )
        return {
            "available": True,
            "dynamics_infinity_norm": float(np.max(np.abs(dynamics))),
            "contact_infinity_norm": float(np.max(np.abs(contact))),
            "torque_violation": float(np.max(torque_violation)),
            "friction_violation": float(np.max(np.maximum(friction, 0.0))),
            "normal_force_lower_violation": float(np.max(normal_lower)),
            "normal_force_upper_violation": float(np.max(normal_upper)),
            "hard_inequality_violation": float(
                max(
                    np.max(torque_violation),
                    np.max(np.maximum(friction, 0.0)),
                    np.max(normal_lower),
                    np.max(normal_upper),
                )
            ),
            "health_adapter_identity_error": float(
                np.max(np.abs(health_output - tau))
            ),
            "fixed_task_normalized_infinity_error": (
                None
                if fixed_task_error is None
                else float(np.max(np.abs(fixed_task_error)))
            ),
            "active_torque_constraints": int(
                np.count_nonzero(np.abs(bound - np.abs(tau)) <= active_tolerance)
            ),
            "active_friction_constraints": int(
                np.count_nonzero(friction_margin <= active_tolerance)
            ),
            "active_normal_lower_constraints": int(
                np.count_nonzero(forces[:, 2] <= active_tolerance)
            ),
            "active_normal_upper_constraints": int(
                np.count_nonzero(
                    s.normal_force_upper - forces[:, 2] <= active_tolerance
                )
            ),
            "torque_normalized_l2": float(
                np.linalg.norm(tau / s.torque_scales)
            ),
            "contact_force_l2_n": float(np.linalg.norm(contact_force)),
            "dynamics_residual": dynamics.tolist(),
            "contact_residual": contact.tolist(),
        }
