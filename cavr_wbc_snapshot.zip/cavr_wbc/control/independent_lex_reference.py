"""Independent Clarabel lexicographic reference for STEP-02R.

This module deliberately assembles the physical equations and cone constraints
without calling the OSQP constraint builder or OSQP solve path.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Any, Iterable

import clarabel
import numpy as np
import scipy.sparse as sp

from cavr_wbc.control.fixed_support_qp import PhysicalSnapshot, QpSolveResult
from cavr_wbc.control.scaled_fixed_support_qp import (
    validate_original_witness,
    variable_scales,
)


@dataclass(frozen=True)
class ClarabelReferenceSettings:
    max_iter: int = 500
    tol_gap_abs: float = 5e-11
    tol_gap_rel: float = 5e-11
    tol_feas: float = 5e-11
    tol_infeas_abs: float = 5e-11
    tol_infeas_rel: float = 5e-11
    equilibrate_enable: bool = True
    presolve_enable: bool = True
    iterative_refinement_enable: bool = True
    verbose: bool = False


@dataclass(frozen=True)
class ReferenceConstraintAssembly:
    equality_matrix: np.ndarray
    equality_rhs: np.ndarray
    equality_labels: tuple[str, ...]
    inequality_matrix: np.ndarray
    inequality_upper: np.ndarray
    inequality_labels: tuple[str, ...]


def assemble_reference_constraints_original(
    snapshot: PhysicalSnapshot,
    rho: Iterable[float],
    *,
    fixed_task_output: np.ndarray | None = None,
    fixed_task_normalized_tolerance: float = 1e-8,
) -> ReferenceConstraintAssembly:
    """Independent original-unit equality plus upper-inequality assembly."""

    health = np.asarray(tuple(rho), dtype=float)
    if health.shape != (snapshot.nu,):
        raise ValueError("rho shape must match actuator count")
    n = snapshot.decision_dimension
    qdd = slice(0, snapshot.nv)
    tau = slice(snapshot.nv, snapshot.nv + snapshot.nu)
    contact_force = slice(snapshot.nv + snapshot.nu, n)

    equalities: list[np.ndarray] = []
    equality_rhs: list[float] = []
    equality_labels: list[str] = []
    dynamics = np.zeros((snapshot.nv, n), dtype=float)
    dynamics[:, qdd] = snapshot.mass_matrix
    dynamics[:, tau] = -snapshot.selection_matrix
    dynamics[:, contact_force] = -snapshot.contact_jacobian.T
    equalities.extend(dynamics)
    equality_rhs.extend((-snapshot.bias_force).tolist())
    equality_labels.extend(
        f"reference_dynamics[{index}]" for index in range(snapshot.nv)
    )
    contact = np.zeros((snapshot.nlambda, n), dtype=float)
    contact[:, qdd] = snapshot.contact_jacobian
    equalities.extend(contact)
    equality_rhs.extend((-snapshot.contact_acceleration_bias).tolist())
    equality_labels.extend(
        f"reference_contact_acceleration[{index}]"
        for index in range(snapshot.nlambda)
    )

    inequalities: list[np.ndarray] = []
    inequality_upper: list[float] = []
    inequality_labels: list[str] = []
    torque_bound = health * snapshot.torque_scales
    for actuator in range(snapshot.nu):
        positive = np.zeros(n, dtype=float)
        positive[tau.start + actuator] = 1.0
        inequalities.append(positive)
        inequality_upper.append(float(torque_bound[actuator]))
        inequality_labels.append(f"reference_torque_upper[{actuator}]")
        inequalities.append(-positive)
        inequality_upper.append(float(torque_bound[actuator]))
        inequality_labels.append(f"reference_torque_lower[{actuator}]")

    for foot, name in enumerate(snapshot.foot_names):
        base = contact_force.start + 3 * foot
        mu = float(snapshot.friction_mu[foot])
        for face, (sx, sy) in enumerate(
            ((1.0, 1.0), (1.0, -1.0), (-1.0, 1.0), (-1.0, -1.0))
        ):
            row = np.zeros(n, dtype=float)
            row[base] = sx
            row[base + 1] = sy
            row[base + 2] = -mu
            inequalities.append(row)
            inequality_upper.append(0.0)
            inequality_labels.append(f"reference_friction[{name},{face}]")
        lower = np.zeros(n, dtype=float)
        lower[base + 2] = -1.0
        inequalities.append(lower)
        inequality_upper.append(0.0)
        inequality_labels.append(f"reference_normal_lower[{name}]")
        upper = -lower
        inequalities.append(upper)
        inequality_upper.append(float(snapshot.normal_force_upper[foot]))
        inequality_labels.append(f"reference_normal_upper[{name}]")

    if fixed_task_output is not None:
        target = np.asarray(fixed_task_output, dtype=float)
        if target.shape != (snapshot.task_dimension,):
            raise ValueError("fixed task output has the wrong dimension")
        tolerance = fixed_task_normalized_tolerance * snapshot.task_scales
        center = target - snapshot.task_bias
        for task_index in range(snapshot.task_dimension):
            row = np.zeros(n, dtype=float)
            row[qdd] = snapshot.task_matrix[task_index]
            inequalities.append(row)
            inequality_upper.append(float(center[task_index] + tolerance[task_index]))
            inequality_labels.append(f"reference_fixed_task_upper[{task_index}]")
            inequalities.append(-row)
            inequality_upper.append(float(-center[task_index] + tolerance[task_index]))
            inequality_labels.append(f"reference_fixed_task_lower[{task_index}]")

    return ReferenceConstraintAssembly(
        equality_matrix=np.vstack(equalities),
        equality_rhs=np.asarray(equality_rhs, dtype=float),
        equality_labels=tuple(equality_labels),
        inequality_matrix=np.vstack(inequalities),
        inequality_upper=np.asarray(inequality_upper, dtype=float),
        inequality_labels=tuple(inequality_labels),
    )


def _independent_row_scaling(matrix: np.ndarray, rhs: np.ndarray) -> np.ndarray:
    scales = np.empty(matrix.shape[0], dtype=float)
    for row in range(matrix.shape[0]):
        characteristic = max(
            float(np.max(np.abs(matrix[row]))), abs(float(rhs[row]))
        )
        scales[row] = 1.0 / characteristic if characteristic > 0.0 else 1.0
    return scales


class IndependentLexicographicReference:
    """Direct Clarabel reference with its own constraint assembly."""

    def __init__(
        self,
        snapshot: PhysicalSnapshot,
        rho: Iterable[float],
        settings: ClarabelReferenceSettings,
        *,
        secondary_task_fix_normalized_tolerance: float,
    ) -> None:
        self.snapshot = snapshot
        self.rho = np.asarray(tuple(rho), dtype=float)
        self.settings = settings
        self.secondary_task_fix_normalized_tolerance = float(
            secondary_task_fix_normalized_tolerance
        )
        self.variable_scales = variable_scales(snapshot)
        self.qdd_slice = slice(0, snapshot.nv)
        self.tau_slice = slice(snapshot.nv, snapshot.nv + snapshot.nu)
        self.lambda_slice = slice(snapshot.nv + snapshot.nu, snapshot.decision_dimension)
        self.accepted_settings: dict[str, Any] | None = None

    def _objective_original(
        self,
        desired_task: np.ndarray | None,
        torque_regularization_weight: float,
    ) -> tuple[np.ndarray, np.ndarray]:
        snapshot = self.snapshot
        hessian = np.zeros(
            (snapshot.decision_dimension, snapshot.decision_dimension), dtype=float
        )
        linear = np.zeros(snapshot.decision_dimension, dtype=float)
        if desired_task is not None:
            desired = np.asarray(desired_task, dtype=float)
            normalized_task = np.sqrt(snapshot.task_weights)[:, None] * (
                snapshot.task_matrix / snapshot.task_scales[:, None]
            )
            normalized_offset = np.sqrt(snapshot.task_weights) * (
                (snapshot.task_bias - desired) / snapshot.task_scales
            )
            hessian[self.qdd_slice, self.qdd_slice] += 2.0 * (
                normalized_task.T @ normalized_task
            )
            linear[self.qdd_slice] += 2.0 * (
                normalized_task.T @ normalized_offset
            )
        if torque_regularization_weight > 0.0:
            indices = np.arange(self.tau_slice.start, self.tau_slice.stop)
            hessian[indices, indices] += (
                2.0
                * torque_regularization_weight
                / np.square(snapshot.torque_scales)
            )
        return hessian, linear

    def _assemble_scaled_conic_problem(
        self,
        desired_task: np.ndarray | None,
        torque_regularization_weight: float,
        fixed_task_output: np.ndarray | None,
    ) -> tuple[
        sp.csc_matrix,
        np.ndarray,
        sp.csc_matrix,
        np.ndarray,
        list[Any],
        ReferenceConstraintAssembly,
        np.ndarray,
        np.ndarray,
    ]:
        original = assemble_reference_constraints_original(
            self.snapshot,
            self.rho,
            fixed_task_output=fixed_task_output,
            fixed_task_normalized_tolerance=(
                self.secondary_task_fix_normalized_tolerance
            ),
        )
        equality_variable_scaled = (
            original.equality_matrix * self.variable_scales[None, :]
        )
        inequality_variable_scaled = (
            original.inequality_matrix * self.variable_scales[None, :]
        )
        equality_row_scales = _independent_row_scaling(
            equality_variable_scaled, original.equality_rhs
        )
        inequality_row_scales = _independent_row_scaling(
            inequality_variable_scaled, original.inequality_upper
        )
        equality_matrix = equality_row_scales[:, None] * equality_variable_scaled
        inequality_matrix = (
            inequality_row_scales[:, None] * inequality_variable_scaled
        )
        A = sp.csc_matrix(np.vstack((equality_matrix, inequality_matrix)))
        b = np.concatenate(
            (
                equality_row_scales * original.equality_rhs,
                inequality_row_scales * original.inequality_upper,
            )
        )
        cones: list[Any] = [
            clarabel.ZeroConeT(equality_matrix.shape[0]),
            clarabel.NonnegativeConeT(inequality_matrix.shape[0]),
        ]
        original_p, original_q = self._objective_original(
            desired_task, torque_regularization_weight
        )
        scaled_p = (
            self.variable_scales[:, None]
            * original_p
            * self.variable_scales[None, :]
        )
        scaled_q = self.variable_scales * original_q
        return (
            sp.triu(sp.csc_matrix(scaled_p), format="csc"),
            scaled_q,
            A,
            b,
            cones,
            original,
            equality_row_scales,
            inequality_row_scales,
        )

    def _clarabel_settings(self) -> Any:
        settings = clarabel.DefaultSettings()
        settings.max_iter = self.settings.max_iter
        settings.tol_gap_abs = self.settings.tol_gap_abs
        settings.tol_gap_rel = self.settings.tol_gap_rel
        settings.tol_feas = self.settings.tol_feas
        settings.tol_infeas_abs = self.settings.tol_infeas_abs
        settings.tol_infeas_rel = self.settings.tol_infeas_rel
        settings.equilibrate_enable = self.settings.equilibrate_enable
        settings.presolve_enable = self.settings.presolve_enable
        settings.iterative_refinement_enable = (
            self.settings.iterative_refinement_enable
        )
        settings.verbose = self.settings.verbose
        fields = tuple(self.settings.__dataclass_fields__)
        self.accepted_settings = {
            field: getattr(settings, field) for field in fields
        }
        return settings

    def _solve(
        self,
        *,
        method: str,
        desired_task: np.ndarray | None,
        torque_regularization_weight: float,
        fixed_task_output: np.ndarray | None = None,
    ) -> QpSolveResult:
        try:
            P, q, A, b, cones, _, _, _ = self._assemble_scaled_conic_problem(
                desired_task,
                torque_regularization_weight,
                fixed_task_output,
            )
            solver = clarabel.DefaultSolver(
                P, q, A, b, cones, self._clarabel_settings()
            )
            raw = solver.solve()
        except Exception as exc:
            return QpSolveResult(
                method=method,
                status=f"exception:{type(exc).__name__}:{exc}",
                status_val=-1,
                success=False,
                qdd=None,
                tau=None,
                contact_force=None,
                task_output=None,
                task_objective=None,
                torque_regularizer=None,
                normalized_task_residual=None,
                validation={"available": False},
                iterations=0,
                solve_time_s=0.0,
                setup_time_s=0.0,
                primal_residual=math.inf,
                dual_residual=math.inf,
                solver_objective=None,
            )
        status = str(raw.status)
        success = status == "Solved" and raw.x is not None and np.isfinite(raw.x).all()
        if not success:
            return QpSolveResult(
                method=method,
                status=status,
                status_val=-1,
                success=False,
                qdd=None,
                tau=None,
                contact_force=None,
                task_output=None,
                task_objective=None,
                torque_regularizer=None,
                normalized_task_residual=None,
                validation={"available": False},
                iterations=int(raw.iterations),
                solve_time_s=float(raw.solve_time),
                setup_time_s=0.0,
                primal_residual=float(raw.r_prim),
                dual_residual=float(raw.r_dual),
                solver_objective=float(raw.obj_val),
            )
        original = np.asarray(raw.x, dtype=float) * self.variable_scales
        qdd = original[self.qdd_slice].copy()
        tau = original[self.tau_slice].copy()
        contact_force = original[self.lambda_slice].copy()
        task_output = self.snapshot.task_matrix @ qdd + self.snapshot.task_bias
        normalized_residual = (
            None
            if desired_task is None
            else (task_output - desired_task) / self.snapshot.task_scales
        )
        task_objective = (
            None
            if normalized_residual is None
            else float(
                np.sum(
                    self.snapshot.task_weights * np.square(normalized_residual)
                )
            )
        )
        torque_regularizer = float(
            np.sum(np.square(tau / self.snapshot.torque_scales))
        )
        validation = validate_original_witness(
            self.snapshot,
            self.rho,
            qdd,
            tau,
            contact_force,
            fixed_task_output=fixed_task_output,
        )
        dual_objective = getattr(raw, "obj_val_dual", None)
        validation["solver_dual_objective"] = (
            None if dual_objective is None else float(dual_objective)
        )
        validation["duality_gap"] = (
            None
            if dual_objective is None
            else abs(float(raw.obj_val) - float(dual_objective))
        )
        return QpSolveResult(
            method=method,
            status=status,
            status_val=1,
            success=True,
            qdd=qdd,
            tau=tau,
            contact_force=contact_force,
            task_output=task_output,
            task_objective=task_objective,
            torque_regularizer=torque_regularizer,
            normalized_task_residual=normalized_residual,
            validation=validation,
            iterations=int(raw.iterations),
            solve_time_s=float(raw.solve_time),
            setup_time_s=0.0,
            primal_residual=float(raw.r_prim),
            dual_residual=float(raw.r_dual),
            solver_objective=float(raw.obj_val),
        )

    def solve_stage_a(self, desired_task: Iterable[float]) -> QpSolveResult:
        return self._solve(
            method="B1_LEX_REFERENCE_INDEPENDENT_STAGE_A",
            desired_task=np.asarray(tuple(desired_task), dtype=float),
            torque_regularization_weight=0.0,
        )

    def solve_stage_b(
        self, projected_task: Iterable[float], lambda_tau: float
    ) -> QpSolveResult:
        return self._solve(
            method="B1_LEX_REFERENCE_INDEPENDENT_STAGE_B",
            desired_task=None,
            torque_regularization_weight=lambda_tau,
            fixed_task_output=np.asarray(tuple(projected_task), dtype=float),
        )

    def audit_problem(
        self,
        *,
        desired_task: Iterable[float] | None = None,
        torque_regularization_weight: float = 0.0,
        fixed_task_output: Iterable[float] | None = None,
    ) -> dict[str, Any]:
        desired = (
            None
            if desired_task is None
            else np.asarray(tuple(desired_task), dtype=float)
        )
        target = (
            None
            if fixed_task_output is None
            else np.asarray(tuple(fixed_task_output), dtype=float)
        )
        P, q, A, b, _, original, eq_scale, ineq_scale = (
            self._assemble_scaled_conic_problem(
                desired, torque_regularization_weight, target
            )
        )
        return {
            "variable_scales": self.variable_scales.tolist(),
            "original_equality_labels": list(original.equality_labels),
            "original_equality_matrix": original.equality_matrix.tolist(),
            "original_equality_rhs": original.equality_rhs.tolist(),
            "original_inequality_labels": list(original.inequality_labels),
            "original_inequality_matrix": original.inequality_matrix.tolist(),
            "original_inequality_upper": original.inequality_upper.tolist(),
            "equality_row_scaling": eq_scale.tolist(),
            "inequality_row_scaling": ineq_scale.tolist(),
            "scaled_conic_A": A.toarray().tolist(),
            "scaled_conic_b": b.tolist(),
            "scaled_P": P.toarray().tolist(),
            "scaled_q": q.tolist(),
        }
