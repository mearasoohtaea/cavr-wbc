"""Transparent torque-space joint PD controller for the healthy Go2 replay."""

from __future__ import annotations

from dataclasses import dataclass

import mujoco
import numpy as np


@dataclass(frozen=True)
class JointPdController:
    kp: np.ndarray
    kd: np.ndarray
    q_reference: np.ndarray
    include_bias_compensation: bool = True

    def __post_init__(self) -> None:
        for name, value in (
            ("kp", self.kp),
            ("kd", self.kd),
            ("q_reference", self.q_reference),
        ):
            array = np.asarray(value, dtype=float)
            if array.ndim != 1 or not np.isfinite(array).all():
                raise ValueError(f"{name} must be a finite one-dimensional array")
        if self.kp.shape != self.kd.shape or self.kp.shape != self.q_reference.shape:
            raise ValueError("kp, kd, and q_reference must have matching shapes")
        if np.any(self.kp < 0.0) or np.any(self.kd < 0.0):
            raise ValueError("PD gains must be non-negative")

    def compute(
        self, model: mujoco.MjModel, data: mujoco.MjData
    ) -> tuple[np.ndarray, dict[str, list[float] | bool]]:
        if model.nu != self.q_reference.size:
            raise ValueError("controller reference size does not match model.nu")
        joint_ids = model.actuator_trnid[:, 0].astype(int)
        qpos_addresses = model.jnt_qposadr[joint_ids]
        dof_addresses = model.jnt_dofadr[joint_ids]
        position_error = self.q_reference - data.qpos[qpos_addresses]
        velocity_error = -data.qvel[dof_addresses]
        compensation = (
            data.qfrc_bias[dof_addresses].copy()
            if self.include_bias_compensation
            else np.zeros(model.nu, dtype=float)
        )
        u_raw = self.kp * position_error + self.kd * velocity_error + compensation
        diagnostics = {
            "position_error": position_error.astype(float).tolist(),
            "velocity_error": velocity_error.astype(float).tolist(),
            "bias_compensation": compensation.astype(float).tolist(),
            "bias_compensation_enabled": self.include_bias_compensation,
        }
        return u_raw, diagnostics

