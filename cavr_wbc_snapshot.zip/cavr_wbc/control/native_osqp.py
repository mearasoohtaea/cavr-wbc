"""Small ctypes bridge to the fixed native OSQP workspace.

This module contains no controller policy. It only owns a persistent native
OSQP workspace and transfers the frozen CSC numeric buffers. The compiled
library is selected explicitly by the retry runner via
``CAVR_WBC_NATIVE_OSQP_DLL``; normal Python experiments remain unchanged.
"""

from __future__ import annotations

import ctypes
import os
from pathlib import Path
from typing import Any

import numpy as np


class NativeOSQPError(RuntimeError):
    pass


def _ptr(array: np.ndarray) -> Any:
    return array.ctypes.data_as(ctypes.POINTER(ctypes.c_double))


def _iptr(array: np.ndarray) -> Any:
    return array.ctypes.data_as(ctypes.POINTER(ctypes.c_int))


def _native_bounds(array: np.ndarray) -> np.ndarray:
    """Translate NumPy infinities to the OSQP C API's finite infinity."""
    out = np.asarray(array, dtype=np.float64, order="C").copy()
    out[np.isneginf(out)] = -1.0e30
    out[np.isposinf(out)] = 1.0e30
    return out


class NativeOSQP:
    """Persistent OSQP C API workspace for one fixed CSC structure."""

    def __init__(self, P: Any, A: Any, q: np.ndarray, l: np.ndarray, u: np.ndarray,
                 *, eps_abs: float, eps_rel: float, max_iter: int) -> None:
        dll_path = os.environ.get("CAVR_WBC_NATIVE_OSQP_DLL")
        if not dll_path:
            raise NativeOSQPError("CAVR_WBC_NATIVE_OSQP_DLL is not set")
        path = Path(dll_path)
        if not path.is_file():
            raise NativeOSQPError(f"native OSQP DLL not found: {path}")
        P = P.tocsc(copy=False)
        A = A.tocsc(copy=False)
        P.sort_indices(); A.sort_indices()
        self.P_i = np.asarray(P.indices, dtype=np.int32, order="C")
        self.P_p = np.asarray(P.indptr, dtype=np.int32, order="C")
        self.P_x = np.asarray(P.data, dtype=np.float64, order="C").copy()
        self.A_i = np.asarray(A.indices, dtype=np.int32, order="C")
        self.A_p = np.asarray(A.indptr, dtype=np.int32, order="C")
        self.A_x = np.asarray(A.data, dtype=np.float64, order="C").copy()
        self.q = np.asarray(q, dtype=np.float64, order="C").copy()
        self.l = _native_bounds(l)
        self.u = _native_bounds(u)
        self.n = int(P.shape[1]); self.m = int(A.shape[0])
        # Python 3.8+ does not necessarily search PATH for dependent DLLs.
        # Keep the native dependency directory explicit and auditable.
        self._dll_dirs = []
        if hasattr(os, "add_dll_directory"):
            self._dll_dirs.append(os.add_dll_directory(str(path.parent)))
            native_bin = os.environ.get("CAVR_WBC_NATIVE_OSQP_BIN")
            if native_bin and Path(native_bin).is_dir():
                self._dll_dirs.append(os.add_dll_directory(native_bin))
        self._lib = ctypes.WinDLL(str(path))
        self._lib.cavr_osqp_create.argtypes = [
            ctypes.c_int, ctypes.c_int,
            ctypes.c_int, ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_double),
            ctypes.c_int, ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_double),
            ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_double),
            ctypes.c_double, ctypes.c_double, ctypes.c_int,
        ]
        self._lib.cavr_osqp_create.restype = ctypes.c_void_p
        self._lib.cavr_osqp_update.argtypes = [
            ctypes.c_void_p, ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_double),
            ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_double),
        ]
        self._lib.cavr_osqp_update.restype = ctypes.c_int
        self._lib.cavr_osqp_warm_start.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_double)]
        self._lib.cavr_osqp_warm_start.restype = ctypes.c_int
        self._lib.cavr_osqp_solve.argtypes = [
            ctypes.c_void_p, ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_double),
            ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_int),
            ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_double),
            ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_double),
        ]
        self._lib.cavr_osqp_solve.restype = ctypes.c_int
        self._lib.cavr_osqp_destroy.argtypes = [ctypes.c_void_p]
        self._lib.cavr_osqp_destroy.restype = None
        self._handle = self._lib.cavr_osqp_create(
            self.n, self.m,
            int(self.P_x.size), _iptr(self.P_i), _iptr(self.P_p), _ptr(self.P_x),
            int(self.A_x.size), _iptr(self.A_i), _iptr(self.A_p), _ptr(self.A_x),
            _ptr(self.q), _ptr(self.l), _ptr(self.u),
            float(eps_abs), float(eps_rel), int(max_iter),
        )
        if not self._handle:
            raise NativeOSQPError("native osqp_setup failed")
        self.last_x: np.ndarray | None = None
        self.last_y: np.ndarray | None = None
        self.setup_count = 1

    def update(self, P_x: np.ndarray, A_x: np.ndarray, q: np.ndarray, l: np.ndarray, u: np.ndarray) -> float:
        self.P_x = np.asarray(P_x, dtype=np.float64, order="C").copy()
        self.A_x = np.asarray(A_x, dtype=np.float64, order="C").copy()
        self.q = np.asarray(q, dtype=np.float64, order="C").copy()
        self.l = _native_bounds(l)
        self.u = _native_bounds(u)
        rc = self._lib.cavr_osqp_update(self._handle, _ptr(self.P_x), _ptr(self.A_x), _ptr(self.q), _ptr(self.l), _ptr(self.u))
        if rc != 0:
            raise NativeOSQPError(f"native osqp_update failed: {rc}")
        return 0.0

    def solve(self, *, warm_start: bool) -> dict[str, Any]:
        if warm_start and self.last_x is not None and self.last_y is not None:
            rc = self._lib.cavr_osqp_warm_start(self._handle, _ptr(self.last_x), _ptr(self.last_y))
            if rc != 0:
                raise NativeOSQPError(f"native osqp_warm_start failed: {rc}")
        x = np.zeros(self.n, dtype=np.float64); y = np.zeros(self.m, dtype=np.float64)
        status = ctypes.c_int(-1); iterations = ctypes.c_int(0)
        setup_s = ctypes.c_double(0.0); solve_s = ctypes.c_double(0.0); run_s = ctypes.c_double(0.0)
        prim = ctypes.c_double(float("nan")); dual = ctypes.c_double(float("nan"))
        rc = self._lib.cavr_osqp_solve(
            self._handle, _ptr(x), _ptr(y), ctypes.byref(status), ctypes.byref(iterations),
            ctypes.byref(setup_s), ctypes.byref(solve_s), ctypes.byref(run_s), ctypes.byref(prim), ctypes.byref(dual),
        )
        if rc != 0:
            raise NativeOSQPError(f"native osqp_solve failed: {rc}")
        self.last_x = x.copy(); self.last_y = y.copy()
        status_val = int(status.value)
        return {
            "x": x, "y": y, "status": {1: "solved", 2: "solved inaccurate"}.get(status_val, f"status_{status_val}"),
            "status_val": status_val, "iterations": int(iterations.value),
            "solve_time_s": float(solve_s.value), "solve_wall_time_s": float(run_s.value),
            "setup_time_s": float(setup_s.value), "update_time_s": 0.0,
            "workspace_reused": True, "warm_started": bool(warm_start),
            "primal_residual": float(prim.value), "dual_residual": float(dual.value),
        }

    def close(self) -> None:
        if getattr(self, "_handle", None):
            self._lib.cavr_osqp_destroy(self._handle)
            self._handle = None

    def __del__(self) -> None:  # pragma: no cover
        try:
            self.close()
        except Exception:
            pass
