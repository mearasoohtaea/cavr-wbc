"""Small ctypes boundary for the compiled MuJoCo P1 interval evaluator."""

from __future__ import annotations

import ctypes
import os
import sys
from pathlib import Path
from typing import Any

import numpy as np


class _Point(ctypes.Structure):
    _fields_ = [
        ("minimum_margin", ctypes.c_double),
        ("roll", ctypes.c_double),
        ("pitch", ctypes.c_double),
        ("height", ctypes.c_double),
        ("velocity", ctypes.c_double),
        ("terminal", ctypes.c_int),
        ("safety", ctypes.c_int),
        ("ncon", ctypes.c_int),
        ("propagation_step", ctypes.c_int),
        ("normal", ctypes.c_double * 4),
        ("tangential", ctypes.c_double * 4),
        ("friction_margin", ctypes.c_double * 4),
        ("contact_present", ctypes.c_int * 4),
        ("reason_mask", ctypes.c_int),
    ]


class NativeP1Evaluator:
    """Call the native MuJoCo rollout/evaluator in one crossing."""

    def __init__(self, dll: str | os.PathLike[str]) -> None:
        self.path = Path(dll).resolve()
        if not self.path.is_file():
            raise FileNotFoundError(self.path)
        self._dll_dirs = []
        search_dirs = [self.path.parent]
        configured = os.environ.get("CAVR_WBC_NATIVE_P1_BIN")
        if configured:
            search_dirs.append(Path(configured))
        search_dirs.append(Path(sys.executable).resolve().parent / "Lib" / "site-packages" / "mujoco")
        if hasattr(os, "add_dll_directory"):
            self._dll_dirs = [os.add_dll_directory(str(p)) for p in search_dirs if p.is_dir()]
        self._lib = ctypes.WinDLL(str(self.path))
        self._fn = self._lib.cavr_p1_rollout
        self._fn.argtypes = [
            ctypes.c_void_p, ctypes.c_void_p,
            ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_double),
            ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
            ctypes.POINTER(ctypes.c_int), ctypes.POINTER(_Point),
            ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_double),
            ctypes.POINTER(ctypes.c_double),
        ]
        self._fn.restype = ctypes.c_int

    def rollout(
        self,
        model: Any,
        data: Any,
        tau: np.ndarray,
        torque_limits: np.ndarray,
        sample_steps: np.ndarray,
    ) -> dict[str, np.ndarray]:
        tau = np.ascontiguousarray(np.asarray(tau, dtype=np.float64).reshape(-1))
        torque_limits = np.ascontiguousarray(np.asarray(torque_limits, dtype=np.float64).reshape(-1))
        sample_steps = np.ascontiguousarray(np.asarray(sample_steps, dtype=np.int32).reshape(-1))
        points = (_Point * int(sample_steps.size))()
        qpos = np.empty((sample_steps.size, int(model.nq)), dtype=np.float64)
        qvel = np.empty((sample_steps.size, int(model.nv)), dtype=np.float64)
        actual = np.empty((sample_steps.size, int(model.nu)), dtype=np.float64)
        rc = self._fn(
            ctypes.c_void_p(int(model._address)), ctypes.c_void_p(int(data._address)),
            tau.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
            torque_limits.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
            int(model.nu), int(model.nq), int(model.nv), int(sample_steps.size),
            sample_steps.ctypes.data_as(ctypes.POINTER(ctypes.c_int)), points,
            qpos.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
            qvel.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
            actual.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
        )
        if rc != 0:
            raise RuntimeError(f"native P1 evaluator failed with code {rc}")
        return {
            "points": points,
            "qpos": qpos,
            "qvel": qvel,
            "actual_force": actual,
        }


_CACHE: dict[str, NativeP1Evaluator] = {}


def native_p1_from_env() -> NativeP1Evaluator | None:
    dll = os.environ.get("CAVR_WBC_NATIVE_P1_DLL")
    if not dll:
        return None
    key = str(Path(dll).resolve())
    if key not in _CACHE:
        _CACHE[key] = NativeP1Evaluator(key)
    return _CACHE[key]
