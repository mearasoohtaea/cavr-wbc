"""Dimensionless OSQP formulation for the frozen STEP-02R audit.

The physical decision remains ``w = [qdd, tau, lambda]``.  OSQP sees the
invertible coordinate ``w_hat`` with ``w = D_variable w_hat`` and a positive
deterministic scaling of every constraint row.  All reported witnesses and
residuals are converted back to original physical units.
"""

from __future__ import annotations

from dataclasses import dataclass
import contextlib
import io
import math
from typing import Any, Iterable

import numpy as np
import osqp
import scipy.sparse as sp

from cavr_wbc.control.fixed_support_qp import PhysicalSnapshot, QpSolveResult
from cavr_wbc.models import ActuatorHealthModel


@dataclass(frozen=True)
class Step02rSolverSettings:
    eps_abs: float = 1e-10
    eps_rel: float = 1e-10
    max_iter: int = 200000
    polish: bool = True
    scaling: int = 10
    adaptive_rho: bool = True
    scaled_termination: bool = True
    check_termination: int = 25
    verbose: bool = False


@dataclass(frozen=True)
class ConstraintAssembly:
    matrix: sp.csc_matrix
    lower: np.ndarray
    upper: np.ndarray
    row_labels: tuple[str, ...]


@dataclass(frozen=True)
class ScaledConstraintAssembly:
    original: ConstraintAssembly
    variable_scales: np.ndarray
    variable_scaled_matrix: sp.csc_matrix
    row_scales: np.ndarray
    matrix: sp.csc_matrix
    lower: np.ndarray
    upper: np.ndarray


def variable_scales(snapshot: PhysicalSnapshot) -> np.ndarray:
    """Return the predeclared invertible STEP-02R physical-unit scales."""

    if snapshot.nv != 18:
        raise ValueError("STEP-02R is frozen to the Go2 nv=18 model")
    qdd = np.concatenate((np.ones(3), np.full(3, 2.0), np.full(12, 10.0)))
    tau = snapshot.torque_scales.copy()
    if not np.allclose(snapshot.normal_force_upper, snapshot.normal_force_upper[0]):
        raise ValueError("STEP-02R requires one frozen robot-weight force scale")
    contact = np.full(snapshot.nlambda, snapshot.normal_force_upper[0])
    scales = np.concatenate((qdd, tau, contact))
    if scales.shape != (snapshot.decision_dimension,) or np.any(scales <= 0.0):
        raise ValueError("variable scaling must be positive and dimensionally complete")
    return scales


def assemble_original_physical_constraints(
    snapshot: PhysicalSnapshot, rho: Iterable[float]
) -> ConstraintAssembly:
    """Assemble the physical-unit OSQP box form without numerical scaling."""

    health = np.asarray(tuple(rho), dtype=float)
    if health.shape != (snapshot.nu,):
        raise ValueError("rho shape must match actuator count")
    if np.any(health < 0.0) or np.any(health > 1.0):
        raise ValueError("rho values must lie in [0, 1]")
    n = snapshot.decision_dimension
    qdd = slice(0, snapshot.nv)
    tau = slice(snapshot.nv, snapshot.nv + snapshot.nu)
    contact_force = slice(snapshot.nv + snapshot.nu, n)
    rows: list[np.ndarray] = []
    lower: list[float] = []
    upper: list[float] = []
    labels: list[str] = []

    dynamics = np.zeros((snapshot.nv, n), dtype=float)
    dynamics[:, qdd] = snapshot.mass_matrix
    dynamics[:, tau] = -snapshot.selection_matrix
    dynamics[:, contact_force] = -snapshot.contact_jacobian.T
    rows.extend(dynamics)
    lower.extend((-snapshot.bias_force).tolist())
    upper.extend((-snapshot.bias_force).tolist())
    labels.extend(f"dynamics[{index}]" for index in range(snapshot.nv))

    contact = np.zeros((snapshot.nlambda, n), dtype=float)
    contact[:, qdd] = snapshot.contact_jacobian
    rows.extend(contact)
    lower.extend((-snapshot.contact_acceleration_bias).tolist())
    upper.extend((-snapshot.contact_acceleration_bias).tolist())
    labels.extend(f"contact_acceleration[{index}]" for index in range(snapshot.nlambda))

    torque_bound = health * snapshot.torque_scales
    for actuator in range(snapshot.nu):
        row = np.zeros(n, dtype=float)
        row[tau.start + actuator] = 1.0
        rows.append(row)
        lower.append(float(-torque_bound[actuator]))
        upper.append(float(torque_bound[actuator]))
        labels.append(f"torque_bound[{actuator}]")

    for foot, name in enumerate(snapshot.foot_names):
        base = contact_force.start + 3 * foot
        mu = float(snapshot.friction_mu[foot])
        for face, (sx, sy) in enumerate(
            ((1.0, 1.0), (1.0, -1.0), (-1.0, 1.0), (-1.0, -1.0))
        ):
            row = np.zeros(n, dtype=float)
            row[base] = sx
            row[base + 1] = sy
            row[base + 2] = -mu
            rows.append(row)
            lower.append(-np.inf)
            upper.append(0.0)
            labels.append(f"friction[{name},{face}]")
        normal = np.zeros(n, dtype=float)
        normal[base + 2] = 1.0
        rows.append(normal)
        lower.append(0.0)
        upper.append(float(snapshot.normal_force_upper[foot]))
        labels.append(f"normal_force[{name}]")
    return ConstraintAssembly(
        matrix=sp.csc_matrix(np.vstack(rows)),
        lower=np.asarray(lower, dtype=float),
        upper=np.asarray(upper, dtype=float),
        row_labels=tuple(labels),
    )


def append_fixed_task_constraints(
    assembly: ConstraintAssembly,
    snapshot: PhysicalSnapshot,
    target: Iterable[float],
    normalized_tolerance: float,
) -> ConstraintAssembly:
    target_array = np.asarray(tuple(target), dtype=float)
    if target_array.shape != (snapshot.task_dimension,):
        raise ValueError("fixed task target has the wrong dimension")
    if normalized_tolerance < 0.0:
        raise ValueError("fixed task tolerance must be non-negative")
    rows = np.zeros(
        (snapshot.task_dimension, snapshot.decision_dimension), dtype=float
    )
    rows[:, : snapshot.nv] = snapshot.task_matrix
    physical_tolerance = normalized_tolerance * snapshot.task_scales
    rhs = target_array - snapshot.task_bias
    return ConstraintAssembly(
        matrix=sp.vstack((assembly.matrix, sp.csc_matrix(rows)), format="csc"),
        lower=np.concatenate((assembly.lower, rhs - physical_tolerance)),
        upper=np.concatenate((assembly.upper, rhs + physical_tolerance)),
        row_labels=assembly.row_labels
        + tuple(f"fixed_task[{index}]" for index in range(snapshot.task_dimension)),
    )


def scale_constraint_assembly(
    assembly: ConstraintAssembly, scales: np.ndarray
) -> ScaledConstraintAssembly:
    """Apply variable conversion and a positive max-magnitude scale to every row."""

    variable_scaled = assembly.matrix @ sp.diags(scales, format="csc")
    csr = variable_scaled.tocsr()
    row_scales = np.empty(csr.shape[0], dtype=float)
    for row in range(csr.shape[0]):
        coefficients = np.abs(csr.data[csr.indptr[row] : csr.indptr[row + 1]])
        characteristic = float(np.max(coefficients)) if coefficients.size else 0.0
        if np.isfinite(assembly.lower[row]):
            characteristic = max(characteristic, abs(float(assembly.lower[row])))
        if np.isfinite(assembly.upper[row]):
            characteristic = max(characteristic, abs(float(assembly.upper[row])))
        row_scales[row] = 1.0 / characteristic if characteristic > 0.0 else 1.0
    scaled_matrix = sp.diags(row_scales, format="csc") @ variable_scaled
    lower = assembly.lower * row_scales
    upper = assembly.upper * row_scales
    return ScaledConstraintAssembly(
        original=assembly,
        variable_scales=scales.copy(),
        variable_scaled_matrix=sp.csc_matrix(variable_scaled),
        row_scales=row_scales,
        matrix=sp.csc_matrix(scaled_matrix),
        lower=lower,
        upper=upper,
    )


def constraint_violation(
    matrix: sp.csc_matrix,
    lower: np.ndarray,
    upper: np.ndarray,
    value: np.ndarray,
) -> float:
    product = np.asarray(matrix @ value).ravel()
    lower_violation = np.where(np.isfinite(lower), lower - product, -np.inf)
    upper_violation = np.where(np.isfinite(upper), product - upper, -np.inf)
    return float(max(0.0, np.max(lower_violation), np.max(upper_violation)))


def validate_original_witness(
    snapshot: PhysicalSnapshot,
    rho: Iterable[float],
    qdd: np.ndarray,
    tau: np.ndarray,
    contact_force: np.ndarray,
    *,
    fixed_task_output: np.ndarray | None = None,
    active_tolerance: float = 1e-6,
) -> dict[str, Any]:
    """Authoritative post-solve validation in original physical units."""

    health = np.asarray(tuple(rho), dtype=float)
    dynamics = (
        snapshot.mass_matrix @ qdd
        + snapshot.bias_force
        - snapshot.selection_matrix @ tau
        - snapshot.contact_jacobian.T @ contact_force
    )
    contact = snapshot.contact_jacobian @ qdd + snapshot.contact_acceleration_bias
    bound = health * snapshot.torque_scales
    torque_violation = np.maximum(np.abs(tau) - bound, 0.0)
    forces = contact_force.reshape(-1, 3)
    friction_raw = (
        np.abs(forces[:, 0])
        + np.abs(forces[:, 1])
        - snapshot.friction_mu * forces[:, 2]
    )
    normal_lower = np.maximum(-forces[:, 2], 0.0)
    normal_upper = np.maximum(
        forces[:, 2] - snapshot.normal_force_upper, 0.0
    )
    health_output = np.asarray(
        ActuatorHealthModel().apply(tau, health, snapshot.torque_scales).u_health
    )
    task_value = snapshot.task_matrix @ qdd + snapshot.task_bias
    fixed_error = (
        None
        if fixed_task_output is None
        else (task_value - fixed_task_output) / snapshot.task_scales
    )
    friction_margin = snapshot.friction_mu * forces[:, 2] - (
        np.abs(forces[:, 0]) + np.abs(forces[:, 1])
    )
    return {
        "available": True,
        "dynamics_infinity_norm": float(np.max(np.abs(dynamics))),
        "contact_infinity_norm": float(np.max(np.abs(contact))),
        "torque_violation": float(np.max(torque_violation)),
        "friction_violation": float(np.max(np.maximum(friction_raw, 0.0))),
        "normal_force_lower_violation": float(np.max(normal_lower)),
        "normal_force_upper_violation": float(np.max(normal_upper)),
        "hard_inequality_violation": float(
            max(
                np.max(torque_violation),
                np.max(np.maximum(friction_raw, 0.0)),
                np.max(normal_lower),
                np.max(normal_upper),
            )
        ),
        "health_adapter_identity_error": float(
            np.max(np.abs(health_output - tau))
        ),
        "fixed_task_normalized_infinity_error": (
            None if fixed_error is None else float(np.max(np.abs(fixed_error)))
        ),
        "active_torque_constraints": int(
            np.count_nonzero(np.abs(bound - np.abs(tau)) <= active_tolerance)
        ),
        "active_friction_constraints": int(
            np.count_nonzero(friction_margin <= active_tolerance)
        ),
        "active_normal_lower_constraints": int(
            np.count_nonzero(forces[:, 2] <= active_tolerance)
        ),
        "active_normal_upper_constraints": int(
            np.count_nonzero(
                snapshot.normal_force_upper - forces[:, 2] <= active_tolerance
            )
        ),
        "torque_normalized_l2": float(
            np.linalg.norm(tau / snapshot.torque_scales)
        ),
        "contact_force_l2_n": float(np.linalg.norm(contact_force)),
        "dynamics_residual": dynamics.tolist(),
        "contact_residual": contact.tolist(),
    }


def physical_validation_pass(
    result: QpSolveResult | None, thresholds: dict[str, float]
) -> bool:
    if result is None or not result.success or not result.validation.get("available"):
        return False
    validation = result.validation
    return bool(
        validation["dynamics_infinity_norm"]
        <= float(thresholds["dynamics_infinity_norm"])
        and validation["contact_infinity_norm"]
        <= float(thresholds["contact_infinity_norm"])
        and validation["hard_inequality_violation"]
        <= float(thresholds["hard_inequality_violation"])
        and validation["health_adapter_identity_error"]
        <= float(thresholds["health_adapter_identity"])
    )


class ScaledFixedSupportPhysicalQp:
    """Production STEP-02R OSQP solver in dimensionless coordinates."""

    def __init__(
        self,
        snapshot: PhysicalSnapshot,
        rho: Iterable[float],
        settings: Step02rSolverSettings,
        *,
        secondary_task_fix_normalized_tolerance: float,
    ) -> None:
        self.snapshot = snapshot
        self.rho = np.asarray(tuple(rho), dtype=float)
        self.settings = settings
        self.secondary_task_fix_normalized_tolerance = float(
            secondary_task_fix_normalized_tolerance
        )
        self.variable_scales = variable_scales(snapshot)
        self.original_physical = assemble_original_physical_constraints(
            snapshot, self.rho
        )
        self.accepted_osqp_settings: dict[str, Any] | None = None
        self.qdd_slice = slice(0, snapshot.nv)
        self.tau_slice = slice(snapshot.nv, snapshot.nv + snapshot.nu)
        self.lambda_slice = slice(snapshot.nv + snapshot.nu, snapshot.decision_dimension)

    def _objective_original(
        self,
        desired_task: np.ndarray | None,
        torque_regularization_weight: float,
    ) -> tuple[sp.csc_matrix, np.ndarray]:
        snapshot = self.snapshot
        n = snapshot.decision_dimension
        hessian = np.zeros((n, n), dtype=float)
        linear = np.zeros(n, dtype=float)
        if desired_task is not None:
            desired = np.asarray(desired_task, dtype=float)
            if desired.shape != (snapshot.task_dimension,):
                raise ValueError("desired task has the wrong dimension")
            transform = np.sqrt(snapshot.task_weights)[:, None] * (
                snapshot.task_matrix / snapshot.task_scales[:, None]
            )
            offset = np.sqrt(snapshot.task_weights) * (
                (snapshot.task_bias - desired) / snapshot.task_scales
            )
            hessian[self.qdd_slice, self.qdd_slice] = 2.0 * (
                transform.T @ transform
            )
            linear[self.qdd_slice] = 2.0 * (transform.T @ offset)
        if torque_regularization_weight < 0.0:
            raise ValueError("torque regularization weight must be non-negative")
        if torque_regularization_weight > 0.0:
            diagonal = 2.0 * torque_regularization_weight / np.square(
                snapshot.torque_scales
            )
            indices = np.arange(self.tau_slice.start, self.tau_slice.stop)
            hessian[indices, indices] += diagonal
        return sp.csc_matrix(hessian), linear

    def _scaled_problem(
        self,
        desired_task: np.ndarray | None,
        torque_regularization_weight: float,
        fixed_task_output: np.ndarray | None,
    ) -> tuple[sp.csc_matrix, np.ndarray, ScaledConstraintAssembly]:
        physical = self.original_physical
        if fixed_task_output is not None:
            physical = append_fixed_task_constraints(
                physical,
                self.snapshot,
                fixed_task_output,
                self.secondary_task_fix_normalized_tolerance,
            )
        constraints = scale_constraint_assembly(physical, self.variable_scales)
        original_p, original_q = self._objective_original(
            desired_task, torque_regularization_weight
        )
        diagonal = sp.diags(self.variable_scales, format="csc")
        scaled_p = diagonal @ original_p @ diagonal
        scaled_q = self.variable_scales * original_q
        return sp.triu(scaled_p, format="csc"), scaled_q, constraints

    @staticmethod
    def _settings_dict(settings: Any) -> dict[str, Any]:
        fields = (
            "eps_abs",
            "eps_rel",
            "max_iter",
            "polishing",
            "scaling",
            "adaptive_rho",
            "scaled_termination",
            "check_termination",
            "rho",
            "sigma",
            "alpha",
            "polish_refine_iter",
        )
        return {
            field: getattr(settings, field)
            for field in fields
            if hasattr(settings, field)
        }

    def _solve(
        self,
        *,
        method: str,
        desired_task: np.ndarray | None,
        torque_regularization_weight: float,
        fixed_task_output: np.ndarray | None = None,
        warm_start: QpSolveResult | None = None,
    ) -> QpSolveResult:
        P, q, constraints = self._scaled_problem(
            desired_task, torque_regularization_weight, fixed_task_output
        )
        solver = osqp.OSQP()
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                solver.setup(
                    P=P,
                    q=q,
                    A=constraints.matrix,
                    l=constraints.lower,
                    u=constraints.upper,
                    eps_abs=self.settings.eps_abs,
                    eps_rel=self.settings.eps_rel,
                    max_iter=self.settings.max_iter,
                    polishing=self.settings.polish,
                    scaling=self.settings.scaling,
                    adaptive_rho=self.settings.adaptive_rho,
                    scaled_termination=self.settings.scaled_termination,
                    check_termination=self.settings.check_termination,
                    verbose=self.settings.verbose,
                )
                self.accepted_osqp_settings = self._settings_dict(solver.settings)
                if warm_start is not None:
                    if not warm_start.success:
                        raise ValueError("warm-start result must be successful")
                    original = np.concatenate(
                        (warm_start.qdd, warm_start.tau, warm_start.contact_force)
                    )
                    solver.warm_start(x=original / self.variable_scales)
                raw = solver.solve(raise_error=False)
        except Exception as exc:
            return QpSolveResult(
                method=method,
                status=f"exception:{type(exc).__name__}:{exc}",
                status_val=-1,
                success=False,
                qdd=None,
                tau=None,
                contact_force=None,
                task_output=None,
                task_objective=None,
                torque_regularizer=None,
                normalized_task_residual=None,
                validation={"available": False},
                iterations=0,
                solve_time_s=0.0,
                setup_time_s=0.0,
                primal_residual=math.inf,
                dual_residual=math.inf,
                solver_objective=None,
            )
        info = raw.info
        success = (
            int(info.status_val) == 1
            and raw.x is not None
            and np.isfinite(raw.x).all()
        )
        if not success:
            return QpSolveResult(
                method=method,
                status=str(info.status),
                status_val=int(info.status_val),
                success=False,
                qdd=None,
                tau=None,
                contact_force=None,
                task_output=None,
                task_objective=None,
                torque_regularizer=None,
                normalized_task_residual=None,
                validation={"available": False},
                iterations=int(info.iter),
                solve_time_s=float(info.solve_time),
                setup_time_s=float(info.setup_time),
                primal_residual=float(info.prim_res),
                dual_residual=float(info.dual_res),
                solver_objective=float(info.obj_val),
            )
        original = np.asarray(raw.x, dtype=float) * self.variable_scales
        qdd = original[self.qdd_slice].copy()
        tau = original[self.tau_slice].copy()
        contact_force = original[self.lambda_slice].copy()
        task_output = self.snapshot.task_matrix @ qdd + self.snapshot.task_bias
        normalized_residual = (
            None
            if desired_task is None
            else (task_output - desired_task) / self.snapshot.task_scales
        )
        task_objective = (
            None
            if normalized_residual is None
            else float(
                np.sum(
                    self.snapshot.task_weights * np.square(normalized_residual)
                )
            )
        )
        torque_regularizer = float(
            np.sum(np.square(tau / self.snapshot.torque_scales))
        )
        validation = validate_original_witness(
            self.snapshot,
            self.rho,
            qdd,
            tau,
            contact_force,
            fixed_task_output=fixed_task_output,
        )
        return QpSolveResult(
            method=method,
            status=str(info.status),
            status_val=int(info.status_val),
            success=True,
            qdd=qdd,
            tau=tau,
            contact_force=contact_force,
            task_output=task_output,
            task_objective=task_objective,
            torque_regularizer=torque_regularizer,
            normalized_task_residual=normalized_residual,
            validation=validation,
            iterations=int(info.iter),
            solve_time_s=float(info.solve_time),
            setup_time_s=float(info.setup_time),
            primal_residual=float(info.prim_res),
            dual_residual=float(info.dual_res),
            solver_objective=float(info.obj_val),
        )

    def solve_p0_stage1(self, desired_task: Iterable[float]) -> QpSolveResult:
        return self._solve(
            method="P0_OSQP_SCALED_STAGE1",
            desired_task=np.asarray(tuple(desired_task), dtype=float),
            torque_regularization_weight=0.0,
        )

    def solve_p0_stage2(
        self,
        projected_task: Iterable[float],
        lambda_tau: float,
        *,
        warm_start: QpSolveResult | None = None,
    ) -> QpSolveResult:
        return self._solve(
            method="P0_OSQP_SCALED_STAGE2",
            desired_task=None,
            torque_regularization_weight=lambda_tau,
            fixed_task_output=np.asarray(tuple(projected_task), dtype=float),
            warm_start=warm_start,
        )

    def solve_internal_lex_stage_a(
        self, desired_task: Iterable[float]
    ) -> QpSolveResult:
        return self._solve(
            method="B1_LEX_OSQP_INTERNAL_STAGE_A",
            desired_task=np.asarray(tuple(desired_task), dtype=float),
            torque_regularization_weight=0.0,
        )

    def solve_internal_lex_stage_b(
        self,
        projected_task: Iterable[float],
        lambda_tau: float,
        *,
        warm_start: QpSolveResult | None = None,
    ) -> QpSolveResult:
        return self._solve(
            method="B1_LEX_OSQP_INTERNAL_STAGE_B",
            desired_task=None,
            torque_regularization_weight=lambda_tau,
            fixed_task_output=np.asarray(tuple(projected_task), dtype=float),
            warm_start=warm_start,
        )

    def solve_b1_soft(
        self, desired_task: Iterable[float], lambda_tau: float
    ) -> QpSolveResult:
        return self._solve(
            method="B1_SOFT_OSQP_SCALED",
            desired_task=np.asarray(tuple(desired_task), dtype=float),
            torque_regularization_weight=lambda_tau,
        )

    def audit_problem(
        self,
        *,
        desired_task: Iterable[float] | None = None,
        torque_regularization_weight: float = 0.0,
        fixed_task_output: Iterable[float] | None = None,
    ) -> dict[str, Any]:
        desired = (
            None
            if desired_task is None
            else np.asarray(tuple(desired_task), dtype=float)
        )
        target = (
            None
            if fixed_task_output is None
            else np.asarray(tuple(fixed_task_output), dtype=float)
        )
        P, q, constraints = self._scaled_problem(
            desired, torque_regularization_weight, target
        )
        return {
            "row_labels": list(constraints.original.row_labels),
            "variable_scales": self.variable_scales.tolist(),
            "unscaled_A": constraints.original.matrix.toarray().tolist(),
            "unscaled_l": constraints.original.lower.tolist(),
            "unscaled_u": constraints.original.upper.tolist(),
            "variable_scaled_A_before_row_scaling": (
                constraints.variable_scaled_matrix.toarray().tolist()
            ),
            "row_scaling_vector": constraints.row_scales.tolist(),
            "scaled_A": constraints.matrix.toarray().tolist(),
            "scaled_l": constraints.lower.tolist(),
            "scaled_u": constraints.upper.tolist(),
            "scaled_P": P.toarray().tolist(),
            "scaled_q": q.tolist(),
        }
