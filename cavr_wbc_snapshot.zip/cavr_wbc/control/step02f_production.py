"""Solver-free production assembly for the frozen STEP-02F affine coordinates."""

from __future__ import annotations

import numpy as np

from cavr_wbc.control.clarabel_p0 import (
    ClarabelP0Production, ClarabelP0Settings, assemble_p0_constraints_original,
)


def _row_scales(matrix, rhs):
    magnitude = np.maximum(np.max(np.abs(matrix), axis=1), np.abs(rhs))
    return np.divide(1.0, magnitude, out=np.ones_like(magnitude), where=magnitude > 0)


def build_problem(snapshot, rho, target, config) -> dict:
    """Substitute w=a+diag(R)z into original physical arrays, exactly once.

    Assembly retains the actual frozen float64 slab endpoints. No solver is
    instantiated, and no witness is projected or clipped.
    """
    task = np.asarray(snapshot.task_matrix, dtype=float)
    target = np.asarray(target, dtype=float)
    if snapshot.task_dimension != 8 or target.shape != (8,) or not np.isfinite(target).all():
        raise ValueError("REPRESENTED_QP_CONTRACT_MISMATCH: expected eight finite targets")
    selectors = np.argmax(task, axis=1)
    expected = np.zeros_like(task)
    expected[np.arange(8), selectors] = 1.0
    if len(set(selectors)) != 8 or not np.array_equal(task, expected) or np.any(snapshot.task_bias != 0):
        raise ValueError("REPRESENTED_QP_CONTRACT_MISMATCH: task must be eight distinct unit selectors with zero bias")
    tolerance = float(config["objectives"]["secondary_task_fix_normalized_tolerance"])
    if tolerance != 1e-8 or config["production_numerical_contract"]["internal_fixed_task_guard_fraction"] != 0:
        raise ValueError("REPRESENTED_QP_CONTRACT_MISMATCH: frozen exact band required")
    source = ClarabelP0Production(
        snapshot, rho, ClarabelP0Settings(**config["clarabel_production"]),
        secondary_task_fix_normalized_tolerance=tolerance,
        fixed_task_numerical_guard_fraction=0.0,
    )
    original = assemble_p0_constraints_original(
        snapshot, rho, fixed_task_output=target,
        fixed_task_normalized_tolerance=tolerance,
    )
    original_P, original_q = source._objective(None, float(config["objectives"]["lambda_tau"]))
    legacy = source.audit_problem(
        torque_regularization_weight=float(config["objectives"]["lambda_tau"]),
        fixed_task_output=target,
    )
    D = source.variable_scales.copy()
    a = np.zeros(snapshot.decision_dimension)
    a[selectors] = target - snapshot.task_bias
    R = D.copy()
    R[selectors] = tolerance * snapshot.task_scales
    if not np.isfinite(R).all() or np.any(R <= 0):
        raise ValueError("REPRESENTED_QP_CONTRACT_MISMATCH: nonpositive/nonfinite affine scale")
    P = R[:, None] * original_P * R[None, :]
    q = R * (original_P @ a + original_q)
    constant = float(0.5 * a @ original_P @ a + original_q @ a)
    E = original.equality * R[None, :]
    f = original.equality_rhs - original.equality @ a
    G = original.inequality * R[None, :]
    h = original.inequality_upper - original.inequality @ a
    es, gs = _row_scales(E, f), _row_scales(G, h)
    legacy_upper = np.asarray(legacy["scaled_P"])
    return {
        "implementation": "STEP02F_PRODUCTION_ORIGINAL_PHYSICAL_AFFINE",
        "original_P": original_P, "original_q": original_q,
        "original_E": original.equality, "original_f": original.equality_rhs,
        "original_G": original.inequality, "original_h": original.inequality_upper,
        "equality_labels": original.equality_labels,
        "inequality_labels": original.inequality_labels,
        "D": D, "a": a, "R": R, "task_selector_indices": selectors,
        "P": P, "q": q, "E": E, "f": f, "G": G, "h": h,
        "objective_constant": constant,
        "equality_row_scales": es, "inequality_row_scales": gs,
        "A": np.vstack((es[:, None] * E, gs[:, None] * G)),
        "b": np.concatenate((es * f, gs * h)),
        "legacy_A": np.asarray(legacy["scaled_conic_A"]),
        "legacy_b": np.asarray(legacy["scaled_conic_b"]),
        "legacy_P": legacy_upper + legacy_upper.T - np.diag(np.diag(legacy_upper)),
        "legacy_q": np.asarray(legacy["scaled_q"]),
        "legacy_equality_row_scales": np.asarray(legacy["equality_row_scaling"]),
        "legacy_inequality_row_scales": np.asarray(legacy["inequality_row_scaling"]),
    }


def inverse_transform(problem, z):
    """Return the unmodified original-unit candidate; never clip or project."""
    coordinate = np.asarray(z, dtype=float)
    if coordinate.shape != problem["R"].shape:
        raise ValueError("affine coordinate dimension mismatch")
    return problem["a"] + problem["R"] * coordinate
