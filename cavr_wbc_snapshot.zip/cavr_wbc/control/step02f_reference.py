"""Independent affine-coordinate reference assembly for STEP-02F.

This module constructs data only; it never instantiates or invokes a solver.
The physical matrices, objective and actually represented float64 task slab
come from the frozen independent reference, before any variable/row scaling.
"""

from __future__ import annotations

from typing import Any, Iterable

import numpy as np

from cavr_wbc.control.fixed_support_qp import PhysicalSnapshot
from cavr_wbc.control.independent_lex_reference import (
    ClarabelReferenceSettings,
    IndependentLexicographicReference,
    _independent_row_scaling,
    assemble_reference_constraints_original,
)


def build_problem(
    snapshot: PhysicalSnapshot,
    rho: Iterable[float],
    target: Iterable[float],
    config: dict[str, Any],
) -> dict[str, Any]:
    """Assemble frozen Stage B under ``w = a + diag(R) z``.

    ``E, f, G, h`` are the un-row-scaled affine-transformed constraints;
    ``A, b`` apply the frozen reference normalization to those new rows.
    All ``original_*`` values remain in physical coordinates, while the
    ``legacy_*`` arrays describe the old ``w = diag(D) x_hat`` representation.
    The returned ``P`` and ``legacy_P`` retain the full symmetric Hessian.
    """
    tolerance = float(config["objectives"]["secondary_task_fix_normalized_tolerance"])
    if tolerance != 1.0e-8:
        raise ValueError("STEP02F_REPRESENTATION_STOP: frozen task tolerance must be 1e-8")
    task_matrix = np.asarray(snapshot.task_matrix, dtype=np.float64)
    task_bias = np.asarray(snapshot.task_bias, dtype=np.float64)
    task_scales = np.asarray(snapshot.task_scales, dtype=np.float64)
    saved_target = np.asarray(tuple(target), dtype=np.float64)
    health = np.asarray(tuple(rho), dtype=np.float64)
    if (
        snapshot.task_dimension != 8
        or task_matrix.shape != (8, snapshot.nv)
        or task_bias.shape != (8,)
        or task_scales.shape != (8,)
        or saved_target.shape != (8,)
        or not np.isfinite(saved_target).all()
        or not np.isfinite(task_scales).all()
        or not np.all(task_scales > 0.0)
        or not np.array_equal(task_bias, np.zeros(8, dtype=np.float64))
    ):
        raise ValueError("STEP02F_REPRESENTATION_STOP: expected eight finite tasks with zero bias")

    selected: list[int] = []
    for row in task_matrix:
        indices = np.flatnonzero(row != 0.0)
        if len(indices) != 1 or row[indices[0]] != 1.0:
            raise ValueError("STEP02F_REPRESENTATION_STOP: task rows must be exact unit coordinate selectors")
        selected.append(int(indices[0]))
    if len(set(selected)) != 8:
        raise ValueError("STEP02F_REPRESENTATION_STOP: task selectors must select eight unique coordinates")

    reference = IndependentLexicographicReference(
        snapshot,
        health,
        ClarabelReferenceSettings(**config["clarabel_reference"]),
        secondary_task_fix_normalized_tolerance=tolerance,
    )
    frozen = assemble_reference_constraints_original(
        snapshot,
        health,
        fixed_task_output=saved_target,
        fixed_task_normalized_tolerance=tolerance,
    )
    original_p, original_q = reference._objective_original(
        None, float(config["objectives"]["lambda_tau"])
    )
    original_e = frozen.equality_matrix.copy()
    original_f = frozen.equality_rhs.copy()
    original_g = frozen.inequality_matrix.copy()
    original_h = frozen.inequality_upper.copy()
    original_p = np.asarray(original_p, dtype=np.float64).copy()
    original_q = np.asarray(original_q, dtype=np.float64).copy()
    d = reference.variable_scales.copy()
    a = np.zeros(snapshot.decision_dimension, dtype=np.float64)
    r = d.copy()
    for task_index, coordinate in enumerate(selected):
        a[coordinate] = saved_target[task_index] - task_bias[task_index]
        r[coordinate] = tolerance * task_scales[task_index]
    if not np.isfinite(r).all() or not np.all(r > 0.0):
        raise ValueError("STEP02F_REPRESENTATION_STOP: affine diagonal must be positive and finite")

    # Transform physical data once.  In particular, transform the frozen h;
    # replacing rounded task-boundary rows with +/-1 would change the QP.
    p = r[:, None] * original_p * r[None, :]
    q = r * (original_p @ a + original_q)
    objective_constant = float(0.5 * (a @ original_p @ a) + original_q @ a)
    e = original_e * r[None, :]
    f = original_f - original_e @ a
    g = original_g * r[None, :]
    h = original_h - original_g @ a
    equality_row_scales = _independent_row_scaling(e, f)
    inequality_row_scales = _independent_row_scaling(g, h)
    conic_a = np.vstack((equality_row_scales[:, None] * e,
                         inequality_row_scales[:, None] * g))
    conic_b = np.concatenate((equality_row_scales * f,
                             inequality_row_scales * h))

    legacy_e = original_e * d[None, :]
    legacy_g = original_g * d[None, :]
    legacy_equality_row_scales = _independent_row_scaling(legacy_e, original_f)
    legacy_inequality_row_scales = _independent_row_scaling(legacy_g, original_h)
    legacy_a = np.vstack((legacy_equality_row_scales[:, None] * legacy_e,
                          legacy_inequality_row_scales[:, None] * legacy_g))
    legacy_b = np.concatenate((legacy_equality_row_scales * original_f,
                              legacy_inequality_row_scales * original_h))

    return {
        "original_P": original_p,
        "original_q": original_q,
        "original_E": original_e,
        "original_f": original_f,
        "original_G": original_g,
        "original_h": original_h,
        "equality_labels": frozen.equality_labels,
        "inequality_labels": frozen.inequality_labels,
        "D": d,
        "a": a,
        "R": r,
        "P": p,
        "q": q,
        "E": e,
        "f": f,
        "G": g,
        "h": h,
        "objective_constant": objective_constant,
        "equality_row_scales": equality_row_scales,
        "inequality_row_scales": inequality_row_scales,
        "A": conic_a,
        "b": conic_b,
        "legacy_A": legacy_a,
        "legacy_b": legacy_b,
        "legacy_P": d[:, None] * original_p * d[None, :],
        "legacy_q": d * original_q,
        "legacy_equality_row_scales": legacy_equality_row_scales,
        "legacy_inequality_row_scales": legacy_inequality_row_scales,
    }


def inverse_transform(problem: dict[str, Any], z: Iterable[float]) -> np.ndarray:
    """Return the unmodified physical candidate ``a + R*z``."""
    affine_coordinate = np.asarray(tuple(z), dtype=np.float64)
    if affine_coordinate.shape != problem["R"].shape:
        raise ValueError("affine coordinate dimension does not match the represented QP")
    return problem["a"] + problem["R"] * affine_coordinate
