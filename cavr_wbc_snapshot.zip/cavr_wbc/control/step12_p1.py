"""One logged, independently identified constant-torque sampled evaluation.

This is a cold component evaluation, not a feedback backup controller or a
continuous safety certificate.  Importing this module performs no simulation.
The only propagation backend is the explicitly frozen Python ``mj_step`` path.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import asdict, is_dataclass
import hashlib
import json
import math
from pathlib import Path
from time import perf_counter_ns
from typing import Any
import xml.etree.ElementTree as ET

import mujoco
import numpy as np

from cavr_wbc.evaluation.e2b_physical import evaluate as independent_evaluate
from cavr_wbc.platforms.go2_mujoco import (
    FOOT_NAMES,
    extract_actuator_audit,
    extract_healthy_torque_limits,
)


BACKEND = "PYTHON_MUJOCO_MJ_STEP"
BACKUP_KIND = "CONSTANT_TORQUE_HOLD"
HORIZON_S = 1.0
CHECKPOINTS = 21
DEADLINE_S = 0.020
# These are the unchanged STEP04 interval_backup evaluator boundaries.
EVALUATOR_CONFIG = {
    "task": {
        "roll_limit_rad": 0.55, "pitch_limit_rad": 0.55,
        "com_height_min_m": 0.16, "com_height_max_m": 0.60,
        "velocity_limit_m_s": 2.0,
    },
    "terminal": {
        "velocity_max_m_s": 0.25, "angle_max_rad": 0.20,
        "friction_margin_min_n": 0.0,
    },
}
RecordCall = Callable[[str, Callable[[], Any], dict[str, Any]], Any]


class StructuralIdentityError(RuntimeError):
    """An input/receiver mismatch forbids further numerical dispatch."""

    def __init__(self, message: str, *, receiver_identity: Any = None,
                 identity_comparison: Any = None) -> None:
        super().__init__(message)
        self.receiver_identity = receiver_identity
        self.identity_comparison = identity_comparison


def _plain(value: Any) -> Any:
    if is_dataclass(value) and not isinstance(value, type):
        return _plain(asdict(value))
    if isinstance(value, Mapping):
        return {str(k): _plain(v) for k, v in sorted(value.items(), key=lambda p: str(p[0]))}
    if isinstance(value, np.ndarray):
        return _plain(value.tolist())
    if isinstance(value, (list, tuple)):
        return [_plain(v) for v in value]
    if isinstance(value, np.generic):
        return _plain(value.item())
    if isinstance(value, Path):
        return value.as_posix()
    if isinstance(value, float) and not math.isfinite(value):
        raise StructuralIdentityError("non-finite identity value")
    if value is None or isinstance(value, (str, bool, int, float)):
        return value
    raise StructuralIdentityError(f"unsupported identity value type: {type(value).__name__}")


def canonical_hash(value: Any) -> str:
    raw = json.dumps(_plain(value), sort_keys=True, separators=(",", ":"),
                     ensure_ascii=False, allow_nan=False).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _na(reason: str) -> dict[str, str]:
    return {"applicability": "NOT_APPLICABLE", "reason": reason}


def _array(value: Any, unit: str | list[str]) -> dict[str, Any]:
    arr = np.asarray(value)
    if arr.dtype.kind in "fc":
        if arr.dtype.kind == "c" or not np.isfinite(arr).all():
            raise StructuralIdentityError("complex/non-finite state or model field")
        arr = np.asarray(arr, dtype="<f8")
        dtype = "float64"
    elif arr.dtype.kind == "b":
        arr = np.asarray(arr, dtype=np.bool_)
        dtype = "bool"
    elif arr.dtype.kind in "iu":
        arr = np.asarray(arr, dtype="<i8")
        dtype = "int64"
    else:
        raise StructuralIdentityError(f"unsupported array dtype {arr.dtype}")
    return {"applicability": "APPLICABLE", "dtype": dtype,
            "byte_order": "little_endian", "shape": list(arr.shape),
            "unit": unit, "values": arr.tolist()}


def model_dependency_manifest(model_path: str | Path) -> dict[str, Any]:
    """Hash the entry MJCF, recursive includes and all referenced file assets.

    This resolves the pinned filesystem MJCF (no VFS, URL or memory assets).
    Compiler asset directories are relative to the entry model directory.
    Missing dependencies are structural errors, never silently omitted.
    """
    entry = Path(model_path).resolve(strict=True)
    files: dict[Path, str] = {}
    trees: list[tuple[Path, ET.Element]] = []
    visiting: set[Path] = set()

    def read_xml(path: Path) -> None:
        path = path.resolve(strict=True)
        if path in visiting:
            raise StructuralIdentityError(f"cyclic MJCF include: {path}")
        if path in files:
            return
        visiting.add(path)
        raw = path.read_bytes()
        files[path] = hashlib.sha256(raw).hexdigest()
        root = ET.fromstring(raw)
        trees.append((path, root))
        for include in root.iter("include"):
            read_xml(path.parent / include.attrib["file"])
        visiting.remove(path)

    read_xml(entry)
    compiler: dict[str, str] = {}
    for _, tree in trees:
        for item in tree.iter("compiler"):
            compiler.update(item.attrib)
    for _, tree in trees:
        for item in tree.iter():
            name = item.get("file")
            if not name or item.tag == "include":
                continue
            assetdir = compiler.get("assetdir", "")
            if item.tag in ("mesh", "skin"):
                assetdir = compiler.get("meshdir", assetdir)
            elif item.tag == "texture":
                assetdir = compiler.get("texturedir", assetdir)
            if compiler.get("strippath", "false").lower() == "true":
                name = Path(name).name
            path = (entry.parent / assetdir / name).resolve(strict=True)
            files[path] = hashlib.sha256(path.read_bytes()).hexdigest()
    return {
        "entry_path": entry.as_posix(),
        "resolver": "pinned_filesystem_MJCF_include_and_asset_files",
        "files": [{"path": p.as_posix(), "sha256": digest}
                  for p, digest in sorted(files.items(), key=lambda pair: str(pair[0]))],
    }


# Relevant compiled semantics are captured by value, independently on each side.
# XML/assets additionally pin meshes and other immutable compiled source data.
_MODEL_FIELDS = {
    "qpos0": "qpos_row_units", "qpos_spring": "qpos_row_units",
    "body_parentid": "index", "body_mocapid": "index",
    "body_pos": "m", "body_quat": "unit_quaternion_wxyz",
    "body_ipos": "m", "body_iquat": "unit_quaternion_wxyz",
    "body_mass": "kg", "body_inertia": "kg*m^2",
    "body_gravcomp": "dimensionless",
    "jnt_type": "MuJoCo_enum", "jnt_qposadr": "index",
    "jnt_dofadr": "index", "jnt_bodyid": "index", "jnt_limited": "bool",
    "jnt_pos": "m", "jnt_axis": "unit_vector", "jnt_range": "joint_coordinate",
    "jnt_margin": "joint_coordinate", "jnt_stiffness": "generalized_force/coordinate",
    "jnt_solref": "MuJoCo_constraint_solref", "jnt_solimp": "dimensionless",
    "jnt_actfrclimited": "bool", "jnt_actfrcrange": "N*m",
    "dof_bodyid": "index", "dof_jntid": "index", "dof_parentid": "index",
    "dof_armature": "generalized_inertia", "dof_damping": "generalized_force/velocity",
    "dof_frictionloss": "generalized_force", "dof_solref": "MuJoCo_constraint_solref",
    "dof_solimp": "dimensionless", "geom_type": "MuJoCo_enum",
    "geom_bodyid": "index", "geom_dataid": "index", "geom_contype": "bitmask",
    "geom_conaffinity": "bitmask", "geom_condim": "dimension",
    "geom_size": "m", "geom_pos": "m", "geom_quat": "unit_quaternion_wxyz",
    "geom_friction": "MuJoCo_friction_parameters", "geom_solmix": "dimensionless",
    "geom_solref": "MuJoCo_constraint_solref", "geom_solimp": "dimensionless",
    "geom_margin": "m", "geom_gap": "m", "geom_priority": "integer",
    "pair_geom1": "index", "pair_geom2": "index", "pair_dim": "dimension",
    "pair_friction": "MuJoCo_friction_parameters", "pair_solref": "MuJoCo_constraint_solref",
    "pair_solimp": "dimensionless", "pair_margin": "m", "pair_gap": "m",
    "exclude_signature": "MuJoCo_body_pair_signature",
    "eq_type": "MuJoCo_enum", "eq_obj1id": "index", "eq_obj2id": "index",
    "eq_active0": "bool", "eq_data": "MuJoCo_equality_parameters",
    "eq_solref": "MuJoCo_constraint_solref", "eq_solimp": "dimensionless",
    "actuator_trntype": "MuJoCo_enum", "actuator_trnid": "index",
    "actuator_dyntype": "MuJoCo_enum", "actuator_gaintype": "MuJoCo_enum",
    "actuator_biastype": "MuJoCo_enum", "actuator_actadr": "index",
    "actuator_actnum": "dimension", "actuator_group": "integer",
    "actuator_ctrllimited": "bool", "actuator_forcelimited": "bool",
    "actuator_actlimited": "bool", "actuator_ctrlrange": "N*m",
    "actuator_forcerange": "N*m", "actuator_actrange": "activation",
    "actuator_gear": "transmission_gain", "actuator_dynprm": "MuJoCo_dynamics_parameters",
    "actuator_gainprm": "MuJoCo_gain_parameters", "actuator_biasprm": "MuJoCo_bias_parameters",
    "actuator_plugin": "index", "plugin": "plugin_slot_index",
}


def _coordinate_units(model: Any) -> tuple[list[str], list[str]]:
    q_units = [""] * int(model.nq)
    v_units = [""] * int(model.nv)
    for j in range(int(model.njnt)):
        kind = int(model.jnt_type[j])
        qa, va = int(model.jnt_qposadr[j]), int(model.jnt_dofadr[j])
        if kind == int(mujoco.mjtJoint.mjJNT_FREE):
            qu, vu = ["m"] * 3 + ["unit_quaternion_wxyz"] * 4, ["m/s"] * 3 + ["rad/s"] * 3
        elif kind == int(mujoco.mjtJoint.mjJNT_BALL):
            qu, vu = ["unit_quaternion_wxyz"] * 4, ["rad/s"] * 3
        elif kind == int(mujoco.mjtJoint.mjJNT_SLIDE):
            qu, vu = ["m"], ["m/s"]
        else:
            qu, vu = ["rad"], ["rad/s"]
        q_units[qa:qa + len(qu)] = qu
        v_units[va:va + len(vu)] = vu
    if len(q_units) != model.nq or len(v_units) != model.nv or "" in q_units + v_units:
        raise StructuralIdentityError("incomplete compiled coordinate/unit mapping")
    return q_units, v_units


def _model_semantics(model: Any) -> dict[str, Any]:
    dimensions = {name: int(getattr(model, name)) for name in
                  ("nq", "nv", "nu", "na", "njnt", "nbody", "ngeom", "nmocap",
                   "neq", "nuserdata", "nplugin", "npluginstate", "ntendon", "nflex")
                  if hasattr(model, name)}
    fields = {name: (_array(getattr(model, name), unit) if hasattr(model, name)
                     else _na("field not exposed by this MuJoCo build"))
              for name, unit in _MODEL_FIELDS.items()}
    # All exposed numeric options include integrator, timestep and solver flags.
    options = {}
    for name in dir(model.opt):
        if name.startswith("_"):
            continue
        value = getattr(model.opt, name)
        if isinstance(value, (int, float, bool, np.number, np.ndarray)):
            options[name] = _plain(value)
    # Pybind enum representations differ between wheels; these fields cannot
    # disappear merely because an enum is not a Python numeric subclass.
    options["integrator"] = int(model.opt.integrator)
    options["timestep"] = float(model.opt.timestep)
    return {"dimensions": dimensions, "fields": fields, "options": options,
            "actuator_mapping": _plain(extract_actuator_audit(model))}


def _observed_contacts(data: Any) -> list[dict[str, Any]]:
    result = []
    units = {"dist": "m", "pos": "m", "frame": "world_basis",
             "friction": "MuJoCo_friction_parameters", "solref": "MuJoCo_constraint_solref",
             "solimp": "dimensionless", "geom1": "index", "geom2": "index",
             "dim": "dimension", "efc_address": "index", "exclude": "MuJoCo_enum"}
    for i in range(int(data.ncon)):
        contact = data.contact[i]
        result.append({name: _array(getattr(contact, name), unit)
                       for name, unit in units.items() if hasattr(contact, name)})
    return result


def _vector(name: str, value: Any, size: int) -> np.ndarray:
    arr = np.asarray(value, dtype=float)
    if arr.shape != (size,) or not np.isfinite(arr).all():
        raise StructuralIdentityError(f"{name}: expected finite shape {(size,)}, got {arr.shape}")
    return arr.copy()


def capture_identity(
    model: Any, data: Any, command: Any, health: Any, config: Any, backup_id: str,
    *, model_path: str | Path, controller_memory: Any = None, target: Any = None,
) -> dict[str, Any]:
    """Read actual state/semantics; no caller-provided equality flags are used."""
    q_units, v_units = _coordinate_units(model)
    command = _vector("command", command, int(model.nu))
    health = _vector("health", health, int(model.nu))
    if np.any(health < 0.0) or np.any(health > 1.0) or not backup_id:
        raise StructuralIdentityError("invalid health/backup identity")
    state = {
        "time": _array(float(data.time), "s"),
        "qpos": _array(_vector("qpos", data.qpos, model.nq), q_units),
        "qvel": _array(_vector("qvel", data.qvel, model.nv), v_units),
    }
    state_units = {
        "act": "actuator_activation",
        "qacc_warmstart": ["m/s^2" if u == "m/s" else "rad/s^2" for u in v_units],
        "ctrl": "N*m_in_compiled_actuator_order",
        "qfrc_applied": ["N" if u == "m/s" else "N*m" for u in v_units],
        "xfrc_applied": "world_[force_N_x_y_z,torque_N*m_x_y_z]",
        "mocap_pos": "m", "mocap_quat": "unit_quaternion_wxyz",
        "plugin_state": "plugin_defined", "eq_active": "bool", "userdata": "user_defined",
    }
    optional_counts = {"act": "na", "mocap_pos": "nmocap", "mocap_quat": "nmocap",
                       "plugin_state": "npluginstate", "eq_active": "neq", "userdata": "nuserdata"}
    for name, unit in state_units.items():
        count = optional_counts.get(name)
        if count and int(getattr(model, count, 0)) == 0:
            state[name] = _na(f"compiled {count}=0; state not enabled")
        elif not hasattr(data, name):
            raise StructuralIdentityError(f"active state {name} unavailable at receiver")
        else:
            state[name] = _array(getattr(data, name), unit)
    payload = {
        "schema": "STEP12_RECEIVER_IDENTITY_V1",
        "normalization": "float64/int64, little endian, exact shapes/values and explicit units",
        "model": _model_semantics(model),
        "model_dependencies": model_dependency_manifest(model_path),
        "state": state,
        "health": _array(health, "dimensionless_output_capacity_fraction"),
        "support_mode": {"kind": "fixed_four_foot_QP_support", "foot_order": list(FOOT_NAMES)},
        "observed_contacts": _observed_contacts(data),
        "observed_ncon": int(data.ncon),
        "controller_memory": (_na("constant torque hold has no feedback controller memory")
                              if controller_memory is None else _plain(controller_memory)),
        "command": _array(command, "N*m_in_compiled_actuator_order"),
        "config": _plain(config), "target": _plain(target),
        "evaluator_config": _plain(EVALUATOR_CONFIG),
        "backup": {"backup_id": str(backup_id), "backup_kind": BACKUP_KIND,
                   "backend": BACKEND, "horizon_s": HORIZON_S,
                   "checkpoints": CHECKPOINTS, "deadline_s": DEADLINE_S,
                   "definition": "identical fixed tau in ctrl at each actual model timestep"},
    }
    return {"payload": payload, "canonical_sha256": canonical_hash(payload)}


def compare_identities(sender: Mapping[str, Any], receiver: Mapping[str, Any]) -> dict[str, Any]:
    """Compare semantic values, shapes and units *and* validate both hashes."""
    mismatches: list[str] = []

    def compare(a: Any, b: Any, path: str) -> None:
        if type(a) is not type(b):
            mismatches.append(path + ":type")
        elif isinstance(a, dict):
            for key in sorted(set(a) | set(b)):
                if key not in a or key not in b:
                    mismatches.append(path + "." + key + ":missing")
                else:
                    compare(a[key], b[key], path + "." + key)
        elif isinstance(a, list):
            if len(a) != len(b):
                mismatches.append(path + ":length")
            else:
                for i, (x, y) in enumerate(zip(a, b)):
                    compare(x, y, f"{path}[{i}]")
        elif a != b:
            mismatches.append(path + ":value")

    compare(sender.get("payload"), receiver.get("payload"), "payload")
    sender_ok = sender.get("canonical_sha256") == canonical_hash(sender.get("payload"))
    receiver_ok = receiver.get("canonical_sha256") == canonical_hash(receiver.get("payload"))
    hashes_equal = sender.get("canonical_sha256") == receiver.get("canonical_sha256")
    return {"identity_equal": not mismatches and sender_ok and receiver_ok and hashes_equal,
            "semantic_equal": not mismatches, "mismatches": mismatches,
            "sender_hash_valid": sender_ok, "receiver_hash_valid": receiver_ok,
            "canonical_hash_equal": hashes_equal}


def checkpoint_steps(timestep: float) -> tuple[list[float], list[int]]:
    """Require exact model-step representation of the frozen sample schedule."""
    if not math.isfinite(timestep) or timestep <= 0:
        raise StructuralIdentityError("invalid actual model timestep")
    samples = np.linspace(0.0, HORIZON_S, CHECKPOINTS).tolist()
    steps = [round(t / timestep) for t in samples]
    if any(not math.isclose(t, n * timestep, rel_tol=0.0, abs_tol=1e-12)
           for t, n in zip(samples, steps)):
        raise StructuralIdentityError("frozen checkpoints are not representable at model timestep")
    return samples, steps


def summarize_points(points: list[dict[str, Any]], backup_id: str) -> dict[str, Any]:
    if len(points) != CHECKPOINTS or any(p["backup_id"] != backup_id for p in points):
        raise StructuralIdentityError("checkpoint count/terminal backup identity mismatch")
    interval_safe = all(not p["evaluation"]["safety_failure"] for p in points)
    terminal_flags = [bool(p["evaluation"]["terminal_set_membership"]) for p in points]
    margins = [float(p["evaluation"]["minimum_margin"]) for p in points]
    terminal = terminal_flags[-1]
    finite_margins = all(math.isfinite(v) for v in margins)
    minimum = min(margins) if finite_margins else None
    accepted = interval_safe and terminal and finite_margins and minimum > 0.05
    tail = 0
    for flag in reversed(terminal_flags):
        if not flag:
            break
        tail += 1
    reason = ("accepted" if accepted else "interval_physical_safety_failure" if not interval_safe
              else "terminal_set_membership_false" if not terminal
              else "minimum_margin_nonfinite" if not finite_margins
              else "minimum_margin_below_threshold")
    return {"sampled_physical_result": "ACCEPT" if accepted else "REJECT",
            "accepted_or_rejected": "accepted" if accepted else "rejected",
            "rejection_reason": reason, "minimum_margin": minimum,
            "interval_safe": interval_safe, "terminal_set_membership": terminal,
            "terminal_backup_id": points[-1]["backup_id"],
            "terminal_dwell_s": max(0, tail - 1) * HORIZON_S / (CHECKPOINTS - 1)}


def evaluate_constant_torque_hold(
    model: Any, data: Any, command: Any, health: Any, config: Any, backup_id: str,
    *, sender_identity: Mapping[str, Any], model_path: str | Path,
    target: Mapping[str, Any], record_call: RecordCall, controller_memory: Any = None,
) -> dict[str, Any]:
    """Log reception before cloning; independently identify and evaluate once.

    ``record_call(kind, thunk, metadata)`` must persist START before invoking
    the thunk and END/ERROR after it.  The parent ledger owns all dispatch
    budgets.  Exactly one ``rollout`` encloses all steps and evaluator calls;
    each nonpropagating ``mj_forward`` is separately logged as ``forward``.
    There is no solver, controller.compute, native backend, or backend fallback.
    """
    if not callable(record_call):
        raise StructuralIdentityError("a write-ahead record_call entry point is required")

    def receive_and_evaluate() -> dict[str, Any]:
        received_ns = perf_counter_ns()
        tau = _vector("command", command, int(model.nu))
        rho = _vector("health", health, int(model.nu))
        sim = mujoco.MjData(model)
        mujoco.mj_copyData(sim, model, data)
        receiver = capture_identity(model, sim, tau, rho, config, backup_id,
                                    model_path=model_path, target=target,
                                    controller_memory=controller_memory)
        comparison = compare_identities(sender_identity, receiver)
        if not comparison["identity_equal"]:
            raise StructuralIdentityError("receiver identity mismatch: " + json.dumps(comparison),
                                          receiver_identity=receiver,
                                          identity_comparison=comparison)
        limits = extract_healthy_torque_limits(model) * rho
        if np.any(np.abs(tau) > limits):
            raise StructuralIdentityError("received command exceeds unchanged health bounds")
        samples, sample_steps = checkpoint_steps(float(model.opt.timestep))
        timestep = float(model.opt.timestep)
        start_sim_time = float(sim.time)
        sim.ctrl[:] = tau
        applied = _vector("applied ctrl", sim.ctrl, int(model.nu))
        if not np.array_equal(applied, tau):
            raise StructuralIdentityError("actual applied ctrl differs from received command")
        applied_mapping = [{"actuator_index": row["actuator_index"],
                            "actuator_name": row["actuator_name"],
                            "joint_name": row["target_joint"], "dof_index": row["dof_index"],
                            "received_tau": float(tau[row["actuator_index"]]),
                            "applied_ctrl": float(applied[row["actuator_index"]]),
                            "unit": "N*m", "transform": "identity_no_clipping"}
                           for row in extract_actuator_audit(model)]
        points: list[dict[str, Any]] = []
        steps = 0
        for sample_index, (offset, target_step) in enumerate(zip(samples, sample_steps)):
            while steps < target_step:
                if float(model.opt.timestep) != timestep:
                    raise StructuralIdentityError("actual timestep changed during P1")
                sim.ctrl[:] = tau
                mujoco.mj_step(model, sim)
                steps += 1
            sim.ctrl[:] = tau
            record_call("forward", lambda: mujoco.mj_forward(model, sim),
                        {"backup_id": backup_id, "purpose": "p1_checkpoint_nonpropagating_forward",
                         "sample_index": sample_index, "propagation_step": steps})
            if not np.array_equal(np.asarray(sim.ctrl), tau):
                raise StructuralIdentityError("ctrl changed during P1 propagation/forward")
            measured_time = float(sim.time)
            expected_time = start_sim_time + steps * timestep
            if not math.isclose(measured_time, expected_time, rel_tol=0.0, abs_tol=1e-9):
                raise StructuralIdentityError("simulation clock did not advance by actual model steps")
            ev = independent_evaluate(model, sim, np.asarray(sim.ctrl).copy(), rho,
                                      EVALUATOR_CONFIG, target)
            points.append({"backup_id": backup_id, "sample_index": sample_index,
                           "requested_time_offset_s": offset,
                           "measured_time_offset_s": measured_time - start_sim_time,
                           "mujoco_time_s": measured_time, "propagation_step": steps,
                           "qpos": np.asarray(sim.qpos).tolist(),
                           "qvel": np.asarray(sim.qvel).tolist(),
                           "applied_ctrl": np.asarray(sim.ctrl).tolist(), "evaluation": ev})
        summary = summarize_points(points, backup_id)
        ended_ns = perf_counter_ns()
        elapsed_s = (ended_ns - received_ns) / 1e9
        return {"backup_id": backup_id, "backup_kind": BACKUP_KIND, "rollout_backend": BACKEND,
                "verified_scope": "full_horizon_sampled_constant_torque_hold_only",
                "receiver_identity": receiver, "identity_comparison": comparison,
                "applied_command_mapping": applied_mapping,
                "p1_received_perf_counter_ns": received_ns, "p1_ended_perf_counter_ns": ended_ns,
                "p1_wall_time_s": elapsed_s, "deadline_s": DEADLINE_S,
                "deadline_result": "MET" if elapsed_s <= DEADLINE_S else "DEADLINE_MISS",
                "sim_start_time_s": start_sim_time, "sim_end_time_s": float(sim.time),
                "actual_model_timestep_s": timestep, "interval_horizon_s": HORIZON_S,
                "interval_sample_count": len(points), "propagation_steps": steps,
                "propagation_clones": 1, "interval_points": points, **summary}

    return record_call("rollout", receive_and_evaluate,
                       {"backup_id": backup_id, "backend": BACKEND, "backup_kind": BACKUP_KIND,
                        "horizon_s": HORIZON_S, "checkpoints": CHECKPOINTS})
