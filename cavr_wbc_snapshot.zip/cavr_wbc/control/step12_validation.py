"""Pure, independent validation of the frozen STEP12 assembled QP.

No simulator, optimizer, model loading or propagation is performed here.
Equality budgets describe numerical consistency of this QP, not complete
MuJoCo applied-force balance or a physical safety certificate.
"""

from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import json
from pathlib import Path
from types import MappingProxyType
from typing import Any, Mapping, Sequence

import numpy as np
import scipy.sparse as sp


FEET = ("FL", "FR", "RL", "RR")
HINGES = tuple(f"{foot}_{part}_joint" for foot in FEET for part in ("hip", "thigh", "calf"))
ACTUATORS = tuple(f"{foot}_{part}" for foot in ("FR", "FL", "RR", "RL") for part in ("hip", "thigh", "calf"))
STATUS_NAMES = {
    1: "solved", 2: "solved_inaccurate", 3: "primal_infeasible",
    4: "primal_infeasible_inaccurate", 5: "dual_infeasible",
    6: "dual_infeasible_inaccurate", 7: "maximum_iterations_reached",
    8: "time_limit_reached", 9: "problem_non_convex",
    10: "interrupted_by_user", 11: "unsolved",
}


class ValidationConfigurationError(ValueError):
    """The frozen mapping or assembly is inconsistent: dispatch is forbidden."""


def osqp_status_name(value: Any) -> str:
    """Classify OSQP 1.x exit status without modifying its raw code/text."""
    return STATUS_NAMES.get(value, "UNKNOWN")


def immutable_copy(value: Any) -> Any:
    """Copy nested evidence, including sparse matrices, into immutable values."""
    if sp.issparse(value):
        value = value.toarray()
    if isinstance(value, np.ndarray):
        # A bytes owner prevents callers from re-enabling the writeable flag.
        arr = np.ascontiguousarray(value)
        return np.frombuffer(arr.tobytes(), dtype=arr.dtype).reshape(arr.shape)
    if isinstance(value, Mapping):
        return MappingProxyType({k: immutable_copy(v) for k, v in value.items()})
    if isinstance(value, (list, tuple)):
        return tuple(immutable_copy(v) for v in value)
    return value


@dataclass(frozen=True)
class AcceptanceConfig:
    document: Mapping[str, Any]
    source_path: str
    sha256: str

    @property
    def version(self) -> str:
        return str(self.document["version"])

    def manifest(self) -> dict[str, Any]:
        return {
            "path": self.source_path, "sha256": self.sha256,
            "schema": self.document["schema"], "version": self.version,
            "dynamics_abs_tolerances": [row["abs_tolerance"] for row in self.document["dynamics_rows"]],
            "dynamics_units": [row["unit"] for row in self.document["dynamics_rows"]],
            "contact_abs_tolerances": [row["abs_tolerance"] for row in self.document["contact_rows"]],
            "contact_units": [row["unit"] for row in self.document["contact_rows"]],
            "relative_tolerance": 0, "additional_comparison_slack": 0,
        }


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ValidationConfigurationError(message)


def validate_acceptance_document(doc: Mapping[str, Any]) -> None:
    """Check every acceptance-defining field before any numerical dispatch."""
    try:
        _require(doc["schema"] == "CAVR_STEP12_V1_EQUALITY_ACCEPTANCE_V1", "acceptance.schema mismatch")
        _require(doc["version"] == "1.0.0", "acceptance.version mismatch")
        model = doc["model"]
        for key, value in (("name", "go2"), ("nq", 19), ("nv", 18), ("nu", 12), ("n_contact_rows", 12), ("free_body", "base_link")):
            _require(model[key] == value, f"acceptance.model.{key} mismatch")
        for key, expected in (("hinge_dof_order", HINGES), ("contact_order", FEET), ("actuator_order_not_dof_order", ACTUATORS)):
            _require(tuple(model[key]) == expected, f"acceptance.model.{key} mismatch")
        evaluation = doc["evaluation"]
        expected_eval = {
            "dtype": "float64", "relative_tolerance": 0,
            "comparison_inclusive": True, "additional_comparison_slack": 0,
            "signed_residuals_preserved": True, "residual_rounding_or_clipping": False,
            "dynamics_expression": "M @ qdd + bias - B @ tau - Jc.T @ lambda",
            "contact_expression": "Jc @ qdd + jdotv",
            "row_predicate": "isfinite(r_i) and abs(r_i) <= abs_tolerance_i",
            "invalid_v1_output": "NO_VALID_COMMAND",
            "p1_after_invalid_v1": "NOT_RUN_NO_VALID_COMMAND",
        }
        for key, value in expected_eval.items():
            _require(evaluation[key] == value, f"acceptance.evaluation.{key} mismatch")
        dyn, contacts = doc["dynamics_rows"], doc["contact_rows"]
        _require(len(dyn) == 18 and len(contacts) == 12, "acceptance equality row counts mismatch")
        for i, row in enumerate(dyn):
            expected = {"row": i, "qp_row": i, "dof": i, "unit": "N" if i < 3 else "N*m", "abs_tolerance": 1e-4}
            if i < 6:
                expected.update(kind="free_translation" if i < 3 else "free_rotation", body="base_link", axis="xyz"[i % 3], frame="world" if i < 3 else "base_link_local")
            else:
                expected.update(kind="hinge", joint_name=HINGES[i - 6], axis="compiled_joint_axis", frame="joint_generalized_coordinate")
            for key, value in expected.items():
                _require(row[key] == value, f"dynamics_rows[{i}].{key} mismatch")
        for i, row in enumerate(contacts):
            expected = {"row": i, "qp_row": 18 + i, "foot": FEET[i // 3], "axis": "xyz"[i % 3], "point": "resolved_foot_geom_center", "frame": "world", "unit": "m/s^2", "abs_tolerance": 1e-5}
            for key, value in expected.items():
                _require(row[key] == value, f"contact_rows[{i}].{key} mismatch")
        for key, value in (("solver_eps_abs", 1e-7), ("solver_eps_rel", 1e-7), ("stage2_hqp_tolerance", 2e-4), ("deadline_s", 0.02), ("horizon_s", 1), ("checkpoints", 21), ("inequality_extra_slack_added", 0), ("stage1_soft_tasks_remain_soft", True)):
            _require(doc["unchanged"][key] == value, f"acceptance.unchanged.{key} mismatch")
    except (KeyError, TypeError) as exc:
        raise ValidationConfigurationError(f"missing/malformed acceptance definition: {exc}") from exc


def load_acceptance_config(path: str | Path) -> AcceptanceConfig:
    path = Path(path).resolve()
    raw = path.read_bytes()
    document = json.loads(raw.decode("utf-8-sig"))
    validate_acceptance_document(document)
    return AcceptanceConfig(immutable_copy(document), str(path), sha256(raw).hexdigest())


def compiled_model_metadata(model: Any, actuator_mapping: Sequence[Any], contact_order: Sequence[str], foot_geom_ids: Sequence[int]) -> dict[str, Any]:
    """Read a compiled model's mapping only; never call mj_forward or load it."""
    import mujoco

    name = lambda kind, i: mujoco.mj_id2name(model, kind, int(i))
    free_ids = [j for j in range(int(model.njnt)) if int(model.jnt_type[j]) == int(mujoco.mjtJoint.mjJNT_FREE)]
    hinges = sorted(
        [{"name": name(mujoco.mjtObj.mjOBJ_JOINT, j), "dof": int(model.jnt_dofadr[j])}
         for j in range(int(model.njnt)) if int(model.jnt_type[j]) == int(mujoco.mjtJoint.mjJNT_HINGE)],
        key=lambda row: row["dof"],
    )
    return {
        "nq": int(model.nq), "nv": int(model.nv), "nu": int(model.nu),
        "free_joints": [{"dof": int(model.jnt_dofadr[j]), "body": name(mujoco.mjtObj.mjOBJ_BODY, model.jnt_bodyid[j])} for j in free_ids],
        "hinges": hinges,
        "actuators": [{"name": e.actuator_name, "joint_name": e.joint_name, "dof": int(e.dof_index), "unit": e.unit} for e in actuator_mapping],
        "contact_order": list(contact_order), "n_contact_rows": 3 * len(foot_geom_ids),
        "contact_geoms": [name(mujoco.mjtObj.mjOBJ_GEOM, g) for g in foot_geom_ids],
        "contact_frame": "world", "contact_point": "resolved_foot_geom_center",
        "contact_unit": "m/s^2", "translation_frame": "world",
        "rotation_frame": "base_link_local", "translation_force_unit": "N",
        "rotation_force_unit": "N*m",
    }


def validate_l0_mapping(config: AcceptanceConfig, metadata: Mapping[str, Any]) -> dict[str, Any]:
    """Validate immutable configuration and actual compiled row/actuator order."""
    validate_acceptance_document(config.document)
    try:
        for key, expected in (("nq", 19), ("nv", 18), ("nu", 12), ("n_contact_rows", 12), ("contact_frame", "world"), ("contact_point", "resolved_foot_geom_center"), ("contact_unit", "m/s^2"), ("translation_frame", "world"), ("rotation_frame", "base_link_local"), ("translation_force_unit", "N"), ("rotation_force_unit", "N*m")):
            _require(metadata[key] == expected, f"L0.{key} mismatch")
        _require(list(metadata["free_joints"]) == [{"dof": 0, "body": "base_link"}], "L0.free_joint mapping mismatch")
        _require(list(metadata["hinges"]) == [{"name": name, "dof": 6 + i} for i, name in enumerate(HINGES)], "L0.hinge dof mapping mismatch")
        _require(tuple(metadata["contact_order"]) == FEET, "L0.contact_order mismatch")
        _require(len(metadata["contact_geoms"]) == 4 and all(isinstance(name, str) and foot.lower() in name.lower() for foot, name in zip(FEET, metadata["contact_geoms"])), "L0.contact geom mapping mismatch")
        actuators = metadata["actuators"]
        _require(len(actuators) == 12, "L0.actuator count mismatch")
        for i, row in enumerate(actuators):
            expected = {"name": ACTUATORS[i], "joint_name": ACTUATORS[i] + "_joint", "dof": 6 + HINGES.index(ACTUATORS[i] + "_joint"), "unit": "N*m"}
            _require(all(row[key] == value for key, value in expected.items()), f"L0.actuators[{i}] mapping/unit mismatch")
    except (KeyError, TypeError) as exc:
        raise ValidationConfigurationError(f"missing/malformed L0 mapping: {exc}") from exc
    return {"pass": True, "acceptance_version": config.version, "metadata": dict(metadata)}


def _array(meta: Mapping[str, Any], key: str, shape: tuple[int, ...], *, bounds: bool = False) -> np.ndarray:
    try:
        arr = np.asarray(meta[key], dtype=np.float64)
    except (KeyError, ValueError, TypeError) as exc:
        raise ValidationConfigurationError(f"missing/malformed assembly.{key}") from exc
    _require(arr.shape == shape, f"assembly.{key} expected {shape}, got {arr.shape}")
    _require(not np.isnan(arr).any() if bounds else bool(np.isfinite(arr).all()), f"assembly.{key} contains invalid coefficients")
    return arr


def validate_assembly(problem: Mapping[str, Any], meta: Mapping[str, Any], *, stage: str) -> None:
    """Pre-dispatch shape, finite coefficient and physical row layout gate."""
    _require(stage in ("stage1", "stage2"), "unknown validation stage")
    rows = 80 if stage == "stage1" else 98
    arrays = {k: v.toarray() if sp.issparse(v) else v for k, v in problem.items()}
    _array(arrays, "P", (42, 42)); _array(arrays, "q", (42,))
    A = _array(arrays, "A", (rows, 42))
    l = _array(arrays, "l", (rows,), bounds=True); u = _array(arrays, "u", (rows,), bounds=True)
    _require(not np.isposinf(l).any() and not np.isneginf(u).any(), "assembly bound infinity orientation invalid")
    M = _array(meta, "M", (18, 18)); bias = _array(meta, "bias", (18,))
    B = _array(meta, "B", (18, 12)); Jc = _array(meta, "Jc", (12, 18))
    jdotv = _array(meta, "jdotv", (12,))
    T = _array(meta, "T", (18, 18))
    _array(meta, "desired", (18,)); _array(meta, "weights", (18,))
    limits = _array(meta, "tau_lim", (12,)); _require(bool(np.all(limits >= 0)), "negative health torque limits")
    qlo = _array(meta, "qdd_lo", (18,), bounds=True); qhi = _array(meta, "qdd_hi", (18,), bounds=True)
    expected = np.zeros((80, 42), dtype=np.float64)
    expected[:18] = np.hstack((M, -B, -Jc.T)); expected[18:30, :18] = Jc
    expected[30:48, :18] = np.eye(18); expected[48:60, 18:30] = np.eye(12)
    try:
        mu, normal_upper = float(meta["friction_mu"]), float(meta["normal_force_upper"])
    except (KeyError, TypeError, ValueError) as exc:
        raise ValidationConfigurationError("missing friction_mu/normal_force_upper definition") from exc
    _require(np.isfinite(mu) and mu > 0 and np.isfinite(normal_upper) and normal_upper > 0, "invalid friction/normal bound definition")
    for foot in range(4):
        row, col = 60 + 5 * foot, 30 + 3 * foot
        expected[row:row + 4, col:col + 3] = [(sx, sy, -mu) for sx, sy in ((1, 1), (1, -1), (-1, 1), (-1, -1))]
        expected[row + 4, col + 2] = 1
    expected_l = np.concatenate((-bias, -jdotv, qlo, -limits, np.full(20, -np.inf)))
    expected_u = np.concatenate((-bias, -jdotv, qhi, limits, np.tile([0, 0, 0, 0, normal_upper], 4)))
    _require(np.array_equal(A[:80], expected), "assembly physical A differs from frozen metadata")
    _require(np.array_equal(l[:80], expected_l) and np.array_equal(u[:80], expected_u), "assembly physical bounds differ from frozen metadata")
    if stage == "stage2":
        center = _array(meta, "band_center", (18,)); band = _array(meta, "band_tolerance", (18,))
        _require(bool(np.all(band == 2e-4)), "stage2 band differs from frozen 2e-4")
        _require(np.array_equal(A[80:], np.hstack((T, np.zeros((18, 24))))) and np.array_equal(l[80:], center - band) and np.array_equal(u[80:], center + band), "assembly stage2 band mapping mismatch")


def assembly_snapshot(problem: Mapping[str, Any], meta: Mapping[str, Any], *, stage: str) -> Mapping[str, Any]:
    validate_assembly(problem, meta, stage=stage)
    return immutable_copy({**problem, "meta": meta, "stage": stage})


def _equality_rows(values: np.ndarray, definitions: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    rows = []
    for value, definition in zip(values, definitions):
        tolerance = float(definition["abs_tolerance"])
        rows.append({**definition, "signed_residual": float(value), "allowed_abs_residual": tolerance,
                     "normalized_ratio": float(abs(value) / tolerance),
                     "pass": bool(np.isfinite(value) and abs(value) <= tolerance)})
    return rows


def _bound_row(*, kind: str, row: int, actual: float, lower: float, upper: float, unit: str, **extra: Any) -> dict[str, Any]:
    lower_margin, upper_margin = actual - lower, upper - actual
    valid = bool(np.isfinite(actual) and not np.isnan(lower_margin) and not np.isnan(upper_margin) and lower_margin >= 0 and upper_margin >= 0)
    return {"kind": kind, "row": row, "actual": float(actual), "lower": float(lower), "upper": float(upper),
            "lower_signed_margin": float(lower_margin), "upper_signed_margin": float(upper_margin),
            "unit": unit, "additional_comparison_slack": 0.0, "pass": valid, **extra}


def validate_candidate(raw: Mapping[str, Any], snapshot: Mapping[str, Any], config: AcceptanceConfig) -> dict[str, Any]:
    """Validate raw primal using same-call immutable coefficients and SI budgets."""
    meta, stage = snapshot["meta"], snapshot["stage"]
    x = raw.get("x")
    result: dict[str, Any] = {
        "acceptance_version": config.version, "acceptance_sha256": config.sha256,
        "stage": stage, "status_val": raw.get("status_val"), "raw_status": raw.get("status"),
        "status_class": osqp_status_name(raw.get("status_val")),
        "status_pass": raw.get("status_val") == 1, "finite_pass": False,
        "equality_pass": False, "inequality_pass": False, "band_pass": stage == "stage1",
        "pass": False, "command_status": "NO_VALID_COMMAND",
        "dynamics_rows": [], "contact_rows": [], "inequality_rows": [], "band_rows": [],
        "solver_primal_residual": raw.get("primal_residual"), "solver_dual_residual": raw.get("dual_residual"),
    }
    if x is None:
        result["reason"] = "MISSING_PRIMAL"
        return result
    x = np.asarray(x, dtype=np.float64)
    if x.shape != (42,):
        result.update(reason="PRIMAL_DIMENSION_CONFIGURATION_ERROR", configuration_error=True, actual_primal_shape=list(x.shape))
        return result
    qdd, tau, lam = x[:18], x[18:30], x[30:]
    result["finite_pass"] = bool(np.isfinite(x).all())
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        dyn = meta["M"] @ qdd + meta["bias"] - meta["B"] @ tau - meta["Jc"].T @ lam
        con = meta["Jc"] @ qdd + meta["jdotv"]
        result["dynamics_rows"] = _equality_rows(dyn, config.document["dynamics_rows"])
        result["contact_rows"] = _equality_rows(con, config.document["contact_rows"])
        result["dynamics_max_normalized_ratio"] = float(np.max(np.abs(dyn) / np.array([r["abs_tolerance"] for r in config.document["dynamics_rows"]])))
        result["contact_max_normalized_ratio"] = float(np.max(np.abs(con) / np.array([r["abs_tolerance"] for r in config.document["contact_rows"]])))
        rows = result["inequality_rows"]
        for i, value in enumerate(qdd):
            rows.append(_bound_row(kind="joint_acceleration", row=30 + i, actual=value, lower=meta["qdd_lo"][i], upper=meta["qdd_hi"][i], unit="m/s^2" if i < 3 else "rad/s^2", dof=i))
        for i, value in enumerate(tau):
            rows.append(_bound_row(kind="health_torque", row=48 + i, actual=value, lower=-meta["tau_lim"][i], upper=meta["tau_lim"][i], unit="N*m", actuator=ACTUATORS[i]))
        for foot in range(4):
            fx, fy, fz = lam[3 * foot:3 * foot + 3]
            for k, (sx, sy) in enumerate(((1, 1), (1, -1), (-1, 1), (-1, -1))):
                value = sx * fx + sy * fy - meta["friction_mu"] * fz
                rows.append(_bound_row(kind="friction_plane", row=60 + foot * 5 + k, actual=value, lower=-np.inf, upper=0, unit="N", foot=FEET[foot], sx=sx, sy=sy))
            # Nonnegative normal force is implied by the four frozen planes;
            # report it explicitly without adding any row to the QP.
            rows.append(_bound_row(kind="normal_force", row=64 + foot * 5, actual=fz, lower=0, upper=meta["normal_force_upper"], unit="N", foot=FEET[foot], lower_bound_source="implied_by_four_friction_planes"))
        if stage == "stage2":
            actual = meta["T"] @ qdd
            for i, value in enumerate(actual):
                result["band_rows"].append(_bound_row(kind="stage2_task_band", row=80 + i, actual=value, lower=snapshot["l"][80 + i], upper=snapshot["u"][80 + i], unit="m/s^2" if i < 3 else "rad/s^2", signed_center_residual=float(value - meta["band_center"][i])))
            result["band_pass"] = all(row["pass"] for row in result["band_rows"])
    result["equality_pass"] = all(row["pass"] for row in result["dynamics_rows"] + result["contact_rows"])
    result["inequality_pass"] = all(row["pass"] for row in result["inequality_rows"])
    result["pass"] = bool(result["status_pass"] and result["finite_pass"] and result["equality_pass"] and result["inequality_pass"] and result["band_pass"])
    result["command_status"] = "VALID_COMMAND" if result["pass"] else "NO_VALID_COMMAND"
    result["reason"] = "VALIDATED" if result["pass"] else "CANDIDATE_REJECTED"
    return result


def stage1_witness(stage1: Mapping[str, Any], stage2: Mapping[str, Any], config: AcceptanceConfig) -> dict[str, Any]:
    """Substitute z1 in actual stage2 arrays; this is not an exact certificate."""
    raw = stage1["raw_result"]
    x = np.asarray(raw["x"], dtype=np.float64)
    with np.errstate(over="ignore", invalid="ignore"):
        actual = stage2["A"] @ x
        lower, upper = actual - stage2["l"], stage2["u"] - actual
    return {
        "shared_A_exact_equal": bool(np.array_equal(stage1["A"], stage2["A"][:80])),
        "shared_l_exact_equal": bool(np.array_equal(stage1["l"], stage2["l"][:80])),
        "shared_u_exact_equal": bool(np.array_equal(stage1["u"], stage2["u"][:80])),
        "actual_A2_z1": actual, "lower_signed_margin": lower, "upper_signed_margin": upper,
        "exact_original_qp_feasible": bool(np.isfinite(actual).all() and np.all(lower >= 0) and np.all(upper >= 0)),
        "frozen_acceptance": validate_candidate(raw, stage2, config),
        "interpretation": "Numerical substitution only; tolerance acceptance is not an exact feasibility certificate.",
    }
