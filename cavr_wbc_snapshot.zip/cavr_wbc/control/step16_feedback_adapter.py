"""Physical STEP16 adapter for the feedback backup policy.

The STEP15 :class:`~cavr_wbc.control.feedback_backup.FeedbackBackupPolicy`
is deliberately controller agnostic: it emits a scalar ``base_x_acceleration``
action from a current-state snapshot.  This module is the small, auditable
adapter used by STEP16 to turn that action into a real MuJoCo command.  The
action is inserted into the public WBC target, the existing constrained P0 QP
is solved, and the returned torque is written by the caller to ``data.ctrl``.

No evaluator output, future state, or future label is passed to the policy.
The adapter only observes the current MuJoCo state/contact model and the
current health/task values supplied by the caller.  It intentionally leaves
``data.ctrl`` untouched; writing the command and advancing the simulator are
responsibilities of the episode runner so that applied torque can be measured
after ``mj_forward``.
"""

from __future__ import annotations

from dataclasses import asdict
from time import perf_counter
from typing import Any, Iterable, Mapping

import mujoco
import numpy as np

from cavr_wbc.control.feedback_backup import FeedbackBackupPolicy, FrozenBackupConfig
from cavr_wbc.platforms.go2_mujoco import FOOT_NAMES, contact_diagnostics


FR_THIGH_INDEX = 1
"""Compiled Go2 actuator index of the damaged FR_thigh channel."""


def _json_value(value: Any) -> Any:
    """Convert common MuJoCo/numpy values into deterministic JSON values."""

    if isinstance(value, np.ndarray):
        return value.astype(float).tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, Mapping):
        return {str(k): _json_value(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [_json_value(v) for v in value]
    return value


class P1FeedbackAdapter:
    """Map current-state feedback action to a physical constrained WBC command.

    Parameters
    ----------
    controller:
        Existing ``DynamicWBC`` instance.  The adapter invokes its public
        ``compute(data, "P0", health, target)`` method; no private solver
        state is accessed.
    model:
        Compiled MuJoCo model corresponding to ``data``.
    config:
        Frozen STEP15 feedback policy configuration.  It is copied/frozen by
        ``FeedbackBackupPolicy.reset`` and exposed through ``config_hash``.
    fr_thigh_index:
        Damaged channel index in the compiled actuator ordering (fixed to 1 by
        the Go2 model audit).
    """

    protocol = "STEP16_P1_FEEDBACK_PHYSICAL_ADAPTER_V1"
    action_channel = "base_x_acceleration"
    action_unit = "m/s^2"

    def __init__(
        self,
        controller: Any,
        model: mujoco.MjModel,
        config: FrozenBackupConfig | Mapping[str, Any] | None = None,
        *,
        fr_thigh_index: int = FR_THIGH_INDEX,
    ) -> None:
        self.controller = controller
        self.model = model
        self.fr_thigh_index = int(fr_thigh_index)
        self.policy = FeedbackBackupPolicy()
        self.config = config if config is not None else FrozenBackupConfig()
        self._reset_meta: dict[str, Any] | None = None
        self.ledger: list[dict[str, Any]] = []
        self.tick = 0

    @property
    def backup_id(self) -> str:
        return self.policy.backup_id

    @property
    def config_hash(self) -> str:
        return self.policy.config_hash

    @property
    def reset_meta(self) -> Mapping[str, Any]:
        if self._reset_meta is None:
            raise RuntimeError("P1FeedbackAdapter.reset must be called first")
        return self._reset_meta

    @property
    def spec(self) -> dict[str, Any]:
        """Return a serializable mapping specification for the manifest."""

        config = self.policy.config.as_dict() if self._reset_meta is not None else (
            self.config.as_dict() if isinstance(self.config, FrozenBackupConfig) else dict(self.config)
        )
        return {
            "schema": "step16_p1_feedback_adapter_v1",
            "protocol": self.protocol,
            "policy_module": "cavr_wbc.control.feedback_backup.FeedbackBackupPolicy",
            "wbc_method": "P0",
            "action_channel": self.action_channel,
            "action_unit": self.action_unit,
            "mapping": "policy.backup_action.value -> target.desired_base_accel[0] -> DynamicWBC.compute(P0) -> tau[N*m]",
            "writes_data_ctrl": False,
            "reads": [
                "data.qpos[0]",
                "data.qvel[0]",
                "current four-foot contact support",
                "compiled model foot friction",
                "current health vector/scalar",
                "current task reference",
                "frozen policy configuration",
            ],
            "forbidden_policy_reads": [
                "future_state",
                "future_label",
                "evaluator_output",
                "terminal_label",
            ],
            "fr_thigh_index": self.fr_thigh_index,
            "foot_names": list(FOOT_NAMES),
            "config": _json_value(config),
            "config_hash": self.config_hash if self._reset_meta is not None else getattr(self.config, "config_hash", None),
        }

    def reset(self, config: FrozenBackupConfig | Mapping[str, Any] | None = None) -> dict[str, Any]:
        """Reset policy identity and clear the per-episode solver ledger."""

        if config is not None:
            self.config = config
        self._reset_meta = self.policy.reset(self.config)
        self.ledger = []
        self.tick = 0
        return dict(self._reset_meta)

    def _health_scalar_and_vector(self, health: float | Iterable[float]) -> tuple[float, np.ndarray]:
        """Normalize scalar/vector health while preserving the FR_thigh index."""

        nu = int(getattr(self.controller, "nu", getattr(self.model, "nu", 0)))
        if np.isscalar(health):
            scalar = float(health)
            vector = np.ones(max(nu, self.fr_thigh_index + 1), dtype=float)
            vector[self.fr_thigh_index] = scalar
            return scalar, vector
        values = np.asarray(list(health), dtype=float).reshape(-1)
        if values.size == 0:
            raise ValueError("health vector must not be empty")
        if self.fr_thigh_index >= values.size:
            raise ValueError("health vector does not contain FR_thigh index")
        scalar = float(values[self.fr_thigh_index])
        if nu and values.size != nu:
            raise ValueError(f"health vector length {values.size} does not match model.nu {nu}")
        return scalar, values.copy()

    def _friction_coeff(self) -> float:
        """Read the compiled foot friction coefficient, never a scenario label."""

        values: list[float] = []
        for name in FOOT_NAMES:
            geom_id = int(mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_GEOM, name))
            if geom_id >= 0:
                values.append(float(self.model.geom_friction[geom_id, 0]))
        if not values:
            return 0.0
        return float(min(values))

    def _current_state(
        self,
        data: mujoco.MjData,
        health_scalar: float,
        task_reference: Mapping[str, Any],
    ) -> dict[str, Any]:
        """Build the policy's current-state read set from simulator state."""

        qpos = np.asarray(data.qpos, dtype=float)
        qvel = np.asarray(data.qvel, dtype=float)
        p = float(qpos[0]) if qpos.size else 0.0
        v = float(qvel[0]) if qvel.size else 0.0
        # p_max is a declared task boundary.  If omitted, the adapter uses a
        # frozen one-metre look-ahead, never a post-rollout/evaluator value.
        p_max = float(task_reference.get("p_max", p + 1.0))
        contacts = contact_diagnostics(self.model, data)
        contact = {name: bool(contacts.get(name, {}).get("present", False)) for name in FOOT_NAMES}
        return {
            "p": p,
            "v": v,
            "p_max": p_max,
            "contact": contact,
            "friction_coeff": self._friction_coeff(),
            "actuator_limit": float(self.policy.config.actuator_limit_normalized),
            "health": float(health_scalar),
        }

    def compute(
        self,
        data: mujoco.MjData,
        health: float | Iterable[float],
        task_reference: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Compute one policy action and one physical WBC torque command.

        The returned ``tau`` remains a numpy array in actuator order for the
        runner.  ``ledger_row`` is JSON-safe and captures all call identities,
        solver status and timing needed by the formal panel audit.
        """

        if self._reset_meta is None:
            self.reset()
        if not isinstance(data, mujoco.MjData):
            raise TypeError("data must be a mujoco.MjData instance")
        task = dict(task_reference or {})
        health_scalar, health_vector = self._health_scalar_and_vector(health)
        start = perf_counter()
        state = self._current_state(data, health_scalar, task)
        policy_result = self.policy.compute(
            state,
            health_scalar,
            {
                "target_velocity_m_s": float(task.get("target_velocity_m_s", task.get("com_velocity", 0.0))),
                "target_position": float(task.get("target_position", state["p_max"] - self.policy.config.target_margin_m)),
            },
        )
        action_value = float(policy_result["backup_action"]["value"])
        # Public, traceable unit mapping.  Only the x base acceleration is
        # replaced; all other target dimensions retain frozen caller values.
        target = dict(task)
        base = np.asarray(target.get("desired_base_accel", target.get("base_accel", np.zeros(6))), dtype=float).reshape(-1)
        if base.size != 6:
            raise ValueError("desired_base_accel must have length 6")
        base = base.copy()
        base[0] = action_value
        target["desired_base_accel"] = base
        nu = int(getattr(self.controller, "nu", getattr(self.model, "nu", 0)))
        target.setdefault("desired_joint_accel", np.zeros(nu, dtype=float))
        target.setdefault("task_weights", np.ones(6 + nu, dtype=float))
        wbc_result = self.controller.compute(data, "P0", health_vector, target)
        elapsed_s = perf_counter() - start
        tau = np.asarray(wbc_result.get("tau", np.zeros(nu)), dtype=float).reshape(-1)
        solver_status = wbc_result.get("status", wbc_result.get("command_status", "unknown"))
        ledger_row = {
            "event": "P1_FEEDBACK_TICK",
            "tick": int(self.tick),
            "backup_id": self.backup_id,
            "policy_config_hash": self.config_hash,
            "state": _json_value(state),
            "state_hash": policy_result.get("diagnostics", {}).get("state_hash"),
            "action": _json_value(policy_result.get("backup_action", {})),
            "action_channel": self.action_channel,
            "action_unit": self.action_unit,
            "target_desired_base_accel": _json_value(base),
            "tau_cmd": _json_value(tau),
            "solver_status": str(solver_status),
            "solver_calls": int(wbc_result.get("solver_calls", 0)),
            "elapsed_s": float(elapsed_s),
            "deadline_s": 0.020,
            "deadline_met": bool(elapsed_s <= 0.020),
            "wbc_success": bool(wbc_result.get("success", wbc_result.get("command_status") == "VALID_COMMAND")),
        }
        self.ledger.append(ledger_row)
        self.tick += 1
        return {
            "backup_id": self.backup_id,
            "policy_config_hash": self.config_hash,
            "policy": policy_result,
            "action": policy_result.get("backup_action"),
            "action_value": action_value,
            "state": state,
            "target": target,
            "tau": tau,
            "wbc": wbc_result,
            "ledger_row": ledger_row,
            "elapsed_s": float(elapsed_s),
            "deadline_met": bool(elapsed_s <= 0.020),
        }


__all__ = ["FR_THIGH_INDEX", "P1FeedbackAdapter"]
