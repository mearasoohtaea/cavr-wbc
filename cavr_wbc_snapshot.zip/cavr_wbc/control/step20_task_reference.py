"""STEP20-only world-base-x references; no changes to historical methods."""
from __future__ import annotations

from dataclasses import asdict
from time import perf_counter
import numpy as np

from cavr_wbc.control.e2b_dynamic import DynamicWBC
from cavr_wbc.control.feedback_backup import FrozenBackupConfig
from cavr_wbc.control.step16_feedback_adapter import P1FeedbackAdapter

METHODS = ("B1", "B2", "B3", "P0", "P1_PD_BACKUP_V2")
POLICY_VERSION = "STEP20_EXPLICIT_LOCAL_REFERENCE_ACCELERATION_FEEDFORWARD_V2"
KP = 1.25
KD = 0.75


def reference(p_init: float, d: float, t: float) -> dict:
    s = float(np.clip(t - 0.2, 0.0, 1.0))
    return {"time_s": float(t), "p_ref_m": p_init + d * (10*s**3 - 15*s**4 + 6*s**5),
            "v_ref_m_s": d * (30*s**2 - 60*s**3 + 30*s**4),
            "a_ref_m_s2": d * (60*s - 180*s**2 + 120*s**3)}


def nominal_acceleration(ref: dict, p: float, v: float) -> float:
    return float(ref["a_ref_m_s2"] + KP * (ref["p_ref_m"] - p) + KD * (ref["v_ref_m_s"] - v))


def limit_backup(raw: float, rho: float, contact_ok: bool, friction: float,
                 config: FrozenBackupConfig | None = None) -> dict:
    cfg = config or FrozenBackupConfig()
    # Both candidate bounds are acceleration, never torque. The normalized
    # cap is relative to the frozen one-m/s^2 acceleration authority scale.
    normalized_cap_mps2 = cfg.actuator_limit_normalized * cfg.max_acceleration_mps2
    authority = min(cfg.max_acceleration_mps2 * rho, normalized_cap_mps2)
    valid = rho > 0 and contact_ok and friction >= cfg.friction_min and normalized_cap_mps2 > 0
    value = float(np.clip(raw, -authority, authority)) if valid else 0.0
    return {"a_raw_mps2": float(raw), "a_backup_mps2": value, "rho": float(rho),
            "rho_mapping": "health_vector[FR_thigh=1]", "a_lim_mps2": float(authority),
            "normalized_actuator_cap": cfg.actuator_limit_normalized,
            "normalized_cap_mps2": normalized_cap_mps2, "acceleration_unit_scale_mps2": cfg.max_acceleration_mps2,
            "contact_ok": bool(contact_ok), "friction_coeff": float(friction),
            "mode": ("BRAKE" if value < 0 else "GOVERN") if valid else ("FALLBACK_NO_AUTHORITY" if rho <= 0 else "STOP"),
            "policy_version": POLICY_VERSION, "predictive_recoverability_filter": False}


class TaskResponseWBC(DynamicWBC):
    """Opt-in observer of the exact original QP assemblies; no new solves."""
    def compute(self, *args, **kwargs):
        self.task_trace = []
        return super().compute(*args, **kwargs)

    def _problem(self, *args, **kwargs):
        result = super()._problem(*args, **kwargs)
        _, q, _, _, _, meta = result
        self.task_trace.append({"stage": "stage2" if kwargs.get("stage2") else "stage1",
            "desired": meta["desired"].tolist(), "weights": meta["weights"].tolist(),
            "linear_objective_q": q.copy().tolist(),
            "contact_J_base_x": meta["Jc"][:, 0].tolist(),
            "contact_jdotv": meta["jdotv"].tolist()})
        return result


class TaskManager:
    def __init__(self, controller: TaskResponseWBC, model, method: str, p_init: float, d: float, backup_id: str):
        if method not in METHODS:
            raise ValueError(method)
        self.controller, self.model, self.method = controller, model, method
        self.p_init, self.d, self.backup_id = float(p_init), float(d), backup_id
        self.adapter = P1FeedbackAdapter(controller, model) if method == METHODS[-1] else None
        if self.adapter is not None:
            self.adapter.reset()

    def compute(self, data, health, control_tick: int) -> dict:
        begin = perf_counter()
        ref = reference(self.p_init, self.d, control_tick * 0.02)
        p, v = float(data.qpos[0]), float(data.qvel[0])
        raw = nominal_acceleration(ref, p, v)
        policy = None
        command = raw
        if self.adapter is not None:
            rho, h = self.adapter._health_scalar_and_vector(health)
            state = self.adapter._current_state(data, rho, {"p_max": 1.0})
            policy = limit_backup(raw, rho, all(state["contact"].values()), state["friction_coeff"], self.adapter.policy.config)
            policy.update(backup_id=self.backup_id, current_state=state, external_reference=ref)
            command = policy["a_backup_mps2"]
        target = {"desired_base_accel": [command, 0., 0., 0., 0., 0.],
                  "desired_joint_accel": [0.] * self.model.nu,
                  "task_weights": [1.] * (6 + self.model.nu),
                  "com_velocity": ref["v_ref_m_s"], "com_height": 0.27,
                  "p_max": 1.0, "target_position": ref["p_ref_m"]}
        wb = self.controller.compute(data, "P0" if self.adapter else self.method, health, target)
        valid = bool(wb.get("success")) and wb.get("tau") is not None and np.isfinite(wb["tau"]).all()
        tau_cmd = np.asarray(wb["tau"], dtype=float).copy() if valid else np.zeros(self.model.nu)
        elapsed_ms = (perf_counter() - begin) * 1000
        return {"wbc": wb, "tau_cmd": tau_cmd.tolist(), "valid_command": valid,
                "external_reference": ref, "measured_p_m": p, "measured_v_m_s": v,
                "a_nominal_mps2": raw, "a_command_mps2": command,
                "target_before_method_transform": target, "qp_tasks": self.controller.task_trace,
                "policy": policy, "policy_version": POLICY_VERSION if self.adapter else "FROZEN_BASELINE_WITH_STEP20_TASK_MANAGER",
                "latency_ms": elapsed_ms}


def specification() -> dict:
    return {"kp_s_inv2": KP, "kd_s_inv": KD, "reference": "quintic 10s^3-15s^4+6s^5; T=1s; fixed p_init",
            "motion_start_s": .2, "motion_end_s": 1.2, "policy_version": POLICY_VERSION,
            "backup_config": asdict(FrozenBackupConfig()),
            "normalized_cap_conversion": "actuator_limit_normalized * max_acceleration_mps2",
            "rho_mapping": "health_vector[1] = FR_thigh capacity", "PD_layers": 1,
            "predictive_recoverability_filter": False}
