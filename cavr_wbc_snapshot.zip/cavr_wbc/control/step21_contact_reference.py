"""Opt-in STEP21 contact-compatible soft references and explicit losses.

The physical QP, regularization, solver and command decoding remain inherited.
Only the joint soft target and, for KF, the versioned dynamics bias change.
"""
from __future__ import annotations

from typing import Any, Iterable, Mapping

import mujoco
import numpy as np

from cavr_wbc.control.e2b_dynamic import DynamicWBC


CONFIGURATIONS = ("L_LEGACY", "K_CONTACT_REFERENCE", "KF_CONTACT_AND_LOSS")
RELATIVE_RANK_CUTOFF = 1e-10
VELOCITY_DEADBAND_RAD_S = 1e-4
ACCELERATION_DEADBAND_RAD_S2 = 1e-6
LEGACY_MODEL_VERSION = "STEP20_QFRC_BIAS_ONLY"
LOSS_MODEL_VERSION = "STEP21_PASSIVE_AND_INTENDED_DRY_FRICTION_V1"


def contact_reference(Jc: Any, jdotv: Any, a_base_ref: Any,
                      mapped_joint_dofs: Iterable[int]) -> tuple[np.ndarray, dict[str, Any]]:
    """Return the fixed-cutoff least-norm reference in actuator order.

    ``Jc`` and ``jdotv`` are the same linearization used in the physical QP.
    Rank deficiency is evidence, not a reason to clip or change the cutoff.
    """
    J = np.asarray(Jc, dtype=float)
    jv = np.asarray(jdotv, dtype=float).reshape(-1)
    base = np.asarray(a_base_ref, dtype=float).reshape(-1)
    dofs = np.asarray(tuple(mapped_joint_dofs), dtype=int)
    if J.ndim != 2 or J.shape[1] < 6 or jv.shape != (J.shape[0],) or base.shape != (6,):
        raise ValueError("contact-reference Jacobian/base dimensions mismatch")
    if (dofs.ndim != 1 or len(set(dofs.tolist())) != len(dofs)
            or np.any(dofs < 6) or np.any(dofs >= J.shape[1])):
        raise ValueError("contact-reference actuator/DOF mapping mismatch")
    if not all(np.isfinite(a).all() for a in (J, jv, base)):
        raise ValueError("contact-reference inputs must be finite")
    Jb, Jj = J[:, :6], J[:, dofs]
    rhs = -jv - Jb @ base
    U, singular_values, Vh = np.linalg.svd(Jj, full_matrices=False)
    threshold = RELATIVE_RANK_CUTOFF * (float(singular_values[0]) if singular_values.size else 0.0)
    keep = singular_values > threshold
    rank = int(np.count_nonzero(keep))
    joint_ref = (Vh[keep, :].T @ ((U[:, keep].T @ rhs) / singular_values[keep])
                 if rank else np.zeros(len(dofs), dtype=float))
    closure = Jb @ base + Jj @ joint_ref + jv
    full_rank = rank == min(Jj.shape) and rank > 0
    condition = float(singular_values[0] / singular_values[-1]) if full_rank else None
    diagnostic = {
        "relative_rank_cutoff": RELATIVE_RANK_CUTOFF,
        "absolute_singular_value_cutoff": threshold,
        "singular_values": singular_values.tolist(), "rank": rank,
        "shape": list(Jj.shape), "condition_estimate": condition,
        "condition_status": "FINITE_FULL_RANK" if full_rank else "RANK_DEFICIENT_OR_ZERO",
        "rhs": rhs.tolist(), "closure_residual": closure.tolist(),
        "closure_residual_inf": float(np.max(np.abs(closure))) if closure.size else 0.0,
        "closure_residual_unit": "m/s^2", "joint_reference_unit": "rad/s^2",
        "joint_reference_order": "actuator order through mapped_joint_dofs",
        "solution": "fixed-SVD least-norm least-squares; unclosed residual retained",
        "reference_clipped": False,
    }
    return joint_ref, diagnostic


def predict_dry_friction(qvel: Any, joint_reference: Any, dof_frictionloss: Any,
                         mapped_joint_dofs: Iterable[int]) -> tuple[np.ndarray, dict[str, Any]]:
    """Model bounded opposing hinge friction using current motion/intention.

    No simulator acceleration or constraint-force truth enters this prediction.
    This deadband rule is an approximation near rest, not MuJoCo's exact law.
    """
    velocity = np.asarray(qvel, dtype=float).reshape(-1)
    eta = np.asarray(dof_frictionloss, dtype=float).reshape(-1)
    dofs = np.asarray(tuple(mapped_joint_dofs), dtype=int)
    reference = np.asarray(joint_reference, dtype=float).reshape(-1)
    if eta.shape != velocity.shape or reference.shape != dofs.shape:
        raise ValueError("dry-friction input dimensions mismatch")
    if (len(set(dofs.tolist())) != len(dofs) or np.any(dofs < 0)
            or np.any(dofs >= velocity.size)):
        raise ValueError("dry-friction actuator/DOF mapping mismatch")
    if not all(np.isfinite(a).all() for a in (velocity, eta, reference)) or np.any(eta < 0):
        raise ValueError("dry-friction inputs must be finite and frictionloss nonnegative")
    local_velocity = velocity[dofs]
    moving = np.abs(local_velocity) > VELOCITY_DEADBAND_RAD_S
    intending = np.abs(reference) > ACCELERATION_DEADBAND_RAD_S2
    direction = np.where(moving, np.sign(local_velocity), np.where(intending, np.sign(reference), 0.0))
    predicted = np.zeros(velocity.size, dtype=float)
    predicted[dofs] = -eta[dofs] * direction
    branches = ["CURRENT_VELOCITY" if m else "REFERENCE_ACCELERATION_NEAR_REST" if a else "ZERO_DEADBAND"
                for m, a in zip(moving, intending)]
    diagnostic = {
        "velocity_deadband_rad_s": VELOCITY_DEADBAND_RAD_S,
        "reference_acceleration_deadband_rad_s2": ACCELERATION_DEADBAND_RAD_S2,
        "direction_actuator_order": direction.tolist(), "branch_actuator_order": branches,
        "compiled_frictionloss_actuator_order_nm": eta[dofs].tolist(),
        "mapped_qvel_rad_s": local_velocity.tolist(),
        "mapped_joint_reference_rad_s2": reference.tolist(),
        "g_loss_pred_unit": "hinge N*m; unactuated generalized entries zero",
        "bounded_by_compiled_frictionloss": bool(np.all(np.abs(predicted[dofs]) <= eta[dofs])),
        "near_rest_intention_rule_is_approximation": True,
        "passive_force_includes_dry_friction": False,
        "uses_qacc_or_qfrc_constraint": False,
    }
    return predicted, diagnostic


class Step21WBC(DynamicWBC):
    """Three explicit STEP21 configurations, sharing the original B1 path."""
    def __init__(self, model, configuration: str, cfg=None, solve_callback=None, *, acceptance_config=None):
        if configuration not in CONFIGURATIONS:
            raise ValueError(f"unknown STEP21 configuration: {configuration}")
        super().__init__(model, cfg, solve_callback, acceptance_config=acceptance_config)
        self.configuration = configuration
        self.last_trace: dict[str, Any] = {}
        self.contact_linearization_calls = 0
        self.svd_calls = 0
        self.loss_model_calls = 0
        self.mapping_info = self._compiled_loss_mapping()

    def _compiled_loss_mapping(self) -> dict[str, Any]:
        if self.nv != 18 or self.nu != 12 or set(self._dof_for_actuator.tolist()) != set(range(6, 18)):
            raise ValueError("STEP21 expects a free base and 12 distinct actuated hinge DOFs")
        rows = []
        for i in range(self.nv):
            joint_id = int(self.model.dof_jntid[i])
            joint_type = int(self.model.jnt_type[joint_id])
            rows.append({
                "dof": i, "joint_id": joint_id,
                "joint_name": mujoco.mj_id2name(self.model, mujoco.mjtObj.mjOBJ_JOINT, joint_id),
                "joint_type": mujoco.mjtJoint(joint_type).name,
                "joint_type_value": joint_type,
                "damping": float(self.model.dof_damping[i]),
                "frictionloss": float(self.model.dof_frictionloss[i]),
                "generalized_force_unit": "N" if i < 3 else "N*m",
                "velocity_unit": "m/s" if i < 3 else "rad/s",
                "damping_unit": "N*s/m" if i < 3 else "N*m*s/rad",
            })
        mapping = []
        for e in self._mapping:
            if int(self.model.jnt_type[e.joint_id]) != int(mujoco.mjtJoint.mjJNT_HINGE):
                raise ValueError(f"STEP21 mapped actuator {e.actuator_name} is not a hinge")
            mapping.append({"actuator_index": int(e.actuator_index), "actuator_name": e.actuator_name,
                            "joint_name": e.joint_name, "joint_id": int(e.joint_id),
                            "dof": int(e.dof_index), "torque_unit": e.unit,
                            "damping_nm_s_rad": float(self.model.dof_damping[e.dof_index]),
                            "frictionloss_nm": float(self.model.dof_frictionloss[e.dof_index]),
                            "healthy_torque_limit_nm": float(e.joint_torque_limit)})
        unactuated = [r for r in rows if r["dof"] not in set(self._dof_for_actuator.tolist()) and r["frictionloss"] != 0.0]
        return {"nv": self.nv, "nu": self.nu, "all_dofs": rows,
                "actuator_to_dof": mapping, "mapped_joint_dofs": self._dof_for_actuator.tolist(),
                "unactuated_nonzero_frictionloss_unmodeled": unactuated,
                "parameter_source": "actual compiled MjModel; no frictionloss hardcoding",
                "actuated_hinges": 12, "qfrc_passive_and_dry_friction_separate": True}

    def compute(self, data, method: str, health, target: Mapping[str, Any] | None = None):
        if str(method).upper() != "B1":
            raise ValueError("STEP21 fixed development batch uses only B1 single-stage QP")
        self.last_trace = {}
        return super().compute(data, "B1", health, target)

    def _problem(self, data, health, target, **kwargs):
        if kwargs.get("stage2") or kwargs.get("physical") is not None:
            raise ValueError("STEP21 uses the single-stage physical linearization")
        # One original assembly provides exactly the contact points, Jacobian,
        # Jdot*v and physical constraints used below; no second Jacobian pass.
        P, q, A, l, u, meta = super()._problem(data, health, target, **kwargs)
        self.contact_linearization_calls += 1
        original_bias = meta["bias"].copy()
        passive = np.asarray(data.qfrc_passive, dtype=float).copy()
        desired = meta["desired"].copy()
        raw_joint = desired[6:].copy()
        reference_diagnostic = None
        if self.configuration != CONFIGURATIONS[0]:
            raw_joint, reference_diagnostic = contact_reference(
                meta["Jc"], meta["jdotv"], desired[:6], self._dof_for_actuator)
            self.svd_calls += 1
            desired[6:] = raw_joint
            meta["desired"] = desired
            q[:self.nv] = -(meta["T"].T @ (meta["weights"] * desired))
        loss = np.zeros(self.nv, dtype=float)
        loss_diagnostic = None
        bias_eff = original_bias.copy()
        model_version = LEGACY_MODEL_VERSION
        if self.configuration == CONFIGURATIONS[2]:
            loss, loss_diagnostic = predict_dry_friction(
                data.qvel, raw_joint, self.model.dof_frictionloss, self._dof_for_actuator)
            self.loss_model_calls += 1
            bias_eff = original_bias - passive - loss
            meta["bias"] = bias_eff
            l[:self.nv] = -bias_eff
            u[:self.nv] = -bias_eff
            model_version = LOSS_MODEL_VERSION
        meta["step21_model_version"] = model_version
        meta["step21_bias_original"] = original_bias
        meta["step21_qfrc_passive"] = passive
        meta["step21_g_loss_pred"] = loss
        self.last_trace = {
            "configuration": self.configuration, "model_version": model_version,
            "dynamics_residual_definition": "M @ qdd + bias_eff - B @ tau_total - Jc.T @ lambda",
            "legacy_dynamics_residual_definition": "M @ qdd + qfrc_bias - B @ tau_total - Jc.T @ lambda",
            "bias_eff_definition": ("qfrc_bias - qfrc_passive - g_loss_pred" if model_version == LOSS_MODEL_VERSION else "qfrc_bias"),
            "Jc": meta["Jc"].tolist(), "jdotv": meta["jdotv"].tolist(), "points": meta["points"].tolist(),
            "mapped_joint_dofs": self._dof_for_actuator.tolist(), "a_base_ref": desired[:6].tolist(),
            "raw_joint_reference": raw_joint.tolist(), "contact_reference": reference_diagnostic,
            "desired": meta["desired"].tolist(), "weights": meta["weights"].tolist(),
            "linear_objective_q": q.tolist(), "T": meta["T"].tolist(), "M": meta["M"].tolist(),
            "bias_original": original_bias.tolist(), "qfrc_passive": passive.tolist(),
            "g_loss_pred": loss.tolist(), "bias_eff": bias_eff.tolist(), "loss_prediction": loss_diagnostic,
            "B": meta["B"].tolist(), "tau_lim": meta["tau_lim"].tolist(),
            "dynamics_lower": l[:self.nv].tolist(), "dynamics_upper": u[:self.nv].tolist(),
            "postsolve_torque_increment": False, "qacc_and_constraint_not_used_for_command": True,
        }
        return P, q, A, l, u, meta

    def _decode(self, out, meta, method):
        # Original decoder returns the QP's tau unchanged. Its bias is explicit
        # in this assembly, so both decoding and optional validation use KF RHS.
        result = super()._decode(out, meta, method)
        result["configuration"] = self.configuration
        result["model_version"] = meta["step21_model_version"]
        result["dynamics_residual_definition"] = "M @ qdd + bias_eff - B @ tau_total - Jc.T @ lambda"
        result["postsolve_torque_increment"] = False
        if result["qdd"] is not None:
            qdd, tau, lam = result["qdd"], result["tau"], result["contact_force"]
            common = meta["M"] @ qdd - meta["B"] @ tau - meta["Jc"].T @ lam
            effective, original = common + meta["bias"], common + meta["step21_bias_original"]
            result["validation"].update({
                "dynamics_model_version": meta["step21_model_version"],
                "dynamics_residual_signed": effective.tolist(),
                "legacy_dynamics_residual_signed": original.tolist(),
                "legacy_dynamics_residual_inf": float(np.max(np.abs(original))),
            })
        return result


def specification() -> dict[str, Any]:
    return {"configurations": list(CONFIGURATIONS), "method": "B1",
            "relative_svd_rank_cutoff": RELATIVE_RANK_CUTOFF,
            "velocity_deadband_rad_s": VELOCITY_DEADBAND_RAD_S,
            "reference_acceleration_deadband_rad_s2": ACCELERATION_DEADBAND_RAD_S2,
            "legacy_dynamics_model_version": LEGACY_MODEL_VERSION,
            "loss_dynamics_model_version": LOSS_MODEL_VERSION,
            "loss_bias_definition": "qfrc_bias - qfrc_passive - g_loss_pred",
            "dry_friction_rule": "oppose velocity above deadband, otherwise reference acceleration above deadband, otherwise zero",
            "reference_clipped": False, "postsolve_torque_increment": False,
            "same_tick_physical_linearization_reused": True,
            "uses_qacc_or_qfrc_constraint_for_command": False}
