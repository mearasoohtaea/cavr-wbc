"""STEP22 opt-in full base-pose servo and contact/passive-force WBC.

The two fixed development servos share one B1 assembly and one solve per tick.
Pose error uses MuJoCo's free-joint tangent coordinates. Dry-friction prediction
is disabled; the only force-model addition is the known current passive force.
"""
from __future__ import annotations

from dataclasses import replace
from time import perf_counter
from typing import Any, Mapping

import mujoco
import numpy as np

from cavr_wbc.control.e2b_dynamic import DynamicWBC, DynamicWBCConfig
from cavr_wbc.control.step20_task_reference import reference
from cavr_wbc.control.step21_contact_reference import Step21WBC, contact_reference


CONFIGURATIONS = ("S22_POSE_PD", "S22_POSE_PID")
OMEGA_S_INV = 8.0
CONTROL_DT_S = 0.020
INTEGRAL_LIMITS = np.ones(6, dtype=float)
AUTHORITY_GATE_FRACTION = 0.99
MODEL_VERSION = "STEP22_QFRC_BIAS_MINUS_KNOWN_PASSIVE_V1"
GAINS = {
    "S22_POSE_PD": {"kp_s_inv2": 64.0, "kd_s_inv": 16.0, "ki_s_inv3": 0.0},
    "S22_POSE_PID": {"kp_s_inv2": 192.0, "kd_s_inv": 24.0, "ki_s_inv3": 512.0},
}


def tangent_pose_error(model, current_qpos: Any, q_reference: Any) -> np.ndarray:
    """Current-to-reference pose displacement in free-joint qvel coordinates.

    dt=1 constructs a tangent displacement, not a measured physical velocity.
    First three channels are world-frame metres; rotation is local-frame radians.
    """
    current = np.asarray(current_qpos, dtype=float).reshape(-1)
    target = np.asarray(q_reference, dtype=float).reshape(-1)
    if current.shape != (int(model.nq),) or target.shape != current.shape:
        raise ValueError("STEP22 pose coordinates do not match model.nq")
    if not np.isfinite(current).all() or not np.isfinite(target).all():
        raise ValueError("STEP22 tangent pose inputs must be finite")
    error = np.zeros(int(model.nv), dtype=float)
    mujoco.mj_differentiatePos(model, error, 1.0, current, target)
    return error[:6].copy()


class Step22WBC(DynamicWBC):
    """Shared B1 QP with contact references and a 20 ms command horizon."""
    def __init__(self, model, solve_callback=None, *, acceptance_config=None):
        super().__init__(model, replace(DynamicWBCConfig(), wbc_dt=CONTROL_DT_S),
                         solve_callback, acceptance_config=acceptance_config)
        self.last_trace: dict[str, Any] = {}
        self.mapping_info = Step21WBC._compiled_loss_mapping(self)
        self.mapping_info.update(dry_friction_feedforward_enabled=False,
                                 joint_bound_command_horizon_s=CONTROL_DT_S)
        self.contact_linearization_calls = 0
        self.svd_calls = 0
        self.passive_model_calls = 0

    def compute(self, data, method: str, health, target: Mapping[str, Any] | None = None):
        if str(method).upper() != "B1":
            raise ValueError("STEP22 uses one B1 single-stage solve per control tick")
        self.last_trace = {}
        return super().compute(data, "B1", health, target)

    def _problem(self, data, health, target, **kwargs):
        if kwargs.get("stage2") or kwargs.get("physical") is not None:
            raise ValueError("STEP22 uses the same-tick single-stage linearization")
        P, q, A, l, u, meta = super()._problem(data, health, target, **kwargs)
        self.contact_linearization_calls += 1
        desired = meta["desired"].copy()
        joint_ref, diagnostic = contact_reference(
            meta["Jc"], meta["jdotv"], desired[:6], self._dof_for_actuator)
        self.svd_calls += 1
        desired[6:] = joint_ref
        meta["desired"] = desired
        q[:self.nv] = -(meta["T"].T @ (meta["weights"] * desired))
        original_bias = meta["bias"].copy()
        passive = np.asarray(data.qfrc_passive, dtype=float).copy()
        loss = np.zeros(self.nv, dtype=float)
        effective = original_bias - passive
        meta["bias"] = effective
        l[:self.nv] = -effective
        u[:self.nv] = -effective
        self.passive_model_calls += 1
        meta.update(step22_model_version=MODEL_VERSION,
                    step22_bias_original=original_bias, step22_qfrc_passive=passive)
        self.last_trace = {
            "configuration": target.get("servo_configuration", "STEP22_SHARED_POSE_WBC"),
            "model_version": MODEL_VERSION,
            "dynamics_residual_definition": "M @ qdd + (qfrc_bias - qfrc_passive) - B @ tau_total - Jc.T @ lambda",
            "legacy_dynamics_residual_definition": "M @ qdd + qfrc_bias - B @ tau_total - Jc.T @ lambda",
            "bias_eff_definition": "qfrc_bias - qfrc_passive",
            "Jc": meta["Jc"].tolist(), "jdotv": meta["jdotv"].tolist(),
            "points": meta["points"].tolist(), "mapped_joint_dofs": self._dof_for_actuator.tolist(),
            "a_base_ref": desired[:6].tolist(), "raw_joint_reference": joint_ref.tolist(),
            "contact_reference": diagnostic, "desired": desired.tolist(),
            "weights": meta["weights"].tolist(), "linear_objective_q": q.tolist(),
            "T": meta["T"].tolist(), "M": meta["M"].tolist(),
            "bias_original": original_bias.tolist(), "qfrc_passive": passive.tolist(),
            "g_loss_pred": loss.tolist(), "bias_eff": effective.tolist(),
            "loss_prediction": {"enabled": False, "g_loss_pred_all_zero": True,
                                "full_amplitude_dry_friction_feedforward": "DISABLED"},
            "B": meta["B"].tolist(), "tau_lim": meta["tau_lim"].tolist(),
            "dynamics_lower": l[:self.nv].tolist(), "dynamics_upper": u[:self.nv].tolist(),
            "joint_bound_previous_horizon_s": DynamicWBCConfig().wbc_dt,
            "joint_bound_command_horizon_s": self.cfg.wbc_dt,
            "joint_bound_lower_actuator_order": meta["qdd_lo"][self._dof_for_actuator].tolist(),
            "joint_bound_upper_actuator_order": meta["qdd_hi"][self._dof_for_actuator].tolist(),
            "postsolve_torque_increment": False,
            "qacc_and_constraint_not_used_for_command": True,
        }
        return P, q, A, l, u, meta

    def _decode(self, out, meta, method):
        result = super()._decode(out, meta, method)
        result.update(model_version=MODEL_VERSION, postsolve_torque_increment=False,
                      dynamics_residual_definition="M @ qdd + (qfrc_bias - qfrc_passive) - B @ tau_total - Jc.T @ lambda")
        if result["qdd"] is not None:
            qdd, tau, lam = result["qdd"], result["tau"], result["contact_force"]
            common = meta["M"] @ qdd - meta["B"] @ tau - meta["Jc"].T @ lam
            effective = common + meta["bias"]
            original = common + meta["step22_bias_original"]
            result["validation"].update(dynamics_model_version=MODEL_VERSION,
                                        dynamics_residual_signed=effective.tolist(),
                                        legacy_dynamics_residual_signed=original.tolist(),
                                        legacy_dynamics_residual_inf=float(np.max(np.abs(original))))
        return result


class BasePoseServo:
    """Fixed six-channel PD/PID servo, with integral state in acceleration units."""
    def __init__(self, model, q_init: Any, d: float, configuration: str):
        if configuration not in CONFIGURATIONS:
            raise ValueError(f"unknown STEP22 servo configuration: {configuration}")
        self.model = model
        self.q_init = np.asarray(q_init, dtype=float).reshape(-1).copy()
        if self.q_init.shape != (int(model.nq),) or not np.isfinite(self.q_init).all():
            raise ValueError("STEP22 requires one finite full reset q_init")
        if int(model.nv) < 6 or not np.isclose(np.linalg.norm(self.q_init[3:7]), 1.0, atol=1e-10):
            raise ValueError("STEP22 reference requires a normalized initial free-joint quaternion")
        self.q_init.flags.writeable = False
        self.d = float(d)
        if not np.isfinite(self.d):
            raise ValueError("STEP22 displacement must be finite")
        self.configuration = configuration
        self.gains = dict(GAINS[configuration])
        self.b_integral = np.zeros(6, dtype=float)
        self.pose_error_calls = 0
        self.integral_update_calls = 0

    def compute(self, controller, data, health, tick: int) -> dict[str, Any]:
        begin = perf_counter()
        if int(tick) != tick or tick < 0:
            raise ValueError("STEP22 control tick must be a nonnegative integer")
        ref = reference(float(self.q_init[0]), self.d, int(tick) * CONTROL_DT_S)
        before = self.b_integral.copy()
        b_used = before.copy() if self.configuration == CONFIGURATIONS[1] else np.zeros(6, dtype=float)
        finite_state = bool(np.isfinite(data.qpos).all() and np.isfinite(data.qvel).all()
                            and np.isfinite(self.b_integral).all())
        if not finite_state:
            wb = {"success": False, "status": "NONFINITE_INPUT_STATE", "status_val": None,
                  "command_status": "NO_VALID_COMMAND", "tau": None, "qdd": None,
                  "contact_force": None, "validation": {}, "model_version": MODEL_VERSION,
                  "solver_calls": 0}
            record = {"b_used": b_used.tolist(), "b_before": before.tolist(), "b_after": before.tolist(),
                      "freeze_reason": "NONFINITE_STATE", "updated": False,
                      "limits": INTEGRAL_LIMITS.tolist(), "authority_gate_saturated_actuators": [],
                      "authority_gate_fraction": AUTHORITY_GATE_FRACTION,
                      "state_unit": ["m/s^2"] * 3 + ["rad/s^2"] * 3,
                      "qp_calls_this_tick": 0}
            return {"wbc": wb, "wb": wb, "tau_cmd": np.zeros(int(self.model.nu)).tolist(),
                    "valid_command": False, "latency_ms": (perf_counter() - begin) * 1000,
                    "configuration": self.configuration, "external_reference": ref,
                    "q_reference": None, "measured_p_m": None, "measured_v_m_s": None,
                    "e_pose": None, "e_vel": None, "v_reference": None,
                    "a_feedforward": None, "a_base_ref": None, "integral_record": record,
                    "target_before_method_transform": None}
        q_reference = np.asarray(data.qpos, dtype=float).copy()
        q_reference[:7] = self.q_init[:7]
        q_reference[0] = ref["p_ref_m"]
        e_pose = tangent_pose_error(self.model, data.qpos, q_reference)
        self.pose_error_calls += 1
        v_reference = np.zeros(6, dtype=float); v_reference[0] = ref["v_ref_m_s"]
        feedforward = np.zeros(6, dtype=float); feedforward[0] = ref["a_ref_m_s2"]
        e_vel = v_reference - np.asarray(data.qvel[:6], dtype=float)
        a_base = feedforward + self.gains["kp_s_inv2"] * e_pose + self.gains["kd_s_inv"] * e_vel + b_used
        target = {"desired_base_accel": a_base.tolist(),
                  "desired_joint_accel": [0.] * int(self.model.nu),
                  "task_weights": [1.] * (6 + int(self.model.nu)),
                  "servo_configuration": self.configuration,
                  "com_velocity": ref["v_ref_m_s"], "com_height": float(self.q_init[2]),
                  "p_max": 1.0, "target_position": ref["p_ref_m"]}
        wb = controller.compute(data, "B1", health, target)
        tau = wb.get("tau")
        valid = bool(wb.get("success")) and tau is not None
        if valid:
            tau = np.asarray(tau, dtype=float).reshape(-1)
            valid = tau.shape == (int(self.model.nu),) and bool(np.isfinite(tau).all())
        tau_cmd = tau.copy() if valid else np.zeros(int(self.model.nu), dtype=float)
        current_limits = np.asarray(controller._healthy_limits, dtype=float) * controller._health(health)
        saturated = []
        zero_capacity = np.flatnonzero(current_limits <= 0.).tolist()
        if valid:
            saturated = np.flatnonzero((current_limits <= 0.) |
                                      (np.abs(tau_cmd) >= AUTHORITY_GATE_FRACTION * current_limits)).tolist()
        updated = False
        if self.configuration == CONFIGURATIONS[0]:
            self.b_integral[:] = 0.0
            reason = "DISABLED_PD"
        elif not valid:
            reason = "INVALID_COMMAND"
        elif saturated:
            reason = "ACTUATOR_AUTHORITY_SATURATED"
        else:
            self.b_integral[:] = np.clip(before + CONTROL_DT_S * self.gains["ki_s_inv3"] * e_pose,
                                         -INTEGRAL_LIMITS, INTEGRAL_LIMITS)
            self.integral_update_calls += 1
            updated = True
            reason = None
        record = {"b_used": b_used.tolist(), "b_before": before.tolist(),
                  "b_after": self.b_integral.tolist(), "freeze_reason": reason, "updated": updated,
                  "limits": INTEGRAL_LIMITS.tolist(), "authority_gate_saturated_actuators": saturated,
                  "authority_gate_fraction": AUTHORITY_GATE_FRACTION,
                  "current_health_torque_limits_nm": current_limits.tolist(),
                  "zero_capacity_saturated_actuators": zero_capacity,
                  "state_unit": ["m/s^2"] * 3 + ["rad/s^2"] * 3,
                  "qp_calls_this_tick": 1, "update_uses_current_pose_error_after_single_qp": True}
        # The timer includes reference/tangent error, authority gate, update,
        # single QP, fallback and command selection; serialization is diagnostic.
        elapsed_ms = (perf_counter() - begin) * 1000
        return {"wbc": wb, "wb": wb, "tau_cmd": tau_cmd.tolist(), "valid_command": valid,
                "latency_ms": elapsed_ms, "configuration": self.configuration,
                "external_reference": ref, "q_reference": q_reference.tolist(),
                "measured_p_m": float(data.qpos[0]), "measured_v_m_s": float(data.qvel[0]),
                "e_pose": e_pose.tolist(), "e_vel": e_vel.tolist(),
                "v_reference": v_reference.tolist(), "a_feedforward": feedforward.tolist(),
                "a_base_ref": a_base.tolist(), "target_before_method_transform": target,
                "integral_record": record}


def specification() -> dict[str, Any]:
    return {"configurations": list(CONFIGURATIONS), "omega_s_inv": OMEGA_S_INV,
            "gains": GAINS, "channels": "all six free-joint tangent channels",
            "nominal_error_polynomial": {"S22_POSE_PD": "(s + omega)^2", "S22_POSE_PID": "(s + omega)^3"},
            "nominal_poles_s_inv": {"S22_POSE_PD": [-8., -8.], "S22_POSE_PID": [-8., -8., -8.]},
            "linear_design_is_not_robot_stability_proof": True,
            "pose_error": "mj_differentiatePos(current, reference, dt=1); tangent displacement, not physical velocity",
            "pose_error_units": ["m"] * 3 + ["rad"] * 3,
            "velocity_error_units": ["m/s"] * 3 + ["rad/s"] * 3,
            "rotation_frame": "free-joint local angular coordinates",
            "fixed_reference": "reset base y/z/quaternion; quintic world x; current joint coordinates",
            "control_dt_s": CONTROL_DT_S, "joint_bound_previous_horizon_s": DynamicWBCConfig().wbc_dt,
            "joint_bound_command_horizon_s": CONTROL_DT_S, "integral_limits": INTEGRAL_LIMITS.tolist(),
            "integral_state_units": ["m/s^2"] * 3 + ["rad/s^2"] * 3,
            "authority_gate_fraction": AUTHORITY_GATE_FRACTION,
            "integral_update_order": "use b_k, one QP, then update all six only valid unsaturated command",
            "zero_authority_actuator_is_saturated": True,
            "model_version": MODEL_VERSION, "bias_eff_definition": "qfrc_bias - qfrc_passive",
            "full_amplitude_dry_friction_feedforward": "DISABLED", "g_loss_pred": "all generalized entries zero",
            "same_tick_contact_linearization_reused": True, "relative_svd_rank_cutoff": 1e-10,
            "postsolve_torque_increment": False, "method": "B1", "qp_calls_per_decision": 1,
            "predictive_recoverability_filter": False}
