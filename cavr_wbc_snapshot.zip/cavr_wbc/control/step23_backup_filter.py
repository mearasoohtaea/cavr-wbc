"""STEP23 single-decision sampled backup prediction and execution branches.

Each branch owns a complete MuJoCo data clone and an independent feedback
backup/controller. Prediction screens numeric observed facts; no independent
actual-execution evaluator or cached physical label enters a decision.
"""
from __future__ import annotations

from time import perf_counter
from typing import Any, Mapping

import mujoco
import numpy as np

from cavr_wbc.control.step22_pose_servo import BasePoseServo, Step22WBC
from cavr_wbc.experiments import step17_formal_panel as frozen
from cavr_wbc.platforms.go2_mujoco import FOOT_NAMES, extract_healthy_torque_limits


HOLD_VERSION = "STEP23_HOLD_CURRENT_POSE_PID_V1"
PHYSICS_DT_S = .002
CONTROL_DT_S = .020
PHYSICS_STEPS = 500
CONTROL_SLOTS = 50
PHYSICS_STEPS_PER_SLOT = 10
PREVIEW_STEPS = 10
CHECKPOINT_STEPS = tuple(range(0, 501, 25))
FIRST_MODES = ("CANDIDATE", "BACKUP", "ZERO")
METHODS = ("M0_QP_CANDIDATE", "M1_ONE_STEP_FILTER", "M2_HORIZON_FILTER")


def clone_data(model, source):
    """Copy the complete MjData, including mjSTATE_INTEGRATION and warmstart."""
    clone = mujoco.MjData(model)
    mujoco.mj_copyData(clone, model, source)
    return clone


def state_values(model, data) -> dict[str, Any]:
    """Serialize complete integration state plus named fields for inspection."""
    signature = int(mujoco.mjtState.mjSTATE_INTEGRATION)
    state = np.empty(mujoco.mj_stateSize(model, signature), dtype=float)
    mujoco.mj_getState(model, data, state, signature)
    result = {"time_s": float(data.time), "integration_state_signature": signature,
              "integration_state": state.tolist()}
    for name in ("qpos", "qvel", "act", "ctrl", "qacc_warmstart", "qfrc_applied",
                 "xfrc_applied", "mocap_pos", "mocap_quat", "userdata", "plugin_state"):
        if hasattr(data, name): result[name] = np.asarray(getattr(data, name)).copy().tolist()
    return result


class HoldBackup:
    """Independent fixed-anchor STEP22 PID; never inherits nominal integral."""
    def __init__(self, model, anchor_q_init, backup_id: str, solve_callback=None):
        if not isinstance(backup_id, str) or not backup_id:
            raise ValueError("STEP23 requires a nonempty immutable backup ID")
        self._backup_id = backup_id
        self._anchor_q_init = np.asarray(anchor_q_init, dtype=float).copy()
        self._anchor_q_init.flags.writeable = False
        self.controller = Step22WBC(model, solve_callback=solve_callback)
        self.servo = BasePoseServo(model, self._anchor_q_init, 0., "S22_POSE_PID")

    @property
    def backup_id(self):
        return self._backup_id

    @property
    def version(self):
        return HOLD_VERSION

    @property
    def anchor_q_init(self):
        result = self._anchor_q_init.copy(); result.flags.writeable = False
        return result

    def compute(self, data, health, slot: int):
        result = self.servo.compute(self.controller, data, health, slot)
        result.update(backup_id=self.backup_id, backup_version=self.version,
                      fixed_anchor_q_init=self._anchor_q_init.tolist())
        return result


def slot_action_sources(first_mode: str) -> tuple[str, ...]:
    if first_mode not in FIRST_MODES:
        raise ValueError("unknown STEP23 first-slot action")
    return (first_mode,) + ("BACKUP",) * (CONTROL_SLOTS - 1)


def _numeric_vector(row, key):
    values = np.asarray(row[key], dtype=float)
    if values.ndim != 1 or not np.isfinite(values).all():
        raise ValueError(f"nonfinite/malformed numeric {key}")
    return values


def predicted_physical_check(row: Mapping[str, Any]) -> dict[str, Any]:
    """Recompute fixed physical predicates directly from numeric facts.

    ``physical_evaluation`` and controller/evaluator labels are never read.
    Deadline is reported separately and does not alter this offline screen.
    """
    names = ("finite", "contact", "normal_force", "friction", "command_torque", "applied_torque",
             "joint_limit", "height", "boundary", "speed", "angular_speed", "angle")
    try:
        qpos, qvel = _numeric_vector(row, "qpos"), _numeric_vector(row, "qvel")
        if len(qpos) < 7 or len(qvel) < 6: raise ValueError("free-joint state missing")
        tau, applied = _numeric_vector(row, "tau_cmd"), _numeric_vector(row, "tau_applied")
        health, limits = _numeric_vector(row, "health_vector"), _numeric_vector(row, "actuator_limits")
        if not (tau.shape == applied.shape == health.shape == limits.shape) or not len(tau):
            raise ValueError("torque/health numeric dimensions mismatch")
        if np.any((health < 0) | (health > 1)) or np.any(limits < 0):
            raise ValueError("invalid health/limit numeric range")
        joints = _numeric_vector(row, "joint_limit_margins")
        if not len(joints): raise ValueError("joint limit numeric margins missing")
        subtree = np.asarray(row["subtree_com"], dtype=float)
        if subtree.ndim == 2:
            subtree = subtree[int(row["base_body_id"])]
        if subtree.shape != (3,) or not np.isfinite(subtree).all():
            raise ValueError("subtree COM numeric fact missing")
        roll, pitch, boundary = float(row["roll"]), float(row["pitch"]), float(row["boundary_margin_m"])
        if not np.isfinite([roll, pitch, boundary]).all(): raise ValueError("nonfinite scalar physical fact")
        contacts = row["contacts"]
        contact = []; normal = []; margins = []
        for foot in FOOT_NAMES:
            value = contacts[foot]
            present = bool(value["present"])
            n, margin = float(value["normal_force_n"]), float(value["friction_margin_n"])
            if not np.isfinite([n, margin]).all(): raise ValueError("nonfinite contact numeric fact")
            contact.append(present); normal.append(n); margins.append(margin)
        current_limits = limits * health
        command_margin = current_limits - np.abs(tau)
        applied_margin = current_limits - np.abs(applied)
        predicates = {"finite": True, "contact": bool(all(contact)),
                      "normal_force": bool(all(n >= 0 for n in normal)),
                      "friction": bool(all(m >= 0 for m in margins)),
                      "command_torque": bool(np.all(command_margin >= 0.)),
                      "applied_torque": bool(np.all(applied_margin >= 0.)),
                      "joint_limit": bool(np.all(joints >= 0.)),
                      "height": bool(.16 <= float(subtree[2]) <= .60),
                      "boundary": bool(boundary >= 0. and 1.0 - float(qpos[0]) >= 0.),
                      "speed": bool(abs(float(qvel[0])) <= 2.),
                      "angular_speed": bool(np.linalg.norm(qvel[3:6]) <= 2.),
                      "angle": bool(abs(roll) <= .55 and abs(pitch) <= .55)}
        return {"pass": bool(all(predicates.values())), "predicates": predicates,
                "failure_reasons": [key for key, passed in predicates.items() if not passed],
                "command_torque_margin_nm": float(np.min(command_margin)),
                "applied_torque_margin_nm": float(np.min(applied_margin)),
                "boundary_margin_m": boundary, "subtree_com_height_m": float(subtree[2]),
                "friction_margin_min_n": float(min(margins)),
                "angular_speed_rad_s": float(np.linalg.norm(qvel[3:6])),
                "uses_cached_physical_labels": False, "torque_tolerance_nm": 0.}
    except (KeyError, TypeError, ValueError, IndexError, OverflowError) as exc:
        return {"pass": False, "predicates": dict.fromkeys(names, False),
                "failure_reasons": ["NONFINITE_OR_MISSING_NUMERIC_FACT"],
                "numeric_error": str(exc), "uses_cached_physical_labels": False,
                "torque_tolerance_nm": 0.}


def predicted_terminal_check(row: Mapping[str, Any], anchor_q_init) -> dict[str, Any]:
    physical = predicted_physical_check(row)
    try:
        qpos, qvel = _numeric_vector(row, "qpos"), _numeric_vector(row, "qvel")
        anchor = np.asarray(anchor_q_init, dtype=float)
        if anchor.ndim != 1 or not np.isfinite(anchor).all() or not len(anchor):
            raise ValueError("terminal anchor invalid")
        x_error = float(qpos[0] - anchor[0])
        roll, pitch = float(row["roll"]), float(row["pitch"])
        conditions = {"physical": physical["pass"], "anchor_x_error": abs(x_error) <= .002,
                      "base_x_speed": abs(float(qvel[0])) <= .001,
                      "original_terminal_y_speed": abs(float(qvel[1])) <= .25,
                      "original_terminal_angle": abs(roll) <= .20 and abs(pitch) <= .20}
        return {"pass": bool(all(conditions.values())), "predicates": conditions,
                "x_error_to_anchor_m": x_error, "base_x_velocity_m_s": float(qvel[0]),
                "anchor_x_m": float(anchor[0]), "physical": physical,
                "definition": "abs(x-anchor_x)<=.002, abs(vx)<=.001, original terminal angles/y-speed and physical predicates"}
    except (KeyError, TypeError, ValueError, IndexError, OverflowError) as exc:
        return {"pass": False, "physical": physical, "numeric_error": str(exc)}


def choose_methods(candidate_valid: bool, one_step_pass: bool, candidate_horizon_pass: bool,
                   immediate_horizon_pass: bool) -> dict[str, dict[str, Any]]:
    valid = bool(candidate_valid)
    one = valid and bool(one_step_pass)
    horizon = valid and bool(candidate_horizon_pass)
    return {
        METHODS[0]: {"first_mode": "CANDIDATE" if valid else "ZERO",
                     "safety_label": "QP_CANDIDATE_NO_LOOKAHEAD" if valid else "ZERO_COMMAND_FALLBACK_CURRENT_CANDIDATE_INVALID"},
        METHODS[1]: {"first_mode": "CANDIDATE" if one else "BACKUP",
                     "safety_label": "ONE_STEP_ACCEPTED" if one else "BACKUP_WITHOUT_HORIZON_SCREEN"},
        METHODS[2]: {"first_mode": "CANDIDATE" if horizon else "BACKUP",
                     "safety_label": ("SAMPLE_ACCEPTED" if horizon else "IMMEDIATE_BACKUP_SCREENED"
                                      if immediate_horizon_pass else "BACKUP_NOT_SCREENED_SAFE")},
    }


def _finite_state(data) -> bool:
    return bool(all(np.isfinite(getattr(data, name)).all() for name in
                    ("qpos", "qvel", "act", "ctrl", "qacc_warmstart", "qacc", "actuator_force")))


def _facts(model, data, health, limits, tau, action, ms, step, slot, backup_id, branch_id):
    row = frozen._facts(model, data, tau, data.actuator_force.copy(), health, limits, ms,
                        t=step * PHYSICS_DT_S, tick=slot, backup_id=backup_id,
                        scenario_id=branch_id, action=action, base_id=frozen._base_id(model))
    # Numeric state is retained even when physical predicates fail. The frozen
    # fact-provider's labels are diagnostic only and are not screen inputs.
    row["physical_evaluation"].pop("utility", None)
    row.update(physics_step=step, simulation_time_s=float(data.time),
               act=data.act.copy().tolist(), ctrl=data.ctrl.copy().tolist(),
               qacc_warmstart=data.qacc_warmstart.copy().tolist(),
               qacc_after_command_or_integration_refresh=data.qacc.copy().tolist())
    return row


def _json_safe(value):
    if isinstance(value, np.ndarray): return _json_safe(value.tolist())
    if isinstance(value, np.generic): return _json_safe(value.item())
    if isinstance(value, Mapping): return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)): return [_json_safe(v) for v in value]
    if isinstance(value, float) and not np.isfinite(value): return {"nonfinite": repr(value)}
    return value


def run_branch(model, current_data, health, anchor_q_init, backup_id, first_mode,
               candidate_tau, kind, branch_id, solve_callback=None, step_observer=None):
    """Execute one fresh 1 s branch; the observer authorizes every real step."""
    begin = perf_counter()
    sources = slot_action_sources(first_mode)
    data = clone_data(model, current_data); data.time = 0.
    policy = HoldBackup(model, anchor_q_init, backup_id, solve_callback=solve_callback)
    health = np.asarray(health, dtype=float).copy()
    limits = extract_healthy_torque_limits(model)
    if health.shape != (int(model.nu),) or not np.isfinite(health).all() or np.any((health < 0) | (health > 1)):
        raise ValueError("STEP23 branch health malformed")
    if first_mode == "CANDIDATE":
        candidate_tau = np.asarray(candidate_tau, dtype=float).copy()
        if candidate_tau.shape != (int(model.nu),) or not np.isfinite(candidate_tau).all():
            raise ValueError("STEP23 candidate command must already be finite and valid")
    initial_state = state_values(model, data)
    initialization_ms = (perf_counter() - begin) * 1000
    controls = []; physics = []; checkpoints = []; solver_ledger = []
    steps = 0; action_forward = 0; refresh = 0; cursor = 0
    all_valid = True; finite = True; failure = None; initial_fact = None
    first_backup_decision_ms = 0.
    integration_s = 0.; action_forward_s = 0.; fact_s = 0.
    for slot, source in enumerate(sources):
        if not _finite_state(data):
            finite = False; failure = {"reason": "NONFINITE_STATE_BEFORE_CONTROL", "slot": slot, "physics_step": steps}
            break
        response = None; wb = None; before = state_values(model, data)
        if source == "BACKUP":
            response = policy.compute(data, health, slot)
            wb = response.pop("wbc"); response.pop("wb", None)
            tau = np.asarray(response["tau_cmd"], dtype=float)
            valid = bool(response["valid_command"])
            all_valid = all_valid and valid
            ms = float(response["latency_ms"]); action = float(response["a_base_ref"][0])
            if slot == 0: first_backup_decision_ms = ms
            for entry in policy.controller.solver_ledger[cursor:]:
                solver_ledger.append(dict(entry, branch_id=branch_id, kind=kind, backup_id=backup_id,
                                          slot=slot, time_s=slot * CONTROL_DT_S))
            cursor = len(policy.controller.solver_ledger)
            source_label = "FEEDBACK_BACKUP_QP_TOTAL" if valid else "INVALID_BACKUP_QP_ZERO_COMMAND_FOR_INITIAL_FACT"
        else:
            tau = candidate_tau.copy() if source == "CANDIDATE" else np.zeros(model.nu)
            valid = True; ms = 0.; action = 0.
            source_label = "FIXED_CANDIDATE_TAU_20MS" if source == "CANDIDATE" else "ZERO_COMMAND_FALLBACK_CURRENT_CANDIDATE_INVALID"
        data.ctrl[:] = tau
        t = perf_counter(); mujoco.mj_forward(model, data); action_forward += 1
        action_forward_s += perf_counter() - t
        numerical_ok = _finite_state(data)
        pre = None
        if numerical_ok:
            t = perf_counter()
            pre = _facts(model, data, health, limits, tau, action, ms, steps, slot, backup_id, branch_id)
            fact_s += perf_counter() - t
        row = {"slot": slot, "time_s": slot * CONTROL_DT_S, "first_mode": first_mode,
               "action_source": source_label, "backup_id": backup_id, "backup_version": HOLD_VERSION,
               "pre_control_state": before, "tau_total": tau.tolist(), "tau_cmd": tau.tolist(),
               "tau_applied": data.actuator_force.copy().tolist(), "health_vector": health.tolist(),
               "valid_command": valid, "latency_ms": ms, "physical_at_decision": pre,
               "servo_response": response, "assembly": policy.controller.last_trace if source == "BACKUP" else None,
               "solver_raw_result": _json_safe(wb), "integral_record": response["integral_record"] if response else None}
        controls.append(row)
        if slot == 0:
            initial_fact = pre
            if pre is not None: checkpoints.append(dict(pre, checkpoint_index=0, checkpoint_target_s=0.))
        if not numerical_ok:
            finite = False; failure = {"reason": "NONFINITE_STATE_AFTER_COMMAND_FORWARD", "slot": slot, "physics_step": steps}
            row["post_control_state"] = state_values(model, data)
            break
        if source == "BACKUP" and not valid:
            failure = {"reason": "INVALID_BACKUP_QP", "slot": slot, "physics_step": steps,
                       "solver_status": wb.get("status"), "solver_status_val": wb.get("status_val")}
            row["post_control_state"] = state_values(model, data)
            break
        for _ in range(PHYSICS_STEPS_PER_SLOT):
            if step_observer is not None: step_observer()
            t = perf_counter(); mujoco.mj_step(model, data); steps += 1
            integration_s += perf_counter() - t
            if not _finite_state(data) or abs(float(data.time) - steps * PHYSICS_DT_S) > 1e-9:
                finite = False; failure = {"reason": "NONFINITE_STATE_OR_SIMULATOR_RESET_AFTER_STEP", "slot": slot, "physics_step": steps}
                physics.append({"time_s": steps * PHYSICS_DT_S, "physics_step": steps,
                                "numerical_failure": failure, "state": state_values(model, data)})
                break
            t = perf_counter(); mujoco.mj_forward(model, data); refresh += 1
            integration_s += perf_counter() - t
            if not _finite_state(data):
                finite = False; failure = {"reason": "NONFINITE_STATE_AFTER_INTEGRATION_REFRESH", "slot": slot, "physics_step": steps}
                physics.append({"time_s": steps * PHYSICS_DT_S, "physics_step": steps,
                                "numerical_failure": failure, "state": state_values(model, data)})
                break
            t = perf_counter()
            fact = _facts(model, data, health, limits, tau, action, ms, steps, slot, backup_id, branch_id)
            fact_s += perf_counter() - t; physics.append(fact)
            if steps in CHECKPOINT_STEPS:
                checkpoints.append(dict(fact, checkpoint_index=len(checkpoints), checkpoint_target_s=steps * PHYSICS_DT_S))
        row["post_control_state"] = state_values(model, data)
        if failure: break
    screening_begin = perf_counter()
    grid = len(checkpoints) == len(CHECKPOINT_STEPS) and all(
        r["physics_step"] == step and abs(r["time_s"] - step * PHYSICS_DT_S) <= 1e-9
        for r, step in zip(checkpoints, CHECKPOINT_STEPS))
    checks = [predicted_physical_check(r) for r in checkpoints]
    terminal = predicted_terminal_check(checkpoints[-1], anchor_q_init) if grid else {"pass": False, "reason": "INCOMPLETE_CHECKPOINT_GRID"}
    complete = steps == PHYSICS_STEPS and len(controls) == CONTROL_SLOTS and failure is None
    screen = {"pass": bool(complete and grid and all_valid and finite and all(x["pass"] for x in checks) and terminal["pass"]),
              "grid_valid": grid, "checkpoint_checks": checks, "all_backup_commands_valid": all_valid,
              "finite": finite, "terminal": terminal, "checkpoint_count": len(checkpoints),
              "semantics": "21-point sampled physical and fixed-anchor terminal acceptance; no continuous certificate"}
    screening_ms = (perf_counter() - screening_begin) * 1000
    return _json_safe({"schema": "STEP23_BRANCH_V1", "status": "COMPLETE" if complete else "FAILED_NUMERICAL",
        "reason": failure, "kind": kind, "branch_id": branch_id, "first_mode": first_mode,
        "backup_id": backup_id, "backup_version": HOLD_VERSION, "fixed_anchor_q_init": policy.anchor_q_init.tolist(),
        "health_vector": health.tolist(), "initialization_ms": initialization_ms,
        "first_backup_decision_ms": first_backup_decision_ms, "elapsed_ms": (perf_counter()-begin)*1000,
        "initial_state": initial_state, "initial_fact": initial_fact, "controls": controls,
        "physics_trajectory": physics, "checkpoints": checkpoints, "final_state": state_values(model, data),
        "solver_ledger": solver_ledger, "sampled_screen": screen,
        "counts": {"physical_steps": steps, "backup_qp_calls": len(solver_ledger), "control_qp_calls": len(solver_ledger),
            "clone_data_calls": 1, "backup_controller_instances": 1,
            "action_conditioned_forward_calls": action_forward, "integration_refresh_forward_calls": refresh,
            "contact_linearization_calls": policy.controller.contact_linearization_calls,
            "svd_calls": policy.controller.svd_calls, "passive_model_calls": policy.controller.passive_model_calls,
            "integral_updates": policy.servo.integral_update_calls},
        "timing": {"action_conditioned_forward_s": action_forward_s, "integration_and_refresh_s": integration_s,
                   "physical_fact_extraction_s": fact_s, "sampled_screen_ms": screening_ms}})


def preview_candidate(model, current_data, health, candidate_tau, backup_id, branch_id, step_observer=None):
    """One independent 20 ms candidate preview; only endpoint is screened."""
    begin = perf_counter(); data = clone_data(model, current_data); data.time = 0.
    health = np.asarray(health, dtype=float).copy()
    tau = np.asarray(candidate_tau, dtype=float).copy()
    limits = extract_healthy_torque_limits(model)
    if tau.shape != (int(model.nu),) or not np.isfinite(tau).all():
        raise ValueError("one-step preview requires an already valid candidate command")
    initial = state_values(model, data)
    initialization_ms = (perf_counter() - begin)*1000
    data.ctrl[:] = tau; mujoco.mj_forward(model, data)
    action_forward = 1; refresh = 0; steps = 0; rows = []; failure = None
    if not _finite_state(data): failure = {"reason": "NONFINITE_AFTER_CANDIDATE_FORWARD", "physics_step": 0}
    if failure is None:
        for _ in range(PREVIEW_STEPS):
            if step_observer is not None: step_observer()
            mujoco.mj_step(model, data); steps += 1
            if not _finite_state(data) or abs(float(data.time)-steps*PHYSICS_DT_S) > 1e-9:
                failure = {"reason": "NONFINITE_OR_SIMULATOR_RESET_AFTER_PREVIEW_STEP", "physics_step": steps}
                rows.append({"time_s": steps*PHYSICS_DT_S, "physics_step": steps,
                             "numerical_failure": failure, "state": state_values(model, data)})
                break
            mujoco.mj_forward(model, data); refresh += 1
            if not _finite_state(data):
                failure = {"reason": "NONFINITE_AFTER_PREVIEW_REFRESH", "physics_step": steps}
                rows.append({"time_s": steps*PHYSICS_DT_S, "physics_step": steps,
                             "numerical_failure": failure, "state": state_values(model, data)})
                break
            rows.append(_facts(model, data, health, limits, tau, 0., 0., steps, 0, backup_id, branch_id))
    check = predicted_physical_check(rows[-1]) if steps == PREVIEW_STEPS and failure is None else {
        "pass": False, "failure_reasons": ["INCOMPLETE_OR_NONFINITE_PREVIEW"]}
    return _json_safe({"schema": "STEP23_ONE_STEP_PREVIEW_V1", "branch_id": branch_id, "backup_id": backup_id,
        "status": "COMPLETE" if steps == PREVIEW_STEPS and failure is None else "FAILED_NUMERICAL",
        "pass": check["pass"], "physical_check": check, "reason": failure,
        "initialization_ms": initialization_ms, "elapsed_ms": (perf_counter()-begin)*1000,
        "initial_state": initial, "final_state": state_values(model, data), "physics_trajectory": rows,
        "counts": {"physical_steps": steps, "backup_qp_calls": 0, "control_qp_calls": 0,
                   "clone_data_calls": 1, "backup_controller_instances": 0,
                   "action_conditioned_forward_calls": action_forward, "integration_refresh_forward_calls": refresh},
        "screening_semantics": "candidate held exactly20ms; numeric endpoint physical check only"})


def specification() -> dict[str, Any]:
    return {"backup_version": HOLD_VERSION, "backup_reference": "case predecision current base pose, immutable for1s",
            "backup_policy": "S22_POSE_PID; zero independent initial integral; health known constant",
            "candidate_first_slot_s": CONTROL_DT_S, "backup_horizon_s": 1.,
            "physics_dt_s": PHYSICS_DT_S, "control_dt_s": CONTROL_DT_S,
            "physics_steps": PHYSICS_STEPS, "control_slots": CONTROL_SLOTS,
            "checkpoint_steps": list(CHECKPOINT_STEPS), "checkpoint_times_s": [s*PHYSICS_DT_S for s in CHECKPOINT_STEPS],
            "methods": list(METHODS), "terminal_anchor_x_error_abs_max_m": .002,
            "terminal_base_x_velocity_abs_max_m_s": .001,
            "original_terminal_angles_abs_max_rad": .20, "original_terminal_y_velocity_abs_max_m_s": .25,
            "physical": {"roll_pitch_abs_max_rad": .55, "subtree_com_height_range_m": [.16, .60],
                "base_x_velocity_abs_max_m_s": 2., "angular_velocity_norm_max_rad_s": 2.,
                "world_x_boundary_m": 1., "all_four_contacts": True, "normal_force_min_n": 0.,
                "friction_margin_min_n": 0., "torque_tolerance_nm": 0.},
            "prediction_screen_uses_cached_physical_labels": False,
            "deadline_miss": "record realtime failure and continue fixed offline pilot",
            "not_continuous_time_certificate": True, "single_decision_only": True}
