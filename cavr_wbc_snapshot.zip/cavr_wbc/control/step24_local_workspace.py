"""Pure STEP24 local-workspace queries over fixed STEP23 trajectories.

Local bounds never enter a controller or propagation call. Prediction decision
helpers accept prediction/current facts only; actual trajectories are consumed
solely by the post-decision excursion and interval analysis.
"""
from __future__ import annotations

from typing import Any, Mapping

import numpy as np

from cavr_wbc.control.step23_backup_filter import (
    CHECKPOINT_STEPS, CONTROL_SLOTS, METHODS, PHYSICS_DT_S, PHYSICS_STEPS,
    PREVIEW_STEPS, predicted_physical_check, predicted_terminal_check,
)


VARIANT = "STEP24_ADDITIONAL_LOCAL_WORKSPACE_V1"
GAPS_M = (.008, .002, .0008)
ANALYTIC_GAP_RANGE_M = (0., .008)


def with_local(row: Mapping[str, Any], upper: float) -> dict[str, Any]:
    """Add explicit local facts without replacing the original global margin."""
    value = float(upper)
    x = float(row["qpos"][0])
    if not np.isfinite([value, x]).all():
        raise ValueError("STEP24 local bound and base x must be finite")
    result = dict(row)
    result.update(global_boundary_margin_m=row["boundary_margin_m"],
                  local_workspace_upper_x_m=value, local_workspace_margin_m=value-x)
    return result


def _grid_valid(branch) -> bool:
    rows = branch.get("checkpoints", [])
    if len(rows) != len(CHECKPOINT_STEPS): return False
    try:
        return all(int(row["physics_step"]) == step and row["physics_step"] == step
                   and abs(float(row["time_s"])-step*PHYSICS_DT_S) <= 1e-9
                   for row, step in zip(rows, CHECKPOINT_STEPS))
    except (KeyError, TypeError, ValueError, OverflowError): return False


def _full_complete(branch) -> bool:
    if not isinstance(branch, Mapping): return False
    return bool(branch.get("status") == "COMPLETE"
                and branch.get("counts", {}).get("physical_steps") == PHYSICS_STEPS
                and len(branch.get("physics_trajectory", [])) == PHYSICS_STEPS
                and len(branch.get("controls", [])) == CONTROL_SLOTS
                and _grid_valid(branch))


def _preview_complete(preview) -> bool:
    if not isinstance(preview, Mapping): return False
    rows = preview.get("physics_trajectory", [])
    if (preview.get("status") != "COMPLETE"
            or preview.get("counts", {}).get("physical_steps") != PREVIEW_STEPS
            or len(rows) != PREVIEW_STEPS): return False
    try:
        return all(row["physics_step"] == i and abs(float(row["time_s"])-i*PHYSICS_DT_S) <= 1e-9
                   for i, row in enumerate(rows, 1))
    except (KeyError, TypeError, ValueError, OverflowError): return False


def _finite_state_row(row) -> bool:
    try:
        if not isinstance(row, Mapping): return False
        for key in ("qpos", "qvel"):
            values = np.asarray(row[key], dtype=float)
            if values.ndim != 1 or not values.size or not np.isfinite(values).all(): return False
        for key in ("act", "ctrl", "qacc_warmstart", "integration_state"):
            if key in row and not np.isfinite(np.asarray(row[key], dtype=float)).all(): return False
        return True
    except (KeyError, TypeError, ValueError, OverflowError): return False


def original_prediction_screen(branch: Mapping[str, Any], anchor) -> dict[str, Any]:
    """Recompute original STEP23 sampled acceptance, excluding all local facts."""
    if not isinstance(branch, Mapping) or not (branch.get("kind") == "PREDICTION"
            or str(branch.get("kind", "")).startswith("PREDICTION_")):
        raise ValueError("STEP24 prediction decisions may consume only PREDICTION branches")
    rows = branch.get("checkpoints", [])
    grid = _grid_valid(branch)
    complete = _full_complete(branch)
    controls = branch.get("controls", [])
    first = branch.get("first_mode")
    if first == "CANDIDATE":
        backup_controls = controls[1:]; expected_backup_slots = 49
    elif first == "BACKUP":
        backup_controls = controls; expected_backup_slots = 50
    else:
        backup_controls = []; expected_backup_slots = None
    valid = bool(expected_backup_slots is not None and len(backup_controls) == expected_backup_slots
                 and all(c.get("valid_command") is True for c in backup_controls))
    states = [branch.get("initial_state"), branch.get("final_state")] + list(branch.get("physics_trajectory", []))
    finite = bool(states and all(_finite_state_row(row) for row in states))
    checks = [predicted_physical_check(row) for row in rows]
    physical = bool(grid and all(check["pass"] for check in checks))
    terminal = predicted_terminal_check(rows[-1], anchor) if grid else {
        "pass": False, "reason": "INCOMPLETE_CHECKPOINT_GRID"}
    conditions = {"complete_500step_50slot_horizon": complete, "checkpoint_grid": grid,
                  "all_backup_commands_valid": valid, "finite": finite,
                  "original_physical_safe": physical, "original_terminal_pass": terminal["pass"]}
    return {"pass": bool(all(conditions.values())), "conditions": conditions,
            "reasons": [name for name, passed in conditions.items() if not passed],
            "checkpoint_checks": checks, "terminal": terminal,
            "checkpoint_count": len(rows), "expected_backup_slots": expected_backup_slots,
            "observed_backup_slots": len(backup_controls), "local_condition_included": False,
            "cached_screen_or_actual_labels_consumed": False}


def _local_prediction_screen(branch, original, upper):
    margins = []
    for row in branch.get("checkpoints", []):
        try: margins.append(with_local(row, upper)["local_workspace_margin_m"])
        except (KeyError, TypeError, ValueError, IndexError, OverflowError): margins.append(None)
    valid = bool(original["conditions"]["checkpoint_grid"]
                 and all(margin is not None and margin >= 0. for margin in margins))
    terminal_local = bool(original["conditions"]["checkpoint_grid"] and margins[-1] is not None and margins[-1] >= 0.)
    reasons = list(original["reasons"])
    if not valid: reasons.append("local_workspace_checkpoint_violation_or_incomplete_grid")
    if not terminal_local: reasons.append("local_workspace_terminal_violation_or_missing_endpoint")
    return {"pass": bool(original["pass"] and valid and terminal_local), "original": original,
            "local_workspace_safe": valid, "terminal_local_pass": terminal_local,
            "local_checkpoint_margins_m": margins,
            "observed_min_local_margin_m": min(m for m in margins if m is not None) if any(m is not None for m in margins) else None,
            "reasons": reasons}


def query_decisions(nominal, preview, pred_C, pred_B, anchor, x0: float, gap: float) -> dict[str, Any]:
    """Freeze one query using current input and predictions, without actuals."""
    x0, gap = float(x0), float(gap)
    if not np.isfinite([x0, gap]).all() or gap < 0.:
        raise ValueError("STEP24 query requires finite x0 and nonnegative gap")
    upper = x0 + gap
    command_valid = bool(nominal.get("command_valid"))
    current = nominal.get("initial_new_command_fact")
    current_check = predicted_physical_check(current) if isinstance(current, Mapping) else {
        "pass": False, "failure_reasons": ["MISSING_CURRENT_NEW_COMMAND_FACT"]}
    try: initial_local_margin = with_local(current, upper)["local_workspace_margin_m"]
    except (KeyError, TypeError, ValueError, IndexError, OverflowError): initial_local_margin = None
    qualified = bool(command_valid and current_check["pass"]
                     and initial_local_margin is not None and initial_local_margin >= 0.)
    base = {"variant": VARIANT, "x0": x0, "gap_m": gap, "local_upper": upper,
            "candidate_command_valid": command_valid, "current_check": current_check,
            "initial_local_margin_m": initial_local_margin}
    if not qualified:
        return {**base, "query_status": "NOT_RUN_INITIAL_UNQUALIFIED", "step_pass": False,
                "one_step_check": None, "C_screen": None, "B_screen": None,
                "method_decisions": {method: {"selected_mode": None,
                    "safety_label": "NOT_RUN_INITIAL_UNQUALIFIED"} for method in METHODS}}
    preview_complete = _preview_complete(preview)
    endpoint = preview["physics_trajectory"][-1] if preview_complete else None
    endpoint_check = predicted_physical_check(endpoint) if endpoint is not None else {
        "pass": False, "failure_reasons": ["INCOMPLETE_OR_INVALID_PREVIEW"]}
    try: endpoint_margin = with_local(endpoint, upper)["local_workspace_margin_m"]
    except (KeyError, TypeError, ValueError, IndexError, OverflowError): endpoint_margin = None
    step_pass = bool(preview_complete and endpoint_check["pass"]
                     and endpoint_margin is not None and endpoint_margin >= 0.)
    one_step = {"pass": step_pass, "preview_complete": preview_complete,
                "current_physical_check": current_check, "endpoint_physical_check": endpoint_check,
                "initial_local_margin_m": initial_local_margin, "endpoint_local_margin_m": endpoint_margin,
                "semantics": "original physics and local bound at current/20ms endpoint only"}
    C = _local_prediction_screen(pred_C, original_prediction_screen(pred_C, anchor), upper)
    B = _local_prediction_screen(pred_B, original_prediction_screen(pred_B, anchor), upper)
    mode = "C" if C["pass"] else "B"
    label = "SAMPLE_ACCEPTED" if C["pass"] else "IMMEDIATE_BACKUP_SCREENED" if B["pass"] else "BACKUP_NOT_SCREENED_SAFE"
    return {**base, "query_status": "QUALIFIED_QUERY_COMPLETED", "step_pass": step_pass,
            "one_step_check": one_step, "C_screen": C, "B_screen": B,
            "method_decisions": {
                METHODS[0]: {"selected_mode": "C", "safety_label": "QP_CANDIDATE_NO_LOOKAHEAD"},
                METHODS[1]: {"selected_mode": "C" if step_pass else "B",
                    "safety_label": "ONE_STEP_ACCEPTED" if step_pass else "BACKUP_WITHOUT_HORIZON_SCREEN"},
                METHODS[2]: {"selected_mode": mode, "safety_label": label,
                    "execution_mode": "BEST_EFFORT" if label == "BACKUP_NOT_SCREENED_SAFE" else "SCREENED_SELECTION"}},
            "decisions_use_actual_trajectory": False}


def _observed_peak(rows, x0):
    values = []
    missing = 0
    for row in rows:
        try:
            if not isinstance(row, Mapping): raise ValueError("missing row")
            numeric = row if "qpos" in row else row["state"]
            x = float(numeric["qpos"][0])
            if not np.isfinite(x): raise ValueError("nonfinite x")
            values.append(x)
        except (KeyError, TypeError, ValueError, IndexError, OverflowError): missing += 1
    return {"observed_peak_excursion_m": max(0., max(values)-x0) if values else None,
            "observed_numeric_rows": len(values), "missing_or_nonfinite_rows": missing,
            "scope": "observed prefix only; not a complete-horizon metric"}


def excursion_metrics(x0: float, preview, predC, predB, actualC, actualB) -> dict[str, Any]:
    """Compute frozen sample/global peaks after decisions; no new propagation."""
    x0 = float(x0)
    if not np.isfinite(x0): raise ValueError("STEP24 metric origin must be finite")
    metrics = {"x0_m": x0, "unit": "m", "d_step": None, "d_preview_full": None,
               "d_pred_C": None, "d_pred_B": None, "d_actual_C": None, "d_actual_B": None,
               "observed_prefix_diagnostics": {}, "complete": {}}
    preview_rows = preview.get("physics_trajectory", []) if isinstance(preview, Mapping) else []
    initial = preview.get("initial_state") if isinstance(preview, Mapping) else None
    endpoint_rows = [initial, preview_rows[-1]] if preview_rows else [initial]
    full_rows = [initial] + list(preview_rows)
    for key, rows in (("d_step", endpoint_rows), ("d_preview_full", full_rows)):
        observed = _observed_peak(rows, x0)
        complete = bool(_preview_complete(preview) and observed["missing_or_nonfinite_rows"] == 0)
        metrics["complete"][key] = complete
        metrics["observed_prefix_diagnostics"][key] = observed
        if complete: metrics[key] = observed["observed_peak_excursion_m"]
    for key, branch, sample in (("d_pred_C", predC, True), ("d_pred_B", predB, True),
                                ("d_actual_C", actualC, False), ("d_actual_B", actualB, False)):
        if isinstance(branch, Mapping):
            rows = list(branch.get("checkpoints", [])) if sample else [branch.get("initial_fact")]+list(branch.get("physics_trajectory", []))
        else: rows = []
        observed = _observed_peak(rows, x0)
        complete = bool(_full_complete(branch) and observed["missing_or_nonfinite_rows"] == 0)
        metrics["complete"][key] = complete
        metrics["observed_prefix_diagnostics"][key] = observed
        if complete: metrics[key] = observed["observed_peak_excursion_m"]
    return metrics


def mechanism_interval(metrics: Mapping[str, Any], eligibility: Mapping[str, Any]) -> dict[str, Any]:
    """Exact predeclared [lower, upper) intersection with closed [0,8mm]."""
    required = ("d_step", "d_pred_B", "d_actual_B", "d_pred_C", "d_actual_C")
    reasons = [str(key) for key, value in eligibility.items() if not bool(value)]
    if not eligibility: reasons.append("NO_ELIGIBILITY_FIELDS")
    values = {}
    for key in required:
        try:
            value = float(metrics[key])
            if not np.isfinite(value): raise ValueError("metric not finite")
            values[key] = value
        except (KeyError, TypeError, ValueError, OverflowError): reasons.append("INCOMPLETE_METRIC:"+key)
    base = {"range_m": list(ANALYTIC_GAP_RANGE_M), "eligibility": dict(eligibility),
            "endpoint_rule": "lower inclusive, raw upper excluded; closed8mm range cutoff included only if below raw upper",
            "comparison_epsilon_m": 0.}
    if reasons:
        return {**base, "status": "NOT_APPLICABLE", "reasons": reasons,
                "raw_interval": None, "intersection_interval": None, "width_m": None}
    lower = max(0., values["d_step"], values["d_pred_B"], values["d_actual_B"])
    upper = min(values["d_pred_C"], values["d_actual_C"])
    raw = {"lower_m": lower, "upper_m": upper, "lower_inclusive": True, "upper_inclusive": False}
    base.update(lower_m=lower, upper_open_m=upper, raw_bounds_m=[lower, upper])
    if not lower < upper:
        return {**base, "status": "EMPTY", "reasons": ["RAW_LOWER_NOT_BELOW_OPEN_UPPER"],
                "raw_interval": None, "intersection_interval": None, "width_m": 0.}
    lo, hi = max(lower, ANALYTIC_GAP_RANGE_M[0]), min(upper, ANALYTIC_GAP_RANGE_M[1])
    upper_inclusive = ANALYTIC_GAP_RANGE_M[1] < upper
    nonempty = lo < hi or (lo == hi and upper_inclusive)
    if not nonempty:
        return {**base, "status": "EMPTY", "reasons": ["NO_INTERSECTION_IN_PREDECLARED_GAP_RANGE"],
                "raw_interval": raw, "intersection_interval": None, "width_m": 0.}
    intersection = {"lower_m": lo, "upper_m": hi, "lower_inclusive": True,
                    "upper_inclusive": upper_inclusive, "is_singleton": lo == hi}
    return {**base, "status": "NONEMPTY", "reasons": [], "raw_interval": raw,
            "intersection_interval": intersection, "width_m": hi-lo}


def specification() -> dict[str, Any]:
    return {"variant": VARIANT, "fixed_gaps_m": list(GAPS_M), "analytic_gap_range_m": list(ANALYTIC_GAP_RANGE_M),
            "local_upper_definition": "x0 + gap", "local_margin_definition": "local_upper_x - base_x",
            "original_global_boundary_preserved": "boundary_margin_m = 1.0 - base_x",
            "local_bound_passed_to_controller": False, "query_selection_consumes_actual": False,
            "M1_screen": "current and20ms endpoint original numeric physical facts and local bound",
            "M2_screen": "21 numeric prediction checkpoints original physical andlocal + validbackup + finite + original terminal",
            "maximum_unique_actual_traces": 4, "method_result_rows_are_not_independent_executions": True,
            "excursions": {"d_step": "initial and20ms endpoint", "d_preview_full": "initial andall10preview steps",
                "d_pred_C_B": "21 prediction checkpoints", "d_actual_C_B": "initial andall500actual steps"},
            "incomplete_excursion": "canonical metric None; explicitly labeled observed-prefix diagnostic",
            "interval_lower": "max(0,d_step,d_pred_B,d_actual_B)",
            "interval_upper_open": "min(d_pred_C,d_actual_C)",
            "interval_eligibility": "current/step original qualified; predictions/actuals complete valid originalphysics/originalterminal; local excluded",
            "comparison_epsilon_m": 0., "no_new_physics_or_QP_for_interval_analysis": True}
