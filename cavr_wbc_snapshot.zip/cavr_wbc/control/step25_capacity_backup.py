"""STEP25 opt-in actuator capacity interface and fresh feedback branches.

The original STEP22 solve, validation and PID update order remain untouched.
The declared executable view supplies a clipped actuator command to that same
PID authority gate. Raw QP variables and execution diagnostics are separate.
"""
from __future__ import annotations

from copy import deepcopy
from time import perf_counter
from typing import Any, Mapping

import mujoco
import numpy as np

from cavr_wbc.control.step22_pose_servo import (
    AUTHORITY_GATE_FRACTION, BasePoseServo, CONTROL_DT_S, INTEGRAL_LIMITS, Step22WBC,
)
from cavr_wbc.control.step23_backup_filter import (
    CHECKPOINT_STEPS, CONTROL_SLOTS, HOLD_VERSION, PHYSICS_DT_S, PHYSICS_STEPS,
    PHYSICS_STEPS_PER_SLOT, PREVIEW_STEPS, _facts, _finite_state, _json_safe,
    clone_data, predicted_physical_check, predicted_terminal_check,
    slot_action_sources, state_values,
)
from cavr_wbc.platforms.go2_mujoco import extract_healthy_torque_limits


CAPACITY_VERSION = "STEP25_ACTUATOR_CAPACITY_SATURATION_V1"
VARIANT = "STEP25_DENSE_DISCRETE_SCREEN_WITH_CAPACITY_INTERFACE_V1"
AXIS_NAMES = ("base_x", "base_y", "base_z", "base_roll", "base_pitch", "base_yaw")
ACCEL_UNITS = ("m/s^2",) * 3 + ("rad/s^2",) * 3


def _health_limits(health_vector, healthy_limits):
    health = np.asarray(health_vector, dtype=float)
    healthy = np.asarray(healthy_limits, dtype=float)
    if (health.ndim != 1 or not health.size or healthy.shape != health.shape
            or not np.isfinite(health).all() or not np.isfinite(healthy).all()
            or np.any((health < 0.) | (health > 1.)) or np.any(healthy < 0.)):
        raise ValueError("STEP25 requires finite full per-channel health and healthy limits")
    return health.copy(), healthy.copy(), health * healthy


def capacity_command(raw_tau, health_vector, healthy_limits, status_val):
    """Pure declared output layer; only exact Solved finite vectors may clip.

    Invalid candidates receive no executable command. The zero ``tau_sent``
    field is an explicit diagnostic fallback, not a rescued solver result.
    """
    begin = perf_counter()
    health, healthy, limits = _health_limits(health_vector, healthy_limits)
    try:
        raw = np.asarray(raw_tau, dtype=float)
        finite_shape = raw.shape == limits.shape and bool(np.isfinite(raw).all())
    except (TypeError, ValueError):
        raw = None
        finite_shape = False
    solved = status_val == 1 and not isinstance(status_val, (bool, np.bool_))
    valid = bool(solved and finite_shape)
    raw_margin = limits - np.abs(raw) if finite_shape else None
    sent = np.clip(raw, -limits, limits) if valid else np.zeros_like(limits)
    correction = sent - raw if valid else None
    saturated = (sent != raw) if valid else np.zeros_like(limits, dtype=bool)
    raw_gate = (limits <= 0.) | (np.abs(raw) >= AUTHORITY_GATE_FRACTION * limits) if valid else None
    sent_gate = (limits <= 0.) | (np.abs(sent) >= AUTHORITY_GATE_FRACTION * limits) if valid else None
    result = {
        "version": CAPACITY_VERSION, "solver_status_val": status_val,
        "solver_exact_solved": bool(solved), "raw_tau_finite_correct_shape": finite_shape,
        "command_valid": valid, "health_vector": health.tolist(),
        "healthy_torque_limits_nm": healthy.tolist(), "effective_capacity_nm": limits.tolist(),
        "tau_raw": _json_safe(raw) if raw is not None else None, "tau_sent": sent.tolist(),
        "saturation_mask": saturated.tolist(), "saturated_actuator_indices": np.flatnonzero(saturated).tolist(),
        "correction_nm": correction.tolist() if correction is not None else None,
        "raw_command_bound_margin_nm": raw_margin.tolist() if raw_margin is not None else None,
        "raw_command_bound_violation_nm": np.maximum(-raw_margin, 0.).tolist() if raw_margin is not None else None,
        "raw_command_within_capacity_exact": bool(np.all(raw_margin >= 0.)) if raw_margin is not None else False,
        "sent_command_bound_margin_nm": (limits - np.abs(sent)).tolist() if valid else None,
        "sent_command_within_capacity_exact": bool(valid and np.all(limits - np.abs(sent) >= 0.)),
        "raw_99_percent_active_indices": np.flatnonzero(raw_gate).tolist() if valid else [],
        "sent_99_percent_active_indices": np.flatnonzero(sent_gate).tolist() if valid else [],
        "raw_exact_active_indices": np.flatnonzero(np.abs(raw) >= limits).tolist() if valid else [],
        "sent_exact_active_indices": np.flatnonzero(np.abs(sent) >= limits).tolist() if valid else [],
        "raw_sent_99_percent_gate_equal": bool(np.array_equal(raw_gate, sent_gate)) if valid else None,
        "invalid_reason": None if valid else "SOLVER_NOT_EXACT_SOLVED" if not solved else "NONFINITE_OR_MALFORMED_TAU",
        "raw_solution_and_validation_not_modified": True, "invalid_command_zero_is_diagnostic_only": not valid,
    }
    result["capacity_interface_ms"] = (perf_counter() - begin) * 1000.
    return result


def execution_diagnostics(raw_wb, assembly, tau_sent, a_base_ref):
    """Raw QP task error and algebraic residual with sent torque, by units."""
    result = {"version": "STEP25_RAW_QP_VERSUS_SENT_EXECUTION_DIAGNOSTICS_V1",
              "raw_qdd_is_actual_acceleration": False,
              "sent_dynamics_residual_definition": "M @ raw_qdd + bias_eff - B @ tau_sent - Jc.T @ raw_lambda",
              "axis_names": list(AXIS_NAMES), "acceleration_units": list(ACCEL_UNITS)}
    try:
        qdd = np.asarray(raw_wb["qdd"], dtype=float)
        lam = np.asarray(raw_wb["contact_force"], dtype=float)
        sent = np.asarray(tau_sent, dtype=float)
        matrix = np.asarray(assembly["M"], dtype=float)
        bias = np.asarray(assembly["bias_eff"], dtype=float)
        actuation = np.asarray(assembly["B"], dtype=float)
        contacts = np.asarray(assembly["Jc"], dtype=float)
        residual = matrix @ qdd + bias - actuation @ sent - contacts.T @ lam
        target = np.asarray(a_base_ref, dtype=float)
        raw_base = qdd[:6]
        if target.shape != (6,) or raw_base.shape != (6,) or not np.isfinite(residual).all():
            raise ValueError("missing finite six-axis QP diagnostic")
        result.update(raw_qdd=qdd.tolist(), raw_contact_lambda=lam.tolist(),
                      raw_qp_base_acceleration=raw_base.tolist(), target_base_acceleration=target.tolist(),
                      raw_qp_base_acceleration_error=(raw_base - target).tolist(),
                      task_axis_records=[{"axis": name, "unit": unit, "target": float(t),
                                          "raw_qp_achieved": float(a), "raw_qp_error": float(a-t)}
                                         for name, unit, t, a in zip(AXIS_NAMES, ACCEL_UNITS, target, raw_base)],
                      sent_dynamics_residual_signed=residual.tolist(),
                      sent_dynamics_residual_inf=float(np.max(np.abs(residual))), available=True)
    except (KeyError, TypeError, ValueError, IndexError) as exc:
        result.update(available=False, reason=str(exc))
    return result


class _ExecutableController:
    """Per-call adapter; no global monkeypatch or changes to raw controller."""
    def __init__(self, controller):
        self.controller = controller
        self._healthy_limits = controller._healthy_limits
        self._health = controller._health
        self.raw_wb = None
        self.interface = None
        self.raw_variables = None

    def compute(self, data, method, health, target):
        original = self.controller.compute(data, method, health, target)
        self.raw_wb = deepcopy(original)
        self.raw_variables = {key: deepcopy(original.get(key)) for key in ("tau", "qdd", "contact_force")}
        self.raw_variables["source"] = "ORIGINAL_DECODED_RAW_QP"
        # Configurable historical V1 may clear decoded fields after validation.
        # Keep that result immutable; expose saved exact raw variables separately.
        snapshot = getattr(self.controller, "last_stage1_snapshot", None)
        if original.get("status_val") == 1 and self.raw_variables["tau"] is None and snapshot:
            saved = np.asarray(snapshot.get("x"), dtype=float)
            nv, nu = int(self.controller.model.nv), len(self._healthy_limits)
            if saved.shape == (nv + nu + 12,) and np.isfinite(saved).all():
                self.raw_variables.update(qdd=saved[:nv].copy(), tau=saved[nv:nv+nu].copy(),
                                          contact_force=saved[nv+nu:].copy(), source="IMMUTABLE_STAGE1_RAW_SNAPSHOT")
        self.interface = capacity_command(self.raw_variables.get("tau"), health, self._healthy_limits,
                                          original.get("status_val"))
        # Exact Solved finite full raw variables are required independently of
        # the original raw validation label. STEP22 defaults already do this.
        for key, shape in (("qdd", (int(self.controller.model.nv),)),
                           ("contact_force", (12,))):
            values = np.asarray(self.raw_variables.get(key), dtype=float)
            if values.shape != shape or not np.isfinite(values).all():
                self.interface.update(command_valid=False, invalid_reason="NONFINITE_OR_MALFORMED_RAW_QP_VARIABLES",
                                      sent_command_within_capacity_exact=False)
                self.interface["tau_sent"] = np.zeros_like(self._healthy_limits).tolist()
        executable = deepcopy(original)
        executable["success"] = self.interface["command_valid"]
        executable["tau"] = np.asarray(self.interface["tau_sent"], dtype=float) if executable["success"] else None
        return executable


class CapacityPoseServo(BasePoseServo):
    """Original six-axis PID with a separate declared executable command view."""
    def compute(self, controller, data, health, tick):
        begin = perf_counter()
        adapter = _ExecutableController(controller)
        response = super().compute(adapter, data, health, tick)
        raw_wb = adapter.raw_wb if adapter.raw_wb is not None else deepcopy(response["wbc"])
        interface = adapter.interface if adapter.interface is not None else capacity_command(
            raw_wb.get("tau"), health, controller._healthy_limits, raw_wb.get("status_val"))
        response["wbc"] = raw_wb
        response["wb"] = raw_wb
        response["raw_solver_result"] = raw_wb
        response["capacity_interface"] = interface
        response["raw_solver_variables"] = adapter.raw_variables
        response["raw_QP_success"] = bool(raw_wb.get("success"))
        response["raw_QP_bound_exact_pass"] = interface["raw_command_within_capacity_exact"]
        response["execution_view"] = {"command_valid": bool(response["valid_command"]),
                                      "tau_sent": response["tau_cmd"], "version": CAPACITY_VERSION}
        response["execution_diagnostics"] = execution_diagnostics(
            adapter.raw_variables or raw_wb, controller.last_trace, response["tau_cmd"], response["a_base_ref"])
        record = response["integral_record"]
        record.update(raw_authority_gate_saturated_actuators=interface["raw_99_percent_active_indices"],
                      sent_authority_gate_saturated_actuators=interface["sent_99_percent_active_indices"],
                      raw_sent_authority_gate_equal=interface["raw_sent_99_percent_gate_equal"],
                      capacity_interface_version=CAPACITY_VERSION,
                      six_axis_updated=[bool(record["updated"])] * 6,
                      six_axis_frozen=[not bool(record["updated"])] * 6,
                      six_axis_freeze_reasons=[record["freeze_reason"]] * 6)
        if response["e_pose"] is not None:
            proposed = np.asarray(record["b_before"]) + CONTROL_DT_S * self.gains["ki_s_inv3"] * np.asarray(response["e_pose"])
            record["proposed_unclipped_b_after"] = proposed.tolist()
            record["six_axis_clipped"] = (bool(record["updated"]) & (np.abs(proposed) > INTEGRAL_LIMITS)).tolist()
        else:
            record["proposed_unclipped_b_after"] = None
            record["six_axis_clipped"] = [False] * 6
        response["latency_ms"] = (perf_counter() - begin) * 1000.
        return response


class CapacityHoldBackup:
    def __init__(self, model, anchor_q_init, backup_id, solve_callback=None):
        if not isinstance(backup_id, str) or not backup_id:
            raise ValueError("STEP25 requires a nonempty immutable backup ID")
        self._backup_id = backup_id
        self._anchor_q_init = np.asarray(anchor_q_init, dtype=float).copy()
        self._anchor_q_init.flags.writeable = False
        self.controller = Step22WBC(model, solve_callback=solve_callback)
        self.servo = CapacityPoseServo(model, self._anchor_q_init, 0., "S22_POSE_PID")

    @property
    def backup_id(self): return self._backup_id

    @property
    def anchor_q_init(self):
        result = self._anchor_q_init.copy()
        result.flags.writeable = False
        return result

    def compute(self, data, health, slot):
        response = self.servo.compute(self.controller, data, health, slot)
        response.update(backup_id=self.backup_id, backup_version=HOLD_VERSION,
                        fixed_anchor_q_init=self._anchor_q_init.tolist())
        return response


def _metadata(record, health):
    result = {"health_vector": np.asarray(health).tolist()}
    for name in ("context_id", "faulted_actuator_name", "faulted_actuator_index", "faulted_health",
                 "legacy_FR_thigh_scalar"):
        if name in record: result[name] = record[name]
    return result


def _capacity_fact(model, data, health, limits, tau, action, ms, step, slot, bid, branch_id, interface, metadata):
    row = _facts(model, data, health, limits, tau, action, ms, step, slot, bid, branch_id)
    if "health" in row: row["legacy_FR_thigh_scalar"] = row.pop("health")
    if "active_health" in row: row["legacy_active_health_FR_thigh_scalar"] = row.pop("active_health")
    row.update(global_boundary_margin_m=row["boundary_margin_m"], tau_raw=deepcopy(interface["tau_raw"]),
               tau_sent=np.asarray(tau).tolist(), capacity_interface_version=CAPACITY_VERSION,
               effective_capacity_nm=deepcopy(interface["effective_capacity_nm"]),
               saturation_mask=deepcopy(interface["saturation_mask"]),
               capacity_correction_nm=deepcopy(interface["correction_nm"]),
               raw_command_bound_margin_nm=deepcopy(interface["raw_command_bound_margin_nm"]),
               sent_command_bound_margin_nm=deepcopy(interface["sent_command_bound_margin_nm"]),
               applied_command_bound_margin_nm=(np.asarray(interface["effective_capacity_nm"]) - np.abs(data.actuator_force)).tolist(),
               raw_QP_bound_exact_pass=interface["raw_command_within_capacity_exact"],
               sent_command_exact_pass=interface["sent_command_within_capacity_exact"],
               actual_mujoco_qacc=data.qacc.copy().tolist(), raw_qdd_is_actual_acceleration=False,
               **metadata)
    return row


def _ledger_wall_s(ledger):
    return float(sum(float(row.get("solve_wall_time_s") or 0.) for row in ledger))


def nominal(model, current, context, solve_callback=None):
    """One new nominal QP using the full capacity vector and source reference."""
    begin = perf_counter()
    data = clone_data(model, current)
    limits = extract_healthy_torque_limits(model)
    health, _, _ = _health_limits(context["health_vector"], limits)
    if health.shape != (int(model.nu),): raise ValueError("STEP25 health shape differs from model.nu")
    controller = Step22WBC(model, solve_callback=solve_callback)
    servo = CapacityPoseServo(model, context["nominal_q_init"], .01, "S22_POSE_PID")
    servo.b_integral[:] = context["nominal_b_used"]
    response = servo.compute(controller, data, health, context["source_tick"])
    raw_wb = response.pop("wbc")
    response.pop("wb", None)
    response.pop("raw_solver_result", None)
    interface = response["capacity_interface"]
    tau = np.asarray(response["tau_cmd"], dtype=float)
    data.ctrl[:] = tau
    forward_start = perf_counter()
    mujoco.mj_forward(model, data)
    forward_s = perf_counter() - forward_start
    fact_start = perf_counter()
    metadata = _metadata(context, health)
    fact = _capacity_fact(model, data, health, limits, tau,
                          float(response["a_base_ref"][0]) if response["a_base_ref"] else 0.,
                          response["latency_ms"], 0, 0, context["backup_id"],
                          context["context_id"], interface, metadata)
    fact_s = perf_counter() - fact_start
    physical = predicted_physical_check(fact)
    return _json_safe({"schema": "STEP25_NOMINAL_CAPACITY_CANDIDATE_V1", "variant": VARIANT,
        **metadata, "command_valid": bool(response["valid_command"]), "tau": tau.tolist(),
        "tau_raw": interface["tau_raw"], "tau_sent": tau.tolist(), "capacity_interface": interface,
        "generation_ms": (perf_counter() - begin) * 1000., "response": response,
        "raw_solver_result": raw_wb, "solver_status": raw_wb.get("status"), "solver_status_val": raw_wb.get("status_val"),
        "raw_solver_variables": response["raw_solver_variables"],
        "qdd": raw_wb.get("qdd"), "contact_lambda": raw_wb.get("contact_force"),
        "QP_validation": raw_wb.get("validation"), "raw_QP_success": bool(raw_wb.get("success")),
        "raw_QP_bound_exact_pass": interface["raw_command_within_capacity_exact"],
        "sent_command_exact_pass": interface["sent_command_within_capacity_exact"],
        "assembly": controller.last_trace, "solver_ledger": controller.solver_ledger,
        "execution_diagnostics": response["execution_diagnostics"],
        "initial_new_command_fact": fact, "current_physical_check": physical,
        "source_b_used": context["nominal_b_used"], "backup_initial_b": [0.] * 6,
        "counts": {"nominal_qp_calls": len(controller.solver_ledger), "clone_data_calls": 1,
                   "nominal_controller_instances": 1, "nominal_command_diagnostic_forward_calls": 1,
                   "contact_linearization_calls": controller.contact_linearization_calls,
                   "svd_calls": controller.svd_calls, "passive_model_calls": controller.passive_model_calls},
        "timing": {"control_total_ms": response["latency_ms"], "solver_wall_s": _ledger_wall_s(controller.solver_ledger),
                   "action_conditioned_forward_s": forward_s, "physical_fact_extraction_s": fact_s,
                   "capacity_interface_ms": interface["capacity_interface_ms"],
                   "timing_overlap_note": "control includes QP and capacity interface; generation includes clone, diagnostics, forward and facts"}})


def _candidate_interface(candidate_record, health, limits):
    if not isinstance(candidate_record, Mapping) or not candidate_record.get("command_valid"):
        raise ValueError("STEP25 candidate must be an already valid nominal record")
    interface = capacity_command(candidate_record["tau_raw"], health, limits, candidate_record["solver_status_val"])
    if not interface["command_valid"] or not np.array_equal(interface["tau_sent"], candidate_record["tau"]):
        raise ValueError("candidate sent command does not match the shared capacity interface")
    if not np.array_equal(candidate_record["health_vector"], health):
        raise ValueError("candidate health differs from branch full health vector")
    return interface


def run_branch(model, current, health, anchor, bid, first_mode, candidate_record, kind, branch_id,
               solve_callback=None, step_observer=None):
    """One independent complete-state branch with 49/50 fresh backup QPs."""
    if kind not in ("PREDICTION_C", "PREDICTION_B", "ACTUAL_C", "ACTUAL_B"):
        raise ValueError("STEP25 requires an explicit prediction/actual C/B kind")
    begin = perf_counter()
    sources = slot_action_sources(first_mode)
    data = clone_data(model, current)
    data.time = 0.
    limits = extract_healthy_torque_limits(model)
    health, _, _ = _health_limits(health, limits)
    if health.shape != (int(model.nu),): raise ValueError("STEP25 branch health shape differs from model.nu")
    candidate_interface = _candidate_interface(candidate_record, health, limits) if first_mode == "CANDIDATE" else None
    policy = CapacityHoldBackup(model, anchor, bid, solve_callback=solve_callback)
    metadata = _metadata(candidate_record, health)
    initial_state = state_values(model, data)
    initialization_ms = (perf_counter() - begin) * 1000.
    controls = []; physics = []; checkpoints = []; solver_ledger = []
    steps = 0; action_forward = 0; refresh = 0; cursor = 0
    all_valid = True; finite = True; failure = None; initial_fact = None
    first_backup_decision_ms = 0.
    integration_s = 0.; refresh_s = 0.; action_forward_s = 0.; fact_s = 0.; control_ms = 0.
    capacity_ms = candidate_interface["capacity_interface_ms"] if candidate_interface else 0.
    for slot, source in enumerate(sources):
        if not _finite_state(data):
            finite = False; failure = {"reason": "NONFINITE_STATE_BEFORE_CONTROL", "slot": slot, "physics_step": steps}
            break
        response = None; raw_wb = None; assembly = None
        before = state_values(model, data)
        if source == "BACKUP":
            response = policy.compute(data, health, slot)
            raw_wb = response.pop("wbc"); response.pop("wb", None); response.pop("raw_solver_result", None)
            interface = response["capacity_interface"]
            tau = np.asarray(response["tau_cmd"], dtype=float)
            valid = bool(response["valid_command"])
            all_valid = all_valid and valid
            ms = float(response["latency_ms"]); control_ms += ms
            action = float(response["a_base_ref"][0]) if response["a_base_ref"] else 0.
            if slot == 0: first_backup_decision_ms = ms
            capacity_ms += interface["capacity_interface_ms"]
            assembly = deepcopy(policy.controller.last_trace)
            diagnostics = response["execution_diagnostics"]
            for entry in policy.controller.solver_ledger[cursor:]:
                solver_ledger.append(dict(entry, branch_id=branch_id, kind=kind, backup_id=bid,
                                          slot=slot, time_s=slot * CONTROL_DT_S))
            cursor = len(policy.controller.solver_ledger)
            source_label = "FEEDBACK_BACKUP_QP_TOTAL" if valid else "INVALID_BACKUP_QP_ZERO_COMMAND_FOR_INITIAL_FACT"
        elif source == "CANDIDATE":
            interface = deepcopy(candidate_interface)
            tau = np.asarray(interface["tau_sent"], dtype=float)
            valid = True; ms = 0.; action = 0.
            raw_wb = deepcopy(candidate_record["raw_solver_result"])
            assembly = deepcopy(candidate_record["assembly"])
            diagnostics = deepcopy(candidate_record["execution_diagnostics"])
            source_label = "FIXED_CANDIDATE_TAU_20MS"
        else:
            interface = capacity_command(np.zeros(model.nu), health, limits, 1)
            tau = np.asarray(interface["tau_sent"]); valid = True; ms = 0.; action = 0.
            diagnostics = {"available": False, "reason": "ZERO_FALLBACK_NO_QP"}
            source_label = "ZERO_COMMAND_FALLBACK_CURRENT_CANDIDATE_INVALID"
        data.ctrl[:] = tau
        t = perf_counter(); mujoco.mj_forward(model, data); action_forward += 1
        action_forward_s += perf_counter() - t
        numerical_ok = _finite_state(data)
        pre = None
        if numerical_ok:
            t = perf_counter()
            pre = _capacity_fact(model, data, health, limits, tau, action, ms, steps, slot,
                                 bid, branch_id, interface, metadata)
            fact_s += perf_counter() - t
        row = {"slot": slot, "time_s": slot * CONTROL_DT_S, "first_mode": first_mode,
               "action_source": source_label, "backup_id": bid, "backup_version": HOLD_VERSION,
               "pre_control_state": before, "tau_total": tau.tolist(), "tau_cmd": tau.tolist(),
               "tau_raw": interface["tau_raw"], "tau_sent": tau.tolist(),
               "tau_applied": data.actuator_force.copy().tolist(), **metadata,
               "valid_command": valid, "latency_ms": ms, "physical_at_decision": pre,
               "servo_response": response, "assembly": assembly, "solver_raw_result": _json_safe(raw_wb),
               "capacity_interface": interface, "execution_diagnostics": diagnostics,
               "actual_mujoco_qacc": data.qacc.copy().tolist(),
               "integral_record": response["integral_record"] if response else None}
        controls.append(row)
        if slot == 0:
            initial_fact = pre
            if pre is not None: checkpoints.append(dict(pre, checkpoint_index=0, checkpoint_target_s=0.))
        if not numerical_ok:
            finite = False; failure = {"reason": "NONFINITE_STATE_AFTER_COMMAND_FORWARD", "slot": slot, "physics_step": steps}
        elif not valid:
            failure = {"reason": "INVALID_BACKUP_QP" if source == "BACKUP" else "INVALID_CANDIDATE_COMMAND",
                       "slot": slot, "physics_step": steps,
                       "solver_status": (raw_wb or {}).get("status"), "solver_status_val": (raw_wb or {}).get("status_val")}
        if failure:
            row["post_control_state"] = state_values(model, data)
            break
        for _ in range(PHYSICS_STEPS_PER_SLOT):
            if step_observer is not None: step_observer()
            t = perf_counter(); mujoco.mj_step(model, data); steps += 1
            integration_s += perf_counter() - t
            if not _finite_state(data) or abs(float(data.time) - steps * PHYSICS_DT_S) > 1e-9:
                finite = False; failure = {"reason": "NONFINITE_STATE_OR_SIMULATOR_RESET_AFTER_STEP", "slot": slot, "physics_step": steps}
                physics.append({"time_s": steps * PHYSICS_DT_S, "physics_step": steps,
                                "numerical_failure": failure, "state": state_values(model, data)})
                break
            t = perf_counter(); mujoco.mj_forward(model, data); refresh += 1
            refresh_s += perf_counter() - t
            if not _finite_state(data):
                finite = False; failure = {"reason": "NONFINITE_STATE_AFTER_INTEGRATION_REFRESH", "slot": slot, "physics_step": steps}
                physics.append({"time_s": steps * PHYSICS_DT_S, "physics_step": steps,
                                "numerical_failure": failure, "state": state_values(model, data)})
                break
            t = perf_counter()
            fact = _capacity_fact(model, data, health, limits, tau, action, ms, steps, slot,
                                  bid, branch_id, interface, metadata)
            fact_s += perf_counter() - t
            physics.append(fact)
            if steps in CHECKPOINT_STEPS:
                checkpoints.append(dict(fact, checkpoint_index=len(checkpoints), checkpoint_target_s=steps * PHYSICS_DT_S))
        row["post_control_state"] = state_values(model, data)
        if failure: break
    screening_begin = perf_counter()
    grid = len(checkpoints) == len(CHECKPOINT_STEPS) and all(
        r["physics_step"] == step and abs(r["time_s"] - step * PHYSICS_DT_S) <= 1e-9
        for r, step in zip(checkpoints, CHECKPOINT_STEPS))
    checks = [predicted_physical_check(r) for r in checkpoints]
    terminal = predicted_terminal_check(checkpoints[-1], anchor) if grid else {"pass": False, "reason": "INCOMPLETE_CHECKPOINT_GRID"}
    complete = steps == PHYSICS_STEPS and len(controls) == CONTROL_SLOTS and failure is None
    screen = {"pass": bool(complete and grid and all_valid and finite and all(x["pass"] for x in checks) and terminal["pass"]),
              "grid_valid": grid, "checkpoint_checks": checks, "all_backup_commands_valid": all_valid,
              "finite": finite, "terminal": terminal, "checkpoint_count": len(checkpoints),
              "semantics": "historical21-point diagnostic; STEP25 dense decision screen is separate"}
    screening_ms = (perf_counter() - screening_begin) * 1000.
    return _json_safe({"schema": "STEP25_CAPACITY_BRANCH_V1", "variant": VARIANT,
        "status": "COMPLETE" if complete else "FAILED_NUMERICAL", "reason": failure,
        "kind": kind, "branch_id": branch_id, "first_mode": first_mode,
        "backup_id": bid, "backup_version": HOLD_VERSION, "capacity_interface_version": CAPACITY_VERSION,
        "fixed_anchor_q_init": policy.anchor_q_init.tolist(), **metadata,
        "initialization_ms": initialization_ms, "first_backup_decision_ms": first_backup_decision_ms,
        "elapsed_ms": (perf_counter() - begin) * 1000., "initial_state": initial_state,
        "initial_fact": initial_fact, "controls": controls, "physics_trajectory": physics,
        "checkpoints": checkpoints, "final_state": state_values(model, data),
        "solver_ledger": solver_ledger, "sampled_screen": screen,
        "counts": {"physical_steps": steps, "backup_qp_calls": len(solver_ledger), "control_qp_calls": len(solver_ledger),
                   "clone_data_calls": 1, "backup_controller_instances": 1,
                   "action_conditioned_forward_calls": action_forward, "integration_refresh_forward_calls": refresh,
                   "contact_linearization_calls": policy.controller.contact_linearization_calls,
                   "svd_calls": policy.controller.svd_calls, "passive_model_calls": policy.controller.passive_model_calls,
                   "integral_updates": policy.servo.integral_update_calls},
        "timing": {"control_total_ms": control_ms, "solver_wall_s": _ledger_wall_s(solver_ledger),
                   "action_conditioned_forward_s": action_forward_s, "integration_s": integration_s,
                   "integration_refresh_s": refresh_s, "integration_and_refresh_s": integration_s + refresh_s,
                   "physical_fact_extraction_s": fact_s, "capacity_interface_ms": capacity_ms,
                   "sampled_screen_ms": screening_ms,
                   "timing_overlap_note": "control includes QP, adapter, raw-copy and capacity costs; assembly/state serialization and JSON-safe conversion not independently timed"}})


def preview_candidate(model, current, health, candidate_record, bid, branch_id, step_observer=None):
    """One independent 20ms preview using exactly the shared sent command."""
    begin = perf_counter()
    data = clone_data(model, current); data.time = 0.
    limits = extract_healthy_torque_limits(model)
    health, _, _ = _health_limits(health, limits)
    if health.shape != (int(model.nu),): raise ValueError("STEP25 preview health shape differs from model.nu")
    interface = _candidate_interface(candidate_record, health, limits)
    metadata = _metadata(candidate_record, health)
    tau = np.asarray(interface["tau_sent"], dtype=float)
    initial = state_values(model, data)
    initialization_ms = (perf_counter() - begin) * 1000.
    t = perf_counter(); data.ctrl[:] = tau; mujoco.mj_forward(model, data)
    action_forward_s = perf_counter() - t
    action_forward = 1; refresh = 0; steps = 0; rows = []; failure = None
    integration_s = 0.; refresh_s = 0.; fact_s = 0.
    if not _finite_state(data): failure = {"reason": "NONFINITE_AFTER_CANDIDATE_FORWARD", "physics_step": 0}
    initial_fact = None
    if failure is None:
        t = perf_counter()
        initial_fact = _capacity_fact(model, data, health, limits, tau, 0., 0., 0, 0, bid, branch_id, interface, metadata)
        fact_s += perf_counter() - t
        for _ in range(PREVIEW_STEPS):
            if step_observer is not None: step_observer()
            t = perf_counter(); mujoco.mj_step(model, data); steps += 1
            integration_s += perf_counter() - t
            if not _finite_state(data) or abs(float(data.time) - steps * PHYSICS_DT_S) > 1e-9:
                failure = {"reason": "NONFINITE_OR_SIMULATOR_RESET_AFTER_PREVIEW_STEP", "physics_step": steps}
                rows.append({"time_s": steps * PHYSICS_DT_S, "physics_step": steps,
                             "numerical_failure": failure, "state": state_values(model, data)})
                break
            t = perf_counter(); mujoco.mj_forward(model, data); refresh += 1
            refresh_s += perf_counter() - t
            if not _finite_state(data):
                failure = {"reason": "NONFINITE_AFTER_PREVIEW_REFRESH", "physics_step": steps}
                rows.append({"time_s": steps * PHYSICS_DT_S, "physics_step": steps,
                             "numerical_failure": failure, "state": state_values(model, data)})
                break
            t = perf_counter()
            rows.append(_capacity_fact(model, data, health, limits, tau, 0., 0., steps, 0, bid, branch_id, interface, metadata))
            fact_s += perf_counter() - t
    complete = steps == PREVIEW_STEPS and failure is None
    check = predicted_physical_check(rows[-1]) if complete else {"pass": False, "failure_reasons": ["INCOMPLETE_OR_NONFINITE_PREVIEW"]}
    return _json_safe({"schema": "STEP25_ONE_STEP_CAPACITY_PREVIEW_V1", "variant": VARIANT,
        "branch_id": branch_id, "backup_id": bid, **metadata,
        "status": "COMPLETE" if complete else "FAILED_NUMERICAL", "pass": check["pass"],
        "physical_check": check, "reason": failure, "capacity_interface": interface,
        "tau_raw": interface["tau_raw"], "tau_sent": tau.tolist(),
        "initialization_ms": initialization_ms, "elapsed_ms": (perf_counter() - begin) * 1000.,
        "initial_state": initial, "initial_fact": initial_fact, "final_state": state_values(model, data),
        "physics_trajectory": rows,
        "counts": {"physical_steps": steps, "backup_qp_calls": 0, "control_qp_calls": 0,
                   "clone_data_calls": 1, "backup_controller_instances": 0,
                   "action_conditioned_forward_calls": action_forward, "integration_refresh_forward_calls": refresh},
        "timing": {"action_conditioned_forward_s": action_forward_s, "integration_s": integration_s,
                   "integration_refresh_s": refresh_s, "integration_and_refresh_s": integration_s + refresh_s,
                   "physical_fact_extraction_s": fact_s, "capacity_interface_ms": interface["capacity_interface_ms"]},
        "screening_semantics": "candidate held exactly20ms; numeric endpoint physical check only"})


preview = preview_candidate


def specification():
    return {"variant": VARIANT, "capacity_interface_version": CAPACITY_VERSION,
            "capacity_formula": "health_vector * healthy_torque_limits",
            "sent_command_formula": "clip(tau_raw,-effective_capacity,+effective_capacity)",
            "solver_gate": "strict status_val=1 and finite correctly shaped raw QP variables",
            "raw_QP_and_validation_immutable": True, "PID_and_authority_gate_unchanged": True,
            "backup_version": HOLD_VERSION, "backup_initial_integral": [0.] * 6,
            "physics_steps": PHYSICS_STEPS, "control_slots": CONTROL_SLOTS,
            "physics_dt_s": PHYSICS_DT_S, "control_dt_s": CONTROL_DT_S,
            "report_checkpoint_steps": list(CHECKPOINT_STEPS),
            "local_bound_not_controller_input": True, "numerical_retries": 0}
