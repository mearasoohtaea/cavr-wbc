"""Opt-in STEP25 dense, prediction-only screens and saved numeric analyses.

This module never propagates a model, solves a QP, or consumes actual facts to
choose a command. Actual traces enter only the post-decision range analysis.
All physical/terminal thresholds are the original STEP23 numeric predicates.
"""
from __future__ import annotations

from time import perf_counter
from typing import Any, Mapping

import numpy as np

from cavr_wbc.control.step23_backup_filter import (
    CHECKPOINT_STEPS, CONTROL_SLOTS, METHODS, PHYSICS_DT_S, PHYSICS_STEPS,
    PREVIEW_STEPS, predicted_physical_check, predicted_terminal_check,
)
from cavr_wbc.control.step24_local_workspace import (
    ANALYTIC_GAP_RANGE_M, _finite_state_row, _observed_peak, _preview_complete,
    mechanism_interval, with_local,
)


VARIANT = "STEP25_DENSE_DISCRETE_SCREEN_WITH_CAPACITY_INTERFACE_V1"
PROBE_GAP_M = .0005


def _prediction_only(branch):
    if not isinstance(branch, Mapping) or not (
        branch.get("kind") == "PREDICTION"
        or str(branch.get("kind", "")).startswith("PREDICTION_")
    ):
        raise ValueError("STEP25 decisions accept only PREDICTION branches")


def _ordered_grid(rows, steps):
    if len(rows) != len(steps):
        return False
    try:
        return all(
            isinstance(row, Mapping) and row["physics_step"] == step
            and int(row["physics_step"]) == step
            and abs(float(row["time_s"]) - step * PHYSICS_DT_S) <= 1e-9
            for row, step in zip(rows, steps)
        )
    except (KeyError, TypeError, ValueError, OverflowError):
        return False


def _full_complete(branch):
    if not isinstance(branch, Mapping):
        return False
    rows = branch.get("physics_trajectory", [])
    controls = branch.get("controls", [])
    return bool(
        branch.get("status") == "COMPLETE"
        and branch.get("counts", {}).get("physical_steps") == PHYSICS_STEPS
        and _ordered_grid(rows, tuple(range(1, PHYSICS_STEPS + 1)))
        and _ordered_grid(branch.get("checkpoints", []), CHECKPOINT_STEPS)
        and len(controls) == CONTROL_SLOTS
        and all(isinstance(c, Mapping) and c.get("slot") == i
                for i, c in enumerate(controls))
    )


def _dense_rows(branch):
    return [branch.get("initial_fact")] + list(branch.get("physics_trajectory", []))


def dense_original_screen(branch: Mapping[str, Any], anchor) -> dict[str, Any]:
    """Check initial plus all 500 prediction facts, excluding local bounds.

    Landmarks are retained and their reporting grid must be complete, but each
    physics row participates directly in acceptance. Cached labels are ignored.
    """
    _prediction_only(branch)
    rows = _dense_rows(branch)
    controls = branch.get("controls", [])
    first = branch.get("first_mode")
    if first == "CANDIDATE":
        backup_controls, expected_backup_slots = controls[1:], 49
    elif first == "BACKUP":
        backup_controls, expected_backup_slots = controls, 50
    else:
        backup_controls, expected_backup_slots = [], None
    valid = bool(
        expected_backup_slots is not None
        and len(backup_controls) == expected_backup_slots
        and all(isinstance(c, Mapping) and c.get("valid_command") is True
                for c in backup_controls)
    )
    complete = _full_complete(branch)
    grid = _ordered_grid(rows, tuple(range(PHYSICS_STEPS + 1)))
    states = [branch.get("initial_state"), branch.get("final_state")] + rows
    finite = all(_finite_state_row(row) for row in states)
    checks = [predicted_physical_check(row) for row in rows]
    physical = bool(grid and all(check["pass"] for check in checks))
    terminal = predicted_terminal_check(rows[-1], anchor) if grid else {
        "pass": False, "reason": "INCOMPLETE_DENSE_GRID"}
    candidate_valid = bool(first != "CANDIDATE" or (
        controls and isinstance(controls[0], Mapping)
        and controls[0].get("valid_command") is True))
    conditions = {
        "complete_500step_50slot_horizon": complete,
        "dense_grid_501_states": grid,
        "report_landmark_grid_21": _ordered_grid(branch.get("checkpoints", []), CHECKPOINT_STEPS),
        "all_backup_commands_valid": valid,
        "candidate_first_command_valid": candidate_valid,
        "finite": bool(finite),
        "original_physical_safe": physical,
        "original_terminal_pass": bool(terminal["pass"]),
    }
    return {
        "pass": bool(all(conditions.values())), "conditions": conditions,
        "reasons": [name for name, passed in conditions.items() if not passed],
        "dense_checks": checks, "terminal": terminal,
        "dense_state_count": len(rows), "checkpoint_count": len(branch.get("checkpoints", [])),
        "expected_backup_slots": expected_backup_slots,
        "observed_backup_slots": len(backup_controls), "local_condition_included": False,
        "cached_screen_or_actual_labels_consumed": False,
        "semantics": "initial plus all5002ms discrete states; no continuous-time certificate",
    }


def dense_with_local_screen(branch, original, upper):
    """Combine original dense checks with local facts; preserve global facts."""
    _prediction_only(branch)
    margins = []
    for row in _dense_rows(branch):
        try:
            margins.append(with_local(row, upper)["local_workspace_margin_m"])
        except (KeyError, TypeError, ValueError, IndexError, OverflowError):
            margins.append(None)
    grid = original["conditions"]["dense_grid_501_states"]
    local = bool(grid and all(value is not None and value >= 0. for value in margins))
    terminal_local = bool(grid and margins[-1] is not None and margins[-1] >= 0.)
    reasons = list(original["reasons"])
    if not local:
        reasons.append("local_workspace_dense_violation_or_incomplete_grid")
    if not terminal_local:
        reasons.append("local_workspace_terminal_violation_or_missing_endpoint")
    observed = [m for m in margins if m is not None]
    return {
        "pass": bool(original["pass"] and local and terminal_local), "original": original,
        "local_workspace_safe": local, "terminal_local_pass": terminal_local,
        "local_dense_margins_m": margins,
        "observed_min_local_margin_m": min(observed) if observed else None,
        "reasons": reasons,
    }


def dense_query_decisions(nominal, preview, pred_C, pred_B, anchor, x0: float,
                          gap: float = PROBE_GAP_M) -> dict[str, Any]:
    """Freeze M0/M1/M2 from current facts and predictions only.

    ``timing_by_method_ms`` isolates screen/selection work: each method includes
    current qualification, M1 additionally its endpoint, and M2 its two dense
    checks. Fresh preview/propagation and nominal costs are added by the caller.
    """
    x0, gap = float(x0), float(gap)
    if not np.isfinite([x0, gap]).all() or gap < 0.:
        raise ValueError("STEP25 query requires finite x0 and nonnegative gap")
    upper = x0 + gap
    begin = perf_counter()
    command_valid = bool(nominal.get("command_valid"))
    current = nominal.get("initial_new_command_fact")
    current_check = predicted_physical_check(current) if isinstance(current, Mapping) else {
        "pass": False, "failure_reasons": ["MISSING_CURRENT_NEW_COMMAND_FACT"]}
    try:
        current_margin = with_local(current, upper)["local_workspace_margin_m"]
    except (KeyError, TypeError, ValueError, IndexError, OverflowError):
        current_margin = None
    qualified = bool(command_valid and current_check["pass"]
                     and current_margin is not None and current_margin >= 0.)
    current_ms = (perf_counter() - begin) * 1000.
    base = {"variant": VARIANT, "x0": x0, "gap_m": gap, "local_upper": upper,
            "candidate_command_valid": command_valid, "current_check": current_check,
            "initial_local_margin_m": current_margin,
            "decisions_use_actual_trajectory": False,
            "timing_scope": "screen/selection only; excludes nominal, preview and horizon propagation"}
    if not qualified:
        decisions = {method: {"selected_mode": None,
            "safety_label": "NOT_RUN_INITIAL_UNQUALIFIED", "execution_mode": "NOT_RUN",
            "check_ms": current_ms} for method in METHODS}
        return {**base, "query_status": "NOT_RUN_INITIAL_UNQUALIFIED", "step_pass": False,
                "one_step_check": None, "C_screen": None, "B_screen": None,
                "method_decisions": decisions,
                "timing_by_method_ms": dict.fromkeys(METHODS, current_ms)}

    begin = perf_counter()
    m0 = {"selected_mode": "C", "safety_label": "CURRENT_EXECUTABLE_CANDIDATE_NO_LOOKAHEAD",
          "execution_mode": "CURRENT_EXECUTABLE_SELECTION"}
    m0_ms = current_ms + (perf_counter() - begin) * 1000.

    begin = perf_counter()
    preview_complete = _preview_complete(preview)
    endpoint = preview["physics_trajectory"][-1] if preview_complete else None
    endpoint_check = predicted_physical_check(endpoint) if endpoint is not None else {
        "pass": False, "failure_reasons": ["INCOMPLETE_OR_INVALID_PREVIEW"]}
    try:
        endpoint_margin = with_local(endpoint, upper)["local_workspace_margin_m"]
    except (KeyError, TypeError, ValueError, IndexError, OverflowError):
        endpoint_margin = None
    step_pass = bool(preview_complete and endpoint_check["pass"]
                     and endpoint_margin is not None and endpoint_margin >= 0.)
    one_step = {"pass": step_pass, "preview_complete": preview_complete,
                "current_physical_check": current_check, "endpoint_physical_check": endpoint_check,
                "initial_local_margin_m": current_margin, "endpoint_local_margin_m": endpoint_margin,
                "semantics": "original physics/local at current and20ms endpoint only"}
    m1 = {"selected_mode": "C" if step_pass else "B",
          "safety_label": "ONE_STEP_ACCEPTED" if step_pass else "BACKUP_WITHOUT_HORIZON_SCREEN",
          "execution_mode": "ONE_STEP_SELECTION"}
    m1_ms = current_ms + (perf_counter() - begin) * 1000.

    begin = perf_counter()
    C = dense_with_local_screen(pred_C, dense_original_screen(pred_C, anchor), upper)
    B = dense_with_local_screen(pred_B, dense_original_screen(pred_B, anchor), upper)
    mode = "C" if C["pass"] else "B"
    label = ("DENSE_SAMPLE_ACCEPTED" if C["pass"] else "IMMEDIATE_BACKUP_DENSE_SCREENED"
             if B["pass"] else "BACKUP_NOT_SCREENED_SAFE")
    m2 = {"selected_mode": mode, "safety_label": label,
          "execution_mode": "BEST_EFFORT" if not C["pass"] and not B["pass"] else "SCREENED_SELECTION"}
    m2_ms = current_ms + (perf_counter() - begin) * 1000.
    timing = dict(zip(METHODS, (m0_ms, m1_ms, m2_ms)))
    decisions = dict(zip(METHODS, (m0, m1, m2)))
    for method, row in decisions.items():
        row["check_ms"] = timing[method]
    return {**base, "query_status": "QUALIFIED_QUERY_COMPLETED", "step_pass": step_pass,
            "one_step_check": one_step, "C_screen": C, "B_screen": B,
            "method_decisions": decisions, "timing_by_method_ms": timing}


def excursion_metrics(x0: float, preview, predC, predB, actualC, actualB) -> dict[str, Any]:
    """Post-decision excursions with complete-horizon canonical metrics only."""
    x0 = float(x0)
    if not np.isfinite(x0):
        raise ValueError("STEP25 metric origin must be finite")
    metrics = {"x0_m": x0, "unit": "m", "d_step": None, "d_preview_full": None,
               "d_pred_C": None, "d_pred_B": None, "d_actual_C": None, "d_actual_B": None,
               "observed_prefix_diagnostics": {}, "complete": {}}
    preview_rows = preview.get("physics_trajectory", []) if isinstance(preview, Mapping) else []
    initial = preview.get("initial_state") if isinstance(preview, Mapping) else None
    for key, rows in (("d_step", [initial, preview_rows[-1]] if preview_rows else [initial]),
                      ("d_preview_full", [initial] + list(preview_rows))):
        observed = _observed_peak(rows, x0)
        complete = bool(_preview_complete(preview) and observed["missing_or_nonfinite_rows"] == 0)
        metrics["complete"][key] = complete
        metrics["observed_prefix_diagnostics"][key] = observed
        if complete:
            metrics[key] = observed["observed_peak_excursion_m"]
    for key, branch, prediction in (("d_pred_C", predC, True), ("d_pred_B", predB, True),
                                    ("d_actual_C", actualC, False), ("d_actual_B", actualB, False)):
        if prediction and isinstance(branch, Mapping):
            _prediction_only(branch)
        rows = _dense_rows(branch) if isinstance(branch, Mapping) else []
        observed = _observed_peak(rows, x0)
        complete = bool(_full_complete(branch) and observed["missing_or_nonfinite_rows"] == 0)
        metrics["complete"][key] = complete
        metrics["observed_prefix_diagnostics"][key] = observed
        if complete:
            metrics[key] = observed["observed_peak_excursion_m"]
    metrics["prediction_grid"] = "initial + all500physics states"
    metrics["actual_grid"] = "independent actual initial + all500physics states"
    return metrics


def _band(lower, upper, reasons=()):
    """A lower-closed, upper-open band intersected with the closed gap range.

    ``upper=None`` means unbounded above, represented without nonfinite JSON.
    """
    base = {"range_m": list(ANALYTIC_GAP_RANGE_M), "comparison_epsilon_m": 0.,
            "endpoint_rule": "lower inclusive; finite raw upper excluded; range cutoff inclusive if below raw upper",
            "reasons": list(reasons)}
    if lower is None:
        return {**base, "status": "NOT_APPLICABLE", "raw_interval": None,
                "intersection_interval": None, "width_m": None}
    lower = max(0., float(lower))
    if upper is not None:
        upper = float(upper)
    if upper is not None and not lower < upper:
        return {**base, "status": "EMPTY", "raw_interval": None,
                "intersection_interval": None, "width_m": 0.}
    raw = {"lower_m": lower, "upper_m": upper, "lower_inclusive": True,
           "upper_inclusive": False, "upper_unbounded": upper is None}
    lo = max(lower, ANALYTIC_GAP_RANGE_M[0])
    hi = ANALYTIC_GAP_RANGE_M[1] if upper is None else min(upper, ANALYTIC_GAP_RANGE_M[1])
    inclusive = upper is None or ANALYTIC_GAP_RANGE_M[1] < upper
    if lo > hi or (lo == hi and not inclusive):
        return {**base, "status": "EMPTY", "raw_interval": raw,
                "intersection_interval": None, "width_m": 0.}
    intersection = {"lower_m": lo, "upper_m": hi, "lower_inclusive": True,
                    "upper_inclusive": inclusive, "is_singleton": lo == hi}
    return {**base, "status": "NONEMPTY", "raw_interval": raw,
            "intersection_interval": intersection, "width_m": hi - lo}


def _original(value):
    if isinstance(value, Mapping):
        return bool(value.get("pass")), list(value.get("reasons", []))
    return bool(value), [] if value else ["ORIGINAL_DENSE_PHYSICAL_TERMINAL_OR_COMMAND_FAILURE"]


def _actual_eligible(eligibility, mode):
    """Return None when individual actual original status was not supplied."""
    for key in (f"actual_{mode}_original_safe_and_terminal", f"actual_{mode}_original_pass",
                f"actual{mode}_original_pass"):
        if key in eligibility:
            return bool(eligibility[key])
    for key in ("all_branches_complete_valid_original_safe_and_terminal",
                "all_original_physics_terminal_pass"):
        if eligibility.get(key) is True:
            return True
    return None


def analyze_range(metrics: Mapping[str, Any], eligibility: Mapping[str, Any],
                  C_original_pass, B_original_pass) -> dict[str, Any]:
    """Exact workspace bands, with explicit nonworkspace failure conditions.

    Dense mechanism uses STEP24's exact formula. Separate local-only failure
    bands remain useful when a nonworkspace predicate invalidates that formula.
    If an actual physical/terminal failure is supplied individually, combined
    actual failure covers every corresponding prediction-accepted gap.
    """
    cp, cr = _original(C_original_pass)
    bp, br = _original(B_original_pass)
    mechanism_eligibility = dict(eligibility)
    mechanism_eligibility.update(C_original_prediction_pass=cp, B_original_prediction_pass=bp)
    mechanism = mechanism_interval(metrics, mechanism_eligibility)
    values = {}
    for key in ("d_pred_C", "d_pred_B", "d_actual_C", "d_actual_B"):
        try:
            value = float(metrics[key])
            values[key] = value if np.isfinite(value) else None
        except (KeyError, TypeError, ValueError, OverflowError):
            values[key] = None
    pc, pb, ac, ab = (values[k] for k in ("d_pred_C", "d_pred_B", "d_actual_C", "d_actual_B"))

    if not cp:
        c_local_failure = _band(0., 0., ["C_NOT_ACCEPTED_BY_ORIGINAL_DENSE_SCREEN"] + cr)
        c_combined_failure = dict(c_local_failure)
    elif pc is None:
        c_local_failure = _band(None, None, ["INCOMPLETE_C_PREDICTION_METRIC"])
        c_combined_failure = dict(c_local_failure)
    else:
        c_local_failure = (_band(pc, ac) if ac is not None else
                           _band(None, None, ["INCOMPLETE_C_ACTUAL_METRIC"]))
        actual_c = _actual_eligible(eligibility, "C")
        c_combined_failure = (_band(pc, None, ["ACTUAL_C_ORIGINAL_PHYSICAL_OR_TERMINAL_FAILURE"])
                              if actual_c is False else dict(c_local_failure))
        c_combined_failure["actual_original_status_supplied"] = actual_c is not None

    # B is selected exactly where C does not pass. If C's original screen fails,
    # C never passes at any gap and introduces no workspace upper cutoff.
    c_selection_upper = pc if cp else None
    if not bp:
        b_local_failure = _band(0., 0., ["B_NOT_ACCEPTED_BY_ORIGINAL_DENSE_SCREEN"] + br)
        b_combined_failure = dict(b_local_failure)
    elif pb is None or (cp and pc is None):
        b_local_failure = _band(None, None, ["INCOMPLETE_B_OR_C_PREDICTION_SELECTION_OR_ACTUAL_METRIC"])
        b_combined_failure = dict(b_local_failure)
    else:
        b_local_failure = (_band(pb, min(ab, c_selection_upper) if c_selection_upper is not None else ab)
                           if ab is not None else _band(None, None, ["INCOMPLETE_B_ACTUAL_METRIC"]))
        actual_b = _actual_eligible(eligibility, "B")
        b_combined_failure = (_band(pb, c_selection_upper, ["ACTUAL_B_ORIGINAL_PHYSICAL_OR_TERMINAL_FAILURE"])
                              if actual_b is False else dict(b_local_failure))
        b_combined_failure["actual_original_status_supplied"] = actual_b is not None

    if (cp and pc is None) or (bp and pb is None):
        uncertified = _band(None, None, ["INCOMPLETE_PREDICTION_METRIC_FOR_SELECTION_RANGE"])
    else:
        upper = min(v for v in (pc if cp else None, pb if bp else None) if v is not None) if cp or bp else None
        uncertified = _band(0., upper, (cr if not cp else []) + (br if not bp else []))
    return {
        "variant": VARIANT, "range_m": list(ANALYTIC_GAP_RANGE_M), "comparison_epsilon_m": 0.,
        "mechanism_interval": mechanism,
        "candidate_acceptance_actual_failure_band": c_combined_failure,
        "backup_screened_selected_actual_failure_band": b_combined_failure,
        "candidate_acceptance_actual_workspace_failure_band": c_local_failure,
        "backup_screened_selected_actual_workspace_failure_band": b_local_failure,
        "backup_uncertified_gap_band": uncertified,
        "C_original_prediction_pass": cp, "B_original_prediction_pass": bp,
        "nonworkspace_reasons": {"C": cr, "B": br},
        "semantics": "conditional on current eligibility; local bound never enters controller; no new propagation",
        "known_saved_healthy_regression_is_not_new_experiment": True,
    }


def specification() -> dict[str, Any]:
    return {"variant": VARIANT, "fixed_development_probe_gap_m": PROBE_GAP_M,
            "probe_design": "targeted development check based on saved healthy mechanism interval",
            "analytic_gap_range_m": list(ANALYTIC_GAP_RANGE_M),
            "dense_grid_states": PHYSICS_STEPS + 1, "physics_dt_s": PHYSICS_DT_S,
            "report_landmark_steps": list(CHECKPOINT_STEPS), "control_slots": CONTROL_SLOTS,
            "original_global_boundary_preserved": "boundary_margin_m =1.0-base_x",
            "local_upper_definition": "x0+gap", "local_bound_passed_to_controller": False,
            "query_selection_consumes_actual": False, "continuous_time_certificate": False,
            "comparison_epsilon_m": 0., "incomplete_excursion": "None; observed-prefix diagnostic separately",
            "method_timing": "current qualification each; M1 endpoint only; M2 two full dense screens; propagation separately",
            "maximum_unique_new_prediction_traces": 4, "maximum_unique_new_actual_traces": 4,
            "counterfactual_mapping": "method selected C/B maps to context's one independent actualC/B",
            "no_new_physics_or_QP_for_saved_reassessment_or_interval_analysis": True}
