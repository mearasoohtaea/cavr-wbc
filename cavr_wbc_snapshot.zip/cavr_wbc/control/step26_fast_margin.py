"""Frozen STEP26 empirical surrogates; inference consumes current features only.

Fitting receives explicit TRAIN/CAL records in memory. This module never opens
trajectory banks, integrates dynamics, solves QPs, or reads held-out labels.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import joblib
import numpy as np
import sklearn
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.preprocessing import PolynomialFeatures, StandardScaler

FIXED_GAPS_M = (.001, .002, .004, .008, .016, .032)
RESERVE_M = .001
OOD_DISTANCE_FLOOR = 1e-12


def specification():
    return {"method": "M3_FAST_MARGIN", "sklearn_version": sklearn.__version__,
            "feature_limit": 48, "scaler": "StandardScaler fit on finite TRAIN only",
            "A": {"polynomial_degree": 2, "include_bias": False,
                  "Ridge": {"alpha": 1e-3},
                  "LogisticRegression": {"C": 1, "max_iter": 2000}},
            "B": {"n_estimators": 128, "max_depth": 5, "min_samples_leaf": 3,
                  "random_state": 26, "n_jobs": 1},
            "reserve_m": RESERVE_M, "validity_min_threshold": .90,
            "unsafe_threshold_rule": "nextafter(max CAL unsafe score, +infinity)",
            "minimum_valid_cal_labels": 1,
            "ood": {"space": "TRAIN standardized current features",
                    "threshold": "3 * max(max CAL nearest TRAIN distance, floor)",
                    "distance_floor": OOD_DISTANCE_FLOOR},
            "selection_gaps_m": list(FIXED_GAPS_M),
            "single_class": "explicit constant probability; no two-class evidence",
            "missing_D": "missing regressor; uncalibrated and rejected"}


class ConstantClassifier:
    """An observed single class, explicitly distinguished from learned evidence."""
    def __init__(self, value):
        self.value = int(value)
        self.classes_ = np.array([self.value])

    def predict_proba(self, x):
        return np.ones((len(x), 1), dtype=float)


def _score(classifier, x):
    if classifier is None:
        return np.zeros(len(x))
    if isinstance(classifier, ConstantClassifier):
        return np.full(len(x), float(classifier.value))
    positive = np.flatnonzero(classifier.classes_ == 1)
    return classifier.predict_proba(x)[:, positive[0]] if len(positive) else np.zeros(len(x))


def _rows(records, allowed, width):
    output = []
    for record in records:
        if record["split"] not in allowed:
            raise ValueError("TRAIN/CAL only: forbidden split " + str(record["split"]))
        features = np.asarray(record["features"], dtype=float)
        if features.shape != (width,):
            raise ValueError("Frozen feature width mismatch")
        output.append((record, features, bool(np.all(np.isfinite(features)))))
    return output


def _target(record, branch):
    label = record["labels"][branch]
    complete = bool(label.get("complete", False))
    value = label.get("D")
    has_d = complete and value is not None and np.isfinite(float(value))
    return float(value) if has_d else None, bool(complete and label.get("valid", False))


def _nearest(x, train):
    if not len(train):
        return np.full(len(x), np.inf)
    return np.sqrt(np.min(np.sum((x[:, None, :] - train[None, :, :]) ** 2, axis=2), axis=1))


def fit_models(train_records, cal_records, feature_names, round_id=1):
    """Exactly the two fixed configurations; CAL only calibrates and selects."""
    if round_id not in (1, 2) or not 0 < len(feature_names) <= 48:
        raise ValueError("Frozen round/feature limits violated")
    width = len(feature_names)
    train_rows = _rows(train_records, {"TRAIN", "DEV_TRAIN"}, width)
    cal_rows = _rows(cal_records, {"CAL", "CALIBRATION"}, width)
    train_ids = {r["context_id"] for r, _, _ in train_rows}
    cal_ids = {r["context_id"] for r, _, _ in cal_rows}
    if train_ids & cal_ids:
        raise ValueError("TRAIN/CAL context overlap")
    train_episodes = {r["episode_id"] for r, _, _ in train_rows if "episode_id" in r}
    cal_episodes = {r["episode_id"] for r, _, _ in cal_rows if "episode_id" in r}
    if train_episodes & cal_episodes:
        raise ValueError("TRAIN/CAL episode overlap")
    finite_train = [r for r, _, finite in train_rows if finite]
    finite_cal = [r for r, _, finite in cal_rows if finite]
    tx = np.array([r["features"] for r in finite_train], dtype=float).reshape(-1, width)
    cx = np.array([r["features"] for r in finite_cal], dtype=float).reshape(-1, width)
    scaler = StandardScaler().fit(tx) if len(tx) else None
    tx = scaler.transform(tx) if scaler is not None else tx
    cx = scaler.transform(cx) if scaler is not None and len(cx) else cx
    cal_nearest = _nearest(cx, tx)
    maximum_cal_distance = float(np.max(cal_nearest)) if len(cal_nearest) and len(tx) else 0.
    ood_threshold = 3 * max(maximum_cal_distance, OOD_DISTANCE_FLOOR)
    output = {}
    for config in ("A", "B"):
        poly = PolynomialFeatures(degree=2, include_bias=False) if config == "A" else None
        ztrain = poly.fit_transform(tx) if poly is not None and len(tx) else tx
        zcal = poly.transform(cx) if poly is not None and len(cx) and len(tx) else cx
        bundle = {"config": config, "round_id": round_id, "feature_names": list(feature_names),
                  "scaler": scaler, "polynomial": poly, "train_scaled": tx,
                  "ood_threshold": ood_threshold, "cal_nearest_distances": cal_nearest.tolist(),
                  "branches": {}, "estimator_fit_count": 0, "specification": specification(),
                  "train_context_ids": sorted(train_ids), "cal_context_ids": sorted(cal_ids),
                  "nonfinite_train_count": len(train_rows) - len(finite_train),
                  "nonfinite_cal_count": len(cal_rows) - len(finite_cal)}
        for branch in ("C", "B"):
            targets = [_target(r, branch) for r in finite_train]
            dmask = np.array([d is not None for d, _ in targets], dtype=bool)
            dtrain = np.array([d for d, _ in targets if d is not None])
            ytrain = np.array([int(valid) for _, valid in targets])
            reg = None
            if len(dtrain):
                reg = (Ridge(alpha=1e-3) if config == "A" else
                       RandomForestRegressor(**specification()["B"]))
                reg.fit(ztrain[dmask], dtrain)
                bundle["estimator_fit_count"] += 1
            classifier = None
            if len(ytrain):
                if len(np.unique(ytrain)) == 1:
                    classifier = ConstantClassifier(ytrain[0])
                else:
                    classifier = (LogisticRegression(C=1, max_iter=2000) if config == "A" else
                                  RandomForestClassifier(**specification()["B"]))
                    classifier.fit(ztrain, ytrain)
                    bundle["estimator_fit_count"] += 1
            cal_targets = [_target(r, branch) for r in finite_cal]
            cal_scores = _score(classifier, zcal) if len(zcal) else np.array([])
            unsafe_scores = [float(p) for p, (_, valid) in zip(cal_scores, cal_targets) if not valid]
            max_unsafe = max(unsafe_scores, default=None)
            threshold = max(.9, float(np.nextafter(max_unsafe, np.inf))) if max_unsafe is not None else .9
            complete_pairs = [(i, d) for i, (d, _) in enumerate(cal_targets) if d is not None]
            valid_cal_count = sum(valid and d is not None for d, valid in cal_targets)
            margin = None
            if reg is not None and complete_pairs:
                dhat = reg.predict(zcal)
                margin = max(0., max(d - float(dhat[i]) for i, d in complete_pairs))
            calibrated = reg is not None and margin is not None and valid_cal_count >= 1
            bundle["branches"][branch] = {
                "regressor": reg, "classifier": classifier, "cal_margin_m": margin,
                "validity_threshold": threshold, "max_cal_unsafe_score": max_unsafe,
                "calibrated": calibrated, "cal_complete_D_count": len(complete_pairs),
                "cal_valid_count": int(valid_cal_count), "train_complete_D_count": len(dtrain),
                "classifier_evidence": ("SINGLE_CLASS_CONSTANT" if isinstance(classifier, ConstantClassifier)
                                        else "TWO_CLASS_FIT" if classifier is not None else "NO_TRAIN_DATA")}
        output[config] = bundle
    return output


def predict(bundle, features):
    """Current-input inference; no accepted/actual labels or trajectory access."""
    x = np.asarray(features, dtype=float)
    if x.shape != (len(bundle["feature_names"]),):
        raise ValueError("Frozen feature width mismatch")
    available = bool(np.all(np.isfinite(x))) and bundle["scaler"] is not None
    if available:
        scaled = bundle["scaler"].transform(x.reshape(1, -1))
        distance = float(_nearest(scaled, bundle["train_scaled"])[0])
        z = bundle["polynomial"].transform(scaled) if bundle["polynomial"] is not None else scaled
    else:
        distance, z = np.inf, None
    ood_passed = available and bool(np.isfinite(distance) and distance <= bundle["ood_threshold"])
    result = {"ood_passed": ood_passed, "nearest_train_distance": distance,
              "ood_threshold": bundle["ood_threshold"], "features_available": available}
    for name in ("C", "B"):
        branch = bundle["branches"][name]
        reg = branch["regressor"]
        dhat = float(reg.predict(z)[0]) if available and reg is not None else None
        score = float(_score(branch["classifier"], z)[0]) if available else None
        calibrated = branch["calibrated"] and dhat is not None and np.isfinite(dhat)
        upper = max(0., dhat) + branch["cal_margin_m"] + RESERVE_M if calibrated else None
        reasons = []
        if not available: reasons.append("CURRENT_FEATURES_UNAVAILABLE")
        if not ood_passed: reasons.append("OOD_REJECT")
        if not calibrated: reasons.append("UNCALIBRATED")
        if score is None or not np.isfinite(score) or score < branch["validity_threshold"]:
            reasons.append("VALIDITY_REJECT")
        result[name] = {"D_hat": dhat, "U": upper, "validity_score": score,
                        "validity_threshold": branch["validity_threshold"],
                        "calibrated": bool(calibrated), "gate_passed": not reasons,
                        "classifier_evidence": branch["classifier_evidence"], "reasons": reasons}
    return result


def decide(bundle, features, gap):
    if not np.isfinite(gap) or not 0 <= gap <= .05:
        raise ValueError("STEP26 gap must be finite and in [0, .05] m")
    prediction = predict(bundle, features)
    reasons = {}
    for name in ("C", "B"):
        item = prediction[name]
        reasons[name] = list(item["reasons"])
        if item["gate_passed"] and item["U"] <= gap:
            return {"method": "M3_FAST_MARGIN", "mode": name, "accepted": True,
                    "gap_m": float(gap), "reasons": reasons, "prediction": prediction}
        if item["U"] is not None and item["U"] > gap:
            reasons[name].append("LOCAL_MARGIN_REJECT")
    return {"method": "M3_FAST_MARGIN", "mode": "ABSTAIN", "accepted": False,
            "gap_m": float(gap), "reasons": reasons, "prediction": prediction}


def select_on_cal(models, cal_records, gaps_m=FIXED_GAPS_M):
    """Rank unsafe accepts, oracle-safe coverage, C retention, then tie A."""
    _rows(cal_records, {"CAL", "CALIBRATION"}, len(models["A"]["feature_names"]))
    metrics = {}
    for name, bundle in models.items():
        unsafe = accepted_safe = oracle_safe = c_retained = queries = accepted = 0
        for record in cal_records:
            truth = {b: _target(record, b) for b in ("C", "B")}
            for gap in gaps_m:
                queries += 1
                safe = {b: valid and d is not None and d <= gap for b, (d, valid) in truth.items()}
                oracle_safe += int(any(safe.values()))
                decision = decide(bundle, record["features"], gap)
                accepted += int(decision["accepted"])
                if decision["accepted"]:
                    good = safe[decision["mode"]]
                    unsafe += int(not good)
                    accepted_safe += int(good)
                    c_retained += int(good and decision["mode"] == "C")
        coverage = accepted_safe / oracle_safe if oracle_safe else 0.
        metrics[name] = {"queries": queries, "unsafe_accepts": unsafe, "accepts": accepted,
                         "oracle_safe_queries": oracle_safe, "safe_accepts": accepted_safe,
                         "oracle_safe_coverage": coverage, "C_retained": c_retained}
    chosen = min(models, key=lambda k: (metrics[k]["unsafe_accepts"],
                 -metrics[k]["oracle_safe_coverage"], -metrics[k]["C_retained"], k != "A"))
    return {"selected": chosen, "ranking": metrics, "gaps_m": list(gaps_m)}


def save_bundle(output_directory, bundle):
    """Persist fitted assets and a label-free, content-hashed freeze manifest."""
    directory = Path(output_directory)
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / ("step26_model_" + bundle["config"] + ".joblib")
    joblib.dump(bundle, path, compress=3)
    metadata = {k: bundle[k] for k in ("config", "round_id", "feature_names", "ood_threshold",
                 "estimator_fit_count", "specification", "train_context_ids", "cal_context_ids")}
    metadata["sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
    metadata["weights_path"] = str(path.resolve())
    metadata["branches"] = {name: {k: value for k, value in branch.items()
                           if k not in ("regressor", "classifier")}
                            for name, branch in bundle["branches"].items()}
    manifest = directory / ("step26_model_" + bundle["config"] + "_freeze.json")
    manifest.write_text(json.dumps(metadata, indent=2, allow_nan=False), encoding="utf-8")
    return {"weights_path": str(path.resolve()), "manifest_path": str(manifest.resolve()),
            "sha256": metadata["sha256"]}
