"""STEP27 opt-in resident STEP22 control kernel.

The QP, contact SVD, PID and actuator output policy are unchanged.  This
module removes diagnostic copies/JSON conversion from the command path,
owns independent nominal and fixed-anchor backup workspaces, and uses the
installed OSQP Python binding's native solver for the one fixed 6 ms variant.
All native invocations still pass through DynamicWBC._invoke and its callback.
"""
from __future__ import annotations

import math
from time import perf_counter, thread_time
import gc
from typing import Any, Mapping

import mujoco
import numpy as np
import osqp

from cavr_wbc.control.e2b_dynamic import DynamicWBC
from cavr_wbc.control.step20_task_reference import reference
from cavr_wbc.control.step21_contact_reference import contact_reference
from cavr_wbc.control.step22_pose_servo import (
    AUTHORITY_GATE_FRACTION, CONTROL_DT_S, GAINS, INTEGRAL_LIMITS, MODEL_VERSION,
    Step22WBC, tangent_pose_error,
)
from cavr_wbc.control.step23_backup_filter import (
    HOLD_VERSION, _finite_state, _json_safe, predicted_physical_check,
)
from cavr_wbc.control.step25_capacity_backup import CAPACITY_VERSION
from cavr_wbc.platforms.go2_mujoco import FOOT_NAMES, extract_actuator_audit


VERSION = "STEP27_RESIDENT_KERNEL_V1"
VARIANTS = ("K_RESIDENT", "K_BUDGETED")
SOLVER_TIME_LIMIT_S = .006


def _copy_integration(model, data, context):
    """Restore the complete serialized integration state into resident data."""
    saved = context.get("state", context.get("source_state", context))
    signature = int(saved["integration_state_signature"])
    if signature != int(mujoco.mjtState.mjSTATE_INTEGRATION):
        raise ValueError("STEP27 requires complete mjSTATE_INTEGRATION")
    values = np.asarray(saved["integration_state"], dtype=float)
    expected_size = int(mujoco.mj_stateSize(model, signature))
    if values.shape != (expected_size,) or not np.isfinite(values).all():
        raise ValueError("STEP27 integration state incomplete/nonfinite")
    mujoco.mj_setState(model, data, values, signature)
    data.time = 0.
    mujoco.mj_forward(model, data)
    for key in ("qpos", "qvel", "act", "ctrl", "qacc_warmstart", "qfrc_applied",
                "xfrc_applied", "mocap_pos", "mocap_quat", "userdata", "plugin_state"):
        if key in saved:
            actual = np.asarray(getattr(data, key))
            expected = np.asarray(saved[key], dtype=float)
            if actual.size != expected.size or not np.array_equal(actual, expected.reshape(actual.shape)):
                raise ValueError("STEP27 forward changed restored integration field " + key)


def reset_workspace_warmstart(controller):
    """Retain OSQP structure/factorization; zero independent-case primal/dual."""
    for cache in controller._solver_cache.values():
        solver = cache["solver"]
        solver.warm_start(x=cache["zero_x"], y=cache["zero_y"])
        cache["last_x"] = None
        cache["last_y"] = None
        cache["independent_case_zeroed"] = True


class ResidentWBC(Step22WBC):
    """Same single-stage STEP22 problem, numeric trace and persistent buffers."""
    def __init__(self, model, solve_callback=None, *, variant="K_RESIDENT"):
        if variant not in VARIANTS:
            raise ValueError("unknown STEP27 kernel variant")
        super().__init__(model, solve_callback=solve_callback)
        self.variant = variant
        self.solver_time_limit_s = SOLVER_TIME_LIMIT_S if variant == "K_BUDGETED" else None
        self.last_meta: dict[str, Any] = {}
        self._point_memory = np.zeros((4, 3))
        self._jacobian_memory = np.zeros((12, self.nv))
        self._jdot_memory = np.zeros(12)
        self._jac_work = np.zeros((4, 3, self.nv))
        self._rot_jac_work = np.zeros((4, 3, self.nv))
        self._jacdot_work = np.zeros((4, 3, self.nv))
        self._rot_jacdot_work = np.zeros((4, 3, self.nv))
        self._actuation_memory = np.zeros((self.nv, self.nu))
        self._task_memory = np.zeros((6 + self.nu, self.nv))
        self._task_memory[:6, :6] = np.eye(6)
        for row, dof in enumerate(self._dof_for_actuator):
            self._task_memory[6 + row, dof] = 1.

    def compute(self, data, method, health, target=None):
        if str(method).upper() != "B1":
            raise ValueError("STEP27 retains single-stage STEP22 B1")
        begin = perf_counter()
        assembly_cpu_begin = thread_time()
        gc_before = tuple(row['collections'] for row in gc.get_stats())
        self.last_trace = {}
        self.last_stage1_snapshot = self.last_stage2_snapshot = self.last_stage1_witness = None
        target = dict(target or {})
        h = self._health(health)
        P, q, A, low, high, meta = self._problem(data, h, target,
            task_weights=np.asarray(target["task_weights"], dtype=float) if "task_weights" in target else None)
        assembled_ms = (perf_counter() - begin) * 1000.
        assembly_cpu_ms = (thread_time() - assembly_cpu_begin) * 1000.
        gc_after = tuple(row['collections'] for row in gc.get_stats())
        out = self._invoke({"P": P, "q": q, "A": A, "l": low, "u": high}, "B1_stage1")
        decoded_begin = perf_counter()
        result = self._decode(out, meta, "B1")
        result["kernel_assembly_ms"] = assembled_ms
        result["assembly_subblocks"] = self.assembly_subblocks
        result["kernel_assembly_thread_cpu_ms"] = assembly_cpu_ms
        result["assembly_gc_collections_before"] = gc_before
        result["assembly_gc_collections_after"] = gc_after
        result["assembly_timing_nested_not_additive"] = True
        result["kernel_decode_ms"] = (perf_counter() - decoded_begin) * 1000.
        return result

    def _contacts(self, data):
        for index, geom in enumerate(self._foot_geom_ids):
            point = self._point_memory[index]
            point[:] = data.geom_xpos[geom]
            body = int(self.model.geom_bodyid[geom])
            jp, jr = self._jac_work[index], self._rot_jac_work[index]
            jpd, jrd = self._jacdot_work[index], self._rot_jacdot_work[index]
            jp.fill(0.); jr.fill(0.); jpd.fill(0.); jrd.fill(0.)
            mujoco.mj_jac(self.model, data, jp, jr, point, body)
            mujoco.mj_jacDot(self.model, data, jpd, jrd, point, body)
            self._jacobian_memory[3 * index:3 * index + 3] = jp
            self._jdot_memory[3 * index:3 * index + 3] = jpd @ data.qvel
        return self._point_memory, self._jacobian_memory, self._jdot_memory

    def _selection(self, data):
        output = self._actuation_memory
        output.fill(0.)
        for actuator in range(self.nu):
            address = int(data.moment_rowadr[actuator])
            count = int(data.moment_rownnz[actuator])
            for offset in range(count):
                item = address + offset
                output[int(data.moment_colind[item]), actuator] = float(data.actuator_moment[item])
        return output

    def _task_map(self, target):
        desired, weights = DynamicWBC._task_values(self, target)
        return self._task_memory, desired, weights

    def _problem(self, data, health, target, **kwargs):
        if kwargs.get("stage2") or kwargs.get("physical") is not None:
            raise ValueError("STEP27 retains one same-tick STEP22 B1 problem")
        P, q, A, low, high, meta = DynamicWBC._problem(self, data, health, target, **kwargs)
        extra_begin, extra_cpu = perf_counter(), thread_time()
        self.contact_linearization_calls += 1
        desired = meta["desired"].copy()
        joint_reference, diagnostic = contact_reference(
            meta["Jc"], meta["jdotv"], desired[:6], self._dof_for_actuator)
        self.svd_calls += 1
        desired[6:] = joint_reference
        meta["desired"] = desired
        q[:self.nv] = -(meta["T"].T @ (meta["weights"] * desired))
        original = meta["bias"].copy()
        passive = np.asarray(data.qfrc_passive, dtype=float).copy()
        effective = original - passive
        meta.update(bias=effective, step22_bias_original=original,
                    step22_qfrc_passive=passive, step22_model_version=MODEL_VERSION,
                    contact_reference=diagnostic)
        low[:self.nv] = -effective; high[:self.nv] = -effective
        self.passive_model_calls += 1
        self.last_meta = meta
        # Numeric references are used by same-command validation.  No JSON,
        # hashing, immutable matrix snapshot or deep copy is performed here.
        self.last_trace = {"M": meta["M"], "B": meta["B"], "Jc": meta["Jc"],
                           "bias_eff": effective, "points": meta["points"],
                           "a_base_ref": desired[:6], "model_version": MODEL_VERSION}
        self.assembly_subblocks['contact_reference_SVD_passive_and_trace'] = dict(
            wall_ms=(perf_counter()-extra_begin)*1000., thread_cpu_ms=(thread_time()-extra_cpu)*1000.)
        return P, q, A, low, high, meta

    def _decode(self, out, meta, method):
        result = DynamicWBC._decode(self, out, meta, method)
        result.update(model_version=MODEL_VERSION, postsolve_torque_increment=False,
                      dynamics_residual_definition="M @ qdd + (qfrc_bias - qfrc_passive) - B @ tau_total - Jc.T @ lambda")
        if result["qdd"] is not None:
            common = meta["M"] @ result["qdd"] - meta["B"] @ result["tau"] - meta["Jc"].T @ result["contact_force"]
            effective = common + meta["bias"]
            legacy = common + meta["step22_bias_original"]
            result["validation"].update(dynamics_model_version=MODEL_VERSION,
                dynamics_residual_signed=effective,
                legacy_dynamics_residual_signed=legacy,
                legacy_dynamics_residual_inf=float(np.max(np.abs(legacy))))
        return result

    def _default_solve(self, problem, *, max_iter_override=None):
        """Public installed OSQP native binding; time limit set BEFORE solve."""
        P = problem["P"].tocsc(copy=False); A = problem["A"].tocsc(copy=False)
        P.sort_indices(); A.sort_indices()
        key = self._workspace_key({"P": P, "A": A})
        cache = self._solver_cache.get(key)
        max_iter = int(self.cfg.osqp_max_iter if max_iter_override is None else max_iter_override)
        setup_s = update_s = 0.; warm_started = False
        time_limit = SOLVER_TIME_LIMIT_S if self.variant == "K_BUDGETED" else 1e10
        if cache is None:
            start = perf_counter()
            solver = osqp.OSQP()
            solver.setup(P=P, q=problem["q"], A=A, l=problem["l"], u=problem["u"],
                eps_abs=self.cfg.osqp_eps_abs, eps_rel=self.cfg.osqp_eps_rel,
                max_iter=max_iter, polish=True, verbose=False, time_limit=time_limit)
            setup_s = perf_counter() - start
            self.solver_setup_calls += 1
            cache = {"solver": solver, "last_x": None, "last_y": None,
                     "zero_x": np.zeros(P.shape[0]), "zero_y": np.zeros(A.shape[0]),
                     "setup_count": self.solver_setup_calls, "native": False,
                     "independent_case_zeroed": True, "time_limit_s": time_limit}
            self._solver_cache[key] = cache
        else:
            solver = cache["solver"]
            start = perf_counter()
            solver.update(Px=P.data, Ax=A.data, q=problem["q"], l=problem["l"], u=problem["u"])
            # Updating the exposed native setting is explicit on every call,
            # not a time-limit probe or a search across budgets.
            solver.update_settings(time_limit=time_limit)
            update_s = perf_counter() - start
            if cache["last_x"] is not None or cache["last_y"] is not None:
                solver.warm_start(x=cache["last_x"], y=cache["last_y"])
                warm_started = True
        start = perf_counter()
        raw = solver.solve(raise_error=False)
        wall_s = perf_counter() - start
        cache["last_x"] = None if raw.x is None else np.asarray(raw.x, dtype=float).copy()
        cache["last_y"] = None if raw.y is None else np.asarray(raw.y, dtype=float).copy()
        cache["independent_case_zeroed"] = False
        info = raw.info
        result = {"x": None if raw.x is None else np.asarray(raw.x, dtype=float),
                  "status": str(info.status), "status_val": int(info.status_val),
                  "iterations": int(info.iter), "solve_time_s": float(info.solve_time),
                  "solve_wall_time_s": wall_s, "setup_time_s": setup_s, "update_time_s": update_s,
                  "workspace_reused": bool(update_s > 0.), "warm_started": warm_started,
                  "primal_residual": float(info.prim_res), "dual_residual": float(info.dual_res),
                  "kernel_variant": self.variant, "osqp_time_limit_s": self.solver_time_limit_s,
                  "native_api": "osqp.OSQP public Python binding to installed native extension"}
        self._last_solver_timings = {key: result[key] for key in
            ("setup_time_s", "update_time_s", "solve_wall_time_s", "solve_time_s", "workspace_reused", "warm_started")}
        return result

    def diagnostic_snapshot(self):
        """Materialize diagnostic matrices AFTER command-ready, never needed to send."""
        meta = self.last_meta
        if not meta:
            return {}
        return _json_safe({"configuration": "S22_POSE_PID", "model_version": MODEL_VERSION,
            "M": meta["M"].copy(), "B": meta["B"].copy(), "Jc": meta["Jc"].copy(),
            "jdotv": meta["jdotv"].copy(), "T": meta["T"].copy(), "points": meta["points"].copy(),
            "bias_eff": meta["bias"].copy(), "bias_original": meta["step22_bias_original"].copy(),
            "qfrc_passive": meta["step22_qfrc_passive"].copy(), "tau_lim": meta["tau_lim"].copy(),
            "a_base_ref": meta["desired"][:6].copy(), "desired": meta["desired"].copy(),
            "weights": meta["weights"].copy(), "contact_reference": meta["contact_reference"],
            "mapped_joint_dofs": self._dof_for_actuator, "g_loss_pred": np.zeros(self.nv),
            "loss_prediction": {"enabled": False, "g_loss_pred_all_zero": True}})


def _capacity(raw, health, healthy_limits, status):
    """Array-only equivalent of STEP25's exact-solved declared output layer."""
    begin = perf_counter()
    health = np.asarray(health, dtype=float)
    limits = health * healthy_limits
    solved = bool(status == 1 and not isinstance(status, (bool, np.bool_)))
    tau = raw.get("tau")
    valid_tau = tau is not None and np.asarray(tau).shape == limits.shape and np.isfinite(tau).all()
    full = valid_tau
    for key, shape in (("qdd", (raw.get("nv", 18),)), ("contact_force", (12,))):
        value = raw.get(key)
        full = bool(full and value is not None and np.asarray(value).shape == shape and np.isfinite(value).all())
    valid = bool(solved and full)
    raw_tau = np.asarray(tau, dtype=float).copy() if valid_tau else None
    sent = np.clip(raw_tau, -limits, limits) if valid else np.zeros_like(limits)
    margin = limits - np.abs(raw_tau) if valid_tau else None
    raw_gate = np.flatnonzero((limits <= 0.) | (np.abs(raw_tau) >= AUTHORITY_GATE_FRACTION * limits)) if valid else np.empty(0, dtype=int)
    sent_gate = np.flatnonzero((limits <= 0.) | (np.abs(sent) >= AUTHORITY_GATE_FRACTION * limits)) if valid else np.empty(0, dtype=int)
    return {"version": CAPACITY_VERSION, "solver_status_val": status, "solver_exact_solved": solved,
            "raw_tau_finite_correct_shape": bool(valid_tau), "command_valid": valid,
            "health_vector": health.copy(), "healthy_torque_limits_nm": healthy_limits.copy(),
            "effective_capacity_nm": limits, "tau_raw": raw_tau, "tau_sent": sent,
            "saturation_mask": sent != raw_tau if valid else np.zeros_like(limits, dtype=bool),
            "saturated_actuator_indices": np.flatnonzero(sent != raw_tau) if valid else np.empty(0, dtype=int),
            "correction_nm": sent - raw_tau if valid else None,
            "raw_command_bound_margin_nm": margin,
            "raw_command_bound_violation_nm": np.maximum(-margin, 0.) if margin is not None else None,
            "raw_command_within_capacity_exact": bool(np.all(margin >= 0.)) if margin is not None else False,
            "sent_command_bound_margin_nm": limits - np.abs(sent) if valid else None,
            "sent_command_within_capacity_exact": bool(valid and np.all(limits - np.abs(sent) >= 0.)),
            "raw_99_percent_active_indices": raw_gate, "sent_99_percent_active_indices": sent_gate,
            "raw_sent_99_percent_gate_equal": bool(np.array_equal(raw_gate, sent_gate)) if valid else None,
            "invalid_reason": None if valid else "SOLVER_NOT_EXACT_SOLVED" if not solved else "NONFINITE_OR_MALFORMED_RAW_QP_VARIABLES",
            "raw_solution_and_validation_not_modified": True, "invalid_command_zero_is_diagnostic_only": not valid,
            "capacity_interface_ms": (perf_counter() - begin) * 1000.}


class ResidentServo:
    """Original STEP22 six-axis PID, resident scratch and no per-tick adapters."""
    def __init__(self, model):
        self.model = model
        self.q_init = np.zeros(int(model.nq)); self.q_init[3] = 1.
        self.q_reference = np.zeros(int(model.nq))
        self.b_integral = np.zeros(6)
        self.v_reference = np.zeros(6)
        self.feedforward = np.zeros(6)
        self.d = 0.
        self.configuration = "S22_POSE_PID"
        self.gains = dict(GAINS[self.configuration])
        self.pose_error_calls = self.integral_update_calls = 0

    def reset(self, q_init, d=0., integral=None):
        values = np.asarray(q_init, dtype=float)
        b = np.zeros(6) if integral is None else np.asarray(integral, dtype=float)
        if (values.shape != self.q_init.shape or not np.isfinite(values).all()
                or not np.isclose(np.linalg.norm(values[3:7]), 1., atol=1e-10)
                or b.shape != (6,) or not np.isfinite(b).all() or np.any(np.abs(b) > INTEGRAL_LIMITS)
                or not np.isfinite(d)):
            raise ValueError("STEP27 servo reset reference/integral is malformed")
        self.q_init[:] = values
        self.d = float(d)
        self.b_integral[:] = b

    def compute(self, controller, data, health, tick):
        begin = perf_counter()
        if int(tick) != tick or tick < 0:
            raise ValueError("STEP27 tick must be a nonnegative integer")
        h = controller._health(health)
        before = self.b_integral.copy()
        ref = reference(float(self.q_init[0]), self.d, int(tick) * CONTROL_DT_S)
        finite = bool(np.isfinite(data.qpos).all() and np.isfinite(data.qvel).all()
                      and np.isfinite(before).all())
        e_pose = e_vel = a_base = target = None
        if finite:
            self.q_reference[:] = data.qpos
            self.q_reference[:7] = self.q_init[:7]
            self.q_reference[0] = ref["p_ref_m"]
            e_pose = tangent_pose_error(self.model, data.qpos, self.q_reference)
            self.pose_error_calls += 1
            self.v_reference.fill(0.); self.v_reference[0] = ref["v_ref_m_s"]
            self.feedforward.fill(0.); self.feedforward[0] = ref["a_ref_m_s2"]
            e_vel = self.v_reference - data.qvel[:6]
            a_base = self.feedforward + self.gains["kp_s_inv2"] * e_pose + self.gains["kd_s_inv"] * e_vel + before
            target = {"desired_base_accel": a_base, "desired_joint_accel": np.zeros(int(self.model.nu)),
                      "task_weights": np.ones(6 + int(self.model.nu)), "servo_configuration": self.configuration,
                      "com_velocity": ref["v_ref_m_s"], "com_height": float(self.q_init[2]),
                      "p_max": 1., "target_position": ref["p_ref_m"]}
            raw = controller.compute(data, "B1", h, target)
        else:
            raw = {"success": False, "status": "NONFINITE_INPUT_STATE", "status_val": None,
                   "tau": None, "qdd": None, "contact_force": None, "validation": {}, "solver_calls": 0}
        interface = _capacity({**raw, "nv": int(self.model.nv)}, h, controller._healthy_limits, raw.get("status_val"))
        valid = bool(interface["command_valid"])
        sent = interface["tau_sent"]
        active = interface["sent_99_percent_active_indices"]
        updated = bool(valid and finite and not len(active))
        reason = "NONFINITE_STATE" if not finite else "INVALID_COMMAND" if not valid else "ACTUATOR_AUTHORITY_SATURATED" if len(active) else None
        proposed = before + CONTROL_DT_S * self.gains["ki_s_inv3"] * e_pose if finite else None
        if updated:
            self.b_integral[:] = np.clip(proposed, -INTEGRAL_LIMITS, INTEGRAL_LIMITS)
            self.integral_update_calls += 1
        record = {"b_used": before, "b_before": before.copy(), "b_after": self.b_integral.copy(),
                  "freeze_reason": reason, "updated": updated, "limits": INTEGRAL_LIMITS.copy(),
                  "authority_gate_saturated_actuators": active.copy(), "authority_gate_fraction": AUTHORITY_GATE_FRACTION,
                  "current_health_torque_limits_nm": interface["effective_capacity_nm"],
                  "zero_capacity_saturated_actuators": np.flatnonzero(interface["effective_capacity_nm"] <= 0.),
                  "state_unit": ["m/s^2"] * 3 + ["rad/s^2"] * 3,
                  "qp_calls_this_tick": int(finite), "update_uses_current_pose_error_after_single_qp": True,
                  "raw_authority_gate_saturated_actuators": interface["raw_99_percent_active_indices"],
                  "sent_authority_gate_saturated_actuators": active,
                  "raw_sent_authority_gate_equal": interface["raw_sent_99_percent_gate_equal"],
                  "capacity_interface_version": CAPACITY_VERSION,
                  "six_axis_updated": [updated] * 6, "six_axis_frozen": [not updated] * 6,
                  "six_axis_freeze_reasons": [reason] * 6,
                  "proposed_unclipped_b_after": proposed,
                  "six_axis_clipped": (updated & (np.abs(proposed) > INTEGRAL_LIMITS)) if proposed is not None else np.zeros(6, dtype=bool)}
        # Raw/algebraic residuals remain validated before send.  Their detailed
        # per-axis matrix explanation is materialized only post-ready.
        diagnostics = {"available": False, "raw_qdd_is_actual_acceleration": False}
        if valid:
            meta = getattr(controller, "last_meta", {})
            if meta:
                residual = meta["M"] @ raw["qdd"] + meta["bias"] - meta["B"] @ sent - meta["Jc"].T @ raw["contact_force"]
                diagnostics.update(available=True, sent_dynamics_residual_inf=float(np.max(np.abs(residual))),
                                   sent_dynamics_residual_signed=residual,
                                   raw_qp_base_acceleration_error=np.asarray(raw["qdd"][:6]) - a_base)
                if not np.isfinite(residual).all():
                    raise ValueError("STEP27 sent residual is nonfinite")
        latency = (perf_counter() - begin) * 1000.
        pre_send = {"exact_solved": interface["solver_exact_solved"],
                    "finite_shape_correct_full_raw_variables": valid,
                    "sent_within_full_channel_capacity": interface["sent_command_within_capacity_exact"],
                    "raw_residuals_evaluated_before_send": bool(raw.get("validation")),
                    "sent_residual_finite": bool(diagnostics["available"]),
                    "no_new_residual_threshold": True}
        return {"wbc": raw, "wb": raw, "raw_solver_result": raw,
                "raw_solver_variables": {"tau": raw.get("tau"), "qdd": raw.get("qdd"),
                                         "contact_force": raw.get("contact_force"), "source": "ORIGINAL_DECODED_RAW_QP"},
                "capacity_interface": interface, "raw_QP_success": bool(raw.get("success")),
                "raw_QP_bound_exact_pass": interface["raw_command_within_capacity_exact"],
                "tau_cmd": sent, "valid_command": valid, "latency_ms": latency, "command_ready_ms": latency,
                "configuration": self.configuration, "external_reference": ref,
                "q_reference": self.q_reference.copy() if finite else None,
                "measured_p_m": float(data.qpos[0]) if finite else None,
                "measured_v_m_s": float(data.qvel[0]) if finite else None,
                "e_pose": e_pose, "e_vel": e_vel, "v_reference": self.v_reference.copy() if finite else None,
                "a_feedforward": self.feedforward.copy() if finite else None, "a_base_ref": a_base,
                "target_before_method_transform": target, "integral_record": record,
                "execution_diagnostics": diagnostics,
                "pre_send_validation": pre_send,
                "timing": {"assembly_ms": raw.get("kernel_assembly_ms"),
                           "decode_ms": raw.get("kernel_decode_ms"),
                           "setup_ms": 1000. * float(raw.get("setup_time_s") or 0.),
                           "update_ms": 1000. * float(raw.get("update_time_s") or 0.),
                           "solve_wall_ms": 1000. * float(raw.get("solve_wall_time_s") or 0.),
                           "capacity_interface_ms": interface["capacity_interface_ms"],
                           "servo_control_ms": latency},
                "execution_view": {"command_valid": valid, "tau_sent": sent, "version": CAPACITY_VERSION}}


class ResidentPolicy:
    """Persistent fixed-anchor backup and memory; no reset between ticks."""
    def __init__(self, model, variant):
        self.controller = ResidentWBC(model, variant=variant)
        self.servo = ResidentServo(model)
        self.backup_id = "UNINITIALIZED"
        self._anchor_q_init = np.zeros(int(model.nq))
        self._anchor_q_init[3] = 1.

    @property
    def anchor_q_init(self):
        return self._anchor_q_init.copy()

    def reset(self, anchor, backup_id):
        if not isinstance(backup_id, str) or not backup_id:
            raise ValueError("STEP27 fixed backup ID is missing")
        self.servo.reset(anchor, 0.)
        self._anchor_q_init[:] = self.servo.q_init
        self.backup_id = backup_id
        reset_workspace_warmstart(self.controller)

    def compute(self, data, health, slot):
        response = self.servo.compute(self.controller, data, health, slot)
        response.update(backup_id=self.backup_id, backup_version=HOLD_VERSION,
                        fixed_anchor_q_init=self._anchor_q_init.copy())
        return response


class ResidentKernel:
    """Two resident data/controller/servo owners with explicit case boundaries."""
    def __init__(self, model, variant="K_RESIDENT", budget=None):
        begin = perf_counter()
        if variant not in VARIANTS:
            raise ValueError("unknown STEP27 kernel variant")
        self.model = model; self.variant = variant; self.budget = budget
        self.version = VERSION
        self.kernel_name = variant
        self.solver_time_limit_s = SOLVER_TIME_LIMIT_S if variant == "K_BUDGETED" else None
        self.data = mujoco.MjData(model)
        self.backup_data = mujoco.MjData(model)
        self.nominal_controller = ResidentWBC(model, variant=variant)
        self.nominal_servo = ResidentServo(model)
        self.policy = ResidentPolicy(model, variant)
        self.backup_controller = self.policy.controller
        self.backup_servo = self.policy.servo
        self.healthy_limits = self.nominal_controller._healthy_limits
        self.limits = self.healthy_limits
        self.mapping = extract_actuator_audit(model)
        self.mapping_info = self.nominal_controller.mapping_info
        self._context_id = None; self._backup_context_id = None; self._last_backup_slot = None
        self._last_backup_response = None
        self.reset_calls = self.backup_reset_calls = 0
        self._base_id = next((int(mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, name))
                             for name in ("base", "base_link", "trunk")
                             if int(mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, name)) >= 0), 1 if int(model.nbody) > 1 else 0)
        self._foot_ids = dict(zip(FOOT_NAMES, self.nominal_controller._foot_geom_ids))
        self._foot_by_geom = {geom: name for name, geom in self._foot_ids.items()}
        self._wrench = np.zeros(6)
        self._limited = tuple((int(model.jnt_qposadr[j]), float(model.jnt_range[j, 0]), float(model.jnt_range[j, 1]))
                              for j in range(int(model.njnt)) if bool(model.jnt_limited[j]))
        self.cold_construction_ms = (perf_counter() - begin) * 1000.

    def _bind(self, controller, budget, kind, owner, first_mode=None):
        active = self.budget if budget is None else budget
        if active is not None:
            active.check()
        controller.solve_callback = active.qp_callback(kind, owner, first_mode) if active is not None else None

    def reset(self, context):
        _copy_integration(self.model, self.data, context)
        self.nominal_servo.reset(context["nominal_q_init"], context["nominal_d_m"], context["nominal_b_used"])
        reset_workspace_warmstart(self.nominal_controller)
        self._context_id = str(context["context_id"])
        self.reset_calls += 1
        return self.data

    def reset_backup(self, current, context, preserve_ready=False):
        identity = str(context["context_id"])
        if preserve_ready:
            if (self._backup_context_id != identity or self.policy.backup_id != context["backup_id"]
                    or self._last_backup_slot != 0 or self._last_backup_response is None
                    or not np.array_equal(self.policy.servo.b_integral,
                        self._last_backup_response["integral_record"]["b_after"])
                    or not np.array_equal(context["health_vector"],
                        self._last_backup_response["capacity_interface"]["health_vector"])
                    or not np.array_equal(context.get("backup_anchor_q_init", self.policy.anchor_q_init),
                                          self.policy.anchor_q_init)):
                raise ValueError("STEP27 ready backup identity/integral mismatch")
            return self.backup_data
        if "state" in context or "source_state" in context:
            _copy_integration(self.model, self.backup_data, context)
        else:
            mujoco.mj_copyData(self.backup_data, self.model, current)
            self.backup_data.time = 0.
            mujoco.mj_forward(self.model, self.backup_data)
        anchor = context.get("backup_anchor_q_init", self.backup_data.qpos)
        self.policy.reset(anchor, context["backup_id"])
        self._backup_context_id = identity; self._last_backup_slot = None
        self._last_backup_response = None
        self.backup_reset_calls += 1
        return self.backup_data

    def physical_fact(self, data, context, interface, latency_ms=0., slot=0, step=0):
        """Only original physical numeric facts; no cached evaluator/solver label."""
        contacts = {name: {"present": False, "contact_count": 0, "normal_force_n": 0.,
                          "tangential_force_n": 0., "friction_mu": 0., "friction_margin_n": 0.,
                          "force_frame": "contact_local"} for name in FOOT_NAMES}
        for index in range(int(data.ncon)):
            contact = data.contact[index]
            g1, g2 = int(contact.geom1), int(contact.geom2)
            name = self._foot_by_geom.get(g2, self._foot_by_geom.get(g1))
            if name is None:
                continue
            sign = 1. if g2 in self._foot_by_geom else -1.
            self._wrench.fill(0.)
            mujoco.mj_contactForce(self.model, data, index, self._wrench)
            normal = sign * float(self._wrench[0])
            tangential = float(np.linalg.norm(self._wrench[1:3]))
            mu = float(contact.friction[0])
            item = contacts[name]
            item.update(present=True, contact_count=item["contact_count"] + 1,
                        normal_force_n=item["normal_force_n"] + normal,
                        tangential_force_n=item["tangential_force_n"] + tangential,
                        friction_mu=mu, friction_margin_n=item["friction_margin_n"] + mu * normal - tangential)
        w, x, y, z = map(float, data.qpos[3:7])
        roll = math.atan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y))
        pitch = math.asin(max(-1., min(1., 2 * (w * y - z * x))))
        hv = np.asarray(context["health_vector"], dtype=float)
        if hv.shape != self.healthy_limits.shape or not np.isfinite(hv).all() or np.any((hv < 0.) | (hv > 1.)):
            raise ValueError("STEP27 full health vector malformed")
        row = {"scenario_id": context["context_id"], "context_id": context["context_id"],
               "qpos": data.qpos.copy(), "qvel": data.qvel.copy(),
               "subtree_com": data.subtree_com[self._base_id].copy(), "base_body_id": self._base_id,
               "subtree_com_height_m": float(data.subtree_com[self._base_id, 2]),
               "base_joint_height_m": float(data.qpos[2]), "roll": roll, "pitch": pitch,
               "contacts": contacts,
               "joint_limit_margins": np.asarray([min(float(data.qpos[a]) - lo, hi - float(data.qpos[a])) for a, lo, hi in self._limited]),
               "health_vector": hv.copy(), "actuator_limits": self.healthy_limits.copy(),
               "tau_cmd": np.asarray(interface["tau_sent"]).copy(), "tau_sent": np.asarray(interface["tau_sent"]).copy(),
               "tau_raw": interface["tau_raw"], "tau_applied": data.actuator_force.copy(),
               "effective_capacity_nm": interface["effective_capacity_nm"],
               "actual_mujoco_qacc": data.qacc.copy(), "global_boundary_margin_m": 1. - float(data.qpos[0]),
               "boundary_margin_m": 1. - float(data.qpos[0]), "friction_coeff": .5,
               "velocity_x_m_s": float(data.qvel[0]), "velocity_y_m_s": float(data.qvel[1]),
               "backup_id": context["backup_id"], "time_s": step * .002, "physics_step": step,
               "tick": slot, "simulation_time_s": float(data.time), "latency_ms": latency_ms}
        for key in ("faulted_actuator_name", "faulted_actuator_index", "faulted_health"):
            if key in context:
                row[key] = context[key]
        return row

    def nominal(self, context, budget=None, kind="NOMINAL", owner=None):
        begin = perf_counter()
        if self._context_id != str(context["context_id"]):
            raise ValueError("STEP27 nominal requires reset to this independent context")
        self._bind(self.nominal_controller, budget, kind, owner or context["context_id"])
        cursor = len(self.nominal_controller.solver_ledger)
        response = self.nominal_servo.compute(self.nominal_controller, self.data, context["health_vector"], context["source_tick"])
        interface = response["capacity_interface"]
        self.data.ctrl[:] = response["tau_cmd"]
        forward_begin = perf_counter(); mujoco.mj_forward(self.model, self.data)
        forward_s = perf_counter() - forward_begin
        fact = self.physical_fact(self.data, context, interface, response["latency_ms"]) if _finite_state(self.data) else None
        physical = predicted_physical_check(fact or {})
        ledger = self.nominal_controller.solver_ledger[cursor:]
        response["solver_ledger_delta"] = ledger
        response["pre_send_validation"]["current_physical_check"] = physical
        raw = response["wbc"]
        points = self.nominal_controller.last_trace.get("points")
        foot_positions = {name: np.asarray(points[i]).copy() for i, name in enumerate(FOOT_NAMES)} if points is not None and np.shape(points) == (4, 3) else None
        elapsed = (perf_counter() - begin) * 1000.
        return {"schema": VERSION, "kernel_variant": self.variant,
                "health_vector": np.asarray(context["health_vector"]).copy(),
                **{key: context[key] for key in ("context_id", "faulted_actuator_name", "faulted_actuator_index", "faulted_health") if key in context},
                "command_valid": bool(response["valid_command"]), "tau": response["tau_cmd"],
                "tau_raw": interface["tau_raw"], "tau_sent": response["tau_cmd"], "capacity_interface": interface,
                "generation_ms": elapsed, "command_ready_ms": elapsed, "response": response,
                "raw_solver_result": raw, "solver_status": raw.get("status"), "solver_status_val": raw.get("status_val"),
                "raw_solver_variables": response["raw_solver_variables"], "qdd": raw.get("qdd"),
                "contact_lambda": raw.get("contact_force"), "QP_validation": raw.get("validation"),
                "raw_QP_success": bool(raw.get("success")), "raw_QP_bound_exact_pass": interface["raw_command_within_capacity_exact"],
                "sent_command_exact_pass": interface["sent_command_within_capacity_exact"],
                "assembly": self.nominal_controller.last_trace, "solver_ledger": ledger,
                "execution_diagnostics": response["execution_diagnostics"], "initial_new_command_fact": fact,
                "current_physical_check": physical, "foot_positions": foot_positions,
                "actual_mujoco_qacc": self.data.qacc.copy(), "source_b_used": np.asarray(context["nominal_b_used"]).copy(),
                "backup_initial_b": np.zeros(6), "nominal_d_m": context["nominal_d_m"],
                "counts": {"nominal_qp_calls": len(ledger), "control_qp_calls": len(ledger), "clone_data_calls": 0,
                           "nominal_controller_instances": 0, "nominal_command_diagnostic_forward_calls": 1},
                "timing": {**response["timing"], "control_total_ms": response["latency_ms"], "action_conditioned_forward_s": forward_s,
                           "solver_wall_s": sum(float(row.get("solve_wall_time_s") or 0.) for row in ledger),
                           "capacity_interface_ms": interface["capacity_interface_ms"]}}

    def compute_backup(self, context, slot, budget=None, kind="ACTUAL_B", owner=None):
        begin = perf_counter()
        if self._backup_context_id != str(context["context_id"]) or self.policy.backup_id != context["backup_id"]:
            raise ValueError("STEP27 backup context/ID mismatch")
        if self._last_backup_slot is not None and int(slot) != self._last_backup_slot + 1:
            raise ValueError("STEP27 backup feedback slots must advance without reset/repeat")
        if self._last_backup_slot is None and int(slot) not in (0, 1):
            raise ValueError("STEP27 first backup slot must be B0 or C1")
        self._bind(self.policy.controller, budget, kind, owner or context["context_id"], "BACKUP")
        cursor = len(self.policy.controller.solver_ledger)
        response = self.policy.compute(self.backup_data, context["health_vector"], slot)
        # Required same-command finite/physical facts stay inside the complete
        # ready interval.  A physical failure remains an experimental outcome,
        # not a numerical status rescue or a reason to mutate the sent torque.
        self.backup_data.ctrl[:] = response["tau_cmd"]
        forward_begin = perf_counter()
        mujoco.mj_forward(self.model, self.backup_data)
        forward_s = perf_counter() - forward_begin
        fact = self.physical_fact(self.backup_data, context, response["capacity_interface"],
                                  response["latency_ms"], int(slot), int(slot) * 10) if _finite_state(self.backup_data) else None
        response["current_physical_check"] = predicted_physical_check(fact or {})
        response["pre_send_validation"]["current_physical_check"] = response["current_physical_check"]
        response["initial_new_command_fact"] = fact
        response["timing"] = {**response["timing"], "control_total_ms": response["latency_ms"],
                              "action_conditioned_forward_s": forward_s,
                              "capacity_interface_ms": response["capacity_interface"]["capacity_interface_ms"]}
        response["solver_ledger_delta"] = self.policy.controller.solver_ledger[cursor:]
        response["command_ready_ms"] = (perf_counter() - begin) * 1000.
        response["latency_ms"] = response["command_ready_ms"]
        response["kernel_variant"] = self.variant
        self._last_backup_slot = int(slot); self._last_backup_response = response
        return response

    def backup_compute(self, data, health, slot):
        """Policy-compatible direct call; orchestration uses compute_backup."""
        return self.policy.compute(data, health, slot)

    def post_ready_nominal(self, record):
        """Freeze and JSON-materialize evidence only after the ready timer."""
        record["assembly"] = self.nominal_controller.diagnostic_snapshot()
        return _json_safe(record)


def specification():
    return {"version": VERSION, "variants": list(VARIANTS), "deadline_ms": 20,
            "osqp_eps_abs": 1e-7, "osqp_eps_rel": 1e-7, "osqp_max_iter": 20000,
            "polishing": True, "K_BUDGETED_time_limit_s_per_call": SOLVER_TIME_LIMIT_S,
            "native_api": "installed osqp.OSQP Python/native extension; setup/update_settings(time_limit)",
            "QP_math": "original STEP22 B1 contact SVD/bias minus passive, no loss feedforward",
            "PID": dict(GAINS["S22_POSE_PID"]), "integral_limit": INTEGRAL_LIMITS.tolist(),
            "authority_fraction": AUTHORITY_GATE_FRACTION, "raw_solver_gate": "status_val=1 and finite shape-correct full qdd/tau/lambda",
            "independent_case_reset": "complete integration state + nominal reference/b_used or backup fixed anchor/b0; cached solver structure retained but primal and dual zeroed",
            "feedback_rule": "same trajectory retains backup servo b_integral and solver primal/dual each tick; first B0 or C1 then strictly consecutive",
            "pre_ready": ["state/input validation", "QP assembly and solve", "finite raw variables", "raw residual evaluation",
                          "declared capacity clip", "sent residual finite check", "current numeric physical check", "PID gate/update"],
            "post_ready": ["detailed matrix snapshot", "JSON materialization", "hash generation", "disk writes", "ledger batch flush"],
            "ledger": "DynamicWBC._invoke emits every true invocation to buffered before/after budget callback",
            "no_retry": True, "time_limit_is_not_total_walltime_guarantee": True}
