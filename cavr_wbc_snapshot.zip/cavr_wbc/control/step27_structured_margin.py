"""STEP27 current-input continuous margins and empirical local support.

Deployment uses numeric arrays only. Source-bank labels are consumed solely by
the DEV loader/fitter; neither ``predict`` nor ``decide`` reads trajectories.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Mapping

import numpy as np

from cavr_wbc.experiments.step26_features_storage import _compiled_mapping, _feet, _vector, load_bank
from cavr_wbc.evaluation.step25_actual import evaluate_actual
from cavr_wbc.evaluation.step23_actual import actual_reasons


VERSION = "STEP27_STRUCTURED_MARGIN_V1"
FEATURE_NAMES = (
    "direction_vx_m_s", "direction_current_nominal_actual_ax_m_s2", "roll_rad",
    "direction_pitch_rad", "roll_rate_rad_s", "direction_pitch_rate_rad_s",
    "subtree_com_height_m", "direction_side_foot_relative_x_min_m", "fault_health",
    "fault_is_thigh", "fault_is_calf", "sent_capacity_utilization_max",
    "direction_desired_ax_m_s2", "direction_side_joint_velocity_mean_rad_s", "vy_m_s", "vz_m_s",
)
GAPS_M = (.001, .002, .004, .008, .016, .032)
CONFIGURATIONS = tuple((family, k) for family in ("linear", "quadratic") for k in (3, 5))
DISTANCE_FLOOR = 1e-12
D_SCALE_M = .01


def feature_specification():
    return {
        "schema": VERSION, "count": 16, "names": list(FEATURE_NAMES),
        "direction": "sign(current vx); abs(vx)>=0.01 m/s",
        "direction_side_joints": "compiled FR hip/thigh/calf for vx>0; RR for vx<0",
        "direction_side_feet": "FR+FL for vx>0; RR+RL for vx<0; minimum of sign(vx)*(foot_x-base_x)",
        "direction_normalized": ["vx", "actual_ax", "pitch", "pitch_rate", "desired_ax"],
        "joint_velocity_mean": "unmodified mean of the three compiled direction-side joint velocities",
        "healthy": "fault_health=1; thigh=calf=0; full 12-channel health retained and checked",
        "current_acceleration": "MuJoCo forward qacc under current nominal sent torque, not WBC desired qdd",
        "utilization": "max(abs(sent torque)/(full health*compiled healthy torque limit))",
        "forbidden_inputs": ["episode", "tick", "split", "future trajectory", "label", "gap"],
        "missing_features": "explicit missing record or input rejection; no zero-vector imputation",
    }


def extract_features(context, nominal, mapping):
    """Exactly 16 finite features; full health and compiled metadata are checked."""
    fact = nominal["initial_new_command_fact"]
    state = context.get("state", context)
    qpos = _vector(state.get("qpos", fact.get("qpos")), "current qpos")
    qvel = _vector(state.get("qvel", fact.get("qvel")), "current qvel")
    if qpos.size < 7 or qvel.size < 6 or abs(qvel[0]) < .01:
        raise ValueError("STEP27 requires a free-joint current state with abs(vx)>=0.01")
    direction = 1. if qvel[0] > 0. else -1.
    entries = _compiled_mapping(mapping)
    side = "FR" if direction > 0. else "RR"
    side_entries = [entry for entry in entries if entry["name"] in
                    (side+"_hip", side+"_thigh", side+"_calf")]
    if len(side_entries) != 3:
        raise ValueError("compiled direction-side actuator mapping missing")
    dofs = [entry.get("dof_index", entry.get("dof_address")) for entry in side_entries]
    if any(not isinstance(index, (int, np.integer)) or not 0 <= index < qvel.size for index in dofs):
        raise ValueError("invalid compiled direction-side joint velocity addresses")
    health = _vector(fact.get("health_vector", nominal.get("health_vector")), "full health", 12)
    if np.any((health < 0.) | (health > 1.)):
        raise ValueError("full health vector outside [0,1]")
    if "health_vector" in context and not np.array_equal(health, _vector(context["health_vector"], "context health", 12)):
        raise ValueError("current nominal fact/context health mismatch")
    fault = nominal.get("faulted_actuator_index", context.get("faulted_actuator_index", fact.get("faulted_actuator_index")))
    fault_name = nominal.get("faulted_actuator_name", context.get("faulted_actuator_name", fact.get("faulted_actuator_name")))
    fault_health = 1.; thigh = calf = 0.
    if np.any(health < 1.):
        if not isinstance(fault, (int, np.integer)) or int(fault) not in [e["index"] for e in side_entries]:
            raise ValueError("degraded health requires an explicit compiled direction-side fault")
        if np.count_nonzero(health < 1.) != 1 or health[int(fault)] >= 1.:
            raise ValueError("fault declaration/full health vector mismatch")
        name = entries[int(fault)]["name"]
        if fault_name != name:
            raise ValueError("fault name/compiled channel mismatch")
        if name not in (side+"_thigh", side+"_calf"):
            raise ValueError("STEP27 fault must be direction-side thigh or calf")
        fault_health = float(health[int(fault)])
        thigh = float(name.endswith("_thigh")); calf = float(name.endswith("_calf"))
    elif fault is not None or fault_name not in (None, "NONE"):
        raise ValueError("healthy current input must not declare a fault channel")
    sent = _vector(nominal.get("tau_sent", nominal.get("tau", fact.get("tau_sent", fact.get("tau_cmd")))), "current sent torque", 12)
    limits = fact.get("actuator_limits")
    if limits is None:
        limits = [e.get("healthy_limit_nm", e.get("healthy_torque_limit_nm")) for e in entries]
    capacities = health * _vector(limits, "compiled healthy torque limits", 12)
    if np.any(capacities <= 0.):
        raise ValueError("positive effective capacities required for fixed STEP27 health levels")
    recorded_capacity = fact.get("effective_capacity_nm", nominal.get("capacity_interface", {}).get("effective_capacity_nm"))
    if recorded_capacity is not None and not np.array_equal(capacities, _vector(recorded_capacity, "recorded capacity", 12)):
        raise ValueError("effective capacities differ from compiled limits/full health")
    com = np.asarray(fact["subtree_com"], dtype=float)
    if com.ndim == 2:
        com = com[int(fact["base_body_id"])]
    com = _vector(com, "current subtree COM", 3)
    # _feet fixes ordering FL, FR, RL, RR, accepting compiled *_foot names.
    feet = _feet(fact, nominal, None)
    side_feet = feet[[0, 1] if direction > 0. else [2, 3], 0]
    actual = _vector(fact.get("actual_mujoco_qacc", nominal.get("actual_mujoco_qacc")), "current actual qacc")
    desired = _vector(nominal["response"]["a_base_ref"], "current desired base acceleration", 6)
    if actual.size < 6:
        raise ValueError("current MuJoCo qacc must include six base components")
    return _vector([direction*qvel[0], direction*actual[0], fact["roll"], direction*fact["pitch"],
                    qvel[3], direction*qvel[4], com[2], np.min(direction*(side_feet-qpos[0])),
                    fault_health, thigh, calf, np.max(np.abs(sent)/capacities), direction*desired[0],
                    np.mean(qvel[dofs]), qvel[1], qvel[2]], "STEP27 current features", 16)


def labels(branch, context):
    """Independent complete 501-state D/G_T labels; failed prefixes stay missing."""
    anchor = context.get("backup_anchor_q_init", context.get("state", context).get("qpos"))
    anchor = _vector(anchor, "fixed backup anchor")
    velocity = _vector(context.get("state", context)["qvel"], "current velocity")
    if abs(velocity[0]) < .01:
        raise ValueError("directional label requires abs(current vx)>=0.01")
    direction = 1. if velocity[0] > 0. else -1.
    evaluated = evaluate_actual(branch, anchor.tolist(), context)
    rows = ([branch["initial_fact"]] if branch.get("initial_fact") is not None else []) + list(branch.get("physics_trajectory", []))
    full_grid = (len(rows) == 501 and [row.get("physics_step") for row in rows] == list(range(501))
                 and all("qpos" in row and "qvel" in row and not row.get("numerical_failure") for row in rows))
    complete = bool(evaluated["complete"] and full_grid)
    controls = branch.get("controls", [])
    command_valid = bool(complete and len(controls) == 50 and all(c.get("valid_command") is True for c in controls))
    out = {"trajectory_id": branch.get("branch_id"), "status": branch.get("status"), "complete": complete,
           "D": None, "D_m": None, "G_T": None, "original_physical": bool(complete and evaluated["actual_safe_all_physics_states"]),
           "original_terminal": bool(complete and evaluated["actual_terminal_pass"]),
           "valid": bool(complete and evaluated["actual_safe_and_terminal"] and command_valid),
           "command_valid_all": command_valid, "endpoint_original_physical": False,
           "evaluation": evaluated, "full_501_grid": full_grid, "progress20_m": None,
           "endpoint_progress_m": None, "reason": branch.get("reason"),
           "original_physical_safe": bool(complete and evaluated["actual_safe_all_physics_states"]),
           "terminal_pass": bool(complete and evaluated["actual_terminal_pass"]),
           "original_failure": evaluated.get("first_physical_failure"),
           "observed_original_physical_failure": bool(evaluated.get("physical_failure_state_count", 0))}
    if not complete:
        return out
    qpos = np.asarray([row["qpos"] for row in rows], dtype=float)
    qvel = np.asarray([row["qvel"] for row in rows], dtype=float)
    if not np.isfinite(qpos).all() or not np.isfinite(qvel).all():
        raise ValueError("complete trajectory contains nonfinite state")
    last = rows[-1]
    terminal_terms = {"x_error": abs(qpos[-1, 0]-anchor[0])/.002,
                      "vx": abs(qvel[-1, 0])/.001, "vy": abs(qvel[-1, 1])/.25,
                      "roll": abs(float(last["roll"]))/ .2, "pitch": abs(float(last["pitch"]))/ .2}
    g_t = max(terminal_terms.values())-1.
    endpoint_physical = not actual_reasons(last)
    numerical_terminal = g_t <= 0.
    if bool(numerical_terminal and endpoint_physical) != bool(evaluated["actual_terminal_pass"]):
        raise ValueError("STEP27 terminal formula differs from the frozen actual evaluator")
    d_m = max(0., float(np.max(direction*(qpos[:, 0]-anchor[0]))))
    out.update(D=d_m, D_m=d_m, G_T=float(g_t), terminal_terms=terminal_terms,
               endpoint_original_physical=endpoint_physical,
               progress20_m=float(direction*(qpos[10, 0]-anchor[0])),
               endpoint_progress_m=float(direction*(qpos[-1, 0]-anchor[0])))
    return out


def load_dev(source_dir, mapping):
    """Read each unique old context/trajectory once, reclassifying all as DEV."""
    source_dir = Path(source_dir).resolve()
    registry = json.loads((source_dir/"SPLIT_REGISTRY.json").read_text(encoding="utf-8"))
    registry = sorted(registry, key=lambda row: (row["episode_id"], row["context"]["source_tick"], row["context"]["health_kind"], row["context_id"]))
    records = []; seen = {}; trajectory_cache = {}
    for source in registry:
        context = source["context"]
        displacement = float(context["nominal_d_m"])
        magnitude = abs(displacement)
        split = "CAL" if np.isclose(magnitude, .06, atol=1e-12, rtol=0.) else "TRAIN"
        if not any(np.isclose(magnitude, value, atol=1e-12, rtol=0.) for value in (.04, .06, .08)):
            raise ValueError("source DEV context outside the fixed ±40/60/80 mm episode registry")
        identity = (round(displacement, 12), int(context["source_tick"]), tuple(context["health_vector"]))
        if identity in seen:
            seen[identity]["source_alias_ids"].append(source["context_id"])
            continue
        directory = source_dir/source["bank_directory"]
        current_path = directory/"CURRENT_INPUT.json"
        current = json.loads(current_path.read_text(encoding="utf-8"))
        feature_error = None
        try:
            features = extract_features(current["context"], current["nominal"], mapping).tolist()
        except (ValueError, KeyError, TypeError, IndexError) as exc:
            features = None; feature_error = type(exc).__name__+": "+str(exc)
        branch_labels = {}; source_paths = {"current": str(current_path)}
        for mode in ("C", "B"):
            path = directory/(mode+".npz")
            trajectory_key = str(path.resolve())
            if trajectory_key not in trajectory_cache:
                trajectory_cache[trajectory_key] = labels(load_bank(path), current["context"])
            branch_labels[mode] = trajectory_cache[trajectory_key]
            source_paths[mode] = str(path)
        record = {"id": source["context_id"], "context_id": source["context_id"], "split": split,
                  "source_previous_split": source["split"], "all_source_data_role": "DEV",
                  "context": current["context"], "features": features, "feature_error": feature_error,
                  "labels": branch_labels, "source_paths": source_paths, "source_alias_ids": [],
                  "current_candidate_valid": bool(current["nominal"].get("command_valid")),
                  "current_physical_pass": bool(current["nominal"].get("current_physical_check", {}).get("pass")),
                  "source_trajectory_ids": {mode: branch_labels[mode]["trajectory_id"] for mode in ("C", "B")}}
        seen[identity] = record; records.append(record)
    return records


def _finite_features(record):
    try:
        return _vector(record["features"], "record features", 16)
    except (ValueError, TypeError, KeyError):
        return None


def _scaler(train_features):
    mean = np.mean(train_features, axis=0)
    scale = np.std(train_features, axis=0, ddof=0)
    scale[scale == 0.] = 1.
    return mean, scale


def _powers(family):
    result = [np.eye(16, dtype=np.int64)[j] for j in range(16)]
    if family == "quadratic":
        result += [np.eye(16, dtype=np.int64)[i]+np.eye(16, dtype=np.int64)[j]
                   for i in range(16) for j in range(i, 16)]
    elif family != "linear":
        raise ValueError("only the two frozen model families are authorized")
    return np.asarray(result, dtype=np.int64)


def _design(z, powers):
    z = np.asarray(z, dtype=float)
    if z.ndim == 1:
        # Fixed linear/quadratic numerical products, without a Python loop or
        # a sklearn transformer on the command-ready path.
        first = np.argmax(powers, axis=1)
        second = np.argmax(powers[:, ::-1], axis=1)
        second = powers.shape[1]-1-second
        return z[first]*np.where(np.sum(powers, axis=1) == 1, 1., z[second])
    return np.prod(np.power(z[:, None, :], powers[None, :, :]), axis=2)


def _ridge(design, target):
    """Ridge(alpha=1, fit_intercept=True), two outputs, no constant feature."""
    xm = design.mean(axis=0); ym = target.mean(axis=0)
    x = design-xm; y = target-ym
    # Exact primal/dual closed-form Ridge; dual avoids a 152x152 solve on small TRAIN.
    if x.shape[0] <= x.shape[1]:
        coefficient = x.T @ np.linalg.solve(x@x.T + np.eye(x.shape[0]), y)
    else:
        coefficient = np.linalg.solve(x.T@x + np.eye(x.shape[1]), x.T@y)
    return coefficient.T, ym-xm@coefficient


def predict(bundle, features):
    """Numeric matrix inference; no sklearn object or source-data access."""
    feature = _vector(features, "current inference features", 16)
    z = (feature-bundle["mean"])/bundle["scale"]
    design = _design(z, bundle["powers"])
    distances = np.sqrt(np.sum((bundle["train_z"]-z)**2, axis=1))
    indices = np.argsort(distances, kind="stable")[:bundle["k"]]
    neighbor_ids = [str(bundle["train_ids"][index]) for index in indices]
    neighbor_distances = [float(distances[index]) for index in indices]
    nearest = float(distances[indices[0]]) if len(indices) else None
    out = {}
    for mode in ("C", "B"):
        model = bundle["branches"][mode]
        estimate = design@model["coefficient"].T+model["intercept"] if model["trained"] else np.array([np.nan, np.nan])
        d_hat = float(estimate[0]*D_SCALE_M) if model["trained"] else None
        g_hat = float(estimate[1]) if model["trained"] else None
        supported = bool(len(indices) == bundle["k"] and np.all(model["train_complete"][indices])
                         and np.all(model["train_physical"][indices]))
        in_domain = bool(nearest is not None and nearest <= bundle["distance_threshold"])
        reasons = []
        if len(indices) != bundle["k"]: reasons.append("INSUFFICIENT_TRAIN_NEIGHBORS")
        if len(indices) and not np.all(model["train_complete"][indices]): reasons.append("NEIGHBOR_NUMERICAL_INCOMPLETE")
        if len(indices) and not np.all(model["train_physical"][indices]): reasons.append("NEIGHBOR_ORIGINAL_PHYSICAL_FAILURE")
        if not in_domain: reasons.append("OUTSIDE_CAL_NEAREST_TRAIN_DISTANCE")
        if not model["trained"]: reasons.append("NO_COMPLETE_TRAIN_LABELS")
        if not model["calibrated"]: reasons.append("NO_COMPLETE_CAL_LABELS")
        out[mode] = {"D_hat": d_hat, "D_hat_m": d_hat, "G_T_hat": g_hat,
                     "U_D": max(0., d_hat)+model["D_residual_margin_m"]+.001 if model["trained"] and model["calibrated"] else None,
                     "U_T": g_hat+model["G_T_residual_margin"]+.05 if model["trained"] and model["calibrated"] else None,
                     "support_gate": supported, "distance_gate": in_domain,
                     "calibration_gate": bool(model["trained"] and model["calibrated"]),
                     "neighbor_ids": neighbor_ids, "neighbor_distances": neighbor_distances,
                     "neighbor_complete": [bool(v) for v in model["train_complete"][indices]],
                     "neighbor_original_physical": [bool(v) for v in model["train_physical"][indices]],
                     "nearest_distance": nearest, "distance_threshold": float(bundle["distance_threshold"]),
                     "reasons": reasons}
    return out


def decide(bundle, features, gap, nominal_command_valid=True):
    if not np.isfinite(gap) or gap < 0.:
        raise ValueError("finite nonnegative gap in metres required")
    try:
        predictions = predict(bundle, features)
    except (ValueError, TypeError, IndexError) as exc:
        return {"choice": "ABSTAIN", "accepted": False, "predictions": {}, "gap_m": float(gap),
                "reject_reasons": ["MISSING_OR_NONFINITE_CURRENT_FEATURES"], "input_error": str(exc)}
    for mode, point in predictions.items():
        point["terminal_gate"] = bool(point["U_T"] is not None and point["U_T"] <= 0.)
        point["local_gate"] = bool(point["U_D"] is not None and point["U_D"] <= gap)
        point["current_command_gate"] = bool(nominal_command_valid or mode == "B")
        if not point["terminal_gate"]: point["reasons"].append("TERMINAL_MARGIN_REJECT")
        if not point["local_gate"]: point["reasons"].append("LOCAL_DISPLACEMENT_MARGIN_REJECT")
        if not point["current_command_gate"]: point["reasons"].append("CURRENT_CANDIDATE_COMMAND_UNAVAILABLE")
        point["accepted"] = all(point[key] for key in ("support_gate", "distance_gate", "calibration_gate", "terminal_gate", "local_gate", "current_command_gate"))
    choice = next((mode for mode in ("C", "B") if predictions[mode]["accepted"]), "ABSTAIN")
    return {"choice": choice, "accepted": choice != "ABSTAIN", "predictions": predictions, "gap_m": float(gap),
            "reject_reasons": [] if choice != "ABSTAIN" else list(dict.fromkeys(reason for point in predictions.values() for reason in point["reasons"]))}


def _safe(label, gap):
    return bool(label["complete"] and label["original_physical"] and label["original_terminal"]
                and label.get("command_valid_all", False) and label["D"] is not None and label["D"] <= gap)


def _cal_metrics(bundle, cal):
    accepted = safe = errors = oracle = c_oracle = c_retained = 0
    error_types = {"physical": 0, "local": 0, "terminal": 0, "numerical_incomplete": 0, "command_unavailable": 0}
    for record in cal:
        for gap in GAPS_M:
            oracle += int(any(_safe(record["labels"][mode], gap) for mode in ("C", "B")))
            c_oracle += int(_safe(record["labels"]["C"], gap) and record.get("current_candidate_valid", True))
            decision = decide(bundle, record["features"], gap, record.get("current_candidate_valid", True))
            if not decision["accepted"]:
                continue
            accepted += 1; label = record["labels"][decision["choice"]]
            if _safe(label, gap):
                safe += 1; c_retained += int(decision["choice"] == "C")
            else:
                errors += 1
                error_types["numerical_incomplete"] += int(not label["complete"])
                error_types["physical"] += int(label["complete"] and not label["original_physical"])
                error_types["terminal"] += int(label["complete"] and not label["original_terminal"])
                error_types["local"] += int(label["D"] is not None and label["D"] > gap)
                error_types["command_unavailable"] += int(not label.get("command_valid_all", False))
    return {"planned_queries": len(cal)*len(GAPS_M), "accepted": accepted, "safe_accepted": safe,
            "error_accepted": errors, "zero_error_acceptance": errors == 0,
            "oracle_safe_queries": oracle, "oracle_safe_coverage": safe/oracle if oracle else 0.,
            "oracle_C_queries": c_oracle, "C_retained": c_retained,
            "C_retention": c_retained/c_oracle if c_oracle else 0., "error_types": error_types,
            "established": bool(accepted > 0 and errors == 0 and oracle > 0 and safe/oracle >= .2 and c_retained > 0)}


def _save_bundle(bundle, directory):
    directory = Path(directory); directory.mkdir(parents=True, exist_ok=True)
    basename = "step27_"+bundle["configuration_id"]
    archive_path = directory/(basename+".npz"); metadata_path = directory/(basename+".json")
    if archive_path.exists() or metadata_path.exists():
        raise FileExistsError("frozen STEP27 model assets may not be overwritten")
    arrays = {key: bundle[key] for key in ("mean", "scale", "powers", "train_z", "train_ids")}
    metadata = {key: bundle[key] for key in ("schema", "configuration_id", "family", "k", "distance_threshold", "cal_max_nearest_distance", "distance_floor", "train_ids_all", "cal_ids_all")}
    metadata["branches"] = {}
    for mode, model in bundle["branches"].items():
        for key in ("coefficient", "intercept", "train_complete", "train_physical"):
            arrays[mode+"_"+key] = model[key]
        metadata["branches"][mode] = {key: model[key] for key in ("trained", "calibrated", "D_residual_margin_m", "G_T_residual_margin", "train_regression_ids", "cal_complete_ids")}
    metadata.update(alpha=1., D_target_scale_m=D_SCALE_M, D_reserve_m=.001, G_T_reserve=.05,
                    standardization="TRAIN-only population standard deviation; constant features scale=1", quadratic_bias=False,
                    support="all finite TRAIN contexts including failed; k neighbors complete+original physical, not terminal",
                    distance="nearest TRAIN distance <= max(3*CAL maximum nearest TRAIN distance,1e-12)",
                    feature_specification=feature_specification())
    with archive_path.open("xb") as stream:
        np.savez_compressed(stream, **arrays)
    metadata_path.write_text(json.dumps(metadata, sort_keys=True, indent=2, allow_nan=False), encoding="utf-8")
    return {"npz": str(archive_path.resolve()), "json": str(metadata_path.resolve()),
            "npz_sha256": hashlib.sha256(archive_path.read_bytes()).hexdigest(),
            "json_sha256": hashlib.sha256(metadata_path.read_bytes()).hexdigest()}


def load_bundle(path):
    path = Path(path)
    if path.is_dir():
        frozen = json.loads((path/"MODEL_FREEZE.json").read_text(encoding="utf-8"))
        path = Path(frozen["assets"][frozen["selected_configuration_id"]]["npz"])
    metadata = json.loads(path.with_suffix(".json").read_text(encoding="utf-8"))
    if metadata["schema"] != VERSION:
        raise ValueError("unsupported STEP27 model version")
    bundle = {key: metadata[key] for key in ("schema", "configuration_id", "family", "k", "distance_threshold", "cal_max_nearest_distance", "distance_floor", "train_ids_all", "cal_ids_all")}
    with np.load(path, allow_pickle=False) as archive:
        bundle.update({key: archive[key].copy() for key in ("mean", "scale", "powers", "train_z", "train_ids")})
        bundle["branches"] = {}
        for mode in ("C", "B"):
            model = dict(metadata["branches"][mode])
            model.update({key: archive[mode+"_"+key].copy() for key in ("coefficient", "intercept", "train_complete", "train_physical")})
            bundle["branches"][mode] = model
    return bundle


def fit_fixed(records, output_dir):
    """Exactly four frozen configs, TRAIN-only fits and complete-CAL margins."""
    if any(record["split"] not in ("TRAIN", "CAL") for record in records):
        raise ValueError("STEP27 fitting refuses new TEST or any split other than TRAIN/CAL")
    if len({record["id"] for record in records}) != len(records):
        raise ValueError("duplicate DEV context IDs")
    train_all = [r for r in records if r["split"] == "TRAIN"]
    cal_all = [r for r in records if r["split"] == "CAL"]
    train = [r for r in train_all if _finite_features(r) is not None]
    cal = [r for r in cal_all if _finite_features(r) is not None]
    if not train:
        raise ValueError("no finite TRAIN current features; cannot freeze a structured model")
    x_train = np.asarray([r["features"] for r in train], dtype=float)
    mean, scale = _scaler(x_train)
    train_z = (x_train-mean)/scale
    cal_z = (np.asarray([r["features"] for r in cal], dtype=float)-mean)/scale if cal else np.empty((0, 16))
    cal_nearest = np.sqrt(np.min(np.sum((cal_z[:, None, :]-train_z[None, :, :])**2, axis=2), axis=1)) if cal else np.empty(0)
    cal_max = float(np.max(cal_nearest)) if len(cal_nearest) else 0.
    distance_threshold = max(3.*cal_max, DISTANCE_FLOOR)
    bundles = {}; metrics = {}; assets = {}
    for family, k in CONFIGURATIONS:
        powers = _powers(family); design_train = _design(train_z, powers); design_cal = _design(cal_z, powers)
        config_id = family+"_k"+str(k)
        bundle = {"schema": VERSION, "configuration_id": config_id, "family": family, "k": k,
                  "mean": mean.copy(), "scale": scale.copy(), "powers": powers, "train_z": train_z.copy(),
                  "train_ids": np.asarray([r["id"] for r in train], dtype=str), "branches": {},
                  "distance_threshold": distance_threshold, "cal_max_nearest_distance": cal_max, "distance_floor": DISTANCE_FLOOR,
                  "train_ids_all": [r["id"] for r in train_all], "cal_ids_all": [r["id"] for r in cal_all]}
        for mode in ("C", "B"):
            train_indices = [j for j, r in enumerate(train) if r["labels"][mode]["complete"]]
            cal_indices = [j for j, r in enumerate(cal) if r["labels"][mode]["complete"]]
            trained = bool(train_indices)
            if trained:
                target = np.asarray([[train[j]["labels"][mode]["D"]/D_SCALE_M, train[j]["labels"][mode]["G_T"]] for j in train_indices], dtype=float)
                if not np.isfinite(target).all():
                    raise ValueError("complete TRAIN target missing/nonfinite")
                coefficient, intercept = _ridge(design_train[train_indices], target)
            else:
                coefficient = np.empty((2, len(powers))); coefficient.fill(np.nan); intercept = np.full(2, np.nan)
            calibrated = bool(trained and cal_indices)
            margin_d = margin_g = None
            if calibrated:
                estimate = design_cal[cal_indices]@coefficient.T+intercept
                observed = np.asarray([[cal[j]["labels"][mode]["D"], cal[j]["labels"][mode]["G_T"]] for j in cal_indices], dtype=float)
                if not np.isfinite(observed).all():
                    raise ValueError("complete CAL target missing/nonfinite")
                margin_d = max(0., float(np.max(observed[:, 0]-estimate[:, 0]*D_SCALE_M)))
                margin_g = max(0., float(np.max(observed[:, 1]-estimate[:, 1])))
            bundle["branches"][mode] = {"trained": trained, "calibrated": calibrated,
                "coefficient": coefficient, "intercept": intercept, "D_residual_margin_m": margin_d,
                "G_T_residual_margin": margin_g, "train_complete": np.asarray([r["labels"][mode]["complete"] for r in train], dtype=bool),
                "train_physical": np.asarray([r["labels"][mode]["original_physical"] for r in train], dtype=bool),
                "train_regression_ids": [train[j]["id"] for j in train_indices], "cal_complete_ids": [cal[j]["id"] for j in cal_indices]}
        bundles[config_id] = bundle; metrics[config_id] = _cal_metrics(bundle, cal_all)
        assets[config_id] = _save_bundle(bundle, output_dir)
    selected = max(bundles, key=lambda key: (metrics[key]["zero_error_acceptance"], metrics[key]["oracle_safe_coverage"],
                    metrics[key]["C_retention"], bundles[key]["family"] == "linear", bundles[key]["k"] == 5))
    summary = {"TRAIN_planned": len(train_all), "TRAIN_finite": len(train), "TRAIN_missing_features": len(train_all)-len(train),
               "CAL_planned": len(cal_all), "CAL_finite": len(cal), "CAL_missing_features": len(cal_all)-len(cal),
               "source_all_DEV": True, "source_replay": False, "new_TEST_consumed": False}
    frozen = {"schema": VERSION, "model_frozen": True, "fixed_model_configurations": 4,
              "selected_configuration_id": selected, "selection_status": "DEV_ESTABLISHED" if metrics[selected]["established"] else "DEV_NOT_ESTABLISHED",
              "selection_order": ["zero CAL error accepts", "oracle safe coverage", "C retention", "linear", "k5"],
              "configuration_metrics": metrics, "assets": assets, "feature_specification": feature_specification(), "split_summary": summary,
              "split_registry": [{"id": r["id"], "split": r["split"], "source_trajectory_ids": r.get("source_trajectory_ids", {}),
                                   "finite_features": _finite_features(r) is not None} for r in records]}
    freeze_path = Path(output_dir)/"MODEL_FREEZE.json"
    if freeze_path.exists():
        raise FileExistsError("STEP27 MODEL_FREEZE already exists")
    freeze_path.write_text(json.dumps(frozen, sort_keys=True, indent=2, allow_nan=False), encoding="utf-8")
    return dict(frozen, selected=bundles[selected], selected_bundle=bundles[selected])
