"""Preallocated STEP28 native 20 ms physical prefix; no QP or servo update."""
from __future__ import annotations

import ctypes
import hashlib
import json
import os
from pathlib import Path
from time import perf_counter

import mujoco
import numpy as np


VERSION = "STEP28_NATIVE_PREFIX_V1"
ABI = 1
STATE_COUNT = 11
PHYSICS_STEPS = 10
PHYSICS_DT_S = .002
PHYSICAL_NAMES = ("finite", "contact", "normal_force", "friction", "command_torque",
                  "applied_torque", "joint_limit", "height", "boundary", "speed",
                  "angular_speed", "angle")
SCALAR_NAMES = ("roll", "pitch", "subtree_com_height_m", "boundary_margin_m",
                "angular_speed_rad_s", "command_torque_margin_nm", "applied_torque_margin_nm",
                "joint_limit_margin_min_rad", "friction_margin_min_n", "simulation_time_s")
CONTACT_NAMES = ("normal_force_n", "tangential_force_n", "friction_mu", "friction_margin_n", "contact_count")
D = ctypes.POINTER(ctypes.c_double)
I = ctypes.POINTER(ctypes.c_int)


class _Request(ctypes.Structure):
    _fields_ = [(name, ctypes.c_int) for name in ("abi", "nq", "nv", "nu", "base_id", "limited_count")] + [
        ("foot_ids", I), ("limited_addresses", I), ("limited_lower", D), ("limited_upper", D),
        ("health", D), ("healthy_limits", D), ("tau_sent", D),
        ("x0", ctypes.c_double), ("direction", ctypes.c_double)]


class _Output(ctypes.Structure):
    _fields_ = [(name, D) for name in ("qpos", "qvel", "qacc", "applied", "subtree_com",
                                      "joint_margins", "contacts", "scalars")] + [
        ("reason_masks", I), ("ncon", I), ("actual_steps", ctypes.c_int),
        ("state_count", ctypes.c_int), ("all_physical_pass", ctypes.c_int),
        ("all_finite", ctypes.c_int), ("max_direction_displacement", ctypes.c_double)]


def _pointer(array, integer=False):
    return array.ctypes.data_as(I if integer else D)


def _hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class _Buffers:
    """Independent C/B destination and arrays, allocated only at construction."""
    def __init__(self, model, limited_count, request_values):
        self.data = mujoco.MjData(model)
        self.qpos = np.empty((STATE_COUNT, int(model.nq)), dtype=np.float64)
        self.qvel = np.empty((STATE_COUNT, int(model.nv)), dtype=np.float64)
        self.qacc = np.empty_like(self.qvel)
        self.applied = np.empty((STATE_COUNT, int(model.nu)), dtype=np.float64)
        self.subtree_com = np.empty((STATE_COUNT, 3), dtype=np.float64)
        self.joint_margins = np.empty((STATE_COUNT, limited_count), dtype=np.float64)
        self.contacts = np.empty((STATE_COUNT, 4, len(CONTACT_NAMES)), dtype=np.float64)
        self.scalars = np.empty((STATE_COUNT, len(SCALAR_NAMES)), dtype=np.float64)
        self.reason_masks = np.empty(STATE_COUNT, dtype=np.int32)
        self.ncon = np.empty(STATE_COUNT, dtype=np.int32)
        self.health = np.empty(int(model.nu), dtype=np.float64)
        self.tau_raw = np.empty(int(model.nu), dtype=np.float64)
        self.tau_sent = np.empty(int(model.nu), dtype=np.float64)
        self.request = _Request(**request_values, health=_pointer(self.health), tau_sent=_pointer(self.tau_sent))
        self.output = _Output(**{name: _pointer(getattr(self, name)) for name in
            ("qpos", "qvel", "qacc", "applied", "subtree_com", "joint_margins", "contacts", "scalars")},
            reason_masks=_pointer(self.reason_masks, True), ncon=_pointer(self.ncon, True))


class NativePrefix:
    """One native crossing copies the current data and checks all eleven states."""
    def __init__(self, model, dll, healthy_limits, foot_ids, base_id, limited):
        self.model = model
        self.path = Path(dll).resolve()
        if not self.path.is_file():
            raise FileNotFoundError(self.path)
        self.healthy_limits = np.ascontiguousarray(healthy_limits, dtype=np.float64)
        self.foot_ids = np.ascontiguousarray(foot_ids, dtype=np.int32)
        self.limited_addresses = np.ascontiguousarray([a for a, lo, hi in limited], dtype=np.int32)
        self.limited_lower = np.ascontiguousarray([lo for a, lo, hi in limited], dtype=np.float64)
        self.limited_upper = np.ascontiguousarray([hi for a, lo, hi in limited], dtype=np.float64)
        if (self.healthy_limits.shape != (int(model.nu),) or not np.isfinite(self.healthy_limits).all()
                or np.any(self.healthy_limits < 0.) or self.foot_ids.shape != (4,)
                or np.any(self.foot_ids < 0) or len(set(self.foot_ids.tolist())) != 4
                or not len(self.limited_addresses)):
            raise ValueError("STEP28 complete foot/joint/capacity contract required")
        if abs(float(model.opt.timestep) - PHYSICS_DT_S) > 1e-15:
            raise ValueError("STEP28 native prefix requires fixed 0.002 s timestep")
        self._dll_dirs = []
        self.runtime_dll = Path(mujoco.__file__).resolve().parent / "mujoco.dll"
        if hasattr(os, "add_dll_directory"):
            for directory in (self.path.parent, self.runtime_dll.parent):
                self._dll_dirs.append(os.add_dll_directory(str(directory)))
        # Functions use the C calling convention.  On Windows x64 the ABI is
        # unified; CDLL also documents this C declaration directly.
        self._lib = ctypes.CDLL(str(self.path))
        exports = {}
        for name in ("abi", "header_version", "runtime_version", "sizeof_request", "sizeof_output",
                     "sizeof_mjmodel", "sizeof_mjdata", "sizeof_mjtNum"):
            fn = getattr(self._lib, "step28_prefix_abi" if name == "abi" else "step28_" + name)
            fn.argtypes = []; fn.restype = ctypes.c_int
            exports[name] = int(fn())
        version_fn = self._lib.step28_runtime_version_string
        version_fn.argtypes = []; version_fn.restype = ctypes.c_char_p
        exports["runtime_version_string"] = version_fn().decode("ascii")
        installed_version = int(mujoco.mj_version())
        if (exports["abi"] != ABI or exports["sizeof_request"] != ctypes.sizeof(_Request)
                or exports["sizeof_output"] != ctypes.sizeof(_Output) or exports["sizeof_mjtNum"] != 8
                or exports["header_version"] != exports["runtime_version"]
                or exports["runtime_version"] != installed_version):
            raise RuntimeError("STEP28 installed header/runtime/ctypes ABI mismatch: " + repr(exports))
        self._fn = self._lib.step28_prefix
        self._fn.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p,
                             ctypes.POINTER(_Request), ctypes.POINTER(_Output)]
        self._fn.restype = ctypes.c_int
        self._model_pointer = ctypes.c_void_p(int(model._address))
        request_values = dict(abi=ABI, nq=int(model.nq), nv=int(model.nv), nu=int(model.nu),
            base_id=int(base_id), limited_count=len(limited), foot_ids=_pointer(self.foot_ids, True),
            limited_addresses=_pointer(self.limited_addresses, True), limited_lower=_pointer(self.limited_lower),
            limited_upper=_pointer(self.limited_upper), healthy_limits=_pointer(self.healthy_limits))
        self.buffers = {mode: _Buffers(model, len(limited), request_values) for mode in ("C", "B")}
        self.call_count = 0
        metadata_path = self.path.with_name("STEP28_NATIVE_BUILD.json")
        build = json.loads(metadata_path.read_text(encoding="utf-8")) if metadata_path.is_file() else None
        self.native_abi = {**exports, "installed_python_mujoco_version": str(mujoco.__version__),
            "installed_python_mujoco_runtime": installed_version, "dll_path": str(self.path),
            "dll_sha256": _hash(self.path), "runtime_dll_path": str(self.runtime_dll),
            "runtime_dll_sha256": _hash(self.runtime_dll) if self.runtime_dll.is_file() else None,
            "pointer_bytes": ctypes.sizeof(ctypes.c_void_p), "request_bytes": ctypes.sizeof(_Request),
            "output_bytes": ctypes.sizeof(_Output), "build_metadata": build,
            "preallocated_prefix_MjData": 2, "states_per_prefix": STATE_COUNT,
            "native_crossings_per_prefix": 1, "physical_dt_s": PHYSICS_DT_S}

    def predict(self, current_data, context, first_record, mode, budget=None):
        begin = perf_counter()
        if mode not in self.buffers:
            raise ValueError("STEP28 native prefix requires explicit C/B mode")
        identity = {"context_id": str(context["context_id"]), "mode": mode,
                    "kind": "PREFIX_PREDICTION", "source": "CURRENT_STATE_FIRST_COMMAND",
                    "actual_trajectory_read": False, "solver_status_val": first_record.get("solver_status_val")}
        valid = bool(first_record.get("command_valid", first_record.get("available", False)))
        available = bool(first_record.get("available", valid))
        status = first_record.get("solver_status_val")
        if not (valid and available and status == 1 and not isinstance(status, (bool, np.bool_))):
            return self._missing(identity, "FIRST_COMMAND_UNAVAILABLE", begin)
        buf = self.buffers[mode]
        health = np.asarray(context["health_vector"], dtype=float)
        raw = np.asarray(first_record.get("tau_raw"), dtype=float)
        sent = np.asarray(first_record.get("tau_sent"), dtype=float)
        expected = self.healthy_limits.shape
        if (health.shape != expected or raw.shape != expected or sent.shape != expected
                or not np.isfinite(health).all() or not np.isfinite(raw).all() or not np.isfinite(sent).all()
                or np.any((health < 0.) | (health > 1.))):
            return self._missing(identity, "NONFINITE_OR_MALFORMED_FIRST_COMMAND", begin)
        capacity = health * self.healthy_limits
        if not np.array_equal(sent, np.clip(raw, -capacity, capacity)):
            return self._missing(identity, "FIRST_COMMAND_CAPACITY_IDENTITY_MISMATCH", begin)
        declared = first_record.get("capacity_interface")
        if declared is not None:
            for name, actual in (("health_vector", health), ("tau_raw", raw), ("tau_sent", sent)):
                if name not in declared or not np.array_equal(np.asarray(declared[name]), actual):
                    return self._missing(identity, "FIRST_COMMAND_INTERFACE_IDENTITY_MISMATCH", begin)
        saved = context.get("state", context.get("source_state", context))
        qpos, qvel = np.asarray(saved["qpos"], dtype=float), np.asarray(saved["qvel"], dtype=float)
        if (qpos.shape != (int(self.model.nq),) or qvel.shape != (int(self.model.nv),)
                or not np.array_equal(current_data.qpos, qpos) or not np.array_equal(current_data.qvel, qvel)
                or not np.isfinite(qpos).all() or not np.isfinite(qvel).all() or abs(qvel[0]) < .01):
            return self._missing(identity, "CURRENT_STATE_DIRECTION_OR_IDENTITY_MISMATCH", begin)
        anchor = np.asarray(context.get("backup_anchor_q_init", qpos), dtype=float)
        if anchor.shape != qpos.shape or not np.isfinite(anchor).all():
            return self._missing(identity, "BACKUP_ANCHOR_MISSING", begin)
        np.copyto(buf.health, health); np.copyto(buf.tau_raw, raw); np.copyto(buf.tau_sent, sent)
        buf.request.x0 = float(anchor[0]); buf.request.direction = 1. if qvel[0] > 0. else -1.
        # A failure before native dispatch reserves no steps.  A native numeric
        # failure reports the actual count and releases its unused reservation.
        token = budget.reserve_steps("PREFIX_PREDICTION", identity["context_id"] + ":" + mode, PHYSICS_STEPS) if budget is not None else None
        buf.output.actual_steps = 0; buf.output.state_count = 0
        native_begin = perf_counter()
        try:
            rc = int(self._fn(self._model_pointer, ctypes.c_void_p(int(current_data._address)),
                ctypes.c_void_p(int(buf.data._address)), ctypes.byref(buf.request), ctypes.byref(buf.output)))
        finally:
            if budget is not None:
                budget.finish_steps(token, int(buf.output.actual_steps))
        native_ms = (perf_counter() - native_begin) * 1000.
        self.call_count += 1
        identity.update(prefix_call_index=self.call_count, reserved_steps=PHYSICS_STEPS,
                        native_return_code=rc, first_capacity_event=first_record.get("first_capacity_event"))
        count = int(buf.output.state_count); steps = int(buf.output.actual_steps)
        if not (0 <= count <= STATE_COUNT and 0 <= steps <= PHYSICS_STEPS):
            raise RuntimeError("STEP28 native returned invalid state/step count")
        complete = bool(rc == 0 and count == STATE_COUNT and steps == PHYSICS_STEPS and buf.output.all_finite)
        # Freeze numeric evidence before the next call reuses these buffers.
        numeric = {name: getattr(buf, name)[:count].copy() for name in
                   ("qpos", "qvel", "qacc", "applied", "subtree_com", "joint_margins",
                    "contacts", "scalars", "reason_masks", "ncon")}
        numeric.update(tau_raw=buf.tau_raw.copy(), tau_sent=buf.tau_sent.copy(),
                       health_vector=buf.health.copy(), healthy_torque_limits_nm=self.healthy_limits.copy(),
                       effective_capacity_nm=capacity.copy(), physics_steps=np.arange(count, dtype=np.int32),
                       physical_names=PHYSICAL_NAMES, scalar_names=SCALAR_NAMES, contact_names=CONTACT_NAMES,
                       foot_geom_ids=self.foot_ids.copy(), base_body_id=int(buf.request.base_id),
                       limited_qpos_addresses=self.limited_addresses.copy())
        endpoint = None
        if complete:
            ep = numeric["qpos"][-1]; ev = numeric["qvel"][-1]; es = numeric["scalars"][-1]
            endpoint = dict(zip(("x", "y", "vx", "vy", "roll", "pitch", "roll_rate", "pitch_rate"),
                               map(float, (ep[0], ep[1], ev[0], ev[1], es[0], es[1], ev[3], ev[4]))))
        return {"schema": VERSION, "complete": complete, "available": complete,
            "original_physical_pass": bool(complete and buf.output.all_physical_pass),
            "D_prefix_m": float(buf.output.max_direction_displacement) if count and buf.output.all_finite else None,
            "endpoint": endpoint, "direction": float(buf.request.direction), "x0_m": float(buf.request.x0),
            "actual_steps": steps, "state_count": count, "identity": identity, "numeric": numeric,
            "native_ms": native_ms, "elapsed_ms": (perf_counter() - begin) * 1000.,
            "reason": None if complete else "NATIVE_NUMERIC_INCOMPLETE" if rc >= 0 else "NATIVE_CONTRACT_ERROR",
            "original_predicates_complete": complete, "command_valid": True,
            "new_QP_calls": 0, "new_MjData_calls": 0, "actual_state_mutated": False,
            "servo_memory_mutated": False, "physical_dt_s": PHYSICS_DT_S}

    @staticmethod
    def _missing(identity, reason, begin):
        return {"schema": VERSION, "complete": False, "available": False,
                "original_physical_pass": False, "D_prefix_m": None, "endpoint": None,
                "actual_steps": 0, "state_count": 0, "identity": identity, "numeric": None,
                "reason": reason, "elapsed_ms": (perf_counter() - begin) * 1000.,
                "new_QP_calls": 0, "new_MjData_calls": 0}


def physical_fact(prefix, state_index, context):
    """Optional post-ready interpretation of a stored numeric state.

    The command path never calls this adapter.  It permits comparison with the
    original evaluator without building eleven detailed Python facts online.
    """
    values = prefix["numeric"]
    k = int(state_index)
    if k != state_index or not 0 <= k < prefix["state_count"]:
        raise IndexError("STEP28 prefix state index out of range")
    from cavr_wbc.platforms.go2_mujoco import FOOT_NAMES
    contacts = {}
    for i, name in enumerate(FOOT_NAMES):
        normal, tangential, mu, margin, count = values["contacts"][k, i]
        contacts[name] = dict(present=bool(count > 0), contact_count=int(count), normal_force_n=float(normal),
            tangential_force_n=float(tangential), friction_mu=float(mu), friction_margin_n=float(margin))
    scalars = dict(zip(SCALAR_NAMES, map(float, values["scalars"][k])))
    return {**scalars, "context_id": context["context_id"], "physics_step": k,
        "qpos": values["qpos"][k], "qvel": values["qvel"][k], "actual_mujoco_qacc": values["qacc"][k],
        "subtree_com": values["subtree_com"][k], "base_body_id": values["base_body_id"],
        "joint_limit_margins": values["joint_margins"][k], "contacts": contacts,
        "health_vector": values["health_vector"], "actuator_limits": values["healthy_torque_limits_nm"],
        "tau_cmd": values["tau_sent"], "tau_sent": values["tau_sent"], "tau_raw": values["tau_raw"],
        "tau_applied": values["applied"][k], "effective_capacity_nm": values["effective_capacity_nm"],
        "native_reason_mask": int(values["reason_masks"][k])}
