"""STEP28 empirical physics-residual prediction, with array-only deployment.

The low-order PID prior is not a physical bound.  Labels are independently
evaluated ACTUAL trajectories; online functions only consume current inputs
and a separate native 20 ms PREFIX_PREDICTION.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np

from cavr_wbc.control import step27_structured_margin as source
from cavr_wbc.evaluation.step23_actual import actual_reasons
from cavr_wbc.evaluation.step25_actual import evaluate_actual


VERSION = "STEP28_PHYSICS_RESIDUAL_V1"
FEATURE_NAMES = source.FEATURE_NAMES + (
    "prefix_direction_dx20_m", "prefix_direction_vx20_m_s", "prefix_vy20_m_s",
    "prefix_roll20_rad", "prefix_pitch20_rad", "first_sent_capacity_99_percent_event",
)
PHYSICAL_FLOORS = np.asarray([
    .02, .2, .01, .01, .05, .05, .005, .01, .1, .5, .5, .1, .2, .1, .02, .02,
    .001, .02, .02, .01, .01, .5,
], dtype=float)
TERMINAL_NAMES = ("T_x", "T_vx", "T_vy", "T_roll", "T_pitch")
CONFIGURATIONS = tuple((kind, family) for kind in ("residual", "direct")
                       for family in ("linear", "quadratic"))
GAPS_M = source.GAPS_M
D_SCALE_M = .01
DISTANCE_FLOOR = 1e-12
K = 5
H = .02


def _vector(value, size, name):
    result = np.asarray(value, dtype=float)
    if result.shape != (size,) or not np.isfinite(result).all():
        raise ValueError(f"finite {name} of shape ({size},) required")
    return result


def _angles(quaternion):
    w, x, y, z = _vector(quaternion, 4, "root quaternion")
    norm = np.linalg.norm([w, x, y, z])
    if norm == 0.:
        raise ValueError("zero root quaternion")
    w, x, y, z = np.asarray([w, x, y, z])/norm
    return np.asarray([np.arctan2(2.*(w*x+y*z), 1.-2.*(x*x+y*y)),
                       np.arcsin(np.clip(2.*(w*y-z*x), -1., 1.))])


def _direction(context):
    velocity = np.asarray(context.get("state", context)["qvel"], dtype=float)
    if velocity.ndim != 1 or len(velocity) < 6 or not np.isfinite(velocity[:6]).all() or abs(velocity[0]) < .01:
        raise ValueError("direction requires finite current abs(vx)>=0.01 m/s")
    return 1. if velocity[0] > 0. else -1.


def _anchor(context):
    value = np.asarray(context.get("backup_anchor_q_init", context.get("state", context)["qpos"]), dtype=float)
    if value.ndim != 1 or len(value) < 7 or not np.isfinite(value).all():
        raise ValueError("finite fixed backup anchor required")
    return value


def prefix_available(prefix):
    return bool(prefix and prefix.get("complete", prefix.get("available", False)))


def prefix_physical_pass(prefix):
    if not prefix:
        return False
    if "original_physical_pass" in prefix:
        return bool(prefix["original_physical_pass"])
    if "original_physical_safe" in prefix:
        return bool(prefix["original_physical_safe"])
    return bool(prefix.get("physical_check", {}).get("pass", False))


def prefix_displacement(prefix):
    value = prefix.get("D_prefix_m", prefix.get("D_prefix", prefix.get("D")))
    value = float(value)
    if not np.isfinite(value) or value < 0.:
        raise ValueError("finite nonnegative native prefix maximum displacement required")
    return value


def _endpoint(prefix):
    """Accept the native helper's named endpoint or raw end-state arrays."""
    if not prefix_available(prefix):
        raise ValueError("complete native prefix unavailable")
    point = prefix.get("endpoint")
    names = ("x", "y", "vx", "vy", "roll", "pitch", "roll_rate", "pitch_rate")
    if point is not None and all(name in point for name in names):
        return _vector([point[name] for name in names], 8, "prefix endpoint")
    point = prefix.get("end_state", prefix.get("final_state", prefix))
    qpos = np.asarray(point.get("qpos", prefix.get("qpos_end")), dtype=float)
    qvel = np.asarray(point.get("qvel", prefix.get("qvel_end")), dtype=float)
    if qpos.ndim != 1 or len(qpos) < 7 or qvel.ndim != 1 or len(qvel) < 6:
        raise ValueError("native prefix lacks endpoint position/velocity/orientation")
    angles = _angles(qpos[3:7])
    return _vector([qpos[0], qpos[1], qvel[0], qvel[1],
                    point.get("roll", prefix.get("roll_end", angles[0])),
                    point.get("pitch", prefix.get("pitch_end", angles[1])), qvel[3], qvel[4]],
                   8, "prefix endpoint")


def first_saturation_event(first_response):
    """Use a recorded sent-torque 99% event, never raw clip activity alone."""
    response = first_response or {}
    for name in ("first_sent_capacity_99_percent_event", "integral_frozen_capacity_99pct", "first_capacity_event"):
        if name in response:
            value = response[name]
            if value not in (0, 1, False, True):
                raise ValueError("first sent 99% event must be explicit boolean")
            return bool(value)
    interface = response.get("capacity_interface", {})
    record = response.get("integral_record", {})
    for data, name in ((interface, "sent_99_percent_active_indices"),
                       (record, "sent_authority_gate_saturated_actuators"),
                       (record, "authority_gate_saturated_actuators")):
        if name in data:
            indices = np.asarray(data[name])
            if indices.ndim != 1:
                raise ValueError("sent 99% active index list malformed")
            return bool(len(indices))
    raise ValueError("first command sent 99% saturation event missing")


def append_prefix_features(base16, prefix, first_response, context=None):
    base = _vector(base16, 16, "current STEP27 features")
    endpoint = _endpoint(prefix)
    direction = _direction(context) if context is not None else float(prefix["direction"])
    if direction not in (-1., 1.):
        raise ValueError("native prefix direction must be signed current vx")
    x0 = float(_anchor(context)[0]) if context is not None else float(prefix["x0_m"])
    result = np.concatenate((base, [direction*(endpoint[0]-x0), direction*endpoint[2],
                                   endpoint[3], endpoint[4], endpoint[5],
                                   float(first_saturation_event(first_response))]))
    return _vector(result, 22, "STEP28 current and branch-prefix features")


def _pid_path(endpoint, anchor, integral, allow_integral, direction, prefix_d, diagnostics=False):
    anchor_angles = _angles(anchor[3:7])
    e = np.asarray([endpoint[0]-anchor[0], endpoint[1]-anchor[1],
                    endpoint[4]-anchor_angles[0], endpoint[5]-anchor_angles[1]])
    velocity = endpoint[[2, 3, 6, 7]].copy()
    b = integral[[0, 1, 3, 4]].copy()
    positions = [e.copy()] if diagnostics else []
    velocities = [velocity.copy()] if diagnostics else []
    integrals = [b.copy()] if diagnostics else []
    max_d = max(0., prefix_d, direction*e[0])
    for _ in range(49):
        # Match the existing servo: use current b and current pose error first,
        # advance the low-order state, then update memory using that old error.
        acceleration = -192.*e-24.*velocity+b
        old_e = e.copy()
        # Include a within-slot extremum of the low-order quadratic displacement.
        if acceleration[0] != 0.:
            extremum_t = -velocity[0]/acceleration[0]
            if 0. < extremum_t < H:
                max_d = max(max_d, float(direction*(e[0]+extremum_t*velocity[0]
                                   +.5*extremum_t**2*acceleration[0])))
        e = e+H*velocity+.5*H*H*acceleration
        velocity = velocity+H*acceleration
        if allow_integral:
            b = np.clip(b-H*512.*old_e, -1., 1.)
        max_d = max(max_d, float(direction*e[0]))
        if diagnostics:
            positions.append(e.copy()); velocities.append(velocity.copy()); integrals.append(b.copy())
    terminal = np.asarray([abs(e[0])/.002, abs(velocity[0])/.001, abs(velocity[1])/.25,
                           abs(anchor_angles[0]+e[2])/.2, abs(anchor_angles[1]+e[3])/.2])
    result = {"D": float(max_d), "T": terminal.tolist()}
    if diagnostics:
        result.update(e=np.asarray(positions).tolist(), v=np.asarray(velocities).tolist(), b=np.asarray(integrals).tolist())
    return result


def prior(context, prefix, mode, first_response=None, diagnostics=False):
    """Two fixed low-order PID responses from the independently frozen prefix."""
    if mode not in ("C", "B"):
        raise ValueError("explicit C/B prior required")
    endpoint = _endpoint(prefix); anchor = _anchor(context); direction = _direction(context)
    prefix_d = prefix_displacement(prefix)
    first_saturation_event(first_response)
    if mode == "B":
        record = (first_response or {}).get("integral_record", {})
        used = _vector(record.get("b_used", record.get("b_before")), 6, "first backup b_used")
        if not np.array_equal(used, np.zeros(6)):
            raise ValueError("first backup must start at the fixed zero integral")
        integral = _vector(record.get("b_after", record.get("b_after_update")), 6, "true first backup b_after")
        if np.any(np.abs(integral) > 1.):
            raise ValueError("first backup integral exceeds unchanged ±1 limit")
        if first_saturation_event(first_response) and not np.array_equal(integral, used):
            raise ValueError("first backup 99% freeze event disagrees with saved integral")
    else:
        integral = np.zeros(6)
    paths = [_pid_path(endpoint, anchor, integral, allow, direction, prefix_d, diagnostics) for allow in (True, False)]
    d = max(point["D"] for point in paths)
    terminal = np.max(np.asarray([point["T"] for point in paths]), axis=0)
    return {"schema": VERSION, "D": float(d), "D_m": float(d), "T": terminal.tolist(),
            "D_prefix_m": prefix_d, "remaining_control_slots": 49,
            "control_dt_s": H, "start_b_after_prefix": integral.tolist(),
            "allow_integral": paths[0], "freeze_integral": paths[1],
            "physical_bound": False, "first_use_then_update": True,
            "terminal_names": list(TERMINAL_NAMES)}


def labelsT_actual(branch, context):
    """Five independently checked nonnegative terminal ratios; missing stays None."""
    anchor = _anchor(context); direction = _direction(context)
    evaluated = evaluate_actual(branch, anchor.tolist(), context)
    rows = ([branch["initial_fact"]] if branch.get("initial_fact") is not None else []) + list(branch.get("physics_trajectory", []))
    full_grid = (len(rows) == 501 and [r.get("physics_step") for r in rows] == list(range(501))
                 and all("qpos" in r and "qvel" in r and not r.get("numerical_failure") for r in rows))
    complete = bool(evaluated["complete"] and full_grid)
    command_valid = bool(complete and len(branch.get("controls", [])) == 50
                         and all(c.get("valid_command") is True for c in branch.get("controls", [])))
    physical = bool(complete and evaluated["actual_safe_all_physics_states"])
    terminal = bool(complete and evaluated["actual_terminal_pass"])
    result = {"trajectory_id": branch.get("branch_id"), "status": branch.get("status"),
              "complete": complete, "D": None, "D_m": None, "T": None,
              "original_physical": physical, "original_physical_safe": physical,
              "original_terminal": terminal, "terminal_pass": terminal,
              "valid": bool(physical and terminal and command_valid), "command_valid_all": command_valid,
              "endpoint_original_physical": False, "full_501_grid": full_grid,
              "progress20_m": None, "endpoint_progress_m": None, "evaluation": evaluated,
              "original_failure": evaluated.get("first_physical_failure"), "reason": branch.get("reason"),
              "observed_original_physical_failure": bool(evaluated.get("physical_failure_state_count", 0))}
    if not complete:
        return result
    qpos = np.asarray([r["qpos"] for r in rows]); qvel = np.asarray([r["qvel"] for r in rows])
    if not np.isfinite(qpos).all() or not np.isfinite(qvel).all():
        raise ValueError("complete actual trajectory has nonfinite state")
    last = rows[-1]
    t = np.asarray([abs(qpos[-1, 0]-anchor[0])/.002, abs(qvel[-1, 0])/.001,
                    abs(qvel[-1, 1])/.25, abs(last["roll"])/.2, abs(last["pitch"])/.2])
    endpoint_physical = not actual_reasons(last)
    if bool(np.all(t <= 1.) and endpoint_physical) != terminal:
        raise ValueError("STEP28 terminal ratios disagree with frozen actual evaluator")
    d = max(0., float(np.max(direction*(qpos[:, 0]-anchor[0]))))
    result.update(D=d, D_m=d, T=t.tolist(), terminal_terms=dict(zip(TERMINAL_NAMES, t.tolist())),
                  endpoint_original_physical=endpoint_physical,
                  progress20_m=float(direction*(qpos[10, 0]-anchor[0])),
                  endpoint_progress_m=float(direction*(qpos[-1, 0]-anchor[0])))
    return result


labels = labelsT_actual


def feature_specification():
    return {"schema": VERSION, "names": list(FEATURE_NAMES), "count": 22,
            "current16": source.feature_specification(), "physical_floor": PHYSICAL_FLOORS.tolist(),
            "prefix6": "direction dx20, direction vx20, vy20, roll20, pitch20, actual sent 99% event",
            "prefix_role": "separate native PREFIX_PREDICTION; no labels or QP during propagation",
            "scale": "max(TRAIN population std, fixed physical floor), TRAIN-only mean",
            "forbidden_inputs": ["episode", "tick", "split", "future label", "gap"],
            "missing": "reject branch; never zero-impute missing current/prefix input"}


def _input_features(branch_input):
    return _vector(branch_input.get("features", branch_input.get("features22")), 22, "branch features")


def _prior_vector(branch_input):
    p = branch_input.get("prior", branch_input.get("priorD_T"))
    if isinstance(p, dict):
        value = [p.get("D", p.get("D_m"))] + list(p["T"])
    else:
        value = p
    result = _vector(value, 6, "branch D/T prior")
    if np.any(result < 0.):
        raise ValueError("negative physics prior")
    return result


def _finite_input(record, mode):
    try:
        branch_input = record["branches"][mode]
        feature = _input_features(branch_input); p = _prior_vector(branch_input)
        prefix_displacement(branch_input["prefix"])
        return feature, p
    except (KeyError, ValueError, TypeError, IndexError):
        return None


def _physical(label):
    return bool(label.get("original_physical", label.get("original_physical_safe", False)))


def _terminal(label):
    return bool(label.get("original_terminal", label.get("terminal_pass", False)))


def safe(label, gap):
    return bool(label.get("complete") and _physical(label) and _terminal(label)
                and label.get("command_valid_all", label.get("valid", False))
                and label.get("D") is not None and label["D"] <= gap)


def _target(label):
    value = _vector([label["D"]]+list(label["T"]), 6, "complete D/T label")
    if not label["complete"] or np.any(value < 0.):
        raise ValueError("complete nonnegative target required")
    return value


def _powers(family):
    eye = np.eye(22, dtype=np.int64)
    powers = list(eye)
    if family == "quadratic":
        powers += [eye[i]+eye[j] for i in range(22) for j in range(i, 22)]
    elif family != "linear":
        raise ValueError("only fixed linear/quadratic families allowed")
    return np.asarray(powers)


def _design(z, powers):
    z = np.asarray(z, dtype=float)
    # A precomputed index-pair representation avoids exponentiation/large
    # temporary broadcast arrays on the command-ready single-input path.
    first = np.argmax(powers, axis=1)
    second = powers.shape[1]-1-np.argmax(powers[:, ::-1], axis=1)
    degree = powers.sum(axis=1)
    if z.ndim == 1:
        return z[first]*np.where(degree == 1, 1., z[second])
    return z[:, first]*np.where(degree[None, :] == 1, 1., z[:, second])


def _ridge(design, target):
    mean_x = design.mean(axis=0); mean_y = target.mean(axis=0)
    x = design-mean_x; y = target-mean_y
    if x.shape[0] <= x.shape[1]:
        coefficient = x.T@np.linalg.solve(x@x.T+np.eye(len(x)), y)
    else:
        coefficient = np.linalg.solve(x.T@x+np.eye(x.shape[1]), x.T@y)
    return coefficient.T, mean_y-mean_x@coefficient


def _project(estimate, p, prefix_d, kind, no_prior=False):
    estimate = _vector(estimate, 6, "model prediction before projection").copy()
    estimate[0] *= D_SCALE_M
    if kind == "residual" and not no_prior:
        estimate += p
    if not np.isfinite(estimate).all():
        raise ValueError("nonfinite prediction cannot be projected into a normal finite output")
    estimate[0] = max(float(prefix_d), 0., estimate[0])
    estimate[1:] = np.maximum(estimate[1:], 0.)
    return estimate


def predict(bundle, branch_inputs, ablation=None):
    if ablation not in (None, "no_prior", "no_cal", "no_support"):
        raise ValueError("unknown saved-data-only ablation")
    result = {}
    for mode in ("C", "B"):
        model = bundle["branches"][mode]; point = {"accepted": False, "reasons": []}
        try:
            entry = branch_inputs[mode]; feature = _input_features(entry); p = _prior_vector(entry)
            prefix = entry["prefix"]; prefix_d = prefix_displacement(prefix)
            if not prefix_available(prefix):
                point["reasons"].append("PREFIX_UNAVAILABLE")
            command_valid = bool(entry.get("first_command_valid", False))
            physical_prefix = prefix_physical_pass(prefix)
            z = (feature-model["mean"])/model["scale"]
            design = _design(z, bundle["powers"])
            distances = np.sqrt(np.sum((model["train_z"]-z)**2, axis=1))
            indices = np.argsort(distances, kind="stable")[:K]
            nearest = float(distances[indices[0]]) if len(indices) else None
            support = bool(len(indices) == K and np.all(model["train_complete"][indices])
                           and np.all(model["train_physical"][indices]))
            distance_gate = bool(nearest is not None and nearest <= model["distance_threshold"])
            calibrated = bool(model["trained"] and model["calibrated"])
            if model["trained"]:
                estimate = _project(design@model["coefficient"].T+model["intercept"], p,
                                    prefix_d, bundle["kind"], ablation == "no_prior")
                upper = estimate.copy()
                if calibrated:
                    upper += np.asarray([.001]+[.05]*5)
                    if ablation != "no_cal":
                        upper += model["cal_margin"]
                else:
                    upper = None
            else:
                estimate = upper = None
            if len(indices) != K: point["reasons"].append("INSUFFICIENT_TRAIN_NEIGHBORS")
            if len(indices) and not np.all(model["train_complete"][indices]): point["reasons"].append("NEIGHBOR_NUMERICAL_INCOMPLETE")
            if len(indices) and not np.all(model["train_physical"][indices]): point["reasons"].append("NEIGHBOR_ORIGINAL_PHYSICAL_FAILURE")
            if not distance_gate: point["reasons"].append("OUTSIDE_CAL_NEAREST_TRAIN_DISTANCE")
            if not model["trained"]: point["reasons"].append("NO_COMPLETE_TRAIN_LABELS")
            if not model["calibrated"]: point["reasons"].append("NO_COMPLETE_CAL_LABELS")
            if not command_valid: point["reasons"].append("FIRST_COMMAND_UNAVAILABLE")
            if not physical_prefix: point["reasons"].append("PREFIX_ORIGINAL_PHYSICAL_FAILURE_OR_MISSING")
            point.update(D_hat=float(estimate[0]) if estimate is not None else None,
                         T_hat=estimate[1:].tolist() if estimate is not None else None,
                         U_D=float(upper[0]) if upper is not None else None,
                         U_T=upper[1:].tolist() if upper is not None else None,
                         D_prior=float(p[0]), T_prior=p[1:].tolist(), D_prefix_m=prefix_d,
                         support_gate=support or ablation == "no_support",
                         distance_gate=distance_gate,
                         calibration_gate=calibrated, current_command_gate=command_valid,
                         prefix_available_gate=prefix_available(prefix), prefix_physical_gate=physical_prefix,
                         neighbor_ids=[str(model["train_ids"][i]) for i in indices],
                         neighbor_distances=distances[indices].tolist(),
                         neighbor_complete=model["train_complete"][indices].tolist(),
                         neighbor_original_physical=model["train_physical"][indices].tolist(),
                         nearest_distance=nearest, distance_threshold=float(model["distance_threshold"]),
                         ablation=ablation)
        except (KeyError, ValueError, TypeError, IndexError) as exc:
            point.update(D_hat=None, T_hat=None, U_D=None, U_T=None, support_gate=False,
                         distance_gate=False, calibration_gate=False, current_command_gate=False,
                         prefix_available_gate=False, prefix_physical_gate=False,
                         neighbor_ids=[], neighbor_distances=[], input_error=str(exc))
            point["reasons"].append("MISSING_OR_NONFINITE_CURRENT_PREFIX_INPUT")
        result[mode] = point
    return result


def decide(bundle, branch_inputs, gap, ablation=None):
    if not np.isfinite(gap) or gap < 0.:
        raise ValueError("finite nonnegative gap metres required")
    predictions = predict(bundle, branch_inputs, ablation)
    for point in predictions.values():
        point["terminal_gate"] = bool(point["U_T"] is not None and np.all(np.asarray(point["U_T"]) <= 1.))
        point["local_gate"] = bool(point["U_D"] is not None and point["U_D"] <= gap)
        if not point["terminal_gate"]: point["reasons"].append("TERMINAL_RATIO_REJECT")
        if not point["local_gate"]: point["reasons"].append("LOCAL_DISPLACEMENT_MARGIN_REJECT")
        point["accepted"] = all(point[key] for key in ("support_gate", "distance_gate", "calibration_gate",
            "current_command_gate", "prefix_available_gate", "prefix_physical_gate", "terminal_gate", "local_gate"))
    choice = next((mode for mode in ("C", "B") if predictions[mode]["accepted"]), "ABSTAIN")
    return {"choice": choice, "accepted": choice != "ABSTAIN", "gap_m": float(gap),
            "predictions": predictions, "ablation": ablation, "deployable_configuration": ablation is None,
            "reject_reasons": [] if choice != "ABSTAIN" else list(dict.fromkeys(
                reason for point in predictions.values() for reason in point["reasons"]))}


def _cal_metrics(bundle, cal):
    accepted = safe_count = errors = oracle = c_oracle = c_retained = 0
    error_types = {key: 0 for key in ("physical", "local", "terminal", "numerical_incomplete", "command_unavailable")}
    for record in cal:
        for gap in GAPS_M:
            oracle += int(any(safe(record["labels"][mode], gap) for mode in ("C", "B")))
            c_oracle += int(safe(record["labels"]["C"], gap))
            decision = decide(bundle, record["branches"], gap)
            if not decision["accepted"]:
                continue
            accepted += 1; label = record["labels"][decision["choice"]]
            if safe(label, gap):
                safe_count += 1; c_retained += int(decision["choice"] == "C")
            else:
                errors += 1
                error_types["numerical_incomplete"] += int(not label["complete"])
                error_types["physical"] += int(label["complete"] and not _physical(label))
                error_types["terminal"] += int(label["complete"] and not _terminal(label))
                error_types["local"] += int(label["D"] is not None and label["D"] > gap)
                error_types["command_unavailable"] += int(not label.get("command_valid_all", label.get("valid", False)))
    return {"planned_queries": len(cal)*len(GAPS_M), "accepted": accepted, "safe_accepted": safe_count,
            "error_accepted": errors, "zero_error_acceptance": errors == 0, "oracle_safe_queries": oracle,
            "oracle_safe_coverage": safe_count/oracle if oracle else 0., "oracle_C_queries": c_oracle,
            "C_retained": c_retained, "C_retention": c_retained/c_oracle if c_oracle else 0.,
            "error_types": error_types, "established": bool(accepted and not errors and oracle
                                                        and safe_count/oracle >= .2 and c_retained)}


def _save_bundle(bundle, directory):
    directory = Path(directory); directory.mkdir(parents=True, exist_ok=True)
    path = directory/("step28_"+bundle["configuration_id"]+".npz")
    if path.exists() or path.with_suffix(".json").exists():
        raise FileExistsError("frozen STEP28 assets cannot be overwritten")
    arrays = {"powers": bundle["powers"]}
    metadata = {key: bundle[key] for key in ("schema", "configuration_id", "kind", "family", "k",
                                            "train_ids_all", "cal_ids_all")}
    metadata["branches"] = {}
    for mode, model in bundle["branches"].items():
        arrays.update({mode+"_"+key: model[key] for key in ("mean", "scale", "train_std", "physical_floor",
                       "train_z", "train_ids", "coefficient", "intercept", "cal_margin", "train_complete", "train_physical")})
        metadata["branches"][mode] = {key: model[key] for key in ("trained", "calibrated", "distance_threshold",
            "cal_max_nearest_distance", "train_regression_ids", "cal_complete_ids", "train_finite_ids", "cal_finite_ids")}
    metadata.update(alpha=1., quadratic_bias=False, D_target_scale_m=.01, D_reserve_m=.001,
                    terminal_reserve=.05, terminal_names=list(TERMINAL_NAMES), feature_specification=feature_specification(),
                    no_support_ablation="remove k5 complete/physical neighbor support ONLY; retain nearest-distance OOD gate",
                    no_cal_ablation="remove empirical positive CAL residual margins ONLY; retain fixed .001m/.05 reserves",
                    no_prior_ablation="zero additive physical prior on saved residual-model predictions; projection unchanged")
    with path.open("xb") as stream:
        np.savez_compressed(stream, **arrays)
    path.with_suffix(".json").write_text(json.dumps(metadata, sort_keys=True, indent=2, allow_nan=False), encoding="utf-8")
    return {"npz": str(path.resolve()), "json": str(path.with_suffix(".json").resolve()),
            "npz_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "json_sha256": hashlib.sha256(path.with_suffix(".json").read_bytes()).hexdigest()}


def load_bundle(path):
    path = Path(path)
    if path.is_dir():
        freeze = json.loads((path/"MODEL_FREEZE.json").read_text(encoding="utf-8"))
        path = Path(freeze["assets"][freeze["selected_configuration_id"]]["npz"])
    metadata = json.loads(path.with_suffix(".json").read_text(encoding="utf-8"))
    if metadata["schema"] != VERSION:
        raise ValueError("unsupported STEP28 model schema")
    result = {key: metadata[key] for key in ("schema", "configuration_id", "kind", "family", "k",
                                            "train_ids_all", "cal_ids_all")}
    result["branches"] = {}
    with np.load(path, allow_pickle=False) as archive:
        result["powers"] = archive["powers"].copy()
        for mode in ("C", "B"):
            model = dict(metadata["branches"][mode])
            model.update({key: archive[mode+"_"+key].copy() for key in ("mean", "scale", "train_std", "physical_floor",
                          "train_z", "train_ids", "coefficient", "intercept", "cal_margin", "train_complete", "train_physical")})
            result["branches"][mode] = model
    return result


def fit_fixed(records, output_dir):
    """Four configs × two branch multioutput Ridge fits; no new TEST accepted."""
    if any(r["split"] not in ("TRAIN", "CAL") for r in records):
        raise ValueError("STEP28 fitting refuses new TEST or unrecognized split")
    if len({r["id"] for r in records}) != len(records):
        raise ValueError("duplicate DEV context ID")
    train_all = [r for r in records if r["split"] == "TRAIN"]
    cal_all = [r for r in records if r["split"] == "CAL"]
    fitted = {}; metrics = {}; assets = {}; fit_calls = []
    branch_data = {}
    for mode in ("C", "B"):
        train = [r for r in train_all if _finite_input(r, mode) is not None]
        cal = [r for r in cal_all if _finite_input(r, mode) is not None]
        if not train:
            raise ValueError("no finite branch "+mode+" TRAIN features")
        x = np.asarray([_input_features(r["branches"][mode]) for r in train])
        mean = x.mean(axis=0); std = x.std(axis=0, ddof=0); scale = np.maximum(std, PHYSICAL_FLOORS)
        train_z = (x-mean)/scale
        cal_z = (np.asarray([_input_features(r["branches"][mode]) for r in cal])-mean)/scale if cal else np.empty((0, 22))
        nearest = np.sqrt(np.min(np.sum((cal_z[:, None]-train_z[None, :])**2, axis=2), axis=1)) if cal else np.empty(0)
        cal_max = float(np.max(nearest)) if len(nearest) else 0.
        branch_data[mode] = dict(train=train, cal=cal, mean=mean, train_std=std, scale=scale,
                                physical_floor=PHYSICAL_FLOORS.copy(), train_z=train_z, cal_z=cal_z,
                                cal_max_nearest_distance=cal_max, distance_threshold=max(3.*cal_max, DISTANCE_FLOOR))
    for kind, family in CONFIGURATIONS:
        config_id = kind+"_"+family; powers = _powers(family)
        bundle = {"schema": VERSION, "configuration_id": config_id, "kind": kind, "family": family,
                  "k": K, "powers": powers, "branches": {},
                  "train_ids_all": [r["id"] for r in train_all], "cal_ids_all": [r["id"] for r in cal_all]}
        for mode in ("C", "B"):
            data = branch_data[mode]; train = data["train"]; cal = data["cal"]
            indices = [i for i, r in enumerate(train) if r["labels"][mode]["complete"]]
            cal_indices = [i for i, r in enumerate(cal) if r["labels"][mode]["complete"]]
            trained = bool(indices)
            design = _design(data["train_z"], powers)
            if trained:
                target = np.asarray([_target(train[i]["labels"][mode]) for i in indices])
                if kind == "residual":
                    target -= np.asarray([_prior_vector(train[i]["branches"][mode]) for i in indices])
                target[:, 0] /= D_SCALE_M
                coefficient, intercept = _ridge(design[indices], target)
                fit_calls.append({"configuration_id": config_id, "branch": mode, "outputs": 6,
                                  "multioutput_estimator_fit": 1, "training_count": len(indices)})
            else:
                coefficient = np.full((6, len(powers)), np.nan); intercept = np.full(6, np.nan)
            calibrated = bool(trained and cal_indices); margin = np.zeros(6)
            if calibrated:
                cal_design = _design(data["cal_z"], powers)
                estimated = []
                for i in cal_indices:
                    entry = cal[i]["branches"][mode]
                    estimated.append(_project(cal_design[i]@coefficient.T+intercept, _prior_vector(entry),
                                              prefix_displacement(entry["prefix"]), kind))
                observed = np.asarray([_target(cal[i]["labels"][mode]) for i in cal_indices])
                margin = np.maximum(0., np.max(observed-np.asarray(estimated), axis=0))
            model = {key: data[key].copy() if isinstance(data[key], np.ndarray) else data[key]
                     for key in ("mean", "train_std", "scale", "physical_floor", "train_z",
                                 "cal_max_nearest_distance", "distance_threshold")}
            model.update(trained=trained, calibrated=calibrated, coefficient=coefficient, intercept=intercept,
                         cal_margin=margin, train_ids=np.asarray([r["id"] for r in train], dtype=str),
                         train_complete=np.asarray([r["labels"][mode]["complete"] for r in train], dtype=bool),
                         train_physical=np.asarray([_physical(r["labels"][mode]) for r in train], dtype=bool),
                         train_regression_ids=[train[i]["id"] for i in indices],
                         cal_complete_ids=[cal[i]["id"] for i in cal_indices],
                         train_finite_ids=[r["id"] for r in train], cal_finite_ids=[r["id"] for r in cal])
            bundle["branches"][mode] = model
        fitted[config_id] = bundle; metrics[config_id] = _cal_metrics(bundle, cal_all)
        assets[config_id] = _save_bundle(bundle, output_dir)
    residual_ids = [key for key in fitted if key.startswith("residual_")]
    selected_id = max(residual_ids, key=lambda key: (metrics[key]["zero_error_acceptance"],
                     metrics[key]["oracle_safe_coverage"], metrics[key]["C_retention"], fitted[key]["family"] == "linear"))
    direct_id = "direct_"+fitted[selected_id]["family"]
    summary = {"TRAIN_planned": len(train_all), "CAL_planned": len(cal_all), "branches": {
        mode: {"TRAIN_finite": len(branch_data[mode]["train"]), "CAL_finite": len(branch_data[mode]["cal"]),
               "TRAIN_missing_input": len(train_all)-len(branch_data[mode]["train"]),
               "CAL_missing_input": len(cal_all)-len(branch_data[mode]["cal"]),
               "complete_CAL_missing_input": sum(r["labels"][mode]["complete"] and _finite_input(r, mode) is None for r in cal_all)}
        for mode in ("C", "B")}, "all_source_role": "DEV", "new_TEST_consumed": False}
    freeze = {"schema": VERSION, "model_frozen": True, "fixed_model_configurations": 4,
              "actual_branch_multioutput_estimator_fit_calls": len(fit_calls),
              "scalar_output_regression_equivalents": 6*len(fit_calls), "fit_call_ledger": fit_calls,
              "selected_configuration_id": selected_id, "selected_direct_configuration_id": direct_id,
              "selection_status": "DEV_ESTABLISHED" if metrics[selected_id]["established"] else "DEV_NOT_ESTABLISHED",
              "selection_order": ["zero CAL error accepts", "oracle safe coverage", "C retention", "linear"],
              "assets": assets, "config_metrics": metrics, "configuration_metrics": metrics,
              "feature_specification": feature_specification(), "split_summary": summary,
              "split_registry": [{"id": r["id"], "split": r["split"], "finite_branch_input": {
                  mode: _finite_input(r, mode) is not None for mode in ("C", "B")}} for r in records]}
    path = Path(output_dir)/"MODEL_FREEZE.json"
    if path.exists():
        raise FileExistsError("STEP28 MODEL_FREEZE cannot be overwritten")
    path.write_text(json.dumps(freeze, sort_keys=True, indent=2, allow_nan=False), encoding="utf-8")
    return dict(freeze, selected=fitted[selected_id], selected_bundle=fitted[selected_id],
                selected_direct=fitted[direct_id], selected_direct_bundle=fitted[direct_id],
                bundles=fitted, freeze_path=str(path.resolve()))
