"""STEP28 startup preparation and two reusable native prediction workspaces."""
from __future__ import annotations

from time import perf_counter

import numpy as np

from cavr_wbc.control.step27_resident_kernel import ResidentKernel, reset_workspace_warmstart
from cavr_wbc.control.step28_native_prefix import NativePrefix


VERSION = "STEP28_STARTUP_KERNEL_V1"
VARIANTS = ("K28_REFERENCE", "K28_STARTUP_READY")
INNER_VARIANTS = {"K28_REFERENCE": "K_RESIDENT", "K28_STARTUP_READY": "K_BUDGETED"}


class StartupKernel(ResidentKernel):
    """Preserve resident mathematics and solver settings across independent cases.

    Public STEP28 names are metadata.  Each inner controller retains the STEP27
    variant that actually selects the fixed six-millisecond solver limit.
    """
    def __init__(self, model, variant="K28_REFERENCE", prefixdll=None, budget=None):
        begin = perf_counter()
        if variant not in VARIANTS:
            raise ValueError("unknown STEP28 kernel variant")
        if prefixdll is None:
            raise ValueError("STEP28 installed-ABI native prefix DLL is required")
        inner = INNER_VARIANTS[variant]
        super().__init__(model, variant=inner, budget=budget)
        self.inner_variant = inner
        self.variant = variant
        self.kernel_name = variant
        self.version = VERSION
        self.ready = False
        self._startup_started = False
        self._startup_complete = False
        self._startup_active = False
        self.startup_record = None
        self.setup_events = []
        self.native_prefix = NativePrefix(model, prefixdll, self.healthy_limits,
            [self._foot_ids[name] for name in self._foot_ids], self._base_id, self._limited)
        self.prefix_data_C = self.native_prefix.buffers["C"].data
        self.prefix_data_B = self.native_prefix.buffers["B"].data
        self.native_abi = self.native_prefix.native_abi
        self.cold_construction_ms = (perf_counter() - begin) * 1000.

    @property
    def setup_count(self):
        return int(self.nominal_controller.solver_setup_calls + self.backup_controller.solver_setup_calls)

    def _bind(self, controller, budget, kind, owner, first_mode=None):
        active = self.budget if budget is None else budget
        if active is not None:
            active.check()
            callback = active.qp_callback(kind, owner, first_mode)
        else:
            callback = None

        def alias(result):
            if result is not None:
                result["inner_kernel_variant"] = controller.variant
                result["kernel_variant"] = self.variant
            return result

        def invoke(stage, payload, solve):
            if stage == "before":
                def inner_solve():
                    return alias(solve())
                return callback(stage, payload, inner_solve) if callback is not None else inner_solve()
            # The callback sees the public name and the real unchanged limit.
            alias(payload["result"])
            return callback(stage, payload, solve) if callback is not None else None
        controller.solve_callback = invoke

    def _record_setup(self, controller, before, result, kind, owner, budget):
        after = int(controller.solver_setup_calls)
        delta = after - before
        rows = result.get("solver_ledger", result.get("solver_ledger_delta", []))
        for row in rows:
            row.update(kernel_variant=self.variant, inner_kernel_variant=controller.variant,
                       osqp_time_limit_s=controller.solver_time_limit_s,
                       startup_priming=bool(self._startup_active))
        if delta:
            event = {"kernel_variant": self.variant, "inner_kernel_variant": controller.variant,
                "controller": "nominal" if controller is self.nominal_controller else "backup",
                "owner": owner, "kind": kind, "setup_count_delta": delta,
                "setup_count_total": self.setup_count, "startup_priming": bool(self._startup_active),
                "runtime_setup": not self._startup_active,
                "setup_time_s": sum(float(row.get("setup_time_s") or 0.) for row in rows)}
            self.setup_events.append(event)
            active = self.budget if budget is None else budget
            if active is not None and hasattr(active, "event"):
                active.event("QP_WORKSPACE_SETUP", **event)
        result["runtime_setup_events"] = delta if not self._startup_active else 0
        result["startup_ready"] = bool(self.ready)
        result["kernel_variant"] = self.variant
        result["inner_kernel_variant"] = controller.variant
        result["solver_time_limit_s"] = controller.solver_time_limit_s
        return result

    def nominal(self, context, budget=None, kind="NOMINAL", owner=None):
        begin = perf_counter()
        before = int(self.nominal_controller.solver_setup_calls)
        result = super().nominal(context, budget, kind, owner)
        self._record_setup(self.nominal_controller, before, result, kind,
                           owner or context["context_id"], budget)
        result["command_ready_ms"] = result["generation_ms"] = (perf_counter() - begin) * 1000.
        return result

    def compute_backup(self, context, slot, budget=None, kind="ACTUAL_B", owner=None):
        begin = perf_counter()
        before = int(self.backup_controller.solver_setup_calls)
        result = super().compute_backup(context, slot, budget, kind, owner)
        self._record_setup(self.backup_controller, before, result, kind,
                           owner or context["context_id"], budget)
        result["command_ready_ms"] = result["latency_ms"] = (perf_counter() - begin) * 1000.
        return result

    def startup(self, home_context, budget=None):
        """Root-called one-time healthy-home priming: precisely two true QPs.

        A command may fail the exact-Solved gate while its OSQP workspace is
        successfully initialized.  Readiness is the initialized-workspace
        condition, and command validity is reported separately.
        """
        if self._startup_complete:
            return self.startup_record
        if self._startup_started:
            raise RuntimeError("STEP28 startup failed or is already active; no implicit re-priming")
        health = np.asarray(home_context["health_vector"], dtype=float)
        b_used = np.asarray(home_context["nominal_b_used"], dtype=float)
        if (not np.array_equal(health, np.ones(int(self.model.nu)))
                or b_used.shape != (6,) or not np.array_equal(b_used, np.zeros(6))
                or float(home_context["nominal_d_m"]) != 0. or int(home_context["source_tick"]) != 0):
            raise ValueError("STEP28 priming requires fixed healthy home, zero reference displacement/integral, tick zero")
        saved = home_context.get("state", home_context.get("source_state", home_context))
        if (not np.array_equal(np.asarray(home_context["nominal_q_init"]), np.asarray(saved["qpos"]))
                or not np.array_equal(np.asarray(home_context["backup_anchor_q_init"]), np.asarray(saved["qpos"]))):
            raise ValueError("STEP28 home priming references must equal the healthy home state")
        self._startup_started = True
        self._startup_active = True
        begin = perf_counter()
        before = self.setup_count
        nominal = backup = None
        try:
            self.reset(home_context)
            nominal = self.nominal(home_context, budget, "STARTUP_PRIMING_NOMINAL", self.variant + ":HOME")
            self.reset_backup(self.data, home_context)
            backup = self.compute_backup(home_context, 0, budget, "STARTUP_PRIMING_BACKUP", self.variant + ":HOME")
            self.ready = bool(self.nominal_controller._solver_cache and self.backup_controller._solver_cache)
            # Independent-case memory is restored after priming.  Symbolic
            # structures and initialized OSQP objects stay owned by the kernel.
            self.reset(home_context)
            self.reset_backup(self.data, home_context)
            reset_workspace_warmstart(self.nominal_controller)
            reset_workspace_warmstart(self.backup_controller)
            prime_valid = bool(nominal["command_valid"] and backup["valid_command"])
            preparation_ms = (perf_counter() - begin) * 1000.
            self.startup_record = {"schema": VERSION, "kernel_variant": self.variant,
                "inner_kernel_variant": self.inner_variant, "ready": self.ready,
                "status": "READY" if self.ready and prime_valid else
                          "READY_PRIMING_COMMAND_UNAVAILABLE" if self.ready else "NOT_READY",
                "healthy_home_only": True, "priming_QP_calls":
                    len(nominal["solver_ledger"]) + len(backup["solver_ledger_delta"]),
                "nominal_priming_status_val": nominal["solver_status_val"],
                "backup_priming_status_val": backup["wbc"]["status_val"],
                "nominal_priming_command_valid": bool(nominal["command_valid"]),
                "backup_priming_command_valid": bool(backup["valid_command"]),
                "nominal_priming_command_ready_ms": float(nominal["command_ready_ms"]),
                "backup_priming_command_ready_ms": float(backup["command_ready_ms"]),
                "construction_ms": self.cold_construction_ms, "preparation_ms": preparation_ms,
                "startup_ms": self.cold_construction_ms + preparation_ms,
                "setup_count": self.setup_count, "startup_setup_delta": self.setup_count - before,
                "solver_time_limit_s_per_call": self.solver_time_limit_s,
                "source_servo_memory_restored": True, "independent_primal_dual_zeroed": True,
                "prefix_MjData_preallocated": 2, "prefix_integrations_during_startup": 0,
                "setup_events": [dict(row) for row in self.setup_events]}
            self._startup_complete = True
            active = self.budget if budget is None else budget
            if active is not None and hasattr(active, "event"):
                active.event("STARTUP_READY_RESULT", **self.startup_record)
            return self.startup_record
        finally:
            self._startup_active = False

    def prefix(self, context, first_record, mode, budget=None):
        if self._context_id != str(context["context_id"]):
            raise ValueError("STEP28 prefix requires reset to the exact current context")
        active = self.budget if budget is None else budget
        return self.native_prefix.predict(self.data, context, first_record, mode, active)


def specification():
    return {"version": VERSION, "variants": list(VARIANTS), "inner_variants": dict(INNER_VARIANTS),
        "solver_time_limit_s": .006, "priming_QP_calls_per_kernel": 2,
        "prefix_steps": 10, "prefix_states": 11, "prefix_MjData_per_kernel": 2,
        "independent_case_reset": "source integration/reference/integral; zero primal+dual; retain solver workspaces",
        "runtime_setup_events_recorded": True, "ready_is_workspace_initialized_not_priming_command_valid": True}
