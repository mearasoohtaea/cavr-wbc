"""Checked, nonoptimal STEP29 convex commands and action-conditioned inputs.

An intermediate command is never an optimizer return.  The frozen STEP12
equality budgets and exact hard inequalities are used only for this command's
algebraic substitution; they do not certify its future trajectory.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

import numpy as np
import scipy.sparse as sp

from cavr_wbc.control.step12_validation import load_acceptance_config
from cavr_wbc.control.step22_pose_servo import AUTHORITY_GATE_FRACTION
from cavr_wbc.control.step27_structured_margin import extract_features
from cavr_wbc.control.step28_physics_residual import append_prefix_features


VERSION = "STEP29_CHECKED_ACTIONS_V1"
GAMMA_GRID = (1., .75, .5, .25, 0.)
SYNTHESIZED_KIND = "SYNTHESIZED_CONVEX_COMMAND"


@lru_cache(maxsize=1)
def frozen_contract():
    return load_acceptance_config(Path(__file__).resolve().parents[2] /
                                  "configs/validation/step12_v1_acceptance_v1.json")


def _copy_matrix(value):
    return value.toarray().copy() if sp.issparse(value) else np.asarray(value, dtype=float).copy()


def capture_matrices(controller, context, meta=None):
    """Copy same-call coefficients before resident fixed-CSC memory is reused."""
    meta = controller.last_meta if meta is None else meta
    state = context.get("state", context.get("source_state", context))
    contract = frozen_contract()
    A = _copy_matrix(meta["constraint_A"])
    l = np.asarray(meta["constraint_l"], dtype=float).copy()
    u = np.asarray(meta["constraint_u"], dtype=float).copy()
    nv, nu, nc = int(controller.nv), int(controller.nu), int(meta["Jc"].shape[0])
    if A.shape != (2 * nv + nc + nu + 20, nv + nu + nc) or l.shape != (A.shape[0],) or u.shape != l.shape:
        raise ValueError("STEP29 requires the unchanged single-stage physical row layout")
    if nv != len(contract.document["dynamics_rows"]) or nc != len(contract.document["contact_rows"]):
        raise ValueError("STEP29 frozen row contract does not match the compiled model")
    tolerance = np.zeros(A.shape[0])
    tolerance[:nv] = [r["abs_tolerance"] for r in contract.document["dynamics_rows"]]
    tolerance[nv:nv + nc] = [r["abs_tolerance"] for r in contract.document["contact_rows"]]
    units = tuple(r["unit"] for r in contract.document["dynamics_rows"]) + tuple(
        r["unit"] for r in contract.document["contact_rows"]) + (
        ("m/s^2",) * 3 + ("rad/s^2",) * (nv - 3) + ("N*m",) * nu + ("N",) * 20)
    return {"A": A, "l": l, "u": u, "row_abs_tolerance": tolerance,
        "row_units": units, "inequality_extra_slack": 0., "nv": nv, "nu": nu, "nc": nc,
        "context_id": str(context["context_id"]), "qpos": np.asarray(state["qpos"], dtype=float).copy(),
        "qvel": np.asarray(state["qvel"], dtype=float).copy(),
        "integration_state": np.asarray(state.get("integration_state", []), dtype=float).copy(),
        "health_vector": np.asarray(context["health_vector"], dtype=float).copy(),
        "healthy_torque_limits_nm": np.asarray(controller._healthy_limits, dtype=float).copy(),
        "points": np.asarray(meta["points"], dtype=float).copy(),
        "acceptance_version": contract.version, "acceptance_sha256": contract.sha256,
        "osqp_eps_abs": float(controller.cfg.osqp_eps_abs), "osqp_eps_rel": float(controller.cfg.osqp_eps_rel),
        "constraint_source": "CURRENT_STATE_ASSEMBLED_PHYSICAL_ROWS"}


def _status(endpoint):
    raw = endpoint.get("raw_solver_result", endpoint.get("wbc", endpoint.get("solver_raw_result", {}))) or {}
    witnesses = [endpoint.get("solver_status_val"), raw.get("status_val"),
                 (endpoint.get("capacity_interface") or {}).get("solver_status_val")]
    known = [s for s in witnesses if s is not None]
    if not known or any(isinstance(s, (bool, np.bool_)) or s != known[0] for s in known):
        return None
    return known[0]


def _variables(endpoint, nv, nu, nc):
    raw = endpoint.get("raw_solver_variables") or {}
    wb = endpoint.get("raw_solver_result", endpoint.get("wbc", endpoint.get("solver_raw_result", {}))) or {}
    qdd = raw.get("qdd", endpoint.get("qdd", wb.get("qdd")))
    tau = raw.get("tau", endpoint.get("tau_raw", wb.get("tau")))
    lam = raw.get("contact_force", raw.get("contact_lambda", endpoint.get("contact_lambda", wb.get("contact_force"))))
    try:
        pieces = [np.asarray(x, dtype=float) for x in (qdd, tau, lam)]
        if any(x.shape != shape or not np.isfinite(x).all() for x, shape in zip(pieces, ((nv,), (nu,), (nc,)))):
            return None
        return np.concatenate(pieces)
    except (TypeError, ValueError):
        return None


def _reference(endpoint):
    response = endpoint.get("response", endpoint)
    ref = response.get("a_base_ref", (endpoint.get("assembly") or {}).get("a_base_ref"))
    if ref is None:
        ref = endpoint.get("desired_base_accel")
    try:
        ref = np.asarray(ref, dtype=float)
        return ref.copy() if ref.shape == (6,) and np.isfinite(ref).all() else None
    except (ValueError, TypeError):
        return None


def shared_matrices(C, B):
    if not C or not B:
        return False, "CURRENT_HARD_MATRICES_UNAVAILABLE"
    for key in ("A", "l", "u", "row_abs_tolerance", "qpos", "qvel", "integration_state", "health_vector",
                "healthy_torque_limits_nm"):
        if key not in C or key not in B or not np.array_equal(C[key], B[key]):
            return False, "SOURCE_SHARED_" + key.upper() + "_MISMATCH"
    if C["context_id"] != B["context_id"]:
        return False, "SOURCE_CONTEXT_ID_MISMATCH"
    return True, None


def check_rows(matrices, z):
    """Every original hard row, with original SI equality budgets and no slack."""
    A, l, u = matrices["A"], matrices["l"], matrices["u"]
    tolerance = matrices["row_abs_tolerance"]
    with np.errstate(over="ignore", invalid="ignore"):
        value = A @ z
        lower, upper = value - l, u - value
        violation = np.maximum(np.maximum(-lower, -upper), 0.)
        passed = np.isfinite(value) & ~np.isnan(lower) & ~np.isnan(upper) & (violation <= tolerance)
    nv, nc = matrices["nv"], matrices["nc"]
    equality = value[:nv + nc] - l[:nv + nc]
    return {"pass": bool(np.all(passed)), "row_pass": passed, "A_z": value,
        "lower_signed_margin": lower, "upper_signed_margin": upper,
        "row_violation": violation, "row_abs_tolerance": tolerance.copy(),
        "signed_equality_residual": equality, "dynamics_residual_signed": equality[:nv].copy(),
        "contact_residual_signed": equality[nv:].copy(), "failed_row_indices": np.flatnonzero(~passed),
        "dynamics_residual_inf": float(np.max(np.abs(equality[:nv]))),
        "contact_residual_inf": float(np.max(np.abs(equality[nv:]))),
        "row_units": matrices["row_units"], "inequality_extra_slack": 0.}


def _missing(gamma, reason, statuses, **extra):
    return {"schema": VERSION, "gamma": float(gamma), "kind": SYNTHESIZED_KIND if 0. < gamma < 1. else "C_ENDPOINT" if gamma == 1. else "B_ENDPOINT",
        "available": False, "command_valid": False, "execution_eligible": False,
        "features_available": False, "unavailable_reason": reason, "solver_status_val": None,
        "source_solver_statuses": statuses, "new_solver_called": False, "new_QP_calls": 0,
        "synthetic_is_optimizer_return": False, "tau_raw": None, "tau_sent": None, "z_raw": None,
        "z_sent": None, **extra}


def make_action(context, endC, endB, gamma, matrices=None):
    """Construct a source endpoint or explicitly checked convex command.

    Endpoint execution keeps the original output interface.  Missing full saved
    primal variables or rejected mixed residuals never invalidate that interface.
    """
    gamma = float(gamma)
    if gamma not in GAMMA_GRID:
        raise ValueError("STEP29 gamma is outside the frozen five-action grid")
    endpoints = {"C": endC or {}, "B": endB or {}}
    statuses = {mode: _status(ep) for mode, ep in endpoints.items()}
    source = "C" if gamma == 1. else "B" if gamma == 0. else None
    mats = matrices or {mode: ep.get("source_matrices") for mode, ep in endpoints.items()}
    if "A" in mats:
        mats = {"C": mats, "B": mats}
    health = np.asarray(context["health_vector"], dtype=float)
    if source is not None:
        ep = endpoints[source]
        valid = bool(ep.get("command_valid", ep.get("valid_command", ep.get("available", False))))
        if statuses[source] != 1 or not valid:
            return _missing(gamma, "SOURCE_ENDPOINT_UNAVAILABLE", statuses, source_endpoint=source)
        interface = ep.get("capacity_interface") or (ep.get("response") or {}).get("capacity_interface") or {}
        try:
            limits = np.asarray(interface.get("healthy_torque_limits_nm", (mats.get(source) or {}).get("healthy_torque_limits_nm")), dtype=float)
            raw = np.asarray(ep.get("tau_raw", interface.get("tau_raw")), dtype=float)
            sent = np.asarray(ep.get("tau_sent", ep.get("tau_cmd", ep.get("tau", interface.get("tau_sent")))), dtype=float)
            if any(x.shape != health.shape or not np.isfinite(x).all() for x in (limits, raw, sent)):
                raise ValueError("malformed endpoint capacity")
            if not np.array_equal(sent, np.clip(raw, -health * limits, health * limits)):
                raise ValueError("endpoint capacity clip mismatch")
            recorded_health = ep.get("health_vector", interface.get("health_vector"))
            if recorded_health is None or not np.array_equal(recorded_health, health):
                raise ValueError("endpoint health mismatch")
        except (ValueError, TypeError):
            return _missing(gamma, "SOURCE_ENDPOINT_INTERFACE_MISMATCH", statuses, source_endpoint=source)
        matrix = mats.get(source)
        nv, nu, nc = (matrix["nv"], matrix["nu"], matrix["nc"]) if matrix else (18, len(health), 12)
        z = _variables(ep, nv, nu, nc)
        ref = _reference(ep)
        action = {"schema": VERSION, "gamma": gamma, "kind": source + "_ENDPOINT",
            "source_endpoint": source, "source_endpoint_record": ep,
            "available": True, "command_valid": True, "execution_eligible": True,
            "features_available": ref is not None, "unavailable_reason": None,
            "solver_status_val": statuses[source], "source_solver_statuses": statuses,
            "tau_raw": raw.copy(), "tau_sent": sent.copy(), "z_raw": z,
            "z_sent": None if z is None else np.r_[z[:nv], sent, z[nv + nu:]],
            "qdd": None if z is None else z[:nv].copy(), "contact_lambda": None if z is None else z[nv + nu:].copy(),
            "a_base_ref": ref, "health_vector": health.copy(), "capacity_interface": interface,
            "integral_record": ep.get("integral_record", (ep.get("response") or {}).get("integral_record")),
            "first_capacity_event": bool(np.any(np.abs(sent) >= AUTHORITY_GATE_FRACTION * health * limits)),
            "source_matrices": matrix, "new_solver_called": False, "new_QP_calls": 0,
            "synthetic_is_optimizer_return": False, "endpoint_original_interface_preserved": True}
        if matrix and z is not None:
            action["raw_hard_check"] = check_rows(matrix, z)
            action["sent_hard_check"] = check_rows(matrix, action["z_sent"])
        return action
    if any(statuses[m] != 1 or not endpoints[m].get("command_valid", endpoints[m].get("valid_command", endpoints[m].get("available", False))) for m in ("C", "B")):
        return _missing(gamma, "BOTH_EXACT_SOLVED_ENDPOINTS_REQUIRED", statuses)
    same, reason = shared_matrices(mats.get("C"), mats.get("B"))
    if not same:
        return _missing(gamma, reason, statuses)
    matrix = mats["C"]
    if matrix["context_id"] != str(context["context_id"]) or not np.array_equal(matrix["health_vector"], health):
        return _missing(gamma, "CURRENT_STATE_HEALTH_IDENTITY_MISMATCH", statuses)
    state = context.get("state", context.get("source_state", context))
    if any(not np.array_equal(matrix[k], state[k]) for k in ("qpos", "qvel")):
        return _missing(gamma, "CURRENT_STATE_HEALTH_IDENTITY_MISMATCH", statuses)
    nv, nu, nc = matrix["nv"], matrix["nu"], matrix["nc"]
    zs = {mode: _variables(ep, nv, nu, nc) for mode, ep in endpoints.items()}
    if any(z is None for z in zs.values()):
        return _missing(gamma, "SOURCE_FULL_PRIMAL_UNAVAILABLE", statuses)
    z = gamma * zs["C"] + (1. - gamma) * zs["B"]
    raw = z[nv:nv + nu].copy()
    limits = matrix["healthy_torque_limits_nm"]
    capacity = health * limits
    sent = np.clip(raw, -capacity, capacity)
    sent_z = np.r_[z[:nv], sent, z[nv + nu:]]
    raw_check, sent_check = check_rows(matrix, z), check_rows(matrix, sent_z)
    valid = bool(raw_check["pass"] and sent_check["pass"])
    refs = {mode: _reference(ep) for mode, ep in endpoints.items()}
    ref = gamma * refs["C"] + (1. - gamma) * refs["B"] if all(v is not None for v in refs.values()) else None
    interface = {"command_valid": valid, "solver_status_val": None, "solver_exact_solved": False,
        "source_solver_statuses": statuses, "version": VERSION, "health_vector": health.copy(),
        "healthy_torque_limits_nm": limits.copy(), "effective_capacity_nm": capacity.copy(),
        "tau_raw": raw, "tau_sent": sent, "saturation_mask": sent != raw, "correction_nm": sent - raw,
        "sent_command_within_capacity_exact": bool(np.all(np.abs(sent) <= capacity)),
        "sent_99_percent_active_indices": np.flatnonzero((capacity <= 0.) | (np.abs(sent) >= AUTHORITY_GATE_FRACTION * capacity))}
    return {"schema": VERSION, "gamma": gamma, "kind": SYNTHESIZED_KIND, "available": valid,
        "command_valid": valid, "execution_eligible": valid, "features_available": ref is not None,
        "unavailable_reason": None if valid else "RAW_OR_SENT_HARD_ROW_REJECTED",
        "solver_status_val": None, "source_solver_statuses": statuses, "source_primal_variables": zs,
        "qdd": z[:nv].copy(), "contact_lambda": z[nv + nu:].copy(), "z_raw": z, "z_sent": sent_z,
        "tau_raw": raw, "tau_sent": sent, "health_vector": health.copy(), "capacity_interface": interface,
        "raw_hard_check": raw_check, "sent_hard_check": sent_check,
        "clip_dynamics_residual_delta": sent_check["dynamics_residual_signed"] - raw_check["dynamics_residual_signed"],
        "a_base_ref": ref, "source_matrices": matrix, "shared_A_l_u_exact": True,
        "first_capacity_event": bool(len(interface["sent_99_percent_active_indices"])),
        "backup_initial_b": np.zeros(6), "integral_record": None,
        "new_solver_called": False, "new_QP_calls": 0, "synthetic_is_optimizer_return": False,
        "optimality_claim": False, "hard_validation_pass": valid}


def action_current_features(context, action, mapping):
    """Reuse the frozen current sixteen definitions under this sent command."""
    fact = action.get("initial_new_command_fact")
    if fact is None or action.get("a_base_ref") is None:
        raise ValueError("action-conditioned current forward/reference unavailable")
    view = {**action, "initial_new_command_fact": fact,
            "response": {"a_base_ref": action["a_base_ref"]}}
    return extract_features(context, view, mapping)


def action_features(context, action, prefix, mapping):
    base = action_current_features(context, action, mapping)
    feature = np.r_[append_prefix_features(base, prefix, action, context), action["gamma"]]
    if feature.shape != (23,) or not np.isfinite(feature).all():
        raise ValueError("finite STEP29 action-conditioned 23-vector required")
    return feature


def convex_command_property():
    return ("For common affine rows, a convex combination of endpoint signed residuals "
        "preserves each endpoint's common absolute row tolerance. Original hard inequalities "
        "also remain satisfied when both endpoints satisfy them. Capacity clipping changes "
        "the primal torque entries and requires a fresh row-by-row check. This concerns only "
        "the current command, with no future safety, invariance, or optimality conclusion.")
