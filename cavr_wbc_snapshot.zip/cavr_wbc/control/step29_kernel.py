"""STEP29 reusable kernel, opt-in synthesized prefix and absolute deadline.

The native ABI, mathematical QP, fixed CSC workspaces, PID and frozen physical
checks remain the STEP28 ones.  A bounded solver's limit is set before its
actual invocation from the remaining absolute command window.
"""
from __future__ import annotations

import ctypes
from time import perf_counter

import mujoco
import numpy as np
import osqp

from cavr_wbc.control.step22_pose_servo import Step22WBC
from cavr_wbc.control.step27_resident_kernel import ResidentWBC
from cavr_wbc.control.step28_startup_kernel import StartupKernel
from cavr_wbc.control.step28_native_prefix import (
    CONTACT_NAMES, PHYSICAL_NAMES, PHYSICS_STEPS, PHYSICS_DT_S, SCALAR_NAMES,
    STATE_COUNT, NativePrefix,
)
from cavr_wbc.control.step23_backup_filter import _finite_state, predicted_physical_check
from cavr_wbc.control.step29_actions import (
    GAMMA_GRID, SYNTHESIZED_KIND, action_current_features, action_features,
    capture_matrices, frozen_contract, make_action,
)
from cavr_wbc.platforms.go2_mujoco import FOOT_NAMES


VERSION = "STEP29_ACTION_KERNEL_V1"
DEADLINE_S = .020
FINAL_RESERVE_S = .003
MIN_SOLVER_S = .001
MAX_SOLVER_S = .006
VARIANTS = {"REFERENCE": "K28_REFERENCE", "BOUNDED": "K28_STARTUP_READY"}


class DeadlineWBC(ResidentWBC):
    """Resident solver with a single configured time limit before each solve."""
    def _default_solve(self, problem, *, max_iter_override=None):
        P = problem["P"].tocsc(copy=False); A = problem["A"].tocsc(copy=False)
        P.sort_indices(); A.sort_indices()
        key = self._workspace_key({"P": P, "A": A})
        cache = self._solver_cache.get(key)
        max_iter = int(self.cfg.osqp_max_iter if max_iter_override is None else max_iter_override)
        time_limit = float(self.solver_time_limit_s) if self.variant == "K_BUDGETED" else 1e10
        if self.variant == "K_BUDGETED" and not MIN_SOLVER_S <= time_limit <= MAX_SOLVER_S:
            raise ValueError("STEP29 bounded QP requires a preconfigured 1--6 ms solve budget")
        setup_s = update_s = 0.; warm_started = False
        if cache is None:
            start = perf_counter()
            solver = osqp.OSQP()
            solver.setup(P=P, q=problem["q"], A=A, l=problem["l"], u=problem["u"],
                eps_abs=self.cfg.osqp_eps_abs, eps_rel=self.cfg.osqp_eps_rel,
                max_iter=max_iter, polish=True, verbose=False, time_limit=time_limit)
            setup_s = perf_counter() - start
            self.solver_setup_calls += 1
            cache = {"solver": solver, "last_x": None, "last_y": None,
                "zero_x": np.zeros(P.shape[0]), "zero_y": np.zeros(A.shape[0]),
                "setup_count": self.solver_setup_calls, "native": False,
                "independent_case_zeroed": True, "time_limit_s": time_limit}
            self._solver_cache[key] = cache
        else:
            solver = cache["solver"]
            start = perf_counter()
            solver.update(Px=P.data, Ax=A.data, q=problem["q"], l=problem["l"], u=problem["u"])
            solver.update_settings(time_limit=time_limit)
            cache["time_limit_s"] = time_limit
            update_s = perf_counter() - start
            if cache["last_x"] is not None or cache["last_y"] is not None:
                solver.warm_start(x=cache["last_x"], y=cache["last_y"])
                warm_started = True
        start = perf_counter()
        raw = solver.solve(raise_error=False)
        wall_s = perf_counter() - start
        cache["last_x"] = None if raw.x is None else np.asarray(raw.x, dtype=float).copy()
        cache["last_y"] = None if raw.y is None else np.asarray(raw.y, dtype=float).copy()
        cache["independent_case_zeroed"] = False
        info = raw.info
        result = {"x": None if raw.x is None else np.asarray(raw.x, dtype=float),
            "status": str(info.status), "status_val": int(info.status_val),
            "iterations": int(info.iter), "solve_time_s": float(info.solve_time),
            "solve_wall_time_s": wall_s, "setup_time_s": setup_s, "update_time_s": update_s,
            "workspace_reused": bool(update_s > 0.), "warm_started": warm_started,
            "primal_residual": float(info.prim_res), "dual_residual": float(info.dual_res),
            "kernel_variant": self.variant, "osqp_time_limit_s": self.solver_time_limit_s,
            "native_api": "osqp.OSQP public Python binding to installed native extension"}
        self._last_solver_timings = {name: result[name] for name in
            ("setup_time_s", "update_time_s", "solve_wall_time_s", "solve_time_s", "workspace_reused", "warm_started")}
        return result


class NativeActionPrefix(NativePrefix):
    """Opt-in synthesized dispatch sharing STEP28's DLL and preallocated buffers."""
    @classmethod
    def share(cls, existing):
        instance = cls.__new__(cls)
        instance.__dict__ = existing.__dict__
        return instance

    def predict_action(self, current_data, context, action, budget=None):
        if action.get("kind") != SYNTHESIZED_KIND:
            mode = "C" if float(action["gamma"]) == 1. else "B"
            return super().predict(current_data, context, action, mode, budget)
        begin = perf_counter()
        gamma = float(action["gamma"])
        identity = {"context_id": str(context["context_id"]), "mode": "GAMMA", "gamma": gamma,
            "kind": "PREFIX_PREDICTION", "source": "CURRENT_CHECKED_SYNTHESIZED_COMMAND",
            "command_kind": SYNTHESIZED_KIND, "actual_trajectory_read": False,
            "solver_status_val": None, "source_solver_statuses": dict(action.get("source_solver_statuses", {}))}
        source_status = action.get("source_solver_statuses", {})
        if not (action.get("command_valid") and action.get("execution_eligible")
                and action.get("hard_validation_pass") and action.get("shared_A_l_u_exact")
                and all(source_status.get(mode) == 1 and not isinstance(source_status.get(mode), (bool, np.bool_)) for mode in ("C", "B"))
                and action.get("solver_status_val") is None
                and action.get("sent_hard_check", {}).get("pass")
                and action.get("raw_hard_check", {}).get("pass")):
            return self._missing(identity, "SYNTHESIZED_COMMAND_UNVALIDATED", begin)
        buf = self.buffers["C"]
        health = np.asarray(context["health_vector"], dtype=float)
        raw, sent = np.asarray(action.get("tau_raw"), dtype=float), np.asarray(action.get("tau_sent"), dtype=float)
        if (any(v.shape != self.healthy_limits.shape or not np.isfinite(v).all() for v in (health, raw, sent))
                or np.any((health < 0.) | (health > 1.))):
            return self._missing(identity, "NONFINITE_OR_MALFORMED_FIRST_COMMAND", begin)
        capacity = health * self.healthy_limits
        if not np.array_equal(sent, np.clip(raw, -capacity, capacity)):
            return self._missing(identity, "FIRST_COMMAND_CAPACITY_IDENTITY_MISMATCH", begin)
        declared = action.get("capacity_interface", {})
        if any(name not in declared or not np.array_equal(declared[name], actual)
               for name, actual in (("health_vector", health), ("tau_raw", raw), ("tau_sent", sent))):
            return self._missing(identity, "FIRST_COMMAND_INTERFACE_IDENTITY_MISMATCH", begin)
        saved = context.get("state", context.get("source_state", context))
        qpos, qvel = np.asarray(saved["qpos"], dtype=float), np.asarray(saved["qvel"], dtype=float)
        if (qpos.shape != (int(self.model.nq),) or qvel.shape != (int(self.model.nv),)
                or not np.isfinite(qpos).all() or not np.isfinite(qvel).all() or abs(qvel[0]) < .01
                or not np.array_equal(current_data.qpos, qpos) or not np.array_equal(current_data.qvel, qvel)):
            return self._missing(identity, "CURRENT_STATE_DIRECTION_OR_IDENTITY_MISMATCH", begin)
        anchor = np.asarray(context.get("backup_anchor_q_init", qpos), dtype=float)
        if anchor.shape != qpos.shape or not np.isfinite(anchor).all():
            return self._missing(identity, "BACKUP_ANCHOR_MISSING", begin)
        np.copyto(buf.health, health); np.copyto(buf.tau_raw, raw); np.copyto(buf.tau_sent, sent)
        buf.request.x0 = float(anchor[0]); buf.request.direction = 1. if qvel[0] > 0. else -1.
        owner = identity["context_id"] + ":G" + str(gamma)
        token = budget.reserve_steps("PREFIX_PREDICTION", owner, PHYSICS_STEPS) if budget is not None else None
        buf.output.actual_steps = 0; buf.output.state_count = 0
        native_begin = perf_counter()
        try:
            rc = int(self._fn(self._model_pointer, ctypes.c_void_p(int(current_data._address)),
                ctypes.c_void_p(int(buf.data._address)), ctypes.byref(buf.request), ctypes.byref(buf.output)))
        finally:
            if budget is not None:
                budget.finish_steps(token, int(buf.output.actual_steps))
        native_ms = (perf_counter() - native_begin) * 1000.
        self.call_count += 1
        identity.update(prefix_call_index=self.call_count, reserved_steps=PHYSICS_STEPS,
            native_return_code=rc, first_capacity_event=action.get("first_capacity_event"))
        count, steps = int(buf.output.state_count), int(buf.output.actual_steps)
        if not (0 <= count <= STATE_COUNT and 0 <= steps <= PHYSICS_STEPS):
            raise RuntimeError("STEP29 native returned invalid state/step count")
        complete = bool(rc == 0 and count == STATE_COUNT and steps == PHYSICS_STEPS and buf.output.all_finite)
        numeric = {name: getattr(buf, name)[:count].copy() for name in
            ("qpos", "qvel", "qacc", "applied", "subtree_com", "joint_margins", "contacts", "scalars", "reason_masks", "ncon")}
        numeric.update(tau_raw=buf.tau_raw.copy(), tau_sent=buf.tau_sent.copy(),
            health_vector=buf.health.copy(), healthy_torque_limits_nm=self.healthy_limits.copy(),
            effective_capacity_nm=capacity.copy(), physics_steps=np.arange(count, dtype=np.int32),
            physical_names=PHYSICAL_NAMES, scalar_names=SCALAR_NAMES, contact_names=CONTACT_NAMES,
            foot_geom_ids=self.foot_ids.copy(), base_body_id=int(buf.request.base_id),
            limited_qpos_addresses=self.limited_addresses.copy())
        endpoint = None
        if complete:
            ep, ev, es = numeric["qpos"][-1], numeric["qvel"][-1], numeric["scalars"][-1]
            endpoint = dict(zip(("x", "y", "vx", "vy", "roll", "pitch", "roll_rate", "pitch_rate"),
                map(float, (ep[0], ep[1], ev[0], ev[1], es[0], es[1], ev[3], ev[4]))))
        return {"schema": VERSION, "complete": complete, "available": complete,
            "original_physical_pass": bool(complete and buf.output.all_physical_pass),
            "D_prefix_m": float(buf.output.max_direction_displacement) if count and buf.output.all_finite else None,
            "endpoint": endpoint, "direction": float(buf.request.direction), "x0_m": float(buf.request.x0),
            "actual_steps": steps, "state_count": count, "identity": identity, "numeric": numeric,
            "native_ms": native_ms, "elapsed_ms": (perf_counter() - begin) * 1000.,
            "reason": None if complete else "NATIVE_NUMERIC_INCOMPLETE" if rc >= 0 else "NATIVE_CONTRACT_ERROR",
            "original_predicates_complete": complete, "command_valid": True, "solver_status_val": None,
            "command_kind": SYNTHESIZED_KIND, "new_QP_calls": 0, "new_MjData_calls": 0,
            "actual_state_mutated": False, "servo_memory_mutated": False, "physical_dt_s": PHYSICS_DT_S}


class Kernel(StartupKernel):
    def __init__(self, model, variant="REFERENCE", prefixdll=None, budget=None):
        if variant not in VARIANTS:
            raise ValueError("unknown STEP29 kernel variant")
        begin = perf_counter()
        super().__init__(model, variant=VARIANTS[variant], prefixdll=prefixdll, budget=budget)
        # Construction allocates controllers only. No solver or integration is
        # dispatched by replacing these unprimed owners with the opt-in solver.
        self.nominal_controller = DeadlineWBC(model, variant=self.inner_variant)
        self.policy.controller = DeadlineWBC(model, variant=self.inner_variant)
        self.backup_controller = self.policy.controller
        self.public_variant = variant
        self.variant = variant
        self.kernel_name = variant
        self.version = VERSION
        self.native_prefix = NativeActionPrefix.share(self.native_prefix)
        self._next_call_limit = None
        frozen_contract()  # Load/hash the frozen contract during construction.
        self.cold_construction_ms = (perf_counter() - begin) * 1000.

    def set_next_call_limit(self, seconds=None):
        if self.public_variant == "REFERENCE":
            self._next_call_limit = None
            return None
        value = MAX_SOLVER_S if seconds is None else float(seconds)
        if not MIN_SOLVER_S <= value <= MAX_SOLVER_S:
            raise ValueError("STEP29 next bounded solver budget must be 1--6 ms")
        self._next_call_limit = value
        return value

    def _configure(self, controller):
        controller.solver_time_limit_s = (MAX_SOLVER_S if self._next_call_limit is None else self._next_call_limit) if self.public_variant == "BOUNDED" else None
        self._next_call_limit = None

    def nominal(self, context, budget=None, kind="NOMINAL", owner=None):
        begin = perf_counter()
        self._configure(self.nominal_controller)
        result = super().nominal(context, budget, kind, owner)
        result["source_matrices"] = capture_matrices(self.nominal_controller, context)
        result["a_base_ref"] = np.asarray(result["response"]["a_base_ref"]).copy() if result["response"].get("a_base_ref") is not None else None
        result["command_ready_ms"] = result["generation_ms"] = (perf_counter() - begin) * 1000.
        return result

    def compute_backup(self, context, slot, budget=None, kind="ACTUAL_B", owner=None):
        begin = perf_counter()
        self._configure(self.backup_controller)
        result = super().compute_backup(context, slot, budget, kind, owner)
        result["source_matrices"] = capture_matrices(self.backup_controller, context)
        result["solver_status_val"] = result["wbc"].get("status_val")
        result["command_valid"] = bool(result["valid_command"])
        result["tau_raw"] = result["capacity_interface"]["tau_raw"]
        result["tau_sent"] = result["tau_cmd"]
        result["health_vector"] = np.asarray(context["health_vector"]).copy()
        result["command_ready_ms"] = result["latency_ms"] = (perf_counter() - begin) * 1000.
        return result

    def first_backup(self, context, budget=None, kind="FIRST_B", owner=None):
        self.reset_backup(self.data, context)
        return self.compute_backup(context, 0, budget, kind, owner)

    def assemble_saved_matrices(self, context):
        """Restore a saved state and assemble existing STEP22 rows without QP."""
        self.reset(context)
        health = np.asarray(context["health_vector"], dtype=float)
        target = {"desired_base_accel": np.zeros(6), "desired_joint_accel": np.zeros(int(self.model.nu)),
                  "task_weights": np.ones(6 + int(self.model.nu)), "servo_configuration": "S22_POSE_PID"}
        _, _, _, _, _, meta = Step22WBC._problem(self.nominal_controller, self.data, health, target)
        self.nominal_controller.last_meta = meta
        matrix = capture_matrices(self.nominal_controller, context, meta)
        return {"C": matrix, "B": {k: v.copy() if isinstance(v, np.ndarray) else v for k, v in matrix.items()}}

    def condition_action(self, context, action):
        if self._context_id != str(context["context_id"]):
            raise ValueError("STEP29 action conditioning requires the exact reset context")
        if not action.get("command_valid"):
            action["features_available"] = False
            return action
        begin = perf_counter()
        self.data.ctrl[:] = action["tau_sent"]
        mujoco.mj_forward(self.model, self.data)
        fact = self.physical_fact(self.data, context, action["capacity_interface"]) if _finite_state(self.data) else None
        action["initial_new_command_fact"] = fact
        action["actual_mujoco_qacc"] = self.data.qacc.copy()
        action["current_physical_check"] = predicted_physical_check(fact or {})
        matrix = action.get("source_matrices")
        points = matrix.get("points") if matrix else self.nominal_controller.last_trace.get("points")
        action["foot_positions"] = {name: np.asarray(points[i]).copy() for i, name in enumerate(FOOT_NAMES)} if points is not None else None
        try:
            action["features16"] = action_current_features(context, action, self.mapping)
            action["features_available"] = True
            action["feature_error"] = None
        except (ValueError, TypeError, KeyError) as exc:
            action["features16"] = None
            action["features_available"] = False
            action["feature_error"] = str(exc)
        action["action_conditioned_forward_ms"] = (perf_counter() - begin) * 1000.
        return action

    def prefix_action(self, context, action, budget=None):
        if self._context_id != str(context["context_id"]):
            raise ValueError("STEP29 prefix requires exact current context")
        active = self.budget if budget is None else budget
        return self.native_prefix.predict_action(self.data, context, action, active)

    def features(self, context, action, prefix):
        if action.get("features16") is not None:
            from cavr_wbc.control.step28_physics_residual import append_prefix_features
            return np.r_[append_prefix_features(action["features16"], prefix, action, context), action["gamma"]]
        return action_features(context, action, prefix, self.mapping)

    def governor(self, context, bundle, gap, policy="GOVERNOR_LAZY", budget=None, decide=None):
        """One absolute 20 ms window; optional model decision callable injection.

        ``decide(bundle, entry, gap)`` receives only this action's current inputs.
        It returns ``accepted`` (or ``recognized``) and its numeric gate evidence.
        """
        if policy not in ("BINARY_EAGER", "BINARY_LAZY", "GOVERNOR_LAZY"):
            raise ValueError("unknown STEP29 online policy")
        if decide is None:
            from cavr_wbc.control.step29_margin import decide as margin_decide
            def decide(model, entry, gap):
                g=float(entry["gamma"])
                inp={"gamma":g,"role":context["health_kind"].split("_")[0].lower(),
                    "features23":entry.get("features23"),"prefix":entry.get("prefix"),
                    "first_command_valid":entry["action"]["command_valid"]}
                return margin_decide(model,{format(g,"g"):inp},gap,allowed=(g,))
        begin = perf_counter()
        deadline = begin + DEADLINE_S
        active = self.budget if budget is None else budget
        evidence = {"schema": VERSION, "policy": policy, "context_id": str(context["context_id"]),
            "gap_m": float(gap), "deadline_ms": 20., "C": {"status": "NOT_REQUESTED"},
            "B": {"status": "NOT_REQUESTED"}, "actions": {}, "selected_gamma": None,
            "selected_action": None, "selected_command_sent": False, "status": "ABSTAIN",
            "prepare_begin": begin, "absolute_deadline": deadline, "new_PID_prior_calls": 0}
        grid = GAMMA_GRID if policy == "GOVERNOR_LAZY" else (1., 0.)
        endC = endB = None

        def remaining():
            return deadline - perf_counter()

        def solver_allowed():
            seconds = min(MAX_SOLVER_S, remaining() - FINAL_RESERVE_S)
            if seconds < MIN_SOLVER_S:
                return False
            self.set_next_call_limit(seconds)
            return True

        def stop(action=None, recognized=False):
            # Required numeric evidence was copied by endpoint/action/prefix
            # methods. No detailed JSON, disk write or hash is done here.
            elapsed = (perf_counter() - begin) * 1000.
            valid = bool(action and action.get("command_valid"))
            any_valid = bool(valid or any(ep and ep.get("command_valid",ep.get("valid_command",False)) for ep in (endC,endB)))
            timely = bool(elapsed <= 20.)
            evidence.update(elapsed_ms=elapsed, command_ready_ms=elapsed,
                timely_recognized_command=bool(recognized and valid and timely),
                command_available=any_valid, selected_command_valid=valid,
                raw_valid_but_late=bool(any_valid and not timely),
                overall_deadline_failure=not timely,
                selected_gamma=float(action["gamma"]) if action else None,
                selected_action=action,
                selected_command_sent=bool(recognized and valid and timely),
                status="RECOGNIZED_SENT" if recognized and valid and timely else
                       "COMPUTED_VALID_BUT_LATE" if valid and not timely else "ABSTAIN")
            for gamma in grid:
                evidence["actions"].setdefault(str(gamma), {"gamma": gamma,
                    "evaluation_status": "NOT_REQUESTED_AFTER_SELECTION" if evidence["selected_command_sent"] else "NOT_EVALUATED_BUDGET"})
            return evidence

        def evaluate(gamma):
            action = make_action(context, endC, endB, gamma)
            entry = {"gamma": gamma, "action": action, "prefix": None, "features": None,
                "decision": None, "evaluation_status": "COMMAND_UNAVAILABLE"}
            evidence["actions"][str(gamma)] = entry
            if not action["command_valid"]:
                return action, False
            self.condition_action(context, action)
            if remaining() < FINAL_RESERVE_S:
                entry["evaluation_status"] = "NOT_EVALUATED_BUDGET"
                return action, False
            prefix = self.prefix_action(context, action, active)
            entry["prefix"] = prefix
            try:
                entry["features"] = self.features(context, action, prefix)
                entry["features23"] = entry["features"]
                entry["context"] = context
                decision = decide(bundle, entry, float(gap))
                entry["decision"] = decision
                entry["evaluation_status"] = "EVALUATED"
                accepted = bool(decision.get("accepted", decision.get("recognized", decision.get("accept", False))))
            except (ValueError, TypeError, KeyError) as exc:
                entry["evaluation_status"] = "PREDICTION_INPUT_UNAVAILABLE"
                entry["feature_error"] = str(exc)
                action["features_available"] = False
                accepted = False
            entry["complete_at_ms"] = (perf_counter() - begin) * 1000.
            return action, accepted

        if not getattr(self,"ready",False):
            evidence["C"]={"status":"NOT_READY"}
            evidence["B"]={"status":"NOT_READY"}
            evidence["not_ready"]=True
            return stop()
        self.reset(context)
        if active is not None:
            active.check()
        if not solver_allowed():
            evidence["C"] = {"status": "NOT_EVALUATED_BUDGET"}
            return stop()
        endC = self.nominal(context, active, "ONLINE_C", context["context_id"])
        evidence["C"] = endC
        # Eager binary first computes both endpoints; lazy policies can send C
        # without requesting any B command or B prefix.
        if policy == "BINARY_EAGER":
            if not solver_allowed():
                evidence["B"] = {"status": "NOT_EVALUATED_BUDGET"}
            else:
                endB = self.first_backup(context, active, "ONLINE_B", context["context_id"])
                evidence["B"] = endB
        action, accepted = evaluate(1.)
        if accepted:
            return stop(action, True)
        if remaining() <= 0.:
            return stop(action)
        if endB is None:
            if not solver_allowed():
                evidence["B"] = {"status": "NOT_EVALUATED_BUDGET"}
                return stop(action)
            endB = self.first_backup(context, active, "ONLINE_B", context["context_id"])
            evidence["B"] = endB
        for gamma in grid[1:]:
            if remaining() < FINAL_RESERVE_S:
                return stop(action)
            action, accepted = evaluate(gamma)
            if accepted:
                return stop(action, True)
        return stop(action)


def core_governor(kernel, context, bundle, gap, policy="GOVERNOR_LAZY", budget=None, decide=None):
    return kernel.governor(context, bundle, gap, policy, budget, decide)
