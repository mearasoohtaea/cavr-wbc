"""Fixed STEP29 action-conditional recoverability margins.

One quadratic Ridge predicts directional excursion and five *signed* terminal
quantities across all actions.  Deployment consumes numeric current/prefix
inputs only; complete ACTUAL labels are confined to DEV fitting and evaluation.
The calibration reserves are empirical, not probability or safety guarantees.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np

from cavr_wbc.control import step28_physics_residual as source
from cavr_wbc.evaluation.step23_actual import actual_reasons
from cavr_wbc.evaluation.step25_actual import evaluate_actual


VERSION = "STEP29_RECOVERABILITY_ACTION_MARGIN_V1"
MAIN = "CAPACITY_CONDITIONAL"
NO_CAPACITY = "NO_EXPLICIT_CAPACITY"
BINARY = "BINARY_SAME_MODEL"
CONFIGURATIONS = (MAIN, NO_CAPACITY)
GAMMA_GRID = (1., .75, .5, .25, 0.)
ROLES = ("healthy", "thigh", "calf")
FEATURE_NAMES = (
    source.FEATURE_NAMES[0], "direction_current_command_model_ax_m_s2",
    *source.FEATURE_NAMES[2:12], "direction_command_desired_ax_m_s2",
    *source.FEATURE_NAMES[13:], "gamma",
)
PHYSICAL_FLOORS = np.r_[source.PHYSICAL_FLOORS, .25]
DROP_CAPACITY_INDICES = (8, 9, 10, 11, 21)
TERMINAL_NAMES = ("Y_x", "Y_vx", "Y_vy", "Y_roll", "Y_pitch")
GAPS_M = tuple(value / 1000. for value in (.5, 1, 1.5, 2, 2.5, 3, 4, 6, 8, 12, 16, 24, 32))
D_SCALE_M = .01
D_RESERVE_M = .001
TERMINAL_RESERVE = .05
DISTANCE_FLOOR = 1e-12
POSE_PAD_RAD = 1e-9
K = 5
MIN_CAL_SNAPSHOTS = 3
MIN_CAL_EPISODES = 2
ALPHA = 1.

prefix_available = source.prefix_available
prefix_physical_pass = source.prefix_physical_pass
prefix_displacement = source.prefix_displacement


def _vector(value, size, name):
    result = np.asarray(value, dtype=float)
    if result.shape != (size,) or not np.isfinite(result).all():
        raise ValueError(f"finite {name} of shape ({size},) required")
    return result


def gamma_key(gamma):
    """Stable JSON key shared by records, groups, and action predictions."""
    value = float(gamma)
    if not np.isfinite(value) or value not in GAMMA_GRID:
        raise ValueError("action gamma must belong to the fixed STEP29 grid")
    return format(value, "g")


def _role(entry):
    role = str(entry.get("role", entry.get("fault_role", ""))).lower().split("_")[0]
    if role not in ROLES:
        raise ValueError("explicit healthy/thigh/calf fault role required")
    return role


def group_key(configuration, gamma, role):
    key = gamma_key(gamma)
    if configuration == MAIN:
        if role not in ROLES:
            raise ValueError("invalid fault role")
        return key + ":" + role
    if configuration == NO_CAPACITY:
        return key
    raise ValueError("only the two fixed STEP29 configurations are allowed")


def append_gamma_features(features22, gamma):
    """Append gamma to freshly extracted command-conditional STEP28 inputs."""
    gamma_key(gamma)
    return np.r_[_vector(features22, 22, "current and action-prefix features"), float(gamma)]


def _input_features(entry):
    features = _vector(entry.get("features23", entry.get("features")), 23, "STEP29 action features")
    gamma = float(entry["gamma"])
    gamma_key(gamma)
    if features[22] != gamma:
        raise ValueError("gamma feature differs from the declared action")
    _role(entry)
    return features


def _finite_input(record):
    # Failed/incomplete actual labels do not remove an otherwise finite input
    # from the neighbor population. Prefix/command gates are checked separately.
    try:
        return _input_features(record)
    except (KeyError, TypeError, ValueError, IndexError):
        return None


def labels(branch, ctx):
    """Read signed terminal labels from a complete independently checked ACTUAL.

    The original physical and terminal evaluator is retained, including the
    endpoint's physical check.  A partial trajectory never supplies D or Y.
    """
    anchor = source._anchor(ctx)
    direction = source._direction(ctx)
    evaluated = evaluate_actual(branch, anchor.tolist(), ctx)
    rows = ([branch["initial_fact"]] if branch.get("initial_fact") is not None else []) + list(branch.get("physics_trajectory", []))
    full_grid = (len(rows) == 501 and [row.get("physics_step") for row in rows] == list(range(501))
                 and all("qpos" in row and "qvel" in row and not row.get("numerical_failure") for row in rows))
    complete = bool(evaluated["complete"] and full_grid)
    command_valid = bool(complete and len(branch.get("controls", [])) == 50
                         and all(row.get("valid_command") is True for row in branch.get("controls", [])))
    physical = bool(complete and evaluated["actual_safe_all_physics_states"])
    terminal = bool(complete and evaluated["actual_terminal_pass"])
    result = {
        "trajectory_id": branch.get("branch_id"), "status": branch.get("status"),
        "complete": complete, "D": None, "D_m": None, "Y": None, "signedY": None,
        "original_physical": physical, "original_physical_safe": physical,
        "original_terminal": terminal, "terminal_pass": terminal,
        "valid": bool(physical and terminal and command_valid), "command_valid_all": command_valid,
        "full_501_grid": full_grid, "endpoint_original_physical": False,
        "progress20_m": None, "endpoint_progress_m": None, "evaluation": evaluated,
        "original_failure": evaluated.get("first_physical_failure"), "reason": branch.get("reason"),
        "observed_original_physical_failure": bool(evaluated.get("physical_failure_state_count", 0)),
    }
    if not complete:
        return result
    qpos = np.asarray([row["qpos"] for row in rows], dtype=float)
    qvel = np.asarray([row["qvel"] for row in rows], dtype=float)
    if (qpos.ndim != 2 or qpos.shape[1] < 7 or qvel.ndim != 2 or qvel.shape[1] < 6
            or not np.isfinite(qpos).all() or not np.isfinite(qvel).all()):
        raise ValueError("complete actual trajectory has malformed or nonfinite state")
    last = rows[-1]
    y = _vector([(qpos[-1, 0] - anchor[0]) / .002, qvel[-1, 0] / .001,
                 qvel[-1, 1] / .25, float(last["roll"]) / .2, float(last["pitch"]) / .2],
                5, "signed actual terminal label")
    endpoint_physical = not actual_reasons(last)
    if bool(np.all(np.abs(y) <= 1.) and endpoint_physical) != terminal:
        raise ValueError("STEP29 signed terminal labels disagree with frozen actual evaluator")
    d = max(0., float(np.max(direction * (qpos[:, 0] - anchor[0]))))
    result.update(D=d, D_m=d, Y=y.tolist(), signedY=y.tolist(),
                  terminal_terms=dict(zip(TERMINAL_NAMES, y.tolist())),
                  endpoint_original_physical=endpoint_physical,
                  progress20_m=float(direction * (qpos[10, 0] - anchor[0])),
                  endpoint_progress_m=float(direction * (qpos[-1, 0] - anchor[0])))
    return result


def _physical(label):
    return bool(label.get("original_physical_safe", label.get("original_physical", False)))


def _terminal(label):
    return bool(label.get("terminal_pass", label.get("original_terminal", False)))


def safe(label, gap):
    d = label.get("D", label.get("D_m"))
    return bool(label.get("complete") and _physical(label) and _terminal(label)
                and label.get("command_valid_all", label.get("valid", False))
                and d is not None and np.isfinite(d) and 0. <= d <= gap)


def _target(label):
    if not label.get("complete"):
        raise ValueError("complete actual label required")
    y = label.get("Y", label.get("signedY"))
    value = _vector([label.get("D", label.get("D_m"))] + list(y), 6, "complete D/signedY label")
    if value[0] < 0.:
        raise ValueError("actual directional excursion must be nonnegative")
    return value


def _complete_target(record):
    try:
        return _target(record["labels"])
    except (KeyError, TypeError, ValueError, IndexError):
        return None


def _powers(size):
    eye = np.eye(size, dtype=np.int64)
    return np.asarray(list(eye) + [eye[i] + eye[j] for i in range(size) for j in range(i, size)])


def _design(z, powers):
    # This is the same no-bias quadratic basis rule for either retained input set.
    z = np.asarray(z, dtype=float)
    first = np.argmax(powers, axis=1)
    second = powers.shape[1] - 1 - np.argmax(powers[:, ::-1], axis=1)
    degree = powers.sum(axis=1)
    if z.ndim == 1:
        return z[first] * np.where(degree == 1, 1., z[second])
    return z[:, first] * np.where(degree[None, :] == 1, 1., z[:, second])


def _ridge(design, target):
    """One six-output Ridge(alpha=1), with an unpenalized intercept."""
    mean_x = design.mean(axis=0)
    mean_y = target.mean(axis=0)
    x = design - mean_x
    y = target - mean_y
    if x.shape[0] <= x.shape[1]:
        coefficient = x.T @ np.linalg.solve(x @ x.T + ALPHA * np.eye(len(x)), y)
    else:
        coefficient = np.linalg.solve(x.T @ x + ALPHA * np.eye(x.shape[1]), x.T @ y)
    return coefficient.T, mean_y - mean_x @ coefficient


def _project(estimate, prefix_d):
    estimate = _vector(estimate, 6, "raw model prediction").copy()
    if not np.isfinite(prefix_d) or prefix_d < 0.:
        raise ValueError("finite nonnegative prefix excursion required")
    estimate[0] = max(0., float(prefix_d), float(estimate[0] * D_SCALE_M))
    # Signed terminal outputs must not be clamped or rescued by their sign.
    return estimate


def feature_specification():
    return {
        "schema": VERSION, "names": list(FEATURE_NAMES), "count": 23,
        "physical_floor": PHYSICAL_FLOORS.tolist(),
        "scale": "max(TRAIN population std, physical floor); TRAIN-only mean",
        "action_conditional_fields": [1, 11, 12, 16, 17, 18, 19, 20, 21, 22],
        "acceleration": "current model forward under this action's sent torque; not sensed/future acceleration or algebraic qdd",
        "desired_ax": "same-gamma weighted C/B endpoint references; single endpoints use their own reference",
        "prefix": "independent native 20ms/10-step PREFIX_PREDICTION; no actual-future input",
        "NO_EXPLICIT_CAPACITY_dropped_indices": list(DROP_CAPACITY_INDICES),
        "online_PID_prior": False,
        "forbidden_inputs": ["episode", "tick", "split", "future label", "gap"],
        "missing": "reject action; never zero-impute missing current/prefix input",
    }


def _empty_prediction(gamma):
    return {
        "gamma": float(gamma), "accepted": False, "reasons": [], "group": None,
        "D_hat": None, "Y_hat": None, "U_D": None, "U_T": None, "D_prefix_m": None,
        "support_gate": False, "distance_gate": False, "calibration_gate": False,
        "pose_gate": False, "current_command_gate": False, "prefix_available_gate": False,
        "prefix_physical_gate": False, "terminal_gate": False, "local_gate": False,
        "neighbor_ids": [], "neighbor_distances": [], "neighbor_complete": [],
        "neighbor_original_physical": [], "nearest_distance": None, "distance_threshold": None,
        "cal_complete_count": 0, "cal_distinct_source_snapshots": 0, "cal_episode_count": 0,
        "pose_value_rad": None, "pose_interval_rad": None, "pose_pad_rad": POSE_PAD_RAD,
    }


def _action_entries(actions_inputs):
    if isinstance(actions_inputs, dict):
        iterable = actions_inputs.items()
    else:
        iterable = ((entry["gamma"], entry) for entry in actions_inputs)
    result = {}
    for key, entry in iterable:
        canonical = gamma_key(key)
        if canonical in result:
            raise ValueError("duplicate action gamma")
        if not isinstance(entry, dict):
            raise ValueError("each action input must be a mapping")
        copied = dict(entry)
        if "gamma" not in copied:
            copied["gamma"] = float(key)
        if gamma_key(copied["gamma"]) != canonical:
            raise ValueError("action mapping key differs from its declared gamma")
        result[canonical] = copied
    return result


def predict(bundle, actions_inputs):
    """Predict supplied actions, without labels, trajectories, or sklearn."""
    entries = _action_entries(actions_inputs)
    predictions = {}
    configuration = bundle["configuration_id"]
    for key, entry in entries.items():
        point = _empty_prediction(float(key))
        try:
            feature = _input_features(entry)
            role = _role(entry)
            group_id = group_key(configuration, entry["gamma"], role)
            group = bundle["groups"][group_id]
            point.update(group=group_id, fault_role=role,
                         cal_complete_count=int(group["cal_complete_count"]),
                         cal_distinct_source_snapshots=int(group["cal_distinct_source_snapshots"]),
                         cal_episode_count=int(group["cal_episode_count"]),
                         distance_threshold=float(group["distance_threshold"]))
            pose = feature[[2, 3]]
            pose_min = np.asarray(bundle["pose_min"], dtype=float)
            pose_max = np.asarray(bundle["pose_max"], dtype=float)
            pose_gate = bool(np.all(pose >= pose_min - POSE_PAD_RAD)
                             and np.all(pose <= pose_max + POSE_PAD_RAD))
            point.update(pose_gate=pose_gate, pose_value_rad=pose.tolist(),
                         pose_interval_rad={"names": ["roll_rad", "direction_pitch_rad"],
                                            "min": pose_min.tolist(), "max": pose_max.tolist()})
            if not pose_gate:
                point["reasons"].append("OUTSIDE_FROZEN_POSE_DOMAIN")
            z = (feature[bundle["feature_indices"]] - bundle["mean"]) / bundle["scale"]
            distances = np.sqrt(np.sum((group["train_z"] - z) ** 2, axis=1))
            indices = np.argsort(distances, kind="stable")[:K]
            nearest = float(distances[indices[0]]) if len(indices) else None
            support = bool(len(indices) == K and np.all(group["train_complete"][indices])
                           and np.all(group["train_physical"][indices]))
            distance_gate = bool(nearest is not None and nearest <= group["distance_threshold"])
            point.update(support_gate=support, distance_gate=distance_gate,
                         neighbor_ids=[str(group["train_ids"][i]) for i in indices],
                         neighbor_distances=distances[indices].tolist(),
                         neighbor_complete=group["train_complete"][indices].tolist(),
                         neighbor_original_physical=group["train_physical"][indices].tolist(),
                         nearest_distance=nearest,
                         calibration_gate=bool(bundle["trained"] and group["calibrated"]))
            if len(indices) != K:
                point["reasons"].append("INSUFFICIENT_TRAIN_NEIGHBORS")
            if len(indices) and not np.all(group["train_complete"][indices]):
                point["reasons"].append("NEIGHBOR_NUMERICAL_INCOMPLETE")
            if len(indices) and not np.all(group["train_physical"][indices]):
                point["reasons"].append("NEIGHBOR_ORIGINAL_PHYSICAL_FAILURE")
            if not distance_gate:
                point["reasons"].append("OUTSIDE_CAL_NEAREST_TRAIN_DISTANCE")
            if not bundle["trained"]:
                point["reasons"].append("NO_COMPLETE_TRAIN_LABELS")
            if not group["calibrated"]:
                point["reasons"].append("INSUFFICIENT_DISTINCT_COMPLETE_CAL")
            command_valid = bool(entry.get("first_command_valid", False))
            point["current_command_gate"] = command_valid
            if not command_valid:
                point["reasons"].append("FIRST_COMMAND_UNAVAILABLE")
            prefix = entry.get("prefix")
            available = prefix_available(prefix)
            physical = prefix_physical_pass(prefix)
            point.update(prefix_available_gate=available, prefix_physical_gate=physical)
            if not available:
                point["reasons"].append("PREFIX_UNAVAILABLE")
            if not physical:
                point["reasons"].append("PREFIX_ORIGINAL_PHYSICAL_FAILURE_OR_MISSING")
            prefix_d = prefix_displacement(prefix)
            point["D_prefix_m"] = float(prefix_d)
            if bundle["trained"]:
                raw = _design(z, bundle["powers"]) @ bundle["coefficient"].T + bundle["intercept"]
                estimate = _project(raw, prefix_d)
                point.update(D_hat=float(estimate[0]), Y_hat=estimate[1:].tolist())
                if group["calibrated"]:
                    margin = group["cal_margin"]
                    point.update(U_D=float(estimate[0] + margin[0] + D_RESERVE_M),
                                 U_T=(np.abs(estimate[1:]) + margin[1:] + TERMINAL_RESERVE).tolist())
        except (KeyError, ValueError, TypeError, IndexError) as exc:
            point["input_error"] = str(exc)
            point["reasons"].append("MISSING_OR_NONFINITE_CURRENT_PREFIX_INPUT")
        predictions[key] = point
    return predictions


def decide(bundle, actions_inputs, gap, allowed=GAMMA_GRID):
    """Choose the largest independently approved gamma; no monotonic assumption."""
    if not np.isfinite(gap) or gap < 0.:
        raise ValueError("finite nonnegative gap metres required")
    ordered = tuple(sorted({float(gamma) for gamma in allowed}, reverse=True))
    for gamma in ordered:
        gamma_key(gamma)
    predictions = predict(bundle, actions_inputs)
    gates = ("support_gate", "distance_gate", "calibration_gate", "pose_gate",
             "current_command_gate", "prefix_available_gate", "prefix_physical_gate",
             "terminal_gate", "local_gate")
    for key, point in predictions.items():
        point["terminal_gate"] = bool(point["U_T"] is not None and np.isfinite(point["U_T"]).all()
                                      and np.all(np.asarray(point["U_T"]) <= 1.))
        point["local_gate"] = bool(point["U_D"] is not None and np.isfinite(point["U_D"])
                                   and point["U_D"] <= gap)
        if not point["terminal_gate"]:
            point["reasons"].append("TERMINAL_RATIO_REJECT")
        if not point["local_gate"]:
            point["reasons"].append("LOCAL_DISPLACEMENT_MARGIN_REJECT")
        point["accepted"] = bool(float(key) in ordered and all(point[gate] for gate in gates))
    for gamma in ordered:
        key = gamma_key(gamma)
        if key not in predictions:
            predictions[key] = _empty_prediction(gamma)
            predictions[key]["reasons"].append("ACTION_INPUT_NOT_SUPPLIED")
    choice = next((gamma for gamma in ordered if predictions[gamma_key(gamma)]["accepted"]), "ABSTAIN")
    return {
        "choice": choice, "gamma": None if choice == "ABSTAIN" else choice,
        "accepted": choice != "ABSTAIN", "gap_m": float(gap), "allowed": list(ordered),
        "predictions": predictions, "configuration_id": bundle["configuration_id"],
        "comparison_id": BINARY if ordered == (1., 0.) and bundle["configuration_id"] == MAIN else bundle["configuration_id"],
        "reject_reasons": [] if choice != "ABSTAIN" else list(dict.fromkeys(
            reason for gamma in ordered for reason in predictions[gamma_key(gamma)]["reasons"])),
    }


def _identity(record, key):
    value = record.get(key)
    if value is None and key == "episode":
        value = record.get("episode_id")
    if value is None or value == "":
        raise ValueError("explicit " + key + " identity required")
    return str(value) if isinstance(value, (str, int, float)) else json.dumps(value, sort_keys=True, allow_nan=False)


def _cal_group(bundle, train, cal, group_id):
    configuration = bundle["configuration_id"]
    group_train = [record for record in train if group_key(configuration, record["gamma"], _role(record)) == group_id]
    group_cal = [record for record in cal if group_key(configuration, record["gamma"], _role(record)) == group_id]
    size = len(bundle["feature_indices"])
    train_z = np.asarray([(_input_features(record)[bundle["feature_indices"]] - bundle["mean"]) / bundle["scale"]
                          for record in group_train], dtype=float).reshape(-1, size)
    cal_z = np.asarray([(_input_features(record)[bundle["feature_indices"]] - bundle["mean"]) / bundle["scale"]
                        for record in group_cal], dtype=float).reshape(-1, size)
    nearest = np.sqrt(np.min(np.sum((cal_z[:, None, :] - train_z[None, :, :]) ** 2, axis=2), axis=1)) if len(cal_z) and len(train_z) else np.empty(0)
    cal_max = float(np.max(nearest)) if len(nearest) else 0.
    complete_cal = []
    predictions = []
    for index, record in enumerate(group_cal):
        target = _complete_target(record)
        try:
            prefix_d = prefix_displacement(record["prefix"])
            if not prefix_available(record["prefix"]):
                continue
        except (KeyError, ValueError, TypeError, IndexError):
            continue
        if target is None:
            continue
        complete_cal.append(record)
        if bundle["trained"]:
            raw = _design(cal_z[index], bundle["powers"]) @ bundle["coefficient"].T + bundle["intercept"]
            predictions.append(_project(raw, prefix_d))
    snapshots = sorted({_identity(record, "source_snapshot") for record in complete_cal})
    episodes = sorted({_identity(record, "episode") for record in complete_cal})
    calibrated = bool(bundle["trained"] and len(complete_cal) >= MIN_CAL_SNAPSHOTS
                      and len(snapshots) >= MIN_CAL_SNAPSHOTS and len(episodes) >= MIN_CAL_EPISODES)
    margin = np.zeros(6)
    if predictions:
        observed = np.asarray([_target(record["labels"]) for record in complete_cal])
        estimates = np.asarray(predictions)
        margin[0] = max(0., float(np.max(observed[:, 0] - estimates[:, 0])))
        margin[1:] = np.max(np.abs(observed[:, 1:] - estimates[:, 1:]), axis=0)
    return {
        "train_z": train_z, "train_ids": np.asarray([record["id"] for record in group_train], dtype=str),
        "train_complete": np.asarray([_complete_target(record) is not None for record in group_train], dtype=bool),
        "train_physical": np.asarray([_physical(record["labels"]) for record in group_train], dtype=bool),
        "calibrated": calibrated, "cal_margin": margin,
        "cal_max_nearest_distance": cal_max, "distance_threshold": max(3. * cal_max, DISTANCE_FLOOR),
        "train_finite_ids": [record["id"] for record in group_train],
        "cal_finite_ids": [record["id"] for record in group_cal],
        "cal_complete_ids": [record["id"] for record in complete_cal],
        "cal_complete_count": len(complete_cal), "cal_distinct_source_snapshots": len(snapshots),
        "cal_episode_count": len(episodes), "cal_source_snapshots": snapshots, "cal_episodes": episodes,
    }


_BUNDLE_ARRAYS = ("feature_indices", "powers", "mean", "scale", "train_std", "physical_floor",
                  "coefficient", "intercept", "pose_min", "pose_max")
_GROUP_ARRAYS = ("train_z", "train_ids", "train_complete", "train_physical", "cal_margin")


def _save_bundle(bundle, directory):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / ("step29_" + bundle["configuration_id"].lower() + ".npz")
    if path.exists() or path.with_suffix(".json").exists():
        raise FileExistsError("frozen STEP29 assets cannot be overwritten")
    arrays = {key: bundle[key] for key in _BUNDLE_ARRAYS}
    metadata = {key: value for key, value in bundle.items() if key not in _BUNDLE_ARRAYS and key != "groups"}
    metadata["groups"] = {}
    for index, (group_id, group) in enumerate(bundle["groups"].items()):
        prefix = "group" + str(index) + "_"
        arrays.update({prefix + key: group[key] for key in _GROUP_ARRAYS})
        metadata["groups"][group_id] = {key: value for key, value in group.items() if key not in _GROUP_ARRAYS}
        metadata["groups"][group_id]["array_prefix"] = prefix
    metadata.update(alpha=ALPHA, quadratic_bias=False, D_target_scale_m=D_SCALE_M,
                    D_reserve_m=D_RESERVE_M, terminal_reserve=TERMINAL_RESERVE,
                    terminal_names=list(TERMINAL_NAMES), feature_specification=feature_specification())
    with path.open("xb") as stream:
        np.savez_compressed(stream, **arrays)
    with path.with_suffix(".json").open("x", encoding="utf-8") as stream:
        json.dump(metadata, stream, sort_keys=True, indent=2, allow_nan=False)
    return {"npz": str(path.resolve()), "json": str(path.with_suffix(".json").resolve()),
            "npz_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "json_sha256": hashlib.sha256(path.with_suffix(".json").read_bytes()).hexdigest()}


def load_bundle(path, configuration=MAIN):
    path = Path(path)
    if path.is_dir():
        freeze = json.loads((path / "MODEL_FREEZE.json").read_text(encoding="utf-8"))
        path = Path(freeze["assets"][configuration]["npz"])
    metadata = json.loads(path.with_suffix(".json").read_text(encoding="utf-8"))
    if metadata["schema"] != VERSION or metadata["configuration_id"] not in CONFIGURATIONS:
        raise ValueError("unsupported STEP29 model schema/configuration")
    with np.load(path, allow_pickle=False) as archive:
        result = dict(metadata)
        result.update({key: archive[key].copy() for key in _BUNDLE_ARRAYS})
        result["groups"] = {}
        for group_id, group_metadata in metadata["groups"].items():
            group = dict(group_metadata)
            prefix = group.pop("array_prefix")
            group.update({key: archive[prefix + key].copy() for key in _GROUP_ARRAYS})
            result["groups"][group_id] = group
    return result


def fit_fixed(records, outdir):
    """Fit only the two predeclared six-output DEV models; freeze main by name."""
    records = list(records)
    if any(record.get("split") not in ("TRAIN", "CAL") for record in records):
        raise ValueError("STEP29 fitting refuses new TEST or unrecognized split")
    if len({record["id"] for record in records}) != len(records):
        raise ValueError("duplicate STEP29 DEV action ID")
    snapshot_splits = {}
    episode_splits = {}
    for record in records:
        gamma_key(record["gamma"])
        _role(record)
        for key, registry in (("source_snapshot", snapshot_splits), ("episode", episode_splits)):
            identity = _identity(record, key)
            if identity in registry and registry[identity] != record["split"]:
                raise ValueError("TRAIN/CAL leak across whole " + key)
            registry[identity] = record["split"]
    outdir = Path(outdir)
    if (outdir / "MODEL_FREEZE.json").exists() or any(
        (outdir / ("step29_" + configuration.lower() + suffix)).exists()
        for configuration in CONFIGURATIONS for suffix in (".npz", ".json")
    ):
        raise FileExistsError("frozen STEP29 assets cannot be overwritten or refitted")
    train_all = [record for record in records if record["split"] == "TRAIN"]
    cal_all = [record for record in records if record["split"] == "CAL"]
    train = [record for record in train_all if _finite_input(record) is not None]
    cal = [record for record in cal_all if _finite_input(record) is not None]
    if not train:
        raise ValueError("no finite STEP29 TRAIN features")
    x23 = np.asarray([_input_features(record) for record in train])
    pose_inputs = np.asarray([_input_features(record)[[2, 3]] for record in train + cal])
    regression_indices = [index for index, record in enumerate(train) if _complete_target(record) is not None]
    bundles = {}
    assets = {}
    fit_calls = []
    for configuration in CONFIGURATIONS:
        feature_indices = np.asarray([index for index in range(23) if configuration == MAIN or index not in DROP_CAPACITY_INDICES], dtype=np.int64)
        x = x23[:, feature_indices]
        mean = x.mean(axis=0)
        std = x.std(axis=0, ddof=0)
        floors = PHYSICAL_FLOORS[feature_indices]
        scale = np.maximum(std, floors)
        powers = _powers(len(feature_indices))
        trained = bool(regression_indices)
        if trained:
            target = np.asarray([_target(train[index]["labels"]) for index in regression_indices])
            target[:, 0] /= D_SCALE_M
            design = _design((x - mean) / scale, powers)
            coefficient, intercept = _ridge(design[regression_indices], target)
            fit_calls.append({"configuration_id": configuration, "outputs": 6,
                              "multioutput_estimator_fit": 1, "training_count": len(regression_indices),
                              "alpha": ALPHA, "family": "quadratic"})
        else:
            coefficient = np.full((6, len(powers)), np.nan)
            intercept = np.full(6, np.nan)
        bundle = {
            "schema": VERSION, "configuration_id": configuration, "family": "quadratic", "k": K,
            "trained": trained, "feature_indices": feature_indices, "powers": powers,
            "mean": mean, "train_std": std, "physical_floor": floors.copy(), "scale": scale,
            "coefficient": coefficient, "intercept": intercept,
            "pose_min": pose_inputs.min(axis=0), "pose_max": pose_inputs.max(axis=0),
            "pose_source_ids": [record["id"] for record in train + cal], "pose_pad_rad": POSE_PAD_RAD,
            "train_ids_all": [record["id"] for record in train_all],
            "cal_ids_all": [record["id"] for record in cal_all],
            "train_regression_ids": [train[index]["id"] for index in regression_indices],
            "groups": {}, "actual_commands_capacity_conditioned": True,
        }
        group_ids = [group_key(configuration, gamma, role) for gamma in GAMMA_GRID
                     for role in (ROLES if configuration == MAIN else ("healthy",))]
        bundle["groups"] = {key: _cal_group(bundle, train, cal, key) for key in group_ids}
        bundles[configuration] = bundle
        assets[configuration] = _save_bundle(bundle, outdir)
    summary = {
        "TRAIN_planned": len(train_all), "CAL_planned": len(cal_all),
        "TRAIN_finite": len(train), "CAL_finite": len(cal),
        "TRAIN_complete_regression": len(regression_indices),
        "TRAIN_missing_input": len(train_all) - len(train), "CAL_missing_input": len(cal_all) - len(cal),
        "all_source_role": "DEV", "new_TEST_consumed": False,
    }
    freeze = {
        "schema": VERSION, "model_frozen": True, "fixed_model_configurations": 2,
        "actual_multioutput_estimator_fit_calls": len(fit_calls),
        "actual_branch_multioutput_estimator_fit_calls": len(fit_calls),
        "scalar_output_regression_equivalents": 6 * len(fit_calls), "fit_call_ledger": fit_calls,
        "selected_configuration_id": MAIN, "selected_main_configuration_id": MAIN,
        "nocapacity_configuration_id": NO_CAPACITY, "selection_status": "PREDECLARED_MAIN",
        "selection_order": [], "new_TEST_model_selection": False,
        "binary_same_model": {"configuration_id": MAIN, "allowed_gamma": [1., 0.], "additional_fit_calls": 0},
        "gamma_grid": list(GAMMA_GRID), "assets": assets, "split_summary": summary,
        "feature_specification": feature_specification(),
        "pose_applicability": {"min": bundles[MAIN]["pose_min"].tolist(), "max": bundles[MAIN]["pose_max"].tolist(),
                               "pad_rad": POSE_PAD_RAD, "original_physical_bounds_changed": False},
        "groups": {configuration: {key: {field: group[field] for field in
                    ("calibrated", "cal_complete_count", "cal_distinct_source_snapshots", "cal_episode_count",
                     "cal_max_nearest_distance", "distance_threshold")}
                    for key, group in bundle["groups"].items()} for configuration, bundle in bundles.items()},
        "split_registry": [{"id": record["id"], "split": record["split"], "gamma": float(record["gamma"]),
                            "role": _role(record), "source_snapshot": _identity(record, "source_snapshot"),
                            "episode": _identity(record, "episode"), "finite_input": _finite_input(record) is not None}
                           for record in records],
    }
    outdir.mkdir(parents=True, exist_ok=True)
    freeze_path = outdir / "MODEL_FREEZE.json"
    with freeze_path.open("x", encoding="utf-8") as stream:
        json.dump(freeze, stream, sort_keys=True, indent=2, allow_nan=False)
    return dict(freeze, selected_main=bundles[MAIN], selected=bundles[MAIN], selected_bundle=bundles[MAIN],
                nocapacity=bundles[NO_CAPACITY], selected_nocapacity=bundles[NO_CAPACITY],
                bundles=bundles, freeze_path=str(freeze_path.resolve()))
