"""STEP30 checked actions: one common-row identity check, no new optimizer.

All tolerances, endpoint decoding and backup semantics are the frozen STEP29
ones.  A shared workspace holds references to the copied current-call numeric
evidence rather than copying full endpoints for each gamma.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from cavr_wbc.control import step29_actions as old
from cavr_wbc.experiments.step26_features_storage import _compiled_mapping

VERSION = 'STEP30_SHARED_CHECKED_ACTIONS_V1'
GAMMA_GRID = old.GAMMA_GRID
SYNTHESIZED_KIND = old.SYNTHESIZED_KIND
GEOMETRY_NAMES = ('direction_side_front_rear', 'fault_or_healthy_calf_joint_q_rad',
                  'fault_or_healthy_all_channel_min_sent_headroom')
GEOMETRY_UNITS = ('dimensionless', 'rad', 'dimensionless')
GEOMETRY_SCALE_FLOORS = np.array([1., .1, .1])
capture_matrices = old.capture_matrices
frozen_contract = old.frozen_contract
check_rows = old.check_rows
shared_matrices = old.shared_matrices
action_current_features = old.action_current_features
convex_command_property = old.convex_command_property


@dataclass
class SharedActions:
    context: dict
    endpoints: dict
    matrices: dict
    status: dict
    zC: object = None
    zB: object = None
    refC: object = None
    refB: object = None
    reason: object = None
    shared_identity_checks: int = 1


def prepare_shared(context, C, B, matrices=None):
    """Check C/B affine coefficients/current identity once, with zero solves."""
    endpoints = {'C': C or {}, 'B': B or {}}
    mats = matrices or {k: ep.get('source_matrices') for k, ep in endpoints.items()}
    if 'A' in mats: mats = {'C': mats, 'B': mats}
    statuses = {k: old._status(ep) for k, ep in endpoints.items()}
    workspace = SharedActions(context, endpoints, mats, statuses)
    if any(statuses[k] != 1 or not endpoints[k].get('command_valid',
           endpoints[k].get('valid_command', endpoints[k].get('available', False))) for k in ('C','B')):
        workspace.reason = 'BOTH_EXACT_SOLVED_ENDPOINTS_REQUIRED'; return workspace
    same, reason = shared_matrices(mats.get('C'), mats.get('B'))
    if not same: workspace.reason = reason; return workspace
    matrix = mats['C']; state = context.get('state', context.get('source_state', context))
    if (matrix['context_id'] != str(context['context_id']) or
        not np.array_equal(matrix['health_vector'], context['health_vector']) or
        any(not np.array_equal(matrix[k], state[k]) for k in ('qpos','qvel')) or
        not np.array_equal(matrix['integration_state'], state.get('integration_state', []))):
        workspace.reason = 'CURRENT_STATE_HEALTH_IDENTITY_MISMATCH'; return workspace
    shape = (matrix['nv'], matrix['nu'], matrix['nc'])
    workspace.zC = old._variables(endpoints['C'], *shape)
    workspace.zB = old._variables(endpoints['B'], *shape)
    if workspace.zC is None or workspace.zB is None:
        workspace.reason = 'SOURCE_FULL_PRIMAL_UNAVAILABLE'; return workspace
    workspace.refC = old._reference(endpoints['C']); workspace.refB = old._reference(endpoints['B'])
    return workspace


def make_action(context, C, B, gamma, matrices=None, workspace=None):
    """Frozen arithmetic and exact row checks, with cached shared identity."""
    gamma = float(gamma)
    if gamma not in GAMMA_GRID: raise ValueError('STEP30 gamma outside fixed grid')
    if gamma in (1.,0.):
        return old.make_action(context, C, B, gamma, matrices)
    ws = workspace if workspace is not None else prepare_shared(context,C,B,matrices)
    if ws.context is not context and ws.context['context_id'] != context['context_id']:
        raise ValueError('STEP30 shared workspace reused for another context')
    if ws.reason: return old._missing(gamma, ws.reason, ws.status)
    matrix=ws.matrices['C']; nv,nu,nc=matrix['nv'],matrix['nu'],matrix['nc']
    # Exact original construction/order and full A @ z checks.  There is no
    # endpoint residual surrogate, slack, or repeat affine-row assembly.
    z = gamma*ws.zC + (1.-gamma)*ws.zB
    raw=z[nv:nv+nu].copy(); health=matrix['health_vector']; limits=matrix['healthy_torque_limits_nm']
    capacity=health*limits; sent=np.clip(raw,-capacity,capacity)
    sent_z=z.copy(); sent_z[nv:nv+nu]=sent
    raw_check=check_rows(matrix,z); sent_check=check_rows(matrix,sent_z)
    valid=bool(raw_check['pass'] and sent_check['pass'])
    ref = gamma*ws.refC+(1.-gamma)*ws.refB if ws.refC is not None and ws.refB is not None else None
    active=np.flatnonzero((capacity<=0.) | (np.abs(sent)>=.99*capacity))
    interface={'command_valid':valid,'solver_status_val':None,'solver_exact_solved':False,
        'source_solver_statuses':ws.status,'version':VERSION,'health_vector':health,
        'healthy_torque_limits_nm':limits,'effective_capacity_nm':capacity,'tau_raw':raw,'tau_sent':sent,
        'saturation_mask':sent!=raw,'correction_nm':sent-raw,
        'sent_command_within_capacity_exact':bool(np.all(np.abs(sent)<=capacity)),
        'sent_99_percent_active_indices':active}
    return {'schema':VERSION,'gamma':gamma,'kind':SYNTHESIZED_KIND,'available':valid,
        'command_valid':valid,'execution_eligible':valid,'features_available':ref is not None,
        'unavailable_reason':None if valid else 'RAW_OR_SENT_HARD_ROW_REJECTED',
        'solver_status_val':None,'source_solver_statuses':ws.status,
        'source_primal_variables':{'C':ws.zC,'B':ws.zB},'qdd':z[:nv].copy(),
        'contact_lambda':z[nv+nu:].copy(),'z_raw':z,'z_sent':sent_z,'tau_raw':raw,'tau_sent':sent,
        'health_vector':health,'capacity_interface':interface,'raw_hard_check':raw_check,
        'sent_hard_check':sent_check,'clip_dynamics_residual_delta':
            sent_check['dynamics_residual_signed']-raw_check['dynamics_residual_signed'],
        'a_base_ref':ref,'source_matrices':matrix,'shared_A_l_u_exact':True,
        'shared_identity_checks_for_workspace':ws.shared_identity_checks,
        'first_capacity_event':bool(len(active)),'backup_initial_b':np.zeros(6),'integral_record':None,
        'new_solver_called':False,'new_QP_calls':0,'synthetic_is_optimizer_return':False,
        'optimality_claim':False,'hard_validation_pass':valid}


class GeometryMapping:
    """Compiled actuator metadata in resident arrays with fixed SI units."""
    def __init__(self,mapping,healthy_limits=None):
        self.entries=_compiled_mapping(mapping)
        self.qpos_addresses=np.ascontiguousarray([e['qpos_address'] for e in self.entries],dtype=np.int32)
        self.names=tuple(e['name'] for e in self.entries)
        # ctrl_range is a compiled direct-motor field, not XML text.  Its
        # already-audited symmetric unit-gear semantics match the platform
        # healthy-limit extractor; unsupported transmissions fail here.
        def compiled_limit(entry):
            known=entry.get('healthy_limit_nm',entry.get('healthy_torque_limit_nm'))
            if known is not None:return known
            bounds=np.asarray(entry.get('ctrl_range'),dtype=float)
            gear=np.asarray(entry.get('gear'),dtype=float)
            if (bounds.shape!=(2,) or not np.isfinite(bounds).all() or not entry.get('ctrl_limited') or
                bounds[0]!=-bounds[1] or bounds[1]<=0. or entry.get('unit')!='N*m' or
                gear.shape!=(6,) or not np.array_equal(gear,np.r_[1.,np.zeros(5)])):
                raise ValueError('STEP30 requires audited compiled symmetric direct-motor torque metadata')
            return bounds[1]
        self.limits=np.ascontiguousarray(healthy_limits if healthy_limits is not None else
            [compiled_limit(e) for e in self.entries],dtype=float)
        if self.limits.shape!=(12,) or not np.isfinite(self.limits).all() or np.any(self.limits<=0.):
            raise ValueError('STEP30 positive compiled healthy torque limits required')
        self.calf_by_direction=(self.names.index('RR_calf'),self.names.index('FR_calf'))
        for side in ('FR','RR'):
            if any(side+'_'+joint not in self.names for joint in ('hip','thigh','calf')):
                raise ValueError('STEP30 compiled direction-side joint mapping missing')
        self.specification={'names':GEOMETRY_NAMES,'units':GEOMETRY_UNITS,
            'scale_floors':GEOMETRY_SCALE_FLOORS.tolist(),
            'qpos_addresses':self.qpos_addresses.tolist(),'actuator_names':list(self.names),
            'healthy_torque_limits_nm':self.limits.tolist(),
            'direction_side':'vx>0: FR/front +1; vx<0: RR/rear -1',
            'damaged_convention':'explicit compiled fault joint angle and channel headroom',
            'healthy_convention':'direction-side calf angle; minimum headroom over all 12 channels',
            'headroom':'1-abs(tau_sent)/(health*compiled healthy_limit)',
            'address_and_limits_source':'compiled mjModel actuator metadata; not XML or trajectory labels'}

    def query(self,context,action):
        state=context.get('state',context.get('source_state',context))
        qpos=np.asarray(state['qpos'],dtype=float);qvel=np.asarray(state['qvel'],dtype=float)
        health=np.asarray(context['health_vector'],dtype=float);sent=np.asarray(action['tau_sent'],dtype=float)
        if (qpos.ndim!=1 or qvel.ndim!=1 or qvel.size<6 or abs(qvel[0])<.01 or
            any(v.shape!=(12,) or not np.isfinite(v).all() for v in (health,sent)) or
            not np.isfinite(qpos).all() or not np.isfinite(qvel).all() or
            np.any((health<=0.)|(health>1.)) or np.any(self.qpos_addresses<0) or
            np.any(self.qpos_addresses>=qpos.size)):
            raise ValueError('STEP30 finite current compiled geometry input required')
        front=bool(qvel[0]>0.);side='FR' if front else 'RR';calf=self.calf_by_direction[int(front)]
        declared=context.get('faulted_actuator_index');name=context.get('faulted_actuator_name')
        if np.any(health<1.):
            if (not isinstance(declared,(int,np.integer)) or int(declared) not in range(12) or
                np.count_nonzero(health<1.)!=1 or health[int(declared)]>=1. or
                name!=self.names[int(declared)] or name not in (side+'_thigh',side+'_calf')):
                raise ValueError('STEP30 compiled fault channel/health/direction identity mismatch')
            index=int(declared)
        else:
            if declared is not None or name not in (None,'NONE'):
                raise ValueError('STEP30 healthy reference cannot declare a damaged channel')
            index=-1
        if action.get('health_vector') is not None and not np.array_equal(action['health_vector'],health):
            raise ValueError('STEP30 action/context full health mismatch')
        if action.get('capacity_interface',{}).get('healthy_torque_limits_nm') is not None and not np.array_equal(
            action['capacity_interface']['healthy_torque_limits_nm'],self.limits):
            raise ValueError('STEP30 action/compiled capacity mismatch')
        return qpos,qvel,health,sent,index,calf


def geometry_features(context,action,mapping):
    compiled=mapping if isinstance(mapping,GeometryMapping) else GeometryMapping(mapping)
    qpos,qvel,health,sent,index,calf=compiled.query(context,action)
    headroom=1.-np.abs(sent)/(health*compiled.limits)
    return np.array([1. if qvel[0]>0. else -1.,qpos[compiled.qpos_addresses[index if index>=0 else calf]],
                    headroom[index] if index>=0 else np.min(headroom)],dtype=float)


def action_features(context,action,prefix,mapping):
    feature=np.r_[old.action_features(context,action,prefix,
        mapping.entries if isinstance(mapping,GeometryMapping) else mapping),
        geometry_features(context,action,mapping)]
    if feature.shape!=(26,) or not np.isfinite(feature).all():
        raise ValueError('STEP30 finite action-conditioned 26-vector required')
    return feature
