"""Resident STEP30 batch prefix and absolute-deadline action governor.

The shared QP, output layer, physical bitmask and feedback policy are inherited
read-only.  Every batch member independently restores the same current state;
no teacher trajectory or PID prior is consumed by the online path.
"""
from __future__ import annotations
import ctypes
import json
from pathlib import Path
from time import perf_counter
import mujoco
import numpy as np
from cavr_wbc.control.step29_kernel import Kernel as PreviousKernel, NativeActionPrefix as PreviousPrefix
from cavr_wbc.control.step29_kernel import DEADLINE_S,FINAL_RESERVE_S,MIN_SOLVER_S,MAX_SOLVER_S
from cavr_wbc.control.step27_resident_kernel import _copy_integration
from cavr_wbc.control.step28_native_prefix import (
    _Buffers,_Request,_Output,_pointer,D,I,STATE_COUNT,PHYSICS_STEPS,PHYSICS_DT_S,
    PHYSICAL_NAMES,SCALAR_NAMES,CONTACT_NAMES,
)
from cavr_wbc.control.step28_physics_residual import append_prefix_features
from cavr_wbc.control.step27_structured_margin import extract_features
from cavr_wbc.control.step30_actions import (
    GAMMA_GRID,SYNTHESIZED_KIND,GeometryMapping,geometry_features,prepare_shared,make_action,
)
from cavr_wbc.platforms.go2_mujoco import FOOT_NAMES

VERSION='STEP30_INJURED_BATCH_KERNEL_V1'
BATCH_GRID=(.75,.5,.25,0.)


class NativeActionPrefix(PreviousPrefix):
    @classmethod
    def share(cls,existing):
        instance=cls.__new__(cls);instance.__dict__=existing.__dict__
        instance._batch_fn=instance._lib.step30_prefix_batch
        instance._batch_fn.argtypes=[ctypes.c_void_p,ctypes.c_void_p,
            ctypes.POINTER(ctypes.c_void_p),ctypes.POINTER(_Request),ctypes.POINTER(_Output),I,ctypes.c_int]
        instance._batch_fn.restype=ctypes.c_int
        abi=instance._lib.step30_batch_abi;abi.argtypes=[];abi.restype=ctypes.c_int
        if abi()!=1:raise RuntimeError('STEP30 batch ABI mismatch')
        template=instance.buffers['C'].request
        values={name:getattr(template,name) for name,_ in _Request._fields_
            if name not in ('health','tau_sent','x0','direction')}
        instance.batch_buffers=[_Buffers(instance.model,len(instance.limited_addresses),values) for _ in BATCH_GRID]
        instance.batch_source_data=mujoco.MjData(instance.model)
        instance._requests=(_Request*4)();instance._outputs=(_Output*4)()
        instance._destinations=(ctypes.c_void_p*4)();instance._return_codes=np.zeros(4,dtype=np.int32)
        instance.batch_call_count=0;instance.last_batch_record=None
        metadata_path=instance.path.with_name('STEP30_NATIVE_BUILD.json')
        metadata=json.loads(metadata_path.read_text(encoding='utf-8')) if metadata_path.is_file() else None
        instance.native_abi.update(step30_batch_abi=1,step30_build_metadata=metadata,
            preallocated_prefix_MjData=7,native_crossings_per_batch=1,
            maximum_independent_prefixes_per_batch=4,
            batch_restore='independent same initial saved integration state for every member')
        return instance

    def _valid_action(self,context,action):
        health=np.asarray(context['health_vector'],dtype=float)
        raw=np.asarray(action.get('tau_raw'),dtype=float);sent=np.asarray(action.get('tau_sent'),dtype=float)
        if not (action.get('command_valid') and action.get('execution_eligible') and
            all(v.shape==self.healthy_limits.shape and np.isfinite(v).all() for v in (health,raw,sent)) and
            np.array_equal(sent,np.clip(raw,-health*self.healthy_limits,health*self.healthy_limits))):
            return False
        if action.get('kind')==SYNTHESIZED_KIND:
            return bool(action.get('solver_status_val') is None and action.get('shared_A_l_u_exact') and
                action.get('hard_validation_pass') and action.get('raw_hard_check',{}).get('pass') and
                action.get('sent_hard_check',{}).get('pass') and
                all(action.get('source_solver_statuses',{}).get(k)==1 and not isinstance(
                    action['source_solver_statuses'][k],(bool,np.bool_)) for k in ('C','B')))
        status=action.get('solver_status_val')
        return bool(status==1 and not isinstance(status,(bool,np.bool_)))

    def _freeze_output(self,buf,action,context,rc,native_ms,elapsed_ms,batch_index,batch_call):
        count=int(buf.output.state_count);steps=int(buf.output.actual_steps)
        if not 0<=count<=STATE_COUNT or not 0<=steps<=PHYSICS_STEPS:
            raise RuntimeError('STEP30 invalid native batch output counter')
        complete=bool(rc==0 and count==STATE_COUNT and steps==PHYSICS_STEPS and buf.output.all_finite)
        numeric={name:getattr(buf,name)[:count].copy() for name in
            ('qpos','qvel','qacc','applied','subtree_com','joint_margins','contacts','scalars','reason_masks','ncon')}
        numeric.update(tau_raw=buf.tau_raw.copy(),tau_sent=buf.tau_sent.copy(),health_vector=buf.health.copy(),
            healthy_torque_limits_nm=self.healthy_limits.copy(),effective_capacity_nm=buf.health*self.healthy_limits,
            physics_steps=np.arange(count,dtype=np.int32),physical_names=PHYSICAL_NAMES,
            scalar_names=SCALAR_NAMES,contact_names=CONTACT_NAMES,foot_geom_ids=self.foot_ids.copy(),
            base_body_id=int(buf.request.base_id),limited_qpos_addresses=self.limited_addresses.copy())
        endpoint=None
        if complete:
            q=numeric['qpos'][-1];v=numeric['qvel'][-1];s=numeric['scalars'][-1]
            endpoint=dict(zip(('x','y','vx','vy','roll','pitch','roll_rate','pitch_rate'),
                map(float,(q[0],q[1],v[0],v[1],s[0],s[1],v[3],v[4]))))
        self.call_count+=1
        return {'schema':VERSION,'complete':complete,'available':complete,
            'original_physical_pass':bool(complete and buf.output.all_physical_pass),
            'D_prefix_m':float(buf.output.max_direction_displacement) if count and buf.output.all_finite else None,
            'endpoint':endpoint,'direction':float(buf.request.direction),'x0_m':float(buf.request.x0),
            'actual_steps':steps,'state_count':count,'numeric':numeric,'native_ms':native_ms,'elapsed_ms':elapsed_ms,
            'identity':{'context_id':str(context['context_id']),'gamma':float(action['gamma']),
                'mode':'GAMMA' if action['kind']==SYNTHESIZED_KIND else 'B',
                'kind':'PREFIX_PREDICTION','source':'CURRENT_STATE_FIRST_COMMAND',
                'actual_trajectory_read':False,'prefix_call_index':self.call_count,
                'native_batch_call_index':batch_call,'native_batch_member_index':batch_index,
                'native_return_code':rc,'reserved_steps':PHYSICS_STEPS,
                'solver_status_val':action.get('solver_status_val'),
                'source_solver_statuses':action.get('source_solver_statuses')},
            'reason':None if complete else 'NATIVE_NUMERIC_INCOMPLETE' if rc>=0 else 'NATIVE_CONTRACT_ERROR',
            'original_predicates_complete':complete,'command_valid':True,'command_kind':action['kind'],
            'new_QP_calls':0,'new_MjData_calls':0,'actual_state_mutated':False,
            'servo_memory_mutated':False,'physical_dt_s':PHYSICS_DT_S}

    def predict_batch(self,context,actions,budget=None):
        """One C call, independent 10-step prefixes, counted actual work only."""
        begin=perf_counter();results={};requested=[]
        normalized={float(g):a for g,a in actions.items()}
        if any(g not in BATCH_GRID for g in normalized):raise ValueError('STEP30 batch grid excludes C')
        state=context.get('state',context.get('source_state',context))
        qpos=np.asarray(state['qpos'],dtype=float);qvel=np.asarray(state['qvel'],dtype=float)
        if (qpos.shape!=(int(self.model.nq),) or qvel.shape!=(int(self.model.nv),) or
            not np.isfinite(qpos).all() or not np.isfinite(qvel).all() or abs(qvel[0])<.01):
            raise ValueError('STEP30 batch current state/direction invalid')
        anchor=np.asarray(context.get('backup_anchor_q_init',qpos),dtype=float)
        if anchor.shape!=qpos.shape or not np.isfinite(anchor).all():raise ValueError('STEP30 backup anchor invalid')
        for gamma in BATCH_GRID:
            if gamma not in normalized:continue
            action=normalized[gamma]
            if not self._valid_action(context,action):
                results[gamma]=self._missing({'context_id':str(context['context_id']),'gamma':gamma},
                    'FIRST_COMMAND_UNAVAILABLE',begin);continue
            requested.append((gamma,action))
        if not requested:
            self.last_batch_record={'native_crossings':0,'requested_prefixes':len(normalized),
                'dispatched_prefixes':0,'actual_steps':0,'actual_trajectory_read':False}
            return results
        _copy_integration(self.model,self.batch_source_data,context)
        tokens=[]
        try:
            for j,(gamma,action) in enumerate(requested):
                buf=self.batch_buffers[j]
                np.copyto(buf.health,context['health_vector']);np.copyto(buf.tau_raw,action['tau_raw']);np.copyto(buf.tau_sent,action['tau_sent'])
                buf.request.x0=float(anchor[0]);buf.request.direction=1. if qvel[0]>0. else -1.
                buf.output.actual_steps=0;buf.output.state_count=0
                self._requests[j]=buf.request;self._outputs[j]=buf.output
                self._destinations[j]=ctypes.c_void_p(int(buf.data._address));self._return_codes[j]=-99
                if budget is not None:
                    tokens.append(budget.reserve_steps('PREFIX_PREDICTION',str(context['context_id'])+':G'+str(gamma),PHYSICS_STEPS))
        except BaseException:
            if budget is not None:
                for token in tokens:budget.finish_steps(token,0)
            raise
        native_begin=perf_counter()
        try:
            rc=int(self._batch_fn(self._model_pointer,ctypes.c_void_p(int(self.batch_source_data._address)),
                self._destinations,self._requests,self._outputs,_pointer(self._return_codes,True),len(requested)))
        finally:
            if budget is not None:
                for j,token in enumerate(tokens):budget.finish_steps(token,int(self._outputs[j].actual_steps))
        native_ms=(perf_counter()-native_begin)*1000.;self.batch_call_count+=1
        if rc!=0:raise RuntimeError('STEP30 native batch contract error '+str(rc))
        for j,(gamma,action) in enumerate(requested):
            buf=self.batch_buffers[j];buf.output=self._outputs[j]
            results[gamma]=self._freeze_output(buf,action,context,int(self._return_codes[j]),native_ms,
                (perf_counter()-begin)*1000.,j,self.batch_call_count)
        self.last_batch_record={'native_batch_call_index':self.batch_call_count,'native_crossings':1,
            'requested_prefixes':len(normalized),'dispatched_prefixes':len(requested),
            'gammas':np.asarray([g for g,_ in requested]),'actual_steps':sum(p['actual_steps'] for p in results.values()),
            'native_return_codes':self._return_codes[:len(requested)].copy(),'native_ms':native_ms,
            'same_initial_state_independent_restore':True,'physical_predicates_unchanged':True,
            'new_QP_calls':0,'new_MjData_calls':0,'actual_trajectory_read':False}
        return results

    def predict_action(self,current_data,context,action,budget=None):
        # Independent saved integration-state restoration also makes the
        # individual/batch comparison use the same complete source memory.
        _copy_integration(self.model,self.batch_source_data,context)
        return super().predict_action(self.batch_source_data,context,action,budget)


class Kernel(PreviousKernel):
    def __init__(self,model,variant='REFERENCE',prefixdll=None,budget=None):
        begin=perf_counter();super().__init__(model,variant,prefixdll,budget)
        self.native_prefix=NativeActionPrefix.share(self.native_prefix)
        self.geometry_mapping=GeometryMapping(self.mapping,self.healthy_limits)
        self.geometry_specification=self.geometry_mapping.specification
        self._geometry_fn=self.native_prefix._lib.step30_geometry
        self._geometry_fn.argtypes=[D,ctypes.c_int,D,ctypes.c_int,D,D,D,ctypes.c_int,I,
            ctypes.c_int,ctypes.c_int,D];self._geometry_fn.restype=ctypes.c_int
        self._geometry_buffer=np.empty(3,dtype=float)
        from cavr_wbc.control.step30_margin import allocate_numeric
        self._numeric_outputs={n:allocate_numeric(n) for n in range(1,5)}
        self._feature_buffer=np.empty((4,26));self._gamma_buffer=np.empty(4);self._prefix_d_buffer=np.empty(4)
        self.version=VERSION;self.native_abi=self.native_prefix.native_abi
        self.cold_construction_ms=(perf_counter()-begin)*1000.

    def geometry_features(self,context,action):
        qpos,qvel,health,sent,index,calf=self.geometry_mapping.query(context,action)
        rc=int(self._geometry_fn(_pointer(qpos),len(qpos),_pointer(qvel),len(qvel),_pointer(health),
            _pointer(self.geometry_mapping.limits),_pointer(sent),len(sent),
            _pointer(self.geometry_mapping.qpos_addresses,True),index,calf,_pointer(self._geometry_buffer)))
        if rc!=0:raise ValueError('STEP30 compiled geometry contract error '+str(rc))
        return self._geometry_buffer.copy()

    def features(self,context,action,prefix):
        base=action.get('features16')
        if base is None:
            # Native prefix initial row is the exact sent-command mj_forward,
            # avoiding an extra Python contact traversal/mj_forward online.
            numeric=prefix.get('numeric')
            if not prefix.get('complete') or numeric is None:raise ValueError('STEP30 complete native prefix required')
            scalar=numeric['scalars'][0];matrix=action.get('source_matrices')
            points=matrix.get('points') if matrix else None
            if points is None:raise ValueError('STEP30 compiled current foot positions unavailable')
            fact={'qpos':numeric['qpos'][0],'qvel':numeric['qvel'][0],
                'roll':float(scalar[0]),'pitch':float(scalar[1]),'subtree_com':numeric['subtree_com'][0],
                'base_body_id':numeric['base_body_id'],'health_vector':numeric['health_vector'],
                'actuator_limits':numeric['healthy_torque_limits_nm'],
                'effective_capacity_nm':numeric['effective_capacity_nm'],'actual_mujoco_qacc':numeric['qacc'][0]}
            view={'initial_new_command_fact':fact,'tau_sent':action['tau_sent'],
                'response':{'a_base_ref':action['a_base_ref']},
                'foot_positions':{name:points[i] for i,name in enumerate(FOOT_NAMES)}}
            base=extract_features(context,view,self.mapping)
            action['features16']=base;action['initial_new_command_fact']=fact
            action['actual_mujoco_qacc']=numeric['qacc'][0].copy()
        result=np.r_[append_prefix_features(base,prefix,action,context),action['gamma'],self.geometry_features(context,action)]
        if result.shape!=(26,) or not np.isfinite(result).all():raise ValueError('STEP30 finite 26-vector required')
        return result

    def prefix_actions(self,context,actions,budget=None):
        if self._context_id!=str(context['context_id']):raise ValueError('STEP30 batch requires exact current context')
        return self.native_prefix.predict_batch(context,actions,self.budget if budget is None else budget)

    def governor(self,context,bundle,gap,policy='GOVERNOR_LOCAL',budget=None,decide=None):
        """One absolute 20ms window, C early return then eligible batch only.

        Default inference is numeric batched lookup.  A mock decision adapter
        can be injected for pure tests; descriptive strings/files are not part
        of the default model lookup.  All numeric proof/prefix copies are timed.
        """
        if policy not in ('GOVERNOR_LOCAL','BINARY_LOCAL','GOVERNOR_LAZY','BINARY_LAZY','GOVERNOR_PROBE'):
            raise ValueError('STEP30 unknown online policy')
        from cavr_wbc.control.step30_margin import calibrated_gammas,batch_numeric
        begin=perf_counter();deadline=begin+DEADLINE_S;active=self.budget if budget is None else budget
        role=context['health_kind'].split('_')[0].lower()
        grid=(1.,0.) if policy in ('BINARY_LOCAL','BINARY_LAZY') else GAMMA_GRID
        eligible=calibrated_gammas(bundle,role,grid) if decide is None else grid
        evidence={'schema':VERSION,'policy':policy,'context_id':str(context['context_id']),'gap_m':float(gap),
            'deadline_ms':20.,'C':{'status':'NOT_REQUESTED'},'B':{'status':'NOT_REQUESTED'},'actions':{},
            'selected_gamma':None,'selected_action':None,'selected_command_sent':False,'status':'ABSTAIN',
            'prepare_begin':begin,'absolute_deadline':deadline,'new_PID_prior_calls':0,
            'qualified_gammas':np.asarray(eligible),'batch_prefix':None,'shared_identity_checks':0}
        endC=endB=None;last_action=None

        def remaining():return deadline-perf_counter()
        def solver_allowed():
            limit=min(MAX_SOLVER_S,remaining()-FINAL_RESERVE_S)
            if limit<MIN_SOLVER_S:return False
            self.set_next_call_limit(limit);return True
        def stop(action=None,recognized=False):
            # Required mutable numeric results have already been frozen.  The
            # measured command-ready timestamp precedes string/status expansion.
            elapsed=(perf_counter()-begin)*1000.;valid=bool(action and action.get('command_valid'))
            any_valid=bool(valid or any(ep and ep.get('command_valid',ep.get('valid_command',False)) for ep in (endC,endB)))
            timely=bool(elapsed<=20.);sent=bool(recognized and valid and timely)
            evidence.update(elapsed_ms=elapsed,command_ready_ms=elapsed,timely_recognized_command=sent,
                command_available=any_valid,selected_command_valid=valid,raw_valid_but_late=bool(any_valid and not timely),
                overall_deadline_failure=not timely,selected_gamma=float(action['gamma']) if action else None,
                selected_action=action,selected_command_sent=sent,
                status='RECOGNIZED_SENT' if sent else 'COMPUTED_VALID_BUT_LATE' if any_valid and not timely else 'ABSTAIN')
            if action is not None:action['command_ready_ms']=elapsed
            for gamma in grid:
                evidence['actions'].setdefault(str(gamma),{'gamma':gamma,'evaluation_status':
                    'NOT_CALIBRATED' if gamma not in eligible else 'NOT_REQUESTED_AFTER_SELECTION' if sent else 'NOT_EVALUATED_BUDGET'})
            return evidence

        def infer(entries):
            if not entries:return None
            if decide is not None:
                for entry in entries:
                    decision=decide(bundle,entry,float(gap));entry['decision']=decision
                    entry['evaluation_status']='EVALUATED';entry['complete_at_ms']=(perf_counter()-begin)*1000.
                    if bool(decision.get('accepted',decision.get('recognized',False))):return entry['action']
                return None
            n=len(entries)
            for i,entry in enumerate(entries):
                self._feature_buffer[i]=entry['features26'];self._gamma_buffer[i]=entry['gamma']
                self._prefix_d_buffer[i]=entry['prefix']['D_prefix_m']
            numeric=batch_numeric(bundle,self._feature_buffer[:n],self._gamma_buffer[:n],[role]*n,
                self._prefix_d_buffer[:n],out=self._numeric_outputs[n])
            accepted=None
            for i,entry in enumerate(entries):
                copied={name:values[i].copy() if isinstance(values[i],np.ndarray) else values[i].item()
                    for name,values in numeric.items()}
                prefix=entry['prefix'];gate=bool(prefix['complete'] and prefix['original_physical_pass'] and
                    entry['action']['command_valid'] and all(bool(numeric[name][i]) for name in
                    ('finite_input','pose_gate','support_gate','distance_gate','calibration_gate')) and
                    np.all(numeric['U_T'][i]<=1.) and numeric['U_D'][i]<=gap)
                entry['decision']={'accepted':gate,'choice':entry['gamma'] if gate else 'ABSTAIN','numeric':copied}
                entry['evaluation_status']='EVALUATED';entry['complete_at_ms']=(perf_counter()-begin)*1000.
                if gate and accepted is None:accepted=entry['action']
            return accepted

        def entry_for(action,prefix=None):
            entry={'gamma':float(action['gamma']),'role':role,'action':action,'prefix':prefix,'features':None,
                'features26':None,'features23':None,'decision':None,'evaluation_status':'COMMAND_UNAVAILABLE'}
            evidence['actions'][str(float(action['gamma']))]=entry
            if prefix is not None and action['command_valid']:
                try:
                    feature=self.features(context,action,prefix);entry.update(features=feature,features26=feature,features23=feature[:23],
                        first_command_valid=True,evaluation_status='READY_FOR_NUMERIC_LOOKUP')
                except (KeyError,ValueError,TypeError) as exc:
                    entry['evaluation_status']='PREDICTION_INPUT_UNAVAILABLE';entry['feature_error']=str(exc)
            return entry

        if not getattr(self,'ready',False):evidence['not_ready']=True;return stop()
        self.reset(context)
        if active is not None:active.check()
        if not solver_allowed():evidence['C']={'status':'NOT_EVALUATED_BUDGET'};return stop()
        endC=self.nominal(context,active,'ONLINE_C',context['context_id']);evidence['C']=endC
        last_action=make_action(context,endC,None,1.)
        entry=entry_for(last_action)
        if 1. not in eligible:entry['evaluation_status']='NOT_CALIBRATED'
        elif last_action['command_valid'] and remaining()>=FINAL_RESERVE_S:
            prefix=self.prefix_action(context,last_action,active)
            if remaining()<=0.:
                entry['prefix']=prefix;entry['evaluation_status']='NOT_EVALUATED_BUDGET'
                return stop(last_action)
            entry=entry_for(last_action,prefix)
            if entry['features26'] is not None:
                approved=infer([entry])
                if approved is not None:return stop(approved,True)
        elif last_action['command_valid']:entry['evaluation_status']='NOT_EVALUATED_BUDGET'
        lower=tuple(g for g in grid if g<1. and g in eligible)
        if not lower:return stop(last_action)
        if not solver_allowed():evidence['B']={'status':'NOT_EVALUATED_BUDGET'};return stop(last_action)
        endB=self.first_backup(context,active,'ONLINE_B',context['context_id']);evidence['B']=endB
        ws=prepare_shared(context,endC,endB);evidence['shared_identity_checks']=ws.shared_identity_checks
        pending={}
        for gamma in lower:
            action=make_action(context,endC,endB,gamma,workspace=ws);last_action=action;entry_for(action)
            if action['command_valid']:pending[gamma]=action
        if remaining()<FINAL_RESERVE_S:
            for gamma in pending:evidence['actions'][str(gamma)]['evaluation_status']='NOT_EVALUATED_BUDGET'
            return stop(last_action)
        prefixes=self.prefix_actions(context,pending,active)
        evidence['batch_prefix']=self.native_prefix.last_batch_record
        if remaining()<=0.:
            for gamma in pending:
                entry=evidence['actions'][str(gamma)];entry['prefix']=prefixes[gamma]
                entry['evaluation_status']='NOT_EVALUATED_BUDGET'
            return stop(last_action)
        entries=[]
        for gamma in lower:
            if gamma not in pending:continue
            entry=entry_for(pending[gamma],prefixes[gamma])
            if entry['features26'] is not None:entries.append(entry)
        approved=infer(entries)
        return stop(approved,True) if approved is not None else stop(last_action)


def core_governor(kernel,context,bundle,gap,policy='GOVERNOR_LOCAL',budget=None,decide=None):
    return kernel.governor(context,bundle,gap,policy,budget,decide)
