"""Fixed STEP30 geometry-conditioned, locally calibrated action margins.

Two quadratic six-output regressions are fitted on DEV only.  Local empirical
reserves use four distinct complete source snapshots over two whole episodes;
physical and terminal failures are not filtered from calibration.  Neither the
predictor nor lookup consumes an ACTUAL trajectory, an episode name, or a gap.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np

from cavr_wbc.control import step29_margin as previous


VERSION = "STEP30_INJURED_ACTION_MARGIN_V1"
MAIN = "GEOMETRY_FULL_26"
NO_GEOMETRY = "NO_GEOMETRY_23"
BINARY = "BINARY_LOCAL"
GLOBAL = "GLOBAL_CAL_SAME_MODEL"
CONFIGURATIONS = (MAIN, NO_GEOMETRY)
GAMMA_GRID = previous.GAMMA_GRID
ROLES = previous.ROLES
FEATURE_NAMES = (*previous.FEATURE_NAMES, "direction_side_leg_front_plus_rear_minus",
                 "configuration_reference_joint_q_rad", "configuration_sent_torque_headroom")
PHYSICAL_FLOORS = np.r_[previous.PHYSICAL_FLOORS, 1., .1, .1]
TERMINAL_NAMES = previous.TERMINAL_NAMES
GAPS_M = previous.GAPS_M
D_SCALE_M = previous.D_SCALE_M
D_RESERVE_M = previous.D_RESERVE_M
TERMINAL_RESERVE = previous.TERMINAL_RESERVE
DISTANCE_FLOOR = previous.DISTANCE_FLOOR
POSE_PAD_RAD = previous.POSE_PAD_RAD
K = previous.K
MIN_CAL_SNAPSHOTS = 4
GLOBAL_MIN_CAL_SNAPSHOTS = previous.MIN_CAL_SNAPSHOTS
MIN_CAL_EPISODES = 2
ALPHA = 1.

prefix_available = previous.prefix_available
prefix_physical_pass = previous.prefix_physical_pass
prefix_displacement = previous.prefix_displacement
labels = previous.labels
safe = previous.safe
gamma_key = previous.gamma_key
_vector = previous._vector
_role = previous._role
_identity = previous._identity
_physical = previous._physical
_target = previous._target
_complete_target = previous._complete_target
_powers = previous._powers
_design = previous._design
_project = previous._project
_ridge = previous._ridge


def group_key(configuration, gamma, role):
    if configuration not in CONFIGURATIONS or role not in ROLES:
        raise ValueError("fixed STEP30 configuration and explicit fault role required")
    return gamma_key(gamma) + ":" + role


def append_geometry_features(features23, leg_sign, joint_q_rad, headroom):
    """Units and conventions are checked, not imputed, before deployment."""
    feature = _vector(features23, 23, "STEP29 command-conditional features")
    extra = _vector([leg_sign, joint_q_rad, headroom], 3, "compiled geometry features")
    if extra[0] not in (-1., 1.):
        raise ValueError("direction-side leg sign must be +1 front or -1 rear")
    return np.r_[feature, extra]


def _input_features(entry):
    feature = _vector(entry.get("features26", entry.get("features")), 26, "STEP30 features")
    gamma_key(entry["gamma"])
    if feature[22] != float(entry["gamma"]):
        raise ValueError("gamma feature differs from declared action")
    if feature[23] not in (-1., 1.):
        raise ValueError("compiled front/rear feature must be +1/-1")
    _role(entry)
    return feature


def _finite_input(record):
    try:
        return _input_features(record)
    except (KeyError, TypeError, ValueError, IndexError):
        return None


def feature_specification():
    return {
        "schema": VERSION, "count": 26, "names": list(FEATURE_NAMES),
        "physical_floor": PHYSICAL_FLOORS.tolist(), "gamma_index": 22,
        "geometry_indices": [23, 24, 25], "NO_GEOMETRY_23_indices": list(range(23)),
        "scale": "max(TRAIN population std, physical floor); TRAIN-only mean",
        "geometry": {"leg_sign": "direction-side front +1 / rear -1 from compiled mapping",
                     "q_rad": "current compiled fault joint qpos address; healthy direction-side calf reference",
                     "headroom": "1-abs(tau_sent)/(health*healthy_limit); healthy uses all-channel minimum"},
        "command_and_prefix": previous.feature_specification(),
        "online_PID_prior": False,
        "forbidden_inputs": ["episode", "tick", "split", "future label", "gap"],
        "missing": "reject action; never zero-impute missing current/prefix/geometry",
    }


def _cal_group(bundle, train, cal, group_id):
    configuration = bundle["configuration_id"]
    group_train = [r for r in train if group_key(configuration, r["gamma"], _role(r)) == group_id]
    group_cal = [r for r in cal if group_key(configuration, r["gamma"], _role(r)) == group_id]
    size = len(bundle["feature_indices"])
    train_z = np.asarray([(_input_features(r)[bundle["feature_indices"]] - bundle["mean"]) / bundle["scale"]
                          for r in group_train], dtype=float).reshape(-1, size)
    all_cal_z = np.asarray([(_input_features(r)[bundle["feature_indices"]] - bundle["mean"]) / bundle["scale"]
                            for r in group_cal], dtype=float).reshape(-1, size)
    nearest = (np.sqrt(np.min(np.sum((all_cal_z[:, None, :] - train_z[None, :, :]) ** 2, axis=2), axis=1))
               if len(all_cal_z) and len(train_z) else np.empty(0))
    cal_max = float(np.max(nearest)) if len(nearest) else 0.
    complete = []
    estimates = []
    complete_z = []
    for index, record in enumerate(group_cal):
        target = _complete_target(record)
        try:
            prefix_d = prefix_displacement(record["prefix"])
            available = prefix_available(record["prefix"])
        except (KeyError, ValueError, TypeError, IndexError, AttributeError):
            continue
        if target is None or not available or not np.isfinite(prefix_d):
            continue
        complete.append(record)
        complete_z.append(all_cal_z[index])
        if bundle["trained"]:
            raw = _design(all_cal_z[index], bundle["powers"]) @ bundle["coefficient"].T + bundle["intercept"]
            estimates.append(_project(raw, prefix_d))
    snapshots = sorted({_identity(r, "source_snapshot") for r in complete})
    episodes = sorted({_identity(r, "episode") for r in complete})
    trained = bool(bundle["trained"])
    local_eligible = bool(trained and len(snapshots) >= MIN_CAL_SNAPSHOTS and len(episodes) >= MIN_CAL_EPISODES)
    global_eligible = bool(trained and len(snapshots) >= GLOBAL_MIN_CAL_SNAPSHOTS and len(episodes) >= MIN_CAL_EPISODES)
    residual = np.empty((0, 6))
    global_margin = np.zeros(6)
    if estimates:
        observed = np.asarray([_target(r["labels"]) for r in complete])
        estimates_array = np.asarray(estimates)
        residual = np.c_[observed[:, 0] - estimates_array[:, 0], np.abs(observed[:, 1:] - estimates_array[:, 1:])]
        global_margin[0] = max(0., float(np.max(residual[:, 0])))
        global_margin[1:] = np.max(residual[:, 1:], axis=0)
    complete_z = np.asarray(complete_z, dtype=float).reshape(-1, size)
    snapshot_map = {identity: index for index, identity in enumerate(snapshots)}
    episode_map = {identity: index for index, identity in enumerate(episodes)}
    return {
        "train_z": train_z, "train_norm2": np.sum(train_z * train_z, axis=1),
        "train_ids": np.asarray([r["id"] for r in group_train], dtype=str),
        "train_complete": np.asarray([_complete_target(r) is not None for r in group_train], dtype=bool),
        "train_physical": np.asarray([_physical(r.get("labels", {})) for r in group_train], dtype=bool),
        "cal_z": complete_z, "cal_norm2": np.sum(complete_z * complete_z, axis=1),
        "cal_ids": np.asarray([r["id"] for r in complete], dtype=str),
        "cal_snapshot_ids": np.asarray([_identity(r, "source_snapshot") for r in complete], dtype=str),
        "cal_episode_ids": np.asarray([_identity(r, "episode") for r in complete], dtype=str),
        "cal_snapshot_index": np.asarray([snapshot_map[_identity(r, "source_snapshot")] for r in complete], dtype=np.int64),
        "cal_episode_index": np.asarray([episode_map[_identity(r, "episode")] for r in complete], dtype=np.int64),
        "cal_complete_physical": np.asarray([_physical(r.get("labels", {})) for r in complete], dtype=bool),
        "cal_complete_terminal": np.asarray([bool(r.get("labels", {}).get("terminal_pass", r.get("labels", {}).get("original_terminal", False)))
                                               for r in complete], dtype=bool),
        "cal_residual": residual, "cal_margin": global_margin,
        "calibrated": local_eligible, "local_calibrated": local_eligible, "global_calibrated": global_eligible,
        "cal_max_nearest_distance": cal_max, "distance_threshold": max(3. * cal_max, DISTANCE_FLOOR),
        "train_finite_ids": [r["id"] for r in group_train], "train_finite_count": len(group_train),
        "cal_finite_ids": [r["id"] for r in group_cal], "cal_finite_count": len(group_cal),
        "cal_complete_ids": [r["id"] for r in complete], "cal_complete_count": len(complete),
        "cal_distinct_source_snapshots": len(snapshots), "cal_episode_count": len(episodes),
        "cal_source_snapshots": snapshots, "cal_episodes": episodes,
        "cal_failed_physical_count": sum(not _physical(r.get("labels", {})) for r in complete),
        "cal_failed_terminal_count": sum(not bool(r.get("labels", {}).get("terminal_pass", r.get("labels", {}).get("original_terminal", False))) for r in complete),
    }


def local_cal_indices(group, distances):
    """Numeric, stable four-snapshot lookup with fixed two-episode replacement.

    Equal distances keep frozen CAL record order.  Every complete record may be
    selected, including physical/terminal failures.  No label influences rank.
    """
    distances = np.asarray(distances, dtype=float)
    if distances.shape != (len(group["cal_ids"]),) or not np.isfinite(distances).all():
        raise ValueError("finite distance for every complete CAL record required")
    ordered = np.argsort(distances, kind="stable")
    selected = []
    seen = set()
    for index in ordered:
        snapshot = int(group["cal_snapshot_index"][index])
        if snapshot not in seen:
            selected.append(int(index)); seen.add(snapshot)
        if len(selected) == MIN_CAL_SNAPSHOTS:
            break
    if len(selected) != MIN_CAL_SNAPSHOTS:
        return np.empty(0, dtype=np.int64)
    episode = group["cal_episode_index"]
    if len({int(episode[index]) for index in selected}) < MIN_CAL_EPISODES:
        first_episode = int(episode[selected[0]])
        retained_snapshots = {int(group["cal_snapshot_index"][index]) for index in selected[:-1]}
        replacement = next((int(index) for index in ordered
                            if int(episode[index]) != first_episode
                            and int(group["cal_snapshot_index"][index]) not in retained_snapshots), None)
        if replacement is None:
            return np.empty(0, dtype=np.int64)
        selected[-1] = replacement
    return np.asarray(selected, dtype=np.int64)


def _calibration_mode(calibration):
    if calibration not in ("LOCAL", "GLOBAL"):
        raise ValueError("calibration must be LOCAL or GLOBAL")
    return calibration


def static_group_eligible(bundle, gamma, role, calibration="LOCAL"):
    """Freeze-time qualification only; it does not imply an input is safe."""
    mode = _calibration_mode(calibration)
    group = bundle["groups"][group_key(bundle["configuration_id"], gamma, role)]
    return bool(bundle["trained"] and group["local_calibrated" if mode == "LOCAL" else "global_calibrated"])


def calibrated_gamma_mask(bundle, role, calibration="LOCAL"):
    return np.asarray([static_group_eligible(bundle, gamma, role, calibration) for gamma in GAMMA_GRID], dtype=bool)


def calibrated_gammas(bundle, role, allowed=GAMMA_GRID, calibration="LOCAL"):
    allowed_values = {float(gamma) for gamma in allowed}
    for gamma in allowed_values: gamma_key(gamma)
    return tuple(gamma for gamma, eligible in zip(GAMMA_GRID, calibrated_gamma_mask(bundle, role, calibration))
                 if gamma in allowed_values and eligible)


_NUMERIC_LAYOUT = {
    "D_hat": (float, ()), "Y_hat": (float, (5,)), "U_D": (float, ()), "U_T": (float, (5,)),
    "finite_input": (bool, ()), "pose_gate": (bool, ()), "support_gate": (bool, ()),
    "distance_gate": (bool, ()), "calibration_gate": (bool, ()), "nearest_distance": (float, ()),
    "distance_threshold": (float, ()), "group_index": (np.int64, ()),
    "neighbor_indices": (np.int64, (K,)), "neighbor_distances": (float, (K,)),
    "local_cal_indices": (np.int64, (MIN_CAL_SNAPSHOTS,)), "local_cal_distances": (float, (MIN_CAL_SNAPSHOTS,)),
}


def _allocate_numeric(count):
    return {name: np.full((count, *trailing), False if dtype is bool else np.nan if dtype is float else -1, dtype=dtype)
            for name, (dtype, trailing) in _NUMERIC_LAYOUT.items()}


def _prepare_resident(bundle):
    """Build immutable lookup tables before an online timing interval."""
    powers = bundle["powers"]
    group_keys = tuple(bundle["groups"])
    bundle["_resident"] = {
        "group_keys": group_keys, "group_arrays": tuple(bundle["groups"][key] for key in group_keys),
        "group_position": {key: index for index, key in enumerate(group_keys)},
        "first": np.argmax(powers, axis=1),
        "second": powers.shape[1] - 1 - np.argmax(powers[:, ::-1], axis=1),
        "linear": powers.sum(axis=1) == 1,
    }
    return bundle


def allocate_numeric(count=5):
    """Allocate before command-ready timing; reusable out rows are reset each call."""
    return _allocate_numeric(int(count))


def batch_numeric(bundle, features26, gammas, roles, prefix_d, calibration="LOCAL", out=None):
    """Batched regression, support and local lookup without string diagnostics.

    Returned indices refer to frozen resident group arrays.  Prefix and current
    feasibility gates remain the caller's responsibility.  No future labels or
    gap are accepted by this function.
    """
    mode = _calibration_mode(calibration)
    feature = np.asarray(features26, dtype=float)
    if feature.ndim != 2 or feature.shape[1] != 26:
        raise ValueError("features26 batch must have shape (N,26)")
    count = len(feature)
    gamma_values = np.asarray(gammas, dtype=float)
    roles = tuple(str(role) for role in roles)
    prefix_values = np.asarray(prefix_d, dtype=float)
    if gamma_values.shape != (count,) or prefix_values.shape != (count,) or len(roles) != count:
        raise ValueError("batch action metadata shapes must agree")
    result = _allocate_numeric(count) if out is None else out
    for name, array in result.items():
        if name not in _NUMERIC_LAYOUT or array.shape != (count, *_NUMERIC_LAYOUT[name][1]):
            raise ValueError("preallocated numeric output shape mismatch")
        if array.dtype.kind == "b": array.fill(False)
        elif array.dtype.kind in "iu": array.fill(-1)
        else: array.fill(np.nan)
    if set(result) != set(_NUMERIC_LAYOUT):
        raise ValueError("preallocated numeric output keys mismatch")
    valid = np.isfinite(feature).all(axis=1) & np.isfinite(prefix_values) & (prefix_values >= 0.)
    valid &= (feature[:, 22] == gamma_values) & np.isin(feature[:, 23], (-1., 1.))
    valid &= np.isin(gamma_values, GAMMA_GRID) & np.asarray([role in ROLES for role in roles])
    result["finite_input"][:] = valid
    indices = np.flatnonzero(valid)
    if not len(indices): return result
    z = (feature[indices][:, bundle["feature_indices"]] - bundle["mean"]) / bundle["scale"]
    pose = feature[indices][:, [2, 3]]
    result["pose_gate"][indices] = (np.all(pose >= bundle["pose_min"] - POSE_PAD_RAD, axis=1)
                                     & np.all(pose <= bundle["pose_max"] + POSE_PAD_RAD, axis=1))
    resident = bundle.get("_resident")
    if resident is None:
        resident = _prepare_resident(bundle)["_resident"]
    if bundle["trained"]:
        design = z[:, resident["first"]] * np.where(resident["linear"][None, :], 1., z[:, resident["second"]])
        estimates = design @ bundle["coefficient"].T + bundle["intercept"]
        estimates[:, 0] = np.maximum.reduce([np.zeros(len(indices)), prefix_values[indices], estimates[:, 0] * D_SCALE_M])
        result["D_hat"][indices] = estimates[:, 0]
        result["Y_hat"][indices] = estimates[:, 1:]
    for local_index, row in enumerate(indices):
        group_id = group_key(bundle["configuration_id"], gamma_values[row], roles[row])
        group = bundle["groups"][group_id]
        result["group_index"][row] = resident["group_position"][group_id]
        result["distance_threshold"][row] = group["distance_threshold"]
        point_z = z[local_index]
        distances = np.sqrt(np.sum((group["train_z"] - point_z) ** 2, axis=1))
        neighbors = np.argsort(distances, kind="stable")[:K]
        result["neighbor_indices"][row, :len(neighbors)] = neighbors
        result["neighbor_distances"][row, :len(neighbors)] = distances[neighbors]
        if len(neighbors): result["nearest_distance"][row] = distances[neighbors[0]]
        result["support_gate"][row] = bool(len(neighbors) == K and np.all(group["train_complete"][neighbors])
                                           and np.all(group["train_physical"][neighbors]))
        result["distance_gate"][row] = bool(len(neighbors) and distances[neighbors[0]] <= group["distance_threshold"])
        eligible = bool(bundle["trained"] and group["local_calibrated" if mode == "LOCAL" else "global_calibrated"])
        if not eligible: continue
        margin = group["cal_margin"]
        if mode == "LOCAL":
            cal_distances = np.sqrt(np.sum((group["cal_z"] - point_z) ** 2, axis=1))
            local = local_cal_indices(group, cal_distances)
            if len(local) != MIN_CAL_SNAPSHOTS: continue
            result["local_cal_indices"][row] = local
            result["local_cal_distances"][row] = cal_distances[local]
            margin = np.max(group["cal_residual"][local], axis=0)
            margin[0] = max(0., float(margin[0]))
        result["calibration_gate"][row] = True
        result["U_D"][row] = result["D_hat"][row] + margin[0] + D_RESERVE_M
        result["U_T"][row] = np.abs(result["Y_hat"][row]) + margin[1:] + TERMINAL_RESERVE
    return result


def _empty_prediction(gamma):
    point = previous._empty_prediction(gamma)
    point.update(local_cal_ids=[], local_cal_distances=[], local_cal_source_snapshots=[], local_cal_episodes=[],
                 local_cal_original_physical=[], local_cal_terminal_pass=[], calibration="LOCAL")
    return point


def _action_entries(actions_inputs):
    return previous._action_entries(actions_inputs)


def predict(bundle, actions_inputs, calibration="LOCAL"):
    """Diagnostic wrapper around the same resident numeric batch path."""
    mode = _calibration_mode(calibration)
    entries = _action_entries(actions_inputs)
    points = {key: _empty_prediction(float(key)) for key in entries}
    valid_keys = []
    features = []
    prefix_d = []
    for key, entry in entries.items():
        point = points[key]
        point["calibration"] = mode
        try:
            feature = _input_features(entry)
            role = _role(entry)
            prefix = entry.get("prefix")
            available = prefix_available(prefix)
            physical = prefix_physical_pass(prefix)
            displacement = prefix_displacement(prefix)
            group_id = group_key(bundle["configuration_id"], entry["gamma"], role)
            group = bundle["groups"][group_id]
            point.update(group=group_id, fault_role=role, current_command_gate=bool(entry.get("first_command_valid", False)),
                         prefix_available_gate=available, prefix_physical_gate=physical, D_prefix_m=float(displacement),
                         cal_complete_count=group["cal_complete_count"], cal_distinct_source_snapshots=group["cal_distinct_source_snapshots"],
                         cal_episode_count=group["cal_episode_count"], pose_value_rad=feature[[2, 3]].tolist(),
                         pose_interval_rad={"names": ["roll_rad", "direction_pitch_rad"], "min": bundle["pose_min"].tolist(), "max": bundle["pose_max"].tolist()})
            valid_keys.append(key); features.append(feature); prefix_d.append(displacement)
        except (KeyError, ValueError, TypeError, IndexError, AttributeError) as exc:
            point["input_error"] = str(exc)
            point["reasons"].append("MISSING_OR_NONFINITE_CURRENT_PREFIX_INPUT")
    if valid_keys:
        numeric = batch_numeric(bundle, np.asarray(features), [entries[key]["gamma"] for key in valid_keys],
                                [_role(entries[key]) for key in valid_keys], prefix_d, mode)
        for row, key in enumerate(valid_keys):
            point = points[key]
            group = bundle["groups"][point["group"]]
            for name in ("pose_gate", "support_gate", "distance_gate", "calibration_gate"):
                point[name] = bool(numeric[name][row])
            for name in ("D_hat", "U_D", "nearest_distance", "distance_threshold"):
                value = numeric[name][row]; point[name] = float(value) if np.isfinite(value) else None
            for name in ("Y_hat", "U_T"):
                value = numeric[name][row]; point[name] = value.tolist() if np.isfinite(value).all() else None
            neighbors = numeric["neighbor_indices"][row]
            neighbors = neighbors[neighbors >= 0]
            point.update(neighbor_ids=group["train_ids"][neighbors].tolist(),
                         neighbor_distances=numeric["neighbor_distances"][row, :len(neighbors)].tolist(),
                         neighbor_complete=group["train_complete"][neighbors].tolist(),
                         neighbor_original_physical=group["train_physical"][neighbors].tolist(),
                         neighbor_numeric_indices=neighbors.tolist())
            local = numeric["local_cal_indices"][row]
            local = local[local >= 0]
            point.update(local_cal_ids=group["cal_ids"][local].tolist(),
                         local_cal_distances=numeric["local_cal_distances"][row, :len(local)].tolist(),
                         local_cal_source_snapshots=group["cal_snapshot_ids"][local].tolist(),
                         local_cal_episodes=group["cal_episode_ids"][local].tolist(),
                         local_cal_original_physical=group["cal_complete_physical"][local].tolist(),
                         local_cal_terminal_pass=group["cal_complete_terminal"][local].tolist(),
                         local_cal_numeric_indices=local.tolist())
    for key, point in points.items():
        reasons = point["reasons"]
        if not point["pose_gate"]: reasons.append("OUTSIDE_FROZEN_POSE_DOMAIN")
        if len(point["neighbor_ids"]) != K: reasons.append("INSUFFICIENT_TRAIN_NEIGHBORS")
        if point["neighbor_complete"] and not all(point["neighbor_complete"]): reasons.append("NEIGHBOR_NUMERICAL_INCOMPLETE")
        if point["neighbor_original_physical"] and not all(point["neighbor_original_physical"]): reasons.append("NEIGHBOR_ORIGINAL_PHYSICAL_FAILURE")
        if not point["distance_gate"]: reasons.append("OUTSIDE_CAL_NEAREST_TRAIN_DISTANCE")
        if not bundle["trained"]: reasons.append("NO_COMPLETE_TRAIN_LABELS")
        if not point["calibration_gate"]: reasons.append("INSUFFICIENT_DISTINCT_COMPLETE_CAL")
        if not point["current_command_gate"]: reasons.append("FIRST_COMMAND_UNAVAILABLE")
        if not point["prefix_available_gate"]: reasons.append("PREFIX_UNAVAILABLE")
        if not point["prefix_physical_gate"]: reasons.append("PREFIX_ORIGINAL_PHYSICAL_FAILURE_OR_MISSING")
    return points


def decide(bundle, actions_inputs, gap, allowed=GAMMA_GRID, calibration="LOCAL"):
    if not np.isfinite(gap) or gap < 0.:
        raise ValueError("finite nonnegative gap metres required")
    mode = _calibration_mode(calibration)
    ordered = tuple(sorted({float(gamma) for gamma in allowed}, reverse=True))
    for gamma in ordered: gamma_key(gamma)
    predictions = predict(bundle, actions_inputs, mode)
    gates = ("support_gate", "distance_gate", "calibration_gate", "pose_gate", "current_command_gate",
             "prefix_available_gate", "prefix_physical_gate", "terminal_gate", "local_gate")
    for key, point in predictions.items():
        point["terminal_gate"] = bool(point["U_T"] is not None and np.isfinite(point["U_T"]).all() and np.all(np.asarray(point["U_T"]) <= 1.))
        point["local_gate"] = bool(point["U_D"] is not None and np.isfinite(point["U_D"]) and point["U_D"] <= gap)
        if not point["terminal_gate"]: point["reasons"].append("TERMINAL_RATIO_REJECT")
        if not point["local_gate"]: point["reasons"].append("LOCAL_DISPLACEMENT_MARGIN_REJECT")
        point["accepted"] = bool(float(key) in ordered and all(point[gate] for gate in gates))
    for gamma in ordered:
        key = gamma_key(gamma)
        if key not in predictions:
            predictions[key] = _empty_prediction(gamma)
            predictions[key]["reasons"].append("ACTION_INPUT_NOT_SUPPLIED")
    choice = next((gamma for gamma in ordered if predictions[gamma_key(gamma)]["accepted"]), "ABSTAIN")
    return {"choice": choice, "gamma": None if choice == "ABSTAIN" else choice, "accepted": choice != "ABSTAIN",
            "gap_m": float(gap), "allowed": list(ordered), "predictions": predictions,
            "configuration_id": bundle["configuration_id"], "calibration": mode,
            "comparison_id": BINARY if ordered == (1., 0.) and mode == "LOCAL" else GLOBAL if mode == "GLOBAL" else bundle["configuration_id"],
            "reject_reasons": [] if choice != "ABSTAIN" else list(dict.fromkeys(reason for gamma in ordered for reason in predictions[gamma_key(gamma)]["reasons"]))}


_BUNDLE_ARRAYS = ("feature_indices", "powers", "mean", "scale", "train_std", "physical_floor", "coefficient", "intercept", "pose_min", "pose_max")
_GROUP_ARRAYS = ("train_z", "train_norm2", "train_ids", "train_complete", "train_physical", "cal_z", "cal_norm2", "cal_ids",
                 "cal_snapshot_ids", "cal_episode_ids", "cal_snapshot_index", "cal_episode_index", "cal_complete_physical",
                 "cal_complete_terminal", "cal_residual", "cal_margin")


def _save_bundle(bundle, directory):
    directory = Path(directory); directory.mkdir(parents=True, exist_ok=True)
    path = directory / ("step30_" + bundle["configuration_id"].lower() + ".npz")
    if path.exists() or path.with_suffix(".json").exists():
        raise FileExistsError("frozen STEP30 assets cannot be overwritten")
    arrays = {key: bundle[key] for key in _BUNDLE_ARRAYS}
    metadata = {key: value for key, value in bundle.items() if key not in _BUNDLE_ARRAYS and key != "groups" and not key.startswith("_")}
    metadata["groups"] = {}
    for index, (group_id, group) in enumerate(bundle["groups"].items()):
        prefix = "group" + str(index) + "_"
        arrays.update({prefix + key: group[key] for key in _GROUP_ARRAYS})
        metadata["groups"][group_id] = {key: value for key, value in group.items() if key not in _GROUP_ARRAYS}
        metadata["groups"][group_id]["array_prefix"] = prefix
    metadata.update(alpha=ALPHA, quadratic_bias=False, D_target_scale_m=D_SCALE_M, D_reserve_m=D_RESERVE_M,
                    terminal_reserve=TERMINAL_RESERVE, terminal_names=list(TERMINAL_NAMES), feature_specification=feature_specification())
    with path.open("xb") as stream: np.savez_compressed(stream, **arrays)
    with path.with_suffix(".json").open("x", encoding="utf-8") as stream:
        json.dump(metadata, stream, sort_keys=True, indent=2, allow_nan=False)
    return {"npz": str(path.resolve()), "json": str(path.with_suffix(".json").resolve()),
            "npz_sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "json_sha256": hashlib.sha256(path.with_suffix(".json").read_bytes()).hexdigest()}


def load_bundle(path, configuration=MAIN):
    path = Path(path)
    if path.is_dir():
        freeze = json.loads((path / "MODEL_FREEZE.json").read_text(encoding="utf-8"))
        path = Path(freeze["assets"][configuration]["npz"])
    metadata = json.loads(path.with_suffix(".json").read_text(encoding="utf-8"))
    if metadata["schema"] != VERSION or metadata["configuration_id"] not in CONFIGURATIONS:
        raise ValueError("unsupported STEP30 model schema/configuration")
    with np.load(path, allow_pickle=False) as archive:
        result = dict(metadata); result.update({key: archive[key].copy() for key in _BUNDLE_ARRAYS})
        result["groups"] = {}
        for group_id, group_metadata in metadata["groups"].items():
            group = dict(group_metadata); prefix = group.pop("array_prefix")
            group.update({key: archive[prefix + key].copy() for key in _GROUP_ARRAYS})
            result["groups"][group_id] = group
    return _prepare_resident(result)


def fit_fixed(records, outdir):
    """Two predeclared six-output fits; no new TEST or post-freeze refit."""
    records = list(records)
    if any(record.get("split") not in ("TRAIN", "CAL") for record in records):
        raise ValueError("STEP30 fitting refuses new TEST or unrecognized split")
    if len({record["id"] for record in records}) != len(records): raise ValueError("duplicate STEP30 DEV action ID")
    snapshot_splits = {}; episode_splits = {}
    for record in records:
        gamma_key(record["gamma"]); _role(record)
        for key, registry in (("source_snapshot", snapshot_splits), ("episode", episode_splits)):
            identity = _identity(record, key)
            if identity in registry and registry[identity] != record["split"]:
                raise ValueError("TRAIN/CAL leak across whole " + key)
            registry[identity] = record["split"]
    outdir = Path(outdir)
    if (outdir / "MODEL_FREEZE.json").exists() or any((outdir / ("step30_" + configuration.lower() + suffix)).exists()
                                                      for configuration in CONFIGURATIONS for suffix in (".npz", ".json")):
        raise FileExistsError("frozen STEP30 assets cannot be overwritten or refitted")
    train_all = [record for record in records if record["split"] == "TRAIN"]
    cal_all = [record for record in records if record["split"] == "CAL"]
    train = [record for record in train_all if _finite_input(record) is not None]
    cal = [record for record in cal_all if _finite_input(record) is not None]
    if not train: raise ValueError("no finite STEP30 TRAIN features")
    x26 = np.asarray([_input_features(record) for record in train])
    pose_inputs = np.asarray([_input_features(record)[[2, 3]] for record in train + cal])
    regression_indices = [index for index, record in enumerate(train) if _complete_target(record) is not None]
    bundles = {}; assets = {}; fit_calls = []
    for configuration in CONFIGURATIONS:
        feature_indices = np.arange(26 if configuration == MAIN else 23, dtype=np.int64)
        x = x26[:, feature_indices]; mean = x.mean(axis=0); std = x.std(axis=0, ddof=0)
        floors = PHYSICAL_FLOORS[feature_indices]; scale = np.maximum(std, floors); powers = _powers(len(feature_indices))
        trained = bool(regression_indices)
        if trained:
            target = np.asarray([_target(train[index]["labels"]) for index in regression_indices]); target[:, 0] /= D_SCALE_M
            design = _design((x - mean) / scale, powers)
            coefficient, intercept = _ridge(design[regression_indices], target)
            fit_calls.append({"configuration_id": configuration, "outputs": 6, "multioutput_estimator_fit": 1,
                              "training_count": len(regression_indices), "alpha": ALPHA, "family": "quadratic"})
        else:
            coefficient = np.full((6, len(powers)), np.nan); intercept = np.full(6, np.nan)
        bundle = {"schema": VERSION, "configuration_id": configuration, "family": "quadratic", "k": K,
                  "trained": trained, "feature_indices": feature_indices, "powers": powers, "mean": mean,
                  "train_std": std, "physical_floor": floors.copy(), "scale": scale, "coefficient": coefficient, "intercept": intercept,
                  "pose_min": pose_inputs.min(axis=0), "pose_max": pose_inputs.max(axis=0),
                  "pose_source_ids": [record["id"] for record in train + cal], "pose_pad_rad": POSE_PAD_RAD,
                  "train_ids_all": [record["id"] for record in train_all], "cal_ids_all": [record["id"] for record in cal_all],
                  "train_regression_ids": [train[index]["id"] for index in regression_indices], "groups": {},
                  "actual_commands_capacity_conditioned": True, "group_rule": "gamma x fault_role for both fixed configurations"}
        group_ids = [group_key(configuration, gamma, role) for gamma in GAMMA_GRID for role in ROLES]
        bundle["groups"] = {key: _cal_group(bundle, train, cal, key) for key in group_ids}
        bundles[configuration] = bundle; assets[configuration] = _save_bundle(bundle, outdir)
        _prepare_resident(bundle)
    summary = {"TRAIN_planned": len(train_all), "CAL_planned": len(cal_all), "TRAIN_finite": len(train), "CAL_finite": len(cal),
               "TRAIN_complete_regression": len(regression_indices), "TRAIN_missing_input": len(train_all) - len(train),
               "CAL_missing_input": len(cal_all) - len(cal), "all_source_role": "DEV", "new_TEST_consumed": False}
    freeze = {"schema": VERSION, "model_frozen": True, "fixed_model_configurations": 2,
              "actual_multioutput_estimator_fit_calls": len(fit_calls), "actual_branch_multioutput_estimator_fit_calls": len(fit_calls),
              "scalar_output_regression_equivalents": 6 * len(fit_calls), "fit_call_ledger": fit_calls,
              "selected_configuration_id": MAIN, "selected_main_configuration_id": MAIN, "nogeometry_configuration_id": NO_GEOMETRY,
              "selection_status": "PREDECLARED_MAIN", "selection_order": [], "new_TEST_model_selection": False,
              "binary_local": {"configuration_id": MAIN, "calibration": "LOCAL", "allowed_gamma": [1., 0.], "additional_fit_calls": 0},
              "global_cal_same_model": {"configuration_id": MAIN, "calibration": "GLOBAL", "additional_fit_calls": 0,
                                        "minimum_distinct_snapshots": GLOBAL_MIN_CAL_SNAPSHOTS, "minimum_episodes": MIN_CAL_EPISODES},
              "local_cal_rule": {"snapshots": MIN_CAL_SNAPSHOTS, "minimum_episodes": MIN_CAL_EPISODES,
                                 "ranking": "stable ascending current standardized feature distance; distinct source snapshot",
                                 "replacement": "if nearest four share one episode, replace farthest with nearest other-episode distinct snapshot",
                                 "failures_excluded": False, "probability_coverage_claim": False},
              "gamma_grid": list(GAMMA_GRID), "assets": assets, "split_summary": summary, "feature_specification": feature_specification(),
              "pose_applicability": {"min": bundles[MAIN]["pose_min"].tolist(), "max": bundles[MAIN]["pose_max"].tolist(),
                                     "pad_rad": POSE_PAD_RAD, "original_physical_bounds_changed": False},
              "groups": {configuration: {key: {field: group[field] for field in
                         ("calibrated", "local_calibrated", "global_calibrated", "train_finite_count", "cal_finite_count", "cal_complete_count",
                          "cal_distinct_source_snapshots", "cal_episode_count", "cal_failed_physical_count", "cal_failed_terminal_count",
                          "cal_max_nearest_distance", "distance_threshold")}
                         for key, group in bundle["groups"].items()} for configuration, bundle in bundles.items()},
              "split_registry": [{"id": record["id"], "split": record["split"], "gamma": float(record["gamma"]), "role": _role(record),
                                  "source_snapshot": _identity(record, "source_snapshot"), "episode": _identity(record, "episode"),
                                  "finite_input": _finite_input(record) is not None} for record in records]}
    outdir.mkdir(parents=True, exist_ok=True); freeze_path = outdir / "MODEL_FREEZE.json"
    with freeze_path.open("x", encoding="utf-8") as stream: json.dump(freeze, stream, sort_keys=True, indent=2, allow_nan=False)
    return dict(freeze, selected_main=bundles[MAIN], selected=bundles[MAIN], selected_bundle=bundles[MAIN],
                nogeometry=bundles[NO_GEOMETRY], selected_nogeometry=bundles[NO_GEOMETRY],
                bundles=bundles, freeze_path=str(freeze_path.resolve()))
