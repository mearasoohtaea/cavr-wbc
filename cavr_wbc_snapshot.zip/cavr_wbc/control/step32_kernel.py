"""Application-clock STEP32 governor using the frozen STEP30 arithmetic.

Every state-dependent operation needed for a TEST decision is inside a single
sample-clock deadline.  Prehold is a known previous command, not an optimizer
return.  The bounds-only shadow owns different solvers and never actuates.
"""
from __future__ import annotations

import ctypes
from copy import deepcopy
from time import perf_counter

import mujoco
import numpy as np

from cavr_wbc.control.step30_kernel import Kernel as FrozenKernel
from cavr_wbc.control.step29_kernel import DeadlineWBC, DEADLINE_S, FINAL_RESERVE_S, MIN_SOLVER_S, MAX_SOLVER_S
from cavr_wbc.control.step27_resident_kernel import _copy_integration, reset_workspace_warmstart
from cavr_wbc.control.step28_native_prefix import _Buffers, PHYSICS_STEPS, STATE_COUNT, PHYSICS_DT_S, PHYSICAL_NAMES, SCALAR_NAMES, CONTACT_NAMES
from cavr_wbc.control.step30_actions import GAMMA_GRID, prepare_shared, make_action, check_rows
from cavr_wbc.experiments.step31_sim import capture_packet_memory

VERSION = 'STEP32_APPLICATION_CLOCK_KERNEL_V1'
METHODS = ('STALE_RECAL', 'ALIGNED_RECAL')
STATE_FIELDS = ('qpos', 'qvel', 'act', 'ctrl', 'qacc_warmstart', 'qfrc_applied', 'xfrc_applied',
                'mocap_pos', 'mocap_quat', 'userdata', 'plugin_state')


def _state(model, data):
    signature = int(mujoco.mjtState.mjSTATE_INTEGRATION)
    vector = np.empty(int(mujoco.mj_stateSize(model, signature)))
    mujoco.mj_getState(model, data, vector, signature)
    return {'integration_state_signature': signature, 'integration_state': vector,
            'time': float(data.time), **{key: np.asarray(getattr(data, key)).copy() for key in STATE_FIELDS}}


def _saved(sample):
    return sample.get('state', sample.get('source_state', sample))


def construct_prehold(sample, healthy_limits):
    """Validate a saved healthy command's identity and apply the new health clip."""
    state = _saved(sample)
    identity = sample.get('previous_command_identity') or {}
    if not isinstance(identity, dict) or identity.get('available') is not True:
        raise ValueError('STEP32 known previous command identity is unavailable')
    tau = np.asarray(sample.get('previous_tau_sent', identity.get('tau_sent')), dtype=float)
    health = np.asarray(sample['health_vector'], dtype=float)
    limits = np.asarray(healthy_limits, dtype=float)
    if (tau.shape != limits.shape or health.shape != limits.shape or not np.isfinite(tau).all()
            or not np.isfinite(health).all() or np.any((health < 0.) | (health > 1.))):
        raise ValueError('STEP32 previous command or health has invalid shape/units')
    if (identity.get('episode_id') != sample.get('episode_id')
            or identity.get('source_tick') != sample.get('source_tick')
            or identity.get('previous_reference_tick', identity.get('applied_previous_reference_tick')) != int(sample['source_tick']) - 1
            or identity.get('source_solver_status_val') != 1
            or isinstance(identity.get('source_solver_status_val'), (bool, np.bool_))
            or identity.get('actual_state_ctrl_matches_healthy_fact_and_control') is False
            or not np.array_equal(np.asarray(identity.get('health_vector', identity.get('source_health_vector'))), np.ones_like(health))
            or not np.array_equal(np.asarray(state.get('ctrl')), tau)
            or not np.array_equal(np.asarray(identity.get('tau_sent')), tau)):
        raise ValueError('STEP32 previous command source/state identity mismatch')
    if identity.get('source_snapshot', identity.get('snapshot_id')) not in (sample.get('source_snapshot'), sample.get('snapshot_id')):
        raise ValueError('STEP32 previous command snapshot identity mismatch')
    sent = np.clip(tau, -health * limits, health * limits)
    return {'schema': VERSION, 'source': 'LAST_COMMAND_HEALTH_CLIPPED', 'kind': 'PREHOLD',
            'command_valid': True, 'solver_status_val': None, 'new_QP_calls': 0,
            'tau_raw': tau.copy(), 'tau_sent': sent, 'health_vector': health.copy(),
            'healthy_torque_limits_nm': limits.copy(), 'effective_capacity_nm': health * limits,
            'previous_command_identity': deepcopy(identity), 'certified_backup': False,
            'sample_start_s': 0., 'sample_end_s': .020}


def application_context(sample, prediction):
    """Copy only predicted integration state; the original anchor stays fixed."""
    context = dict(sample)
    context['state'] = prediction['state']
    context['source_state'] = prediction['state']
    context['backup_anchor_q_init'] = np.asarray(sample['backup_anchor_q_init']).copy()
    context['original_sample_state'] = _saved(sample)
    context['original_direction'] = float(sample.get('direction', 1. if _saved(sample)['qvel'][0] > 0. else -1.))
    context['application_state_source'] = 'INDEPENDENT_PREHOLD_PREDICTION'
    context['application_time_s'] = .020
    return context


class Kernel(FrozenKernel):
    def __init__(self, model, variant='BOUNDED', prefixdll=None, budget=None):
        super().__init__(model, variant=variant, prefixdll=prefixdll, budget=budget)
        self.version = VERSION
        template = self.native_prefix.buffers['C'].request
        values = {name: getattr(template, name) for name, _ in template._fields_
                  if name not in ('health', 'tau_sent', 'x0', 'direction')}
        self._application_buffer = _Buffers(model, len(self.native_prefix.limited_addresses), values)
        self._application_source = mujoco.MjData(model)
        self._shadow_controllers = {name: DeadlineWBC(model, variant='K_BUDGETED') for name in ('C', 'B')}
        self._capture_problem(self.nominal_controller)
        self._capture_problem(self.backup_controller)

    @staticmethod
    def _capture_problem(controller):
        original = controller._invoke
        original_decode = controller._decode

        def invoke(problem, stage, **kwargs):
            # This necessary copy belongs to command-ready, not a free proposal.
            saved = {name: problem[name].copy() for name in ('P', 'q', 'A', 'l', 'u')}
            result = original(problem, stage, **kwargs)
            result['step32_problem'] = saved
            key = controller._workspace_key({'P': problem['P'], 'A': problem['A']})
            cache = controller._solver_cache.get(key, {})
            result['step32_existing_dual'] = None if cache.get('last_y') is None else cache['last_y'].copy()
            return result

        def decode(answer, *args, **kwargs):
            result = original_decode(answer, *args, **kwargs)
            # The frozen decoder deliberately creates a new result dictionary;
            # retain the already-counted same-call shadow evidence in that new
            # dictionary, without assembling another problem or solving again.
            for name in ('step32_problem', 'step32_existing_dual'):
                if name in answer:
                    result[name] = answer[name]
            return result
        controller._invoke = invoke
        controller._decode = decode

    def construct_prehold(self, sample):
        return construct_prehold(sample, self.healthy_limits)

    def predict_application(self, sample, prehold, budget=None):
        """Ten counted native steps in a resident independent prediction MjData."""
        active = self.budget if budget is None else budget
        begin = perf_counter()
        _copy_integration(self.model, self._application_source, sample)
        buf = self._application_buffer
        np.copyto(buf.health, prehold['health_vector'])
        np.copyto(buf.tau_raw, prehold['tau_raw'])
        np.copyto(buf.tau_sent, prehold['tau_sent'])
        buf.request.x0 = float(np.asarray(sample['backup_anchor_q_init'])[0])
        direction = float(sample.get('direction', 1. if _saved(sample)['qvel'][0] > 0. else -1.))
        if direction not in (-1., 1.):
            raise ValueError('STEP32 original direction must be frozen +/-1')
        buf.request.direction = direction
        buf.output.actual_steps = 0
        buf.output.state_count = 0
        token = active.reserve_steps('APPLICATION_PREDICTION', sample['context_id'], 10) if active is not None else None
        try:
            rc = int(self.native_prefix._fn(self.native_prefix._model_pointer,
                ctypes.c_void_p(int(self._application_source._address)), ctypes.c_void_p(int(buf.data._address)),
                ctypes.byref(buf.request), ctypes.byref(buf.output)))
        finally:
            if active is not None:
                active.finish_steps(token, int(buf.output.actual_steps))
        count, steps = int(buf.output.state_count), int(buf.output.actual_steps)
        if rc < 0 or not 0 <= count <= 11 or not 0 <= steps <= 10:
            raise RuntimeError('STEP32 application prediction native interface error')
        complete = bool(rc == 0 and count == 11 and steps == 10 and buf.output.all_finite)
        numeric = {name: getattr(buf, name)[:count].copy() for name in
            ('qpos', 'qvel', 'qacc', 'applied', 'subtree_com', 'joint_margins', 'contacts', 'scalars', 'reason_masks', 'ncon')}
        numeric.update(physical_names=PHYSICAL_NAMES, scalar_names=SCALAR_NAMES, contact_names=CONTACT_NAMES,
                       physics_steps=np.arange(count), tau_raw=buf.tau_raw.copy(), tau_sent=buf.tau_sent.copy())
        record = {'schema': VERSION, 'kind': 'APPLICATION_PREDICTION', 'complete': complete,
            'available': complete, 'state': _state(self.model, buf.data) if complete else None,
            'numeric': numeric, 'state_count': count, 'actual_steps': steps,
            'original_physical_pass': bool(complete and buf.output.all_physical_pass),
            'D_prehold_m': float(buf.output.max_direction_displacement) if count and buf.output.all_finite else None,
            'direction': direction, 'x0_m': float(buf.request.x0), 'horizon_s': .020,
            'actual_trajectory_read': False, 'teacher_calls': 0, 'new_QP_calls': 0,
            'elapsed_ms': (perf_counter() - begin) * 1000., 'independent_prediction_data': True,
            'original_sample_state': _saved(sample), 'original_anchor_q_init': np.asarray(sample['backup_anchor_q_init']).copy()}
        prehold.update(complete=complete, original_physical_pass=record['original_physical_pass'],
                       D_prehold_m=record['D_prehold_m'], application_prediction_steps=steps)
        return record

    def _prepare_sample(self, sample, budget, method):
        if method not in METHODS:
            raise ValueError('STEP32 unknown paired method')
        prehold = self.construct_prehold(sample)
        prediction = self.predict_application(sample, prehold, budget)
        context = application_context(sample, prediction) if method == 'ALIGNED_RECAL' and prediction['complete'] else dict(sample)
        return context, prehold, prediction

    def _entry(self, context, action, prefix, prehold):
        entry = {'gamma': float(action['gamma']), 'role': context['health_kind'].split('_')[0].lower(),
                 'action': action, 'prefix': prefix, 'features26': None, 'features23': None,
                 'prehold': prehold, 'prehold_D_m': prehold.get('D_prehold_m'), 'decision': None,
                 'evaluation_status': 'COMMAND_UNAVAILABLE'}
        if prefix is not None and action.get('command_valid'):
            try:
                features = self.features(context, action, prefix)
                entry.update(features26=features, features=features, features23=features[:23],
                             evaluation_status='READY_FOR_NUMERIC_LOOKUP')
            except (KeyError, ValueError, TypeError) as exc:
                entry.update(evaluation_status='PREDICTION_INPUT_UNAVAILABLE', feature_error=str(exc))
        return entry

    def _prefix_one(self, context, action, active):
        try:
            original_direction = float(context.get('original_direction', context.get('direction', 1. if _saved(context)['qvel'][0] > 0. else -1.)))
            if original_direction * float(_saved(context)['qvel'][0]) <= 0.:
                return {'complete': False, 'original_physical_pass': False, 'D_prefix_m': None,
                        'reason': 'FROZEN_PREFIX_DIRECTION_INPUT_UNAVAILABLE', 'actual_steps': 0}
            return self.prefix_action(context, action, active)
        except (ValueError, TypeError) as exc:
            return {'complete': False, 'original_physical_pass': False, 'D_prefix_m': None,
                    'reason': 'FROZEN_PREFIX_INPUT_UNAVAILABLE', 'error': str(exc), 'actual_steps': 0}

    def _prefix_lower(self, context, actions, active):
        try:
            original_direction = float(context.get('original_direction', context.get('direction', 1. if _saved(context)['qvel'][0] > 0. else -1.)))
            if original_direction * float(_saved(context)['qvel'][0]) <= 0.:
                raise ValueError('frozen original direction differs from application velocity')
            return self.prefix_actions(context, actions, active)
        except (ValueError, TypeError) as exc:
            return {gamma: {'complete': False, 'original_physical_pass': False, 'D_prefix_m': None,
                'reason': 'FROZEN_PREFIX_INPUT_UNAVAILABLE', 'error': str(exc), 'actual_steps': 0} for gamma in actions}

    def collect_actions(self, sample, budget=None, method='ALIGNED_RECAL'):
        """DEV's single C/B set and five actions; no actual trajectory or CAL read."""
        active = self.budget if budget is None else budget
        begin = perf_counter()
        context, prehold, prediction = self._prepare_sample(sample, active, method)
        packet = {'schema': VERSION, 'context_id': sample['context_id'], 'method': method,
                  'context_used': context, 'prehold': prehold, 'application_prediction': prediction,
                  'sample_context': sample, 'actions': {}, 'selected_command_sent': False,
                  'selected_gamma': None, 'status': 'DEV_COLLECTION'}
        if not prediction['complete']:
            packet.update(C={'status': 'APPLICATION_PREDICTION_UNAVAILABLE'}, B={'status': 'APPLICATION_PREDICTION_UNAVAILABLE'},
                          command_ready_ms=(perf_counter() - begin) * 1000.)
            packet['actions'] = {str(g): self._entry(context, make_action(context, None, None, g), None, prehold)
                                 for g in GAMMA_GRID}
            return packet
        self.reset(context)
        self.set_next_call_limit(.006)
        C = self.nominal(context, active, 'DEV_' + method + '_C', sample['context_id'])
        self.set_next_call_limit(.006)
        B = self.first_backup(context, active, 'DEV_' + method + '_B', sample['context_id'])
        packet.update(C=C, B=B)
        workspace = prepare_shared(context, C, B)
        actions = {g: make_action(context, C, B, g, workspace=workspace) for g in GAMMA_GRID}
        prefixes = {}
        if actions[1.].get('command_valid'):
            prefixes[1.] = self._prefix_one(context, actions[1.], active)
        lower = {g: action for g, action in actions.items() if g < 1. and action.get('command_valid')}
        if lower:
            prefixes.update(self._prefix_lower(context, lower, active))
        for gamma, action in actions.items():
            packet['actions'][str(gamma)] = self._entry(context, action, prefixes.get(gamma), prehold)
        capture_packet_memory(self, packet)
        packet['command_ready_ms'] = (perf_counter() - begin) * 1000.
        packet['step31_backup_memory']['decision_command_ready_ms_unchanged'] = packet['command_ready_ms']
        return packet

    def governor(self, sample, bundle, gap, budget=None, method='ALIGNED_RECAL', decide=None):
        """One absolute sample-clock window, including prehold/state prediction."""
        from cavr_wbc.control.step32_margin import calibrated_gammas, batch_numeric
        active = self.budget if budget is None else budget
        begin = perf_counter()
        deadline = begin + DEADLINE_S
        role = sample['health_kind'].split('_')[0].lower()
        eligible = calibrated_gammas(bundle, role, GAMMA_GRID) if decide is None else GAMMA_GRID
        packet = {'schema': VERSION, 'context_id': sample['context_id'], 'method': method, 'sample_context': sample,
            'gap_m': float(gap), 'deadline_ms': 20., 'prepare_begin': begin, 'absolute_deadline': deadline,
            'C': {'status': 'NOT_REQUESTED'}, 'B': {'status': 'NOT_REQUESTED'}, 'actions': {},
            'selected_gamma': None, 'selected_action': None, 'selected_command_sent': False,
            'qualified_gammas': np.asarray(eligible), 'new_PID_prior_calls': 0, 'status': 'ABSTAIN'}
        C = B = last = None

        def remaining():
            return deadline - perf_counter()

        def solver_allowed():
            limit = min(MAX_SOLVER_S, remaining() - FINAL_RESERVE_S)
            if limit < MIN_SOLVER_S:
                return False
            self.set_next_call_limit(limit)
            return True

        def stop(action=None, recognized=False):
            # B0 restore memory is required by the first packet's semantics;
            # copy it before measuring ready, rather than creating free work.
            capture_packet_memory(self, packet)
            elapsed = (perf_counter() - begin) * 1000.
            valid = bool(action and action.get('command_valid'))
            any_valid = bool(valid or any(ep and ep.get('command_valid', ep.get('valid_command', False)) for ep in (C, B)))
            timely = bool(elapsed <= 20.)
            sent = bool(recognized and valid and timely)
            packet.update(elapsed_ms=elapsed, command_ready_ms=elapsed, timely_recognized_command=sent,
                command_available=any_valid, selected_command_valid=valid, selected_command_sent=sent,
                selected_gamma=float(action['gamma']) if action is not None else None, selected_action=action,
                raw_valid_but_late=bool(any_valid and not timely), overall_deadline_failure=not timely,
                status='RECOGNIZED_SENT' if sent else 'COMPUTED_VALID_BUT_LATE' if any_valid and not timely else 'ABSTAIN')
            for g in GAMMA_GRID:
                packet['actions'].setdefault(str(g), {'gamma': g, 'evaluation_status':
                    'NOT_CALIBRATED' if g not in eligible else 'NOT_REQUESTED_AFTER_SELECTION' if sent else 'NOT_EVALUATED_BUDGET'})
            if action is not None:
                action['command_ready_ms'] = elapsed
            packet['step31_backup_memory']['decision_command_ready_ms_unchanged'] = elapsed
            return packet

        def infer(entries):
            entries = [e for e in entries if e['features26'] is not None]
            if not entries:
                return None
            if decide is not None:
                approved = None
                for entry in entries:
                    entry['decision'] = decide(bundle, entry, float(gap))
                    entry['evaluation_status'] = 'EVALUATED'
                    if (prehold['complete'] and prehold['original_physical_pass'] and
                        entry['prefix'].get('complete') and entry['prefix'].get('original_physical_pass') and
                        entry['decision'].get('accepted', entry['decision'].get('recognized', False)) and approved is None):
                        approved = entry['action']
                return approved
            n = len(entries)
            for i, entry in enumerate(entries):
                self._feature_buffer[i] = entry['features26']
                self._gamma_buffer[i] = entry['gamma']
                self._prefix_d_buffer[i] = max(float(entry['prefix']['D_prefix_m']), float(prehold['D_prehold_m']))
            numeric = batch_numeric(bundle, self._feature_buffer[:n], self._gamma_buffer[:n], [role] * n,
                                    self._prefix_d_buffer[:n], out=self._numeric_outputs[n])
            approved = None
            for i, entry in enumerate(entries):
                copied = {name: values[i].copy() if isinstance(values[i], np.ndarray) else values[i].item()
                          for name, values in numeric.items()}
                prefix = entry['prefix']
                gate = bool(prehold['complete'] and prehold['original_physical_pass'] and prefix['complete'] and
                    prefix['original_physical_pass'] and entry['action']['command_valid'] and
                    all(bool(numeric[name][i]) for name in ('finite_input', 'pose_gate', 'support_gate', 'distance_gate', 'calibration_gate')) and
                    np.all(numeric['U_T'][i] <= 1.) and numeric['U_D'][i] <= gap)
                entry.update(decision={'accepted': gate, 'choice': entry['gamma'] if gate else 'ABSTAIN', 'numeric': copied},
                             evaluation_status='EVALUATED', complete_at_ms=(perf_counter() - begin) * 1000.)
                if gate and approved is None:
                    approved = entry['action']
            return approved

        if not getattr(self, 'ready', False):
            packet['not_ready'] = True
            return stop()
        context, prehold, prediction = self._prepare_sample(sample, active, method)
        packet.update(context_used=context, prehold=prehold, application_prediction=prediction,
                      QP_state_time_s=.020 if method == 'ALIGNED_RECAL' else 0., actual_first_packet_apply_time_s=.020)
        if not prediction['complete']:
            packet['reason'] = 'APPLICATION_PREDICTION_UNAVAILABLE'
            return stop()
        self.reset(context)
        if active is not None:
            active.check()
        if not solver_allowed():
            packet['C'] = {'status': 'NOT_EVALUATED_BUDGET'}
            return stop()
        C = self.nominal(context, active, 'ONLINE_' + method + '_C', sample['context_id'])
        packet['C'] = C
        last = make_action(context, C, None, 1.)
        entry = self._entry(context, last, None, prehold)
        packet['actions']['1.0'] = entry
        if 1. in eligible and last.get('command_valid') and remaining() >= FINAL_RESERVE_S:
            prefix = self._prefix_one(context, last, active)
            entry = self._entry(context, last, prefix, prehold)
            packet['actions']['1.0'] = entry
            if remaining() > 0.:
                approved = infer([entry])
                if approved is not None:
                    return stop(approved, True)
        lower = tuple(g for g in GAMMA_GRID if g < 1. and g in eligible)
        if not lower or not solver_allowed():
            packet['B'] = {'status': 'NOT_EVALUATED_BUDGET' if lower else 'NOT_CALIBRATED'}
            return stop(last)
        B = self.first_backup(context, active, 'ONLINE_' + method + '_B', sample['context_id'])
        packet['B'] = B
        workspace = prepare_shared(context, C, B)
        packet['shared_identity_checks'] = workspace.shared_identity_checks
        pending = {}
        for g in lower:
            action = make_action(context, C, B, g, workspace=workspace)
            packet['actions'][str(g)] = self._entry(context, action, None, prehold)
            last = action
            if action.get('command_valid'):
                pending[g] = action
        if remaining() < FINAL_RESERVE_S:
            return stop(last)
        prefixes = self._prefix_lower(context, pending, active)
        packet['batch_prefix'] = self.native_prefix.last_batch_record
        entries = []
        for g, action in pending.items():
            entry = self._entry(context, action, prefixes.get(g), prehold)
            packet['actions'][str(g)] = entry
            entries.append(entry)
        if remaining() <= 0.:
            return stop(last)
        approved = infer(entries)
        return stop(approved, True) if approved is not None else stop(last)

    def shadow(self, sample, packet, budget=None):
        """At most C/B true bounds-only shadow calls, never a sent command."""
        active = self.budget if budget is None else budget
        prediction = packet.get('application_prediction') or {}
        health = np.asarray(sample['health_vector'], dtype=float)
        damaged = np.flatnonzero(health < 1.)
        result = {'schema': VERSION, 'context_id': sample['context_id'], 'state_time_s': .020,
                  'method': packet.get('method'), 'damaged_channels': damaged, 'C': None, 'B': None,
                  'actuation': False, 'model_selection_read': False, 'calibration_read': False}
        if packet.get('method') != 'ALIGNED_RECAL' or not prediction.get('complete') or not len(damaged):
            result.update(status='NOT_RUN', reason='ALIGNED_PREDICTED_APPLICATION_PROBLEM_UNAVAILABLE')
            return result
        context = packet['context_used']
        for name in ('C', 'B'):
            endpoint = packet.get(name) or {}
            raw = endpoint.get('raw_solver_result', endpoint.get('wbc', {})) or {}
            problem, matrix = raw.get('step32_problem'), endpoint.get('source_matrices')
            if not problem or not matrix:
                result[name] = {'status': 'NOT_RUN', 'reason': 'ORIGINAL_SAME_CALL_PROBLEM_UNAVAILABLE'}
                continue
            changed = {key: value.copy() for key, value in problem.items()}
            row0 = 2 * matrix['nv'] + matrix['nc']
            rows = row0 + damaged
            changed['l'][rows] = -self.healthy_limits[damaged]
            changed['u'][rows] = self.healthy_limits[damaged]
            original_z = np.r_[endpoint.get('qdd', raw.get('qdd')),
                              endpoint.get('tau_raw', raw.get('tau')),
                              endpoint.get('contact_lambda', raw.get('contact_force'))] if all(
                                  v is not None for v in (endpoint.get('qdd', raw.get('qdd')),
                                    endpoint.get('tau_raw', raw.get('tau')), endpoint.get('contact_lambda', raw.get('contact_force')))) else None
            controller = self._shadow_controllers[name]
            reset_workspace_warmstart(controller)
            controller.solver_time_limit_s = .006
            self._bind(controller, active, 'CAPACITY_SHADOW_' + name, sample['context_id'], name)
            begin = perf_counter()
            answer = controller._invoke(changed, 'STEP32_BOUNDS_ONLY_SHADOW_' + name)
            z = answer.get('x')
            finite = bool(z is not None and np.shape(z) == (matrix['nv'] + matrix['nu'] + matrix['nc'],) and np.isfinite(z).all())
            exact = bool(answer.get('status_val') == 1 and not isinstance(answer.get('status_val'), (bool, np.bool_)) and finite)
            original_check = check_rows(matrix, np.asarray(z)) if finite else None
            bounded_check = check_rows(matrix, original_z) if original_z is not None and np.isfinite(original_z).all() else None
            tau = np.asarray(z)[matrix['nv']:matrix['nv'] + matrix['nu']].copy() if finite else None
            capacity = health * self.healthy_limits
            violation = np.maximum(np.abs(tau) - capacity, 0.) if tau is not None else None
            roundoff = (100. * np.finfo(float).eps * np.maximum.reduce(
                [np.ones_like(capacity), np.abs(self.healthy_limits), np.abs(tau)])) if tau is not None else None
            substantive_violation = bool(violation is not None and np.any(violation[damaged] > roundoff[damaged]))
            other = np.ones(len(problem['l']), dtype=bool)
            other[rows] = False
            same = bool(np.array_equal(problem['P'].data, changed['P'].data) and np.array_equal(problem['q'], changed['q']) and
                np.array_equal(problem['A'].data, changed['A'].data) and np.array_equal(problem['l'][other], changed['l'][other]) and
                np.array_equal(problem['u'][other], changed['u'][other]))
            original_valid = bool(bounded_check and bounded_check['pass'] and endpoint.get('command_valid', endpoint.get('valid_command', False)))
            dual_cache = controller._solver_cache.get(controller._workspace_key({'P': changed['P'], 'A': changed['A']}), {})
            result[name] = {'status': 'RETURNED', 'solver': answer, 'solver_status_val': answer.get('status_val'),
                'strict_solved_finite': exact, 'z_shadow': None if not finite else np.asarray(z).copy(),
                'z_original': original_z, 'tau_shadow_raw': tau, 'tau_original_raw': endpoint.get('tau_raw'),
                'raw_margin_original_capacity_nm': None if tau is None else capacity - np.abs(tau),
                'original_raw_margin_nm': None if original_z is None else capacity - np.abs(original_z[matrix['nv']:matrix['nv'] + matrix['nu']]),
                'capacity_violation_nm': violation, 'original_rows_check': original_check,
                'shadow_minus_original_tau_nm': None if tau is None or original_z is None else
                    tau - original_z[matrix['nv']:matrix['nv'] + matrix['nu']],
                'floating_roundoff_bound_nm': roundoff,
                'roundoff_only_capacity_violation': bool(violation is not None and np.any(violation[damaged] > 0.) and not substantive_violation),
                'roundoff_rule': '100 * machine_double_epsilon * max(1 Nm, healthy_capacity, abs(shadow_tau)); diagnostic exclusion only',
                'bounded_original_rows_check': bounded_check, 'original_bounded_feasible': original_valid,
                'capacity_bound_effect': bool(exact and original_valid and substantive_violation and
                                               np.any(~original_check['row_pass'][rows])),
                'changed_row_indices': rows.copy(), 'changed_channel_indices': damaged.copy(),
                'original_l_rows': problem['l'][rows].copy(), 'original_u_rows': problem['u'][rows].copy(),
                'shadow_l_rows': changed['l'][rows].copy(), 'shadow_u_rows': changed['u'][rows].copy(),
                'same_except_injured_torque_bounds': same, 'servo_health_unchanged': health.copy(),
                'same_state_integration': np.asarray(_saved(context)['integration_state']).copy(),
                'original_dual': raw.get('step32_existing_dual'),
                'shadow_dual': None if dual_cache.get('last_y') is None else dual_cache['last_y'].copy(),
                'QP_problem_original': problem, 'QP_problem_shadow': changed,
                'original_matrices': matrix, 'elapsed_ms': (perf_counter() - begin) * 1000.,
                'new_QP_calls': 1, 'actuated': False}
            if not same:
                raise RuntimeError('STEP32 shadow changed a non-torque problem coefficient')
        result['status'] = 'RETURNED'
        return result
