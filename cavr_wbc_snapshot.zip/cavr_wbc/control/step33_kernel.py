"""Application-clock STEP33 governor using the frozen STEP30 arithmetic.

Every state-dependent operation needed for a TEST decision is inside a single
sample-clock deadline.  Prehold is a known previous command, not an optimizer
return.  The bounds-only shadow owns different solvers and never actuates.
"""
from __future__ import annotations

import ctypes
import os

import osqp
from copy import deepcopy
from time import perf_counter

import mujoco
import numpy as np

from cavr_wbc.control.step30_kernel import Kernel as FrozenKernel
from cavr_wbc.control.step29_kernel import DeadlineWBC, DEADLINE_S, FINAL_RESERVE_S, MIN_SOLVER_S, MAX_SOLVER_S
from cavr_wbc.control.step27_resident_kernel import ResidentWBC, _copy_integration, reset_workspace_warmstart
from cavr_wbc.control.step28_native_prefix import _Buffers, PHYSICS_STEPS, STATE_COUNT, PHYSICS_DT_S, PHYSICAL_NAMES, SCALAR_NAMES, CONTACT_NAMES
from cavr_wbc.control.step30_actions import GAMMA_GRID, prepare_shared, make_action, check_rows
from cavr_wbc.experiments.step31_sim import capture_packet_memory

VERSION = 'STEP33_CALIBRATION_REPAIR_KERNEL_V1'
OFFLINE_TEACHER_QP_LIMIT_S = .100
METHODS = ('STALE_RECAL', 'ALIGNED_RECAL')
STATE_FIELDS = ('qpos', 'qvel', 'act', 'ctrl', 'qacc_warmstart', 'qfrc_applied', 'xfrc_applied',
                'mocap_pos', 'mocap_quat', 'userdata', 'plugin_state')

SOLVER_EVIDENCE_FIELDS = (
    'solver_owner_id', 'solver_owner_scope', 'owner_pid', 'osqp_time_limit_s',
    'configured_native_time_limit_s', 'setup_time_s', 'update_time_s',
    'update_settings_time_s', 'warm_start_wall_time_s', 'solve_time_s',
    'solve_wall_time_s', 'polish_time_s', 'polish_status', 'invoke_total_wall_time_s',
    'solve_wall_includes_polish', 'end_to_end_hard_wall_cap_claim',
)


def _owned_solve(controller, problem, max_iter_override=None):
    """One unchanged OSQP call, configured before execution, without rescue."""
    begin = perf_counter()
    P = problem['P'].tocsc(copy=False)
    A = problem['A'].tocsc(copy=False)
    P.sort_indices()
    A.sort_indices()
    key = controller._workspace_key({'P': P, 'A': A})
    cache = controller._solver_cache.get(key)
    max_iter = int(controller.cfg.osqp_max_iter if max_iter_override is None else max_iter_override)
    teacher = controller.solver_owner_scope == 'OFFLINE_DELAY_TEACHER_DEV_ONLY'
    limit = OFFLINE_TEACHER_QP_LIMIT_S if teacher else float(controller.solver_time_limit_s)
    if teacher:
        if controller.solver_time_limit_s != OFFLINE_TEACHER_QP_LIMIT_S:
            raise ValueError('STEP33 teacher owner must remain fixed at native 100 ms')
    elif not MIN_SOLVER_S <= limit <= MAX_SOLVER_S:
        raise ValueError('STEP33 online owner remains within native 1--6 ms')
    setup_s = update_s = settings_s = warm_s = 0.
    reused = cache is not None
    warm_started = False
    if cache is None:
        start = perf_counter()
        solver = osqp.OSQP()
        solver.setup(P=P, q=problem['q'], A=A, l=problem['l'], u=problem['u'],
            eps_abs=controller.cfg.osqp_eps_abs, eps_rel=controller.cfg.osqp_eps_rel,
            max_iter=max_iter, polish=True, verbose=False, time_limit=limit)
        setup_s = perf_counter() - start
        controller.solver_setup_calls += 1
        cache = {'solver': solver, 'last_x': None, 'last_y': None,
            'zero_x': np.zeros(P.shape[0]), 'zero_y': np.zeros(A.shape[0]),
            'setup_count': controller.solver_setup_calls, 'native': False,
            'independent_case_zeroed': True, 'time_limit_s': limit,
            'solver_owner_id': controller.solver_owner_id,
            'solver_owner_scope': controller.solver_owner_scope}
        controller._solver_cache[key] = cache
    else:
        if cache.get('solver_owner_id') != controller.solver_owner_id:
            raise ValueError('STEP33 solver workspace belongs to another owner')
        solver = cache['solver']
        start = perf_counter()
        solver.update(Px=P.data, Ax=A.data, q=problem['q'], l=problem['l'], u=problem['u'])
        update_s = perf_counter() - start
        start = perf_counter()
        solver.update_settings(time_limit=limit)
        settings_s = perf_counter() - start
        cache['time_limit_s'] = limit
        if cache['last_x'] is not None or cache['last_y'] is not None:
            start = perf_counter()
            solver.warm_start(x=cache['last_x'], y=cache['last_y'])
            warm_s = perf_counter() - start
            warm_started = True
    start = perf_counter()
    raw = solver.solve(raise_error=False)
    solve_wall = perf_counter() - start
    cache['last_x'] = None if raw.x is None else np.asarray(raw.x, dtype=float).copy()
    cache['last_y'] = None if raw.y is None else np.asarray(raw.y, dtype=float).copy()
    cache['independent_case_zeroed'] = False
    info = raw.info
    result = {'x': None if raw.x is None else np.asarray(raw.x, dtype=float),
        'status': str(info.status), 'status_val': int(info.status_val),
        'iterations': int(info.iter), 'solve_time_s': float(info.solve_time),
        'solve_wall_time_s': solve_wall, 'setup_time_s': setup_s,
        'update_time_s': update_s, 'update_settings_time_s': settings_s,
        'warm_start_wall_time_s': warm_s, 'polish_time_s': float(info.polish_time),
        'polish_status': int(info.status_polish), 'workspace_reused': reused,
        'warm_started': warm_started, 'primal_residual': float(info.prim_res),
        'dual_residual': float(info.dual_res), 'kernel_variant': controller.variant,
        'osqp_time_limit_s': limit, 'configured_native_time_limit_s': limit,
        'solver_owner_id': controller.solver_owner_id,
        'solver_owner_scope': controller.solver_owner_scope, 'owner_pid': os.getpid(),
        'invoke_total_wall_time_s': perf_counter() - begin,
        'solve_wall_includes_polish': True, 'end_to_end_hard_wall_cap_claim': False,
        'native_api': 'osqp.OSQP public Python binding to installed native extension'}
    controller._last_solver_timings = {
        name: result[name] for name in SOLVER_EVIDENCE_FIELDS if name in result}
    return result


class OnlineWBC(DeadlineWBC):
    """Unchanged bounded mathematics/settings, with complete timing evidence."""
    def __init__(self, model, solve_callback=None):
        super().__init__(model, solve_callback=solve_callback, variant='K_BUDGETED')
        self.solver_owner_scope = 'ONLINE_6MS_20MS_WINDOW'
        self.solver_owner_id = '%s:%s:%s' % (os.getpid(), self.solver_owner_scope, id(self))

    def _default_solve(self, problem, *, max_iter_override=None):
        return _owned_solve(self, problem, max_iter_override)


class OfflineTeacherWBC(ResidentWBC):
    """DEV-only solver owner; never uses DeadlineWBC's bounded-limit path."""
    def __init__(self, model, solve_callback=None, *, dev_authorized=False):
        if dev_authorized is not True:
            raise ValueError('STEP33 offline teacher requires DEV-only authorization')
        super().__init__(model, solve_callback=solve_callback, variant='K_BUDGETED')
        self.solver_time_limit_s = OFFLINE_TEACHER_QP_LIMIT_S
        self.solver_owner_scope = 'OFFLINE_DELAY_TEACHER_DEV_ONLY'
        self.solver_owner_id = '%s:%s:%s' % (os.getpid(), self.solver_owner_scope, id(self))

    def _default_solve(self, problem, *, max_iter_override=None):
        return _owned_solve(self, problem, max_iter_override)



def _state(model, data):
    signature = int(mujoco.mjtState.mjSTATE_INTEGRATION)
    vector = np.empty(int(mujoco.mj_stateSize(model, signature)))
    mujoco.mj_getState(model, data, vector, signature)
    return {'integration_state_signature': signature, 'integration_state': vector,
            'time': float(data.time), **{key: np.asarray(getattr(data, key)).copy() for key in STATE_FIELDS}}


def _saved(sample):
    return sample.get('state', sample.get('source_state', sample))


def construct_prehold(sample, healthy_limits):
    """Validate a saved healthy command's identity and apply the new health clip."""
    state = _saved(sample)
    identity = sample.get('previous_command_identity') or {}
    if not isinstance(identity, dict) or identity.get('available') is not True:
        raise ValueError('STEP33 known previous command identity is unavailable')
    tau = np.asarray(sample.get('previous_tau_sent', identity.get('tau_sent')), dtype=float)
    health = np.asarray(sample['health_vector'], dtype=float)
    limits = np.asarray(healthy_limits, dtype=float)
    if (tau.shape != limits.shape or health.shape != limits.shape or not np.isfinite(tau).all()
            or not np.isfinite(health).all() or np.any((health < 0.) | (health > 1.))):
        raise ValueError('STEP33 previous command or health has invalid shape/units')
    if (identity.get('episode_id') != sample.get('episode_id')
            or identity.get('source_tick') != sample.get('source_tick')
            or identity.get('previous_reference_tick', identity.get('applied_previous_reference_tick')) != int(sample['source_tick']) - 1
            or identity.get('source_solver_status_val') != 1
            or isinstance(identity.get('source_solver_status_val'), (bool, np.bool_))
            or identity.get('actual_state_ctrl_matches_healthy_fact_and_control') is False
            or not np.array_equal(np.asarray(identity.get('health_vector', identity.get('source_health_vector'))), np.ones_like(health))
            or not np.array_equal(np.asarray(state.get('ctrl')), tau)
            or not np.array_equal(np.asarray(identity.get('tau_sent')), tau)):
        raise ValueError('STEP33 previous command source/state identity mismatch')
    if identity.get('source_snapshot', identity.get('snapshot_id')) not in (sample.get('source_snapshot'), sample.get('snapshot_id')):
        raise ValueError('STEP33 previous command snapshot identity mismatch')
    sent = np.clip(tau, -health * limits, health * limits)
    return {'schema': VERSION, 'source': 'LAST_COMMAND_HEALTH_CLIPPED', 'kind': 'PREHOLD',
            'command_valid': True, 'solver_status_val': None, 'new_QP_calls': 0,
            'tau_raw': tau.copy(), 'tau_sent': sent, 'health_vector': health.copy(),
            'healthy_torque_limits_nm': limits.copy(), 'effective_capacity_nm': health * limits,
            'previous_command_identity': deepcopy(identity), 'certified_backup': False,
            'sample_start_s': 0., 'sample_end_s': .020}


def application_context(sample, prediction):
    """Copy only predicted integration state; the original anchor stays fixed."""
    context = dict(sample)
    context['state'] = prediction['state']
    context['source_state'] = prediction['state']
    context['backup_anchor_q_init'] = np.asarray(sample['backup_anchor_q_init']).copy()
    context['original_sample_state'] = _saved(sample)
    context['original_direction'] = float(sample.get('direction', 1. if _saved(sample)['qvel'][0] > 0. else -1.))
    context['application_state_source'] = 'INDEPENDENT_PREHOLD_PREDICTION'
    context['application_time_s'] = .020
    return context


class Kernel(FrozenKernel):
    def __init__(self, model, variant='BOUNDED', prefixdll=None, budget=None, teacher=False):
        if variant != 'BOUNDED':
            raise ValueError('STEP33 never instantiates an unlimited REFERENCE solver')
        super().__init__(model, variant=variant, prefixdll=prefixdll, budget=budget)
        self.teacher = bool(teacher)
        self._replace_solver_owners()
        self.solver_time_limit_s = OFFLINE_TEACHER_QP_LIMIT_S if self.teacher else MAX_SOLVER_S
        self.version = VERSION
        template = self.native_prefix.buffers['C'].request
        values = {name: getattr(template, name) for name, _ in template._fields_
                  if name not in ('health', 'tau_sent', 'x0', 'direction')}
        self._application_buffer = _Buffers(model, len(self.native_prefix.limited_addresses), values)
        self._application_source = mujoco.MjData(model)
        self._shadow_controllers = {name: OnlineWBC(model) for name in ('C', 'B')}
        self._capture_problem(self.nominal_controller)
        self._capture_problem(self.backup_controller)


    def _replace_solver_owners(self):
        # Construction only: no calls, no existing workspaces and no PID changes.
        make = (lambda: OfflineTeacherWBC(self.model, dev_authorized=True)) if self.teacher else (lambda: OnlineWBC(self.model))
        self.nominal_controller = make()
        self.backup_controller = make()
        self.policy.controller = self.backup_controller

    def _configure(self, controller):
        if getattr(self, 'teacher', False):
            if not isinstance(controller, OfflineTeacherWBC):
                raise ValueError('STEP33 teacher must use its own offline solver owner')
            controller.solver_time_limit_s = OFFLINE_TEACHER_QP_LIMIT_S
            self._next_call_limit = None
        else:
            super()._configure(controller)

    def configure_feedback(self, sample):
        if getattr(self, 'teacher', False):
            if sample.get('split') != 'DEV':
                raise ValueError('STEP33 teacher feedback is DEV-only')
            if self.policy.controller is not self.backup_controller:
                raise ValueError('STEP33 backup controller alias changed')
            self._configure(self.backup_controller)
        else:
            self.set_next_call_limit(MAX_SOLVER_S)

    def _bind(self, controller, budget, kind, owner, first_mode=None):
        if getattr(self, 'teacher', False) and (str(kind).startswith('ONLINE') or str(kind).startswith('COUNTERFACTUAL')):
            raise ValueError('STEP33 teacher owner cannot service an online/TEST call')
        return super()._bind(controller, budget, kind, owner, first_mode)

    def _teacher_context(self, context):
        if (getattr(self, 'teacher', False) and context.get('split') != 'DEV'
                and not getattr(self, '_startup_active', False)):
            raise ValueError('STEP33 teacher may use only DEV contexts or healthy-home startup')

    def nominal(self, context, budget=None, kind='NOMINAL', owner=None):
        self._teacher_context(context)
        return super().nominal(context, budget, kind, owner)

    def compute_backup(self, context, slot, budget=None, kind='ACTUAL_B', owner=None):
        self._teacher_context(context)
        return super().compute_backup(context, slot, budget, kind, owner)

    def solver_owner_identity(self):
        return {'pid': os.getpid(),
            'scope': 'OFFLINE_DELAY_TEACHER_DEV_ONLY' if getattr(self, 'teacher', False) else 'ONLINE_6MS_20MS_WINDOW',
            'nominal_owner': getattr(getattr(self, 'nominal_controller', None), 'solver_owner_id', None),
            'backup_owner': getattr(getattr(self, 'backup_controller', None), 'solver_owner_id', None)}

    def _capture_packet(self, packet):
        identity = self.solver_owner_identity()
        if 'step33_solver_owner' in packet and packet['step33_solver_owner'] != identity:
            raise ValueError('STEP33 cannot relabel another solver owner as the packet source')
        capture_packet_memory(self, packet)
        packet['step33_solver_owner'] = identity
        memory = packet['step31_backup_memory']
        if memory.get('status') == 'CAPTURED_B0':
            memory['step33_solver_owner'] = deepcopy(packet['step33_solver_owner'])
            raw = (packet.get('B') or {}).get('wbc', (packet.get('B') or {}).get('raw_solver_result', {}))
            memory['same_call_CSC_problem'] = raw.get('step33_problem')
            memory['same_call_CSC_captured_before_any_branch'] = True
        return packet

    @staticmethod
    def _capture_problem(controller):
        original = controller._invoke
        original_decode = controller._decode

        def invoke(problem, stage, **kwargs):
            # This necessary copy belongs to command-ready, not a free proposal.
            saved = {name: problem[name].copy() for name in ('P', 'q', 'A', 'l', 'u')}
            result = original(problem, stage, **kwargs)
            result['step33_problem'] = saved
            key = controller._workspace_key({'P': problem['P'], 'A': problem['A']})
            cache = controller._solver_cache.get(key, {})
            result['step33_existing_dual'] = None if cache.get('last_y') is None else cache['last_y'].copy()
            rows = getattr(controller, 'solver_ledger', [])
            if rows and rows[-1].get('solver_call_index') == result.get('solver_call_index'):
                rows[-1].update({name: result[name] for name in SOLVER_EVIDENCE_FIELDS if name in result})
            return result

        def decode(answer, *args, **kwargs):
            result = original_decode(answer, *args, **kwargs)
            # The frozen decoder deliberately creates a new result dictionary;
            # retain the already-counted same-call shadow evidence in that new
            # dictionary, without assembling another problem or solving again.
            for name in ('step33_problem', 'step33_existing_dual') + SOLVER_EVIDENCE_FIELDS:
                if name in answer:
                    result[name] = answer[name]
            return result
        controller._invoke = invoke
        controller._decode = decode

    def construct_prehold(self, sample):
        return construct_prehold(sample, self.healthy_limits)

    def predict_application(self, sample, prehold, budget=None):
        """Ten counted native steps in a resident independent prediction MjData."""
        active = self.budget if budget is None else budget
        begin = perf_counter()
        _copy_integration(self.model, self._application_source, sample)
        buf = self._application_buffer
        np.copyto(buf.health, prehold['health_vector'])
        np.copyto(buf.tau_raw, prehold['tau_raw'])
        np.copyto(buf.tau_sent, prehold['tau_sent'])
        buf.request.x0 = float(np.asarray(sample['backup_anchor_q_init'])[0])
        direction = float(sample.get('direction', 1. if _saved(sample)['qvel'][0] > 0. else -1.))
        if direction not in (-1., 1.):
            raise ValueError('STEP33 original direction must be frozen +/-1')
        buf.request.direction = direction
        buf.output.actual_steps = 0
        buf.output.state_count = 0
        token = active.reserve_steps('APPLICATION_PREDICTION', sample['context_id'], 10) if active is not None else None
        try:
            rc = int(self.native_prefix._fn(self.native_prefix._model_pointer,
                ctypes.c_void_p(int(self._application_source._address)), ctypes.c_void_p(int(buf.data._address)),
                ctypes.byref(buf.request), ctypes.byref(buf.output)))
        finally:
            if active is not None:
                active.finish_steps(token, int(buf.output.actual_steps))
        count, steps = int(buf.output.state_count), int(buf.output.actual_steps)
        if rc < 0 or not 0 <= count <= 11 or not 0 <= steps <= 10:
            raise RuntimeError('STEP33 application prediction native interface error')
        complete = bool(rc == 0 and count == 11 and steps == 10 and buf.output.all_finite)
        numeric = {name: getattr(buf, name)[:count].copy() for name in
            ('qpos', 'qvel', 'qacc', 'applied', 'subtree_com', 'joint_margins', 'contacts', 'scalars', 'reason_masks', 'ncon')}
        numeric.update(physical_names=PHYSICAL_NAMES, scalar_names=SCALAR_NAMES, contact_names=CONTACT_NAMES,
                       physics_steps=np.arange(count), tau_raw=buf.tau_raw.copy(), tau_sent=buf.tau_sent.copy())
        record = {'schema': VERSION, 'kind': 'APPLICATION_PREDICTION', 'complete': complete,
            'available': complete, 'state': _state(self.model, buf.data) if complete else None,
            'numeric': numeric, 'state_count': count, 'actual_steps': steps,
            'original_physical_pass': bool(complete and buf.output.all_physical_pass),
            'D_prehold_m': float(buf.output.max_direction_displacement) if count and buf.output.all_finite else None,
            'direction': direction, 'x0_m': float(buf.request.x0), 'horizon_s': .020,
            'actual_trajectory_read': False, 'teacher_calls': 0, 'new_QP_calls': 0,
            'elapsed_ms': (perf_counter() - begin) * 1000., 'independent_prediction_data': True,
            'original_sample_state': _saved(sample), 'original_anchor_q_init': np.asarray(sample['backup_anchor_q_init']).copy()}
        prehold.update(complete=complete, original_physical_pass=record['original_physical_pass'],
                       D_prehold_m=record['D_prehold_m'], application_prediction_steps=steps)
        return record

    def _prepare_sample(self, sample, budget, method):
        if method not in METHODS:
            raise ValueError('STEP33 unknown paired method')
        prehold = self.construct_prehold(sample)
        prediction = self.predict_application(sample, prehold, budget)
        context = application_context(sample, prediction) if method == 'ALIGNED_RECAL' and prediction['complete'] else dict(sample)
        return context, prehold, prediction

    def _entry(self, context, action, prefix, prehold):
        entry = {'gamma': float(action['gamma']), 'role': context['health_kind'].split('_')[0].lower(),
                 'action': action, 'prefix': prefix, 'features26': None, 'features23': None,
                 'prehold': prehold, 'prehold_D_m': prehold.get('D_prehold_m'), 'decision': None,
                 'evaluation_status': 'COMMAND_UNAVAILABLE'}
        if prefix is not None and action.get('command_valid'):
            try:
                features = self.features(context, action, prefix)
                entry.update(features26=features, features=features, features23=features[:23],
                             evaluation_status='READY_FOR_NUMERIC_LOOKUP')
            except (KeyError, ValueError, TypeError) as exc:
                entry.update(evaluation_status='PREDICTION_INPUT_UNAVAILABLE', feature_error=str(exc))
        return entry

    def _prefix_one(self, context, action, active):
        try:
            original_direction = float(context.get('original_direction', context.get('direction', 1. if _saved(context)['qvel'][0] > 0. else -1.)))
            if original_direction * float(_saved(context)['qvel'][0]) <= 0.:
                return {'complete': False, 'original_physical_pass': False, 'D_prefix_m': None,
                        'reason': 'FROZEN_PREFIX_DIRECTION_INPUT_UNAVAILABLE', 'actual_steps': 0}
            return self.prefix_action(context, action, active)
        except (ValueError, TypeError) as exc:
            return {'complete': False, 'original_physical_pass': False, 'D_prefix_m': None,
                    'reason': 'FROZEN_PREFIX_INPUT_UNAVAILABLE', 'error': str(exc), 'actual_steps': 0}

    def _prefix_lower(self, context, actions, active):
        try:
            original_direction = float(context.get('original_direction', context.get('direction', 1. if _saved(context)['qvel'][0] > 0. else -1.)))
            if original_direction * float(_saved(context)['qvel'][0]) <= 0.:
                raise ValueError('frozen original direction differs from application velocity')
            return self.prefix_actions(context, actions, active)
        except (ValueError, TypeError) as exc:
            return {gamma: {'complete': False, 'original_physical_pass': False, 'D_prefix_m': None,
                'reason': 'FROZEN_PREFIX_INPUT_UNAVAILABLE', 'error': str(exc), 'actual_steps': 0} for gamma in actions}

    def collect_actions(self, sample, budget=None, method='ALIGNED_RECAL'):
        """DEV's single C/B set and five actions; no actual trajectory or CAL read."""
        if getattr(self, 'teacher', False) and sample.get('split') != 'DEV':
            raise ValueError('STEP33 teacher collection uses DEV inputs only')
        active = self.budget if budget is None else budget
        begin = perf_counter()
        context, prehold, prediction = self._prepare_sample(sample, active, method)
        packet = {'schema': VERSION, 'context_id': sample['context_id'], 'method': method,
                  'context_used': context, 'prehold': prehold, 'application_prediction': prediction,
                  'sample_context': sample, 'actions': {}, 'selected_command_sent': False,
                  'selected_gamma': None, 'status': 'DEV_COLLECTION'}
        if not prediction['complete']:
            packet.update(C={'status': 'APPLICATION_PREDICTION_UNAVAILABLE'}, B={'status': 'APPLICATION_PREDICTION_UNAVAILABLE'},
                          command_ready_ms=(perf_counter() - begin) * 1000.)
            packet['actions'] = {str(g): self._entry(context, make_action(context, None, None, g), None, prehold)
                                 for g in GAMMA_GRID}
            return packet
        self.reset(context)
        if not getattr(self, 'teacher', False):
            self.set_next_call_limit(MAX_SOLVER_S)
        C = self.nominal(context, active, 'DEV_' + method + '_C', sample['context_id'])
        if not getattr(self, 'teacher', False):
            self.set_next_call_limit(MAX_SOLVER_S)
        B = self.first_backup(context, active, 'DEV_' + method + '_B', sample['context_id'])
        packet.update(C=C, B=B, offline_teacher=getattr(self, 'teacher', False),
            label_semantics='OFFLINE_DELAY_TEACHER_100MS' if getattr(self, 'teacher', False) else 'ONLINE_BOUNDED_6MS',
            native_endpoint_QP_limit_s=OFFLINE_TEACHER_QP_LIMIT_S if getattr(self, 'teacher', False) else MAX_SOLVER_S)
        workspace = prepare_shared(context, C, B)
        actions = {g: make_action(context, C, B, g, workspace=workspace) for g in GAMMA_GRID}
        prefixes = {}
        if actions[1.].get('command_valid'):
            prefixes[1.] = self._prefix_one(context, actions[1.], active)
        lower = {g: action for g, action in actions.items() if g < 1. and action.get('command_valid')}
        if lower:
            prefixes.update(self._prefix_lower(context, lower, active))
        for gamma, action in actions.items():
            packet['actions'][str(gamma)] = self._entry(context, action, prefixes.get(gamma), prehold)
        self._capture_packet(packet)
        packet['command_ready_ms'] = (perf_counter() - begin) * 1000.
        packet['step31_backup_memory']['decision_command_ready_ms_unchanged'] = packet['command_ready_ms']
        return packet

    def endpoint_diagnostic(self, sample, budget=None, method='ALIGNED_RECAL'):
        """One 20 ms C/B availability window, without CAL inference or sending."""
        if getattr(self, 'teacher', False):
            raise ValueError('STEP33 endpoint diagnostic must use online-only owners')
        active = self.budget if budget is None else budget
        begin = perf_counter()
        deadline = begin + DEADLINE_S
        packet = {'schema': VERSION, 'context_id': sample['context_id'], 'method': method,
            'sample_context': sample, 'prepare_begin': begin, 'absolute_deadline': deadline,
            'deadline_ms': 20., 'C': {'status': 'NOT_REQUESTED'}, 'B': {'status': 'NOT_REQUESTED'},
            'actions': {}, 'selected_gamma': None, 'selected_action': None,
            'selected_command_sent': False, 'calibration_read': False, 'CAL_approved': False,
            'ACTUAL_calls': 0, 'diagnostic_only': True, 'endpoint_calls': 0,
            'status': 'ENDPOINT_AVAILABILITY_DIAGNOSTIC'}

        def stop(reason=None):
            self._capture_packet(packet)
            elapsed = (perf_counter() - begin) * 1000.
            packet.update(command_ready_ms=elapsed, elapsed_ms=elapsed,
                overall_deadline_failure=elapsed > 20., reason=reason,
                command_available=any((packet.get(name) or {}).get('command_valid',
                    (packet.get(name) or {}).get('valid_command', False)) for name in ('C', 'B')),
                selected_command_sent=False)
            packet['step31_backup_memory']['decision_command_ready_ms_unchanged'] = elapsed
            return packet

        context, prehold, prediction = self._prepare_sample(sample, active, method)
        packet.update(context_used=context, prehold=prehold, application_prediction=prediction,
            QP_state_time_s=.020 if method == 'ALIGNED_RECAL' else 0.,
            actual_first_packet_apply_time_s=.020)
        if not prediction['complete']:
            return stop('APPLICATION_PREDICTION_UNAVAILABLE')
        if not getattr(self, 'ready', False):
            return stop('ONLINE_RESIDENT_OWNER_NOT_READY')
        self.reset(context)
        for name in ('C', 'B'):
            if active is not None:
                active.check()
            limit = min(MAX_SOLVER_S, deadline - perf_counter() - FINAL_RESERVE_S)
            if limit < MIN_SOLVER_S:
                packet[name] = {'status': 'NOT_EVALUATED_BUDGET', 'command_valid': False}
                continue
            self.set_next_call_limit(limit)
            fn = self.nominal if name == 'C' else self.first_backup
            packet[name] = fn(context, active, 'ONLINE_DIAGNOSTIC_' + method + '_' + name, sample['context_id'])
            packet['endpoint_calls'] += 1
        return stop()

    def governor(self, sample, bundle, gap, budget=None, method='ALIGNED_RECAL', decide=None):
        """One absolute sample-clock window, including prehold/state prediction."""
        if getattr(self, 'teacher', False):
            raise ValueError('STEP33 offline teacher cannot perform TEST governor decisions')
        from cavr_wbc.control.step33_margin import calibrated_gammas, batch_numeric
        active = self.budget if budget is None else budget
        begin = perf_counter()
        deadline = begin + DEADLINE_S
        role = sample['health_kind'].split('_')[0].lower()
        eligible = calibrated_gammas(bundle, role, GAMMA_GRID) if decide is None else GAMMA_GRID
        packet = {'schema': VERSION, 'context_id': sample['context_id'], 'method': method, 'sample_context': sample,
            'gap_m': float(gap), 'deadline_ms': 20., 'prepare_begin': begin, 'absolute_deadline': deadline,
            'C': {'status': 'NOT_REQUESTED'}, 'B': {'status': 'NOT_REQUESTED'}, 'actions': {},
            'selected_gamma': None, 'selected_action': None, 'selected_command_sent': False,
            'qualified_gammas': np.asarray(eligible), 'new_PID_prior_calls': 0, 'status': 'ABSTAIN'}
        C = B = last = None

        def remaining():
            return deadline - perf_counter()

        def solver_allowed():
            limit = min(MAX_SOLVER_S, remaining() - FINAL_RESERVE_S)
            if limit < MIN_SOLVER_S:
                return False
            self.set_next_call_limit(limit)
            return True

        def stop(action=None, recognized=False):
            # B0 restore memory is required by the first packet's semantics;
            # copy it before measuring ready, rather than creating free work.
            self._capture_packet(packet)
            elapsed = (perf_counter() - begin) * 1000.
            valid = bool(action and action.get('command_valid'))
            any_valid = bool(valid or any(ep and ep.get('command_valid', ep.get('valid_command', False)) for ep in (C, B)))
            timely = bool(elapsed <= 20.)
            sent = bool(recognized and valid and timely)
            packet.update(elapsed_ms=elapsed, command_ready_ms=elapsed, timely_recognized_command=sent,
                command_available=any_valid, selected_command_valid=valid, selected_command_sent=sent,
                selected_gamma=float(action['gamma']) if action is not None else None, selected_action=action,
                raw_valid_but_late=bool(any_valid and not timely), overall_deadline_failure=not timely,
                status='RECOGNIZED_SENT' if sent else 'COMPUTED_VALID_BUT_LATE' if any_valid and not timely else 'ABSTAIN')
            for g in GAMMA_GRID:
                packet['actions'].setdefault(str(g), {'gamma': g, 'evaluation_status':
                    'NOT_CALIBRATED' if g not in eligible else 'NOT_REQUESTED_AFTER_SELECTION' if sent else 'NOT_EVALUATED_BUDGET'})
            if action is not None:
                action['command_ready_ms'] = elapsed
            packet['step31_backup_memory']['decision_command_ready_ms_unchanged'] = elapsed
            return packet

        def infer(entries):
            entries = [e for e in entries if e['features26'] is not None]
            if not entries:
                return None
            if decide is not None:
                approved = None
                for entry in entries:
                    entry['decision'] = decide(bundle, entry, float(gap))
                    entry['evaluation_status'] = 'EVALUATED'
                    if (prehold['complete'] and prehold['original_physical_pass'] and
                        entry['prefix'].get('complete') and entry['prefix'].get('original_physical_pass') and
                        entry['decision'].get('accepted', entry['decision'].get('recognized', False)) and approved is None):
                        approved = entry['action']
                return approved
            n = len(entries)
            for i, entry in enumerate(entries):
                self._feature_buffer[i] = entry['features26']
                self._gamma_buffer[i] = entry['gamma']
                self._prefix_d_buffer[i] = max(float(entry['prefix']['D_prefix_m']), float(prehold['D_prehold_m']))
            numeric = batch_numeric(bundle, self._feature_buffer[:n], self._gamma_buffer[:n], [role] * n,
                                    self._prefix_d_buffer[:n], out=self._numeric_outputs[n])
            approved = None
            for i, entry in enumerate(entries):
                copied = {name: values[i].copy() if isinstance(values[i], np.ndarray) else values[i].item()
                          for name, values in numeric.items()}
                prefix = entry['prefix']
                gate = bool(prehold['complete'] and prehold['original_physical_pass'] and prefix['complete'] and
                    prefix['original_physical_pass'] and entry['action']['command_valid'] and
                    all(bool(numeric[name][i]) for name in ('finite_input', 'pose_gate', 'support_gate', 'distance_gate', 'calibration_gate')) and
                    np.all(numeric['U_T'][i] <= 1.) and numeric['U_D'][i] <= gap)
                entry.update(decision={'accepted': gate, 'choice': entry['gamma'] if gate else 'ABSTAIN', 'numeric': copied},
                             evaluation_status='EVALUATED', complete_at_ms=(perf_counter() - begin) * 1000.)
                if gate and approved is None:
                    approved = entry['action']
            return approved

        if not getattr(self, 'ready', False):
            packet['not_ready'] = True
            return stop()
        context, prehold, prediction = self._prepare_sample(sample, active, method)
        packet.update(context_used=context, prehold=prehold, application_prediction=prediction,
                      QP_state_time_s=.020 if method == 'ALIGNED_RECAL' else 0., actual_first_packet_apply_time_s=.020)
        if not prediction['complete']:
            packet['reason'] = 'APPLICATION_PREDICTION_UNAVAILABLE'
            return stop()
        self.reset(context)
        if active is not None:
            active.check()
        if not solver_allowed():
            packet['C'] = {'status': 'NOT_EVALUATED_BUDGET'}
            return stop()
        C = self.nominal(context, active, 'ONLINE_' + method + '_C', sample['context_id'])
        packet['C'] = C
        last = make_action(context, C, None, 1.)
        entry = self._entry(context, last, None, prehold)
        packet['actions']['1.0'] = entry
        if 1. in eligible and last.get('command_valid') and remaining() >= FINAL_RESERVE_S:
            prefix = self._prefix_one(context, last, active)
            entry = self._entry(context, last, prefix, prehold)
            packet['actions']['1.0'] = entry
            if remaining() > 0.:
                approved = infer([entry])
                if approved is not None:
                    return stop(approved, True)
        lower = tuple(g for g in GAMMA_GRID if g < 1. and g in eligible)
        if not lower or not solver_allowed():
            packet['B'] = {'status': 'NOT_EVALUATED_BUDGET' if lower else 'NOT_CALIBRATED'}
            return stop(last)
        B = self.first_backup(context, active, 'ONLINE_' + method + '_B', sample['context_id'])
        packet['B'] = B
        workspace = prepare_shared(context, C, B)
        packet['shared_identity_checks'] = workspace.shared_identity_checks
        pending = {}
        for g in lower:
            action = make_action(context, C, B, g, workspace=workspace)
            packet['actions'][str(g)] = self._entry(context, action, None, prehold)
            last = action
            if action.get('command_valid'):
                pending[g] = action
        if remaining() < FINAL_RESERVE_S:
            return stop(last)
        prefixes = self._prefix_lower(context, pending, active)
        packet['batch_prefix'] = self.native_prefix.last_batch_record
        entries = []
        for g, action in pending.items():
            entry = self._entry(context, action, prefixes.get(g), prehold)
            packet['actions'][str(g)] = entry
            entries.append(entry)
        if remaining() <= 0.:
            return stop(last)
        approved = infer(entries)
        return stop(approved, True) if approved is not None else stop(last)

    def shadow(self, sample, packet, budget=None):
        """At most C/B true bounds-only shadow calls, never a sent command."""
        active = self.budget if budget is None else budget
        prediction = packet.get('application_prediction') or {}
        health = np.asarray(sample['health_vector'], dtype=float)
        damaged = np.flatnonzero(health < 1.)
        result = {'schema': VERSION, 'context_id': sample['context_id'], 'state_time_s': .020,
                  'method': packet.get('method'), 'damaged_channels': damaged, 'C': None, 'B': None,
                  'actuation': False, 'model_selection_read': False, 'calibration_read': False}
        if packet.get('method') != 'ALIGNED_RECAL' or not prediction.get('complete') or not len(damaged):
            result.update(status='NOT_RUN', reason='ALIGNED_PREDICTED_APPLICATION_PROBLEM_UNAVAILABLE')
            return result
        context = packet['context_used']
        for name in ('C', 'B'):
            endpoint = packet.get(name) or {}
            raw = endpoint.get('raw_solver_result', endpoint.get('wbc', {})) or {}
            problem, matrix = raw.get('step33_problem'), endpoint.get('source_matrices')
            if not problem or not matrix:
                result[name] = {'status': 'NOT_RUN', 'reason': 'ORIGINAL_SAME_CALL_PROBLEM_UNAVAILABLE'}
                continue
            changed = {key: value.copy() for key, value in problem.items()}
            row0 = 2 * matrix['nv'] + matrix['nc']
            rows = row0 + damaged
            changed['l'][rows] = -self.healthy_limits[damaged]
            changed['u'][rows] = self.healthy_limits[damaged]
            original_z = np.r_[endpoint.get('qdd', raw.get('qdd')),
                              endpoint.get('tau_raw', raw.get('tau')),
                              endpoint.get('contact_lambda', raw.get('contact_force'))] if all(
                                  v is not None for v in (endpoint.get('qdd', raw.get('qdd')),
                                    endpoint.get('tau_raw', raw.get('tau')), endpoint.get('contact_lambda', raw.get('contact_force')))) else None
            controller = self._shadow_controllers[name]
            reset_workspace_warmstart(controller)
            controller.solver_time_limit_s = .006
            self._bind(controller, active, 'CAPACITY_SHADOW_' + name, sample['context_id'], name)
            begin = perf_counter()
            answer = controller._invoke(changed, 'STEP33_BOUNDS_ONLY_SHADOW_' + name)
            z = answer.get('x')
            finite = bool(z is not None and np.shape(z) == (matrix['nv'] + matrix['nu'] + matrix['nc'],) and np.isfinite(z).all())
            exact = bool(answer.get('status_val') == 1 and not isinstance(answer.get('status_val'), (bool, np.bool_)) and finite)
            original_check = check_rows(matrix, np.asarray(z)) if finite else None
            bounded_check = check_rows(matrix, original_z) if original_z is not None and np.isfinite(original_z).all() else None
            tau = np.asarray(z)[matrix['nv']:matrix['nv'] + matrix['nu']].copy() if finite else None
            capacity = health * self.healthy_limits
            violation = np.maximum(np.abs(tau) - capacity, 0.) if tau is not None else None
            roundoff = (100. * np.finfo(float).eps * np.maximum.reduce(
                [np.ones_like(capacity), np.abs(self.healthy_limits), np.abs(tau)])) if tau is not None else None
            substantive_violation = bool(violation is not None and np.any(violation[damaged] > roundoff[damaged]))
            other = np.ones(len(problem['l']), dtype=bool)
            other[rows] = False
            same = bool(np.array_equal(problem['P'].data, changed['P'].data) and np.array_equal(problem['q'], changed['q']) and
                np.array_equal(problem['A'].data, changed['A'].data) and np.array_equal(problem['l'][other], changed['l'][other]) and
                np.array_equal(problem['u'][other], changed['u'][other]))
            original_valid = bool(bounded_check and bounded_check['pass'] and endpoint.get('command_valid', endpoint.get('valid_command', False)))
            dual_cache = controller._solver_cache.get(controller._workspace_key({'P': changed['P'], 'A': changed['A']}), {})
            result[name] = {'status': 'RETURNED', 'solver': answer, 'solver_status_val': answer.get('status_val'),
                'strict_solved_finite': exact, 'z_shadow': None if not finite else np.asarray(z).copy(),
                'z_original': original_z, 'tau_shadow_raw': tau, 'tau_original_raw': endpoint.get('tau_raw'),
                'raw_margin_original_capacity_nm': None if tau is None else capacity - np.abs(tau),
                'original_raw_margin_nm': None if original_z is None else capacity - np.abs(original_z[matrix['nv']:matrix['nv'] + matrix['nu']]),
                'capacity_violation_nm': violation, 'original_rows_check': original_check,
                'shadow_minus_original_tau_nm': None if tau is None or original_z is None else
                    tau - original_z[matrix['nv']:matrix['nv'] + matrix['nu']],
                'floating_roundoff_bound_nm': roundoff,
                'roundoff_only_capacity_violation': bool(violation is not None and np.any(violation[damaged] > 0.) and not substantive_violation),
                'roundoff_rule': '100 * machine_double_epsilon * max(1 Nm, healthy_capacity, abs(shadow_tau)); diagnostic exclusion only',
                'bounded_original_rows_check': bounded_check, 'original_bounded_feasible': original_valid,
                'capacity_bound_effect': bool(exact and original_valid and substantive_violation and
                                               np.any(~original_check['row_pass'][rows])),
                'changed_row_indices': rows.copy(), 'changed_channel_indices': damaged.copy(),
                'original_l_rows': problem['l'][rows].copy(), 'original_u_rows': problem['u'][rows].copy(),
                'shadow_l_rows': changed['l'][rows].copy(), 'shadow_u_rows': changed['u'][rows].copy(),
                'same_except_injured_torque_bounds': same, 'servo_health_unchanged': health.copy(),
                'same_state_integration': np.asarray(_saved(context)['integration_state']).copy(),
                'original_dual': raw.get('step33_existing_dual'),
                'shadow_dual': None if dual_cache.get('last_y') is None else dual_cache['last_y'].copy(),
                'QP_problem_original': problem, 'QP_problem_shadow': changed,
                'original_matrices': matrix, 'elapsed_ms': (perf_counter() - begin) * 1000.,
                'new_QP_calls': 1, 'actuated': False}
            if not same:
                raise RuntimeError('STEP33 shadow changed a non-torque problem coefficient')
        result['status'] = 'RETURNED'
        return result
