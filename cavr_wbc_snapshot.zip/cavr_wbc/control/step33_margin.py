"""DEV-only delay calibration of the unchanged STEP30 six-output predictor.

This module never fits a regression.  Both method objects retain the exact
TRAIN support, coefficients, scaler, pose domain and distance thresholds.  New
CAL targets refer to sample t=1 s, and incomplete finite CAL rows stay in the
LOCAL neighbor population so that they cannot disappear into safe evidence.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
from pathlib import Path

import numpy as np

from cavr_wbc.control import step30_margin as frozen


VERSION = "STEP33_TEACHER_DELAY_CAL_V1"
METHODS = ("STALE_RECAL", "ALIGNED_RECAL")
MAIN = frozen.MAIN
GAMMA_GRID = frozen.GAMMA_GRID
ROLES = frozen.ROLES
K = frozen.K
MIN_CAL_SNAPSHOTS = frozen.MIN_CAL_SNAPSHOTS
MIN_CAL_EPISODES = frozen.MIN_CAL_EPISODES
D_RESERVE_M = frozen.D_RESERVE_M
TERMINAL_RESERVE = frozen.TERMINAL_RESERVE
POSE_PAD_RAD = frozen.POSE_PAD_RAD
TERMINAL_NAMES = frozen.TERMINAL_NAMES
FEATURE_NAMES = frozen.FEATURE_NAMES
PHYSICAL_FLOORS = frozen.PHYSICAL_FLOORS
gamma_key = frozen.gamma_key
group_key = frozen.group_key
labels = frozen.labels
safe = frozen.safe
prefix_available = frozen.prefix_available
prefix_physical_pass = frozen.prefix_physical_pass
prefix_displacement = frozen.prefix_displacement
append_geometry_features = frozen.append_geometry_features
allocate_numeric = frozen.allocate_numeric
local_cal_indices = frozen.local_cal_indices

_BUNDLE_ARRAYS = frozen._BUNDLE_ARRAYS
_GROUP_ARRAYS = (*frozen._GROUP_ARRAYS, "cal_complete")
_TRAIN_ARRAYS = ("train_z", "train_norm2", "train_ids", "train_complete", "train_physical")


def _method(method):
    if method not in METHODS:
        raise ValueError("STALE_RECAL or ALIGNED_RECAL required")
    return method


def _local(calibration):
    if calibration != "LOCAL":
        raise ValueError("STEP33 uses only frozen LOCAL calibration rules")
    return calibration


def _prehold(entry):
    saved = entry.get("prehold") or {}
    d = entry.get("prehold_D_m", saved.get("D_prehold_m", saved.get("D_max_m", saved.get("D_m"))))
    complete = bool(entry.get("prehold_complete", saved.get("complete", False)))
    physical = bool(entry.get("prehold_original_physical_pass", saved.get("original_physical_pass", saved.get("physical_pass", False))))
    if d is None or not np.isfinite(d) or float(d) < 0.:
        raise ValueError("finite nonnegative original-anchor prehold D required")
    return float(d), complete, physical


def _lower_bound(entry):
    prehold_d, complete, physical = _prehold(entry)
    prefix = entry.get("prefix")
    prefix_d = prefix_displacement(prefix)
    if not np.isfinite(prefix_d) or prefix_d < 0.:
        raise ValueError("finite original-anchor action-prefix D required")
    available = bool(prefix_available(prefix) and complete)
    return max(float(prefix_d), prehold_d), available, bool(prefix_physical_pass(prefix) and physical)


def _array_digest(array):
    value = np.ascontiguousarray(array)
    digest = hashlib.sha256()
    digest.update(str(value.dtype).encode("utf-8"))
    digest.update(str(value.shape).encode("ascii"))
    digest.update(value.tobytes())
    return digest.hexdigest()


def frozen_predictor_identity(bundle):
    """Identity of retained numeric predictor and applicability, not old files."""
    return {
        "configuration_id": bundle["configuration_id"],
        "array_sha256": {name: _array_digest(bundle[name]) for name in _BUNDLE_ARRAYS},
        "train_support_sha256": {
            group_id: {name: _array_digest(group[name]) for name in _TRAIN_ARRAYS}
            for group_id, group in bundle["groups"].items()
        },
        "distance_thresholds": {key: float(group["distance_threshold"]) for key, group in bundle["groups"].items()},
    }


def _new_group(bundle, source_group, entries):
    # Frozen TRAIN rows and all applicability thresholds are copied verbatim.
    group = deepcopy(source_group)
    finite = []
    missing = []
    for entry in entries:
        feature = frozen._finite_input(entry)
        (finite if feature is not None else missing).append(entry)
    size = len(bundle["feature_indices"])
    cal_z = np.asarray([(frozen._input_features(entry)[bundle["feature_indices"]] - bundle["mean"]) / bundle["scale"]
                        for entry in finite], dtype=float).reshape(-1, size)
    snapshots = sorted({frozen._identity(entry, "source_snapshot") for entry in finite})
    episodes = sorted({frozen._identity(entry, "episode") for entry in finite})
    snapshot_index = {value: index for index, value in enumerate(snapshots)}
    episode_index = {value: index for index, value in enumerate(episodes)}
    residuals = np.full((len(finite), 6), np.nan)
    complete = np.zeros(len(finite), dtype=bool)
    physical = np.zeros(len(finite), dtype=bool)
    terminal = np.zeros(len(finite), dtype=bool)
    for index, entry in enumerate(finite):
        target = frozen._complete_target(entry)
        try:
            d_lower, available, _physical_prefix = _lower_bound(entry)
        except (KeyError, TypeError, ValueError, IndexError, AttributeError):
            continue
        if target is None or not available or not bundle["trained"]:
            continue
        # Complete observed physical/terminal failures still supply residuals.
        raw = frozen._design(cal_z[index], bundle["powers"]) @ bundle["coefficient"].T + bundle["intercept"]
        estimate = frozen._project(raw, d_lower)
        residuals[index] = np.r_[target[0] - estimate[0], np.abs(target[1:] - estimate[1:])]
        complete[index] = True
        physical[index] = frozen._physical(entry.get("labels", {}))
        terminal[index] = bool(entry.get("labels", {}).get("terminal_pass", entry.get("labels", {}).get("original_terminal", False)))
    complete_records = [entry for entry, valid in zip(finite, complete) if valid]
    complete_snapshots = {frozen._identity(entry, "source_snapshot") for entry in complete_records}
    complete_episodes = {frozen._identity(entry, "episode") for entry in complete_records}
    eligible = bool(bundle["trained"] and len(complete_snapshots) >= MIN_CAL_SNAPSHOTS
                    and len(complete_episodes) >= MIN_CAL_EPISODES)
    cal_margin = np.zeros(6)
    if complete.any():
        cal_margin = np.max(residuals[complete], axis=0)
        cal_margin[0] = max(0., float(cal_margin[0]))
    group.update(
        cal_z=cal_z, cal_norm2=np.sum(cal_z * cal_z, axis=1),
        cal_ids=np.asarray([entry["id"] for entry in finite], dtype=str),
        cal_snapshot_ids=np.asarray([frozen._identity(entry, "source_snapshot") for entry in finite], dtype=str),
        cal_episode_ids=np.asarray([frozen._identity(entry, "episode") for entry in finite], dtype=str),
        cal_snapshot_index=np.asarray([snapshot_index[frozen._identity(entry, "source_snapshot")] for entry in finite], dtype=np.int64),
        cal_episode_index=np.asarray([episode_index[frozen._identity(entry, "episode")] for entry in finite], dtype=np.int64),
        cal_complete=complete, cal_complete_physical=physical, cal_complete_terminal=terminal,
        cal_residual=residuals, cal_margin=cal_margin,
        calibrated=eligible, local_calibrated=eligible, global_calibrated=False,
        cal_finite_ids=[entry["id"] for entry in finite], cal_finite_count=len(finite),
        cal_complete_ids=[entry["id"] for entry in complete_records], cal_complete_count=len(complete_records),
        cal_missing_input_ids=[entry["id"] for entry in missing], cal_missing_input_count=len(missing),
        cal_planned_ids=[entry["id"] for entry in entries], cal_planned_count=len(entries),
        cal_distinct_source_snapshots=len(complete_snapshots), cal_episode_count=len(complete_episodes),
        cal_source_snapshots=sorted(complete_snapshots), cal_episodes=sorted(complete_episodes),
        cal_failed_physical_count=int(np.sum(complete & ~physical)),
        cal_failed_terminal_count=int(np.sum(complete & ~terminal)),
        cal_incomplete_ids=[entry["id"] for entry, valid in zip(finite, complete) if not valid],
        distance_threshold_source="UNCHANGED_STEP30_GROUP",
    )
    return group


def build_delay_calibration(frozen_bundle, dev_records, method):
    """Build one method-matched DELAY_CAL object; no fit and no TEST reads."""
    method = _method(method)
    if frozen_bundle.get("configuration_id") != MAIN or len(frozen_bundle.get("mean", ())) != 26:
        raise ValueError("unchanged GEOMETRY_FULL_26 predictor required")
    records = list(dev_records)
    if any(entry.get("split") != "DEV" for entry in records):
        raise ValueError("delay calibration accepts new DEV only, never TEST or old TRAIN/CAL")
    if any(entry.get("method", method) != method for entry in records):
        raise ValueError("method-matched delay trajectory records required")
    if len({entry["id"] for entry in records}) != len(records):
        raise ValueError("duplicate delay-calibration action identity")
    for entry in records:
        gamma_key(entry["gamma"]); frozen._role(entry)
        for field in ("episode", "source_snapshot"):
            frozen._identity(entry, field)
        if entry.get("target_horizon_origin", "SAMPLE") != "SAMPLE" or float(entry.get("target_horizon_s", 1.)) != 1.:
            raise ValueError("delay residual target must be original sample t=1 s")
    source_identity = frozen_predictor_identity(frozen_bundle)
    bundle = {name: deepcopy(value) for name, value in frozen_bundle.items() if name not in ("groups", "_resident")}
    bundle.update(schema=VERSION, delay_method=method, calibration_id=VERSION + ":" + method,
                  source_model_schema=frozen_bundle.get("schema"), source_predictor_identity=source_identity,
                  actual_multioutput_estimator_fit_calls=0, new_regression_model_fits=0,
                  original_sample_horizon_s=1., application_delay_s=.020,
                  target_horizon_origin="SAMPLE", calibration="LOCAL", new_TEST_consumed=False,
                  cal_ids_all=[entry["id"] for entry in records],
                  delay_dev_registry=[{"id": entry["id"], "split": "DEV", "method": method,
                                       "gamma": float(entry["gamma"]), "role": frozen._role(entry),
                                       "episode": entry["episode"], "source_snapshot": entry["source_snapshot"]}
                                      for entry in records],
                  local_cal_rule={"snapshots": MIN_CAL_SNAPSHOTS, "minimum_episodes": MIN_CAL_EPISODES,
                                  "ranking": "same stable ascending standardized feature distance and distinct snapshot rule as STEP30",
                                  "incomplete_finite_rows_retained": True, "selected_incomplete_rejects": True,
                                  "missing_feature_group_rejects": False, "complete_failures_excluded": False,
                                  "probability_coverage_claim": False})
    bundle["groups"] = {
        key: _new_group(bundle, group, [entry for entry in records if group_key(MAIN, entry["gamma"], frozen._role(entry)) == key])
        for key, group in frozen_bundle["groups"].items()
    }
    if frozen_predictor_identity(bundle) != source_identity:
        raise ValueError("delay calibration altered the frozen predictor/applicability")
    return frozen._prepare_resident(bundle)


def static_group_eligible(bundle, gamma, role, calibration="LOCAL"):
    _local(calibration)
    group = bundle["groups"][group_key(MAIN, gamma, role)]
    return bool(bundle["trained"] and group["local_calibrated"])


def calibrated_gamma_mask(bundle, role, calibration="LOCAL"):
    return np.asarray([static_group_eligible(bundle, gamma, role, calibration) for gamma in GAMMA_GRID], dtype=bool)


def calibrated_gammas(bundle, role, allowed=GAMMA_GRID, calibration="LOCAL"):
    allowed_values = {float(gamma) for gamma in allowed}
    for gamma in allowed_values:
        gamma_key(gamma)
    return tuple(gamma for gamma, eligible in zip(GAMMA_GRID, calibrated_gamma_mask(bundle, role, calibration))
                 if gamma in allowed_values and eligible)


def batch_numeric(bundle, features26, gammas, roles, prefix_d, calibration="LOCAL", out=None, prehold_d=None):
    """Same resident numeric contract; caller supplies original-anchor D bound.

    The caller must independently require prehold and action-prefix physical
    validity.  Optional prehold_d combines the two lower bounds in this API.
    """
    _local(calibration)
    lower = np.asarray(prefix_d, dtype=float)
    if prehold_d is not None:
        before = np.asarray(prehold_d, dtype=float)
        if before.shape != lower.shape:
            raise ValueError("prehold and prefix D batch shapes must agree")
        lower = np.maximum(lower, before)
        lower[(~np.isfinite(before)) | (before < 0.)] = np.nan
    result = frozen.batch_numeric(bundle, features26, gammas, roles, lower, calibration="LOCAL", out=out)
    for row in np.flatnonzero(result["calibration_gate"]):
        key = bundle["_resident"]["group_keys"][int(result["group_index"][row])]
        group = bundle["groups"][key]
        local = result["local_cal_indices"][row]
        if np.any(local < 0) or not np.all(group["cal_complete"][local]) or not np.isfinite(group["cal_residual"][local]).all():
            result["calibration_gate"][row] = False
            result["U_D"][row] = np.nan
            result["U_T"][row] = np.nan
    return result


def predict(bundle, actions_inputs, calibration="LOCAL"):
    """Saved diagnostic expansion of the same numeric lookup, without ACTUAL."""
    _local(calibration)
    if isinstance(actions_inputs, dict) and "gamma" in actions_inputs:
        actions_inputs = {gamma_key(actions_inputs["gamma"]): actions_inputs}
    entries = frozen._action_entries(actions_inputs)
    points = {key: frozen._empty_prediction(float(key)) for key in entries}
    valid_keys, feature_rows, d_rows = [], [], []
    for key, entry in entries.items():
        point = points[key]
        point.update(calibration="LOCAL", delay_method=bundle["delay_method"], prehold_physical_gate=False,
                     prehold_available_gate=False, local_cal_complete=[], D_prehold_m=None)
        try:
            feature = frozen._input_features(entry)
            role = frozen._role(entry)
            d_lower, available, physical = _lower_bound(entry)
            prehold_d, prehold_complete, prehold_physical = _prehold(entry)
            group_id = group_key(MAIN, entry["gamma"], role)
            group = bundle["groups"][group_id]
            point.update(group=group_id, fault_role=role, current_command_gate=bool(entry.get("first_command_valid", False)),
                         prefix_available_gate=available, prefix_physical_gate=physical, D_prefix_m=d_lower,
                         D_prehold_m=prehold_d, prehold_available_gate=prehold_complete, prehold_physical_gate=prehold_physical,
                         cal_complete_count=group["cal_complete_count"], cal_distinct_source_snapshots=group["cal_distinct_source_snapshots"],
                         cal_episode_count=group["cal_episode_count"], pose_value_rad=feature[[2, 3]].tolist(),
                         pose_interval_rad={"names": ["roll_rad", "direction_pitch_rad"], "min": bundle["pose_min"].tolist(), "max": bundle["pose_max"].tolist()})
            valid_keys.append(key); feature_rows.append(feature); d_rows.append(d_lower)
        except (KeyError, TypeError, ValueError, IndexError, AttributeError) as exc:
            point["input_error"] = str(exc)
            point["reasons"].append("MISSING_OR_NONFINITE_CURRENT_PREFIX_PREHOLD_INPUT")
    if valid_keys:
        numeric = batch_numeric(bundle, np.asarray(feature_rows), [entries[key]["gamma"] for key in valid_keys],
                                [frozen._role(entries[key]) for key in valid_keys], d_rows)
        for row, key in enumerate(valid_keys):
            point = points[key]; group = bundle["groups"][point["group"]]
            for name in ("pose_gate", "support_gate", "distance_gate", "calibration_gate"):
                point[name] = bool(numeric[name][row])
            for name in ("D_hat", "U_D", "nearest_distance", "distance_threshold"):
                value = numeric[name][row]; point[name] = float(value) if np.isfinite(value) else None
            for name in ("Y_hat", "U_T"):
                value = numeric[name][row]; point[name] = value.tolist() if np.isfinite(value).all() else None
            neighbors = numeric["neighbor_indices"][row]; neighbors = neighbors[neighbors >= 0]
            local = numeric["local_cal_indices"][row]; local = local[local >= 0]
            point.update(neighbor_ids=group["train_ids"][neighbors].tolist(),
                         neighbor_distances=numeric["neighbor_distances"][row, :len(neighbors)].tolist(),
                         neighbor_complete=group["train_complete"][neighbors].tolist(),
                         neighbor_original_physical=group["train_physical"][neighbors].tolist(),
                         neighbor_numeric_indices=neighbors.tolist(),
                         local_cal_ids=group["cal_ids"][local].tolist(),
                         local_cal_distances=numeric["local_cal_distances"][row, :len(local)].tolist(),
                         local_cal_source_snapshots=group["cal_snapshot_ids"][local].tolist(),
                         local_cal_episodes=group["cal_episode_ids"][local].tolist(),
                         local_cal_original_physical=group["cal_complete_physical"][local].tolist(),
                         local_cal_terminal_pass=group["cal_complete_terminal"][local].tolist(),
                         local_cal_complete=group["cal_complete"][local].tolist(), local_cal_numeric_indices=local.tolist())
    for point in points.values():
        for gate, reason in (("pose_gate", "OUTSIDE_FROZEN_POSE_DOMAIN"),
                             ("support_gate", "TRAIN_SUPPORT_REJECT"),
                             ("distance_gate", "OUTSIDE_FROZEN_TRAIN_DISTANCE"),
                             ("calibration_gate", "INCOMPLETE_OR_INSUFFICIENT_LOCAL_DELAY_CAL"),
                             ("current_command_gate", "FIRST_COMMAND_UNAVAILABLE"),
                             ("prefix_available_gate", "PREFIX_OR_PREHOLD_UNAVAILABLE"),
                             ("prefix_physical_gate", "PREFIX_OR_PREHOLD_ORIGINAL_PHYSICAL_FAILURE")):
            if not point[gate]:
                point["reasons"].append(reason)
        if point["local_cal_complete"] and not all(point["local_cal_complete"]):
            point["reasons"].append("NEAREST_DELAY_CAL_NUMERICAL_INCOMPLETE")
    return points


def decide(bundle, actions_inputs, gap, allowed=GAMMA_GRID, calibration="LOCAL"):
    _local(calibration)
    if not np.isfinite(gap) or gap < 0.:
        raise ValueError("finite nonnegative local gap metres required")
    ordered = tuple(sorted({float(gamma) for gamma in allowed}, reverse=True))
    for gamma in ordered:
        gamma_key(gamma)
    points = predict(bundle, actions_inputs)
    gates = ("support_gate", "distance_gate", "calibration_gate", "pose_gate", "current_command_gate",
             "prefix_available_gate", "prefix_physical_gate", "prehold_available_gate", "prehold_physical_gate", "terminal_gate", "local_gate")
    for key, point in points.items():
        point["terminal_gate"] = bool(point["U_T"] is not None and np.all(np.asarray(point["U_T"]) <= 1.))
        point["local_gate"] = bool(point["U_D"] is not None and point["U_D"] <= gap)
        if not point["terminal_gate"]:
            point["reasons"].append("TERMINAL_RATIO_REJECT")
        if not point["local_gate"]:
            point["reasons"].append("LOCAL_DISPLACEMENT_MARGIN_REJECT")
        point["accepted"] = bool(float(key) in ordered and all(point[gate] for gate in gates))
    choice = next((gamma for gamma in ordered if gamma_key(gamma) in points and points[gamma_key(gamma)]["accepted"]), "ABSTAIN")
    return {"choice": choice, "gamma": None if choice == "ABSTAIN" else choice, "accepted": choice != "ABSTAIN",
            "gap_m": float(gap), "allowed": list(ordered), "predictions": points,
            "configuration_id": MAIN, "calibration": "LOCAL", "delay_method": bundle["delay_method"],
            "calibration_id": bundle["calibration_id"], "reject_reasons": [] if choice != "ABSTAIN" else list(dict.fromkeys(
                reason for point in points.values() for reason in point["reasons"]))}


def save_delay_calibration(bundle, directory):
    """Write a distinct STEP33 asset, refusing overwrite of any prior object."""
    method = _method(bundle.get("delay_method"))
    if bundle.get("schema") != VERSION or frozen_predictor_identity(bundle) != bundle["source_predictor_identity"]:
        raise ValueError("unaltered predictor and STEP33 calibration identity required")
    directory = Path(directory); directory.mkdir(parents=True, exist_ok=True)
    path = directory / ("step33_delay_cal_" + method.lower() + ".npz")
    metadata_path = path.with_suffix(".json")
    if path.exists() or metadata_path.exists():
        raise FileExistsError("delay calibration objects cannot be overwritten")
    arrays = {name: bundle[name] for name in _BUNDLE_ARRAYS}
    metadata = {name: value for name, value in bundle.items() if name not in _BUNDLE_ARRAYS and name != "groups" and not name.startswith("_")}
    metadata["groups"] = {}
    for index, (key, group) in enumerate(bundle["groups"].items()):
        prefix = "group" + str(index) + "_"
        arrays.update({prefix + name: group[name] for name in _GROUP_ARRAYS})
        metadata["groups"][key] = {name: value for name, value in group.items() if name not in _GROUP_ARRAYS}
        metadata["groups"][key]["array_prefix"] = prefix
    with path.open("xb") as stream:
        np.savez_compressed(stream, **arrays)
    with metadata_path.open("x", encoding="utf-8") as stream:
        json.dump(metadata, stream, sort_keys=True, indent=2, allow_nan=False)
    return {"npz": str(path.resolve()), "json": str(metadata_path.resolve()),
            "npz_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "json_sha256": hashlib.sha256(metadata_path.read_bytes()).hexdigest(),
            "method": method, "calibration_id": bundle["calibration_id"], "new_regression_model_fits": 0}


def load_delay_calibration(path):
    path = Path(path)
    metadata = json.loads(path.with_suffix(".json").read_text(encoding="utf-8"))
    if metadata.get("schema") != VERSION or metadata.get("configuration_id") != MAIN:
        raise ValueError("unsupported STEP33 delay calibration schema/configuration")
    _method(metadata.get("delay_method"))
    with np.load(path, allow_pickle=False) as archive:
        bundle = dict(metadata); bundle.update({name: archive[name].copy() for name in _BUNDLE_ARRAYS})
        bundle["groups"] = {}
        for key, group_metadata in metadata["groups"].items():
            group = dict(group_metadata); prefix = group.pop("array_prefix")
            group.update({name: archive[prefix + name].copy() for name in _GROUP_ARRAYS})
            bundle["groups"][key] = group
    if frozen_predictor_identity(bundle) != bundle["source_predictor_identity"]:
        raise ValueError("delay object changed frozen predictor/applicability")
    return frozen._prepare_resident(bundle)


# Explicit aliases keep runner code concise without exposing any fitting path.
save_bundle = save_delay_calibration
load_bundle = load_delay_calibration
