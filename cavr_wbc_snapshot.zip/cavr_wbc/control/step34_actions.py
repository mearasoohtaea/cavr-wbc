"""Checked affine combinations of current STEP34 feasible candidates.

Convexity proposition: for the same affine row a, bounds l/u and fixed
nonnegative tolerance epsilon, the set l-epsilon <= a*z <= u+epsilon is
convex.  If both current witnesses satisfy every such row, their Gamma convex
combination satisfies the same finite-tolerance rows.  The original inequality
epsilon is zero.  A clipped torque is a changed witness and is independently
rechecked.  This proposition concerns only these current frozen affine rows;
it gives no claim about future nonlinear MuJoCo states, invariance or optimality.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from cavr_wbc.control import step29_actions as frozen
from cavr_wbc.control.step34_candidate import VERSION as CANDIDATE_VERSION, capacity_interface, check_candidate

VERSION = 'STEP34_CHECKED_CURRENT_CANDIDATE_ACTIONS_V1'
GAMMA_GRID = frozen.GAMMA_GRID
SYNTHESIZED_KIND = frozen.SYNTHESIZED_KIND
check_rows = frozen.check_rows
capture_matrices = frozen.capture_matrices
frozen_contract = frozen.frozen_contract


def raw_result(endpoint):
    return endpoint.get('raw_solver_result', endpoint.get('wbc', {})) or {}


def _status(endpoint):
    result = raw_result(endpoint)
    known = [v for v in (endpoint.get('solver_status_val'), result.get('status_val'),
        endpoint.get('capacity_interface', {}).get('solver_status_val')) if v is not None]
    return known[0] if known and all(v == known[0] and not isinstance(v, (bool, np.bool_)) for v in known) else None


def _valid(endpoint):
    proof = raw_result(endpoint).get('candidate_certificate') or {}
    return bool(proof.get('schema') == CANDIDATE_VERSION and proof.get('candidate_valid') and
        proof.get('raw_optimizer_status') == _status(endpoint) and
        endpoint.get('command_valid', endpoint.get('valid_command', False)))


@dataclass
class SharedActions:
    context: dict
    endpoints: dict
    matrices: dict
    status: dict
    zC: object = None
    zB: object = None
    refC: object = None
    refB: object = None
    reason: object = None
    shared_identity_checks: int = 1


def prepare_shared(context, C, B, matrices=None):
    endpoints = {'C': C or {}, 'B': B or {}}
    mats = matrices or {name: ep.get('source_matrices', raw_result(ep).get('source_matrices')) for name, ep in endpoints.items()}
    if 'A' in mats:
        mats = {'C': mats, 'B': mats}
    statuses = {name: _status(ep) for name, ep in endpoints.items()}
    ws = SharedActions(context, endpoints, mats, statuses)
    if not all(_valid(ep) for ep in endpoints.values()):
        ws.reason = 'BOTH_CURRENT_FEASIBLE_CANDIDATES_REQUIRED'
        return ws
    same, reason = frozen.shared_matrices(mats.get('C'), mats.get('B'))
    if not same:
        ws.reason = reason
        return ws
    state = context.get('state', context.get('source_state', context))
    m = mats['C']
    if (m['context_id'] != str(context['context_id']) or not np.array_equal(m['health_vector'], context['health_vector']) or
        any(not np.array_equal(m[name], state[name]) for name in ('qpos', 'qvel', 'integration_state'))):
        ws.reason = 'CURRENT_STATE_HEALTH_IDENTITY_MISMATCH'
        return ws
    ws.zC = raw_result(endpoints['C'])['candidate_certificate']['raw_full_primal']
    ws.zB = raw_result(endpoints['B'])['candidate_certificate']['raw_full_primal']
    ws.refC = frozen._reference(endpoints['C'])
    ws.refB = frozen._reference(endpoints['B'])
    return ws


def _missing(gamma, reason, statuses):
    return {'schema': VERSION, 'gamma': gamma,
        'kind': SYNTHESIZED_KIND if 0. < gamma < 1. else 'C_ENDPOINT' if gamma == 1. else 'B_ENDPOINT',
        'command_valid': False, 'execution_eligible': False, 'available': False,
        'features_available': False, 'source_solver_statuses': statuses,
        'solver_status_val': None, 'unavailable_reason': reason,
        'new_QP_calls': 0, 'new_solver_called': False, 'optimality_claim': False}


def make_action(context, C, B, gamma, matrices=None, workspace=None):
    gamma = float(gamma)
    if gamma not in GAMMA_GRID:
        raise ValueError('STEP34 Gamma outside original fixed five-action grid')
    endpoints = {'C': C or {}, 'B': B or {}}
    statuses = {name: _status(ep) for name, ep in endpoints.items()}
    if gamma in (1., 0.):
        name = 'C' if gamma == 1. else 'B'
        ep = endpoints[name]
        if not _valid(ep):
            return _missing(gamma, 'CURRENT_FEASIBLE_ENDPOINT_UNAVAILABLE', statuses)
        raw = raw_result(ep)
        proof = raw['candidate_certificate']
        matrix = ep.get('source_matrices', raw.get('source_matrices'))
        # Recheck same full current raw; stale caches are not a candidate source.
        proof = check_candidate({'status_val': statuses[name], 'x': proof['raw_full_primal']}, matrix, context)
        if not proof['candidate_valid']:
            return _missing(gamma, proof['rejection_reason'], statuses)
        interface = capacity_interface({'status_val': statuses[name], 'candidate_certificate': proof},
            context['health_vector'], matrix['healthy_torque_limits_nm'])
        z, sent_z = proof['raw_full_primal'], proof['sent_full_primal']
        ref = frozen._reference(ep)
        return {'schema': VERSION, 'gamma': gamma, 'kind': name + '_ENDPOINT',
            'source_endpoint': name, 'source_endpoint_record': ep,
            'command_valid': True, 'available': True, 'execution_eligible': True,
            'features_available': ref is not None, 'solver_status_val': statuses[name],
            'optimizer_converged': proof['optimizer_converged'], 'strict_candidate_mask': proof['strict_candidate_mask'],
            'source_solver_statuses': statuses, 'candidate_schema': CANDIDATE_VERSION,
            'candidate_certificate': proof, 'tau_raw': proof['tau_raw'], 'tau_sent': proof['tau_sent'],
            'z_raw': z, 'z_sent': sent_z, 'qdd': z[:matrix['nv']],
            'contact_lambda': z[matrix['nv'] + matrix['nu']:], 'a_base_ref': ref,
            'health_vector': interface['health_vector'], 'capacity_interface': interface,
            'raw_hard_check': proof['raw_hard_check'], 'sent_hard_check': proof['sent_hard_check'],
            'hard_validation_pass': True, 'source_matrices': matrix,
            'integral_record': ep.get('integral_record', ep.get('response', {}).get('integral_record')),
            'first_capacity_event': bool(len(interface['sent_99_percent_active_indices'])),
            'new_QP_calls': 0, 'new_solver_called': False, 'optimality_claim': False}
    ws = workspace if workspace is not None else prepare_shared(context, C, B, matrices)
    if ws.reason:
        return _missing(gamma, ws.reason, statuses)
    matrix = ws.matrices['C']
    nv, nu = matrix['nv'], matrix['nu']
    z = gamma * ws.zC + (1. - gamma) * ws.zB
    raw = z[nv:nv + nu].copy()
    health, limits = matrix['health_vector'], matrix['healthy_torque_limits_nm']
    capacity = health * limits
    sent = np.clip(raw, -capacity, capacity)
    sent_z = z.copy()
    sent_z[nv:nv + nu] = sent
    raw_check, sent_check = check_rows(matrix, z), check_rows(matrix, sent_z)
    valid = bool(raw_check['pass'] and sent_check['pass'] and np.all(np.abs(raw) <= capacity))
    active = np.flatnonzero((capacity <= 0.) | (np.abs(sent) >= .99 * capacity))
    proof = {'schema': CANDIDATE_VERSION, 'candidate_valid': valid,
        'status': 'CURRENT_CONTRACT_FEASIBLE_SYNTHESIZED_COMMAND' if valid else 'CURRENT_CONTRACT_CANDIDATE_REJECTED',
        'raw_optimizer_status': None, 'source_solver_statuses': statuses,
        'optimizer_converged': False, 'strict_candidate_mask': valid and all(v == 1 for v in statuses.values()),
        'current_state_health_identity': True, 'shared_A_l_u_exact': True,
        'raw_hard_check': raw_check, 'sent_hard_check': sent_check,
        'raw_full_primal': z, 'sent_full_primal': sent_z, 'new_QP_calls': 0}
    interface = {'version': CANDIDATE_VERSION, 'candidate_schema': CANDIDATE_VERSION,
        'candidate_valid': valid, 'candidate_certificate': proof, 'command_valid': valid,
        'solver_status_val': None, 'solver_exact_solved': False,
        'source_solver_statuses': statuses, 'health_vector': health, 'healthy_torque_limits_nm': limits,
        'effective_capacity_nm': capacity, 'tau_raw': raw, 'tau_sent': sent,
        'saturation_mask': sent != raw, 'correction_nm': sent - raw,
        'raw_command_within_capacity_exact': bool(np.all(np.abs(raw) <= capacity)),
        'sent_command_within_capacity_exact': bool(np.all(np.abs(sent) <= capacity)),
        'sent_99_percent_active_indices': active, 'raw_99_percent_active_indices': active}
    ref = gamma * ws.refC + (1. - gamma) * ws.refB if ws.refC is not None and ws.refB is not None else None
    return {'schema': VERSION, 'gamma': gamma, 'kind': SYNTHESIZED_KIND,
        'command_valid': valid, 'execution_eligible': valid, 'available': valid,
        'features_available': ref is not None, 'solver_status_val': None,
        'source_solver_statuses': statuses, 'candidate_schema': CANDIDATE_VERSION,
        'candidate_certificate': proof, 'strict_candidate_mask': proof['strict_candidate_mask'],
        'source_primal_variables': {'C': ws.zC, 'B': ws.zB}, 'z_raw': z, 'z_sent': sent_z,
        'qdd': z[:nv].copy(), 'contact_lambda': z[nv + nu:].copy(), 'tau_raw': raw, 'tau_sent': sent,
        'health_vector': health, 'capacity_interface': interface, 'raw_hard_check': raw_check,
        'sent_hard_check': sent_check, 'a_base_ref': ref, 'source_matrices': matrix,
        'shared_A_l_u_exact': True, 'hard_validation_pass': valid,
        'first_capacity_event': bool(len(active)), 'backup_initial_b': np.zeros(6),
        'integral_record': None, 'new_QP_calls': 0, 'new_solver_called': False,
        'optimality_claim': False, 'synthetic_is_optimizer_return': False,
        'unavailable_reason': None if valid else 'RAW_OR_SENT_ORIGINAL_HARD_ROW_REJECTED'}
