"""Current affine-contract feasible candidates, independent of convergence.

No status is promoted to Solved.  Every command uses only this invocation's
full primal and coefficients.  All SI tolerances are the frozen original rows.
"""
from __future__ import annotations

from copy import deepcopy
from time import perf_counter
import mujoco
import numpy as np

from cavr_wbc.control.step33_kernel import OnlineWBC, SOLVER_EVIDENCE_FIELDS
from cavr_wbc.control.step29_actions import capture_matrices, check_rows
from cavr_wbc.control.step22_pose_servo import AUTHORITY_GATE_FRACTION

VERSION = 'STEP34_CURRENT_AFFINE_FEASIBLE_CANDIDATE_V1'
ELIGIBLE_RAW_STATUSES = (1, 2, 7, 8)


def integration_state(model, data):
    signature = int(mujoco.mjtState.mjSTATE_INTEGRATION)
    vector = np.empty(int(mujoco.mj_stateSize(model, signature)))
    mujoco.mj_getState(model, data, vector, signature)
    return {'integration_state_signature': signature, 'integration_state': vector,
            'qpos': data.qpos.copy(), 'qvel': data.qvel.copy(), 'ctrl': data.ctrl.copy()}


def status_eligible(status):
    return bool(not isinstance(status, (bool, np.bool_)) and status in ELIGIBLE_RAW_STATUSES)


def check_candidate(raw, matrix, context):
    """Check the same-call current raw and clipped full affine witness."""
    begin = perf_counter()
    status = raw.get('status_val')
    certificate = {'schema': VERSION, 'status': 'CURRENT_CONTRACT_CANDIDATE_REJECTED',
        'candidate_valid': False, 'raw_optimizer_status': status,
        'optimizer_converged': bool(status == 1 and not isinstance(status, (bool, np.bool_))),
        'eligible_raw_status': status_eligible(status), 'raw_status_preserved': True,
        'strict_candidate_mask': False, 'new_QP_calls': 0,
        'inequality_extra_slack': 0., 'raw_full_primal': None, 'sent_full_primal': None,
        'raw_hard_check': None, 'sent_hard_check': None,
        'current_state_health_identity': False, 'rejection_reason': None}
    reason = None
    if not status_eligible(status):
        reason = 'RAW_STATUS_NOT_ELIGIBLE'
    state = context.get('state', context.get('source_state', context))
    identity = bool(matrix.get('context_id') == str(context['context_id']) and
        np.array_equal(matrix.get('health_vector'), context['health_vector']) and
        all(np.array_equal(matrix.get(name), state.get(name)) for name in ('qpos', 'qvel', 'integration_state')))
    certificate['current_state_health_identity'] = identity
    if not identity:
        reason = reason or 'CURRENT_STATE_HEALTH_IDENTITY_MISMATCH'
    nv, nu, nc = int(matrix['nv']), int(matrix['nu']), int(matrix['nc'])
    x = raw.get('x')
    try:
        z = np.asarray(x, dtype=float)
        full = bool(z.shape == (nv + nu + nc,) and np.isfinite(z).all())
    except (ValueError, TypeError):
        full = False
        z = None
    certificate['raw_finite_shape_correct_full_primal'] = full
    if not full:
        reason = reason or 'CURRENT_RAW_FULL_PRIMAL_UNAVAILABLE'
    # Refuse accidental altered contracts; inequalities have no numerical slack.
    A, l, u = matrix['A'], matrix['l'], matrix['u']
    tolerance = np.asarray(matrix['row_abs_tolerance'])
    contract_shape = bool(A.shape == (len(l), nv + nu + nc) and np.shape(u) == np.shape(l)
        and tolerance.shape == np.shape(l) and np.isfinite(A).all()
        and not np.isnan(l).any() and not np.isnan(u).any()
        and np.isfinite(tolerance).all() and np.all(tolerance >= 0.)
        and matrix.get('inequality_extra_slack') == 0.
        and np.all(tolerance[nv + nc:] == 0.) and np.array_equal(l[:nv + nc], u[:nv + nc]))
    certificate['unchanged_row_contract_shape'] = contract_shape
    if not contract_shape:
        reason = reason or 'ORIGINAL_ROW_CONTRACT_MALFORMED'
    health = np.asarray(context['health_vector'], dtype=float)
    limits = np.asarray(matrix['healthy_torque_limits_nm'], dtype=float)
    capacity = health * limits
    capacity_valid = bool(health.shape == limits.shape == (nu,) and np.isfinite(capacity).all()
        and np.all((health >= 0.) & (health <= 1.)) and np.all(limits > 0.))
    if not capacity_valid:
        reason = reason or 'CURRENT_CAPACITY_IDENTITY_MALFORMED'
    if full and contract_shape and capacity_valid:
        raw_tau = z[nv:nv + nu].copy()
        sent_tau = np.clip(raw_tau, -capacity, capacity)
        sent_z = z.copy()
        sent_z[nv:nv + nu] = sent_tau
        raw_check = check_rows(matrix, z)
        sent_check = check_rows(matrix, sent_z)
        raw_capacity = bool(np.all(np.abs(raw_tau) <= capacity))
        sent_capacity = bool(np.all(np.abs(sent_tau) <= capacity))
        certificate.update(raw_full_primal=z.copy(), sent_full_primal=sent_z,
            raw_hard_check=raw_check, sent_hard_check=sent_check,
            tau_raw=raw_tau, tau_sent=sent_tau,
            raw_capacity_exact_pass=raw_capacity, sent_capacity_exact_pass=sent_capacity,
            health_vector=health.copy(), healthy_torque_limits_nm=limits.copy(),
            effective_capacity_nm=capacity, source_matrix_identity={
                name: deepcopy(matrix.get(name)) for name in ('context_id', 'qpos', 'qvel',
                    'integration_state', 'health_vector', 'acceptance_version', 'acceptance_sha256')})
        if not raw_check['pass'] or not sent_check['pass'] or not raw_capacity or not sent_capacity:
            reason = reason or 'RAW_OR_SENT_ORIGINAL_HARD_ROW_REJECTED'
    valid = bool(reason is None)
    certificate.update(candidate_valid=valid, strict_candidate_mask=valid and certificate['optimizer_converged'],
        status='CURRENT_CONTRACT_FEASIBLE_CANDIDATE' if valid else 'CURRENT_CONTRACT_CANDIDATE_REJECTED',
        rejection_reason=reason, check_ms=(perf_counter() - begin) * 1000.)
    return certificate


def capacity_interface(raw, health, healthy_limits):
    """New schema consumes candidate proof, retaining the optimizer status."""
    begin = perf_counter()
    proof = raw.get('candidate_certificate') or {}
    h, limits = np.asarray(health, dtype=float), np.asarray(healthy_limits, dtype=float)
    valid = bool(proof.get('schema') == VERSION and proof.get('candidate_valid') and
        proof.get('raw_optimizer_status') == raw.get('status_val') and
        np.array_equal(proof.get('health_vector'), h) and
        np.array_equal(proof.get('healthy_torque_limits_nm'), limits))
    capacity = h * limits
    tau_raw = proof.get('tau_raw')
    sent = np.asarray(proof['tau_sent']).copy() if valid else None
    raw_tau = np.asarray(tau_raw).copy() if tau_raw is not None else None
    margin = capacity - np.abs(raw_tau) if raw_tau is not None else None
    raw_active = np.flatnonzero((capacity <= 0.) | (np.abs(raw_tau) >= AUTHORITY_GATE_FRACTION * capacity)) if valid else np.empty(0, dtype=int)
    active = np.flatnonzero((capacity <= 0.) | (np.abs(sent) >= AUTHORITY_GATE_FRACTION * capacity)) if valid else np.empty(0, dtype=int)
    return {'version': VERSION, 'candidate_schema': VERSION, 'candidate_valid': valid,
        'candidate_certificate': proof, 'command_valid': valid, 'solver_status_val': raw.get('status_val'),
        'solver_exact_solved': proof.get('optimizer_converged', False),
        'optimizer_converged': proof.get('optimizer_converged', False),
        'strict_candidate_mask': proof.get('strict_candidate_mask', False),
        'health_vector': h.copy(), 'healthy_torque_limits_nm': limits.copy(),
        'effective_capacity_nm': capacity, 'tau_raw': raw_tau, 'tau_sent': sent,
        'raw_tau_finite_correct_shape': bool(raw_tau is not None and raw_tau.shape == capacity.shape and np.isfinite(raw_tau).all()),
        'raw_command_bound_margin_nm': margin,
        'raw_command_bound_violation_nm': np.maximum(-margin, 0.) if margin is not None else None,
        'raw_command_within_capacity_exact': bool(margin is not None and np.all(margin >= 0.)),
        'sent_command_bound_margin_nm': capacity - np.abs(sent) if valid else None,
        'sent_command_within_capacity_exact': bool(valid and np.all(np.abs(sent) <= capacity)),
        'saturation_mask': sent != raw_tau if valid else np.zeros_like(capacity, dtype=bool),
        'saturated_actuator_indices': np.flatnonzero(sent != raw_tau) if valid else np.empty(0, dtype=int),
        'correction_nm': sent - raw_tau if valid else None,
        'raw_99_percent_active_indices': raw_active, 'sent_99_percent_active_indices': active,
        'raw_sent_99_percent_gate_equal': bool(np.array_equal(raw_active, active)) if valid else None,
        'invalid_reason': None if valid else proof.get('rejection_reason', 'CURRENT_CANDIDATE_EVIDENCE_MISSING'),
        'invalid_tau_is_not_a_command': not valid, 'raw_solution_and_validation_not_modified': True,
        'capacity_interface_ms': (perf_counter() - begin) * 1000.}


class CandidateWBC(OnlineWBC):
    """Resident unchanged QP, with current full raw before strict decode loss."""
    def __init__(self, model, solve_callback=None):
        super().__init__(model, solve_callback=solve_callback)
        self.solver_time_limit_s = .003
        self.current_context_id = 'STEP34_CURRENT'
        self.last_candidate = None

    def compute(self, data, method, health, target=None):
        self._candidate_context = {'context_id': self.current_context_id,
            'state': integration_state(self.model, data), 'health_vector': np.asarray(health).copy()}
        return super().compute(data, method, health, target)

    def _invoke(self, problem, stage, **kwargs):
        frozen = {name: problem[name].copy() for name in ('P', 'q', 'A', 'l', 'u')}
        result = super()._invoke(problem, stage, **kwargs)
        result['step34_problem'] = frozen
        key = self._workspace_key({'P': problem['P'], 'A': problem['A']})
        cache = self._solver_cache.get(key, {})
        result['step34_existing_dual'] = None if cache.get('last_y') is None else cache['last_y'].copy()
        result['step34_current_raw_x'] = None if result.get('x') is None else np.asarray(result['x']).copy()
        return result

    def _decode(self, out, meta, method):
        result = super()._decode(out, meta, method)
        matrix = capture_matrices(self, self._candidate_context, meta)
        problem = out['step34_problem']
        if not (np.array_equal(problem['A'].toarray(), matrix['A']) and
                np.array_equal(problem['l'], matrix['l']) and np.array_equal(problem['u'], matrix['u'])):
            raise ValueError('STEP34 same-call CSC/decoder physical matrix identity mismatch')
        raw = dict(out, x=out['step34_current_raw_x'])
        certificate = check_candidate(raw, matrix, self._candidate_context)
        self.last_candidate = certificate
        z = certificate['raw_full_primal']
        nv, nu, nc = matrix['nv'], matrix['nu'], matrix['nc']
        result.update(raw_optimizer_status=out.get('status_val'), optimizer_converged=certificate['optimizer_converged'],
            strict_candidate_mask=certificate['strict_candidate_mask'], candidate_certificate=certificate,
            candidate_valid=certificate['candidate_valid'], candidate_schema=VERSION,
            success=certificate['candidate_valid'], command_status=certificate['status'],
            full_current_raw_x=out['step34_current_raw_x'], source_matrices=matrix,
            raw_solver_variables={'qdd': None if z is None else z[:nv].copy(),
                'tau': None if z is None else z[nv:nv + nu].copy(),
                'contact_force': None if z is None else z[nv + nu:].copy(),
                'source': 'THIS_REAL_OPTIMIZER_RETURN_BEFORE_STRICT_DECODE'},
            qdd=None if z is None else z[:nv].copy(), tau=None if z is None else z[nv:nv + nu].copy(),
            contact_force=None if z is None else z[nv + nu:].copy(),
            validation=certificate.get('raw_hard_check') or {},
            v1_valid=certificate['candidate_valid'], optimality_claim=False,
            stability_claim=False, future_safety_claim=False)
        for name in ('step34_problem', 'step34_existing_dual') + SOLVER_EVIDENCE_FIELDS:
            if name in out:
                result[name] = out[name]
        if self.solver_ledger:
            self.solver_ledger[-1].update({name: out[name] for name in SOLVER_EVIDENCE_FIELDS if name in out})
            self.solver_ledger[-1].update(raw_optimizer_status=out.get('status_val'),
                optimizer_converged=certificate['optimizer_converged'], candidate_valid=certificate['candidate_valid'],
                strict_candidate_mask=certificate['strict_candidate_mask'], candidate_schema=VERSION,
                candidate_rejection_reason=certificate['rejection_reason'], candidate_check_ms=certificate['check_ms'],
                failed_raw_rows=None if certificate['raw_hard_check'] is None else certificate['raw_hard_check']['failed_row_indices'].tolist(),
                failed_sent_rows=None if certificate['sent_hard_check'] is None else certificate['sent_hard_check']['failed_row_indices'].tolist())
        return result
