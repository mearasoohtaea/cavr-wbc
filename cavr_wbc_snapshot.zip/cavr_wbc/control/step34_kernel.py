"""Application-time feasible candidates with sequential on-demand prefixes."""
from __future__ import annotations
from copy import deepcopy
from time import perf_counter
import mujoco
import numpy as np

from cavr_wbc.control.step33_kernel import Kernel as BaseKernel, application_context
from cavr_wbc.control.step29_kernel import DEADLINE_S, FINAL_RESERVE_S, MIN_SOLVER_S, MAX_SOLVER_S
from cavr_wbc.control.step27_resident_kernel import reset_workspace_warmstart
from cavr_wbc.control.step23_backup_filter import _finite_state, predicted_physical_check
from cavr_wbc.control.step34_candidate import CandidateWBC, VERSION as CANDIDATE_VERSION, status_eligible, check_candidate
from cavr_wbc.control.step34_servo import CapacityPoseServo
from cavr_wbc.control.step34_actions import GAMMA_GRID, make_action, prepare_shared, check_rows
from cavr_wbc.control.step34_native_prefix import NativeActionPrefix
from cavr_wbc.experiments.step31_sim import capture_packet_memory
from cavr_wbc.platforms.go2_mujoco import FOOT_NAMES

VERSION = 'STEP34_APPLICATION_CURRENT_FEASIBILITY_GOVERNOR_V1'
METHODS = ('APPLICATION_FEAS_GOV', 'APPLICATION_FEAS_BINARY')
FIRST_QP_LIMIT_S = .003


def construct_prehold(sample, healthy_limits):
    state = sample.get('state', sample.get('source_state', sample))
    identity = sample.get('previous_command_identity') or {}
    h, limits = np.asarray(sample['health_vector']), np.asarray(healthy_limits)
    tau = np.asarray(sample.get('previous_tau_sent', identity.get('tau_sent')), dtype=float)
    valid = bool(identity.get('available') is True and identity.get('source_candidate_valid') is True and
        identity.get('candidate_schema', identity.get('source_candidate_schema')) == CANDIDATE_VERSION and
        status_eligible(identity.get('source_solver_status_val')) and
        identity.get('episode_id') == sample.get('episode_id') and
        identity.get('source_tick') == sample.get('source_tick') and
        identity.get('previous_reference_tick', identity.get('applied_previous_reference_tick')) == int(sample['source_tick']) - 1 and
        identity.get('source_snapshot', identity.get('snapshot_id')) in (sample.get('source_snapshot'), sample.get('snapshot_id')) and
        np.array_equal(np.asarray(identity.get('health_vector', identity.get('source_health_vector'))), np.ones_like(h)) and
        tau.shape == limits.shape == h.shape and np.isfinite(tau).all() and np.isfinite(h).all() and
        np.all((h >= 0.) & (h <= 1.)) and np.array_equal(state['ctrl'], tau) and np.array_equal(identity.get('tau_sent'), tau))
    if not valid:
        raise ValueError('STEP34 known previous candidate command/state identity mismatch')
    sent = np.clip(tau, -h * limits, h * limits)
    return {'schema': VERSION, 'source': 'LAST_COMMAND_HEALTH_CLIPPED', 'kind': 'PREHOLD',
        'command_valid': True, 'solver_status_val': None, 'new_QP_calls': 0,
        'tau_raw': tau.copy(), 'tau_sent': sent, 'health_vector': h.copy(),
        'healthy_torque_limits_nm': limits.copy(), 'effective_capacity_nm': h * limits,
        'previous_command_identity': deepcopy(identity), 'certified_backup': False,
        'sample_start_s': 0., 'sample_end_s': .020}


class Kernel(BaseKernel):
    def __init__(self, model, variant='BOUNDED', prefixdll=None, budget=None):
        super().__init__(model, variant, prefixdll, budget, teacher=False)
        self.nominal_servo = CapacityPoseServo(model)
        self.backup_servo = CapacityPoseServo(model)
        self.policy.servo = self.backup_servo
        self.native_prefix = NativeActionPrefix.share(self.native_prefix)
        self._shadow_controllers = {name: CandidateWBC(model) for name in ('C', 'B')}
        self.version = VERSION
        self._candidate_current_scope = None

    def _replace_solver_owners(self):
        self.nominal_controller = CandidateWBC(self.model)
        self.backup_controller = CandidateWBC(self.model)
        self.policy.controller = self.backup_controller

    @staticmethod
    def _capture_problem(controller):
        # CandidateWBC captures current raw/CSC before the strict decoder itself.
        return None

    def solver_owner_identity(self):
        result = super().solver_owner_identity()
        result['scope'] = 'STEP34_CURRENT_CANDIDATE_3MS_FIRST_6MS_FEEDBACK'
        return result

    def construct_prehold(self, sample):
        return construct_prehold(sample, self.healthy_limits)

    def reset(self, context):
        data = super().reset(context)
        # C/B witness identity includes application clock.  The original helper
        # zeroes the clock for actual branches; these QP resets preserve it.
        data.time = float(context.get('application_time_s', 0.))
        self.nominal_controller.current_context_id = str(context['context_id'])
        return data

    def reset_backup(self, current, context, preserve_ready=False):
        data = super().reset_backup(current, context, preserve_ready)
        if not preserve_ready:
            data.time = float(context.get('application_time_s', 0.))
        self.backup_controller.current_context_id = str(context['context_id'])
        return data

    def _prepare_sample(self, sample, budget, method):
        if method not in METHODS:
            raise ValueError('STEP34 unknown application-time paired method')
        prehold = self.construct_prehold(sample)
        prediction = self.predict_application(sample, prehold, budget)
        context = application_context(sample, prediction) if prediction['complete'] else dict(sample)
        return context, prehold, prediction

    def _candidate_event(self, active, raw, kind, owner):
        proof = raw.get('candidate_certificate') or {}
        if active is not None and hasattr(active, 'event'):
            active.event('CURRENT_CANDIDATE_CHECK', kind=kind, owner=owner,
                local_qp_index=raw.get('solver_call_index'), raw_optimizer_status=raw.get('status_val'),
                candidate_valid=proof.get('candidate_valid', False),
                strict_candidate_mask=proof.get('strict_candidate_mask', False),
                optimizer_converged=proof.get('optimizer_converged', False),
                candidate_rejection_reason=proof.get('rejection_reason'),
                candidate_check_ms=proof.get('check_ms'), candidate_schema=CANDIDATE_VERSION)

    def nominal(self, context, budget=None, kind='NOMINAL', owner=None):
        begin = perf_counter()
        active = self.budget if budget is None else budget
        self._configure(self.nominal_controller)
        if self._context_id != str(context['context_id']):
            raise ValueError('STEP34 nominal current context must be reset independently')
        self._bind(self.nominal_controller, active, kind, owner or context['context_id'])
        cursor = len(self.nominal_controller.solver_ledger)
        before = self.nominal_controller.solver_setup_calls
        response = self.nominal_servo.compute(self.nominal_controller, self.data, context['health_vector'], context['source_tick'])
        interface, raw = response['capacity_interface'], response['wbc']
        valid = bool(response['valid_command'])
        forward_s, fact = 0., None
        if valid:
            self.data.ctrl[:] = response['tau_cmd']
            t = perf_counter()
            mujoco.mj_forward(self.model, self.data)
            forward_s = perf_counter() - t
            fact = self.physical_fact(self.data, context, interface, response['latency_ms']) if _finite_state(self.data) else None
        physical = predicted_physical_check(fact or {})
        response['pre_send_validation']['current_physical_check'] = physical
        response['solver_ledger_delta'] = self.nominal_controller.solver_ledger[cursor:]
        self._candidate_event(active, raw, kind, owner or context['context_id'])
        matrix = raw.get('source_matrices')
        points = self.nominal_controller.last_trace.get('points')
        result = {'schema': VERSION, 'context_id': context['context_id'],
            'kernel_variant': self.variant, 'health_vector': np.asarray(context['health_vector']).copy(),
            'command_valid': valid, 'candidate_valid': valid, 'candidate_schema': CANDIDATE_VERSION,
            'optimizer_converged': raw.get('optimizer_converged'), 'strict_candidate_mask': raw.get('strict_candidate_mask'),
            'tau': response['tau_cmd'], 'tau_raw': interface['tau_raw'], 'tau_sent': response['tau_cmd'],
            'capacity_interface': interface, 'response': response, 'raw_solver_result': raw,
            'raw_solver_variables': response['raw_solver_variables'], 'source_matrices': matrix,
            'qdd': raw.get('qdd'), 'contact_lambda': raw.get('contact_force'),
            'solver_status_val': raw.get('status_val'), 'solver_status': raw.get('status'),
            'raw_QP_success': raw.get('optimizer_converged', False), 'candidate_certificate': raw.get('candidate_certificate'),
            'QP_validation': raw.get('validation'), 'a_base_ref': response.get('a_base_ref'),
            'assembly': self.nominal_controller.last_trace, 'initial_new_command_fact': fact,
            'current_physical_check': physical, 'execution_diagnostics': response['execution_diagnostics'],
            'solver_ledger': response['solver_ledger_delta'],
            'foot_positions': {name: np.asarray(points[i]).copy() for i, name in enumerate(FOOT_NAMES)} if points is not None else None,
            'actual_mujoco_qacc': self.data.qacc.copy() if valid else None,
            'raw_QP_bound_exact_pass': interface['raw_command_within_capacity_exact'],
            'sent_command_exact_pass': interface['sent_command_within_capacity_exact'],
            'backup_initial_b': np.zeros(6), 'source_b_used': np.asarray(context['nominal_b_used']).copy(),
            'nominal_d_m': context['nominal_d_m'], 'invalid_command_not_applied': not valid,
            'counts': {'nominal_qp_calls': len(response['solver_ledger_delta']), 'control_qp_calls': len(response['solver_ledger_delta']),
                'clone_data_calls': 0, 'nominal_controller_instances': 0, 'nominal_command_diagnostic_forward_calls': int(valid)},
            'timing': {**response['timing'], 'action_conditioned_forward_s': forward_s}}
        self._record_setup(self.nominal_controller, before, result, kind, owner or context['context_id'], active)
        result['command_ready_ms'] = result['generation_ms'] = (perf_counter() - begin) * 1000.
        return result

    def compute_backup(self, context, slot, budget=None, kind='ACTUAL_B', owner=None):
        begin = perf_counter()
        active = self.budget if budget is None else budget
        self._configure(self.backup_controller)
        if (self._backup_context_id != str(context['context_id']) or self.policy.backup_id != context['backup_id'] or
            (self._last_backup_slot is not None and int(slot) != self._last_backup_slot + 1) or
            (self._last_backup_slot is None and int(slot) not in (0, 1))):
            raise ValueError('STEP34 backup current identity/feedback slot mismatch')
        self._bind(self.backup_controller, active, kind, owner or context['context_id'], 'BACKUP')
        cursor = len(self.backup_controller.solver_ledger)
        before = self.backup_controller.solver_setup_calls
        response = self.policy.compute(self.backup_data, context['health_vector'], slot)
        raw, interface = response['wbc'], response['capacity_interface']
        valid = bool(response['valid_command'])
        forward_s, fact = 0., None
        if valid:
            self.backup_data.ctrl[:] = response['tau_cmd']
            t = perf_counter()
            mujoco.mj_forward(self.model, self.backup_data)
            forward_s = perf_counter() - t
            fact = self.physical_fact(self.backup_data, context, interface, response['latency_ms'], int(slot), int(slot) * 10) if _finite_state(self.backup_data) else None
        response.update(current_physical_check=predicted_physical_check(fact or {}), initial_new_command_fact=fact,
            source_matrices=raw.get('source_matrices'), solver_status_val=raw.get('status_val'),
            command_valid=valid, tau_raw=interface['tau_raw'], tau_sent=response['tau_cmd'],
            health_vector=np.asarray(context['health_vector']).copy(), invalid_command_not_applied=not valid,
            solver_ledger_delta=self.backup_controller.solver_ledger[cursor:])
        response['pre_send_validation']['current_physical_check'] = response['current_physical_check']
        response['timing'].update(action_conditioned_forward_s=forward_s)
        self._candidate_event(active, raw, kind, owner or context['context_id'])
        self._record_setup(self.backup_controller, before, response, kind, owner or context['context_id'], active)
        response['command_ready_ms'] = response['latency_ms'] = (perf_counter() - begin) * 1000.
        self._last_backup_slot, self._last_backup_response = int(slot), response
        return response

    def _capture_packet(self, packet):
        current = self.solver_owner_identity()
        if 'step34_solver_owner' in packet and packet['step34_solver_owner'] != current:
            raise ValueError('STEP34 packet/controller owner changed before same-packet branch')
        capture_packet_memory(self, packet)
        packet['step34_solver_owner'] = current
        memory = packet['step31_backup_memory']
        if memory.get('status') == 'CAPTURED_B0':
            memory['step34_solver_owner'] = deepcopy(current)
            memory['same_call_CSC_problem'] = packet['B']['wbc'].get('step34_problem')
            memory['candidate_schema'] = CANDIDATE_VERSION
        return packet

    def _endpoints(self, sample, context, packet, active, deadline=None):
        for name in ('B', 'C'):
            if active is not None:
                active.check()
            if deadline is not None and deadline - perf_counter() < FIRST_QP_LIMIT_S + FINAL_RESERVE_S:
                packet[name] = {'status': 'NOT_EVALUATED_BUDGET', 'command_valid': False}
                continue
            t = perf_counter()
            # Restore identical complete application witness for each owner;
            # nominal reset never mutates the already-computed B0 servo/cache.
            self.reset(context)
            self.set_next_call_limit(FIRST_QP_LIMIT_S)
            fn = self.first_backup if name == 'B' else self.nominal
            packet[name] = fn(context, active, 'FIRST_' + packet['method'] + '_' + name, sample['context_id'])
            if name == 'B':
                self._capture_packet(packet)
            packet['phase_latency_ms'][name + '_QP_and_contract_ms'] = (perf_counter() - t) * 1000.
        return prepare_shared(context, packet.get('C'), packet.get('B'))

    def _packet_base(self, sample, active, method):
        context, prehold, prediction = self._prepare_sample(sample, active, method)
        packet = {'schema': VERSION, 'context_id': sample['context_id'], 'method': method,
            'context_used': context, 'sample_context': sample, 'prehold': prehold,
            'application_prediction': prediction, 'actions': {}, 'phase_latency_ms': {},
            'C': {'status': 'NOT_REQUESTED'}, 'B': {'status': 'NOT_REQUESTED'},
            'selected_gamma': None, 'selected_action': None, 'selected_command_sent': False,
            'QP_state_time_s': .020, 'actual_first_packet_apply_time_s': .020,
            'first_QP_native_time_limit_s': FIRST_QP_LIMIT_S, 'on_demand_prefix_order': [],
            'status': 'ABSTAIN'}
        return context, packet

    def collect_actions(self, sample, budget=None, method='APPLICATION_FEAS_GOV'):
        active = self.budget if budget is None else budget
        begin = perf_counter()
        context, packet = self._packet_base(sample, active, method)
        packet['status'] = 'CAL_COLLECTION'
        if packet['application_prediction']['complete']:
            ws = self._endpoints(sample, context, packet, active)
            for gamma in GAMMA_GRID:
                action = make_action(context, packet['C'], packet['B'], gamma, workspace=ws)
                prefix = self._prefix_one(context, action, active) if action.get('command_valid') else None
                packet['actions'][str(gamma)] = self._entry(context, action, prefix, packet['prehold'])
                if prefix is not None:
                    packet['on_demand_prefix_order'].append(gamma)
        self._capture_packet(packet)
        packet['command_ready_ms'] = (perf_counter() - begin) * 1000.
        return packet

    def endpoint_diagnostic(self, sample, budget=None, method='APPLICATION_FEAS_GOV'):
        return self.governor(sample, None, float('nan'), budget, method, diagnostic_only=True)

    def governor(self, sample, bundle, gap, budget=None, method='APPLICATION_FEAS_GOV', decide=None, diagnostic_only=False):
        from cavr_wbc.control.step34_margin import calibrated_gammas, batch_numeric
        if method not in METHODS:
            raise ValueError('STEP34 unknown paired selection method')
        active = self.budget if budget is None else budget
        begin = perf_counter()
        deadline = begin + DEADLINE_S
        role = sample['health_kind'].split('_')[0].lower()
        grid = GAMMA_GRID if method == 'APPLICATION_FEAS_GOV' else (1., 0.)
        eligible = grid if diagnostic_only or decide is not None else calibrated_gammas(bundle, role, grid)
        context, packet = self._packet_base(sample, active, method)
        packet.update(gap_m=float(gap), deadline_ms=20., prepare_begin=begin, absolute_deadline=deadline,
            qualified_gammas=np.asarray(eligible), diagnostic_only=diagnostic_only, calibration_read=not diagnostic_only)
        last = approved = None
        if getattr(self, 'ready', False) and packet['application_prediction']['complete']:
            ws = self._endpoints(sample, context, packet, active, deadline)
            for gamma in grid:
                action = make_action(context, packet['C'], packet['B'], gamma, workspace=ws)
                last = action
                entry = self._entry(context, action, None, packet['prehold'])
                packet['actions'][str(gamma)] = entry
                if gamma not in eligible:
                    entry['evaluation_status'] = 'NOT_CALIBRATED'
                    continue
                if not action.get('command_valid'):
                    continue
                if deadline - perf_counter() < FINAL_RESERVE_S:
                    entry['evaluation_status'] = 'NOT_EVALUATED_BUDGET'
                    break
                t = perf_counter()
                prefix = self._prefix_one(context, action, active)
                entry = self._entry(context, action, prefix, packet['prehold'])
                packet['actions'][str(gamma)] = entry
                packet['on_demand_prefix_order'].append(gamma)
                packet['phase_latency_ms']['G' + str(gamma) + '_prefix_feature_ms'] = (perf_counter() - t) * 1000.
                if deadline <= perf_counter():
                    entry['evaluation_status'] = 'NOT_EVALUATED_BUDGET'
                    break
                if diagnostic_only:
                    entry['evaluation_status'] = 'DIAGNOSTIC_PREFIX_ONLY_NO_CAL_NO_SEND'
                    continue
                if entry['features26'] is None:
                    continue
                t = perf_counter()
                if decide is not None:
                    decision = decide(bundle, entry, float(gap))
                else:
                    numeric = batch_numeric(bundle, np.asarray([entry['features26']]), np.array([gamma]), [role],
                        np.asarray([prefix.get('D_prefix_m')]), prehold_d=np.asarray([packet['prehold'].get('D_prehold_m')]))
                    copied = {name: value[0].copy() if isinstance(value[0], np.ndarray) else value[0].item() if hasattr(value[0], 'item') else value[0]
                        for name, value in numeric.items()}
                    accept = bool(all(bool(numeric[name][0]) for name in ('finite_input', 'pose_gate', 'support_gate',
                        'distance_gate', 'calibration_gate', 'physical_risk_gate')) and np.all(numeric['U_T'][0] <= 1.) and numeric['U_D'][0] <= gap)
                    decision = {'accepted': accept, 'choice': gamma if accept else 'ABSTAIN', 'numeric': copied}
                gate = bool(packet['prehold'].get('complete') and packet['prehold'].get('original_physical_pass') and
                    prefix.get('complete') and prefix.get('original_physical_pass') and decision.get('accepted', False))
                entry.update(decision=decision, evaluation_status='EVALUATED', complete_at_ms=(perf_counter() - begin) * 1000.)
                packet['phase_latency_ms']['G' + str(gamma) + '_inference_ms'] = (perf_counter() - t) * 1000.
                if gate:
                    approved = action
                    break
        self._capture_packet(packet)
        elapsed = (perf_counter() - begin) * 1000.
        any_valid = any(ep.get('command_valid', ep.get('valid_command', False)) for ep in (packet['C'], packet['B']))
        sent = bool(not diagnostic_only and approved is not None and elapsed <= 20.)
        packet.update(command_ready_ms=elapsed, elapsed_ms=elapsed, overall_deadline_failure=elapsed > 20.,
            selected_action=approved if approved is not None else last, selected_gamma=approved['gamma'] if approved is not None else None,
            selected_command_sent=sent, timely_recognized_command=sent, command_available=any_valid,
            status='RECOGNIZED_SENT' if sent else 'COMPUTED_VALID_BUT_LATE' if any_valid and elapsed > 20. else 'ENDPOINT_DIAGNOSTIC' if diagnostic_only else 'ABSTAIN')
        for gamma in GAMMA_GRID:
            packet['actions'].setdefault(str(gamma), {'gamma': gamma, 'evaluation_status':
                'NOT_IN_POLICY' if gamma not in grid else 'NOT_REQUESTED_AFTER_SELECTION' if sent else 'NOT_EVALUATED_BUDGET'})
        packet['step31_backup_memory']['decision_command_ready_ms_unchanged'] = elapsed
        if approved is not None:
            approved['command_ready_ms'] = elapsed
        return packet

    def shadow(self, sample, packet, budget=None):
        """One bounds-only 3 ms same-problem candidate for each available endpoint."""
        active = self.budget if budget is None else budget
        context = packet.get('context_used') or {}
        h = np.asarray(sample['health_vector'], dtype=float)
        limits = np.asarray(self.healthy_limits, dtype=float)
        results = {}
        for name in ('C', 'B'):
            endpoint = packet.get(name) or {}
            raw = endpoint.get('raw_solver_result', endpoint.get('wbc', {})) or {}
            problem, matrix = raw.get('step34_problem'), endpoint.get('source_matrices')
            if not problem or not matrix or not packet.get('selected_command_sent') or not (0. < float(packet.get('selected_gamma', -1.)) < 1.):
                results[name] = {'status': 'NOT_RUN', 'reason': 'SENT_MIDDLE_SAME_CALL_ENDPOINT_UNAVAILABLE', 'new_QP_calls': 0}
                continue
            changed = {key: value.copy() for key, value in problem.items()}
            nv, nu, nc = matrix['nv'], matrix['nu'], matrix['nc']
            rows = 2 * nv + nc + np.flatnonzero(h < 1.)
            indices = np.flatnonzero(h < 1.)
            changed['l'][rows] = -limits[indices]
            changed['u'][rows] = limits[indices]
            controller = self._shadow_controllers[name]
            controller.solver_time_limit_s = FIRST_QP_LIMIT_S
            reset_workspace_warmstart(controller)
            self._bind(controller, active, 'SHADOW_' + name, sample['context_id'])
            begin = perf_counter()
            answer = controller._invoke(changed, 'STEP34_BOUNDS_ONLY_SHADOW')
            shadow_matrix = dict(matrix, l=changed['l'], u=changed['u'], health_vector=np.ones_like(h))
            shadow_context = dict(context, health_vector=np.ones_like(h))
            proof = check_candidate(answer, shadow_matrix, shadow_context)
            z = proof.get('raw_full_primal')
            tau = None if z is None else z[nv:nv + nu].copy()
            violation = None if tau is None else np.abs(tau) - h * limits
            roundoff = None if tau is None else 100. * np.finfo(float).eps * np.maximum.reduce([np.ones_like(limits), limits, np.abs(tau)])
            substantive = bool(proof['candidate_valid'] and np.any(violation > roundoff))
            bounded = raw.get('candidate_certificate') or {}
            original = raw.get('candidate_certificate', {}).get('raw_full_primal')
            difference = None if z is None or original is None else z - original
            same = bool(all(np.array_equal(changed[key], problem[key]) for key in ('q',)) and
                np.array_equal(changed['P'].data, problem['P'].data) and
                np.array_equal(changed['A'].data, problem['A'].data) and
                np.array_equal(changed['l'][np.setdiff1d(np.arange(len(changed['l'])), rows)], problem['l'][np.setdiff1d(np.arange(len(changed['l'])), rows)]) and
                np.array_equal(changed['u'][np.setdiff1d(np.arange(len(changed['u'])), rows)], problem['u'][np.setdiff1d(np.arange(len(changed['u'])), rows)]))
            results[name] = {'schema': VERSION, 'status': 'CURRENT_CONTRACT_FEASIBLE_CANDIDATE' if proof['candidate_valid'] else 'CURRENT_CONTRACT_CANDIDATE_REJECTED',
                'raw_optimizer_status': answer.get('status_val'), 'optimizer_converged': proof['optimizer_converged'],
                'candidate_valid': proof['candidate_valid'], 'candidate_certificate': proof,
                'bounded_candidate_valid': bounded.get('candidate_valid', False),
                'bounded_optimizer_converged': bounded.get('optimizer_converged', False),
                'capacity_bound_effect': substantive, 'nonoptimal_excluded_action_exists': substantive,
                'optimal_solution_capacity_effect_claim': False,
                'damaged_capacity_violation_nm': violation, 'roundoff_only_capacity_violation': bool(violation is not None and np.any(violation > 0.) and not substantive),
                'floating_roundoff_bound_nm': roundoff,
                'roundoff_rule': 'UNCHANGED 100*double_eps*max(1Nm,healthy_limit,abs(shadow_tau)); diagnostic only, no constraint slack',
                'tau_raw': tau, 'raw_primal_difference': difference,
                'raw_problem': changed, 'changed_row_indices': rows, 'same_except_injured_torque_bounds': same,
                'raw_solver_result': answer, 'native_time_limit_s': FIRST_QP_LIMIT_S,
                'elapsed_ms': (perf_counter() - begin) * 1000., 'new_QP_calls': 1,
                'actuated': False, 'CAL_used': False, 'method_selection_used': False,
                'source_context_health': h.copy(), 'shadow_problem_health': np.ones_like(h)}
            self._candidate_event(active, dict(answer, candidate_certificate=proof), 'SHADOW_' + name, sample['context_id'])
        return {'schema': VERSION, 'status': 'RETURNED', 'context_id': sample['context_id'], **results}
