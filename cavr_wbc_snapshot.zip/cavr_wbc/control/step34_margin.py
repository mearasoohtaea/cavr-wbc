"""Application-clock linear targets, density support and empirical physical risk.

Only STEP33 ALIGNED DEV trains the two fixed heads. CAL uses the new bounded
candidate controller; partial inputs remain ranked and never supply zero
targets. Labels do not enter distance ranking, and TEST never enters fitting.
"""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import warnings
import numpy as np
from scipy.special import expit
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.exceptions import ConvergenceWarning
from cavr_wbc.control import step30_margin as original
from cavr_wbc.control.step33_margin import _lower_bound

VERSION = 'STEP34_APPLICATION_FEAS_LINEAR_RISK_V1'
MAIN = 'APPLICATION_LINEAR_26'
GAMMA_GRID = original.GAMMA_GRID
ROLES = ('healthy', 'thigh', 'calf')
K = 5
MIN_CAL_SNAPSHOTS = 4
MIN_CAL_EPISODES = 2
D_SCALE_M = original.D_SCALE_M
D_RESERVE_M = original.D_RESERVE_M
TERMINAL_RESERVE = original.TERMINAL_RESERVE
POSE_PAD_RAD = original.POSE_PAD_RAD
DISTANCE_FLOOR = original.DISTANCE_FLOOR
FEATURE_NAMES = original.FEATURE_NAMES
PHYSICAL_FLOORS = original.PHYSICAL_FLOORS
gamma_key = original.gamma_key
labels = original.labels
safe = original.safe
local_cal_indices = original.local_cal_indices

ARRAYS = ('mean', 'scale', 'train_std', 'physical_floor', 'coefficient', 'intercept',
          'risk_coefficient', 'risk_intercept', 'pose_min', 'pose_max')
GROUP_ARRAYS = ('train_z', 'train_ids', 'train_snapshot_ids', 'train_complete', 'train_physical',
    'cal_z', 'cal_ids', 'cal_snapshot_ids', 'cal_episode_ids', 'cal_snapshot_index', 'cal_episode_index',
    'cal_complete', 'cal_residual', 'cal_physical_known', 'cal_physical_pass', 'cal_probability')


def group_key(gamma, role):
    if role not in ROLES:
        raise ValueError('explicit fault role required')
    return gamma_key(gamma) + ':' + role


def physical_target(record):
    lab = record.get('labels') or {}
    if original._complete_target(record) is not None:
        return int(original._physical(lab))
    if lab.get('observed_original_physical_failure') or lab.get('original_failure'):
        return 0
    return None


def _validate(records, split):
    records = list(records)
    if len({r['id'] for r in records}) != len(records):
        raise ValueError('duplicate action identity')
    for row in records:
        if row.get('split') != split:
            raise ValueError('STEP34 requires ' + split + ' only; TEST is never training/CAL')
        original._identity(row, 'episode'); original._identity(row, 'source_snapshot')
        group_key(row['gamma'], original._role(row))
    return records


def train(records, budget=None):
    """Exactly one fixed six-output fit and one fixed L2 logistic fit."""
    rows = _validate(records, 'TRAIN')
    if any(r.get('source_method') != 'ALIGNED_RECAL' or r.get('source_split') != 'DEV' for r in rows):
        raise ValueError('TRAIN_SOURCE must be STEP33_ALIGNED_DEV_ONLY')
    finite = [r for r in rows if original._finite_input(r) is not None]
    if not finite:
        raise ValueError('no finite TRAIN input')
    x = np.asarray([original._input_features(r) for r in finite])
    mean, std = x.mean(axis=0), x.std(axis=0, ddof=0)
    scale = np.maximum(std, PHYSICAL_FLOORS)
    z = (x - mean) / scale
    target_indices = [i for i, r in enumerate(finite) if original._complete_target(r) is not None]
    if not target_indices:
        raise ValueError('no complete D/Y TRAIN targets')
    target = np.asarray([original._target(finite[i]['labels']) for i in target_indices])
    target[:, 0] /= D_SCALE_M
    if budget is not None:
        budget.register_fit('REGRESSION')
    regression = Ridge(alpha=1., fit_intercept=True, solver='cholesky')
    regression.fit(z[target_indices], target)
    risk_indices = [i for i, row in enumerate(finite) if physical_target(row) is not None]
    risk_y = np.asarray([physical_target(finite[i]) for i in risk_indices], dtype=int)
    if set(risk_y) != {0, 1}:
        raise ValueError('physical risk head requires both observed classes, no synthetic targets')
    if budget is not None:
        budget.register_fit('PHYSICAL_RISK')
    risk = LogisticRegression(C=1., penalty='l2', solver='lbfgs', max_iter=1000,
                              tol=1e-8, fit_intercept=True, class_weight=None, random_state=20261300)
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always', ConvergenceWarning)
        risk.fit(z[risk_indices], risk_y)
    converged = not any(issubclass(w.category, ConvergenceWarning) for w in caught) and int(risk.n_iter_[0]) < 1000
    groups = {}
    for gamma in GAMMA_GRID:
        for role in ROLES:
            selected = [(i, r) for i, r in enumerate(finite) if r['gamma'] == gamma and original._role(r) == role]
            groups[group_key(gamma, role)] = {
                'train_z': z[[i for i, _ in selected]].reshape(-1, 26),
                'train_ids': np.asarray([r['id'] for _, r in selected], dtype=str),
                'train_snapshot_ids': np.asarray([r['source_snapshot'] for _, r in selected], dtype=str),
                'train_complete': np.asarray([original._complete_target(r) is not None for _, r in selected]),
                'train_physical': np.asarray([physical_target(r) == 1 for _, r in selected]),
                'TRAIN_finite_count': len(selected), 'TRAIN_distinct_snapshots': len({r['source_snapshot'] for _, r in selected}),
                'local_calibrated': False, 'distance_threshold': DISTANCE_FLOOR}
    bundle = {'schema': VERSION, 'configuration_id': MAIN, 'family': 'linear Ridge alpha=1', 'trained': True,
        'risk_family': 'L2 logistic C=1 (alpha=1)', 'risk_solver': 'lbfgs', 'risk_max_iter': 1000,
        'risk_tol': 1e-8, 'risk_classes': risk.classes_.tolist(), 'risk_iterations': int(risk.n_iter_[0]),
        'risk_converged': converged, 'risk_warning_messages': [str(w.message) for w in caught],
        'mean': mean, 'scale': scale, 'train_std': std, 'physical_floor': PHYSICAL_FLOORS.copy(),
        'coefficient': regression.coef_.copy(), 'intercept': regression.intercept_.copy(),
        'risk_coefficient': risk.coef_[0].copy(), 'risk_intercept': risk.intercept_.copy(),
        'pose_min': x[:, [2, 3]].min(axis=0), 'pose_max': x[:, [2, 3]].max(axis=0),
        'pose_source': 'FINITE_TRAIN_ONLY', 'pose_source_ids': [r['id'] for r in finite],
        'TRAIN_ids_all': [r['id'] for r in rows], 'TRAIN_finite_ids': [r['id'] for r in finite],
        'TRAIN_regression_ids': [finite[i]['id'] for i in target_indices],
        'TRAIN_risk_ids': [finite[i]['id'] for i in risk_indices],
        'TRAIN_unknown_risk_ids': [r['id'] for r in finite if physical_target(r) is None],
        'TRAIN_complete_failures_retained': sum(physical_target(finite[i]) == 0 for i in target_indices),
        'TRAIN_partial_observed_physical_failures_retained': sum(physical_target(r) == 0 and original._complete_target(r) is None for r in finite),
        'TRAIN_risk_pass_count': int(np.sum(risk_y == 1)), 'TRAIN_risk_fail_count': int(np.sum(risk_y == 0)),
        'regression_fit_calls': 1, 'physical_risk_fit_calls': 1, 'TEST_consumed': False,
        'source_label_semantics': 'STEP33_ALIGNED_OFFLINE_100MS_TEACHER_TRANSFER_NOT_ONLINE_EVIDENCE',
        'input_density_rule': 'stable K=5 distinct finite TRAIN snapshot; no safe-label requirement',
        'groups': groups, 'feature_names': list(FEATURE_NAMES), 'calibration_id': None}
    return prepare_resident(bundle)


def probabilities(bundle, z):
    return expit(np.asarray(z) @ bundle['risk_coefficient'] + float(bundle['risk_intercept'][0]))


def build_calibration(trained, records):
    rows = _validate(records, 'CAL')
    if ({r['source_snapshot'] for r in rows} & {v for g in trained['groups'].values() for v in g['train_snapshot_ids']}
            or {r['episode'] for r in rows} & {v.split('_T')[0] for g in trained['groups'].values() for v in g['train_snapshot_ids']}):
        raise ValueError('TRAIN/CAL episode or snapshot overlap')
    bundle = deepcopy({key: value for key, value in trained.items() if not key.startswith('_')})
    for key, group in bundle['groups'].items():
        gamma, role = key.split(':'); gamma = float(gamma)
        planned = [r for r in rows if r['gamma'] == gamma and original._role(r) == role]
        finite = [r for r in planned if original._finite_input(r) is not None]
        x = np.asarray([original._input_features(r) for r in finite], dtype=float).reshape(-1, 26)
        z = (x - bundle['mean']) / bundle['scale']
        probability = probabilities(bundle, z)
        complete = np.zeros(len(finite), dtype=bool); residual = np.full((len(finite), 6), np.nan)
        known = np.asarray([physical_target(r) is not None for r in finite], dtype=bool)
        physical = np.asarray([physical_target(r) == 1 for r in finite], dtype=bool)
        for i, record in enumerate(finite):
            target = original._complete_target(record)
            try:
                lower, available, _ = _lower_bound(record)
            except (KeyError, ValueError, TypeError, AttributeError):
                continue
            if target is None or not available:
                continue
            predicted = original._project(z[i] @ bundle['coefficient'].T + bundle['intercept'], lower)
            residual[i] = np.r_[target[0] - predicted[0], np.abs(target[1:] - predicted[1:])]
            complete[i] = True
        snapshots = sorted({r['source_snapshot'] for r in finite}); episodes = sorted({r['episode'] for r in finite})
        complete_snapshots = {r['source_snapshot'] for r, valid in zip(finite, complete) if valid}
        complete_episodes = {r['episode'] for r, valid in zip(finite, complete) if valid}
        nearest = np.sqrt(np.min(np.sum((z[:, None, :] - group['train_z'][None, :, :])**2, axis=2), axis=1)) if len(z) and len(group['train_z']) else np.empty(0)
        eligible = bool(bundle['trained'] and len(complete_snapshots) >= 4 and len(complete_episodes) >= 2)
        group.update(cal_z=z, cal_ids=np.asarray([r['id'] for r in finite], dtype=str),
            cal_snapshot_ids=np.asarray([r['source_snapshot'] for r in finite], dtype=str),
            cal_episode_ids=np.asarray([r['episode'] for r in finite], dtype=str),
            cal_snapshot_index=np.asarray([snapshots.index(r['source_snapshot']) for r in finite], dtype=np.int64),
            cal_episode_index=np.asarray([episodes.index(r['episode']) for r in finite], dtype=np.int64),
            cal_complete=complete, cal_residual=residual, cal_physical_known=known, cal_physical_pass=physical,
            cal_probability=probability, CAL_planned=len(planned), CAL_finite=len(finite), CAL_complete=int(complete.sum()),
            CAL_complete_distinct_snapshots=len(complete_snapshots), CAL_complete_episodes=len(complete_episodes),
            CAL_missing_feature_ids=[r['id'] for r in planned if original._finite_input(r) is None],
            CAL_incomplete_finite_ids=[r['id'] for r, valid in zip(finite, complete) if not valid],
            CAL_complete_physical_failures=int(np.sum(complete & ~physical)), CAL_physical_unknown=int(np.sum(~known)),
            local_calibrated=eligible, cal_max_nearest_distance=float(nearest.max()) if len(nearest) else 0.,
            distance_threshold=max(3. * float(nearest.max()) if len(nearest) else 0., DISTANCE_FLOOR))
    bundle.update(calibration_id='STEP34_NEW_BOUNDED_FEAS_CAL_V1', CAL_ids_all=[r['id'] for r in rows],
        CAL_target_semantics='MATCHING_CANDIDATE_FEEDBACK_MAX6MS_NO_100MS_TEACHER', CAL_frozen=True)
    return prepare_resident(bundle)


LAYOUT = {**original._NUMERIC_LAYOUT,
    'physical_risk_gate': (bool, ()), 'physical_risk_known_CAL_gate': (bool, ()),
    'physical_pass_probability': (float, ()), 'local_physical_threshold': (float, ())}


def allocate_numeric(count=5):
    return {name: np.full((count, *shape), False if dtype is bool else np.nan if dtype is float else -1, dtype=dtype)
            for name, (dtype, shape) in LAYOUT.items()}


def prepare_resident(bundle):
    keys = tuple(bundle['groups'])
    bundle['_resident'] = {'group_keys': keys, 'group_position': {key: i for i, key in enumerate(keys)}}
    return bundle


def static_group_eligible(bundle, gamma, role, calibration='LOCAL'):
    if calibration != 'LOCAL':
        raise ValueError('STEP34 only LOCAL')
    return bool(bundle['trained'] and bundle['groups'][group_key(gamma, role)]['local_calibrated'])


def calibrated_gammas(bundle, role, allowed=GAMMA_GRID, calibration='LOCAL'):
    return tuple(g for g in GAMMA_GRID if g in allowed and static_group_eligible(bundle, g, role, calibration))


def density_neighbors(group, distance):
    ordered = np.argsort(distance, kind='stable'); selected = []; snapshots = set()
    for index in ordered:
        snapshot = str(group['train_snapshot_ids'][index])
        if snapshot not in snapshots:
            selected.append(int(index)); snapshots.add(snapshot)
        if len(selected) == K:
            break
    return np.asarray(selected, dtype=np.int64)


def batch_numeric(bundle, features26, gammas, roles, prefix_d, calibration='LOCAL', out=None, prehold_d=None):
    if calibration != 'LOCAL':
        raise ValueError('STEP34 only LOCAL')
    features = np.asarray(features26, dtype=float); n = len(features)
    gammas = np.asarray(gammas, dtype=float); lower = np.asarray(prefix_d, dtype=float)
    if features.shape != (n, 26) or gammas.shape != (n,) or lower.shape != (n,) or len(roles) != n:
        raise ValueError('current batch metadata shape mismatch')
    if prehold_d is not None:
        before = np.asarray(prehold_d, dtype=float)
        if before.shape != lower.shape:
            raise ValueError('prehold batch shape mismatch')
        lower = np.maximum(lower, before)
    result = allocate_numeric(n) if out is None else out
    if set(result) != set(LAYOUT):
        raise ValueError('numeric output keys mismatch')
    for key, values in result.items():
        dtype, shape = LAYOUT[key]
        if values.shape != (n, *shape):
            raise ValueError('numeric output dimensions mismatch')
        values.fill(False if dtype is bool else np.nan if dtype is float else -1)
    finite = np.isfinite(features).all(axis=1) & np.isfinite(lower) & (lower >= 0)
    finite &= (features[:, 22] == gammas) & np.isin(features[:, 23], (-1., 1.)) & np.isin(gammas, GAMMA_GRID)
    finite &= np.asarray([r in ROLES for r in roles])
    result['finite_input'][:] = finite
    indices = np.flatnonzero(finite)
    if not len(indices):
        return result
    z = (features[indices] - bundle['mean']) / bundle['scale']
    raw = z @ bundle['coefficient'].T + bundle['intercept']
    result['D_hat'][indices] = np.maximum.reduce([np.zeros(len(indices)), lower[indices], raw[:, 0] * D_SCALE_M])
    result['Y_hat'][indices] = raw[:, 1:]
    result['physical_pass_probability'][indices] = probabilities(bundle, z)
    pose = features[indices][:, [2, 3]]
    result['pose_gate'][indices] = np.all(pose >= bundle['pose_min'] - POSE_PAD_RAD, axis=1) & np.all(pose <= bundle['pose_max'] + POSE_PAD_RAD, axis=1)
    for j, row in enumerate(indices):
        key = group_key(gammas[row], roles[row]); group = bundle['groups'][key]
        result['group_index'][row] = bundle['_resident']['group_position'][key]
        distance = np.sqrt(np.sum((group['train_z'] - z[j])**2, axis=1))
        neighbors = density_neighbors(group, distance)
        result['neighbor_indices'][row, :len(neighbors)] = neighbors
        result['neighbor_distances'][row, :len(neighbors)] = distance[neighbors]
        result['support_gate'][row] = len(neighbors) == K
        result['distance_threshold'][row] = group['distance_threshold']
        if len(distance):
            result['nearest_distance'][row] = distance.min()
            result['distance_gate'][row] = distance.min() <= group['distance_threshold']
        if not static_group_eligible(bundle, gammas[row], roles[row]):
            continue
        distance_cal = np.sqrt(np.sum((group['cal_z'] - z[j])**2, axis=1))
        local = local_cal_indices(group, distance_cal)
        if len(local) != 4:
            continue
        result['local_cal_indices'][row] = local; result['local_cal_distances'][row] = distance_cal[local]
        known = bool(np.all(group['cal_physical_known'][local]))
        result['physical_risk_known_CAL_gate'][row] = known
        if known:
            failed = local[~group['cal_physical_pass'][local]]
            threshold = max(.5, float(group['cal_probability'][failed].max()) if len(failed) else .5)
            result['local_physical_threshold'][row] = threshold
            result['physical_risk_gate'][row] = result['physical_pass_probability'][row] > threshold
        if not np.all(group['cal_complete'][local]) or not np.isfinite(group['cal_residual'][local]).all():
            continue
        margin = group['cal_residual'][local].max(axis=0); margin[0] = max(0., margin[0])
        result['calibration_gate'][row] = True
        result['U_D'][row] = result['D_hat'][row] + margin[0] + D_RESERVE_M
        result['U_T'][row] = np.abs(result['Y_hat'][row]) + margin[1:] + TERMINAL_RESERVE
    return result


def identity(bundle):
    return {key: hashlib.sha256(np.ascontiguousarray(bundle[key]).tobytes()).hexdigest() for key in ARRAYS}


def save_bundle(bundle, directory, stem='step34_application_model_cal'):
    directory = Path(directory); directory.mkdir(parents=True, exist_ok=True)
    path = directory / (stem + '.npz')
    if path.exists() or path.with_suffix('.json').exists():
        raise FileExistsError('STEP34 model/CAL cannot be overwritten/refitted')
    arrays = {name: bundle[name] for name in ARRAYS}
    meta = {k: v for k, v in bundle.items() if k not in ARRAYS and k != 'groups' and not k.startswith('_')}
    meta['groups'] = {}
    for i, (key, group) in enumerate(bundle['groups'].items()):
        prefix = 'group' + str(i) + '_'
        names = [name for name in GROUP_ARRAYS if name in group]
        arrays.update({prefix + name: group[name] for name in names})
        meta['groups'][key] = {k: v for k, v in group.items() if k not in names}
        meta['groups'][key].update(array_prefix=prefix, array_names=names)
    meta.update(alpha=1, D_scale_m=D_SCALE_M, D_reserve_m=D_RESERVE_M, terminal_reserve=TERMINAL_RESERVE,
                pose_pad_rad=POSE_PAD_RAD, k=5, min_CAL_snapshots=4, min_CAL_episodes=2,
                input_density_is_not_physical_success=True, probability_formal_safety_claim=False)
    with path.open('xb') as stream:
        np.savez_compressed(stream, **arrays)
    with path.with_suffix('.json').open('x', encoding='utf-8') as stream:
        json.dump(meta, stream, ensure_ascii=False, allow_nan=False, indent=2)
    return {'npz': str(path), 'json': str(path.with_suffix('.json')),
        'npz_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
        'json_sha256': hashlib.sha256(path.with_suffix('.json').read_bytes()).hexdigest(), 'predictor_identity': identity(bundle)}


def load_bundle(path):
    path = Path(path); meta = json.loads(path.with_suffix('.json').read_text(encoding='utf-8'))
    if meta['schema'] != VERSION:
        raise ValueError('unsupported STEP34 model schema')
    with np.load(path, allow_pickle=False) as archive:
        bundle = dict(meta); bundle.update({name: archive[name].copy() for name in ARRAYS})
        groups = {}
        for key, value in meta['groups'].items():
            group = dict(value); prefix = group.pop('array_prefix'); names = group.pop('array_names')
            group.update({name: archive[prefix + name].copy() for name in names}); groups[key] = group
        bundle['groups'] = groups
    return prepare_resident(bundle)
