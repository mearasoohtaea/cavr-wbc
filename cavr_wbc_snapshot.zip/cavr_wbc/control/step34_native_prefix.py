"""On-demand single-action STEP34 bridge to unchanged ten-step native physics.

The DLL consumes a command, never an OSQP status.  This new Python entry checks
the candidate schema without changing status values before dispatching the
exact original native arithmetic, physical masks and preallocated arrays.
"""
from __future__ import annotations
import ctypes
from time import perf_counter
import numpy as np
from cavr_wbc.control.step30_kernel import NativeActionPrefix as FrozenPrefix
from cavr_wbc.control.step27_resident_kernel import _copy_integration
from cavr_wbc.control.step34_candidate import VERSION as CANDIDATE_VERSION, status_eligible
from cavr_wbc.control.step34_actions import SYNTHESIZED_KIND

VERSION = 'STEP34_ON_DEMAND_EXACT_NATIVE_PREFIX_V1'


class NativeActionPrefix(FrozenPrefix):
    @classmethod
    def share(cls, existing):
        instance = cls.__new__(cls)
        instance.__dict__ = existing.__dict__
        return instance

    def _valid_action(self, context, action):
        proof = action.get('candidate_certificate') or {}
        h = np.asarray(context['health_vector'], dtype=float)
        raw, sent = np.asarray(action.get('tau_raw')), np.asarray(action.get('tau_sent'))
        if not (action.get('command_valid') and action.get('execution_eligible') and
            proof.get('schema') == CANDIDATE_VERSION and proof.get('candidate_valid') and
            action.get('raw_hard_check', {}).get('pass') and action.get('sent_hard_check', {}).get('pass') and
            all(v.shape == self.healthy_limits.shape and np.isfinite(v).all() for v in (h, raw, sent)) and
            np.array_equal(sent, np.clip(raw, -h * self.healthy_limits, h * self.healthy_limits))):
            return False
        if action.get('kind') == SYNTHESIZED_KIND:
            return bool(action.get('solver_status_val') is None and action.get('shared_A_l_u_exact') and
                all(status_eligible(action.get('source_solver_statuses', {}).get(name)) for name in ('C', 'B')))
        return bool(status_eligible(action.get('solver_status_val')) and
            proof.get('raw_optimizer_status') == action.get('solver_status_val'))

    def predict_action(self, current_data, context, action, budget=None):
        begin = perf_counter()
        if not self._valid_action(context, action):
            return self._missing({'context_id': context['context_id'], 'gamma': action['gamma'],
                'solver_status_val': action.get('solver_status_val')}, 'CURRENT_CANDIDATE_UNAVAILABLE', begin)
        _copy_integration(self.model, self.batch_source_data, context)
        state = context.get('state', context.get('source_state', context))
        qvel = np.asarray(state['qvel'])
        if not np.isfinite(qvel).all() or abs(qvel[0]) < .01:
            return self._missing({'context_id': context['context_id']}, 'CURRENT_DIRECTION_UNAVAILABLE', begin)
        buf = self.buffers['C']
        np.copyto(buf.health, context['health_vector'])
        np.copyto(buf.tau_raw, action['tau_raw'])
        np.copyto(buf.tau_sent, action['tau_sent'])
        buf.request.x0 = float(np.asarray(context['backup_anchor_q_init'])[0])
        buf.request.direction = 1. if qvel[0] > 0. else -1.
        buf.output.actual_steps = 0
        buf.output.state_count = 0
        owner = str(context['context_id']) + ':G' + str(action['gamma'])
        token = budget.reserve_steps('PREFIX_PREDICTION', owner, 10) if budget is not None else None
        native_begin = perf_counter()
        try:
            rc = int(self._fn(self._model_pointer,
                ctypes.c_void_p(int(self.batch_source_data._address)), ctypes.c_void_p(int(buf.data._address)),
                ctypes.byref(buf.request), ctypes.byref(buf.output)))
        finally:
            if budget is not None:
                budget.finish_steps(token, int(buf.output.actual_steps))
        result = self._freeze_output(buf, action, context, rc,
            (perf_counter() - native_begin) * 1000., (perf_counter() - begin) * 1000., 0, None)
        result.update(schema=VERSION, on_demand=True, native_crossings=1,
            candidate_schema=CANDIDATE_VERSION, original_native_arithmetic_unchanged=True,
            raw_status_preserved=True)
        return result
