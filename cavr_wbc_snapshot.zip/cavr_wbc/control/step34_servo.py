"""STEP34 unchanged six-axis PID with current-candidate validity bridge."""
from __future__ import annotations
from time import perf_counter
import numpy as np
from cavr_wbc.control.step20_task_reference import reference
from cavr_wbc.control.step22_pose_servo import (
    AUTHORITY_GATE_FRACTION, CONTROL_DT_S, GAINS, INTEGRAL_LIMITS, tangent_pose_error)
from cavr_wbc.control.step34_candidate import capacity_interface, VERSION as CAPACITY_VERSION

class ResidentServo:
    """Original STEP22 six-axis PID, resident scratch and no per-tick adapters."""
    def __init__(self, model, q_init=None, d_m=0., configuration='S22_POSE_PID'):
        if configuration != 'S22_POSE_PID':
            raise ValueError('STEP34 retains frozen six-axis pose PID')
        self.model = model
        self.q_init = np.zeros(int(model.nq)); self.q_init[3] = 1.
        self.q_reference = np.zeros(int(model.nq))
        self.b_integral = np.zeros(6)
        self.v_reference = np.zeros(6)
        self.feedforward = np.zeros(6)
        self.d = 0.
        self.configuration = "S22_POSE_PID"
        self.gains = dict(GAINS[self.configuration])
        self.pose_error_calls = self.integral_update_calls = 0
        if q_init is not None:
            self.reset(q_init, d_m)

    def reset(self, q_init, d=0., integral=None):
        values = np.asarray(q_init, dtype=float)
        b = np.zeros(6) if integral is None else np.asarray(integral, dtype=float)
        if (values.shape != self.q_init.shape or not np.isfinite(values).all()
                or not np.isclose(np.linalg.norm(values[3:7]), 1., atol=1e-10)
                or b.shape != (6,) or not np.isfinite(b).all() or np.any(np.abs(b) > INTEGRAL_LIMITS)
                or not np.isfinite(d)):
            raise ValueError("STEP27 servo reset reference/integral is malformed")
        self.q_init[:] = values
        self.d = float(d)
        self.b_integral[:] = b

    def reference_at(self, data, tick):
        return reference(float(self.q_init[0]), self.d, int(tick) * CONTROL_DT_S)

    def compute(self, controller, data, health, tick):
        begin = perf_counter()
        if int(tick) != tick or tick < 0:
            raise ValueError("STEP27 tick must be a nonnegative integer")
        h = controller._health(health)
        before = self.b_integral.copy()
        ref = self.reference_at(data, tick)
        finite = bool(np.isfinite(data.qpos).all() and np.isfinite(data.qvel).all()
                      and np.isfinite(before).all())
        e_pose = e_vel = a_base = target = None
        if finite:
            self.q_reference[:] = data.qpos
            self.q_reference[:7] = self.q_init[:7]
            self.q_reference[0] = ref["p_ref_m"]
            e_pose = tangent_pose_error(self.model, data.qpos, self.q_reference)
            self.pose_error_calls += 1
            self.v_reference.fill(0.); self.v_reference[0] = ref["v_ref_m_s"]
            self.feedforward.fill(0.); self.feedforward[0] = ref["a_ref_m_s2"]
            e_vel = self.v_reference - data.qvel[:6]
            a_base = self.feedforward + self.gains["kp_s_inv2"] * e_pose + self.gains["kd_s_inv"] * e_vel + before
            target = {"desired_base_accel": a_base, "desired_joint_accel": np.zeros(int(self.model.nu)),
                      "task_weights": np.ones(6 + int(self.model.nu)), "servo_configuration": self.configuration,
                      "com_velocity": ref["v_ref_m_s"], "com_height": float(self.q_init[2]),
                      "p_max": 1., "target_position": ref["p_ref_m"]}
            raw = controller.compute(data, "B1", h, target)
        else:
            raw = {"success": False, "status": "NONFINITE_INPUT_STATE", "status_val": None,
                   "tau": None, "qdd": None, "contact_force": None, "validation": {}, "solver_calls": 0}
        interface = capacity_interface(raw, h, controller._healthy_limits)
        valid = bool(interface["command_valid"])
        sent = interface["tau_sent"]
        active = interface["sent_99_percent_active_indices"]
        updated = bool(valid and finite and not len(active))
        reason = "NONFINITE_STATE" if not finite else "INVALID_COMMAND" if not valid else "ACTUATOR_AUTHORITY_SATURATED" if len(active) else None
        proposed = before + CONTROL_DT_S * self.gains["ki_s_inv3"] * e_pose if finite else None
        if updated:
            self.b_integral[:] = np.clip(proposed, -INTEGRAL_LIMITS, INTEGRAL_LIMITS)
            self.integral_update_calls += 1
        record = {"b_used": before, "b_before": before.copy(), "b_after": self.b_integral.copy(),
                  "freeze_reason": reason, "updated": updated, "limits": INTEGRAL_LIMITS.copy(),
                  "authority_gate_saturated_actuators": active.copy(), "authority_gate_fraction": AUTHORITY_GATE_FRACTION,
                  "current_health_torque_limits_nm": interface["effective_capacity_nm"],
                  "zero_capacity_saturated_actuators": np.flatnonzero(interface["effective_capacity_nm"] <= 0.),
                  "state_unit": ["m/s^2"] * 3 + ["rad/s^2"] * 3,
                  "qp_calls_this_tick": int(finite), "update_uses_current_pose_error_after_single_qp": True,
                  "raw_authority_gate_saturated_actuators": interface["raw_99_percent_active_indices"],
                  "sent_authority_gate_saturated_actuators": active,
                  "raw_sent_authority_gate_equal": interface["raw_sent_99_percent_gate_equal"],
                  "capacity_interface_version": CAPACITY_VERSION,
                  "six_axis_updated": [updated] * 6, "six_axis_frozen": [not updated] * 6,
                  "six_axis_freeze_reasons": [reason] * 6,
                  "proposed_unclipped_b_after": proposed,
                  "six_axis_clipped": (updated & (np.abs(proposed) > INTEGRAL_LIMITS)) if proposed is not None else np.zeros(6, dtype=bool)}
        # Raw/algebraic residuals remain validated before send.  Their detailed
        # per-axis matrix explanation is materialized only post-ready.
        diagnostics = {"available": False, "raw_qdd_is_actual_acceleration": False}
        if valid:
            meta = getattr(controller, "last_meta", {})
            if meta:
                residual = meta["M"] @ raw["qdd"] + meta["bias"] - meta["B"] @ sent - meta["Jc"].T @ raw["contact_force"]
                diagnostics.update(available=True, sent_dynamics_residual_inf=float(np.max(np.abs(residual))),
                                   sent_dynamics_residual_signed=residual,
                                   raw_qp_base_acceleration_error=np.asarray(raw["qdd"][:6]) - a_base)
                if not np.isfinite(residual).all():
                    raise ValueError("STEP27 sent residual is nonfinite")
        latency = (perf_counter() - begin) * 1000.
        pre_send = {"exact_solved": interface["solver_exact_solved"],
                    "finite_shape_correct_full_raw_variables": valid,
                    "sent_within_full_channel_capacity": interface["sent_command_within_capacity_exact"],
                    "raw_residuals_evaluated_before_send": bool(raw.get("validation")),
                    "candidate_valid": valid, "candidate_schema": CAPACITY_VERSION,
                    "raw_optimizer_status": raw.get("status_val"),
                    "strict_candidate_mask": raw.get("strict_candidate_mask", False),
                    "sent_residual_finite": bool(diagnostics["available"]),
                    "no_new_residual_threshold": True}
        return {"candidate_valid": valid, "candidate_schema": CAPACITY_VERSION,
                "candidate_certificate": raw.get("candidate_certificate"),
                "optimizer_converged": raw.get("optimizer_converged", False),
                "strict_candidate_mask": raw.get("strict_candidate_mask", False),
                "wbc": raw, "wb": raw, "raw_solver_result": raw,
                "raw_solver_variables": {"tau": raw.get("tau"), "qdd": raw.get("qdd"),
                                         "contact_force": raw.get("contact_force"), "source": "THIS_REAL_OPTIMIZER_RETURN_BEFORE_STRICT_DECODE"},
                "capacity_interface": interface, "raw_QP_success": bool(raw.get("success")),
                "raw_QP_bound_exact_pass": interface["raw_command_within_capacity_exact"],
                "tau_cmd": sent, "valid_command": valid, "latency_ms": latency, "command_ready_ms": latency,
                "configuration": self.configuration, "external_reference": ref,
                "q_reference": self.q_reference.copy() if finite else None,
                "measured_p_m": float(data.qpos[0]) if finite else None,
                "measured_v_m_s": float(data.qvel[0]) if finite else None,
                "e_pose": e_pose, "e_vel": e_vel, "v_reference": self.v_reference.copy() if finite else None,
                "a_feedforward": self.feedforward.copy() if finite else None, "a_base_ref": a_base,
                "target_before_method_transform": target, "integral_record": record,
                "execution_diagnostics": diagnostics,
                "pre_send_validation": pre_send,
                "timing": {"assembly_ms": raw.get("kernel_assembly_ms"),
                           "assembly_subblocks": raw.get("assembly_subblocks", {}),
                           "assembly_thread_cpu_ms": raw.get("kernel_assembly_thread_cpu_ms"),
                           "assembly_gc_collections_before": raw.get("assembly_gc_collections_before"),
                           "assembly_gc_collections_after": raw.get("assembly_gc_collections_after"),
                           "nested_not_additive": True,
                           "decode_ms": raw.get("kernel_decode_ms"),
                           "setup_ms": 1000. * float(raw.get("setup_time_s") or 0.),
                           "update_ms": 1000. * float(raw.get("update_time_s") or 0.),
                           "solve_wall_ms": 1000. * float(raw.get("solve_wall_time_s") or 0.),
                           "capacity_interface_ms": interface["capacity_interface_ms"],
                           "servo_control_ms": latency},
                "execution_view": {"command_valid": valid, "tau_sent": sent, "version": CAPACITY_VERSION}}


CapacityPoseServo = ResidentServo
