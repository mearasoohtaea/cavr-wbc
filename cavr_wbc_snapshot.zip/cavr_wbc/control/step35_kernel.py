"""Unchanged STEP34 injured numerical path, with every current raw return retained.

Only reference owners change precision. These owners retain 1e-7 and the
original 3ms/6ms limits. Disk persistence happens after packet command-ready.
"""
import os
from cavr_wbc.control.step34_candidate import CandidateWBC as BaseWBC
from cavr_wbc.control.step34_kernel import Kernel as BaseKernel

EPS_FIELDS = ('configured_eps_abs', 'configured_eps_rel', 'actual_setup_eps_abs',
              'actual_setup_eps_rel', 'step35_global_qp_index')


class InjuredWBC(BaseWBC):
    def __init__(self, model, solve_callback=None):
        super().__init__(model, solve_callback=solve_callback)
        if self.cfg.osqp_eps_abs != 1e-7 or self.cfg.osqp_eps_rel != 1e-7:
            raise ValueError('STEP35 injured precision must remain1e-7')
        self.solver_owner_scope = 'STEP35_INJURED_UNCHANGED_EPS1E7'
        self.solver_owner_id = f'{os.getpid()}:{self.solver_owner_scope}:{id(self)}'
        self.pending_raw_evidence = []

    def _default_solve(self, problem, *, max_iter_override=None):
        result = super()._default_solve(problem, max_iter_override=max_iter_override)
        key = self._workspace_key({'P': problem['P'], 'A': problem['A']})
        cache = self._solver_cache[key]
        if not result['workspace_reused']:
            cache['actual_setup_eps_abs'] = float(self.cfg.osqp_eps_abs)
            cache['actual_setup_eps_rel'] = float(self.cfg.osqp_eps_rel)
        if cache.get('actual_setup_eps_abs') != 1e-7 or cache.get('actual_setup_eps_rel') != 1e-7:
            raise ValueError('injured owner reused another precision workspace')
        result.update(configured_eps_abs=float(self.cfg.osqp_eps_abs), configured_eps_rel=float(self.cfg.osqp_eps_rel),
                      actual_setup_eps_abs=cache['actual_setup_eps_abs'], actual_setup_eps_rel=cache['actual_setup_eps_rel'])
        return result

    def _invoke(self, problem, stage, **kwargs):
        raw = super()._invoke(problem, stage, **kwargs)
        budget = getattr(self, 'evidence_budget', None)
        if budget is not None:
            raw['step35_global_qp_index'] = budget.qp_calls
        return raw

    def _decode(self, out, meta, method):
        result = super()._decode(out, meta, method)
        result.update({key: out[key] for key in EPS_FIELDS if key in out})
        self.pending_raw_evidence.append((result, getattr(self, 'evidence_kind', 'UNKNOWN'), getattr(self, 'evidence_owner', 'UNKNOWN')))
        return result


class Kernel(BaseKernel):
    def __init__(self, model, variant='BOUNDED', prefixdll=None, budget=None):
        super().__init__(model, variant, prefixdll, budget)
        self._shadow_controllers = {name: InjuredWBC(model) for name in ('C', 'B')}

    def _replace_solver_owners(self):
        self.nominal_controller = InjuredWBC(self.model)
        self.backup_controller = InjuredWBC(self.model)
        self.policy.controller = self.backup_controller

    def reset(self, context):
        data = super().reset(context)
        if 'application_time_s' in context:
            # Preserve the actual ten-step prediction's complete witness bits;
            # do not replace repeated-addition time with a rounded literal.
            data.time = float(context['state']['time'])
        return data

    def reset_backup(self, current, context, preserve_ready=False):
        data = super().reset_backup(current, context, preserve_ready)
        if not preserve_ready and 'application_time_s' in context:
            data.time = float(context['state']['time'])
        return data

    def _bind(self, controller, budget, kind, owner, first_mode=None):
        active = self.budget if budget is None else budget
        controller.evidence_budget, controller.evidence_kind, controller.evidence_owner = active, kind, owner
        return super()._bind(controller, active, kind, owner, first_mode)

    def flush_raw_evidence(self):
        for controller in (self.nominal_controller, self.backup_controller):
            pending = controller.pending_raw_evidence
            while pending:
                raw, kind, owner = pending[0]
                self.budget.record_raw(raw, kind, owner)
                pending.pop(0)

    def shadow(self, sample, packet, budget=None):
        result = super().shadow(sample, packet, budget)
        active = self.budget if budget is None else budget
        for name in ('C', 'B'):
            endpoint = result.get(name) or {}
            if endpoint.get('new_QP_calls'):
                raw = {**endpoint['raw_solver_result'], 'candidate_certificate': endpoint['candidate_certificate']}
                active.record_raw(raw, 'SHADOW_' + name, sample['context_id'])
        return result
