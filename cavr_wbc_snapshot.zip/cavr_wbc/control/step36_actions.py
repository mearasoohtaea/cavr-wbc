"""Original-contract actions plus separately identified working-QP evidence.

The current convex-combination claim still concerns common original affine
rows and their original SI tolerances.  Working residuals are diagnostics,
not an additional zero-tolerance candidate acceptance requirement.
"""
from __future__ import annotations
import numpy as np
from cavr_wbc.control import step34_actions as original

VERSION = 'STEP36_ORIGINAL_AND_WORKING_ACTION_IDENTITIES_V1'
GAMMA_GRID = original.GAMMA_GRID
SYNTHESIZED_KIND = original.SYNTHESIZED_KIND
check_rows = original.check_rows
capture_matrices = original.capture_matrices
frozen_contract = original.frozen_contract


def working_shared_identity(C, B):
    endpoints = {'C': C or {}, 'B': B or {}}
    raw = {name: original.raw_result(ep) for name, ep in endpoints.items()}
    original_mats = {name: ep.get('source_matrices', raw[name].get('source_matrices')) for name, ep in endpoints.items()}
    same_original, original_reason = original.frozen.shared_matrices(original_mats['C'], original_mats['B'])
    fields = ('step36_original_l', 'step36_original_u', 'step36_working_l', 'step36_working_u',
        'step36_working_changed_rows', 'step36_working_friction_reserve_N')
    available = all(all(key in raw[name] for key in fields) for name in ('C', 'B'))
    same_working = bool(available and all(np.array_equal(raw['C'][key], raw['B'][key]) for key in fields))
    return {'schema': VERSION, 'original_shared_identity_pass': bool(same_original),
        'original_shared_identity_reason': original_reason,
        'working_shared_identity_available': available, 'working_shared_identity_pass': same_working,
        'working_shared_identity_gate_is_not_working_feasibility_veto': True,
        'candidate_acceptance_contract': 'UNCHANGED_ORIGINAL_A_L_U_SI_TOLERANCES',
        'working_constraint_semantics': 'FIXED_TANGENTIAL_FRICTION_UPPER_MINUS_1E_MINUS4_N',
        'working_bounds': {name: {key: raw[name].get(key) for key in fields} for name in ('C', 'B')}}


def prepare_shared(context, C, B, matrices=None):
    workspace = original.prepare_shared(context, C, B, matrices)
    workspace.working_shared_identity = working_shared_identity(C, B)
    identity = workspace.working_shared_identity
    if identity['working_shared_identity_available'] and not identity['working_shared_identity_pass']:
        raise ValueError('STEP36 paired current working-bound production identity mismatch')
    return workspace


def make_action(context, C, B, gamma, matrices=None, workspace=None):
    ws = workspace if workspace is not None else prepare_shared(context, C, B, matrices)
    action = original.make_action(context, C, B, gamma, matrices, ws)
    action.update(schema=VERSION, step36_working_shared_identity=ws.working_shared_identity,
        current_command_acceptance_contract='ORIGINAL_PHYSICAL_ROWS',
        additional_working_zero_slack_acceptance_gate=False,
        optimizer_converged_problem='WORKING_FRICTION_TIGHTENED_QP',
        original_QP_optimality_claim=False)
    if action.get('command_valid') and 0. < float(gamma) < 1.:
        m = action.get('source_matrices')
        raw = original.raw_result(C or {})
        if m is not None and 'step36_working_l' in raw:
            work = dict(m, l=raw['step36_working_l'], u=raw['step36_working_u'])
            action['working_raw_hard_check_diagnostic'] = check_rows(work, action['z_raw'])
            action['working_sent_hard_check_diagnostic'] = check_rows(work, action['z_sent'])
    return action
