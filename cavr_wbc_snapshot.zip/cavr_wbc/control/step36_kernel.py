"""STEP36 interior working friction bounds and asymmetric first-packet caps.

Original CandidateWBC capture/decoding remains read-only.  Only the l/u given
to the native solver are copied and tightened; original physical acceptance
and all future physics checks are unchanged.
"""
from __future__ import annotations
from time import perf_counter
import os
import numpy as np
from cavr_wbc.control.step35_kernel import Kernel as BaseKernel, InjuredWBC
from cavr_wbc.control.step34_kernel import METHODS
from cavr_wbc.control.step29_kernel import DEADLINE_S, FINAL_RESERVE_S, MIN_SOLVER_S
from cavr_wbc.control.step29_actions import frozen_contract
from cavr_wbc.control.step27_resident_kernel import reset_workspace_warmstart
from cavr_wbc.control.step36_actions import GAMMA_GRID, prepare_shared, make_action

VERSION = 'STEP36_INTERIOR_FRICTION_B6_C3_KERNEL_V1'
FRICTION_RESERVE_N = 1e-4
FIRST_B_QP_LIMIT_UPPER_S = .006
FIRST_C_QP_LIMIT_UPPER_S = .003
FEEDBACK_QP_LIMIT_UPPER_S = .006
WORKING_FIELDS = ('step36_original_l', 'step36_original_u', 'step36_working_l', 'step36_working_u',
    'step36_working_changed_rows', 'step36_working_row_families', 'step36_working_row_units',
    'step36_working_friction_reserve_N', 'step36_working_constraint_semantics',
    'step36_optimizer_status_problem', 'step36_original_contract_acceptance_unchanged',
    'step36_P_q_A_unchanged', 'step36_global_qp_index')


def tighten_working_bounds(problem, nv=18, nu=12, nc=12, row_units=None):
    """Validate the exact original four-foot tangential rows; copy l/u only."""
    if (nv, nu, nc) != (18, 12, 12):
        raise ValueError('STEP36 interior rule requires the current frozen18/12/12 row layout')
    A = problem['A'].toarray() if hasattr(problem['A'], 'toarray') else np.asarray(problem['A'])
    low, high = np.asarray(problem['l']), np.asarray(problem['u'])
    start = 2 * nv + nc + nu
    rows = np.asarray([start + 5 * foot + k for foot in range(4) for k in range(4)], dtype=int)
    if A.shape != (80, 42) or low.shape != (80,) or high.shape != (80,):
        raise ValueError('STEP36 original affine physical row layout mismatch')
    if row_units is None:
        contract = frozen_contract()
        row_units = tuple(r['unit'] for r in contract.document['dynamics_rows']) + tuple(
            r['unit'] for r in contract.document['contact_rows']) + (
            ('m/s^2',) * 3 + ('rad/s^2',) * (nv - 3) + ('N*m',) * nu + ('N',) * 20)
    if len(row_units) != 80 or any(row_units[row] != 'N' for row in rows):
        raise ValueError('STEP36 tangential friction rows must retain original N units')
    if not np.all(np.isneginf(low[rows])) or not np.all(high[rows] == 0.):
        raise ValueError('STEP36 must start from original friction l=-inf/u=0, not already-working bounds')
    normal_rows = [start + 5 * foot + 4 for foot in range(4)]
    families = []
    for foot in range(4):
        columns = np.arange(nv + nu + 3 * foot, nv + nu + 3 * foot + 3)
        for k, (sx, sy) in enumerate(((1., 1.), (1., -1.), (-1., 1.), (-1., -1.))):
            row = start + 5 * foot + k
            coefficients = A[row]
            expected = np.zeros(42)
            expected[columns[:2]] = (sx, sy)
            mu = -float(coefficients[columns[2]])
            expected[columns[2]] = -mu
            if not np.isfinite(mu) or mu <= 0. or not np.array_equal(coefficients, expected):
                raise ValueError('STEP36 changed row is not the current four-sign tangential friction family')
            families.append('TANGENTIAL_FRICTION_FOOT' + str(foot) + '_SIGN' + str(k))
    original_l, original_u = low.copy(), high.copy()
    working_l, working_u = low.copy(), high.copy()
    working_u[rows] = -FRICTION_RESERVE_N
    if not np.array_equal(working_u[normal_rows], original_u[normal_rows]):
        raise ValueError('STEP36 normal-force rows unexpectedly changed')
    working = dict(problem, l=working_l, u=working_u)
    evidence = {'step36_original_l': original_l, 'step36_original_u': original_u,
        'step36_working_l': working_l.copy(), 'step36_working_u': working_u.copy(),
        'step36_working_changed_rows': rows, 'step36_working_row_families': tuple(families),
        'step36_working_row_units': tuple(row_units[row] for row in rows),
        'step36_working_friction_reserve_N': FRICTION_RESERVE_N,
        'step36_working_constraint_semantics': 'ORIGINAL_QP_WITH_16_TANGENTIAL_FRICTION_UPPER_MINUS_1E_MINUS4_N',
        'step36_optimizer_status_problem': 'WORKING_FRICTION_TIGHTENED_QP',
        'step36_original_contract_acceptance_unchanged': True, 'step36_P_q_A_unchanged': True}
    return working, evidence


class WorkingWBC(InjuredWBC):
    def __init__(self, model, solve_callback=None):
        super().__init__(model, solve_callback=solve_callback)
        self.solver_owner_scope = 'STEP36_INTERIOR_FRICTION_EPS1E7_B6_C3_FB6'
        self.solver_owner_id = f'{os.getpid()}:{self.solver_owner_scope}:{id(self)}'

    def _default_solve(self, problem, *, max_iter_override=None):
        working, evidence = tighten_working_bounds(problem, self.nv, self.nu, 12,
            row_units=getattr(self, 'working_row_units', None))
        result = super()._default_solve(working, max_iter_override=max_iter_override)
        result.update(evidence)
        return result

    def _invoke(self, problem, stage, **kwargs):
        # The parent still freezes the ORIGINAL same-call CSC problem.
        result = super()._invoke(problem, stage, **kwargs)
        if 'step35_global_qp_index' in result:
            result['step36_global_qp_index'] = result['step35_global_qp_index']
        return result

    def _decode(self, out, meta, method):
        result = super()._decode(out, meta, method)
        result.update({key: out[key] for key in WORKING_FIELDS if key in out})
        z = result.get('full_current_raw_x')
        if z is not None and np.asarray(z).shape == (42,) and np.isfinite(z).all():
            value = out['step34_problem']['A'] @ np.asarray(z)
            rows = out['step36_working_changed_rows']
            result['step36_working_friction_Az'] = value[rows].copy()
            result['step36_working_friction_upper_violation_N'] = np.maximum(value[rows] - out['step36_working_u'][rows], 0.)
            result['step36_original_friction_upper_violation_N'] = np.maximum(value[rows] - out['step36_original_u'][rows], 0.)
            result['step36_working_residual_is_diagnostic_not_acceptance'] = True
        result['original_QP_optimality_claim'] = False
        if self.solver_ledger:
            self.solver_ledger[-1].update({key: result[key] for key in WORKING_FIELDS if key in result and
                key not in ('step36_original_l', 'step36_original_u', 'step36_working_l', 'step36_working_u')})
            self.solver_ledger[-1]['original_QP_optimality_claim'] = False
        # InjuredWBC enqueued this same result dictionary before returning;
        # adding fields here preserves true working bounds in pending raw NPZ.
        return result


class Kernel(BaseKernel):
    def __init__(self, model, variant='BOUNDED', prefixdll=None, budget=None):
        super().__init__(model, variant, prefixdll, budget)
        self._shadow_controllers = {name: WorkingWBC(model) for name in ('C', 'B')}
        self.version = VERSION

    def _replace_solver_owners(self):
        self.nominal_controller = WorkingWBC(self.model)
        self.backup_controller = WorkingWBC(self.model)
        self.policy.controller = self.backup_controller

    def solver_owner_identity(self):
        identity = super().solver_owner_identity()
        identity['scope'] = 'STEP36_INTERIOR_FRICTION_B6_C3_FB6'
        return identity

    def nominal(self, context, budget=None, kind='NOMINAL', owner=None):
        if self._next_call_limit is None:
            self.set_next_call_limit(FIRST_C_QP_LIMIT_UPPER_S)
        if self._next_call_limit > FIRST_C_QP_LIMIT_UPPER_S:
            raise ValueError('STEP36 nominal first/startup C may not exceed3 ms')
        return super().nominal(context, budget, kind, owner)

    def compute_backup(self, context, slot, budget=None, kind='ACTUAL_B', owner=None):
        if self._next_call_limit is None:
            self.set_next_call_limit(FIRST_B_QP_LIMIT_UPPER_S if int(slot) == 0 else FEEDBACK_QP_LIMIT_UPPER_S)
        return super().compute_backup(context, slot, budget, kind, owner)

    def _endpoints(self, sample, context, packet, active, deadline=None):
        packet['first_QP_native_limits_s'] = {'B': None, 'C': None}
        packet['first_QP_native_limit_upper_s'] = {'B': FIRST_B_QP_LIMIT_UPPER_S, 'C': FIRST_C_QP_LIMIT_UPPER_S}
        for name, cap in (('B', FIRST_B_QP_LIMIT_UPPER_S), ('C', FIRST_C_QP_LIMIT_UPPER_S)):
            if active is not None:
                active.check()
            t = perf_counter()
            # Every restoration/copy is inside the absolute sample window.
            self.reset(context)
            limit = cap if deadline is None else min(cap, deadline - perf_counter() - FINAL_RESERVE_S)
            if limit < MIN_SOLVER_S:
                packet[name] = {'status': 'NOT_EVALUATED_BUDGET', 'command_valid': False,
                    'requested_native_limit_upper_s': cap, 'actual_native_limit_s': None}
                packet['phase_latency_ms'][name + '_QP_and_contract_ms'] = (perf_counter() - t) * 1000.
                continue
            self.set_next_call_limit(limit)
            fn = self.first_backup if name == 'B' else self.nominal
            packet[name] = fn(context, active, 'FIRST_' + packet['method'] + '_' + name, sample['context_id'])
            packet[name]['requested_native_limit_upper_s'] = cap
            packet[name]['actual_native_limit_s'] = limit
            packet['first_QP_native_limits_s'][name] = limit
            if name == 'B':
                self._capture_packet(packet)
            packet['phase_latency_ms'][name + '_QP_and_contract_ms'] = (perf_counter() - t) * 1000.
        return prepare_shared(context, packet.get('C'), packet.get('B'))

    def _packet_base(self, sample, active, method):
        context, packet = super()._packet_base(sample, active, method)
        packet.update(schema=VERSION, first_QP_native_limits_s={'B': None, 'C': None},
            first_QP_native_limit_upper_s={'B': FIRST_B_QP_LIMIT_UPPER_S, 'C': FIRST_C_QP_LIMIT_UPPER_S},
            working_friction_upper_N=-FRICTION_RESERVE_N,
            original_friction_acceptance_upper_N=0., original_inequality_extra_slack=0.,
            working_QP_not_equivalent_to_original_QP=True)
        packet.pop('first_QP_native_time_limit_s', None)
        return context, packet

    def startup(self, home_context, budget=None):
        """Root-called one-time healthy-home priming: precisely two true QPs.

        A command may fail the exact-Solved gate while its OSQP workspace is
        successfully initialized.  Readiness is the initialized-workspace
        condition, and command validity is reported separately.
        """
        if self._startup_complete:
            return self.startup_record
        if self._startup_started:
            raise RuntimeError("STEP28 startup failed or is already active; no implicit re-priming")
        health = np.asarray(home_context["health_vector"], dtype=float)
        b_used = np.asarray(home_context["nominal_b_used"], dtype=float)
        if (not np.array_equal(health, np.ones(int(self.model.nu)))
                or b_used.shape != (6,) or not np.array_equal(b_used, np.zeros(6))
                or float(home_context["nominal_d_m"]) != 0. or int(home_context["source_tick"]) != 0):
            raise ValueError("STEP28 priming requires fixed healthy home, zero reference displacement/integral, tick zero")
        saved = home_context.get("state", home_context.get("source_state", home_context))
        if (not np.array_equal(np.asarray(home_context["nominal_q_init"]), np.asarray(saved["qpos"]))
                or not np.array_equal(np.asarray(home_context["backup_anchor_q_init"]), np.asarray(saved["qpos"]))):
            raise ValueError("STEP28 home priming references must equal the healthy home state")
        self._startup_started = True
        self._startup_active = True
        begin = perf_counter()
        before = self.setup_count
        nominal = backup = None
        try:
            self.reset(home_context)
            nominal = self.nominal(home_context, budget, "STARTUP_PRIMING_NOMINAL", self.variant + ":HOME")
            self.reset_backup(self.data, home_context)
            backup = self.compute_backup(home_context, 0, budget, "STARTUP_PRIMING_BACKUP", self.variant + ":HOME")
            self.ready = bool(self.nominal_controller._solver_cache and self.backup_controller._solver_cache)
            # Independent-case memory is restored after priming.  Symbolic
            # structures and initialized OSQP objects stay owned by the kernel.
            self.reset(home_context)
            self.reset_backup(self.data, home_context)
            reset_workspace_warmstart(self.nominal_controller)
            reset_workspace_warmstart(self.backup_controller)
            prime_valid = bool(nominal["command_valid"] and backup["valid_command"])
            preparation_ms = (perf_counter() - begin) * 1000.
            self.startup_record = {"schema": VERSION, "kernel_variant": self.variant,
                "inner_kernel_variant": self.inner_variant, "ready": self.ready,
                "status": "READY" if self.ready and prime_valid else
                          "READY_PRIMING_COMMAND_UNAVAILABLE" if self.ready else "NOT_READY",
                "healthy_home_only": True, "priming_QP_calls":
                    len(nominal["solver_ledger"]) + len(backup["solver_ledger_delta"]),
                "nominal_priming_status_val": nominal["solver_status_val"],
                "backup_priming_status_val": backup["wbc"]["status_val"],
                "nominal_priming_command_valid": bool(nominal["command_valid"]),
                "backup_priming_command_valid": bool(backup["valid_command"]),
                "nominal_priming_command_ready_ms": float(nominal["command_ready_ms"]),
                "backup_priming_command_ready_ms": float(backup["command_ready_ms"]),
                "construction_ms": self.cold_construction_ms, "preparation_ms": preparation_ms,
                "startup_ms": self.cold_construction_ms + preparation_ms,
                "setup_count": self.setup_count, "startup_setup_delta": self.setup_count - before,
                "solver_native_limit_s_by_owner": {'C': .003, 'B': .006},
                "actual_nominal_owner_scope": self.nominal_controller.solver_owner_scope,
                "actual_backup_owner_scope": self.backup_controller.solver_owner_scope,
                "working_friction_upper_N": -FRICTION_RESERVE_N,
                "original_candidate_contract_preserved": True,
                "source_servo_memory_restored": True, "independent_primal_dual_zeroed": True,
                "prefix_MjData_preallocated": 2, "prefix_integrations_during_startup": 0,
                "setup_events": [dict(row) for row in self.setup_events]}
            self._startup_complete = True
            active = self.budget if budget is None else budget
            if active is not None and hasattr(active, "event"):
                active.event("STARTUP_READY_RESULT", **self.startup_record)
            return self.startup_record
        finally:
            self._startup_active = False
    def collect_actions(self, sample, budget=None, method='APPLICATION_FEAS_GOV'):
        active = self.budget if budget is None else budget
        begin = perf_counter()
        context, packet = self._packet_base(sample, active, method)
        packet['status'] = 'CAL_COLLECTION'
        if packet['application_prediction']['complete']:
            ws = self._endpoints(sample, context, packet, active)
            for gamma in GAMMA_GRID:
                action = make_action(context, packet['C'], packet['B'], gamma, workspace=ws)
                prefix = self._prefix_one(context, action, active) if action.get('command_valid') else None
                packet['actions'][str(gamma)] = self._entry(context, action, prefix, packet['prehold'])
                if prefix is not None:
                    packet['on_demand_prefix_order'].append(gamma)
        self._capture_packet(packet)
        packet['command_ready_ms'] = (perf_counter() - begin) * 1000.
        return packet

    def endpoint_diagnostic(self, sample, budget=None, method='APPLICATION_FEAS_GOV'):
        return self.governor(sample, None, float('nan'), budget, method, diagnostic_only=True)

    def governor(self, sample, bundle, gap, budget=None, method='APPLICATION_FEAS_GOV', decide=None, diagnostic_only=False):
        from cavr_wbc.control.step34_margin import calibrated_gammas, batch_numeric
        if method not in METHODS:
            raise ValueError('STEP34 unknown paired selection method')
        active = self.budget if budget is None else budget
        begin = perf_counter()
        deadline = begin + DEADLINE_S
        role = sample['health_kind'].split('_')[0].lower()
        grid = GAMMA_GRID if method == 'APPLICATION_FEAS_GOV' else (1., 0.)
        eligible = grid if diagnostic_only or decide is not None else calibrated_gammas(bundle, role, grid)
        context, packet = self._packet_base(sample, active, method)
        packet.update(gap_m=float(gap), deadline_ms=20., prepare_begin=begin, absolute_deadline=deadline,
            qualified_gammas=np.asarray(eligible), diagnostic_only=diagnostic_only, calibration_read=not diagnostic_only)
        last = approved = None
        if getattr(self, 'ready', False) and packet['application_prediction']['complete']:
            ws = self._endpoints(sample, context, packet, active, deadline)
            for gamma in grid:
                action = make_action(context, packet['C'], packet['B'], gamma, workspace=ws)
                last = action
                entry = self._entry(context, action, None, packet['prehold'])
                packet['actions'][str(gamma)] = entry
                if gamma not in eligible:
                    entry['evaluation_status'] = 'NOT_CALIBRATED'
                    continue
                if not action.get('command_valid'):
                    continue
                if deadline - perf_counter() < FINAL_RESERVE_S:
                    entry['evaluation_status'] = 'NOT_EVALUATED_BUDGET'
                    break
                t = perf_counter()
                prefix = self._prefix_one(context, action, active)
                entry = self._entry(context, action, prefix, packet['prehold'])
                packet['actions'][str(gamma)] = entry
                packet['on_demand_prefix_order'].append(gamma)
                packet['phase_latency_ms']['G' + str(gamma) + '_prefix_feature_ms'] = (perf_counter() - t) * 1000.
                if deadline <= perf_counter():
                    entry['evaluation_status'] = 'NOT_EVALUATED_BUDGET'
                    break
                if diagnostic_only:
                    entry['evaluation_status'] = 'DIAGNOSTIC_PREFIX_ONLY_NO_CAL_NO_SEND'
                    continue
                if entry['features26'] is None:
                    continue
                t = perf_counter()
                if decide is not None:
                    decision = decide(bundle, entry, float(gap))
                else:
                    numeric = batch_numeric(bundle, np.asarray([entry['features26']]), np.array([gamma]), [role],
                        np.asarray([prefix.get('D_prefix_m')]), prehold_d=np.asarray([packet['prehold'].get('D_prehold_m')]))
                    copied = {name: value[0].copy() if isinstance(value[0], np.ndarray) else value[0].item() if hasattr(value[0], 'item') else value[0]
                        for name, value in numeric.items()}
                    accept = bool(all(bool(numeric[name][0]) for name in ('finite_input', 'pose_gate', 'support_gate',
                        'distance_gate', 'calibration_gate', 'physical_risk_gate')) and np.all(numeric['U_T'][0] <= 1.) and numeric['U_D'][0] <= gap)
                    decision = {'accepted': accept, 'choice': gamma if accept else 'ABSTAIN', 'numeric': copied}
                gate = bool(packet['prehold'].get('complete') and packet['prehold'].get('original_physical_pass') and
                    prefix.get('complete') and prefix.get('original_physical_pass') and decision.get('accepted', False))
                entry.update(decision=decision, evaluation_status='EVALUATED', complete_at_ms=(perf_counter() - begin) * 1000.)
                packet['phase_latency_ms']['G' + str(gamma) + '_inference_ms'] = (perf_counter() - t) * 1000.
                if gate:
                    approved = action
                    break
        self._capture_packet(packet)
        elapsed = (perf_counter() - begin) * 1000.
        any_valid = any(ep.get('command_valid', ep.get('valid_command', False)) for ep in (packet['C'], packet['B']))
        sent = bool(not diagnostic_only and approved is not None and elapsed <= 20.)
        packet.update(command_ready_ms=elapsed, elapsed_ms=elapsed, overall_deadline_failure=elapsed > 20.,
            selected_action=approved if approved is not None else last, selected_gamma=approved['gamma'] if approved is not None else None,
            selected_command_sent=sent, timely_recognized_command=sent, command_available=any_valid,
            status='RECOGNIZED_SENT' if sent else 'COMPUTED_VALID_BUT_LATE' if any_valid and elapsed > 20. else 'ENDPOINT_DIAGNOSTIC' if diagnostic_only else 'ABSTAIN')
        for gamma in GAMMA_GRID:
            packet['actions'].setdefault(str(gamma), {'gamma': gamma, 'evaluation_status':
                'NOT_IN_POLICY' if gamma not in grid else 'NOT_REQUESTED_AFTER_SELECTION' if sent else 'NOT_EVALUATED_BUDGET'})
        packet['step31_backup_memory']['decision_command_ready_ms_unchanged'] = elapsed
        if approved is not None:
            approved['command_ready_ms'] = elapsed
        return packet
