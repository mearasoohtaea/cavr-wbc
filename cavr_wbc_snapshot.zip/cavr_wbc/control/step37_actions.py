"""Same original affine action contract for the two STEP37 representations."""
from cavr_wbc.control import step36_actions as previous

VERSION = 'STEP37_DIRECT_ORIGINAL_CONTRACT_ACTIONS_V1'
GAMMA_GRID = (1., .5, 0.)
SYNTHESIZED_KIND = previous.SYNTHESIZED_KIND
check_rows = previous.check_rows


def prepare_shared(context, C, B, matrices=None):
    return previous.prepare_shared(context, C, B, matrices)


def make_action(context, C, B, gamma, matrices=None, workspace=None):
    if float(gamma) not in GAMMA_GRID:
        raise ValueError('STEP37 direct panel has only C/.5/B; no additionalGamma')
    action = previous.make_action(context, C, B, gamma, matrices, workspace)
    action.update(schema=VERSION, model_authorized=False,
        action_purpose='DIRECT_OFFLINE_COUNTERFACTUAL_RECOVERY',
        original_physical_gate_unchanged=True,
        working_torque_box_inset_Nm=1e-4,
        original_QP_optimality_claim=False)
    return action
