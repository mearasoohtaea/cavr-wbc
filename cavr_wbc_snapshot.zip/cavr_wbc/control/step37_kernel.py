"""Native FULL/REDUCED resident owners for direct same-packet recovery.

Transformation is charged per call before the native invocation callback.
Unavailable reduction is not an optimizer call.  Native and physical vectors
are separately preserved, and physical branch memory is remapped each tick.
"""
from __future__ import annotations
from copy import deepcopy
from time import perf_counter
import os
import numpy as np

from cavr_wbc.control.step35_kernel import InjuredWBC
from cavr_wbc.control.step34_candidate import CandidateWBC
from cavr_wbc.control.step36_kernel import Kernel as PreviousKernel
from cavr_wbc.control.step33_kernel import _owned_solve
from cavr_wbc.control.step27_resident_kernel import reset_workspace_warmstart
from cavr_wbc.control.step37_reduction import (
    FULL, REDUCED, REPRESENTATIONS, make_working_problem, reduce_whitened,
    remap_physical_warm_start, reconstruct_physical)
from cavr_wbc.control.step37_actions import make_action, prepare_shared, GAMMA_GRID
from cavr_wbc.experiments.step31_sim import _workspace_id

VERSION = 'STEP37_DIRECT_RESIDENT_REPRESENTATIONS_V1'


class RepresentationWBC(InjuredWBC):
    def __init__(self, model, solve_callback=None, representation=FULL):
        if representation not in REPRESENTATIONS:
            raise ValueError('STEP37 unknown native representation')
        super().__init__(model, solve_callback=solve_callback)
        self.representation = representation
        self.solver_owner_scope = 'STEP37_' + representation
        self.solver_owner_id = f'{os.getpid()}:{self.solver_owner_scope}:{id(self)}'
        self.accepted_physical_z = None
        self.accepted_native_dual = None
        self.current_basis = None
        self.unavailable_evidence = []

    def reset_physical_initials(self, native_reset=True):
        if native_reset:
            reset_workspace_warmstart(self)
        self.accepted_physical_z = None
        self.accepted_native_dual = None
        self.current_basis = None

    def seed_applied_witness(self, physical_z):
        z = np.asarray(physical_z, dtype=float)
        if z.shape != (42,) or not np.isfinite(z).all():
            raise ValueError('STEP37 applied witness seed must be finite physical42')
        self.accepted_physical_z = z.copy()
        # Cross-owner seeding is only a physical numerical initial, not a copy
        # of a foreign dual, solver state or transformed coordinate cache.
        self.accepted_native_dual = None

    def capture_physical_memory(self):
        return {'schema': VERSION, 'representation': self.representation,
            'solver_owner_id': self.solver_owner_id,
            'physical_accepted_z': None if self.accepted_physical_z is None else self.accepted_physical_z.copy(),
            'native_accepted_dual': None if self.accepted_native_dual is None else self.accepted_native_dual.copy(),
            'current_basis': deepcopy(self.current_basis),
            'native_workspaces': [{'workspace_id': _workspace_id(key), 'last_x': None if value.get('last_x') is None else value['last_x'].copy(),
                'last_y': None if value.get('last_y') is None else value['last_y'].copy()}
                for key, value in self._solver_cache.items()]}

    def restore_physical_memory(self, saved):
        if saved.get('representation') != self.representation or saved.get('solver_owner_id') != self.solver_owner_id:
            raise ValueError('STEP37 B0 native/internal memory cannot be restored into another owner')
        self.accepted_physical_z = None if saved.get('physical_accepted_z') is None else np.asarray(saved['physical_accepted_z']).copy()
        self.accepted_native_dual = None if saved.get('native_accepted_dual') is None else np.asarray(saved['native_accepted_dual']).copy()
        self.current_basis = deepcopy(saved.get('current_basis'))
        by_id = {_workspace_id(key): value for key, value in self._solver_cache.items()}
        for row in saved['native_workspaces']:
            key = row['workspace_id']
            if key not in by_id:
                raise ValueError('STEP37 B0 original native residentworkspace is missing')
            cache = by_id[key]
            cache.update(last_x=None if row['last_x'] is None else np.asarray(row['last_x']).copy(),
                last_y=None if row['last_y'] is None else np.asarray(row['last_y']).copy())
            cache['solver'].warm_start(x=cache['last_x'], y=cache['last_y'])

    def _prepare_native(self, original):
        begin = perf_counter()
        working = make_working_problem(original, self.nv, self.nu, 12, getattr(self, 'working_row_units', None))
        evidence = working['evidence']
        if not working['available']:
            return {'available': False, 'status': working['status'], 'reason': working['reason'],
                'evidence': evidence, 'basis': None, 'native_problem': None,
                'prepare_ms': (perf_counter() - begin) * 1000.}
        if self.representation == FULL:
            return {'available': True, 'evidence': evidence, 'basis': None,
                'native_problem': working['working'], 'prepare_ms': (perf_counter() - begin) * 1000.}
        reduced = reduce_whitened(working['working'])
        return {'available': reduced['available'], 'status': reduced['status'], 'reason': reduced['reason'],
            'evidence': evidence, 'basis': reduced['basis'], 'native_problem': reduced['reduced'],
            'prepare_ms': (perf_counter() - begin) * 1000.}

    def _execute_native(self, prepared, max_iter_override=None):
        native = prepared['native_problem']
        native['P'].sort_indices()
        native['A'].sort_indices()
        key = self._workspace_key(native)
        cache = self._solver_cache.get(key)
        warm = None
        if self.accepted_physical_z is not None:
            warm = (self.accepted_physical_z.copy() if self.representation == FULL else
                remap_physical_warm_start(prepared['basis'], self.accepted_physical_z))
        expected_dual = 80 if self.representation == FULL else 50
        dual = self.accepted_native_dual
        if dual is not None and (dual.shape != (expected_dual,) or not np.isfinite(dual).all()):
            raise ValueError('STEP37 same row-order native dual shape/nonfinite mismatch')
        if cache is not None:
            cache['last_x'] = warm
            cache['last_y'] = None if dual is None else dual.copy()
            # If no accepted physical initial exists, explicitly zero both
            # native guesses; clearing Python cache entries alone is not enough.
            if warm is None and dual is None:
                cache['solver'].warm_start(x=cache['zero_x'], y=cache['zero_y'])
        result = _owned_solve(self, native, max_iter_override)
        cache = self._solver_cache[key]
        result.update(configured_eps_abs=float(self.cfg.osqp_eps_abs), configured_eps_rel=float(self.cfg.osqp_eps_rel),
            actual_setup_eps_abs=float(self.cfg.osqp_eps_abs), actual_setup_eps_rel=float(self.cfg.osqp_eps_rel),
            step37_warm_start_native_x=None if warm is None or not result['workspace_reused'] else warm.copy(),
            step37_warm_start_remap_applied=bool(warm is not None and result['workspace_reused']),
            step37_warm_start_physical_source=None if self.accepted_physical_z is None else self.accepted_physical_z.copy(),
            step37_warm_start_dual=None if dual is None else dual.copy(),
            step37_native_y=None if cache['last_y'] is None else cache['last_y'].copy())
        return result

    def _default_solve(self, problem, *, max_iter_override=None):
        raise RuntimeError('STEP37 native calls must enter the prepared single-call _invoke path')

    def _invoke(self, problem, stage, *, max_iter_override=None):
        original = {name: value.copy() for name, value in problem.items()}
        prepared = self._prepare_native(original)
        metadata = {**prepared['evidence'], 'step37_representation': self.representation,
            'step37_basis': prepared['basis'], 'step37_native_problem': prepared['native_problem'],
            'step37_prepare_ms': prepared['prepare_ms'], 'step34_problem': original,
            'step37_original_problem': original,
            'step37_native_dimensions': (42, 80) if self.representation == FULL else (12, 50),
            'step37_native_status_describes': self.representation + '_WORKING_QP',
            'step37_physical_equality_duals_available': self.representation == FULL,
            'step37_missing_physical_equality_duals_not_fabricated': True}
        if not prepared['available']:
            result = {**metadata, 'status': prepared.get('status', 'REDUCTION_UNAVAILABLE'), 'status_val': None,
                'x': None, 'step34_current_raw_x': None, 'step34_existing_dual': None,
                'step37_native_x': None, 'step37_native_y': None, 'step37_physical_x': None,
                'representation_unavailable_reason': prepared['reason'], 'real_optimizer_called': False,
                'solver_calls_this_tick': 0, 'new_QP_calls': 0, 'solver_call_index': None,
                'solver_owner_scope': self.solver_owner_scope, 'solver_owner_id': self.solver_owner_id}
            return result
        payload = {'stage': stage, **prepared['native_problem'], 'original_problem': original,
            'solver_call_index': self.solver_calls + 1, 'representation': self.representation}
        called, cached = False, None
        def solve_once():
            nonlocal called, cached
            if called:
                raise RuntimeError('STEP37 callback cannot execute the native solver twice')
            called = True
            self.solver_calls += 1
            self.real_optimizer_calls += 1
            cached = self._execute_native(prepared, max_iter_override)
            cached.update(real_optimizer_called=True, callback_injection=False,
                solver_call_index=self.solver_calls, solver_calls_this_tick=1)
            return cached
        if self.solve_callback is None:
            answer = solve_once()
        else:
            answer = self.solve_callback('before', payload, solve_once)
            if answer is None:
                answer = cached if called else solve_once()
            elif not called:
                raise RuntimeError('STEP37 production callback returned a result without the single native call')
            self.solve_callback('after', {**payload, 'result': answer, 'solver_call_index': self.solver_calls}, lambda: answer)
        native_x = None if answer.get('x') is None else np.asarray(answer['x']).copy()
        reconstruction_begin = perf_counter()
        physical = (native_x.copy() if self.representation == FULL and native_x is not None and native_x.shape == (42,)
            else reconstruct_physical(prepared['basis'], native_x) if self.representation == REDUCED else None)
        result = {**answer, **metadata, 'x': physical, 'step34_current_raw_x': physical,
            'step37_native_x': native_x, 'step37_physical_x': physical,
            'step34_existing_dual': answer.get('step37_native_y') if self.representation == FULL else None,
            'step37_reconstruction_ms': (perf_counter() - reconstruction_begin) * 1000.,
            'native_primal_residual': answer.get('primal_residual'), 'native_dual_residual': answer.get('dual_residual'),
            'native_residual_scope': 'ALL80_NATIVE_ROWS' if self.representation == FULL else 'REDUCED50_INEQUALITIES_ONLY'}
        budget = getattr(self, 'evidence_budget', None)
        if budget is not None:
            result['step37_global_qp_index'] = budget.qp_calls
            result['step35_global_qp_index'] = budget.qp_calls
        ledger_row = {key: value for key, value in result.items() if key in (
            'status', 'status_val', 'solver_call_index', 'real_optimizer_called', 'iterations',
            'setup_time_s', 'update_time_s', 'update_settings_time_s', 'solve_time_s', 'solve_wall_time_s',
            'polish_time_s', 'polish_status', 'warm_started', 'workspace_reused',
            'osqp_time_limit_s', 'solver_owner_scope', 'step37_representation', 'step37_global_qp_index',
            'step37_prepare_ms', 'step37_reconstruction_ms', 'native_primal_residual', 'native_dual_residual',
            'native_residual_scope')}
        ledger_row['stage'] = stage
        self.solver_ledger.append(ledger_row)
        self.current_basis = prepared['basis']
        return result

    def _decode(self, out, meta, method):
        if out.get('real_optimizer_called'):
            result = super()._decode(out, meta, method)
        else:
            # A missing representation is not a native call.  CandidateWBC's
            # original row checker remains the decoder, but its ledger append
            # decoration must not overwrite a previous real invocation.
            saved_ledger = self.solver_ledger
            self.solver_ledger = []
            try:
                result = CandidateWBC._decode(self, out, meta, method)
            finally:
                self.solver_ledger = saved_ledger
        result.update({key: value for key, value in out.items() if key.startswith('step37_') or key.startswith('step36_')})
        result.update(native_primal_residual=out.get('native_primal_residual'), native_dual_residual=out.get('native_dual_residual'),
            native_residual_scope=out.get('native_residual_scope'),
            representation_unavailable_reason=out.get('representation_unavailable_reason'),
            solver_calls_this_tick=out.get('solver_calls_this_tick', 0),
            solver_calls=out.get('solver_calls_this_tick', 0),
            original_QP_optimality_claim=False)
        if result.get('candidate_valid'):
            self.accepted_physical_z = np.asarray(result['candidate_certificate']['sent_full_primal']).copy()
            self.accepted_native_dual = None if out.get('step37_native_y') is None else np.asarray(out['step37_native_y']).copy()
        if not out.get('real_optimizer_called'):
            self.unavailable_evidence.append((result, getattr(self, 'evidence_kind', 'UNKNOWN'), getattr(self, 'evidence_owner', 'UNKNOWN')))
        return result


class FullWBC(RepresentationWBC):
    def __init__(self, model, solve_callback=None):
        super().__init__(model, solve_callback, FULL)


class ReducedWBC(RepresentationWBC):
    def __init__(self, model, solve_callback=None):
        super().__init__(model, solve_callback, REDUCED)


class Kernel(PreviousKernel):
    def __init__(self, model, variant='BOUNDED', prefixdll=None, budget=None, representation=FULL):
        if representation not in REPRESENTATIONS:
            raise ValueError('STEP37 unknown representation')
        self.representation = representation
        super().__init__(model, variant, prefixdll, budget)
        self.version = VERSION
        self._shadow_controllers = {}

    def _replace_solver_owners(self):
        self.nominal_controller = RepresentationWBC(self.model, representation=self.representation)
        self.backup_controller = RepresentationWBC(self.model, representation=self.representation)
        self.policy.controller = self.backup_controller

    def solver_owner_identity(self):
        identity = super().solver_owner_identity()
        identity['scope'] = 'STEP37_' + self.representation
        return identity

    def reset(self, context):
        data = super().reset(context)
        self.nominal_controller.reset_physical_initials(native_reset=False)
        return data

    def reset_backup(self, current, context, preserve_ready=False):
        data = super().reset_backup(current, context, preserve_ready)
        if not preserve_ready:
            self.backup_controller.reset_physical_initials(native_reset=False)
        return data

    def _packet_base(self, sample, active, method):
        context, packet = super()._packet_base(sample, active, method)
        packet.update(schema=VERSION, representation=self.representation,
            working_torque_box_inset_Nm=1e-4,
            native_problem_dimensions=(42, 80) if self.representation == FULL else (12, 50),
            model_authorized=False)
        return context, packet

    def _capture_packet(self, packet):
        result = super()._capture_packet(packet)
        result['step37_representation'] = self.representation
        memory = result['step31_backup_memory']
        if memory.get('status') == 'CAPTURED_B0' and 'step37_physical_memory' not in memory:
            memory['step37_physical_memory'] = self.backup_controller.capture_physical_memory()
            memory['step37_native_memory_owner_id'] = self.backup_controller.solver_owner_id
        return result

    def flush_raw_evidence(self):
        super().flush_raw_evidence()
        for controller in (self.nominal_controller, self.backup_controller):
            while controller.unavailable_evidence:
                raw, kind, owner = controller.unavailable_evidence[0]
                if hasattr(self.budget, 'record_unavailable'):
                    self.budget.record_unavailable(raw, kind, owner)
                else:
                    self.budget.event('QP_REPRESENTATION_UNAVAILABLE', kind=kind, owner=owner,
                        representation=controller.representation,
                        reason=raw.get('representation_unavailable_reason'), new_QP_calls=0)
                controller.unavailable_evidence.pop(0)

    def direct_packet(self, sample, budget=None):
        active = self.budget if budget is None else budget
        begin = perf_counter()
        context, packet = self._packet_base(sample, active, 'APPLICATION_FEAS_GOV')
        packet.update(schema=VERSION, representation=self.representation, method='DIRECT_' + self.representation,
            model_authorized=False, selected_command_sent=False, governor_calls=0,
            direct_counterfactual=True, actions={})
        if packet['application_prediction']['complete']:
            self._endpoints(sample, context, packet, active, begin + .020)
            shared = prepare_shared(context, packet.get('C'), packet.get('B'))
            for gamma in GAMMA_GRID:
                packet['actions'][str(gamma)] = {'gamma': gamma, 'action': make_action(context, packet['C'], packet['B'], gamma, workspace=shared),
                    'prefix': None, 'features26': None, 'model_authorized': False,
                    'evaluation_status': 'DIRECT_ORIGINAL_CURRENT_CONTRACT_ONLY'}
        self._capture_packet(packet)
        elapsed = (perf_counter() - begin) * 1000.
        packet.update(command_ready_ms=elapsed, elapsed_ms=elapsed, overall_deadline_failure=elapsed > 20.,
            status='LATE_FIRST_PACKET_OFFLINE_ONLY' if elapsed > 20. else 'DIRECT_OFFLINE_PACKET_READY',
            selected_command_sent=False, on_demand_prefix_order=[], screening_prefixes=0,
            numerical_representation=self.representation)
        packet['step31_backup_memory']['decision_command_ready_ms_unchanged'] = elapsed
        return packet

    def collect_actions(self, sample, budget=None, method=None):
        return self.direct_packet(sample, budget)

    def governor(self, *args, **kwargs):
        raise RuntimeError('STEP37 has no model/CAL/governor authorization')
