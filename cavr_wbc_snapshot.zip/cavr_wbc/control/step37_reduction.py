"""Exact affine equality elimination and objective whitening; no solver calls."""
from __future__ import annotations
from time import perf_counter
import numpy as np
import scipy.linalg as la
import scipy.sparse as sp
from cavr_wbc.control.step36_kernel import tighten_working_bounds

VERSION = 'STEP37_AFFINE_REDUCED_WHITENED_MAPPING_V1'
TORQUE_RESERVE_NM = 1e-4
FULL = 'FULL_INTERIOR_RESIDENT'
REDUCED = 'REDUCED_WHITENED_RESIDENT'
REPRESENTATIONS = (FULL, REDUCED)


def fixed_dense_csc(matrix, upper=False):
    """Explicit-zero resident CSC layout, independent of changing values."""
    value = np.asarray(matrix, dtype=float)
    nr, nc = value.shape
    if upper:
        lengths = np.minimum(np.arange(nc) + 1, nr)
        indices = np.concatenate([np.arange(n, dtype=np.int32) for n in lengths])
        data = np.concatenate([value[:n, column] for column, n in enumerate(lengths)])
        indptr = np.r_[0, np.cumsum(lengths)].astype(np.int32)
    else:
        data = value.ravel(order='F').copy()
        indices = np.tile(np.arange(nr, dtype=np.int32), nc)
        indptr = np.arange(nc + 1, dtype=np.int32) * nr
    return sp.csc_matrix((data, indices, indptr), shape=value.shape)


def make_working_problem(original, nv=18, nu=12, nc=12, row_units=None):
    """Common subset for FULL/RED: friction inset plus exact torque-box inset."""
    begin = perf_counter()
    working, evidence = tighten_working_bounds(original, nv, nu, nc, row_units)
    A = original['A'].toarray() if sp.issparse(original['A']) else np.asarray(original['A'])
    rows = np.arange(48, 60, dtype=int)
    expected = np.zeros((12, 42))
    expected[:, 18:30] = np.eye(12)
    if not np.array_equal(A[rows], expected):
        raise ValueError('STEP37 torque rows48:60 must be unchanged current tau box rows')
    if row_units is not None and any(row_units[row] != 'N*m' for row in rows):
        raise ValueError('STEP37 torque inset must retain original N*m units')
    original_low, original_high = np.asarray(original['l']), np.asarray(original['u'])
    if not (np.isfinite(original_low[rows]).all() and np.isfinite(original_high[rows]).all() and
            np.array_equal(original_low[rows], -original_high[rows])):
        raise ValueError('STEP37 expects original symmetric finite health torque bounds')
    working['l'][rows] += TORQUE_RESERVE_NM
    working['u'][rows] -= TORQUE_RESERVE_NM
    evidence.update(step36_working_l=working['l'].copy(), step36_working_u=working['u'].copy(),
        step36_working_constraint_semantics='STEP37_FRICTION_AND_TORQUE_INSET_WORKING_QP',
        step37_original_problem={name: value.copy() for name, value in original.items()},
        step37_working_problem=working,
        step37_original_l=np.asarray(original['l']).copy(), step37_original_u=np.asarray(original['u']).copy(),
        step37_working_l=working['l'].copy(), step37_working_u=working['u'].copy(),
        step37_torque_changed_rows=rows, step37_torque_box_inset_Nm=TORQUE_RESERVE_NM,
        step37_friction_changed_rows=evidence['step36_working_changed_rows'],
        step37_working_constraint_semantics='COMMON_ORIGINAL_QP_SUBSET_FRICTION1E_MINUS4_N_TORQUE1E_MINUS4_NM',
        step37_original_physical_gate_unchanged=True,
        step37_working_build_ms=(perf_counter() - begin) * 1000.)
    empty = np.flatnonzero(working['l'][rows] > working['u'][rows])
    evidence['step37_empty_torque_box_rows'] = rows[empty]
    return {'schema': VERSION, 'available': not len(empty),
        'status': 'WORKING_QP_READY' if not len(empty) else 'WORKING_QP_UNAVAILABLE',
        'reason': None if not len(empty) else 'FIXED_TORQUE_INSET_EMPTY_BOX',
        'working': working, 'evidence': evidence, 'new_QP_calls': 0}


def reduce_whitened(working):
    """Full pivoted QR, fixed machine-scale rank rule, unregularized Cholesky."""
    begin = perf_counter()
    A = working['A'].toarray() if sp.issparse(working['A']) else np.asarray(working['A'], dtype=float)
    P = working['P'].toarray() if sp.issparse(working['P']) else np.asarray(working['P'], dtype=float)
    q = np.asarray(working['q'], dtype=float)
    low, high = np.asarray(working['l'], dtype=float), np.asarray(working['u'], dtype=float)
    result = {'schema': VERSION, 'available': False, 'status': 'REDUCTION_UNAVAILABLE',
        'reason': None, 'reduced': None, 'basis': None, 'new_QP_calls': 0}
    if (A.shape != (80, 42) or P.shape != (42, 42) or q.shape != (42,) or
        low.shape != (80,) or high.shape != (80,) or not np.array_equal(low[:30], high[:30]) or
        not np.isfinite(A).all() or not np.isfinite(P).all() or not np.isfinite(q).all() or not np.isfinite(low[:30]).all()):
        result['reason'] = 'NONFINITE_OR_MALFORMED_AFFINE_ELIMINATION_INPUT'
        return result
    # OSQP stores the upper triangle; reconstruct its symmetric quadratic form.
    if not np.array_equal(P, P.T):
        if np.count_nonzero(np.tril(P, -1)):
            result['reason'] = 'PHYSICAL_HESSIAN_NOT_SYMMETRIC_OR_UPPER_TRIANGULAR'
            return result
        P = np.triu(P) + np.triu(P, 1).T
    E, b, G = A[:30].copy(), low[:30].copy(), A[30:].copy()
    qr_begin = perf_counter()
    Q, R, pivot = la.qr(E.T, mode='full', pivoting=True, check_finite=False)
    diag = np.abs(np.diag(R[:30, :]))
    rank_tolerance = np.finfo(float).eps * max(E.shape) * (float(np.max(diag)) if len(diag) else 0.)
    rank = int(np.count_nonzero(diag > rank_tolerance))
    qr_ms = (perf_counter() - qr_begin) * 1000.
    basis = {'E': E, 'b': b, 'pivot': pivot, 'Q': Q, 'R': R, 'rank': rank,
        'rank_tolerance': rank_tolerance,
        'rank_rule': 'double_eps * max(E.shape) * max(abs(diag(R)); fixed, no scan',
        'qr_ms': qr_ms, 'physical_dimension': 42, 'equality_count': 30, 'native_dimension': 12}
    result['basis'] = basis
    if rank != 30:
        result.update(reason='EQUALITY_RANK_NOT_30')
        basis['total_transform_ms'] = (perf_counter() - begin) * 1000.
        return result
    zp = Q[:, :30] @ la.solve_triangular(R[:30, :].T, b[pivot], lower=True, check_finite=False)
    N = Q[:, 30:]
    H = N.T @ P @ N
    H_symmetry = float(np.max(np.abs(H - H.T)))
    # H comes from the symmetric physical P. No Hessian regularization or
    # eigenvalue truncation is allowed; Cholesky directly decides availability.
    white_begin = perf_counter()
    try:
        L = la.cholesky(H, lower=True, check_finite=False)
    except la.LinAlgError:
        result.update(reason='REDUCED_HESSIAN_CHOLESKY_NOT_SPD')
        basis.update(zp=zp, N=N, H=H, H_symmetry_error=H_symmetry,
            total_transform_ms=(perf_counter() - begin) * 1000.)
        return result
    T = N @ la.solve_triangular(L.T, np.eye(12), lower=False, check_finite=False)
    white_ms = (perf_counter() - white_begin) * 1000.
    raw_Pr = T.T @ P @ T
    Pr_symmetry = float(np.max(np.abs(raw_Pr - raw_Pr.T)))
    Pr = .5 * (raw_Pr + raw_Pr.T)
    qr = T.T @ (P @ zp + q)
    Ar = G @ T
    shifted = G @ zp
    lr, ur = low[30:] - shifted, high[30:] - shifted
    constant = float(.5 * zp @ P @ zp + q @ zp)
    reduced = {'P': fixed_dense_csc(Pr, upper=True), 'q': qr, 'A': fixed_dense_csc(Ar), 'l': lr, 'u': ur}
    eq_error = float(np.max(np.abs(E @ zp - b)))
    null_error = float(np.max(np.abs(E @ N)))
    whiten_error = float(np.max(np.abs(Pr - np.eye(12))))
    basis.update(zp=zp, N=N, L=L, T=T, H=H, P_physical_symmetric=P,
        objective_constant=constant, H_symmetry_error=H_symmetry,
        Pr_symmetry_error=Pr_symmetry, actual_Pr=Pr,
        equality_particular_error_inf=eq_error, equality_nullspace_error_inf=null_error,
        actual_whitening_identity_error_inf=whiten_error,
        whitening_ms=white_ms, total_transform_ms=(perf_counter() - begin) * 1000.,
        symmetry_only_no_new_regularization=True, native_inequality_rows=np.arange(30, 80))
    result.update(available=True, status='REDUCED_QP_READY', reason=None, reduced=reduced,
        objective_constant=constant)
    return result


def remap_physical_warm_start(basis, physical_z):
    """Current coordinates from this branch's last applied accepted witness."""
    z = np.asarray(physical_z, dtype=float)
    if z.shape != (42,) or not np.isfinite(z).all():
        raise ValueError('STEP37 warm initial requires a finite accepted physical42 witness')
    return basis['L'].T @ (basis['N'].T @ (z - basis['zp']))


def reconstruct_physical(basis, native_x):
    x = np.asarray(native_x, dtype=float)
    if x.shape != (12,) or not np.isfinite(x).all():
        return None
    return basis['zp'] + basis['T'] @ x
