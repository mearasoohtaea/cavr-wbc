"""Fresh RED recovery and trained-only frozen three-action screening.

Feedback is calculated in private integration/PID staging. Native workspaces
retain real invocation history; only a valid ready command commits the logical
servo state and actual ctrl. No model fitting or historical trajectory access.
"""
from __future__ import annotations
from copy import deepcopy
from time import perf_counter
import gc
import mujoco
import numpy as np

from cavr_wbc.control.step37_kernel import Kernel as PreviousKernel
from cavr_wbc.control.step37_reduction import REDUCED
from cavr_wbc.control.step37_actions import GAMMA_GRID, make_action
from cavr_wbc.control.step34_servo import CapacityPoseServo
from cavr_wbc.control.step34_candidate import VERSION as CANDIDATE_VERSION
from cavr_wbc.control.step29_kernel import DEADLINE_S, FINAL_RESERVE_S
from cavr_wbc.control.step23_backup_filter import _finite_state, predicted_physical_check, HOLD_VERSION
from cavr_wbc.control.step28_physics_residual import append_prefix_features
from cavr_wbc.experiments.step26_features_storage import _compiled_mapping, _feet, _vector
from cavr_wbc.platforms.go2_mujoco import FOOT_NAMES

VERSION = 'STEP38_FRESH_REDUCED_FROZEN_SCREEN_V1'
SERVO_ARRAYS = ('q_init', 'q_reference', 'b_integral', 'v_reference', 'feedforward')
SERVO_SCALARS = ('d', 'pose_error_calls', 'integral_update_calls')


class CommitWindowError(RuntimeError):
    """Unexpected final-copy overrun; rejected evidence survives the stop."""
    def __init__(self, response):
        super().__init__('STEP38 final commit exceeded the frozen reserved window; no forward/integration performed')
        self.response = response


def current_features(context, nominal, mapping):
    """Frozen 16 feature meanings; explicit fault is not forced to travel side."""
    fact = nominal['initial_new_command_fact']
    state = context.get('state', context)
    qpos = _vector(state.get('qpos', fact.get('qpos')), 'current qpos')
    qvel = _vector(state.get('qvel', fact.get('qvel')), 'current qvel')
    if qpos.size < 7 or qvel.size < 6 or abs(qvel[0]) < .01:
        raise ValueError('STEP38 current feature state/direction unavailable')
    direction = 1. if qvel[0] > 0. else -1.
    entries = _compiled_mapping(mapping)
    side = 'FR' if direction > 0. else 'RR'
    side_entries = [e for e in entries if e['name'] in (side+'_hip', side+'_thigh', side+'_calf')]
    if len(side_entries) != 3:
        raise ValueError('STEP38 direction-side compiled joint mapping missing')
    dofs = [e.get('dof_index', e.get('dof_address')) for e in side_entries]
    if any(not isinstance(i, (int, np.integer)) or not 0 <= i < qvel.size for i in dofs):
        raise ValueError('STEP38 direction-side joint velocity mapping invalid')
    health = _vector(fact.get('health_vector', nominal.get('health_vector')), 'full health', 12)
    if np.any((health < 0.) | (health > 1.)) or not np.array_equal(health, context['health_vector']):
        raise ValueError('STEP38 feature/context full health mismatch')
    fault = context.get('faulted_actuator_index')
    name = context.get('faulted_actuator_name')
    fault_health, thigh, calf = 1., 0., 0.
    if np.any(health < 1.):
        by_index = {int(e['index']): e for e in entries}
        if (not isinstance(fault, (int, np.integer)) or int(fault) not in by_index or
            np.count_nonzero(health < 1.) != 1 or health[int(fault)] >= 1. or
            name != by_index[int(fault)]['name'] or
            name not in ('FR_thigh', 'FR_calf', 'RR_thigh', 'RR_calf')):
            raise ValueError('STEP38 explicit fault channel/name/health mismatch')
        fault_health = float(health[int(fault)])
        thigh, calf = float(name.endswith('_thigh')), float(name.endswith('_calf'))
    elif fault is not None or name not in (None, 'NONE'):
        raise ValueError('STEP38 healthy feature cannot declare a damaged actuator')
    sent = _vector(nominal.get('tau_sent', nominal.get('tau', fact.get('tau_sent', fact.get('tau_cmd')))), 'sent torque', 12)
    limits = fact.get('actuator_limits')
    if limits is None:
        limits = [e.get('healthy_limit_nm', e.get('healthy_torque_limit_nm')) for e in entries]
    capacities = health * _vector(limits, 'healthy limits', 12)
    if np.any(capacities <= 0.):
        raise ValueError('STEP38 original feature contract requires positive capacity')
    recorded = fact.get('effective_capacity_nm', nominal.get('capacity_interface', {}).get('effective_capacity_nm'))
    if recorded is not None and not np.array_equal(capacities, _vector(recorded, 'recorded capacity', 12)):
        raise ValueError('STEP38 feature effective capacity mismatch')
    com = np.asarray(fact['subtree_com'])
    if com.ndim == 2:
        com = com[int(fact['base_body_id'])]
    com = _vector(com, 'subtree COM', 3)
    feet = _feet(fact, nominal, None)
    side_feet = feet[[0, 1] if direction > 0. else [2, 3], 0]
    actual = _vector(fact.get('actual_mujoco_qacc', nominal.get('actual_mujoco_qacc')), 'actual qacc')
    desired = _vector(nominal['response']['a_base_ref'], 'desired base acceleration', 6)
    if actual.size < 6:
        raise ValueError('STEP38 current actual qacc incomplete')
    return _vector([direction*qvel[0], direction*actual[0], fact['roll'], direction*fact['pitch'],
        qvel[3], direction*qvel[4], com[2], np.min(direction*(side_feet-qpos[0])),
        fault_health, thigh, calf, np.max(np.abs(sent)/capacities), direction*desired[0],
        np.mean(qvel[dofs]), qvel[1], qvel[2]], 'STEP38 current features', 16)


def servo_memory(servo):
    return {**{name: np.asarray(getattr(servo, name)).copy() for name in SERVO_ARRAYS},
        **{name: getattr(servo, name) for name in SERVO_SCALARS}}


def restore_servo_memory(servo, memory):
    for name in SERVO_ARRAYS:
        np.copyto(getattr(servo, name), memory[name])
    for name in SERVO_SCALARS:
        setattr(servo, name, memory[name])


def release_loaded_dll_search_handles(native_prefix):
    """Release search registrations, not the already loaded DLL/native owner.

    The library and its linked MuJoCo dependencies have resolved during the
    constructor. Search-directory cookies are not solver state and need not
    accumulate for every fresh owner. No library handle or cache is closed.
    """
    handles=getattr(native_prefix,'_dll_dirs',[])
    count=len(handles)
    for handle in handles:handle.close()
    native_prefix._dll_dirs=[]
    return count


def commit_feedback(actual_data, committed_servo, staging_servo, response, begin,
                    require_sent=True, clock=perf_counter):
    """Pure-testable commit barrier; no forward/integration or native rollback.

    Prepare all command/logical copies before the deadline check. The frozen
    final 3ms reserve protects the small final committed-memory/ctrl copy. A
    late candidate never enters that copy path. Native solver history is not
    included in logical memory and is never reverted.
    """
    valid = bool(response.get('valid_command'))
    tau = None if not valid else np.asarray(response['tau_cmd']).copy()
    memory = servo_memory(staging_servo)
    original_ctrl = np.asarray(actual_data.ctrl).copy()
    original_logical = servo_memory(committed_servo)
    prepared_ms = (clock() - begin) * 1000.
    late = bool(prepared_ms > DEADLINE_S * 1000.)
    reserve_unavailable = bool(require_sent and prepared_ms > (DEADLINE_S - FINAL_RESERVE_S) * 1000.)
    committed = bool(valid and not (require_sent and (late or reserve_unavailable)))
    if committed:
        restore_servo_memory(committed_servo, memory)
        np.copyto(actual_data.ctrl, tau)
    total_ms = (clock() - begin) * 1000.
    response.update(command_ready_ms=total_ms, latency_ms=total_ms,
        staging_committed=committed, staging_discarded=not committed,
        private_staging=True, actual_ctrl_written=committed,
        logical_memory_committed=committed, native_cache_rolled_back=False,
        prepared_commit_ms=prepared_ms, final_commit_copy_ms=total_ms-prepared_ms,
        frozen_final_reserve_ms=FINAL_RESERVE_S * 1000.,
        reserve_unavailable=reserve_unavailable,
        execution_failure='NUMERICAL_UNAVAILABLE' if not valid else
            'DEADLINE_MISS' if require_sent and (late or reserve_unavailable) else None,
        within_online_deadline=bool(committed and total_ms <= 20.))
    response.setdefault('timing', {}).update(prepared_commit_ms=prepared_ms,
        final_commit_copy_ms=total_ms-prepared_ms, complete_command_ready_ms=total_ms,
        prepared_reserve_ms=(DEADLINE_S-FINAL_RESERVE_S)*1000.,
        complete_deadline_ms=DEADLINE_S*1000., nested_not_additive=True)
    if require_sent and committed and total_ms > 20.:
        # Final copies have not been followed by any actual forward or step.
        # Restore only the unadvanced ctrl/logical transaction; native cache
        # remains the true completed solver history and is never rolled back.
        np.copyto(actual_data.ctrl, original_ctrl)
        restore_servo_memory(committed_servo, original_logical)
        response.update(staging_committed=False, staging_discarded=True,
            actual_ctrl_written=False, transient_ctrl_copy_not_actuated=True,
            logical_memory_committed=False, committed_ctrl_and_PID_restored_before_forward=True,
            actual_forward_calls_before_commit=0, actual_integrations_before_commit=0,
            execution_failure='COMMIT_WINDOW_OVERRUN_IMPLEMENTATION_ERROR', within_online_deadline=False)
        raise CommitWindowError(response)
    return response


class Kernel(PreviousKernel):
    def __init__(self, model, variant='BOUNDED', prefixdll=None, budget=None, representation=REDUCED):
        if representation != REDUCED:
            raise ValueError('STEP38 only authorizes REDUCED_WHITENED_RESIDENT')
        super().__init__(model, variant, prefixdll, budget, representation)
        self.released_loaded_dll_search_registrations=release_loaded_dll_search_handles(self.native_prefix)
        self.version = VERSION
        self._feedback_staging_data = mujoco.MjData(model)
        self._feedback_staging_servo = CapacityPoseServo(model)
        self._governor_contexts = set()

    def solver_owner_identity(self):
        result = super().solver_owner_identity()
        result['scope'] = 'STEP38_FRESH_REDUCED_INDEPENDENT_LIVE_OWNER'
        return result

    def geometry_features(self, context, action):
        """Same three geometry values with explicit cross-leg fault metadata."""
        mapping = self.geometry_mapping
        state = context.get('state', context.get('source_state', context))
        qpos, qvel = np.asarray(state['qpos']), np.asarray(state['qvel'])
        health, sent = np.asarray(context['health_vector']), np.asarray(action['tau_sent'])
        if (qvel.size < 6 or abs(qvel[0]) < .01 or health.shape != (12,) or sent.shape != (12,) or
            not all(np.isfinite(v).all() for v in (qpos, qvel, health, sent)) or
            np.any((health <= 0.) | (health > 1.)) or
            np.any(mapping.qpos_addresses < 0) or np.any(mapping.qpos_addresses >= qpos.size)):
            raise ValueError('STEP38 current geometry input unavailable')
        front = bool(qvel[0] > 0.)
        calf = mapping.calf_by_direction[int(front)]
        index, name = context.get('faulted_actuator_index'), context.get('faulted_actuator_name')
        if np.any(health < 1.):
            if (not isinstance(index, (int, np.integer)) or int(index) not in range(12) or
                np.count_nonzero(health < 1.) != 1 or health[int(index)] >= 1. or
                name != mapping.names[int(index)] or name not in ('FR_thigh','FR_calf','RR_thigh','RR_calf')):
                raise ValueError('STEP38 explicit geometry fault identity mismatch')
            index = int(index)
        else:
            if index is not None or name not in (None, 'NONE'):
                raise ValueError('STEP38 healthy geometry declares a fault')
            index = -1
        if not np.array_equal(action['health_vector'], health) or not np.array_equal(
            action['capacity_interface']['healthy_torque_limits_nm'], mapping.limits):
            raise ValueError('STEP38 current geometry full health/limits mismatch')
        from cavr_wbc.control.step28_native_prefix import _pointer
        rc = int(self._geometry_fn(_pointer(qpos), len(qpos), _pointer(qvel), len(qvel), _pointer(health),
            _pointer(mapping.limits), _pointer(sent), len(sent), _pointer(mapping.qpos_addresses, True),
            index, calf, _pointer(self._geometry_buffer)))
        if rc != 0:
            raise ValueError('STEP38 native current geometry contract error')
        return self._geometry_buffer.copy()

    def features(self, context, action, prefix):
        numeric = prefix.get('numeric')
        if not prefix.get('complete') or numeric is None:
            raise ValueError('STEP38 complete independent native action prefix required')
        scalar = numeric['scalars'][0]
        matrix = action.get('source_matrices') or {}
        points = matrix.get('points')
        if points is None:
            raise ValueError('STEP38 current foot positions unavailable')
        fact = {'qpos':numeric['qpos'][0], 'qvel':numeric['qvel'][0],
            'roll':float(scalar[0]), 'pitch':float(scalar[1]), 'subtree_com':numeric['subtree_com'][0],
            'base_body_id':numeric['base_body_id'], 'health_vector':numeric['health_vector'],
            'actuator_limits':numeric['healthy_torque_limits_nm'], 'effective_capacity_nm':numeric['effective_capacity_nm'],
            'actual_mujoco_qacc':numeric['qacc'][0]}
        view = {'initial_new_command_fact':fact, 'tau_sent':action['tau_sent'],
            'response':{'a_base_ref':action['a_base_ref']},
            'foot_positions':{name:points[i] for i,name in enumerate(FOOT_NAMES)}}
        base = current_features(context, view, self.mapping)
        action.update(features16=base, initial_new_command_fact=fact, actual_mujoco_qacc=numeric['qacc'][0].copy())
        result = np.r_[append_prefix_features(base, prefix, action, context), action['gamma'], self.geometry_features(context, action)]
        if result.shape != (26,) or not np.isfinite(result).all():
            raise ValueError('STEP38 finite original26-vector required')
        return result

    def direct_packet(self, sample, budget=None, owners=None):
        if owners is None:
            raise ValueError('STEP38 direct packet requires three independent branch owners')
        return direct_packet(self, sample, self.budget if budget is None else budget, owners)

    def governor(self, sample, bundle, gap, budget=None, method='APPLICATION_FEAS_GOV'):
        from cavr_wbc.control.step34_margin import calibrated_gammas, batch_numeric
        if method != 'APPLICATION_FEAS_GOV' or sample['health_kind'] == 'HEALTHY':
            raise ValueError('STEP38 governor is only the fixed three-action injured protocol')
        cid = str(sample['context_id'])
        if cid in self._governor_contexts:
            raise ValueError('STEP38 exactly one governor call per injured context/owner')
        self._governor_contexts.add(cid)
        active = self.budget if budget is None else budget
        begin = perf_counter()
        deadline = begin + DEADLINE_S
        role = sample['health_kind'].split('_')[0].lower()
        context, packet = self._packet_base(sample, active, method)
        eligible = () if bundle is None else calibrated_gammas(bundle, role, GAMMA_GRID)
        packet.update(schema=VERSION, representation=self.representation,
            method='STEP38_FROZEN_SCREEN', gap_m=float(gap), deadline_ms=20.,
            prepare_begin=begin, absolute_deadline=deadline, qualified_gammas=np.asarray(eligible),
            calibration_read=bundle is not None, trained_source_available=bundle is not None,
            global_readiness_veto=False, model_authorized=False, governor_calls=1,
            step37_branch_owners={name:self.solver_owner_identity() for name in ('C','MIDDLE','B')})
        approved = None
        if getattr(self, 'ready', False) and packet['application_prediction']['complete']:
            workspace = self._endpoints(sample, context, packet, active, deadline)
            for gamma in GAMMA_GRID:
                action = make_action(context, packet.get('C'), packet.get('B'), gamma, workspace=workspace)
                action.update(action_purpose='FROZEN_SCREEN_CURRENT_CANDIDATE', model_authorized=False)
                entry = self._entry(context, action, None, packet['prehold'])
                packet['actions'][str(gamma)] = entry
                if not action.get('command_valid'):
                    continue
                if gamma not in eligible:
                    entry['evaluation_status'] = 'TRAINED_SOURCE_UNAVAILABLE' if bundle is None else 'NOT_CALIBRATED'
                    continue
                if deadline - perf_counter() < FINAL_RESERVE_S:
                    entry['evaluation_status'] = 'NOT_EVALUATED_BUDGET'
                    break
                t = perf_counter()
                prefix = self._prefix_one(context, action, active)
                entry = self._entry(context, action, prefix, packet['prehold'])
                packet['actions'][str(gamma)] = entry
                packet['on_demand_prefix_order'].append(gamma)
                packet['phase_latency_ms']['G'+str(gamma)+'_prefix_feature_ms'] = (perf_counter()-t)*1000.
                if deadline - perf_counter() < FINAL_RESERVE_S:
                    entry['evaluation_status'] = 'NOT_EVALUATED_BUDGET'
                    break
                if entry['features26'] is None:
                    continue
                t = perf_counter()
                numeric = batch_numeric(bundle, np.asarray([entry['features26']]), np.array([gamma]), [role],
                    np.asarray([prefix.get('D_prefix_m')]), prehold_d=np.asarray([packet['prehold'].get('D_prehold_m')]))
                copied = {name:deepcopy(value[0]) for name,value in numeric.items()}
                gates = ('finite_input','pose_gate','support_gate','distance_gate','calibration_gate','physical_risk_gate')
                accepted = bool(all(bool(numeric[name][0]) for name in gates) and
                    np.all(numeric['U_T'][0] <= 1.) and numeric['U_D'][0] <= gap and
                    packet['prehold'].get('complete') and packet['prehold'].get('original_physical_pass') and
                    prefix.get('complete') and prefix.get('original_physical_pass'))
                entry.update(decision={'accepted':accepted,'choice':gamma if accepted else 'ABSTAIN','numeric':copied},
                    evaluation_status='EVALUATED', complete_at_ms=(perf_counter()-begin)*1000.)
                packet['phase_latency_ms']['G'+str(gamma)+'_inference_gates_ms'] = (perf_counter()-t)*1000.
                if accepted:
                    approved = action
                    break
        self._capture_packet(packet)
        packet['step37_B0_physical_memory'] = deepcopy(packet['step31_backup_memory'].get('step37_physical_memory'))
        packet['selected_action'] = deepcopy(approved)
        elapsed = (perf_counter()-begin)*1000.
        sent = bool(approved is not None and elapsed <= 20.)
        if packet['selected_action'] is not None:
            packet['selected_action'].update(command_ready_ms=elapsed, model_authorized=sent)
        packet.update(command_ready_ms=elapsed, elapsed_ms=elapsed, overall_deadline_failure=elapsed>20.,
            selected_gamma=None if approved is None else float(approved['gamma']), selected_command_sent=sent,
            timely_recognized_command=sent, model_authorized=sent,
            status='RECOGNIZED_SENT' if sent else 'COMPUTED_VALID_BUT_LATE' if approved is not None else 'ABSTAIN',
            selected_packet_copy_in_command_ready=True, all_gate_metadata_copy_in_command_ready=True)
        packet['step31_backup_memory']['decision_command_ready_ms_unchanged'] = elapsed
        for gamma in GAMMA_GRID:
            packet['actions'].setdefault(str(gamma), {'gamma':gamma,'evaluation_status':'NOT_REQUESTED_AFTER_SELECTION' if approved is not None else 'NOT_EVALUATED'})
        return packet

    def feedback_transaction(self, actual_data, context, slot, budget=None, kind='ACTUAL_B', owner=None,
                             require_sent=True, physical_seed=None, b0_packet=None, prepare_callback=None):
        """Complete prepare/seed/configure/check/copy window before ACTUAL commit."""
        begin = perf_counter()
        # STEP49 preparation shares the original transaction clock. No QP or
        # physical/logical copy is reached after a rejected or late callback.
        preparation_callback = None
        if prepare_callback is not None:
            preparation_callback = timed_prepare(prepare_callback, begin, require_sent)
            if not preparation_callback['accepted']:
                return rejected_prepare(preparation_callback)
        gc_feedback_before = tuple(row['collections'] for row in gc.get_stats())
        active = self.budget if budget is None else budget
        if self.policy.controller is not self.backup_controller or self.policy.servo is not self.backup_servo:
            raise ValueError('STEP38 feedback aliases changed')
        committed = servo_memory(self.backup_servo)
        staging = self._feedback_staging_servo
        restore_servo_memory(staging, committed)
        mujoco.mj_copyData(self._feedback_staging_data, self.model, actual_data)
        staged_data = self._feedback_staging_data
        previous = self._last_backup_slot
        preparation = {'status':'SAME_BRANCH_COMMITTED_MEMORY', 'new_QP_calls':0}
        if b0_packet is not None:
            memory = b0_packet.get('step31_backup_memory') or {}
            physical = b0_packet.get('step37_B0_physical_memory')
            B = b0_packet.get('B') or {}
            if (memory.get('status') != 'CAPTURED_B0' or memory.get('context_id') != context['context_id'] or
                memory.get('backup_id') != context['backup_id'] or physical is None or
                b0_packet.get('step34_solver_owner') != self.solver_owner_identity() or
                not np.array_equal(memory['integral_b_after'], B['integral_record']['b_after'])):
                raise ValueError('STEP38 same-owner B0 logical/physical checkpoint mismatch')
            self.backup_controller.restore_physical_memory(physical)
            np.copyto(staging.b_integral, memory['integral_b_after'])
            previous = 0
            preparation = {'status':'RESTORED_APPLICATION_PACKET_B0','logical_last_slot':0,
                'new_QP_calls':0,'no_cross_owner_native_internal_state_copy':True,
                'physical_application_state_not_replaced':True}
        elif physical_seed is not None:
            self.backup_controller.seed_applied_witness(physical_seed)
            preparation = {'status':'OWN_BRANCH_APPLIED_PHYSICAL_WITNESS_SEED','new_QP_calls':0,
                'source':'THIS_BRANCH_ALREADY_APPLIED_SENT_WITNESS', 'foreign_native_x_y_internal_state_copied':False}
        if (self._backup_context_id != str(context['context_id']) or self.policy.backup_id != context['backup_id'] or
            (previous is not None and int(slot) != previous+1) or (previous is None and int(slot) not in (0,1))):
            raise ValueError('STEP38 feedback current identity/logical slot mismatch')
        old_physical = None if self.backup_controller.accepted_physical_z is None else self.backup_controller.accepted_physical_z.copy()
        self.configure_feedback(context)
        self._configure(self.backup_controller)
        self._bind(self.backup_controller, active, kind, owner or context['context_id'], 'BACKUP')
        cursor, setups = len(self.backup_controller.solver_ledger), self.backup_controller.solver_setup_calls
        prepared_at = perf_counter()
        response = staging.compute(self.backup_controller, staged_data, context['health_vector'], slot)
        response['prepare_callback'] = preparation_callback
        response.update(backup_id=self.policy.backup_id, backup_version=getattr(self.policy, 'version', HOLD_VERSION),
            fixed_anchor_q_init=self.policy.anchor_q_init)
        raw, interface = response['wbc'], response['capacity_interface']
        valid = bool(response['valid_command'])
        scratch = 0
        fact = None
        t = perf_counter()
        if valid:
            np.copyto(staged_data.ctrl, response['tau_cmd'])
            mujoco.mj_forward(self.model, staged_data)
            scratch = 1
            fact = self.physical_fact(staged_data, context, interface, response['latency_ms'], int(slot), int(slot)*10) if _finite_state(staged_data) else None
        response.update(current_physical_check=predicted_physical_check(fact or {}), initial_new_command_fact=fact,
            source_matrices=raw.get('source_matrices'), solver_status_val=raw.get('status_val'),
            command_valid=valid, tau_raw=interface['tau_raw'], tau_sent=response['tau_cmd'],
            health_vector=np.asarray(context['health_vector']).copy(), invalid_command_not_applied=not valid,
            solver_ledger_delta=self.backup_controller.solver_ledger[cursor:], scratch_forward_calls=scratch,
            feedback_preparation=preparation, staging_data_copy_calls=1,
            actual_forward_calls_before_commit=0, actual_integrations_before_commit=0)
        response['pre_send_validation']['current_physical_check'] = response['current_physical_check']
        response['timing'].update(feedback_prepare_seed_configure_ms=(prepared_at-begin)*1000.,
            scratch_action_forward_and_check_ms=(perf_counter()-t)*1000.,
            complete_command_ready_scope='PREPARE_SEED_CONFIGURE_PRIVATE_PID_SOLVE_CHECK_COPY_COMMIT')
        self._candidate_event(active, raw, kind, owner or context['context_id'])
        self._record_setup(self.backup_controller, setups, response, kind, owner or context['context_id'], active)
        response['timing'].update(feedback_gc_collections_before=gc_feedback_before,
            feedback_gc_collections_after=tuple(row['collections'] for row in gc.get_stats()))
        try:
            response = commit_feedback(actual_data, self.backup_servo, staging, response, begin, require_sent)
        except CommitWindowError as exc:
            self.backup_controller.accepted_physical_z = old_physical
            # A rare scheduler/copy overrun is an implementation/resource stop,
            # not ordinary panel data. Preserve the raw return and rejected
            # transaction before unwinding; actual data has not been advanced.
            self.flush_raw_evidence()
            if active is not None and hasattr(active, 'out'):
                from cavr_wbc.experiments.step38_io import save_numeric, relative
                index = getattr(active, 'qp_calls', 0)
                path = active.out / 'staging_errors' / ('COMMIT_QP'+str(index).zfill(6)+'.json')
                asset = save_numeric(path, {'response':exc.response,
                    'actual_ctrl_after_rejection':np.asarray(actual_data.ctrl).copy(),
                    'committed_PID_after_rejection':servo_memory(self.backup_servo),
                    'logical_slot_before':self._last_backup_slot,
                    'actual_time_s_unchanged':float(actual_data.time),
                    'no_actual_forward_or_integration':True, 'native_cache_rolled_back':False})
                active.event('FEEDBACK_COMMIT_WINDOW_IMPLEMENTATION_ERROR', owner=owner or context['context_id'],
                    path=relative(path, active.out), npz_sha256=asset['npz_sha256'],
                    command_ready_ms=exc.response['command_ready_ms'], actual_physics_not_advanced=True)
                active.persist(phase='STAGING_COMMIT_ERROR_EVIDENCE_SAVED')
            raise
        if response['staging_committed']:
            self._last_backup_slot, self._last_backup_response = int(slot), response
        else:
            self.backup_controller.accepted_physical_z = old_physical
        return response


def timed_prepare(callback, begin, require_sent=True, clock=perf_counter):
    result = callback()
    elapsed = (clock()-begin)*1000.
    accepted = bool(result.get('accepted', True))
    late = bool(require_sent and elapsed > 17.)
    return dict(result, accepted=accepted and not late, callback_ms=elapsed,
                gate_accepted=accepted, late=late,
                execution_failure='DEADLINE_MISS' if late else
                    result.get('execution_failure', 'PHASE1_GATE_FAILED') if not accepted else None)


def rejected_prepare(preparation):
    return dict(valid_command=False, command_valid=False, tau_cmd=None,
        capacity_interface={}, wbc={}, a_base_ref=[], solver_ledger_delta=[],
        command_ready_ms=preparation['callback_ms'], latency_ms=preparation['callback_ms'],
        staging_committed=False, staging_discarded=True, actual_ctrl_written=False,
        within_online_deadline=False, prepare_callback=preparation,
        execution_failure=preparation['execution_failure'], new_QP_calls=0,
        actual_forward_calls_before_commit=0, actual_integrations_before_commit=0,
        timing=dict(prepare_callback_ms=preparation['callback_ms'],
                    prepared_commit_ms=preparation['callback_ms'],
                    complete_command_ready_ms=preparation['callback_ms']))


def direct_packet(kernel, sample, budget, owners):
    """STEP37 sprint helper semantics including its true top-level B0 memory."""
    if set(owners) != {'C','MIDDLE','B'} or owners['B'] is not kernel:
        raise ValueError('STEP38 direct packet B owner and three-branch table mismatch')
    begin = perf_counter()
    context, packet = kernel._packet_base(sample, budget, 'APPLICATION_FEAS_GOV')
    packet.update(schema=VERSION, method='STEP38_DIRECT_RECOVERY_REDUCED', representation=REDUCED,
        status='DIRECT_OFFLINE_COUNTERFACTUAL_RECOVERY', model_authorized=False, selected_command_sent=False,
        stage='APPLICATION_PACKET', step37_branch_owners={name:k.solver_owner_identity() for name,k in owners.items()},
        no_CAL_model_or_governor=True, absolute_deadline=begin+.020, deadline_ms=20.)
    if packet['application_prediction']['complete']:
        workspace = kernel._endpoints(sample, context, packet, budget, deadline=begin+.020)
        for gamma in GAMMA_GRID:
            action = make_action(context, packet.get('C'), packet.get('B'), gamma, workspace=workspace)
            packet['actions'][str(gamma)] = {'action':action,'screening_prefix_status':'NOT_REQUESTED_BY_DIRECT_PROTOCOL'}
    kernel._capture_packet(packet)
    packet['step37_B0_physical_memory'] = deepcopy(packet['step31_backup_memory'].get('step37_physical_memory'))
    packet['command_ready_ms'] = (perf_counter()-begin)*1000.
    packet['first_packet_timing_status'] = 'FIRST_PACKET_TIMELY_OFFLINE' if packet['command_ready_ms']<=20. else 'LATE_FIRST_PACKET_OFFLINE_ONLY'
    packet['step31_backup_memory']['decision_command_ready_ms_unchanged'] = packet['command_ready_ms']
    return packet
