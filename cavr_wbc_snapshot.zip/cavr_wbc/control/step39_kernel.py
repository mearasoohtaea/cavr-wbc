"""Matched 28-input V2 shortlist on STEP38 unchanged staged RED owners."""
from copy import deepcopy
from time import perf_counter
import numpy as np
from cavr_wbc.control.step38_kernel import Kernel as SourceKernel, direct_packet
from cavr_wbc.control.step37_actions import make_action
from cavr_wbc.control.step29_kernel import DEADLINE_S,FINAL_RESERVE_S
VERSION='STEP39_MATCHED_SCREEN_V2'
GAMMA_GRID=(.5,0.)
def fault_bits(context,mapping):
    h=np.asarray(context['health_vector'])
    name=context.get('faulted_actuator_name')
    ix=context.get('faulted_actuator_index')
    if np.all(h==1):
        if ix is not None or name not in (None,'NONE'): raise ValueError('healthy fault metadata')
        return np.zeros(2)
    entries={int(r.get('actuator_index',r.get('index'))):r.get('actuator_name',r.get('name')) for r in mapping}
    if ix not in entries or entries[ix]!=name or np.count_nonzero(h<1)!=1 or h[ix]>=1:
        raise ValueError('real compiled fault name/index mismatch')
    if name not in ('FR_thigh','FR_calf','RR_thigh','RR_calf'):raise ValueError('unregistered fault')
    return np.array([float(name.startswith('FR_')),float(name.startswith('RR_'))])
class Kernel(SourceKernel):
    def features(self,context,action,prefix):
        return np.r_[super().features(context,action,prefix),fault_bits(context,self.mapping)]
    def _entry(self,context,action,prefix,prehold):
        entry=super()._entry(context,action,prefix,prehold)
        entry['features28']=entry.pop('features26')
        entry['role']=context['role']
        return entry
    def governor(self, sample, bundle, gap, budget=None, method='APPLICATION_FEAS_GOV'):
        from cavr_wbc.control.step39_margin import calibrated_gammas, batch_numeric
        if method != 'APPLICATION_FEAS_GOV' or sample['health_kind'] == 'HEALTHY':
            raise ValueError('STEP39 governor is only the fixed two-action injured protocol')
        cid = str(sample['context_id'])
        if cid in self._governor_contexts:
            raise ValueError('STEP39 exactly one governor call per injured context/owner')
        self._governor_contexts.add(cid)
        active = self.budget if budget is None else budget
        begin = perf_counter()
        deadline = begin + DEADLINE_S
        role = sample['role']
        context, packet = self._packet_base(sample, active, method)
        eligible = () if bundle is None else calibrated_gammas(bundle, role, GAMMA_GRID)
        packet.update(schema=VERSION, representation=self.representation,
            method='STEP39_FROZEN_SCREEN', gap_m=float(gap), deadline_ms=20.,
            prepare_begin=begin, absolute_deadline=deadline, qualified_gammas=np.asarray(eligible),
            calibration_read=bundle is not None, trained_source_available=bundle is not None,
            global_readiness_veto=False, model_authorized=False, governor_calls=1,
            step37_branch_owners={name:self.solver_owner_identity() for name in ('C','MIDDLE','B')})
        approved = None
        if getattr(self, 'ready', False) and packet['application_prediction']['complete']:
            workspace = self._endpoints(sample, context, packet, active, deadline)
            for gamma in GAMMA_GRID:
                action = make_action(context, packet.get('C'), packet.get('B'), gamma, workspace=workspace)
                action.update(action_purpose='FROZEN_SCREEN_CURRENT_CANDIDATE', model_authorized=False)
                entry = self._entry(context, action, None, packet['prehold'])
                packet['actions'][str(gamma)] = entry
                if not action.get('command_valid'):
                    continue
                if gamma not in eligible:
                    entry['evaluation_status'] = 'TRAINED_SOURCE_UNAVAILABLE' if bundle is None else 'NOT_CALIBRATED'
                    continue
                if deadline - perf_counter() < FINAL_RESERVE_S:
                    entry['evaluation_status'] = 'NOT_EVALUATED_BUDGET'
                    break
                t = perf_counter()
                prefix = self._prefix_one(context, action, active)
                entry = self._entry(context, action, prefix, packet['prehold'])
                packet['actions'][str(gamma)] = entry
                packet['on_demand_prefix_order'].append(gamma)
                packet['phase_latency_ms']['G'+str(gamma)+'_prefix_feature_ms'] = (perf_counter()-t)*1000.
                if deadline - perf_counter() < FINAL_RESERVE_S:
                    entry['evaluation_status'] = 'NOT_EVALUATED_BUDGET'
                    break
                if entry['features28'] is None:
                    continue
                t = perf_counter()
                numeric = batch_numeric(bundle, np.asarray([entry['features28']]), np.array([gamma]), [role],
                    np.asarray([prefix.get('D_prefix_m')]), prehold_d=np.asarray([packet['prehold'].get('D_prehold_m')]))
                copied = {name:deepcopy(value[0]) for name,value in numeric.items()}
                ablation_u=float(numeric['U_D'][0]+.0009)
                entry['reserve_ablation']={'main_R_m':.0001,'ablation_R_m':.001,
                    'main_U_D_m':float(numeric['U_D'][0]),'ablation_U_D_m':ablation_u,
                    'main_local_eligible':bool(numeric['U_D'][0]<=gap),
                    'ablation_local_eligible':bool(ablation_u<=gap),'same_prefix_features':True,
                    'new_QP_or_prefix_calls':0}
                gates = ('finite_input','pose_gate','support_gate','distance_gate','calibration_gate','physical_risk_gate')
                accepted = bool(all(bool(numeric[name][0]) for name in gates) and
                    np.all(numeric['U_T'][0] <= 1.) and numeric['U_D'][0] <= gap and
                    packet['prehold'].get('complete') and packet['prehold'].get('original_physical_pass') and
                    prefix.get('complete') and prefix.get('original_physical_pass'))
                entry.update(decision={'accepted':accepted,'choice':gamma if accepted else 'ABSTAIN','numeric':copied},
                    evaluation_status='EVALUATED', complete_at_ms=(perf_counter()-begin)*1000.)
                packet['phase_latency_ms']['G'+str(gamma)+'_inference_gates_ms'] = (perf_counter()-t)*1000.
                if accepted:
                    approved = action
                    break
        self._capture_packet(packet)
        packet['step37_B0_physical_memory'] = deepcopy(packet['step31_backup_memory'].get('step37_physical_memory'))
        packet['selected_action'] = deepcopy(approved)
        elapsed = (perf_counter()-begin)*1000.
        sent = bool(approved is not None and elapsed <= 20.)
        if packet['selected_action'] is not None:
            packet['selected_action'].update(command_ready_ms=elapsed, model_authorized=sent)
        packet.update(command_ready_ms=elapsed, elapsed_ms=elapsed, overall_deadline_failure=elapsed>20.,
            selected_gamma=None if approved is None else float(approved['gamma']), selected_command_sent=sent,
            timely_recognized_command=sent, model_authorized=sent,
            status='RECOGNIZED_SENT' if sent else 'COMPUTED_VALID_BUT_LATE' if approved is not None else 'ABSTAIN',
            selected_packet_copy_in_command_ready=True, all_gate_metadata_copy_in_command_ready=True)
        packet['step31_backup_memory']['decision_command_ready_ms_unchanged'] = elapsed
        for gamma in GAMMA_GRID:
            packet['actions'].setdefault(str(gamma), {'gamma':gamma,'evaluation_status':'NOT_REQUESTED_AFTER_SELECTION' if approved is not None else 'NOT_EVALUATED'})
        packet['ablation_final_choice_identified']=bool(packet['on_demand_prefix_order']==[.5,0.] or
            (packet['on_demand_prefix_order']==[.5] and
             packet['actions']['0.5'].get('reserve_ablation',{}).get('ablation_local_eligible')))
        packet['ablation_final_choice_if_unqueried_B']='UNIDENTIFIED'
        return packet
