"""Frozen causal CAL boxes; empirical support, never a safety certificate."""
from types import MappingProxyType
import numpy as np
from cavr_wbc.control.step39_margin import FEATURE_NAMES

AXES = ('v_now', 'v_prefix_end', 'u_sent_max')
UNITS = ('m/s', 'm/s', '1')
FEATURES = ('direction_vx_m_s', 'prefix_direction_vx20_m_s', 'sent_capacity_utilization_max')
INDICES = tuple(FEATURE_NAMES.index(name) for name in FEATURES)
EPS_RELATIVE = 1e-12


def stratum_key(gamma, direction, leg, role='thigh', health=.15):
    if gamma not in (.5, 0.) or direction not in (-1, 1) or leg not in ('FR', 'RR') or role != 'thigh' or health != .15:
        raise ValueError('unregistered terminal domain stratum')
    return f'{float(gamma)}:{role}:{int(direction)}:{leg}:{health}'


def causal_axes(features, action, context, mapping):
    """Read named raw speeds and full-channel sent/capacity, not future peaks."""
    x = np.asarray(features, dtype=float)
    if x.shape != (28,) or not np.isfinite(x).all():
        raise ValueError('raw causal features28 unavailable')
    interface = action.get('capacity_interface') or {}
    sent = np.asarray(action.get('tau_sent'), dtype=float)
    health = np.asarray(action.get('health_vector'), dtype=float)
    limits = np.asarray(interface.get('healthy_torque_limits_nm'), dtype=float)
    names = [r['actuator_name'] for r in mapping]
    indices = [int(r['actuator_index']) for r in mapping]
    expected_limits = np.asarray([r['healthy_limit_nm'] for r in mapping], dtype=float)
    if indices != list(range(len(indices))) or len(indices) != 12 or len(set(names)) != 12:
        raise ValueError('full actuator mapping unavailable')
    if any(a.shape != (12,) or not np.isfinite(a).all() for a in (sent, health, limits)):
        raise ValueError('full sent/capacity interface unavailable')
    capacity = health * limits
    if np.any(capacity <= 0.) or np.any(health > 1.):
        raise ValueError('nonpositive or invalid capacity')
    if (not np.array_equal(limits, expected_limits) or
        not np.array_equal(health, np.asarray(context['health_vector'])) or
        not np.array_equal(health, np.asarray(interface.get('health_vector'))) or
        not np.array_equal(sent, np.asarray(interface.get('tau_sent'))) or
        not np.array_equal(capacity, np.asarray(interface.get('effective_capacity_nm')))):
        raise ValueError('current action/health/compiled mapping mismatch')
    ix = context.get('faulted_actuator_index')
    name = context.get('faulted_actuator_name')
    if not isinstance(ix, (int, np.integer)) or ix not in range(12) or names[ix] != name:
        raise ValueError('fault index/name mismatch')
    leg = name[:2]
    if (name != leg + '_thigh' or health[ix] != .15 or np.count_nonzero(health < 1.) != 1 or
        x[8] != .15 or x[9] != 1. or x[10] != 0. or
        tuple(x[26:28]) != ((1., 0.) if leg == 'FR' else (0., 1.)) or
        x[22] != action['gamma']):
        raise ValueError('causal fault/gamma feature identity mismatch')
    key = stratum_key(action['gamma'], int(x[23]), leg, context['role'], .15)
    utilization = float(np.max(np.abs(sent) / capacity))
    if not np.isclose(utilization, x[INDICES[2]], rtol=0., atol=EPS_RELATIVE):
        raise ValueError('raw feature/full-channel current utilization mismatch')
    return key, np.asarray([x[INDICES[0]], x[INDICES[1]], utilization])


def build_table(records, mapping):
    """All planned records enter; failed labels never select or trim ranges."""
    if len({r['id'] for r in records}) != len(records):
        raise ValueError('duplicate CAL record')
    strata = {}
    for gamma in (.5, 0.):
        for direction in (1, -1):
            for leg in ('FR', 'RR'):
                key = stratum_key(gamma, direction, leg)
                planned = [r for r in records if r['stratum'] == key]
                finite = [r for r in planned if r.get('axes') is not None and np.isfinite(r['axes']).all()]
                complete = [r for r in finite if r['complete_terminal_evaluation']]
                snapshots = {r['snapshot'] for r in complete}
                episodes = {r['episode'] for r in complete}
                lo = np.min([r['axes'] for r in finite], axis=0) if finite else np.full(3, np.nan)
                hi = np.max([r['axes'] for r in finite], axis=0) if finite else np.full(3, np.nan)
                eps = EPS_RELATIVE * np.maximum.reduce([np.ones(3), np.abs(lo), np.abs(hi)])
                strata[key] = dict(planned=len(planned), finite=len(finite), complete=len(complete),
                    distinct_complete_snapshots=len(snapshots), distinct_complete_episodes=len(episodes),
                    ready=len(snapshots) >= 4 and len(episodes) >= 2,
                    lo=lo, hi=hi, epsilon=eps, axes=list(AXES), units=list(UNITS),
                    records=[r['id'] for r in planned], finite_ids=[r['id'] for r in finite],
                    complete_ids=[r['id'] for r in complete], source_hashes={r['id']:r['source_hashes'] for r in planned})
    return dict(schema='STEP41_RAW_CAUSAL_TERMINAL_CAL_DOMAIN_V1', strata=strata,
        mapping=mapping, feature_names=list(FEATURE_NAMES), axis_feature_names=list(FEATURES),
        axis_feature_indices=list(INDICES), units=list(UNITS), epsilon_relative=EPS_RELATIVE,
        min_complete_snapshots=4, min_complete_episodes=2, records=records,
        fit_calls=0, new_CAL_trajectories=0, raw_features_not_reverse_standardized=True,
        label_filtering=False, empirical_axis_box_not_joint_or_formal_coverage=True)


class ResidentDomain:
    def __init__(self, table, digest):
        self.digest = digest
        self.mapping = tuple(MappingProxyType(dict(r)) for r in table['mapping'])
        groups = {}
        for key, group in table['strata'].items():
            arrays = {}
            for name in ('lo', 'hi', 'epsilon'):
                value = np.asarray(group[name], dtype=float).copy()
                value.flags.writeable = False
                arrays[name] = value
            groups[key] = MappingProxyType(dict(ready=group['ready'], **arrays,
                complete=group['complete'], snapshots=group['distinct_complete_snapshots'],
                episodes=group['distinct_complete_episodes']))
        self.groups = MappingProxyType(groups)

    def check(self, features, action, context):
        try:
            key, x = causal_axes(features, action, context, self.mapping)
        except (ValueError, KeyError, TypeError, IndexError) as exc:
            return dict(accepted=False, reason='INPUT_UNAVAILABLE', detail=str(exc),
                axes=None, stratum=None, table_sha256=self.digest)
        group = self.groups[key]
        axis_pass = (x >= group['lo'] - group['epsilon']) & (x <= group['hi'] + group['epsilon'])
        ready = bool(group['ready'])
        accepted = bool(ready and axis_pass.all())
        return dict(accepted=accepted, reason='IN_DOMAIN' if accepted else
            'STRATUM_UNREADY' if not ready else 'OUTSIDE_CAUSAL_CAL_RANGE',
            axes=x, axis_pass=axis_pass, rejected_axes=[AXES[i] for i in range(3) if not axis_pass[i]],
            stratum=key, ready=ready, lo=group['lo'].copy(), hi=group['hi'].copy(),
            epsilon=group['epsilon'].copy(), complete_samples=group['complete'],
            distinct_complete_snapshots=group['snapshots'], distinct_complete_episodes=group['episodes'],
            units=list(UNITS), feature_indices=list(INDICES), table_sha256=self.digest)
