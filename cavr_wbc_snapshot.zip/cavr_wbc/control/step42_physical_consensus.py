"""Original-local4 CAL physical unanimity, never a replacement neighbor search."""
import numpy as np
from cavr_wbc.control.step39_margin import group_key

VERSION = 'STEP42_ORIGINAL_LOCAL4_PHYSICAL_CONSENSUS_V1'

def check_consensus(bundle, gamma, role, numeric):
    evidence = dict(version=VERSION, group_key=group_key(gamma, role),
        accepted=False, reasons=[], local_cal_indices=None, neighbors=[],
        original_neighbor_selection_unchanged=True, new_QP_or_prefix_calls=0,
        query_physical_probability=numeric.get('physical_pass_probability'),
        original_physical_threshold=numeric.get('local_physical_threshold'),
        four_distinct_snapshots=False, at_least_two_episodes=False)
    def reject(reason):
        evidence['reasons'].append(reason)
        return evidence
    group = (bundle or {}).get('groups', {}).get(evidence['group_key'])
    if group is None:
        return reject('CAL_GROUP_UNAVAILABLE')
    indices = np.asarray(numeric.get('local_cal_indices'))
    # Reject float/bool/negative/sentinel before indexing. -1 is never a record.
    if indices.shape != (4,) or indices.dtype.kind not in 'iu':
        return reject('INVALID_ORIGINAL_LOCAL4_INDICES')
    if np.any(indices < 0) or len(set(indices.tolist())) != 4:
        return reject('INVALID_ORIGINAL_LOCAL4_INDICES')
    required = ('cal_ids', 'cal_snapshot_ids', 'cal_episode_ids', 'cal_complete',
        'cal_physical_known', 'cal_physical_pass', 'cal_probability', 'cal_residual', 'cal_z')
    if any(name not in group for name in required):
        return reject('CAL_NEIGHBOR_FIELDS_MISSING')
    n = len(group['cal_ids'])
    if any(len(group[name]) != n for name in required) or np.any(indices >= n):
        return reject('INVALID_ORIGINAL_LOCAL4_INDICES_OR_ARRAY_LENGTH')
    distances = np.asarray(numeric.get('local_cal_distances'))
    if distances.shape != (4,) or not np.isfinite(distances).all() or np.any(distances < 0):
        return reject('CAL_NEIGHBOR_DISTANCE_NONFINITE_OR_MISSING')
    evidence['local_cal_indices'] = indices.copy()
    for name in ('cal_probability', 'cal_residual', 'cal_z'):
        if not np.isfinite(np.asarray(group[name])[indices]).all():
            return reject('CAL_NEIGHBOR_NONFINITE_'+name)
    for name in ('cal_complete', 'cal_physical_known', 'cal_physical_pass'):
        values = np.asarray(group[name])[indices]
        if values.dtype.kind not in 'biuf' or not np.isfinite(values).all() or not np.isin(values, (0, 1)).all():
            return reject('CAL_LABEL_INVALID_'+name)
    snapshots = [str(group['cal_snapshot_ids'][i]) for i in indices]
    episodes = [str(group['cal_episode_ids'][i]) for i in indices]
    identities = [str(group['cal_ids'][i]) for i in indices]
    if any(not s or s.lower() in ('none', 'nan', 'unknown') for s in snapshots+episodes+identities):
        return reject('CAL_NEIGHBOR_IDENTITY_MISSING')
    evidence['four_distinct_snapshots'] = len(set(snapshots)) == 4
    evidence['at_least_two_episodes'] = len(set(episodes)) >= 2
    evidence['neighbors'] = [
        dict(index=int(i), id=identities[j], snapshot=snapshots[j], episode=episodes[j],
             distance=float(distances[j]), complete=bool(group['cal_complete'][i]),
             physical_known=bool(group['cal_physical_known'][i]),
             physical_pass=bool(group['cal_physical_pass'][i]),
             frozen_cal_probability=float(group['cal_probability'][i]))
        for j, i in enumerate(indices)]
    evidence['failed_neighbor_count'] = sum(not r['physical_pass'] for r in evidence['neighbors'])
    evidence['unknown_neighbor_count'] = sum(not r['physical_known'] for r in evidence['neighbors'])
    evidence['incomplete_neighbor_count'] = sum(not r['complete'] for r in evidence['neighbors'])
    if not evidence['four_distinct_snapshots']:
        evidence['reasons'].append('CAL_LOCAL4_NOT_FOUR_DISTINCT_SNAPSHOTS')
    if not evidence['at_least_two_episodes']:
        evidence['reasons'].append('CAL_LOCAL4_LESS_THAN_TWO_EPISODES')
    if evidence['incomplete_neighbor_count']:
        evidence['reasons'].append('CAL_LOCAL4_INCOMPLETE')
    if evidence['unknown_neighbor_count']:
        evidence['reasons'].append('CAL_LOCAL4_PHYSICAL_UNKNOWN')
    if evidence['failed_neighbor_count']:
        evidence['reasons'].append('CAL_LOCAL4_PHYSICAL_FAILURE')
    evidence['accepted'] = not evidence['reasons']
    return evidence
