"""Preassigned experimental allocation, not a learned safety approval."""
from copy import deepcopy
from time import perf_counter
import os
from cavr_wbc.control.step38_kernel import Kernel as SourceKernel, CommitWindowError
from cavr_wbc.control.step37_actions import make_action
from cavr_wbc.control.step29_kernel import DEADLINE_S, FINAL_RESERVE_S
from cavr_wbc.control.step46_policy import TaskAwareCapacityPoseServo, TaskAwarePolicy, VERSION
from cavr_wbc.control.step34_servo import CapacityPoseServo

class Kernel(SourceKernel):
    def __init__(self, model, variant='BOUNDED', prefixdll=None, budget=None, task=False):
        super().__init__(model,variant,prefixdll,budget)
        self.task_aware=bool(task)
        self.arm_instance=f'{os.getpid()}:EXPERIMENT_ARM:{id(self)}'
        if task:
            self.backup_servo=TaskAwareCapacityPoseServo(model)
            self.policy=TaskAwarePolicy(self.backup_controller,self.backup_servo)
            self._feedback_staging_servo=TaskAwareCapacityPoseServo(model)

    def reset_backup(self,current,context,preserve_ready=False):
        if self.task_aware and not preserve_ready:
            for servo in (self.backup_servo,self._feedback_staging_servo):
                servo.freeze_source(context,self.policy.instance_id)
        return super().reset_backup(current,context,preserve_ready)

    def solver_owner_identity(self):
        result=super().solver_owner_identity()
        result.update(arm_instance=self.arm_instance,
            backup_policy=VERSION if self.task_aware else 'HOLD_ORIGINAL')
        return result

    def governor(self,*args,**kwargs):
        raise RuntimeError('STEP46 forbids learned/model/CAL/domain screening')

    def feedback_transaction(self,*args,**kwargs):
        try:
            result=super().feedback_transaction(*args,**kwargs)
        except CommitWindowError as exc:
            # Original barrier already rolled back ctrl before any real step.
            # STEP46 treats a scheduling/copy overrun as a retained partial.
            result=exc.response
            result.update(execution_failure='DEADLINE_MISS',staging_committed=False,
                within_online_deadline=False)
        result.update(policy_version=VERSION if self.task_aware else 'HOLD_ORIGINAL',
            arm_instance=self.arm_instance,
            committed_reference_clock='ACTUAL_RELATIVE_PHYSICAL_TIME',
            original_anchor_unchanged=True)
        return result

def experimental_packet(kernel,sample,budget,owners,gamma,arm,clock=perf_counter):
    """Complete prepare/check/copy/commit with unchanged 17/20 ms gates."""
    if set(owners)!={'C','MIDDLE','B'} or kernel is not owners['B' if gamma==0. else 'MIDDLE']:
        raise ValueError('experimental arm/owner table mismatch')
    begin=clock()
    context,packet=kernel._packet_base(sample,budget,'APPLICATION_FEAS_GOV')
    packet.update(method=arm,arm=arm,experimental_dispatch=True,
        dispatch_reason='PREASSIGNED_EXPERIMENT_ARM',experimental_committed=False,
        governor_selected=False,learner_approved=False,model_authorized=False,
        selected_command_sent=False,governor_calls=0,screening_calls=0,
        prepare_begin=begin,absolute_deadline=begin+DEADLINE_S,
        policy_version=VERSION if kernel.task_aware else 'HOLD_ORIGINAL',
        arm_instance=kernel.arm_instance,
        step37_branch_owners={name:k.solver_owner_identity() for name,k in owners.items()},
        first_packet_backup_owner=kernel.backup_controller.solver_owner_id,
        first_packet_nominal_owner=kernel.nominal_controller.solver_owner_id)
    action=None
    if kernel.ready and packet['application_prediction']['complete']:
        workspace=kernel._endpoints(sample,context,packet,budget,begin+DEADLINE_S)
        action=make_action(context,packet.get('C'),packet.get('B'),gamma,workspace=workspace)
    kernel._capture_packet(packet)
    packet['step37_B0_physical_memory']=deepcopy(packet['step31_backup_memory'].get('step37_physical_memory'))
    packet['actions']={str(gamma):{'action':deepcopy(action),'screening_prefix_status':'NOT_REQUESTED_BY_EXPERIMENT'}}
    packet['selected_action']=deepcopy(action)
    packet['selected_gamma']=gamma
    packet['experimental_prepared']=bool(action and action.get('command_valid') and action.get('execution_eligible')
        and packet['step31_backup_memory'].get('status')=='CAPTURED_B0')
    prepared=(clock()-begin)*1000.
    committed=bool(packet['experimental_prepared'] and prepared<=(DEADLINE_S-FINAL_RESERVE_S)*1000.)
    packet.update(prepared_commit_ms=prepared,prepared_reserve_ms=17.,
        frozen_complete_deadline_ms=20.,experimental_committed=committed,
        status='EXPERIMENT_COMMITTED' if committed else 'EXPERIMENT_LATE_UNAPPLIED' if prepared>17. else 'EXPERIMENT_COMMAND_UNAVAILABLE')
    total=(clock()-begin)*1000.
    if total>20.:
        packet.update(experimental_committed=False,status='EXPERIMENT_LATE_UNAPPLIED')
    packet.update(command_ready_ms=total,final_commit_copy_ms=total-prepared,
        overall_deadline_failure=bool(prepared>17. or total>20.),
        no_actual_forward_or_integration_before_commit=True,
        complete_scope='BEGIN_PREHOLD_PREDICTION_ENDPOINTS_STAGING_VALIDATION_COPY_COMMIT',
        actual_command_applied=False)
    packet['step31_backup_memory']['decision_command_ready_ms_unchanged']=total
    return packet
