"""Fixed 1 mm quintic base-x reference; original six-axis PID is inherited."""
import os
import numpy as np
from cavr_wbc.control.step34_servo import CapacityPoseServo
from cavr_wbc.control.step27_resident_kernel import ResidentPolicy, reset_workspace_warmstart
VERSION = 'TASK_AWARE_1MM_06S_V1'
CAP_M = .001
RAMP_S = .60
START_S = .02

def task_reference(anchor, task, physical_time):
    if not np.isfinite([anchor, task, physical_time]).all() or physical_time < -1e-12:
        raise ValueError('invalid frozen reference/physical clock')
    d = float(np.clip(task-anchor, -CAP_M, CAP_M))
    tau = max(0., float(physical_time)-START_S)
    s = float(np.clip(tau/RAMP_S, 0., 1.))
    return dict(time_s=float(physical_time), tau_s=tau,
        p_ref_m=float(anchor+d*(10*s**3-15*s**4+6*s**5)),
        v_ref_m_s=float(d*(30*s**2-60*s**3+30*s**4)/RAMP_S),
        a_ref_m_s2=float(d*(60*s-180*s**2+120*s**3)/RAMP_S**2),
        x_anchor_m=float(anchor), x_task_m=float(task), d_task_m=d,
        policy_version=VERSION, physical_time_not_call_counter=True)

class TaskAwareCapacityPoseServo(CapacityPoseServo):
    def freeze_source(self, context, policy_instance):
        self.task_anchor = float(context['backup_anchor_q_init'][0])
        self.task_goal = float(context['nominal_q_init'][0])+float(context['nominal_d_m'])
        self.task_backup_id = context['backup_id']
        self.policy_instance = policy_instance
        self.task_context_id = context['context_id']

    def reset(self, q_init, d=0., integral=None):
        if not hasattr(self, 'task_goal'):
            raise ValueError('TASK reference must be frozen before reset')
        if float(q_init[0]) != self.task_anchor:
            raise ValueError('TASK must retain original source anchor')
        super().reset(q_init, float(np.clip(self.task_goal-self.task_anchor,-CAP_M,CAP_M)), integral)

    def reference_at(self, data, tick):
        ref = task_reference(self.task_anchor, self.task_goal, float(data.time))
        ref.update(backup_id=self.task_backup_id, policy_instance=self.policy_instance,
                   servo_instance=f'{os.getpid()}:{id(self)}')
        return ref

class TaskAwarePolicy(ResidentPolicy):
    version = VERSION
    def __init__(self, controller, servo):
        self.controller, self.servo = controller, servo
        self.backup_id = 'UNINITIALIZED'
        self._anchor_q_init = np.zeros(int(servo.model.nq));self._anchor_q_init[3]=1.
        self.instance_id = f'{os.getpid()}:TASK_POLICY:{id(self)}'
    def reset(self, anchor, backup_id):
        if backup_id != self.servo.task_backup_id:
            raise ValueError('TASK frozen backup identity mismatch')
        self.servo.reset(anchor)
        self._anchor_q_init[:] = self.servo.q_init
        self.backup_id = backup_id
        reset_workspace_warmstart(self.controller)
    def compute(self, data, health, slot):
        response=self.servo.compute(self.controller,data,health,slot)
        response.update(backup_id=self.backup_id,backup_version=VERSION,
            policy_instance=self.instance_id,fixed_anchor_q_init=self.anchor_q_init)
        return response
