"""Preassigned experimental allocation, not a learned safety approval."""
from copy import deepcopy
from time import perf_counter
import os
from cavr_wbc.control.step42_kernel import Kernel as SourceKernel
from cavr_wbc.control.step38_kernel import CommitWindowError
from cavr_wbc.experiments.step47_binding import assert_policy, packet_binding
from cavr_wbc.control.step37_actions import make_action
from cavr_wbc.control.step29_kernel import DEADLINE_S, FINAL_RESERVE_S
from cavr_wbc.control.step46_policy import TaskAwareCapacityPoseServo, TaskAwarePolicy, VERSION
from cavr_wbc.control.step34_servo import CapacityPoseServo

class Kernel(SourceKernel):
    def __init__(self, model, variant='BOUNDED', prefixdll=None, budget=None, task=False, domain=None, contract=None):
        super().__init__(model,variant,prefixdll,budget,domain=domain,consensus_enabled=True)
        self.policy_contract=deepcopy(contract)
        self.task_aware=bool(task)
        self.arm_instance=f'{os.getpid()}:STEP47_OWNER:{id(self)}'
        if task:
            self.backup_servo=TaskAwareCapacityPoseServo(model)
            self.policy=TaskAwarePolicy(self.backup_controller,self.backup_servo)
            self._feedback_staging_servo=TaskAwareCapacityPoseServo(model)

    def reset_backup(self,current,context,preserve_ready=False):
        if self.task_aware and not preserve_ready:
            for servo in (self.backup_servo,self._feedback_staging_servo):
                servo.freeze_source(context,self.policy.instance_id)
        return super().reset_backup(current,context,preserve_ready)

    def solver_owner_identity(self):
        result=super().solver_owner_identity()
        result.update(arm_instance=self.arm_instance,
            backup_policy=VERSION if self.task_aware else 'HOLD_ORIGINAL')
        return result

    def _packet_base(self,sample,active,method):
        context,packet=super()._packet_base(sample,active,method)
        packet.update(policy_contract=deepcopy(self.policy_contract),
            policy_binding=packet_binding(sample,self.policy_contract),
            policy_version=VERSION if self.task_aware else 'HOLD_ORIGINAL',
            arm_instance=self.arm_instance)
        return context,packet

    def governor(self,sample,bundle,gap,budget=None,method='APPLICATION_FEAS_GOV'):
        begin=perf_counter()
        # Cross-policy rejection is before packet construction and every QP.
        assert_policy(self.policy_contract,sample,bundle,self.terminal_domain)
        packet=super().governor(sample,bundle,gap,budget,method)
        packet.update(method=sample['method'],experimental_dispatch=False,
            experimental_committed=False,governor_selected=bool(packet.get('selected_action')),
            learner_approved=bool(packet.get('selected_action')),
            dispatch_reason='POLICY_MATCHED_LEARNED_GOVERNOR',
            prepared_commit_ms=(perf_counter()-begin)*1000.,
            prepared_reserve_ms=17.,frozen_complete_deadline_ms=20.)
        prepared=packet['prepared_commit_ms']
        elapsed=(perf_counter()-begin)*1000.
        sent=bool(packet['selected_action'] is not None and prepared<=17. and elapsed<=20.)
        packet.update(command_ready_ms=elapsed,elapsed_ms=elapsed,selected_command_sent=sent,
            model_authorized=sent,timely_recognized_command=sent,
            overall_deadline_failure=bool(prepared>17. or elapsed>20.),
            status='RECOGNIZED_SENT' if sent else 'COMPUTED_VALID_BUT_LATE' if packet['selected_action'] is not None else 'ABSTAIN')
        if packet['selected_action'] is not None:
            packet['selected_action'].update(model_authorized=sent,command_ready_ms=elapsed)
        packet['step31_backup_memory']['decision_command_ready_ms_unchanged']=elapsed
        return packet

    def feedback_transaction(self,*args,**kwargs):
        try:
            result=super().feedback_transaction(*args,**kwargs)
        except CommitWindowError as exc:
            # Original barrier already rolled back ctrl before any real step.
            # STEP46 treats a scheduling/copy overrun as a retained partial.
            result=exc.response
            result.update(execution_failure='DEADLINE_MISS',staging_committed=False,
                within_online_deadline=False)
        result.update(policy_version=VERSION if self.task_aware else 'HOLD_ORIGINAL',
            arm_instance=self.arm_instance,
            committed_reference_clock='ACTUAL_RELATIVE_PHYSICAL_TIME',
            original_anchor_unchanged=True)
        return result
