"""Unchanged STEP47 control and timing, with external comparison identity."""
from cavr_wbc.control.step47_kernel import Kernel as SourceKernel
from cavr_wbc.control.step46_policy import VERSION

class Kernel(SourceKernel):
    def __init__(self,model,variant='BOUNDED',prefixdll=None,budget=None,domain=None,contract=None):
        if contract is None: raise ValueError('actual policy contract required')
        super().__init__(model,variant,prefixdll,budget,
            task=contract['policy_version']==VERSION,domain=domain,contract=contract)
    def _packet_base(self,sample,active,method):
        context,packet=super()._packet_base(sample,active,method)
        packet.update(comparison_arm=sample['comparison_arm'],
            step48_method_freeze_sha256=sample['step48_method_freeze_sha256'])
        return context,packet
