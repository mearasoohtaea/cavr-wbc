"""Original resident numerical backend with timed, same-owner phase switch."""
from cavr_wbc.control.step46_kernel import Kernel as SourceKernel
from cavr_wbc.control.step49_policy import MissionServo,MissionPolicy,VERSION

class Kernel(SourceKernel):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,task=True,**kwargs)
        self.backup_servo=MissionServo(self.model)
        self.policy=MissionPolicy(self.backup_controller,self.backup_servo)
        self._feedback_staging_servo=MissionServo(self.model)
    def solver_owner_identity(self):
        identity=super().solver_owner_identity()
        identity['backup_policy']=VERSION
        return identity
    def _packet_base(self,*args,**kwargs):
        context,packet=super()._packet_base(*args,**kwargs)
        packet.update(policy_version=VERSION,composite_policy_id=VERSION,old_CAL_certifies_mission=False)
        return context,packet
    def prepare_phase(self,data,slot,summary):
        time=float(data.time)
        arm=self.backup_servo.mission_arm
        result=dict(accepted=True,physical_time_s=time,logical_slot=slot,
            composite_policy_id=VERSION,phase_policy_id='TASK_AWARE_1MM_06S_V1',
            forced_recovery_gate=arm!='IMMEDIATE_MISSION' and slot==49,
            same_plant_id=id(data),same_controller_id=id(self.backup_controller),
            same_PID_id=id(self.backup_servo),same_backup_id=self.policy.backup_id,
            q_init_anchor_unchanged=True,warm_start_reset=False,health_restored=False)
        if slot==49:
            if abs(time-1.)>1e-9 or self._last_backup_slot!=48:
                raise ValueError('STEP49 continuous handoff clock/logical identity')
            if arm!='IMMEDIATE_MISSION':
                gate=summary.gate()
                result.update(gate=gate,accepted=gate['pass'])
                if not gate['pass']:
                    result['execution_failure']='PHASE1_GATE_FAILED'
                    return result
        active = (arm=='IMMEDIATE_MISSION' and time>=.04-1e-9) or (
            arm in ('MIDDLE_RECOVER_RESUME','B_RECOVER_RESUME') and time>=1.-1e-9)
        for servo in (self.backup_servo,self._feedback_staging_servo):
            servo.mission_active=active
        result.update(live_staging_plan_equal=self.backup_servo.mission_active==self._feedback_staging_servo.mission_active,
            phase_policy_id='STEP49_ORIGINAL_GOAL_2S_QUINTIC_V1' if active else 'TASK_AWARE_1MM_06S_V1')
        return result
    def feedback_transaction(self,*args,**kwargs):
        result=super().feedback_transaction(*args,**kwargs)
        result.update(policy_version=VERSION,composite_policy_id=VERSION,
            phase_policy_id=(result.get('external_reference') or {}).get('phase_policy_id'),
            old_CAL_certifies_mission=False)
        return result
