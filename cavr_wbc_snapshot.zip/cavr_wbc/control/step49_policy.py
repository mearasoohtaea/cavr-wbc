"""Frozen original-goal recovery/mission plan, no new PID or approval."""
import os
import numpy as np
from cavr_wbc.control.step46_policy import TaskAwareCapacityPoseServo, TaskAwarePolicy, task_reference
VERSION = 'STEP49_RECOVERY_TO_ORIGINAL_MISSION_4S_V1'
ARMS = ('MIDDLE_RECOVER_RESUME','MIDDLE_RECOVER_HOLD','IMMEDIATE_MISSION','B_RECOVER_RESUME')

def mission_reference(anchor, goal, arm, time_s, mission_active=False):
    if arm not in ARMS or not np.isfinite([anchor, goal, time_s]).all():
        raise ValueError('STEP49 frozen plan invalid')
    if not mission_active or arm == 'MIDDLE_RECOVER_HOLD':
        return dict(task_reference(anchor,goal,time_s), phase_policy_id='TASK_AWARE_1MM_06S_V1')
    start = anchor if arm == 'IMMEDIATE_MISSION' else anchor+float(np.clip(goal-anchor,-.001,.001))
    start_s = .02 if arm == 'IMMEDIATE_MISSION' else 1.
    s = float(np.clip((time_s-start_s)/2.,0.,1.))
    d = goal-start
    return dict(time_s=float(time_s),p_ref_m=float(start+d*(10*s**3-15*s**4+6*s**5)),
        v_ref_m_s=float(d*(30*s**2-60*s**3+30*s**4)/2.),
        a_ref_m_s2=float(d*(60*s-180*s**2+120*s**3)/4.),
        x_anchor_m=float(anchor),x_task_m=float(goal),x_start_m=float(start),
        mission_start_time_s=start_s,ramp_duration_s=2.,policy_version=VERSION,
        phase_policy_id='STEP49_ORIGINAL_GOAL_2S_QUINTIC_V1',physical_time_not_call_counter=True)

class MissionServo(TaskAwareCapacityPoseServo):
    def freeze_source(self,context,policy_instance):
        super().freeze_source(context,policy_instance)
        self.mission_arm=context.get('experimental_arm','MIDDLE_RECOVER_RESUME')
        self.mission_active=False
    def reference_at(self,data,tick):
        ref=mission_reference(self.task_anchor,self.task_goal,self.mission_arm,float(data.time),self.mission_active)
        ref.update(backup_id=self.task_backup_id,policy_instance=self.policy_instance,
            composite_policy_id=VERSION,servo_instance=f'{os.getpid()}:{id(self)}',
            old_CAL_certifies_mission=False)
        return ref
class MissionPolicy(TaskAwarePolicy):
    version=VERSION
