"""One first-send predicate shared by the live gate and offline evaluation."""
import math
KINDS=('LEARNED_GOVERNOR','PREASSIGNED_EXPERIMENT','PREASSIGNED_NOMINAL')
SEND_FIELDS=dict(zip(KINDS,('selected_command_sent','experimental_committed','nominal_sent')))
def first_sent(packet,context=None):
    kind=packet.get('dispatch_kind')
    if kind not in KINDS:raise ValueError('explicit STEP50 dispatch kind required')
    if kind!='LEARNED_GOVERNOR' and any(packet.get(k) for k in
        ('model_authorized','learner_approved','governor_selected','selected_command_sent')):
        raise ValueError('preassigned dispatch cannot claim learned authorization')
    action=packet.get('selected_action') or {}
    prepared=packet.get('prepared_commit_ms');complete=packet.get('command_ready_ms')
    sent=bool(packet.get(SEND_FIELDS[kind]))
    if context is not None and packet.get('context_id')!=context['context_id']:
        raise ValueError('first packet/context identity')
    if sent and kind=='LEARNED_GOVERNOR' and not all(packet.get(k) for k in
        ('model_authorized','learner_approved','governor_selected')):
        raise ValueError('learned send lost actual approval identity')
    return bool(sent and action.get('command_valid') and action.get('execution_eligible')
        and prepared is not None and complete is not None
        and math.isfinite(prepared) and math.isfinite(complete)
        and 0<=prepared<=17 and 0<=complete<=20
        and action.get('gamma') in ((.5,0.) if kind=='LEARNED_GOVERNOR' else
            (1.,) if kind=='PREASSIGNED_NOMINAL' else (.5,0.)))
