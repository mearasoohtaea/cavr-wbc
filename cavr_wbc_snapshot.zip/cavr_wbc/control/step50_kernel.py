"""Actual frozen governor plus narrowly adapted nominal dispatch and mission."""
from copy import deepcopy
from time import perf_counter
import numpy as np
from cavr_wbc.control.step48_kernel import Kernel as SourceKernel
from cavr_wbc.control.step49_kernel import Kernel as PhaseHook
from cavr_wbc.control.step50_policy import MissionServo,MissionPolicy,VERSION
from cavr_wbc.control.step46_policy import VERSION as TASK_VERSION
from cavr_wbc.control.step46_kernel import experimental_packet as source_experimental
from cavr_wbc.control.step37_actions import make_action
from cavr_wbc.control.step38_kernel import servo_memory
from cavr_wbc.control.step29_kernel import DEADLINE_S,FINAL_RESERVE_S,MIN_SOLVER_S
class Kernel(SourceKernel):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.backup_servo=MissionServo(self.model)
        self.policy=MissionPolicy(self.backup_controller,self.backup_servo)
        self._feedback_staging_servo=MissionServo(self.model)
    def _packet_base(self,sample,active,method):
        c,p=super()._packet_base(sample,active,method)
        p.update(external_arm=sample['external_arm'],internal_plan=sample['experimental_arm'],
            dispatch_kind=dispatch_kind(sample['external_arm']),composite_policy_id=VERSION,
            policy_version=TASK_VERSION,authorization_scope='RECOVERY_1S_ONLY',
            step50_method_freeze_sha256=sample['step50_method_freeze_sha256'],old_CAL_certifies_mission=False)
        return c,p
    def prepare_phase(self,data,slot,summary):
        r=PhaseHook.prepare_phase(self,data,slot,summary)
        r['composite_policy_id']=VERSION
        return r
    def feedback_transaction(self,*args,**kwargs):
        r=super().feedback_transaction(*args,**kwargs)
        r.update(policy_version=TASK_VERSION,composite_policy_id=VERSION,
            phase_policy_id=(r.get('external_reference') or {}).get('phase_policy_id'),
            old_CAL_certifies_mission=False)
        return r
def dispatch_kind(arm):
    return 'LEARNED_GOVERNOR' if arm=='GOVERNED_RECOVER_RESUME' else 'PREASSIGNED_NOMINAL' if arm=='NOMINAL_IMMEDIATE' else 'PREASSIGNED_EXPERIMENT'
def experimental_packet(kernel,sample,budget,owners,gamma,arm):
    # Source adapter retains its full original prepare/commit clock and copies.
    return source_experimental(kernel,sample,budget,owners,gamma,arm)
def nominal_packet(kernel,sample,budget,clock=perf_counter):
    """Own C only; zero initial feedback PID is explicit, not a fictitious B0."""
    begin=clock()
    c,p=kernel._packet_base(sample,budget,'APPLICATION_FEAS_GOV')
    p.update(method='TASK_MATCHED',nominal_sent=False,experimental_dispatch=False,
        experimental_committed=False,selected_command_sent=False,governor_selected=False,
        learner_approved=False,model_authorized=False,governor_calls=0,screening_calls=0,
        dispatch_reason='PREASSIGNED_OWN_CAPACITY_AWARE_C_ENDPOINT',
        prepare_begin=begin,absolute_deadline=begin+DEADLINE_S,
        step34_solver_owner=kernel.solver_owner_identity(),
        step37_branch_owners={n:kernel.solver_owner_identity() for n in ('C','MIDDLE','B')},
        first_packet_backup_owner=kernel.backup_controller.solver_owner_id,
        first_packet_nominal_owner=kernel.nominal_controller.solver_owner_id)
    action=None
    if kernel.nominal_controller._solver_cache and p['application_prediction']['complete']:
        kernel.reset(c)
        kernel.reset_backup(kernel.data,c,preserve_ready=False)
        kernel._last_backup_slot=0
        p['nominal_initial_memory']=dict(context_id=sample['context_id'],backup_id=sample['backup_id'],
            owner=kernel.solver_owner_identity(),servo=servo_memory(kernel.backup_servo),
            status='OWN_ZERO_PID_INITIAL_SEED_NO_B0',new_QP_calls=0)
        limit=min(.003,begin+DEADLINE_S-clock()-FINAL_RESERVE_S)
        if limit>=MIN_SOLVER_S:
            kernel.set_next_call_limit(limit)
            p['C']=kernel.nominal(c,budget,'FIRST_NOMINAL_C',sample['context_id'])
            p['first_QP_native_limits_s']['C']=limit
            action=make_action(c,p['C'],None,1.)
    p.update(selected_action=deepcopy(action),selected_gamma=1.,
        actions={'1.0':{'action':deepcopy(action),'screening_prefix_status':'NOT_REQUESTED_BY_NOMINAL'}})
    prepared=(clock()-begin)*1000.
    p['prepared_commit_ms']=prepared
    sent=bool(action and action.get('command_valid') and action.get('execution_eligible') and prepared<=17.)
    total=(clock()-begin)*1000.;sent &= total<=20.
    p.update(nominal_sent=sent,command_ready_ms=total,final_commit_copy_ms=total-prepared,
        prepared_reserve_ms=17.,frozen_complete_deadline_ms=20.,
        status='NOMINAL_SENT' if sent else 'NOMINAL_LATE_UNAPPLIED' if prepared>17 or total>20 else 'NOMINAL_COMMAND_UNAVAILABLE',
        overall_deadline_failure=prepared>17 or total>20,actual_command_applied=False,
        complete_scope='BEGIN_PREHOLD_PREDICTION_OWN_C_SEED_VALIDATION_COPY_COMMIT')
    return p
