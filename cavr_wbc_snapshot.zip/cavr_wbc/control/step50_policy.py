"""Explicit external-to-internal plan mapping; source TASK contract unchanged."""
from cavr_wbc.control.step49_policy import MissionServo as SourceServo,mission_reference
from cavr_wbc.control.step46_policy import TaskAwarePolicy
VERSION='STEP50_FROZEN_GOVERNOR_RECOVERY_TO_MISSION_4S_V1'
ARMS=('GOVERNED_RECOVER_RESUME','MIDDLE_RECOVER_RESUME','MIDDLE_IMMEDIATE_MISSION','B_RECOVER_RESUME','NOMINAL_IMMEDIATE')
PLANS=dict(zip(ARMS,('MIDDLE_RECOVER_RESUME','MIDDLE_RECOVER_RESUME','IMMEDIATE_MISSION','B_RECOVER_RESUME','IMMEDIATE_MISSION')))
def internal_plan(arm):
    if arm not in PLANS:raise ValueError('unknown STEP50 external arm')
    return PLANS[arm]
class MissionServo(SourceServo):
    def freeze_source(self,context,policy_instance):
        super().freeze_source(context,policy_instance)
        self.mission_arm=internal_plan(context['external_arm'])
    def reference_at(self,data,tick):
        r=super().reference_at(data,tick)
        r['composite_policy_id']=VERSION
        return r
class MissionPolicy(TaskAwarePolicy):
    composite_policy_id=VERSION
