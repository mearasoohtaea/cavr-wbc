"""Saved-evidence evaluation utilities; no experimental solver execution."""
