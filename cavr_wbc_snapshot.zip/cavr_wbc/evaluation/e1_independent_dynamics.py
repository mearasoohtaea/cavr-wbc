"""Independent public-state MuJoCo replay for the E1 preparation stage.

The evaluator receives only q, v, health metadata, and actual actuator-space
commands.  It never imports a controller and never consumes a feasibility or
solver label.  A fresh MjData object is used for every replay.  The backend is
explicitly recorded as ``mujoco_fresh_data``; this is an independent replay
boundary, not a claim of a second physics engine.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import math
from typing import Callable, Iterable, Sequence

import mujoco
import numpy as np

from cavr_wbc.evaluation.e1_public_state import (
    PublicState,
    capture_public_state,
    model_source_hash,
    sha256_json,
)
from cavr_wbc.platforms.go2_mujoco import DEFAULT_GO2_MODEL_PATH, load_go2_model


VERSION = "CAVR_WBC_E1_INDEPENDENT_DYNAMICS_V1"
TaskCallback = Callable[[mujoco.MjModel, mujoco.MjData], dict[str, float]]


def _finite_vector(name: str, values: Iterable[float], length: int) -> np.ndarray:
    array = np.asarray(tuple(values), dtype=float)
    if array.shape != (length,) or not np.isfinite(array).all():
        raise ValueError(f"{name} must be a finite vector of length {length}")
    return array


def _warnings(data: mujoco.MjData) -> tuple[dict[str, int], ...]:
    return tuple(
        {
            "warning_index": int(index),
            "number": int(item.number),
            "lastinfo": int(item.lastinfo),
        }
        for index, item in enumerate(data.warning)
        if int(item.number) > 0
    )


@dataclass(frozen=True)
class IndependentReplayResult:
    version: str
    backend: str
    model_source_hash: str
    input_hash: str
    steps_requested: int
    states: tuple[PublicState, ...]
    warnings: tuple[dict[str, int], ...]

    def __post_init__(self) -> None:
        if self.version != VERSION or self.backend != "mujoco_fresh_data":
            raise ValueError("unsupported independent replay metadata")
        if self.steps_requested < 1 or len(self.states) != self.steps_requested:
            raise ValueError("replay step count does not match public states")

    @property
    def all_finite(self) -> bool:
        return all(
            np.isfinite(np.asarray(state.qpos)).all()
            and np.isfinite(np.asarray(state.qvel)).all()
            and np.isfinite(np.asarray(state.qacc)).all()
            for state in self.states
        )


class IndependentDynamicsEvaluator:
    """Replay actual actuator commands through a fresh public-state boundary."""

    backend = "mujoco_fresh_data"

    def __init__(self, model_path: str = str(DEFAULT_GO2_MODEL_PATH)) -> None:
        self.model_path = model_path
        self.model = load_go2_model(model_path)
        self.model_hash = model_source_hash(model_path)

    def replay(
        self,
        qpos: Iterable[float],
        qvel: Iterable[float],
        commands: Sequence[Iterable[float]],
        rho: Iterable[float],
        *,
        start_time_s: float = 0.0,
        step_index: int = 0,
        task_callback: TaskCallback | None = None,
    ) -> IndependentReplayResult:
        if not math.isfinite(float(start_time_s)) or start_time_s < 0.0:
            raise ValueError("start_time_s must be finite and non-negative")
        if step_index < 0:
            raise ValueError("step_index must be non-negative")
        qpos_array = _finite_vector("qpos", qpos, self.model.nq)
        qvel_array = _finite_vector("qvel", qvel, self.model.nv)
        health = _finite_vector("rho", rho, self.model.nu)
        command_rows = tuple(_finite_vector(f"commands[{i}]", row, self.model.nu) for i, row in enumerate(commands))
        if not command_rows:
            raise ValueError("commands must contain at least one step")
        if len(command_rows) > 2:
            raise ValueError("preparation replay is limited to at most two steps")

        data = mujoco.MjData(self.model)
        data.qpos[:] = qpos_array
        data.qvel[:] = qvel_array
        data.ctrl[:] = 0.0
        mujoco.mj_forward(self.model, data)
        states: list[PublicState] = []
        for offset, command in enumerate(command_rows):
            data.ctrl[:] = command
            mujoco.mj_forward(self.model, data)
            task_values = task_callback(self.model, data) if task_callback is not None else {}
            state = capture_public_state(
                self.model,
                data,
                ctrl_written=command,
                rho=health,
                step_index=step_index + offset,
                time_s=float(start_time_s) + offset * float(self.model.opt.timestep),
                model_hash=self.model_hash,
                task_values=task_values,
            )
            states.append(state)
            mujoco.mj_step(self.model, data)
        payload = {
            "version": VERSION,
            "backend": self.backend,
            "model_source_hash": self.model_hash,
            "qpos": qpos_array.tolist(),
            "qvel": qvel_array.tolist(),
            "commands": [row.tolist() for row in command_rows],
            "rho": health.tolist(),
            "start_time_s": float(start_time_s),
            "step_index": int(step_index),
        }
        return IndependentReplayResult(
            version=VERSION,
            backend=self.backend,
            model_source_hash=self.model_hash,
            input_hash=sha256_json(payload),
            steps_requested=len(command_rows),
            states=tuple(states),
            warnings=_warnings(data),
        )

