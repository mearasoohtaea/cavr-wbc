"""Controller-independent E1 metric and structural-gate functions."""

from __future__ import annotations

from dataclasses import dataclass, asdict
import math
from typing import Any, Iterable, Mapping

import mujoco
import numpy as np

from cavr_wbc.evaluation.e1_public_state import PublicState
from cavr_wbc.platforms.go2_mujoco import extract_actuator_joint_map, extract_healthy_torque_limits


VERSION = "CAVR_WBC_E1_METRICS_V1"
DEFAULT_METRIC_GATE = {
    "qacc_abs_tolerance": 1.0e-6,
    "torque_bound_abs_tolerance_nm": 1.0e-8,
    "contact_normal_force_abs_tolerance_n": 1.0e-6,
    "friction_margin_abs_tolerance_n": 1.0e-6,
    "max_tangential_speed_m_s": 1.0e-5,
    "minimum_normal_force_n": 0.0,
    "required_contact_count": 4,
    "task_direction_cosine_min": 0.999999,
}


@dataclass(frozen=True)
class MetricGate:
    qacc_abs_tolerance: float = DEFAULT_METRIC_GATE["qacc_abs_tolerance"]
    torque_bound_abs_tolerance_nm: float = DEFAULT_METRIC_GATE["torque_bound_abs_tolerance_nm"]
    contact_normal_force_abs_tolerance_n: float = DEFAULT_METRIC_GATE["contact_normal_force_abs_tolerance_n"]
    friction_margin_abs_tolerance_n: float = DEFAULT_METRIC_GATE["friction_margin_abs_tolerance_n"]
    max_tangential_speed_m_s: float = DEFAULT_METRIC_GATE["max_tangential_speed_m_s"]
    minimum_normal_force_n: float = DEFAULT_METRIC_GATE["minimum_normal_force_n"]
    required_contact_count: int = DEFAULT_METRIC_GATE["required_contact_count"]
    task_direction_cosine_min: float = DEFAULT_METRIC_GATE["task_direction_cosine_min"]

    def __post_init__(self) -> None:
        for name in ("qacc_abs_tolerance", "torque_bound_abs_tolerance_nm", "contact_normal_force_abs_tolerance_n", "friction_margin_abs_tolerance_n", "max_tangential_speed_m_s", "minimum_normal_force_n"):
            value = float(getattr(self, name))
            if not math.isfinite(value) or value < 0.0:
                raise ValueError(f"{name} must be finite and non-negative")
        if type(self.required_contact_count) is not int or self.required_contact_count < 0:
            raise ValueError("required_contact_count must be a non-negative integer")
        if not 0.0 <= float(self.task_direction_cosine_min) <= 1.0:
            raise ValueError("task_direction_cosine_min must lie in [0, 1]")

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def _subtree_com_acceleration(model: mujoco.MjModel, data: mujoco.MjData) -> np.ndarray:
    """Compute whole-model subtree-CoM acceleration from public dynamics.

    MuJoCo exposes the subtree-CoM Jacobian but not its time derivative.  The
    latter is obtained by a fixed, symmetric public-state finite difference;
    this is deliberately recorded as a numerical implementation detail and is
    not used to label feasibility.
    """

    jacobian = np.zeros((3, model.nv), dtype=float)
    mujoco.mj_jacSubtreeCom(model, data, jacobian, 0)
    epsilon = 1.0e-6
    jacobians = []
    for sign in (-1.0, 1.0):
        qpos = np.asarray(data.qpos, dtype=float).copy()
        mujoco.mj_integratePos(model, qpos, np.asarray(data.qvel, dtype=float), sign * epsilon)
        probe = mujoco.MjData(model)
        probe.qpos[:] = qpos
        probe.qvel[:] = data.qvel
        mujoco.mj_forward(model, probe)
        item = np.zeros((3, model.nv), dtype=float)
        mujoco.mj_jacSubtreeCom(model, probe, item, 0)
        jacobians.append(item)
    jacobian_dot = (jacobians[1] - jacobians[0]) / (2.0 * epsilon)
    return jacobian @ np.asarray(data.qacc, dtype=float) + jacobian_dot @ np.asarray(data.qvel, dtype=float)


def task_components_from_data(model: mujoco.MjModel, data: mujoco.MjData) -> dict[str, float]:
    """Compute the four frozen public task outputs; no controller status is read."""

    body_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "base_link")
    if body_id < 0:
        raise ValueError("base_link body is missing")
    acceleration = np.zeros(6, dtype=float)
    mujoco.mj_objectAcceleration(model, data, mujoco.mjtObj.mjOBJ_BODY, body_id, acceleration, 0)
    com_acceleration = _subtree_com_acceleration(model, data)
    return {
        "body_roll_acceleration": float(acceleration[3]),
        "body_pitch_acceleration": float(acceleration[4]),
        "com_height_acceleration": float(com_acceleration[2]),
        "base_forward_acceleration": float(acceleration[0]),
    }


def task_direction_value(task_values: Mapping[str, float], coefficients: Mapping[str, float]) -> float:
    missing = set(coefficients) - set(task_values)
    if missing:
        raise ValueError(f"task values missing components: {sorted(missing)}")
    value = sum(float(coefficients[key]) * float(task_values[key]) for key in coefficients)
    if not math.isfinite(value):
        raise ValueError("task direction value is not finite")
    return float(value)


def validate_public_sequence(states: Iterable[PublicState]) -> dict[str, Any]:
    """Check ordering metadata without using any controller truth."""

    records = list(states)
    return {
        "records": len(records),
        "timestamp_monotonic": bool(records) and all(
            current.time_s >= previous.time_s
            for previous, current in zip(records, records[1:])
        ),
        "step_monotonic": bool(records) and all(
            current.step_index == previous.step_index + 1
            for previous, current in zip(records, records[1:])
        ),
    }


def _maximum_contact_count(contacts: Mapping[str, Mapping[str, Any]]) -> int:
    return sum(bool(row.get("present", False)) for row in contacts.values())


def compute_step_metrics(
    model: mujoco.MjModel,
    state: PublicState,
    *,
    gate: MetricGate = MetricGate(),
    expected_qacc: Iterable[float] | None = None,
    task_target: Mapping[str, float] | None = None,
) -> dict[str, Any]:
    """Compute physical residuals from a public state only."""

    if len(state.ctrl_written) != model.nu or len(state.generalized_torque) != model.nu:
        raise ValueError("public state actuator width does not match model")
    limits = extract_healthy_torque_limits(model) * np.asarray(state.rho, dtype=float)
    torque = np.asarray(state.generalized_torque, dtype=float)
    torque_violation = np.maximum(np.abs(torque) - limits, 0.0)
    contact_rows = tuple(state.contacts.values())
    friction_margins = [float(row.get("friction_margin_n", 0.0)) for row in contact_rows]
    tangential_speeds = [float(row.get("tangential_speed_m_s", 0.0)) for row in contact_rows]
    normal_forces = [float(row.get("normal_force_n", 0.0)) for row in contact_rows]
    expected = None if expected_qacc is None else np.asarray(tuple(expected_qacc), dtype=float)
    qacc_error = None if expected is None else float(np.max(np.abs(np.asarray(state.qacc) - expected)))
    target_residual = None
    if task_target is not None:
        target_residual = {key: float(state.task_values[key]) - float(value) for key, value in task_target.items() if key in state.task_values}
    finite = all(np.isfinite(np.asarray(getattr(state, field), dtype=float)).all() for field in ("qpos", "qvel", "qacc", "ctrl_written", "actuator_force", "generalized_torque", "rho"))
    structural_ok = finite and len(state.contacts) == 4 and all("present" in row for row in contact_rows)
    physical_failure = (
        float(np.max(torque_violation)) > gate.torque_bound_abs_tolerance_nm
        or _maximum_contact_count(state.contacts) < gate.required_contact_count
        or any(margin < -gate.friction_margin_abs_tolerance_n for margin in friction_margins)
        or any(speed > gate.max_tangential_speed_m_s for speed in tangential_speeds)
        or any(force < gate.minimum_normal_force_n - gate.friction_margin_abs_tolerance_n for force in normal_forces if force != 0.0)
    )
    if not structural_ok:
        status = "STRUCTURAL_INVALID"
    elif physical_failure:
        status = "PHYSICAL_FAILURE"
    elif qacc_error is not None and qacc_error > gate.qacc_abs_tolerance:
        status = "NUMERICAL_MISMATCH"
    else:
        status = "PUBLIC_STATE_VALID"
    return {
        "metrics_version": VERSION,
        "status": status,
        "structural_ok": bool(structural_ok),
        "physical_failure": bool(physical_failure),
        "qacc_error_inf": qacc_error,
        "torque_violation_inf_nm": float(np.max(torque_violation)),
        "minimum_friction_margin_n": min(friction_margins) if friction_margins else None,
        "maximum_tangential_speed_m_s": max(tangential_speeds) if tangential_speeds else None,
        "minimum_normal_force_n": min(normal_forces) if normal_forces else None,
        "contact_count": _maximum_contact_count(state.contacts),
        "task_direction_cosine": None,
        "task_target_residual": target_residual,
        "feasibility_label": None,
        "false_feasible": None,
        "false_infeasible": None,
        "feasibility_label_source": "not_available_from_public_state",
    }


def aggregate_gate(rows: Iterable[Mapping[str, Any]]) -> dict[str, Any]:
    records = list(rows)
    statuses = {str(row.get("status", "UNKNOWN")) for row in records}
    return {
        "metrics_version": VERSION,
        "records": len(records),
        "structural_invalid": sum(row.get("status") == "STRUCTURAL_INVALID" for row in records),
        "physical_failure": sum(row.get("status") == "PHYSICAL_FAILURE" for row in records),
        "numerical_mismatch": sum(row.get("status") == "NUMERICAL_MISMATCH" for row in records),
        "public_state_valid": sum(row.get("status") == "PUBLIC_STATE_VALID" for row in records),
        "statuses": sorted(statuses),
        "strict_gate_pass": bool(records) and not any(row.get("status") != "PUBLIC_STATE_VALID" for row in records),
        "controller_feasibility_labels_consumed": False,
    }

