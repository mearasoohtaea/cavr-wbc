"""Public-state boundary for the E1 physical replay.

This module intentionally has no dependency on a controller, a QP result, or
any solver status.  It converts the compiled MuJoCo state and the *actual*
actuator path into a small immutable record that an independent evaluator can
consume.  Feasibility, certificates, and controller diagnostics are not part
of this boundary.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path
from typing import Any, Iterable, Mapping

import mujoco
import numpy as np

from cavr_wbc.platforms.go2_mujoco import (
    DEFAULT_GO2_MODEL_PATH,
    extract_actuator_joint_map,
    joint_tau_from_qfrc,
)


VERSION = "CAVR_WBC_E1_PUBLIC_STATE_V1"
_SHA256 = 64
_FORBIDDEN_KEYS = {
    "feasible",
    "is_feasible",
    "solver_status",
    "certificate",
    "hidden_label",
    "controller_diagnostics",
    "optimization_status",
}
SCENARIO_STATE_CLASSES = ("healthy_balance", "near_capacity", "authored_infeasible")
SCENARIO_BASE_FORWARD_VELOCITY = {
    "healthy_balance": 0.0,
    "near_capacity": 0.20,
    "authored_infeasible": 0.50,
}
SCENARIO_TASK_TARGET = {
    "healthy_balance": (0.0, 0.0, 0.0, 0.0),
    "near_capacity": (0.0, 0.0, 0.25, 0.25),
    "authored_infeasible": (0.0, 0.0, 10.0, 10.0),
}


def _finite_array(name: str, values: Iterable[float], *, length: int | None = None) -> tuple[float, ...]:
    array = np.asarray(tuple(values), dtype=float)
    if array.ndim != 1 or (length is not None and array.size != length):
        expected = "one-dimensional" if length is None else f"length {length}"
        raise ValueError(f"{name} must be a {expected} finite vector")
    if not np.isfinite(array).all():
        raise ValueError(f"{name} must contain only finite values")
    return tuple(float(value) for value in array)


def _check_public_keys(value: Any, path: str = "metadata") -> None:
    if isinstance(value, Mapping):
        for key, item in value.items():
            if str(key).lower() in _FORBIDDEN_KEYS:
                raise ValueError(f"{path} contains controller/solver truth key: {key}")
            _check_public_keys(item, f"{path}.{key}")
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            _check_public_keys(item, f"{path}[{index}]")


def _jsonable(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _jsonable(item) for key, item in sorted(value.items(), key=lambda pair: str(pair[0]))}
    if isinstance(value, (list, tuple)):
        return [_jsonable(item) for item in value]
    if isinstance(value, np.ndarray):
        return [_jsonable(item) for item in value.tolist()]
    if isinstance(value, (np.floating, np.integer, np.bool_)):
        return value.item()
    return value


def canonical_json(value: Any) -> str:
    return json.dumps(_jsonable(value), ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def sha256_json(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def model_source_hash(model_path: str | Path = DEFAULT_GO2_MODEL_PATH) -> str:
    path = Path(model_path)
    if not path.is_absolute():
        path = Path.cwd() / path
    return hashlib.sha256(path.resolve().read_bytes()).hexdigest()


@dataclass(frozen=True)
class ScenarioState:
    """Deterministic, authored public initial-state fixture."""

    state_class: str
    qpos: tuple[float, ...]
    qvel: tuple[float, ...]
    task_target: tuple[float, ...]
    model_source_hash: str
    fixture_hash: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "state_class": self.state_class,
            "qpos": list(self.qpos),
            "qvel": list(self.qvel),
            "task_target": list(self.task_target),
            "model_source_hash": self.model_source_hash,
            "fixture_hash": self.fixture_hash,
        }


def scenario_state(
    model: mujoco.MjModel,
    state_class: str,
    *,
    model_hash: str | None = None,
) -> ScenarioState:
    """Return a deterministic fixture from the compiled model qpos0.

    The class name and task target are authored metadata only.  They are never
    passed as controller feasibility truth to the independent evaluator.
    """

    if state_class not in SCENARIO_STATE_CLASSES:
        raise ValueError(f"unknown state class: {state_class}")
    digest = model_source_hash() if model_hash is None else model_hash
    qpos = _finite_array("qpos", model.qpos0, length=model.nq)
    qvel_array = np.zeros(model.nv, dtype=float)
    qvel_array[0] = SCENARIO_BASE_FORWARD_VELOCITY[state_class]
    qvel = _finite_array("qvel", qvel_array, length=model.nv)
    target = tuple(float(value) for value in SCENARIO_TASK_TARGET[state_class])
    payload = {
        "version": VERSION,
        "state_class": state_class,
        "qpos": list(qpos),
        "qvel": list(qvel),
        "task_target": list(target),
        "model_source_hash": digest,
    }
    return ScenarioState(
        state_class=state_class,
        qpos=qpos,
        qvel=qvel,
        task_target=target,
        model_source_hash=digest,
        fixture_hash=sha256_json(payload),
    )


def _public_contact_diagnostics(model: mujoco.MjModel, data: mujoco.MjData) -> dict[str, dict[str, float | bool | int]]:
    """Extract contact data without using a controller feasibility label."""

    foot_names = ("FL", "FR", "RL", "RR")
    geom_ids = {
        name: mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_GEOM, name)
        for name in foot_names
    }
    result: dict[str, dict[str, float | bool | int]] = {
        name: {
            "present": False,
            "contact_count": 0,
            "normal_force_n": 0.0,
            "tangential_force_n": 0.0,
            "friction_mu": 0.0,
            "friction_margin_n": 0.0,
            "tangential_speed_m_s": 0.0,
        }
        for name in foot_names
    }
    for contact_index in range(data.ncon):
        contact = data.contact[contact_index]
        matched = [name for name, geom_id in geom_ids.items() if int(contact.geom1) == geom_id or int(contact.geom2) == geom_id]
        if not matched:
            continue
        wrench = np.zeros(6, dtype=float)
        mujoco.mj_contactForce(model, data, contact_index, wrench)
        name = matched[0]
        tangential = float(np.linalg.norm(wrench[1:3]))
        normal = float(wrench[0])
        mu = float(contact.friction[0])
        velocity = np.zeros(6, dtype=float)
        mujoco.mj_objectVelocity(model, data, mujoco.mjtObj.mjOBJ_GEOM, geom_ids[name], velocity, 0)
        row = result[name]
        row["present"] = True
        row["contact_count"] = int(row["contact_count"]) + 1
        row["normal_force_n"] = float(row["normal_force_n"]) + normal
        row["tangential_force_n"] = float(row["tangential_force_n"]) + tangential
        row["friction_mu"] = mu
        row["friction_margin_n"] = float(row["friction_margin_n"]) + mu * normal - tangential
        row["tangential_speed_m_s"] = max(float(row["tangential_speed_m_s"]), float(np.linalg.norm(velocity[3:5])))
    return result


@dataclass(frozen=True)
class PublicState:
    """Controller-independent state/actuation observation."""

    version: str
    step_index: int
    time_s: float
    qpos: tuple[float, ...]
    qvel: tuple[float, ...]
    qacc: tuple[float, ...]
    ctrl_written: tuple[float, ...]
    actuator_force: tuple[float, ...]
    generalized_torque: tuple[float, ...]
    rho: tuple[float, ...]
    contacts: Mapping[str, Mapping[str, float | bool | int]]
    task_values: Mapping[str, float]
    model_source_hash: str
    input_hash: str

    def __post_init__(self) -> None:
        if self.version != VERSION:
            raise ValueError("unsupported public-state version")
        if type(self.step_index) is not int or self.step_index < 0:
            raise ValueError("step_index must be a non-negative integer")
        if not math.isfinite(float(self.time_s)) or self.time_s < 0.0:
            raise ValueError("time_s must be finite and non-negative")
        for name in ("qpos", "qvel", "qacc", "ctrl_written", "actuator_force", "generalized_torque", "rho"):
            _finite_array(name, getattr(self, name))
        actuator_lengths = {len(self.ctrl_written), len(self.actuator_force), len(self.generalized_torque), len(self.rho)}
        if len(actuator_lengths) != 1:
            raise ValueError("actuator-space vectors must have equal lengths")
        if any(value < 0.0 or value > 1.0 for value in self.rho):
            raise ValueError("rho must lie in [0, 1]")
        if len(self.qpos) == 0 or len(self.qvel) == 0 or len(self.qacc) == 0:
            raise ValueError("state vectors must not be empty")
        _check_public_keys(self.contacts, "contacts")
        _check_public_keys(self.task_values, "task_values")
        for key, value in self.task_values.items():
            if not math.isfinite(float(value)):
                raise ValueError(f"task value {key!r} must be finite")
        for name, digest in (("model_source_hash", self.model_source_hash), ("input_hash", self.input_hash)):
            if type(digest) is not str or len(digest) != _SHA256 or any(char not in "0123456789abcdef" for char in digest):
                raise ValueError(f"{name} must be a lowercase SHA256 digest")

    def as_dict(self) -> dict[str, Any]:
        return {
            "version": self.version,
            "step_index": self.step_index,
            "time_s": self.time_s,
            "qpos": list(self.qpos),
            "qvel": list(self.qvel),
            "qacc": list(self.qacc),
            "ctrl_written": list(self.ctrl_written),
            "actuator_force": list(self.actuator_force),
            "generalized_torque": list(self.generalized_torque),
            "rho": list(self.rho),
            "contacts": _jsonable(self.contacts),
            "task_values": _jsonable(self.task_values),
            "model_source_hash": self.model_source_hash,
            "input_hash": self.input_hash,
        }


def capture_public_state(
    model: mujoco.MjModel,
    data: mujoco.MjData,
    *,
    ctrl_written: Iterable[float] | None = None,
    rho: Iterable[float],
    step_index: int,
    time_s: float,
    model_hash: str,
    task_values: Mapping[str, float] | None = None,
) -> PublicState:
    """Capture only public simulator outputs at the current pre-step state."""

    mapping = extract_actuator_joint_map(model)
    command = np.asarray(data.ctrl if ctrl_written is None else tuple(ctrl_written), dtype=float)
    health = np.asarray(tuple(rho), dtype=float)
    if command.shape != (model.nu,) or health.shape != (model.nu,):
        raise ValueError("ctrl_written and rho must match model.nu")
    if not np.isfinite(command).all() or not np.isfinite(health).all():
        raise ValueError("ctrl_written and rho must be finite")
    if len(mapping) != model.nu:
        raise ValueError("compiled actuator map is incomplete")
    payload = {
        "version": VERSION,
        "step_index": int(step_index),
        "time_s": float(time_s),
        "qpos": np.asarray(data.qpos, dtype=float).tolist(),
        "qvel": np.asarray(data.qvel, dtype=float).tolist(),
        "qacc": np.asarray(data.qacc, dtype=float).tolist(),
        "ctrl_written": command.tolist(),
        "actuator_force": np.asarray(data.actuator_force, dtype=float).tolist(),
        "generalized_torque": joint_tau_from_qfrc(model, data).tolist(),
        "rho": health.tolist(),
        "contacts": _public_contact_diagnostics(model, data),
        "task_values": dict(task_values or {}),
        "model_source_hash": model_hash,
    }
    return PublicState(
        version=VERSION,
        step_index=int(step_index),
        time_s=float(time_s),
        qpos=_finite_array("qpos", data.qpos, length=model.nq),
        qvel=_finite_array("qvel", data.qvel, length=model.nv),
        qacc=_finite_array("qacc", data.qacc, length=model.nv),
        ctrl_written=_finite_array("ctrl_written", command, length=model.nu),
        actuator_force=_finite_array("actuator_force", data.actuator_force, length=model.nu),
        generalized_torque=_finite_array("generalized_torque", joint_tau_from_qfrc(model, data), length=model.nu),
        rho=_finite_array("rho", health, length=model.nu),
        contacts=_public_contact_diagnostics(model, data),
        task_values=dict(task_values or {}),
        model_source_hash=model_hash,
        input_hash=sha256_json(payload),
    )
