"""Independent physical/task evaluator for the E2-B DEV experiments.

The evaluator deliberately consumes only public MuJoCo state and the command
that was actually written to the simulator.  It does not import a controller,
read a solver status, or use a feasibility/certificate label.  ``health`` is
used only to reconstruct the declared physical output bounds; the domain
classification is computed from the observed state and contacts alone.
"""

from __future__ import annotations

from collections.abc import Mapping
import math
from typing import Any, Iterable

import mujoco
import numpy as np

from cavr_wbc.platforms.go2_mujoco import (
    FOOT_NAMES,
    extract_actuator_joint_map,
    extract_healthy_torque_limits,
)


VERSION = "CAVR_WBC_E2B_INDEPENDENT_PHYSICAL_EVALUATOR_V1"


def _get(cfg: Any, key: str, default: Any) -> Any:
    """Read a possibly nested configuration key from mappings/objects."""

    if cfg is None:
        return default
    if isinstance(cfg, Mapping):
        if key in cfg:
            return cfg[key]
        cur: Any = cfg
        for part in key.split("."):
            if not isinstance(cur, Mapping) or part not in cur:
                return default
            cur = cur[part]
        return cur
    cur = cfg
    for part in key.split("."):
        if not hasattr(cur, part):
            return default
        cur = getattr(cur, part)
    return cur


def _finite(name: str, values: Iterable[float], length: int | None = None) -> np.ndarray:
    arr = np.asarray(tuple(values), dtype=float)
    if arr.ndim != 1 or (length is not None and arr.size != length):
        raise ValueError(f"{name} must be a one-dimensional vector of length {length}")
    if not np.isfinite(arr).all():
        raise ValueError(f"{name} must contain only finite values")
    return arr


def _base_body_id(model: mujoco.MjModel) -> int:
    for name in ("base_link", "base", "trunk"):
        ident = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, name)
        if ident >= 0:
            return int(ident)
    return 1 if model.nbody > 1 else 0


def _rpy_from_body_rotation(rotation: np.ndarray) -> tuple[float, float]:
    """Return roll/pitch for a world-frame body rotation matrix."""

    r = np.asarray(rotation, dtype=float).reshape(3, 3)
    # ZYX convention, with clipping to keep the evaluator finite at gimbal lock.
    pitch = math.asin(float(np.clip(-r[2, 0], -1.0, 1.0)))
    roll = math.atan2(float(r[2, 1]), float(r[2, 2]))
    return roll, pitch


def _target_value(target: Any, name: str, default: float = 0.0) -> float:
    if isinstance(target, Mapping):
        if name in target:
            return float(target[name])
        # A compact tuple target is accepted for the common task contract.
        aliases = {"roll": 0, "pitch": 1, "com_height": 2, "com_velocity": 3}
        if isinstance(target.get("values"), (tuple, list)) and name in aliases:
            values = target["values"]
            idx = aliases[name]
            if idx < len(values):
                return float(values[idx])
    elif isinstance(target, (tuple, list)):
        aliases = {"roll": 0, "pitch": 1, "com_height": 2, "com_velocity": 3}
        idx = aliases.get(name)
        if idx is not None and idx < len(target):
            return float(target[idx])
    return float(default)


def _contact_observation(model: mujoco.MjModel, data: mujoco.MjData) -> dict[str, dict[str, Any]]:
    """Extract four-foot contact forces in a sign-consistent contact frame.

    MuJoCo's ``mj_contactForce`` vector is expressed in the contact frame and
    is the force on geom2.  When a foot is geom1 the sign is inverted; this is
    important for models in which the geom ordering differs from the pinned
    Go2 scene.  Friction is evaluated in the same local frame as the reported
    normal force.
    """

    foot_ids = {
        name: int(mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_GEOM, name))
        for name in FOOT_NAMES
    }
    result: dict[str, dict[str, Any]] = {
        name: {
            "present": False,
            "contact_count": 0,
            "normal_force_n": 0.0,
            "tangential_force_n": 0.0,
            "friction_mu": 0.0,
            "friction_margin_n": 0.0,
            "slip_speed_m_s": 0.0,
            "force_frame": "contact_local",
        }
        for name in FOOT_NAMES
    }
    for idx in range(int(data.ncon)):
        contact = data.contact[idx]
        foot_name: str | None = None
        sign = 1.0
        if int(contact.geom2) in foot_ids.values():
            foot_name = next(name for name, ident in foot_ids.items() if ident == int(contact.geom2))
            sign = 1.0
        elif int(contact.geom1) in foot_ids.values():
            foot_name = next(name for name, ident in foot_ids.items() if ident == int(contact.geom1))
            sign = -1.0
        if foot_name is None:
            continue
        wrench = np.zeros(6, dtype=float)
        mujoco.mj_contactForce(model, data, idx, wrench)
        normal = sign * float(wrench[0])
        tangential = float(np.linalg.norm(wrench[1:3]))
        mu = float(contact.friction[0])
        velocity = np.zeros(6, dtype=float)
        mujoco.mj_objectVelocity(
            model,
            data,
            mujoco.mjtObj.mjOBJ_GEOM,
            foot_ids[foot_name],
            velocity,
            0,
        )
        row = result[foot_name]
        row["present"] = True
        row["contact_count"] = int(row["contact_count"]) + 1
        row["normal_force_n"] = float(row["normal_force_n"]) + normal
        row["tangential_force_n"] = float(row["tangential_force_n"]) + tangential
        row["friction_mu"] = mu
        row["friction_margin_n"] = float(row["friction_margin_n"]) + mu * normal - tangential
        row["slip_speed_m_s"] = max(float(row["slip_speed_m_s"]), float(np.linalg.norm(velocity[3:5])))
    for row in result.values():
        row["normal_force_n"] = float(row["normal_force_n"])
        row["friction_margin_n"] = float(row["friction_margin_n"])
    return result


def _domain_class(task: Mapping[str, float], contacts: Mapping[str, Mapping[str, Any]], cfg: Any) -> str:
    """Classify only the observed public state (never the health/fault label)."""

    roll_lim = abs(float(_get(cfg, "task.roll_limit_rad", 0.55)))
    pitch_lim = abs(float(_get(cfg, "task.pitch_limit_rad", 0.55)))
    h_low = float(_get(cfg, "task.com_height_min_m", 0.16))
    h_high = float(_get(cfg, "task.com_height_max_m", 0.60))
    speed_limit = abs(float(_get(cfg, "task.velocity_limit_m_s", 2.0)))
    all_contact = all(bool(contacts[name]["present"]) for name in FOOT_NAMES)
    all_normal = all(float(contacts[name]["normal_force_n"]) >= 0.0 for name in FOOT_NAMES)
    if (
        all_contact
        and all_normal
        and abs(float(task["roll"])) <= 0.5 * roll_lim
        and abs(float(task["pitch"])) <= 0.5 * pitch_lim
        and h_low <= float(task["com_height"]) <= h_high
        and abs(float(task["com_velocity"])) <= 0.5 * speed_limit
    ):
        return "R1"
    if (
        all_contact
        and abs(float(task["roll"])) <= roll_lim
        and abs(float(task["pitch"])) <= pitch_lim
        and h_low <= float(task["com_height"]) <= h_high
        and abs(float(task["com_velocity"])) <= speed_limit
    ):
        return "R2"
    return "R3"


def classify_public_domain(task: Mapping[str, float], contacts: Mapping[str, Mapping[str, Any]], cfg: Any = None) -> str:
    """Public-state-only R1/R2/R3 classifier exposed for smoke tests."""

    required = {"roll", "pitch", "com_height", "com_velocity"}
    if not required.issubset(task):
        raise ValueError(f"task is missing public values: {sorted(required - set(task))}")
    if any(name not in contacts for name in FOOT_NAMES):
        raise ValueError("contacts must provide all four feet")
    return _domain_class(task, contacts, cfg)


def _joint_margins(model: mujoco.MjModel, data: mujoco.MjData) -> tuple[list[float], bool]:
    margins: list[float] = []
    violation = False
    for joint_id in range(model.njnt):
        if not bool(model.jnt_limited[joint_id]):
            continue
        qadr = int(model.jnt_qposadr[joint_id])
        low, high = (float(v) for v in model.jnt_range[joint_id])
        value = float(data.qpos[qadr])
        margin = min(value - low, high - value)
        margins.append(margin)
        violation = violation or margin < 0.0
    return margins, violation


def evaluate(
    model: mujoco.MjModel,
    data: mujoco.MjData,
    command: Iterable[float],
    health: Iterable[float],
    cfg: Any = None,
    target: Any = None,
) -> dict[str, Any]:
    """Evaluate one public MuJoCo state and actual actuator command.

    The function is intentionally side-effect free: it does not call
    ``mj_step`` and does not mutate ``data``.  ``command`` is the command that
    was written to ``data.ctrl``; actual actuator force is read from
    ``data.actuator_force`` after MuJoCo forward dynamics.
    """

    command_arr = _finite("command", command, model.nu)
    health_arr = _finite("health", health, model.nu)
    if np.any(health_arr < 0.0) or np.any(health_arr > 1.0):
        raise ValueError("health must lie in [0, 1]")
    actual_arr = _finite("actuator_force", data.actuator_force, model.nu)
    limits = extract_healthy_torque_limits(model)
    if limits.shape != (model.nu,):
        raise ValueError("compiled actuator map has unexpected length")
    rho_bounds = health_arr * limits
    command_margin = rho_bounds - np.abs(command_arr)
    actual_margin = rho_bounds - np.abs(actual_arr)

    base_id = _base_body_id(model)
    roll, pitch = _rpy_from_body_rotation(np.asarray(data.xmat[base_id], dtype=float))
    com_height = float(data.subtree_com[base_id][2])
    com_velocity = float(data.qvel[0]) if model.nv else 0.0
    task = {
        "roll": roll,
        "pitch": pitch,
        "com_height": com_height,
        "com_velocity": com_velocity,
    }
    desired = {
        name: _target_value(target, name, 0.0 if name in ("roll", "pitch", "com_velocity") else com_height)
        for name in task
    }
    task_error = {name: float(task[name] - desired[name]) for name in task}
    utility = -float(
        abs(task_error["roll"])
        + abs(task_error["pitch"])
        + abs(task_error["com_height"])
        + abs(task_error["com_velocity"])
    )
    contacts = _contact_observation(model, data)
    joint_margins, joint_violation = _joint_margins(model, data)
    domain = classify_public_domain(task, contacts, cfg)

    reasons: list[str] = []
    if not all(bool(contacts[name]["present"]) for name in FOOT_NAMES):
        reasons.append("not_all_four_contacts")
    for name in FOOT_NAMES:
        row = contacts[name]
        if float(row["normal_force_n"]) < 0.0:
            reasons.append(f"negative_normal_force:{name}")
        if float(row["friction_margin_n"]) < 0.0:
            reasons.append(f"friction_cone:{name}")
    if float(np.min(command_margin)) < 0.0:
        reasons.append("command_torque_bound")
    if float(np.min(actual_margin)) < 0.0:
        reasons.append("actual_torque_bound")
    if joint_violation:
        reasons.append("joint_limit")
    roll_lim = abs(float(_get(cfg, "task.roll_limit_rad", 0.55)))
    pitch_lim = abs(float(_get(cfg, "task.pitch_limit_rad", 0.55)))
    h_low = float(_get(cfg, "task.com_height_min_m", 0.16))
    h_high = float(_get(cfg, "task.com_height_max_m", 0.60))
    if abs(roll) > roll_lim:
        reasons.append("roll_boundary")
    if abs(pitch) > pitch_lim:
        reasons.append("pitch_boundary")
    if not h_low <= com_height <= h_high:
        reasons.append("height_boundary")
    terminal_low_speed = abs(float(_get(cfg, "terminal.velocity_max_m_s", 0.25)))
    terminal_angle = abs(float(_get(cfg, "terminal.angle_max_rad", 0.20)))
    terminal_margin = float(_get(cfg, "terminal.friction_margin_min_n", 0.0))
    terminal = (
        abs(float(data.qvel[0])) <= terminal_low_speed
        and abs(float(data.qvel[1])) <= terminal_low_speed
        and abs(roll) <= terminal_angle
        and abs(pitch) <= terminal_angle
        and h_low <= com_height <= h_high
        and all(bool(contacts[name]["present"]) for name in FOOT_NAMES)
        and all(float(contacts[name]["normal_force_n"]) >= 0.0 for name in FOOT_NAMES)
        and all(float(contacts[name]["friction_margin_n"]) >= terminal_margin for name in FOOT_NAMES)
    )
    margins = [float(v) for v in command_margin] + [float(v) for v in actual_margin] + [float(v) for v in joint_margins]
    margins += [float(contacts[name]["friction_margin_n"]) for name in FOOT_NAMES]
    minimum_margin = float(min(margins)) if margins else float("nan")
    return {
        "version": VERSION,
        "task": task,
        "target": desired,
        "task_error": task_error,
        "utility": utility,
        "command": command_arr.tolist(),
        "actuator_force_actual": actual_arr.tolist(),
        "healthy_torque_limits": limits.tolist(),
        "health_scaled_torque_limits": rho_bounds.tolist(),
        "command_torque_margin": command_margin.tolist(),
        "actual_torque_margin": actual_margin.tolist(),
        "joint_limit_margins": joint_margins,
        "contacts": contacts,
        "domain_layer": domain,
        "terminal_set_membership": bool(terminal),
        "minimum_margin": minimum_margin,
        "safety_failure": bool(reasons),
        "safety_reasons": reasons,
    }


__all__ = ["VERSION", "classify_public_domain", "evaluate"]
