"""Exact saved-QP box proofs and fixed-multiplier Lagrangian lower bounds.

This module constructs no optimizer and no candidate. Every final box face is
proved by an explicit nonnegative combination of saved inequality rows plus
an unrestricted combination of saved equality rows. The lower-bound routine
rechecks those algebraic certificates against its own actual input matrices.
"""

from __future__ import annotations

from fractions import Fraction
from functools import lru_cache
import hashlib
import math
from numbers import Integral, Real
import re

F0 = Fraction(0)
F1 = Fraction(1)


def exact(value):
    """Recover an actual finite binary floating value, never a short decimal."""
    if isinstance(value, Fraction):
        return value
    if isinstance(value, bool):
        raise ValueError("BOOLEAN_IS_NOT_A_COEFFICIENT")
    if isinstance(value, Integral):
        return Fraction(int(value))
    if isinstance(value, Real):
        number = float(value)
        if not math.isfinite(number):
            raise ValueError("NONFINITE_INPUT")
        return Fraction.from_float(number)
    raise ValueError("UNSUPPORTED_COEFFICIENT_TYPE:" + type(value).__name__)


def _vector(values, length=None):
    result = [exact(value) for value in values]
    if length is not None and len(result) != length:
        raise ValueError("VECTOR_DIMENSION_MISMATCH")
    return result


def _matrix(values, columns):
    return [_vector(row, columns) for row in values]


def _dot(left, right):
    return sum((a * b for a, b in zip(left, right) if a and b), F0)


def _digest(matrix):
    digest = hashlib.sha256()
    for row in matrix:
        digest.update(("|".join(f"{x.numerator}/{x.denominator}" for x in row) + "\n").encode("ascii"))
    return digest.hexdigest()


def _failure(reason, *, status="INCONCLUSIVE", proof=None, dimensions=None, label_map=None):
    return {"status": status, "reason": reason, "lower": None, "upper": None,
            "proof": proof or {}, "dimensions": dimensions or {}, "label_map": label_map or {}}


def _certificate(variable, sign, equality=None, inequality=None, rhs=F0):
    return {"variable": variable, "sign": sign,
            "equality_weights": dict(equality or {}),
            "inequality_weights": dict(inequality or {}), "rhs": rhs}


def _add_weights(destination, source, scale):
    for row, weight in source.items():
        destination[row] = destination.get(row, F0) + scale * weight
        if not destination[row]:
            del destination[row]


def _combine(variable, sign, parts, equality=None, rhs=F0):
    result = _certificate(variable, sign, equality=equality, rhs=rhs)
    for scale, certificate in parts:
        if scale < 0:
            raise ValueError("NEGATIVE_BOX_COMBINATION")
        _add_weights(result["equality_weights"], certificate["equality_weights"], scale)
        _add_weights(result["inequality_weights"], certificate["inequality_weights"], scale)
        result["rhs"] += scale * certificate["rhs"]
    return result


def _labels(problem):
    equality, inequality = {}, {}
    mapping = []
    for kind, destination in (("equality", equality), ("inequality", inequality)):
        for index, label in enumerate(problem[kind + "_labels"]):
            if not isinstance(label, str):
                raise ValueError("NONSTRING_LABEL")
            canonical = label
            for prefix in ("p0_", "reference_"):
                if canonical.startswith(prefix):
                    canonical = canonical[len(prefix):]
                    break
            if canonical in equality or canonical in inequality:
                raise ValueError("DUPLICATE_CANONICAL_LABEL:" + canonical)
            destination[canonical] = index
            mapping.append({"kind": kind, "row": index, "original": label, "canonical": canonical})
    expected_equality = {f"dynamics[{i}]" for i in range(18)} | {f"contact_acceleration[{i}]" for i in range(12)}
    if set(equality) != expected_equality:
        raise ValueError("UNSUPPORTED_EQUALITY_LABEL_SET")
    feet = set()
    for label in inequality:
        match = re.fullmatch(r"normal_upper\[([A-Za-z0-9_]+)\]", label)
        if match:
            feet.add(match.group(1))
    if len(feet) != 4:
        raise ValueError("EXPECTED_FOUR_LABELED_CONTACTS")
    expected_inequality = (
        {f"torque_{side}[{i}]" for side in ("upper", "lower") for i in range(12)}
        | {f"fixed_task_{side}[{i}]" for side in ("upper", "lower") for i in range(8)}
        | {f"normal_{side}[{foot}]" for side in ("upper", "lower") for foot in feet}
        | {f"friction[{foot},{i}]" for foot in feet for i in range(4)}
    )
    if set(inequality) != expected_inequality:
        raise ValueError("UNSUPPORTED_INEQUALITY_LABEL_SET")
    return equality, inequality, sorted(feet), mapping


def _single_bound(G, h, row, variable, sign):
    coefficients = G[row]
    if [i for i, value in enumerate(coefficients) if value] != [variable] or coefficients[variable] * sign <= 0:
        raise ValueError("BOUND_ROW_NOT_EXPECTED_SINGLE_SIGNED_COORDINATE")
    scale = Fraction(sign, 1) / coefficients[variable]
    return _certificate(variable, sign, inequality={row: scale}, rhs=scale * h[row])


@lru_cache(maxsize=16)
def _invert_exact(matrix):
    n = len(matrix)
    augmented = [list(row) + [Fraction(i == j) for j in range(n)] for i, row in enumerate(matrix)]
    for col in range(n):
        pivot = next((row for row in range(col, n) if augmented[row][col]), None)
        if pivot is None:
            raise ValueError("DYNAMICS_MASS_MATRIX_SINGULAR")
        if pivot != col:
            augmented[col], augmented[pivot] = augmented[pivot], augmented[col]
        pivot_value = augmented[col][col]
        augmented[col] = [value / pivot_value for value in augmented[col]]
        for row in range(n):
            if row == col or not augmented[row][col]:
                continue
            factor = augmented[row][col]
            augmented[row] = [a - factor * b for a, b in zip(augmented[row], augmented[col])]
    inverse = tuple(tuple(row[n:]) for row in augmented)
    for i in range(n):
        for j in range(n):
            if sum((matrix[i][k] * inverse[k][j] for k in range(n)), F0) != Fraction(i == j):
                raise ValueError("EXACT_INVERSE_IDENTITY_VERIFICATION_FAILED")
    return inverse


def verify_box_certificate(E, d, G, h, box):
    """Verify finite bounds as exact row consequences; a status label is insufficient."""
    try:
        if not isinstance(box, dict) or box.get("status") != "CERTIFIED":
            return {"status": "INCONCLUSIVE", "reason": "UNPROVEN_BOX"}
        lower, upper = _vector(box["lower"]), _vector(box["upper"])
        n = len(lower)
        if not n or len(upper) != n:
            raise ValueError("BOX_DIMENSION_MISMATCH")
        E, G = _matrix(E, n), _matrix(G, n)
        d, h = _vector(d, len(E)), _vector(h, len(G))
        if any(a > b for a, b in zip(lower, upper)):
            return {"status": "INCONSISTENCY_DETECTED", "reason": "EMPTY_BOX_INTERVAL"}
        proof = box["proof"]
        for kind, sign, values in (("lower_certificates", -1, lower), ("upper_certificates", 1, upper)):
            certificates = proof[kind]
            if len(certificates) != n:
                raise ValueError("MISSING_BOX_FACE_CERTIFICATE")
            for variable, certificate in enumerate(certificates):
                if certificate["variable"] != variable or certificate["sign"] != sign:
                    raise ValueError("BOX_FACE_IDENTITY_MISMATCH")
                coefficients = [F0] * n
                rhs = F0
                for name, matrix, vector, nonnegative in (("equality_weights", E, d, False), ("inequality_weights", G, h, True)):
                    for row_key, weight_value in certificate[name].items():
                        row = int(row_key)
                        if str(row) != str(row_key) or not 0 <= row < len(matrix):
                            raise ValueError("BOX_PROOF_ROW_INDEX_INVALID")
                        weight = exact(weight_value)
                        if nonnegative and weight < 0:
                            raise ValueError("BOX_PROOF_NEGATIVE_INEQUALITY_WEIGHT")
                        for col, value in enumerate(matrix[row]):
                            coefficients[col] += weight * value
                        rhs += weight * vector[row]
                expected = [F0] * n
                expected[variable] = Fraction(sign)
                if coefficients != expected or rhs != sign * values[variable] or rhs != exact(certificate["rhs"]):
                    raise ValueError("BOX_FACE_ALGEBRA_MISMATCH")
        return {"status": "CERTIFIED", "reason": "ALL_BOX_FACES_EXACT_ROW_CONSEQUENCES", "faces_verified": 2 * n}
    except (ValueError, TypeError, KeyError, IndexError) as exc:
        return {"status": "INCONCLUSIVE", "reason": str(exc)}


def derive_box(problem) -> dict:
    """Prove finite bounds for saved Go2 [qdd18,tau12,contact12] variables."""
    proof, dimensions, mapping = {}, {}, []
    try:
        n = len(problem["original_q"])
        E, G = _matrix(problem["original_E"], n), _matrix(problem["original_G"], n)
        d, h = _vector(problem["original_f"], len(E)), _vector(problem["original_h"], len(G))
        P, q = _matrix(problem["original_P"], n), _vector(problem["original_q"], n)
        dimensions = {"variables": n, "equalities": len(E), "inequalities": len(G), "qdd": 18, "torque": 12, "contact_force": 12}
        if (n, len(P), len(E), len(G)) != (42, 42, 30, 64):
            raise ValueError("UNSUPPORTED_SAVED_QP_DIMENSIONS")
        equality, inequality, feet, mapping = _labels(problem)
        if len(problem["equality_labels"]) != len(E) or len(problem["inequality_labels"]) != len(G):
            raise ValueError("LABEL_ROW_COUNT_MISMATCH")
        proof = {
            "algorithm": "EXACT_ROW_COMBINATIONS_AND_DYNAMICS_INTERVAL_MAP_V1",
            "inputs": {"P": P, "q": q, "E": E, "d": d, "G": G, "h": h},
            "input_sha256": {"P": _digest(P), "q": _digest([q]), "E": _digest(E), "d": _digest([d]), "G": _digest(G), "h": _digest([h])},
            "torque": [], "contacts": [], "dynamics": {}, "task_intersections": [],
        }
        lower_proofs, upper_proofs = [None] * n, [None] * n
        for actuator in range(12):
            variable = 18 + actuator
            upper_row, lower_row = (inequality[f"torque_{side}[{actuator}]"] for side in ("upper", "lower"))
            upper_proofs[variable] = _single_bound(G, h, upper_row, variable, 1)
            lower_proofs[variable] = _single_bound(G, h, lower_row, variable, -1)
            proof["torque"].append({"actuator": actuator, "variable": variable, "upper_row": upper_row, "lower_row": lower_row, "upper_certificate": upper_proofs[variable], "lower_certificate": lower_proofs[variable]})

        contact_coordinates = set()
        for foot in feet:
            normal_upper_row, normal_lower_row = (inequality[f"normal_{side}[{foot}]"] for side in ("upper", "lower"))
            nonzero = [i for i, value in enumerate(G[normal_upper_row]) if value]
            if len(nonzero) != 1 or nonzero[0] not in (32, 35, 38, 41):
                raise ValueError("NORMAL_FORCE_COORDINATE_STRUCTURE_MISMATCH")
            z = nonzero[0]
            if z in contact_coordinates:
                raise ValueError("DUPLICATE_CONTACT_BLOCK")
            contact_coordinates.add(z)
            x, y = z - 2, z - 1
            upper_proofs[z] = _single_bound(G, h, normal_upper_row, z, 1)
            lower_proofs[z] = _single_bound(G, h, normal_lower_row, z, -1)
            faces = {}
            common = None
            for face in range(4):
                row = inequality[f"friction[{foot},{face}]"]
                if [i for i, value in enumerate(G[row]) if value] != [x, y, z]:
                    raise ValueError("FRICTION_NOT_THREE_COMPONENT_L1_FACE")
                gx, gy, gz = G[row][x], G[row][y], G[row][z]
                if gz >= 0:
                    raise ValueError("FRICTION_NORMAL_COEFFICIENT_NOT_NEGATIVE")
                characteristic = (abs(gx), abs(gy), gz)
                if common is None:
                    common = characteristic
                elif common != characteristic:
                    raise ValueError("FRICTION_FACES_NOT_ONE_COMMON_L1_PYRAMID")
                signs = (1 if gx > 0 else -1, 1 if gy > 0 else -1)
                if signs in faces:
                    raise ValueError("DUPLICATE_FRICTION_FACE_SIGNS")
                faces[signs] = row
            if set(faces) != {(1, 1), (1, -1), (-1, 1), (-1, -1)}:
                raise ValueError("MISSING_FRICTION_L1_SIGN_COMBINATION")
            contact_proof = {"foot": foot, "coordinates": [x, y, z], "normal_upper_certificate": upper_proofs[z], "normal_lower_certificate": lower_proofs[z], "friction_faces": [{"signs": list(signs), "row": row} for signs, row in sorted(faces.items())], "tangent_combinations": []}
            for variable, axis in ((x, 0), (y, 1)):
                for sign in (-1, 1):
                    row_a, row_b = [row for signs, row in sorted(faces.items()) if signs[axis] == sign]
                    alpha = F1 / (2 * abs(G[row_a][variable]))
                    pair = _certificate(variable, sign, inequality={row_a: alpha, row_b: alpha}, rhs=alpha * (h[row_a] + h[row_b]))
                    combined_normal = alpha * (G[row_a][z] + G[row_b][z])
                    final = _combine(variable, sign, [(F1, pair), (-combined_normal, upper_proofs[z])])
                    (upper_proofs if sign > 0 else lower_proofs)[variable] = final
                    contact_proof["tangent_combinations"].append({"variable": variable, "sign": sign, "paired_friction_rows": [row_a, row_b], "pair_weights": [alpha, alpha], "normal_upper_weight": -combined_normal, "certificate": final})
            proof["contacts"].append(contact_proof)
        if contact_coordinates != {32, 35, 38, 41}:
            raise ValueError("CONTACT_FORCE_COVERAGE_INCOMPLETE")

        for i in range(18, 42):
            if -lower_proofs[i]["rhs"] > upper_proofs[i]["rhs"]:
                proof["empty_interval"] = {"variable": i, "lower_certificate": lower_proofs[i], "upper_certificate": upper_proofs[i]}
                return _failure("EMPTY_ACTUATOR_OR_CONTACT_INTERVAL", status="INCONSISTENCY_DETECTED", proof=proof, dimensions=dimensions, label_map=mapping)
        dynamic_rows = [equality[f"dynamics[{i}]"] for i in range(18)]
        for i in range(12):
            if any(E[equality[f"contact_acceleration[{i}]"]][18:]):
                raise ValueError("CONTACT_EQUALITY_HAS_NON_ACCELERATION_COEFFICIENTS")
        M = tuple(tuple(E[row][:18]) for row in dynamic_rows)
        cache_before = _invert_exact.cache_info()
        inverse = _invert_exact(M)
        cache_after = _invert_exact.cache_info()
        dyn_rhs = [d[row] for row in dynamic_rows]
        other = [E[row][18:] for row in dynamic_rows]
        offset = [_dot(row, dyn_rhs) for row in inverse]
        linear = [[-sum((inverse[i][k] * other[k][j] for k in range(18)), F0) for j in range(24)] for i in range(18)]
        proof["dynamics"] = {"row_indices": dynamic_rows, "mass_matrix": M, "mass_matrix_exact_sha256": _digest(M), "inverse": inverse, "inverse_product_identity_exact": True, "inverse_cache_hit": cache_after.hits > cache_before.hits, "other_coefficients": other, "rhs": dyn_rhs, "offset": offset, "other_variable_linear_map": linear, "coordinate_bounds": []}
        for i in range(18):
            for sign in (-1, 1):
                equality_weights = {dynamic_rows[k]: sign * inverse[i][k] for k in range(18) if inverse[i][k]}
                parts = []
                endpoint_choices = []
                for j, coefficient in enumerate(linear[i]):
                    if not coefficient:
                        continue
                    variable = 18 + j
                    selected = upper_proofs[variable] if sign * coefficient > 0 else lower_proofs[variable]
                    parts.append((abs(coefficient), selected))
                    endpoint_choices.append({"variable": variable, "coefficient": coefficient, "chosen_box_face_sign": selected["sign"], "combination_weight": abs(coefficient)})
                certificate = _combine(i, sign, parts, equality=equality_weights, rhs=sign * offset[i])
                (upper_proofs if sign > 0 else lower_proofs)[i] = certificate
                proof["dynamics"]["coordinate_bounds"].append({"variable": i, "sign": sign, "endpoint_choices": endpoint_choices, "certificate": certificate})

        task_coordinates = set()
        for task in range(8):
            up, low = (inequality[f"fixed_task_{side}[{task}]"] for side in ("upper", "lower"))
            nonzero = [i for i, value in enumerate(G[up]) if value]
            if len(nonzero) != 1 or not 0 <= nonzero[0] < 18 or nonzero[0] in task_coordinates:
                raise ValueError("TASK_SELECTOR_STRUCTURE_MISMATCH")
            variable = nonzero[0]
            task_coordinates.add(variable)
            task_upper, task_lower = _single_bound(G, h, up, variable, 1), _single_bound(G, h, low, variable, -1)
            old_lower, old_upper = -lower_proofs[variable]["rhs"], upper_proofs[variable]["rhs"]
            if task_lower["rhs"] < lower_proofs[variable]["rhs"]:
                lower_proofs[variable] = task_lower
            if task_upper["rhs"] < upper_proofs[variable]["rhs"]:
                upper_proofs[variable] = task_upper
            new_lower, new_upper = -lower_proofs[variable]["rhs"], upper_proofs[variable]["rhs"]
            proof["task_intersections"].append({"task": task, "variable": variable, "pre_intersection_lower": old_lower, "pre_intersection_upper": old_upper, "task_lower_certificate": task_lower, "task_upper_certificate": task_upper, "intersection_lower": new_lower, "intersection_upper": new_upper})
            if new_lower > new_upper:
                proof["empty_interval"] = {"variable": variable, "lower_certificate": lower_proofs[variable], "upper_certificate": upper_proofs[variable]}
                return _failure("EMPTY_TASK_DYNAMICS_INTERSECTION", status="INCONSISTENCY_DETECTED", proof=proof, dimensions=dimensions, label_map=mapping)
        lower, upper = [-item["rhs"] for item in lower_proofs], [item["rhs"] for item in upper_proofs]
        proof["lower_certificates"], proof["upper_certificates"] = lower_proofs, upper_proofs
        result = {"status": "CERTIFIED", "reason": "FINITE_BOX_PROVED_FROM_SAVED_ORIGINAL_ROWS", "lower": lower, "upper": upper, "proof": proof, "dimensions": dimensions, "label_map": mapping}
        verification = verify_box_certificate(E, d, G, h, result)
        proof["final_face_verification"] = verification
        if verification["status"] != "CERTIFIED":
            return _failure(verification["reason"], proof=proof, dimensions=dimensions, label_map=mapping)
        return result
    except MemoryError:
        return _failure("RESOURCE_INSUFFICIENT_EXACT_ARITHMETIC", proof=proof, dimensions=dimensions, label_map=mapping)
    except (ValueError, TypeError, KeyError, IndexError, ZeroDivisionError) as exc:
        return _failure(str(exc), proof=proof, dimensions=dimensions, label_map=mapping)


def lagrangian_lower_bound(P, q, E, d, G, h, nu, mu, box, c_original=Fraction(0)) -> dict:
    """Fixed saved multipliers; exact separable infimum over a proved box.

    A finite box list or a bare CERTIFIED status does not suffice: all box
    faces are independently verified against E,d,G,h before this returns L.
    """
    failure = {"status": "INCONCLUSIVE", "L": None, "k": None, "constant": None, "coordinate_minima": []}
    try:
        q = _vector(q)
        n = len(q)
        P, E, G = _matrix(P, n), _matrix(E, n), _matrix(G, n)
        if len(P) != n:
            raise ValueError("P_DIMENSION_MISMATCH")
        d, h = _vector(d, len(E)), _vector(h, len(G))
        nu, mu = _vector(nu, len(E)), _vector(mu, len(G))
        constant_original = exact(c_original)
        if any(P[i][j] != P[j][i] or (i != j and P[i][j] != 0) for i in range(n) for j in range(n)) or any(P[i][i] < 0 for i in range(n)):
            return {**failure, "reason": "UNSUPPORTED_P_STRUCTURE"}
        negative = [{"row": i, "value": value} for i, value in enumerate(mu) if value < 0]
        if negative:
            return {**failure, "reason": "NEGATIVE_INEQUALITY_MULTIPLIER", "negative_mu": negative}
        verification = verify_box_certificate(E, d, G, h, box)
        if verification["status"] != "CERTIFIED":
            return {**failure, "reason": "UNPROVEN_BOX:" + verification["reason"], "box_verification": verification}
        lower, upper = _vector(box["lower"], n), _vector(box["upper"], n)
        k = [q[i] + sum((E[j][i] * nu[j] for j in range(len(E))), F0) + sum((G[j][i] * mu[j] for j in range(len(G))), F0) for i in range(n)]
        constant = constant_original - _dot(nu, d) - _dot(mu, h)
        minima = []
        for i in range(n):
            candidates = [("lower", lower[i]), ("upper", upper[i])]
            if P[i][i] > 0:
                stationary = -k[i] / P[i][i]
                if lower[i] <= stationary <= upper[i]:
                    candidates.append(("stationary", stationary))
            evaluated = [{"kind": kind, "argument": t, "value": P[i][i] * t * t / 2 + k[i] * t} for kind, t in candidates]
            selected = min(evaluated, key=lambda item: (item["value"], item["argument"]))
            minima.append({"coordinate": i, "P_diagonal": P[i][i], "k": k[i], "lower": lower[i], "upper": upper[i], "evaluated_candidates": evaluated, "minimizer": selected["argument"], "minimum": selected["value"], "selected_kind": selected["kind"]})
        L = constant + sum((item["minimum"] for item in minima), F0)
        return {"status": "CERTIFIED", "reason": "EXACT_FIXED_MULTIPLIER_BOX_LAGRANGIAN_INFIMUM", "L": L, "k": k, "constant": constant, "c_original": constant_original, "nu": nu, "mu": mu, "coordinate_minima": minima, "box_verification": verification, "does_not_prove_primal_feasibility": True,
                "proof": "Every original feasible w is in the verified box; mu>=0 implies Lagrangian(w)<=objective(w). The exact box infimum L is no greater than that Lagrangian value, hence L<=f*. No stationarity assumption or candidate repair is used."}
    except MemoryError:
        return {**failure, "reason": "RESOURCE_INSUFFICIENT_EXACT_ARITHMETIC"}
    except (ValueError, TypeError, KeyError, IndexError, ZeroDivisionError) as exc:
        return {**failure, "reason": str(exc)}
