"""Exact saved-candidate audit; no construction, solve, repair or new witness.

The physical witness saved by STEP-02F is the primary object. The exact affine
image is a separate algebraic diagnostic and never replaces that witness.
"""

from __future__ import annotations

from fractions import Fraction
from types import SimpleNamespace
from typing import Any, Mapping

import numpy as np

from cavr_wbc.evaluation.step02g_bounds import derive_box, exact, lagrangian_lower_bound
from cavr_wbc.evaluation.step02g_endpoints import canonical_label


ZERO = Fraction(0)


def _vector(values):
    return [exact(value) for value in values]


def _matrix(values):
    return [_vector(row) for row in values]


def _dot(left, right):
    if len(left) != len(right):
        raise ValueError("Exact vector dimensions differ")
    return sum((a * b for a, b in zip(left, right) if a and b), ZERO)


def _matvec(matrix, vector):
    return [_dot(row, vector) for row in matrix]


def _transpose_product(matrix, vector, n):
    if len(matrix) != len(vector):
        raise ValueError("Exact transpose-product dimensions differ")
    return [sum((row[i] * value for row, value in zip(matrix, vector) if row[i] and value), ZERO)
            for i in range(n)]


def _maximum(values, *, start=0):
    if not values:
        return {"absolute_maximum": ZERO, "index": None, "signed_value": ZERO}
    index = max(range(len(values)), key=lambda i: abs(values[i]))
    return {"absolute_maximum": abs(values[index]), "index": start + index, "signed_value": values[index]}


def map_multipliers(problem: Mapping[str, Any], dual) -> tuple[list[Fraction], list[Fraction]]:
    """Map the saved cone dual to physical equality/inequality units once."""
    ne, ng = len(problem["original_E"]), len(problem["original_G"])
    vector = _vector(dual)
    equality_scales = _vector(problem["equality_row_scales"])
    inequality_scales = _vector(problem["inequality_row_scales"])
    if len(vector) != ne + ng or len(equality_scales) != ne or len(inequality_scales) != ng:
        raise ValueError("Saved multiplier/row-scale dimensions disagree")
    if any(scale <= 0 for scale in equality_scales + inequality_scales):
        raise ValueError("Saved row scales must be positive")
    return ([scale * value for scale, value in zip(equality_scales, vector[:ne])],
            [scale * value for scale, value in zip(inequality_scales, vector[ne:])])


def candidate_objective_bounds(P, q, E, d, G, h, witness, lower_bound, c_original=ZERO) -> dict:
    """Condition upper bound/gap on exact original-QP feasibility, never a tolerance."""
    P, q, E, d, G, h, w = _matrix(P), _vector(q), _matrix(E), _vector(d), _matrix(G), _vector(h), _vector(witness)
    if len(P) != len(w) or len(q) != len(w) or len(E) != len(d) or len(G) != len(h):
        raise ValueError("Saved original objective/constraint dimensions disagree")
    equalities = [value - rhs for value, rhs in zip(_matvec(E, w), d)]
    inequalities = [value - rhs for value, rhs in zip(_matvec(G, w), h)]
    objective = _dot(w, _matvec(P, w)) / 2 + _dot(q, w) + exact(c_original)
    feasible = all(value == 0 for value in equalities) and all(value <= 0 for value in inequalities)
    L = lower_bound.get("L") if lower_bound.get("status") == "CERTIFIED" else None
    if L is not None:
        L = exact(L)
    return {
        "exact_original_qp_feasible": feasible,
        "candidate_objective": objective,
        "strict_lower_bound": L,
        "candidate_objective_minus_lower_bound": None if L is None else objective - L,
        "strict_primal_upper_bound": objective if feasible else None,
        "strict_optimality_gap": objective - L if feasible and L is not None else None,
        "exact_equality_residual": equalities,
        "exact_inequality_residual": inequalities,
        "interpretation": "The candidate objective is an upper bound only when every original equality is exactly zero and every inequality residual is nonpositive.",
    }


def _saved_arrays(problem):
    shapes = {
        "original_P": (42, 42), "original_q": (42,), "original_E": (30, 42),
        "original_f": (30,), "original_G": (64, 42), "original_h": (64,),
        "P": (42, 42), "q": (42,), "E": (30, 42), "f": (30,),
        "G": (64, 42), "h": (64,), "A": (94, 42), "b": (94,),
        "D": (42,), "a": (42,), "R": (42,),
        "equality_row_scales": (30,), "inequality_row_scales": (64,),
    }
    arrays = {}
    for key, shape in shapes.items():
        array = np.asarray(problem[key])
        if array.dtype != np.dtype("float64") or array.shape != shape or not np.isfinite(array).all():
            raise ValueError(f"Saved {key} has unsupported dtype, shape or nonfinite data")
        arrays[key] = array
    if np.any(arrays["D"] <= 0) or np.any(arrays["R"] <= 0):
        raise ValueError("Saved variable scales must be positive")
    return arrays


def _reconstruct_validator_snapshot(problem, config, health_id):
    """Extract only quantities the frozen validator uses, from saved physical rows."""
    data = _saved_arrays(problem)
    eq_labels = [canonical_label(value, equality=True) for value in problem["equality_labels"]]
    ineq_labels = [canonical_label(value, equality=False) for value in problem["inequality_labels"]]
    if len(eq_labels) != 30 or len(set(eq_labels)) != 30 or len(ineq_labels) != 64 or len(set(ineq_labels)) != 64:
        raise ValueError("Saved constraint labels missing or duplicated")
    expected_eq = [f"dynamics[{i}]" for i in range(18)] + [f"contact_acceleration[{i}]" for i in range(12)]
    if eq_labels != expected_eq:
        raise ValueError("Saved equality/cone row order differs from verified dynamics/contact order")
    index = {label: i for i, label in enumerate(ineq_labels)}
    feet = tuple(config["physical_model"]["fixed_feet"])
    if feet != ("FL", "FR", "RL", "RR"):
        raise ValueError("Frozen contact order differs")
    expected_ineq = [f"torque_{side}[{i}]" for i in range(12) for side in ("upper", "lower")]
    for foot in feet:
        expected_ineq.extend([f"friction[{foot},{face}]" for face in range(4)])
        expected_ineq.extend([f"normal_lower[{foot}]", f"normal_upper[{foot}]"])
    expected_ineq.extend([f"fixed_task_{side}[{i}]" for i in range(8) for side in ("upper", "lower")])
    if ineq_labels != expected_ineq:
        raise ValueError("Saved inequality/cone row order differs from frozen schema")
    all_scales = np.concatenate((data["equality_row_scales"], data["inequality_row_scales"]))
    if np.any(all_scales <= 0) or not np.array_equal(data["A"], all_scales[:, None] * np.vstack((data["E"], data["G"]))) or not np.array_equal(data["b"], all_scales * np.concatenate((data["f"], data["h"]))):
        raise ValueError("Saved cone order and row-scale product could not be confirmed")
    E, d, G, h = data["original_E"], data["original_f"], data["original_G"], data["original_h"]
    mass, selection, J = E[:18, :18], -E[:18, 18:30], E[18:, :18]
    if not np.array_equal(E[:18, 30:], -J.T) or np.any(E[18:, 18:]):
        raise ValueError("Saved E does not encode the verified physical dynamics/contact convention")
    torque_scales = data["D"][18:30]
    torque_bounds = []
    for i in range(12):
        for side, sign in (("upper", 1.0), ("lower", -1.0)):
            row = index[f"torque_{side}[{i}]"]
            expected = np.zeros(42)
            expected[18 + i] = sign
            if not np.array_equal(G[row], expected):
                raise ValueError("Saved torque row has unsupported coefficients")
        upper, lower = h[index[f"torque_upper[{i}]"]], h[index[f"torque_lower[{i}]"]]
        if upper != lower:
            raise ValueError("Frozen symmetric torque bounds disagree")
        torque_bounds.append(upper)
    torque_bounds = np.asarray(torque_bounds)
    rho = torque_bounds / torque_scales
    if np.any(rho < 0) or np.any(rho > 1) or not np.array_equal(rho * torque_scales, torque_bounds):
        raise ValueError("Health factor does not reconstruct saved torque bounds exactly in binary64")
    names = list(config["_audited_actuator_names"])
    if len(names) != 12 or len(set(names)) != 12:
        raise ValueError("Audited actuator names must have 12 unique index-ordered entries")
    specs = [row for row in config["health_panel"] if row["health_id"] == health_id]
    if len(specs) != 1:
        raise ValueError("Case health ID missing or duplicated in frozen panel")
    expected_rho = np.ones(12)
    if specs[0]["actuator"] is not None:
        expected_rho[names.index(specs[0]["actuator"])] = float(specs[0]["rho"])
    if not np.array_equal(rho, expected_rho):
        raise ValueError("Saved physical torque bounds disagree with named frozen health condition")
    friction, upper_forces = [], []
    for foot_index, foot in enumerate(feet):
        base = 30 + 3 * foot_index
        mu = -G[index[f"friction[{foot},0]"], base + 2]
        if mu <= 0:
            raise ValueError("Saved friction coefficient is not positive")
        for face, (sx, sy) in enumerate(((1, 1), (1, -1), (-1, 1), (-1, -1))):
            row = index[f"friction[{foot},{face}]"]
            expected = np.zeros(42)
            expected[base:base + 3] = [sx, sy, -mu]
            if not np.array_equal(G[row], expected) or h[row] != 0:
                raise ValueError("Saved friction row differs from frozen L1 face convention")
        for side, sign in (("lower", -1), ("upper", 1)):
            row = index[f"normal_{side}[{foot}]"]
            expected = np.zeros(42)
            expected[base + 2] = sign
            if not np.array_equal(G[row], expected):
                raise ValueError("Saved normal force row differs from frozen convention")
        if h[index[f"normal_lower[{foot}]"]] != 0:
            raise ValueError("Frozen normal lower bound must be zero")
        friction.append(mu)
        upper_forces.append(h[index[f"normal_upper[{foot}]"]])
    task_matrix = np.zeros((8, 18))
    for task in range(8):
        up, low = index[f"fixed_task_upper[{task}]"], index[f"fixed_task_lower[{task}]"]
        nonzero = np.flatnonzero(G[up])
        if len(nonzero) != 1 or nonzero[0] >= 18 or G[up, nonzero[0]] != 1 or not np.array_equal(G[low], -G[up]):
            raise ValueError("Saved task is not a signed qdd unit selector pair")
        task_matrix[task] = G[up, :18]
    if len(set(np.argmax(task_matrix, axis=1))) != 8:
        raise ValueError("Saved task selectors are not unique")
    snapshot = SimpleNamespace(
        nv=18, nu=12, nlambda=12, decision_dimension=42, task_dimension=8,
        mass_matrix=mass, bias_force=-d[:18], selection_matrix=selection,
        contact_jacobian=J, contact_acceleration_bias=-d[18:],
        torque_scales=torque_scales, friction_mu=np.asarray(friction),
        normal_force_upper=np.asarray(upper_forces), foot_names=feet,
        task_matrix=task_matrix, task_bias=np.zeros(8),
        task_scales=np.asarray(config["task_stack"]["normalization_scales"], dtype=float),
        task_weights=np.asarray(config["task_stack"]["weight_diagonal"], dtype=float),
    )
    if snapshot.task_scales.shape != (8,) or np.any(snapshot.task_scales <= 0):
        raise ValueError("Invalid frozen task scales")
    return snapshot, rho, data, eq_labels, ineq_labels


def _stationarity(P, q, E, G, nu, mu, w):
    n = len(q)
    terms = (_matvec(P, w), q, _transpose_product(E, nu, n), _transpose_product(G, mu, n))
    return [sum(values, ZERO) for values in zip(*terms)]


def audit_candidate(problem, raw, certificate, config, stage_a_record) -> dict:
    """Audit one previously saved Stage-B record, including rejected statuses."""
    for key in ("solve_ordinal", "case_id", "path"):
        if raw[key] != certificate[key]:
            raise ValueError(f"Saved raw/certificate join differs: {key}")
    identifiers = raw["case_id"].split("__")
    if len(identifiers) != 3:
        raise ValueError("Frozen case ID has unsupported schema")
    health_id = identifiers[1]
    snapshot, rho, arrays, equality_labels, inequality_labels = _reconstruct_validator_snapshot(problem, config, health_id)
    original_w = np.asarray(certificate["original_witness"], dtype=float)
    saved_affine_constant = np.asarray(problem["objective_constant"])
    if saved_affine_constant.shape != () or saved_affine_constant.dtype != np.dtype("float64") or not np.isfinite(saved_affine_constant):
        raise ValueError("Saved affine objective_constant must be one finite binary64 scalar")
    z_float = np.asarray(raw["z_coordinate"], dtype=float)
    dual_float = np.asarray(raw["dual"], dtype=float)
    target_float = np.asarray(certificate["cached_stage_a_target"], dtype=float)
    if original_w.shape != (42,) or z_float.shape != (42,) or dual_float.shape != (94,) or target_float.shape != (8,) or not all(np.isfinite(value).all() for value in (original_w, z_float, dual_float, target_float)):
        raise ValueError("Saved candidate/dual/target data are missing or nonfinite")
    if not np.array_equal(target_float, np.asarray(stage_a_record["task_output"], dtype=float)):
        raise ValueError("Saved cached target disagrees with joined Stage-A evidence")
    selectors = np.argmax(snapshot.task_matrix, axis=1)
    if not np.array_equal(arrays["a"][selectors], target_float):
        raise ValueError("Saved affine origin differs from the cached Stage-A target")
    if not np.array_equal(arrays["a"] + arrays["R"] * z_float, original_w):
        raise ValueError("Saved original witness differs from its archived float64 inverse mapping")

    # This import exposes only the historical validator; root installs the
    # fail-fast optimizer guard before entering this function.
    from cavr_wbc.control.scaled_fixed_support_qp import validate_original_witness
    validation = validate_original_witness(snapshot, rho, original_w[:18], original_w[18:30], original_w[30:], fixed_task_output=target_float)
    thresholds = config["validation"]
    metric_thresholds = {
        "dynamics_infinity_norm": float(thresholds["dynamics_infinity_norm"]),
        "contact_infinity_norm": float(thresholds["contact_infinity_norm"]),
        "hard_inequality_violation": float(thresholds["hard_inequality_violation"]),
        "health_adapter_identity_error": float(thresholds["health_adapter_identity"]),
        "fixed_task_normalized_infinity_error": float(config["objectives"]["secondary_task_fix_normalized_tolerance"]),
    }
    if list(metric_thresholds.values()) != [1e-6, 1e-6, 1e-7, 1e-9, 1e-8]:
        raise ValueError("Frozen numeric acceptance thresholds changed")
    gates = {key: {"value": validation[key], "threshold": threshold, "pass": validation[key] <= threshold}
             for key, threshold in metric_thresholds.items()}
    physical = all(gates[key]["pass"] for key in metric_thresholds if key != "fixed_task_normalized_infinity_error")
    band = gates["fixed_task_normalized_infinity_error"]["pass"]
    accepted = raw["status"] == "Solved"
    historical_comparison = {key: {"equal": validation[key] == certificate["validation"].get(key),
                                    "replayed": validation[key], "saved": certificate["validation"].get(key)}
                             for key in validation}
    historical_gate_comparison = {
        "numeric_physical_matches": physical == certificate["raw_candidate_physical_pass"],
        "numeric_band_matches": band == certificate["raw_candidate_fixed_band_pass"],
        "status_matches": accepted == raw["status_accepted"] == certificate["status_accepted"],
    }

    P, q, E, d, G, h = (_matrix(arrays[key]) if key in ("original_P", "original_E", "original_G") else _vector(arrays[key])
                         for key in ("original_P", "original_q", "original_E", "original_f", "original_G", "original_h"))
    w, z, a, R = _vector(original_w), _vector(z_float), _vector(arrays["a"]), _vector(arrays["R"])
    affine_w = [origin + scale * value for origin, scale, value in zip(a, R, z)]
    inverse_rounding = [saved - auxiliary for saved, auxiliary in zip(w, affine_w)]
    nu, mu = map_multipliers(problem, dual_float)
    r_saved = _stationarity(P, q, E, G, nu, mu, w)
    r_affine = _stationarity(P, q, E, G, nu, mu, affine_w)
    encoded_P, encoded_q, encoded_A, dual = _matrix(arrays["P"]), _vector(arrays["q"]), _matrix(arrays["A"]), _vector(dual_float)
    r_z = [sum(values, ZERO) for values in zip(_matvec(encoded_P, z), encoded_q, _transpose_product(encoded_A, dual, 42))]
    encoding_term = [new - scale * old for new, scale, old in zip(r_z, R, r_affine)]
    inverse_term = [scale * (auxiliary - saved) for scale, auxiliary, saved in zip(R, r_affine, r_saved)]
    discrepancy = [new - scale * old for new, scale, old in zip(r_z, R, r_saved)]
    identity = all(total == encoded + inverse for total, encoded, inverse in zip(discrepancy, encoding_term, inverse_term))
    if not identity:
        raise ArithmeticError("Exact stationarity encoding/inverse-rounding decomposition failed")

    box = derive_box(problem)
    bound = lagrangian_lower_bound(P, q, E, d, G, h, nu, mu, box, c_original=ZERO)
    objective = candidate_objective_bounds(P, q, E, d, G, h, w, bound, c_original=ZERO)
    equality_residual = objective["exact_equality_residual"]
    inequality_residual = objective["exact_inequality_residual"]
    complementarity = [multiplier * residual for multiplier, residual in zip(mu, inequality_residual)]
    task_scales = _vector(snapshot.task_scales)
    targets = _vector(target_float)
    task_offsets = [(w[int(selector)] - target) / scale for selector, target, scale in zip(selectors, targets, task_scales)]
    exact_binary_band = all(abs(value) <= Fraction.from_float(1e-8) for value in task_offsets)
    exact_decimal_band = all(abs(value) <= Fraction(1, 100000000) for value in task_offsets)
    tau_scales = _vector(arrays["D"][18:30])
    unweighted = sum(((value / scale) ** 2 for value, scale in zip(w[18:30], tau_scales)), ZERO)
    lambda_binary = exact(float(config["objectives"]["lambda_tau"]))
    lambda_diagonal = [P[18 + i][18 + i] * scale * scale / 2 for i, scale in enumerate(tau_scales)]
    common_ratio = lambda_diagonal[0] if len(set(lambda_diagonal)) == 1 else None
    tau_only = all(P[i][j] == 0 for i in range(42) for j in range(42) if i != j or not 18 <= i < 30) and all(value == 0 for value in q)
    exact_conversion = common_ratio is not None and common_ratio > 0 and tau_only
    expected_diagonal_float = 2.0 * float(config["objectives"]["lambda_tau"]) / np.square(arrays["D"][18:30])
    frozen_objective_pattern = tau_only and np.array_equal(np.diag(arrays["original_P"])[18:30], expected_diagonal_float)
    if not frozen_objective_pattern:
        # Preserve the unsupported certificate result rather than repairing P.
        bound = {"status": "INCONCLUSIVE", "reason": "FROZEN_STAGE_B_OBJECTIVE_SOURCE_MISMATCH", "L": None}
        objective = candidate_objective_bounds(P, q, E, d, G, h, w, bound, c_original=ZERO)

    reasons = []
    if not objective["exact_original_qp_feasible"]:
        reasons.append("SAVED_CANDIDATE_NOT_EXACT_ORIGINAL_QP_FEASIBLE_NO_STRICT_PRIMAL_UPPER_BOUND_OR_GAP")
    if bound["status"] != "CERTIFIED":
        reasons.append(bound["reason"])
    if not accepted:
        reasons.append("FROZEN_SOLVER_STATUS_REJECTED_UNCHANGED")
    stationarity = _maximum(r_saved)
    stationarity_groups = {"qdd": _maximum(r_saved[:18]), "tau": _maximum(r_saved[18:30], start=18),
                           "contact_force": _maximum(r_saved[30:], start=30)}
    exact_evidence = {
        "input_recovery": "NPZ float64 and json.loads-restored finite binary64; Fraction.from_float/as_integer_ratio semantics; no decimal-string reinterpretation",
        "original_saved_witness": w, "saved_affine_coordinate": z,
        "auxiliary_exact_affine_image": affine_w, "saved_minus_exact_affine_image": inverse_rounding,
        "inverse_mapping_rounding_maximum": _maximum(inverse_rounding),
        "original_objective_constant": ZERO,
        "original_constant_source": "Frozen Stage-B objective desired_task=None: torque quadratic plus zero linear term, no original additive constant. Saved affine objective_constant is a distinct encoding term.",
        "saved_affine_objective_constant": exact(saved_affine_constant.item()),
        "original_equality_residual": equality_residual,
        "original_inequality_residual": inequality_residual,
        "equality_labels": equality_labels, "inequality_labels": inequality_labels,
        "equality_label_mapping": [{"original": str(old), "canonical": new} for old, new in zip(problem["equality_labels"], equality_labels)],
        "inequality_label_mapping": [{"original": str(old), "canonical": new} for old, new in zip(problem["inequality_labels"], inequality_labels)],
        "exact_violated_equality_rows": [i for i, value in enumerate(equality_residual) if value],
        "exact_violated_inequality_rows": [i for i, value in enumerate(inequality_residual) if value > 0],
        "nu_original": nu, "mu_original": mu,
        "negative_mu": [{"row": i, "value": value} for i, value in enumerate(mu) if value < 0],
        "stationarity_original_saved": r_saved, "stationarity_original_exact_affine_image": r_affine,
        "stationarity_by_variable_group": stationarity_groups,
        "complementarity_mu_times_Gw_minus_h": complementarity,
        "complementarity_maximum": _maximum(complementarity),
        "stationarity_encoded_z": r_z, "encoded_stationarity_maximum": _maximum(r_z),
        "stationarity_encoding_term": encoding_term, "stationarity_inverse_rounding_term": inverse_term,
        "stationarity_encoded_minus_R_original_saved": discrepancy,
        "stationarity_decomposition_exact_identity": identity,
        "solver_reported_diagnostics": {key: raw.get(key) for key in ("solver_primal_residual", "solver_dual_residual", "duality_gap", "gap_abs", "gap_rel", "kkt_primal_infinity", "kkt_stationarity_infinity", "complementarity_infinity", "primal_objective_without_constant", "dual_objective_without_constant")},
        "task_signed_normalized_offsets": task_offsets,
        "literal_binary64_band": Fraction.from_float(1e-8), "literal_decimal_band": Fraction(1, 100000000),
        "box_certificate": box, "lower_bound_certificate": bound,
        "objective_evidence": {**objective, "weighted_stage_b_objective": objective["candidate_objective"],
            "unweighted_torque_regularizer": unweighted, "saved_stage_a_task_objective": stage_a_record.get("task_objective"),
            "saved_torque_regularizer_float": certificate.get("torque_regularizer"),
            "lambda_binary64": lambda_binary, "effective_lambda_per_torque_coefficient": lambda_diagonal,
            "coefficient_ratios_equal_config_lambda": [ratio == lambda_binary for ratio in lambda_diagonal],
            "common_exact_ratio": common_ratio, "exact_objective_unit_conversion_proved": exact_conversion,
            "rigorous_unweighted_lower_bound": objective["strict_lower_bound"] / common_ratio if exact_conversion and objective["strict_lower_bound"] is not None else None,
            "diagnostic_lower_bound_divided_by_binary64_lambda": None if objective["strict_lower_bound"] is None else float(objective["strict_lower_bound"]) / float(lambda_binary),
            "diagnostic_conversion_is_not_certified": True, "frozen_objective_pattern_verified": frozen_objective_pattern},
        "validation_replay": validation, "validation_gates": gates,
        "saved_validation_comparison": historical_comparison,
        "saved_gate_comparison": historical_gate_comparison,
        "reconstructed_health": rho.tolist(),
        "numeric_validator_input_source": "Only saved original E/f/G/h/D plus frozen configuration and audited actuator-name order; no model loading, new assembly, state invention or experiment runner.",
    }
    return {
        "solve_ordinal": raw["solve_ordinal"], "case_id": raw["case_id"], "path": raw["path"], "original_status": raw["status"],
        "frozen_numeric_physical_pass": bool(physical), "frozen_literal_band_pass": bool(band),
        "frozen_status_accepted": accepted, "exact_original_qp_feasible": objective["exact_original_qp_feasible"],
        "exact_literal_band_binary64_pass": exact_binary_band, "exact_literal_band_decimal_pass": exact_decimal_band,
        "original_stationarity_absolute_maximum": stationarity["absolute_maximum"],
        "original_stationarity_maximum_index": stationarity["index"], "minimum_mu": min(mu),
        "box_proof_status": box["status"], "lower_bound_status": bound["status"],
        "lower_bound_reason": bound["reason"], "strict_lower_bound": objective["strict_lower_bound"],
        "candidate_objective": objective["candidate_objective"],
        "candidate_objective_minus_lower_bound": objective["candidate_objective_minus_lower_bound"],
        "strict_primal_upper_bound": objective["strict_primal_upper_bound"], "strict_optimality_gap": objective["strict_optimality_gap"],
        "unweighted_torque_regularizer": unweighted, "saved_stage_a_task_objective": stage_a_record.get("task_objective"),
        "validation_replay_matches_saved_gates": all(historical_gate_comparison.values()),
        "noncertification_reasons": reasons, "exact_evidence": exact_evidence,
    }
