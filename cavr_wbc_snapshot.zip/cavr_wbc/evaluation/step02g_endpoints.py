"""Exact endpoint audit of saved STEP-02F original, affine and final rows.

No optimizer, controller, model loader or experiment module is imported. Every
rational is restored from a supplied finite binary64 value; final A/b entries
are evaluated as saved, not replaced with ideal row-scale products.
"""

from __future__ import annotations

from fractions import Fraction
import re
from typing import Any, Mapping, Sequence

import numpy as np


_EQUALITY_LABEL = re.compile(r"(?:dynamics|contact_acceleration)\[(?:0|[1-9][0-9]*)\]\Z")
_INEQUALITY_LABEL = re.compile(
    r"(?:torque_(?:upper|lower)|fixed_task_(?:upper|lower))\[(?:0|[1-9][0-9]*)\]\Z"
    r"|(?:normal_(?:upper|lower))\[(?:FL|FR|RL|RR)\]\Z"
    r"|friction\[(?:FL|FR|RL|RR),[0-3]\]\Z"
)
_TASK_LABEL = re.compile(r"fixed_task_(upper|lower)\[(0|[1-9][0-9]*)\]\Z")
_BINARY64_BAND = Fraction.from_float(1.0e-8)
_DECIMAL_BAND = Fraction(1, 100000000)


def _fraction(value: Any) -> Fraction:
    number = float(value)
    if not np.isfinite(number):
        raise ValueError("Endpoint audit requires finite binary64 data")
    return Fraction.from_float(number)


def canonical_label(label: Any, *, equality: bool) -> str:
    """Remove at most one known prefix and reject any unrecognized full label."""
    if not isinstance(label, (str, np.str_)):
        raise ValueError("Constraint label must be a string")
    canonical = str(label)
    for prefix in ("p0_", "reference_"):
        if canonical.startswith(prefix):
            canonical = canonical[len(prefix):]
            break
    pattern = _EQUALITY_LABEL if equality else _INEQUALITY_LABEL
    if pattern.fullmatch(canonical) is None:
        raise ValueError(f"Unknown constraint label: {label!r}")
    return canonical


def _float_array(problem: Mapping[str, Any], key: str) -> np.ndarray:
    values = np.asarray(problem[key])
    if values.dtype != np.dtype("float64") or not np.isfinite(values).all():
        raise ValueError(f"{key} must contain saved finite binary64 values")
    return values


def _require_shape(values: np.ndarray, shape: tuple[int, ...], key: str) -> None:
    if values.shape != shape:
        raise ValueError(f"{key} shape {values.shape} differs from verified {shape}")


def _expected_labels() -> tuple[list[str], list[str]]:
    equalities = [f"dynamics[{index}]" for index in range(18)]
    equalities += [f"contact_acceleration[{index}]" for index in range(12)]
    inequalities = [f"torque_{side}[{index}]" for index in range(12)
                    for side in ("upper", "lower")]
    for foot in ("FL", "FR", "RL", "RR"):
        inequalities += [f"friction[{foot},{face}]" for face in range(4)]
        inequalities += [f"normal_lower[{foot}]", f"normal_upper[{foot}]"]
    inequalities += [f"fixed_task_{side}[{index}]" for index in range(8)
                     for side in ("upper", "lower")]
    return equalities, inequalities


def _selector(row: np.ndarray, name: str) -> int:
    nonzero = np.flatnonzero(row)
    if len(nonzero) != 1:
        raise ValueError(f"{name} must have exactly one nonzero selector coefficient")
    return int(nonzero[0])


def _band_position(endpoint: Fraction, center: Fraction, task_scale: Fraction) -> dict:
    signed = (endpoint - center) / task_scale
    distance = abs(signed)
    return {
        "signed_normalized_offset": signed,
        "normalized_distance": distance,
        "within_binary64_literal_band": distance <= _BINARY64_BAND,
        "within_decimal_rational_band": distance <= _DECIMAL_BAND,
        "signed_excess_over_binary64_band": distance - _BINARY64_BAND,
        "signed_excess_over_decimal_band": distance - _DECIMAL_BAND,
    }


def audit_endpoints(
    problem: Mapping[str, Any],
    task_scales: Sequence[float],
    *,
    strict_schema: bool = True,
) -> list[dict[str, Any]]:
    """Return exact records for all saved fixed-task upper/lower endpoints.

    The production API defaults to the verified 42-variable, 30-equality,
    64-inequality schema and eight tasks. ``strict_schema=False`` permits small
    synthetic tests only; label validity, cone row order, selector structure,
    sign, scaling and finite-value checks remain mandatory.
    """
    keys = ("original_E", "original_f", "original_G", "original_h",
            "E", "f", "G", "h", "A", "b", "a", "R",
            "equality_row_scales", "inequality_row_scales")
    data = {key: _float_array(problem, key) for key in keys}
    if data["a"].ndim != 1 or data["original_E"].ndim != 2 or data["original_G"].ndim != 2:
        raise ValueError("Saved affine vector and constraint matrices have invalid rank")
    n = len(data["a"])
    ne, ng = data["original_E"].shape[0], data["original_G"].shape[0]
    for key in ("original_E", "E"):
        _require_shape(data[key], (ne, n), key)
    for key in ("original_G", "G"):
        _require_shape(data[key], (ng, n), key)
    for key in ("original_f", "f", "equality_row_scales"):
        _require_shape(data[key], (ne,), key)
    for key in ("original_h", "h", "inequality_row_scales"):
        _require_shape(data[key], (ng,), key)
    _require_shape(data["R"], (n,), "R")
    _require_shape(data["A"], (ne + ng, n), "A")
    _require_shape(data["b"], (ne + ng,), "b")
    if np.any(data["R"] <= 0.0) or np.any(data["equality_row_scales"] <= 0.0) or np.any(data["inequality_row_scales"] <= 0.0):
        raise ValueError("Affine and row scales must be positive")

    scales = np.asarray(task_scales, dtype=np.float64)
    if scales.ndim != 1 or not len(scales) or not np.isfinite(scales).all() or np.any(scales <= 0):
        raise ValueError("Task scales must be a positive finite vector")
    raw_e = list(problem["equality_labels"])
    raw_g = list(problem["inequality_labels"])
    if len(raw_e) != ne or len(raw_g) != ng:
        raise ValueError("Constraint label dimensions disagree with saved rows")
    labels_e = [canonical_label(label, equality=True) for label in raw_e]
    labels_g = [canonical_label(label, equality=False) for label in raw_g]
    if len(set(labels_e)) != ne or len(set(labels_g)) != ng:
        raise ValueError("Duplicate canonical constraint labels")
    if strict_schema:
        if (n, ne, ng, len(scales)) != (42, 30, 64, 8):
            raise ValueError("Frozen endpoint schema must be 42 variables, 30 equalities, 64 inequalities, 8 tasks")
        expected_e, expected_g = _expected_labels()
        if labels_e != expected_e or labels_g != expected_g:
            raise ValueError("Constraint labels/order differ from the verified frozen schema")

    # This saved-data check verifies equality-cone rows precede inequality-cone
    # rows and preserves actual float64 products. It is not a rational identity
    # assertion: rounding differences in those products are audited below.
    all_scales = np.concatenate((data["equality_row_scales"], data["inequality_row_scales"]))
    with np.errstate(over="raise", invalid="raise"):
        encoded_a = all_scales[:, None] * np.vstack((data["E"], data["G"]))
        encoded_b = all_scales * np.concatenate((data["f"], data["h"]))
    if not np.array_equal(data["A"], encoded_a) or not np.array_equal(data["b"], encoded_b):
        raise ValueError("Final A/b do not match the verified saved row scaling and cone order")

    task_rows = [(index, _TASK_LABEL.fullmatch(label)) for index, label in enumerate(labels_g)]
    task_rows = [(index, match) for index, match in task_rows if match is not None]
    expected_tasks = {(side, str(index)) for index in range(len(scales)) for side in ("upper", "lower")}
    if {(match.group(1), match.group(2)) for _, match in task_rows} != expected_tasks:
        raise ValueError("Fixed-task upper/lower rows do not cover each declared task exactly")

    records = []
    task_selectors: dict[int, int] = {}
    for row, match in task_rows:
        side, task = match.group(1), int(match.group(2))
        final_row = ne + row
        original_selector = _selector(data["original_G"][row], "original fixed-task row")
        affine_selector = _selector(data["G"][row], "affine fixed-task row")
        final_selector = _selector(data["A"][final_row], "final fixed-task row")
        if original_selector != affine_selector or original_selector != final_selector:
            raise ValueError("Fixed-task selector changes between encoding layers")
        selector = original_selector
        if task in task_selectors and task_selectors[task] != selector:
            raise ValueError("Fixed-task upper/lower rows select different variables")
        task_selectors[task] = selector
        original_c = _fraction(data["original_G"][row, selector])
        affine_c = _fraction(data["G"][row, selector])
        final_c = _fraction(data["A"][final_row, selector])
        sign = 1 if side == "upper" else -1
        if any(coefficient * sign <= 0 for coefficient in (original_c, affine_c, final_c)):
            raise ValueError("Saved coefficient sign contradicts upper/lower label")
        if strict_schema and original_c != sign:
            raise ValueError("Frozen original task selector coefficient must be exactly +/-1")
        original_rhs = _fraction(data["original_h"][row])
        affine_rhs = _fraction(data["h"][row])
        final_rhs = _fraction(data["b"][final_row])
        center, radius = _fraction(data["a"][selector]), _fraction(data["R"][selector])
        row_scale = _fraction(data["inequality_row_scales"][row])
        task_scale = _fraction(scales[task])
        original_endpoint = original_rhs / original_c
        affine_z = affine_rhs / affine_c
        final_z = final_rhs / final_c
        affine_endpoint = center + radius * affine_z
        final_endpoint = center + radius * final_z
        records.append({
            "task_index": task, "side": side, "selector_index": selector,
            "inequality_row_index": row, "final_A_row_index": final_row,
            "original_label": str(raw_g[row]), "canonical_label": labels_g[row],
            "label_mapping": {"original": str(raw_g[row]), "canonical": labels_g[row]},
            "schema": {"variables": n, "equalities": ne, "inequalities": ng,
                       "strict_frozen_schema": strict_schema,
                       "cone_order_verified": "equalities_then_nonnegative_inequalities"},
            "bound_direction": "upper: coordinate <= endpoint" if original_c > 0 else "lower: coordinate >= endpoint",
            "original_selector_coefficient": original_c, "original_rhs": original_rhs,
            "pre_row_scaled_selector_coefficient": affine_c, "pre_row_scaled_rhs": affine_rhs,
            "final_encoded_selector_coefficient": final_c, "final_encoded_rhs": final_rhs,
            "inequality_row_scale": row_scale,
            "a_selector": center, "R_selector": radius, "task_scale": task_scale,
            "original_physical_endpoint": original_endpoint,
            "pre_row_scaled_z_endpoint": affine_z,
            "pre_row_scaled_physical_endpoint": affine_endpoint,
            "final_encoded_z_endpoint": final_z,
            "final_encoded_physical_endpoint": final_endpoint,
            "signed_pre_minus_original_endpoint": affine_endpoint - original_endpoint,
            "signed_final_minus_original_endpoint": final_endpoint - original_endpoint,
            "signed_final_minus_pre_endpoint": final_endpoint - affine_endpoint,
            "signed_final_coefficient_rounding_error": final_c - row_scale * affine_c,
            "signed_final_rhs_rounding_error": final_rhs - row_scale * affine_rhs,
            "binary64_literal_normalized_band": _BINARY64_BAND,
            "decimal_rational_normalized_band": _DECIMAL_BAND,
            "band_positions": {
                "original": _band_position(original_endpoint, center, task_scale),
                "pre_row_scaled": _band_position(affine_endpoint, center, task_scale),
                "final_encoded": _band_position(final_endpoint, center, task_scale),
            },
            "saved_binary64_hex": {
                "original_coefficient": float(original_c).hex(), "original_rhs": float(original_rhs).hex(),
                "pre_row_scaled_coefficient": float(affine_c).hex(), "pre_row_scaled_rhs": float(affine_rhs).hex(),
                "final_encoded_coefficient": float(final_c).hex(), "final_encoded_rhs": float(final_rhs).hex(),
                "row_scale": float(row_scale).hex(), "a": float(center).hex(),
                "R": float(radius).hex(), "task_scale": float(task_scale).hex(),
            },
        })
    if len(set(task_selectors.values())) != len(scales):
        raise ValueError("Distinct task indices must have distinct selectors")
    return records
