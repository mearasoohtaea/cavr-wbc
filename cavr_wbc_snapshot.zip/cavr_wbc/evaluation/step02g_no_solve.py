"""Fail-fast optimizer boundary for the saved-evidence-only STEP-02G audit.

Importing this module does not import an optimizer or an experiment runner.
The context imports backend *modules*, never optimizer instances, then blocks
native constructors before importing the four frozen controller wrappers.
"""

from __future__ import annotations

from contextlib import ExitStack, contextmanager
from contextvars import ContextVar
import importlib
import inspect
import sys
import threading
from unittest.mock import patch


class ZeroSolveBoundaryError(BaseException):
    """A prohibited optimizer entry was intercepted before its implementation.

    BaseException is deliberate: frozen controllers catch Exception around
    their optimizer calls and must not silently convert a boundary violation
    into a failed numerical result.
    """


_WRAPPERS = (
    ("cavr_wbc.control.clarabel_p0", "ClarabelP0Production"),
    ("cavr_wbc.control.independent_lex_reference", "IndependentLexicographicReference"),
    ("cavr_wbc.control.fixed_support_qp", "FixedSupportPhysicalQp"),
    ("cavr_wbc.control.scaled_fixed_support_qp", "ScaledFixedSupportPhysicalQp"),
)


_ACTIVE_GUARD = ContextVar("step02g_active_optimizer_guard", default=None)


@contextmanager
def optimizer_guard():
    """Share the installed guard across nested scopes on the same thread.

    Only the outermost scope installs and restores backend patches. Nested
    tests therefore reuse the audit's coverage and counters without treating
    already-blocked constructor exports as an unexpected backend schema.
    """
    active = _ACTIVE_GUARD.get()
    owner = threading.get_ident()
    if active is not None and active[0] == owner:
        log = active[1]
        log["nested_guard_entries"] += 1
        log["active_scope_count"] += 1
        log["maximum_active_scope_count"] = max(
            log["maximum_active_scope_count"], log["active_scope_count"]
        )
        try:
            yield log
        finally:
            log["active_scope_count"] -= 1
        return
    with _installed_optimizer_guard() as log:
        log["nested_guard_entries"] = 0
        log["active_scope_count"] = 1
        log["maximum_active_scope_count"] = 1
        token = _ACTIVE_GUARD.set((owner, log))
        try:
            yield log
        finally:
            log["active_scope_count"] -= 1
            _ACTIVE_GUARD.reset(token)


@contextmanager
def _installed_optimizer_guard():
    """Yield auditable coverage while prohibiting constructions and solves.

    Counters describe actual backend dispatches, not intentionally blocked
    test probes. Every intercepted probe is separately recorded; a production
    audit must reject any nonempty ``blocked_attempts`` list. There is no
    optimizer construction, solve, setup, or warm start in guard installation.

    Native class descriptors protect references imported before this context.
    Export replacements additionally protect imports performed afterward. A
    profiling hook detects cached native bound solve methods and cached Python
    wrapper methods. Static alias inspection documents additional loaded-module
    references, including version-dependent ``_OSQP`` aliases when present.
    """
    log = {
        "actual_constructions": 0,
        "actual_solve_calls": 0,
        "blocked_attempts": [],
        "patched_entrypoints": [],
        "patch_failures": [],
        "observed_backend_classes": [],
        "observed_optional_aliases": [],
        "static_cached_class_aliases": [],
        "wrapper_routes": [],
        "guard_installed": False,
        "guard_restored": False,
        "experiment_runners_imported_by_guard": [],
        "counter_interpretation": (
            "All observed optimizer entrypoints are intercepted before their "
            "implementation. Blocked probes are not actual backend calls. "
            "Production audit requires blocked_attempts to be empty."
        ),
        "fallback_scope": (
            "If a native descriptor is immutable, exported aliases and loaded "
            "module aliases are replaced and all frozen wrapper routes remain "
            "blocked. Cached native bound solve methods are profiled. This is "
            "coverage of the inspected installed backends and frozen wrappers, "
            "not a sandbox against arbitrary dynamically loaded native code."
        ),
    }
    original_types = []
    blocked_python_codes = {}

    def reject(entrypoint, kind):
        log["blocked_attempts"].append({
            "entrypoint": entrypoint,
            "kind": kind,
            "intercepted_before_backend_dispatch": True,
        })
        raise ZeroSolveBoundaryError(
            f"STEP02G zero-optimizer boundary: {kind} at {entrypoint}"
        )

    def blocker(entrypoint, kind):
        def forbidden(*args, **kwargs):
            reject(entrypoint, kind)
        return forbidden

    with ExitStack() as stack:
        def install(owner, name, replacement, label):
            try:
                stack.enter_context(patch.object(owner, name, replacement))
            except (AttributeError, TypeError) as exc:
                log["patch_failures"].append({
                    "entrypoint": label,
                    "reason": f"{type(exc).__name__}: {exc}",
                    "fallback": "export/static-alias replacement plus frozen-wrapper and profile guards",
                })
                return False
            log["patched_entrypoints"].append(label)
            return True

        # Import definitions only. No class below is instantiated.
        clarabel = importlib.import_module("clarabel")
        native_clarabel = importlib.import_module("clarabel.clarabel")
        osqp = importlib.import_module("osqp")
        osqp_interface = importlib.import_module("osqp.interface")
        osqp_native = importlib.import_module("osqp.ext_builtin")
        modules = (clarabel, native_clarabel, osqp, osqp_interface, osqp_native)
        required = (
            (clarabel, "DefaultSolver"),
            (native_clarabel, "DefaultSolver"),
            (osqp, "OSQP"),
            (osqp_interface, "OSQP"),
            (osqp_native, "OSQPSolver"),
        )
        exports = []
        for module, attribute in required:
            cls = getattr(module, attribute)
            if not inspect.isclass(cls):
                raise ZeroSolveBoundaryError(
                    f"Unexpected optimizer schema: {module.__name__}.{attribute} is not a class"
                )
            exports.append((module, attribute, cls))
        for module in modules:
            present = hasattr(module, "_OSQP")
            log["observed_optional_aliases"].append({
                "entrypoint": f"{module.__name__}._OSQP", "present": present,
            })
            if present:
                cls = getattr(module, "_OSQP")
                if not inspect.isclass(cls):
                    raise ZeroSolveBoundaryError(
                        f"Unsupported optional optimizer alias: {module.__name__}._OSQP"
                    )
                exports.append((module, "_OSQP", cls))

        for _, _, cls in exports:
            if not any(cls is known for known in original_types):
                original_types.append(cls)
        for cls in original_types:
            label = f"{cls.__module__}.{cls.__name__}"
            record = {"class": label, "native_constructor_descriptor_blocked": False}
            log["observed_backend_classes"].append(record)
            record["native_constructor_descriptor_blocked"] = install(
                cls, "__new__", staticmethod(blocker(label + ".__new__", "construction")),
                label + ".__new__",
            )
            for name in ("__init__", "setup", "solve"):
                if not hasattr(cls, name):
                    continue
                original = getattr(cls, name)
                if hasattr(original, "__code__"):
                    blocked_python_codes[original.__code__] = label + "." + name
                kind = "construction" if name == "__init__" else "setup" if name == "setup" else "solve"
                install(cls, name, blocker(label + "." + name, kind), label + "." + name)

        # Inspect and replace already-imported module-level class aliases too.
        # Identity comparisons avoid invoking equality on arbitrary module data.
        cached = []
        for module_name, module in tuple(sys.modules.items()):
            namespace = getattr(module, "__dict__", None)
            if not isinstance(namespace, dict):
                continue
            for name, value in tuple(namespace.items()):
                if any(value is cls for cls in original_types):
                    cached.append((module_name, module, name, value))
        for module_name, module, name, cls in cached:
            label = f"{module_name}.{name}"
            log["static_cached_class_aliases"].append({
                "entrypoint": label, "class": f"{cls.__module__}.{cls.__name__}",
            })
            if not install(module, name, blocker(label, "construction"), label):
                # The actual installed classes are mutable; this branch records
                # a version-specific limitation rather than silently claiming it.
                native_covered = next(
                    row["native_constructor_descriptor_blocked"]
                    for row in log["observed_backend_classes"]
                    if row["class"] == f"{cls.__module__}.{cls.__name__}"
                )
                if not native_covered:
                    raise ZeroSolveBoundaryError(f"Uncovered optimizer class alias: {label}")
        for module, name, _ in exports:
            if inspect.isclass(getattr(module, name)):
                raise ZeroSolveBoundaryError(f"Optimizer export was not blocked: {module.__name__}.{name}")

        # These modules contain the original validators and controller classes;
        # importing them performs no optimization. No experiment runner imports.
        for module_name, class_name in _WRAPPERS:
            cls = getattr(importlib.import_module(module_name), class_name)
            methods = [name for name in vars(cls) if name == "_solve" or name.startswith("solve_")]
            if "_solve" not in methods:
                raise ZeroSolveBoundaryError(f"Unexpected frozen wrapper schema: {module_name}.{class_name}")
            for name in methods:
                label = f"{module_name}.{class_name}.{name}"
                original = getattr(cls, name)
                if hasattr(original, "__code__"):
                    blocked_python_codes[original.__code__] = label
                if not install(cls, name, blocker(label, "wrapper_solve"), label):
                    raise ZeroSolveBoundaryError(f"Uncovered frozen wrapper route: {label}")
                log["wrapper_routes"].append(label)

        native_types = tuple(original_types)
        old_profile = sys.getprofile()
        old_thread_profile = threading.getprofile()

        def profile(frame, event, arg):
            if event == "call":
                route = blocked_python_codes.get(frame.f_code)
                if route is not None:
                    reject(route, "cached_python_optimizer_route")
            elif event == "c_call":
                name = getattr(arg, "__name__", "")
                if name in ("solve", "setup", "__new__", "__init__"):
                    owner = getattr(arg, "__self__", None)
                    declaring = getattr(arg, "__objclass__", None)
                    if (isinstance(owner, native_types)
                            or any(owner is cls or declaring is cls for cls in native_types)):
                        reject(f"{getattr(arg, '__module__', 'native')}.{name}", "cached_native_optimizer_route")
            if old_profile is not None:
                old_profile(frame, event, arg)

        sys.setprofile(profile)
        threading.setprofile(profile)
        log["profile_guards"] = ["cached native optimizer C-call", "cached frozen Python optimizer route"]
        log["guard_installed"] = True
        try:
            yield log
        finally:
            sys.setprofile(old_profile)
            threading.setprofile(old_thread_profile)
            log["guard_restored"] = True
