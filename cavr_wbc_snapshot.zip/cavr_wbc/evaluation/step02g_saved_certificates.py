"""Input integrity and lossless evidence serialization; no experimental assembly."""
from __future__ import annotations

import hashlib
import json
import math
from fractions import Fraction
from pathlib import Path, PureWindowsPath
import numpy as np


class InputIntegrityError(ValueError):
    pass


def checked_path(root, relative):
    root = Path(root).resolve()
    relative = str(relative)
    if Path(relative).is_absolute() or PureWindowsPath(relative).is_absolute() or ".." in relative.replace("\\", "/").split("/"):
        raise InputIntegrityError(f"Unsafe relative input path: {relative}")
    result = (root / relative).resolve()
    if not result.is_relative_to(root) or result == root:
        raise InputIntegrityError(f"Input path escapes root: {relative}")
    return result


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def verify_hash(path, expected):
    if not Path(path).is_file():
        raise InputIntegrityError(f"Missing input: {path}")
    actual = sha256(path)
    if actual != expected:
        raise InputIntegrityError(f"SHA256 mismatch: {path}: {actual} != {expected}")


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def read_jsonl(path):
    return [json.loads(line) for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]


def join_records(raw, certificates, calls, attempts, expected_count=20):
    collections = []
    keys = ("solve_ordinal", "phase", "case_id", "path")
    for name, records in zip(("raw", "certificate", "call", "attempt"), (raw, certificates, calls, attempts)):
        if len(records) != expected_count:
            raise InputIntegrityError(f"{name}: expected {expected_count} records, got {len(records)}")
        indexed = {}
        for record in records:
            if not all(key in record for key in keys):
                raise InputIntegrityError(f"{name}: missing join keys")
            ordinal = record["solve_ordinal"]
            if type(ordinal) is not int or ordinal in indexed:
                raise InputIntegrityError(f"{name}: invalid/duplicate ordinal {ordinal}")
            indexed[ordinal] = record
        if set(indexed) != set(range(1, expected_count + 1)):
            raise InputIntegrityError(f"{name}: non-sequential ordinal coverage")
        collections.append(indexed)
    joined = []
    seen = set()
    for ordinal in range(1, expected_count + 1):
        records = tuple(index[ordinal] for index in collections)
        identity = tuple(records[0][key] for key in keys)
        if any(tuple(record[key] for key in keys) != identity for record in records):
            raise InputIntegrityError(f"Cross-file join mismatch at ordinal {ordinal}")
        research_key = identity[1:]
        if research_key in seen:
            raise InputIntegrityError(f"Duplicate phase/case/path {research_key}")
        seen.add(research_key)
        joined.append(records)
    return joined


def serialize_exact(value):
    """Preserve exact rationals plus direction-checked binary64 display bounds."""
    if isinstance(value, Fraction):
        nearest = float(value)
        if not math.isfinite(nearest):
            raise InputIntegrityError("Exact evidence exceeds finite binary64 display range")
        lower = nearest if Fraction.from_float(nearest) <= value else float(np.nextafter(nearest, -np.inf))
        upper = nearest if Fraction.from_float(nearest) >= value else float(np.nextafter(nearest, np.inf))
        if not math.isfinite(lower) or not math.isfinite(upper) or not Fraction.from_float(lower) <= value <= Fraction.from_float(upper):
            raise InputIntegrityError("Outward rounding check failed")
        return {"numerator": str(value.numerator), "denominator": str(value.denominator),
                "approximate_float": nearest, "lower_float": lower, "upper_float": upper,
                "float_bounds_direction_checked": True}
    if isinstance(value, np.ndarray):
        return serialize_exact(value.tolist())
    if isinstance(value, np.generic):
        return serialize_exact(value.item())
    if isinstance(value, dict):
        return {str(key): serialize_exact(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [serialize_exact(item) for item in value]
    if isinstance(value, float) and not math.isfinite(value):
        raise InputIntegrityError("Nonfinite JSON evidence")
    return value


def decode_exact(value):
    if isinstance(value, dict):
        if "numerator" in value and "denominator" in value:
            return Fraction(int(value["numerator"]), int(value["denominator"]))
        return {key: decode_exact(item) for key, item in value.items()}
    if isinstance(value, list):
        return [decode_exact(item) for item in value]
    return value


def write_json(path, value):
    Path(path).write_text(json.dumps(serialize_exact(value), ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8", newline="\n")


def append_jsonl(path, value):
    with Path(path).open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(serialize_exact(value), ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n")


def load_problem(path):
    with np.load(path, allow_pickle=False) as archive:
        problem = {key: archive[key].copy() for key in archive.files}
    expected = {"original_P": (42, 42), "original_q": (42,), "original_E": (30, 42),
                "original_f": (30,), "original_G": (64, 42), "original_h": (64,),
                "P": (42, 42), "q": (42,), "E": (30, 42), "f": (30,),
                "G": (64, 42), "h": (64,), "A": (94, 42), "b": (94,),
                "D": (42,), "a": (42,), "R": (42,), "equality_row_scales": (30,),
                "inequality_row_scales": (64,), "objective_constant": ()}
    for name, shape in expected.items():
        if name not in problem or problem[name].shape != shape or problem[name].dtype != np.float64 or not np.isfinite(problem[name]).all():
            raise InputIntegrityError(f"Invalid finite binary64 schema: {path}: {name}")
    for name, shape in (("equality_labels", (30,)), ("inequality_labels", (64,))):
        if name not in problem or problem[name].shape != shape or problem[name].dtype.kind != "U":
            raise InputIntegrityError(f"Invalid label schema: {path}: {name}")
    return problem
