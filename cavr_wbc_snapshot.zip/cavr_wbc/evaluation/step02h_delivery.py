"""Reporting-only STEP-02H delivery from persisted evidence and call receipts.

This module never imports or invokes the LP/recovery/verifier implementations.
Ledger access validates existing records; it reserves or starts no new attempt.
"""

from __future__ import annotations

from collections import Counter
import csv
from decimal import Context, Decimal, ROUND_CEILING, ROUND_FLOOR
from fractions import Fraction
import json
from pathlib import Path

from cavr_wbc.evaluation.step02h_inputs import (
    BASE, CONFIG_SHA, GF, OUT, ROOT, VERSION, compact, git, rational_decode,
    read_json, sha256, utc, verify_sources, write_compact,
)
from cavr_wbc.evaluation.step02h_runtime import Ledger


def _read(path, default=None):
    return rational_decode(read_json(path)) if Path(path).exists() else default


def _lines(path):
    if not Path(path).exists():
        return []
    with Path(path).open("r", encoding="utf-8") as stream:
        return [rational_decode(json.loads(line)) for line in stream if line.strip()]


def _save(name, value):
    write_compact(OUT / name, value)


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def _indexed(rows, name):
    indexed = {}
    for row in rows:
        ordinal = row["solve_ordinal"]
        _require(type(ordinal) is int and 1 <= ordinal <= 20 and ordinal not in indexed,
                 f"Duplicate/out-of-range ordinal in {name}")
        indexed[ordinal] = row
    return indexed


def _decimal_bounds(value, precision=18):
    """Directed decimal rounding checked against the exact rational value."""
    if value is None:
        return None
    _require(isinstance(value, Fraction), "Exact reporting quantity must be Fraction")
    lower = Context(prec=precision, rounding=ROUND_FLOOR).divide(Decimal(value.numerator), Decimal(value.denominator))
    upper = Context(prec=precision, rounding=ROUND_CEILING).divide(Decimal(value.numerator), Decimal(value.denominator))
    _require(Fraction(lower) <= value <= Fraction(upper), "Outward decimal display verification failed")
    return {"lower_decimal": str(lower), "upper_decimal": str(upper),
            "significant_digits": precision, "outward_directions_checked": True}


def _display(value):
    if value is None:
        return "null"
    interval = _decimal_bounds(value)
    if interval["lower_decimal"] == interval["upper_decimal"]:
        return interval["lower_decimal"]
    return f"[{interval['lower_decimal']}, {interval['upper_decimal']}]"


def _call_counts(snapshot, events):
    """Do not equate a dispatch intent or an occupied reservation with receipt."""
    categories = {}
    attempts = []
    for category in ("saved_record", "synthetic_fixture"):
        reservations = [event for event in events if event["event"] == "RESERVED" and event["token"]["category"] == category]
        confirmed, unknown_dispatches, pending_before_dispatch = 0, 0, 0
        for reservation in reservations:
            token = reservation["token"]
            related = [event for event in events if event["token"]["reservation_id"] == token["reservation_id"]]
            started = any(event["event"] == "LINPROG_STARTED" for event in related)
            terminals = [event for event in related if event["event"] == "FINISHED"]
            terminal = terminals[0] if terminals else None
            metadata = terminal["metadata"] if terminal else {}
            receipt = metadata.get("receipt")
            entries = receipt.get("top_level_entries") if receipt is not None else None
            _require(entries in (None, 0, 1), "Receipt shows unsupported repeated top-level LP entry")
            if receipt is not None:
                _require(receipt["reservation_id"] == token["reservation_id"] and receipt["category"] == category
                         and receipt["identity"] == token["identity"] and receipt["input_hash"] == token["input_hash"],
                         "Terminal receipt does not match immutable reservation")
            actual_unknown = started and receipt is None
            confirmed += int(entries == 1)
            unknown_dispatches += int(actual_unknown)
            pending_before_dispatch += int(not started and terminal is None)
            attempts.append({"token": token, "dispatch_intent_recorded": started,
                             "terminal_status": metadata.get("status", "ATTEMPT_OUTCOME_UNKNOWN"),
                             "confirmed_top_level_entries": entries,
                             "actual_backend_entry_unknown": actual_unknown,
                             "outcome_unknown": terminal is None or metadata.get("status") == "ATTEMPT_OUTCOME_UNKNOWN" or actual_unknown,
                             "receipt": receipt, "reservation_consumed": True, "retry_allowed": False})
        reserved = len(reservations)
        dispatches = sum(attempt["dispatch_intent_recorded"] for attempt in attempts if attempt["token"]["category"] == category)
        category_snapshot = snapshot["categories"][category]
        _require(reserved == category_snapshot["reserved"] and dispatches == category_snapshot["linprog_started"],
                 "Ledger snapshot and event aggregation disagree")
        categories[category] = {
            "budget": category_snapshot["limit"], "reservations_consumed": reserved,
            "durable_dispatch_intents": dispatches, "confirmed_backend_entries": confirmed,
            "dispatches_without_terminal_receipt": unknown_dispatches,
            "pending_reservations_before_dispatch": pending_before_dispatch,
            "actual_call_count": confirmed if unknown_dispatches == 0 else None,
            "actual_call_count_lower_bound": confirmed, "actual_call_count_upper_bound": confirmed + unknown_dispatches,
        }
    lower = sum(value["actual_call_count_lower_bound"] for value in categories.values())
    upper = sum(value["actual_call_count_upper_bound"] for value in categories.values())
    return {"categories": categories, "attempts": attempts,
            "total_confirmed_backend_entries": lower,
            "total_actual_call_count": lower if lower == upper else None,
            "total_actual_call_count_lower_bound": lower, "total_actual_call_count_upper_bound": upper,
            "total_reservations_consumed": snapshot["total_reserved"],
            "total_durable_dispatch_intents": snapshot["total_linprog_started"],
            "ledger_sha256": snapshot["ledger_sha256"], "ledger_hash_chain_validated": True,
            "interpretation": "Reservation consumes budget; LINPROG_STARTED is durable dispatch intent. A terminal receipt with one top-level entry confirms an LP call. Interrupted entry without such a receipt stays unknown and is never retried."}


def _tests(counts):
    latest = _read(OUT / "pure_tests_latest.json", {})
    synthetic = _read(OUT / "synthetic_tests.json", {"results": [], "complete": False, "passed": False})
    history = []
    for path in sorted((OUT / "test_history").glob("pure_*.json")) if (OUT / "test_history").exists() else []:
        record = _read(path)
        history.append({"file": str(path.relative_to(ROOT)).replace("\\", "/"), "sha256": sha256(path),
                        "utc": record.get("utc"), "tests_run": record.get("tests_run"),
                        "passed": record.get("passed"), "failures": record.get("failures"), "errors": record.get("errors")})
    report = {"pure_algebra_tests": latest, "pure_test_history": history,
              "synthetic_fixture_tests": synthetic,
              "synthetic_fixture_call_accounting": counts["categories"]["synthetic_fixture"],
              "synthetic_calls_included_in_total_optimization_calls": True,
              "saved_verification_replay": _read(OUT / "verification_replay.json", {"status": "NOT RUN"})}
    _save("tests.json", report)
    text = ["STEP02H tests and call accounting", "", json.dumps(compact(report), ensure_ascii=False, indent=2), ""]
    if latest.get("test_log"):
        path = ROOT / latest["test_log"]
        _require(sha256(path) == latest["test_log_sha256"], "Pure test log hash changed")
        text.extend(["Latest pure test execution log:", path.read_text(encoding="utf-8")])
    (OUT / "tests.txt").write_text("\n".join(text), encoding="utf-8", newline="\n")
    return report


def _guard_receipts():
    records, construction_count, original_calls, blocked = [], 0, 0, []
    for path in sorted((OUT / "auxiliary_lp_inputs").glob("*/worker_result.json")):
        worker = _read(path)
        guard = worker.get("guard")
        if guard is None:
            records.append({"file": str(path.relative_to(ROOT)), "guard_record_available": False,
                            "worker_status": worker.get("status"), "sha256": sha256(path)})
            continue
        original = guard.get("original_guard", {})
        construction_count += int(guard.get("actual_original_optimizer_constructions", 0))
        original_calls += int(guard.get("actual_original_stage_a_b_calls", 0))
        blocked.extend(guard.get("blocked_attempts", []))
        blocked.extend(original.get("blocked_attempts", []))
        records.append({"file": str(path.relative_to(ROOT)), "sha256": sha256(path), "guard_record_available": True,
                        "worker_status": worker.get("status"), "guard_installed": guard.get("guard_installed"),
                        "guard_restored": guard.get("guard_restored"), "allowed_calls": guard.get("allowed_calls", []),
                        "original_guard_installed": original.get("guard_installed"),
                        "original_entrypoint_coverage": original.get("patched_entrypoints", []),
                        "h_entrypoint_coverage": guard.get("patched_entrypoints", [])})
    worker_requests = list((OUT / "auxiliary_lp_inputs").glob("*/worker_request.json"))
    result_directories = {Path(record["file"]).parent for record in records}
    missing_results = [str(path.parent.relative_to(ROOT)) for path in worker_requests
                       if path.parent.relative_to(ROOT) not in result_directories]
    return {"worker_guard_records": records, "worker_requests_without_result_receipt": missing_results,
            "guard_receipts_complete_for_requested_workers": not missing_results and all(record["guard_record_available"] for record in records),
            "original_optimizer_constructions": construction_count,
            "original_stage_a_b_solve_calls": original_calls, "blocked_prohibited_worker_attempts": blocked,
            "scope": "Original-call counters aggregate persisted worker guard receipts; absent worker receipts are explicitly listed, not inferred to be receipts with zero calls. Intentional negative guard probes in pure tests are separate from scientific optimizer calls; no universal native-code sandbox claim."}


def deliver():
    """Write fixed-20-row delivery after recovery ends; performs zero LP calls."""
    if (OUT / "RUN_STARTED.json").exists() and not (OUT / "RUN_FINISHED.json").exists():
        raise ValueError("Run has not finished; do not deliver while a worker may still be active")
    integrity_before = verify_sources()
    manifest = _read(OUT / "IMPLEMENTATION_MANIFEST.json", {})
    for name, digest in manifest.get("files", {}).items():
        _require(sha256(ROOT / name) == digest, "Implementation changed after freeze: " + name)
    ledger = Ledger(OUT / "recovery_call_ledger.jsonl")
    snapshot, events = ledger.snapshot(), ledger.events()
    counts = _call_counts(snapshot, events)
    guards = _guard_receipts()
    call_audit = {**counts, **guards, "reporting_generated_utc": utc(),
                  "reporting_lp_calls": 0, "source_ledger": "recovery_call_ledger.jsonl"}
    _save("optimizer_call_audit.json", call_audit)

    g_rows = _indexed(_lines(GF / "candidate_audit.jsonl"), "G candidate summary")
    _require(set(g_rows) == set(range(1, 21)), "G reference coverage must be exactly 20 ordinals")
    outcomes = _indexed(_lines(OUT / "record_outcomes.jsonl"), "H record outcomes")
    verifications = _indexed(_lines(OUT / "independent_verification.jsonl"), "H independent verifications")
    exports = _indexed(_lines(OUT / "binary64_export_checks.jsonl"), "H binary64 exports")
    attempts = {item["token"]["identity"]: item for item in counts["attempts"] if item["token"]["category"] == "saved_record"}
    rows = []
    for ordinal in range(1, 21):
        g, outcome = g_rows[ordinal], outcomes.get(ordinal)
        _require(g["strict_primal_upper_bound"] is None and g["strict_optimality_gap"] is None,
                 "G original null upper bound/gap history changed")
        if outcome is not None:
            _require(outcome["case_id"] == g["case_id"] and outcome["path"] == g["path"], "H/G delivery join mismatch")
        verification, export, attempt = verifications.get(ordinal), exports.get(ordinal), attempts.get(ordinal)
        status = outcome["recovery_status"] if outcome else "ATTEMPT_OUTCOME_UNKNOWN" if attempt else "NOT RUN"
        certified = bool(verification and verification.get("certified") and verification.get("status") == "CERTIFIED_PRIMAL_WITNESS")
        if certified:
            U, gap = verification["U"], verification["certified_gap_bound"]
            _require(isinstance(U, Fraction) and isinstance(gap, Fraction) and U >= g["strict_lower_bound"]
                     and gap == U - g["strict_lower_bound"], "Saved interval is inconsistent with original G L")
            _require(status == "CERTIFIED_PRIMAL_WITNESS", "Verified certificate status differs from recorded outcome")
        else:
            U = gap = None
            _require(not verification or verification.get("U") is None, "Uncertified verification claims a new upper bound")
        row = {
            "solve_ordinal": ordinal, "case_id": g["case_id"], "path": g["path"], "original_f_status": g["original_status"],
            "original_g_L": g["strict_lower_bound"], "original_g_primal_upper_bound": g["strict_primal_upper_bound"],
            "original_g_optimality_gap": g["strict_optimality_gap"],
            "original_saved_candidate_objective": g["candidate_objective"],
            "original_saved_candidate_objective_minus_L_diagnostic": g["candidate_objective_minus_lower_bound"],
            "recovery_status": status, "rational_witness_certified": certified,
            "exact_original_qp_feasible": bool(verification and verification.get("exact_equalities_pass") and verification.get("exact_original_inequalities_pass")),
            "literal_binary64_pass": verification.get("literal_binary64_band_pass") if verification else None,
            "decimal_band_report_only_pass": verification.get("decimal_band_report_only_pass") if verification else None,
            "returned_t": verification.get("returned_t") if verification else None,
            "verified_scaled_linf_distance": verification.get("verified_scaled_linf_distance") if verification else None,
            "distance_optimality_proved": False, "U": U, "certified_gap_bound": gap,
            "certified_interval": [g["strict_lower_bound"], U] if certified else None,
            "binary64_export_status": export.get("status") if export else "NOT RUN",
            "binary64_numeric_physical_pass": export.get("numeric_physical_pass") if export else None,
            "binary64_numeric_band_pass": export.get("numeric_band_pass") if export else None,
            "binary64_exact_literal_pass": export.get("literal_binary64_band_pass") if export else None,
            "reasons": (verification.get("failures", []) if verification else []) +
                       ([outcome["reason"]] if outcome and outcome.get("reason") else []),
            "elapsed_seconds": outcome.get("elapsed_seconds") if outcome else None,
            "call_accounting": attempt,
            "objective_units": "actual weighted original Stage-B QP; no division by lambda_tau",
            "outward_decimal_display": {"L": _decimal_bounds(g["strict_lower_bound"]), "U": _decimal_bounds(U),
                                         "gap": _decimal_bounds(gap),
                                         "distance": _decimal_bounds(verification.get("verified_scaled_linf_distance")) if verification else None},
        }
        if not certified and not row["reasons"]:
            row["reasons"] = [status + ": no independently certified rational witness was delivered"]
        rows.append(row)
    with (OUT / "primal_dual_intervals.jsonl").open("w", encoding="utf-8", newline="\n") as stream:
        for row in rows:
            stream.write(json.dumps(compact(row), ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n")
    csv_fields = [key for key in rows[0] if key not in ("call_accounting", "outward_decimal_display", "certified_interval")]
    with (OUT / "recovery_summary.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=csv_fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: str(row[key]) if isinstance(row[key], Fraction) else
                             json.dumps(row[key], ensure_ascii=False) if isinstance(row[key], list) else row[key]
                             for key in csv_fields})
    tests = _tests(counts)
    replay = tests["saved_verification_replay"]
    verified_rows = [row for row in rows if row["rational_witness_certified"]]
    divergence = [row["solve_ordinal"] for row in verified_rows if row["binary64_export_status"] == "BINARY64_EXPORT_NOT_ACCEPTABLE"]
    run_finished = _read(OUT / "RUN_FINISHED.json", {})
    critical = any(row["recovery_status"] in ("CERTIFICATE_INCONSISTENCY", "RETURNED_WITNESS_INVALID", "ERROR") for row in rows)
    report_status = "COMPLETED_WITH_CERTIFICATES" if verified_rows and not critical else "STOPPED_FOR_AUDIT" if critical else "COMPLETED_WITHOUT_CERTIFICATE"
    if not (OUT / "RUN_STARTED.json").exists():
        report_status = "PREPARATION_INCOMPLETE"
    result = {
        "stage": "STEP02H", "status": report_status, "verification_level": "ANALYZED", "algorithm_version": VERSION,
        "generated_utc": utc(), "source_G_commit": BASE, "source_F_commit": "0aa98d533de944b0644f13f4ef84c331f9decce1",
        "config_sha256": CONFIG_SHA, "worktree": str(ROOT), "branch": git(ROOT, "branch", "--show-current"),
        "fixed_saved_record_scope": 20, "fixed_record_rows_delivered": len(rows),
        "recovery_status_counts": dict(Counter(row["recovery_status"] for row in rows)),
        "new_certificate_witnesses": len(verified_rows), "rational_float_export_divergence_ordinals": divergence,
        "binary64_export_status_counts": dict(Counter(row["binary64_export_status"] for row in rows)),
        "call_accounting": counts, "original_optimizer_constructions": guards["original_optimizer_constructions"],
        "original_stage_a_b_solve_calls": guards["original_stage_a_b_solve_calls"],
        "tests": {"pure_tests": tests["pure_algebra_tests"].get("tests_run", 0),
                  "pure_passed": tests["pure_algebra_tests"].get("passed", False),
                  "synthetic_fixture_results": tests["synthetic_fixture_tests"],
                  "verification_replay_records": len(replay.get("records", [])), "replay_optimization_calls": replay.get("optimization_calls")},
        "run_stop_reason": run_finished.get("stop_reason"), "real_batch_elapsed_seconds": run_finished.get("elapsed_seconds"),
        "original_G_upper_bounds_and_gaps_unchanged_null": True,
        "step02f_result_unchanged": "FAIL / REVISE", "step02g_result_unchanged": "AUDIT_COMPLETED",
        "remaining_step02f_regressions": "NOT RUN", "step02f_full_panel": "NOT RUN",
        "post_hoc_known_data_diagnostic": True, "distance_optimality_independently_proved": False,
        "objective_unit_division_performed": False, "new_absolute_gap_acceptance_threshold": None,
        "further_solve_authorized": False, "e1_authorized": False,
        "source_integrity": integrity_before, "reporting_new_optimization_calls": 0,
        "implementation_manifest_sha256": sha256(OUT / "IMPLEMENTATION_MANIFEST.json") if manifest else None,
    }
    _save("STEP02H_RESULT.json", result)
    _write_report(result, rows, tests, guards)
    integrity_after = verify_sources()
    _require(ledger.snapshot() == snapshot, "Delivery changed recovery ledger")
    return {"status": report_status, "fixed_rows": 20, "new_certificate_witnesses": len(verified_rows),
            "call_accounting": counts, "reporting_optimization_calls": 0, "source_integrity_after": integrity_after}


def _count_text(category):
    value = category["actual_call_count"]
    return str(value) if value is not None else f"UNKNOWN [{category['actual_call_count_lower_bound']},{category['actual_call_count_upper_bound']}]"


def _write_report(result, rows, tests, guards):
    counts = result["call_accounting"]
    saved, synthetic = counts["categories"]["saved_record"], counts["categories"]["synthetic_fixture"]
    total = str(counts["total_actual_call_count"]) if counts["total_actual_call_count"] is not None else f"UNKNOWN [{counts['total_actual_call_count_lower_bound']},{counts['total_actual_call_count_upper_bound']}]"
    certified = result["new_certificate_witnesses"]
    text = [
        "# STEP-02H 精确可行见证恢复", "",
        "验证等级：ANALYZED。已见 F/G 数据之后的限定证书构造与独立复核；不是新的独立验证集，也没有重跑原研究实验。", "",
        f"交付状态：{result['status']}。固定20条记录完整列出；经独立 Fraction 验证的新证书见证 {certified}/20。",
        f"真实记录辅助 LP 已确认调用：{_count_text(saved)}/20；合成 fixture 调用：{_count_text(synthetic)}/16；总新增优化调用：{total}。",
        "F 保持 FAIL / REVISE，G 保持 AUDIT_COMPLETED。G 原保存候选及其严格上界/gap 的 null 值保持原样；H 的新见证另存。", "",
        "## 固定范围与结果", "",
        "下表 L、U、U−L 均为实际加权原 Stage-B 目标单位；没有除以 lambda_tau。距离为原物理尺度 D 下的 L∞。数值显示为独立核对方向的十进制外包区间；完整有理数保存在 primal_dual_intervals.jsonl。",
        "",
        "|序号|路径|原状态|H 恢复状态|L|U|U−L|恢复距离|浮点导出|",
        "|---|---|---|---|---|---|---|---|---|",
    ]
    for row in rows:
        text.append(f"|{row['solve_ordinal']}|{row['path']}|{row['original_f_status']}|{row['recovery_status']}|{_display(row['original_g_L'])}|{_display(row['U'])}|{_display(row['certified_gap_bound'])}|{_display(row['verified_scaled_linf_distance'])}|{row['binary64_export_status']}|")
    text += ["", "完整 case_id、原保存点 f(w_saved)−L、t、精确各门、未运行/失败原因及调用凭证见 recovery_summary.csv、primal_dual_intervals.jsonl 和独立验证记录。NOT RUN 记录仍保留其原 G 下界。",
             "", "## 证书含义和方法边界", "",
             "独立验证器重新核验各路径 G 的原输入、84个盒面证明、非负不等式组合权重、保存对偶仅乘行尺度一次、对角PSD目标及固定乘子盒上闭式下界代数。恢复器的有理数等式消元、LP可行判断不作为验证器的证据来源。",
             "H 只使用固定的 SymPy 1.14.0 linprog 辅助问题：完整原等式/不等式、G证明盒、binary64 literal task band、42维D尺度距离双侧约束及t>=0。十进制1/100000000 band仅报告，不作为额外inward约束。没有二级原torque优化、半径重试或backend切换。",
             "新见证只有在全部独立精确约束通过后才得到U；若U<L立即作为CERTIFICATE_INCONSISTENCY停止，不能取绝对值或截断。有效区间说明0<=f(w_certificate)−f*<=U−L；不意味着找到精确QP最优解。后端t和可核验距离不构成独立最近点证明。",
             f"本轮有理证书与binary64导出不一致的ordinal：{result['rational_float_export_divergence_ordinals']}。有理见证至多直接舍入一次；导出点单独复核旧数值物理门及literal band。导出失败不否定已成立的有理上界，导出通过也不制造Clarabel Solved或追认F的AlmostSolved。",
             "没有获得证书的记录只说明该固定方法/资源预算没有交付经验证的新点。后端infeasible标签没有独立Farkas证明，不能推出原QP不可行；辅助literal交集也不能替代原QP。",
             "", "## 调用账本、资源与测试", "",
             f"持久化预留：真实 {saved['reservations_consumed']}，合成 {synthetic['reservations_consumed']}；durable dispatch intent：真实 {saved['durable_dispatch_intents']}，合成 {synthetic['durable_dispatch_intents']}。",
             f"终止回执确认的顶层入口：真实 {saved['confirmed_backend_entries']}，合成 {synthetic['confirmed_backend_entries']}；有dispatch但缺终止回执、实际入口/结局未确认：真实 {saved['dispatches_without_terminal_receipt']}，合成 {synthetic['dispatches_without_terminal_receipt']}。",
             "预留永久占用额度。未知结局不重试，不能把预留或dispatch intent直接写成已确认实际调用。精确线性代数、独立验证与报告聚合分别计数，不算LP。所有合成LP也计入本轮总优化调用。",
             f"纯代数测试：{tests['pure_algebra_tests'].get('tests_run', 0)}项，通过={tests['pure_algebra_tests'].get('passed', False)}；合成fixture计划完整={tests['synthetic_fixture_tests'].get('complete', False)}、通过={tests['synthetic_fixture_tests'].get('passed', False)}。历史准备期测试日志保留，见tests.json/tests.txt。",
             f"新见证只读回放：{result['tests']['verification_replay_records']}条；回放LP调用={result['tests']['replay_optimization_calls']}。保存guard回执记录的原Stage-A/B调用={guards['original_stage_a_b_solve_calls']}；原优化器构造={guards['original_optimizer_constructions']}。guard回执覆盖完整={guards['guard_receipts_complete_for_requested_workers']}；缺失回执单列，不能解释成完整的零调用回执。",
             f"单条worker固定300秒，真实恢复全轮固定3600秒。实际全轮耗时={result['real_batch_elapsed_seconds']}秒，停止原因={result['run_stop_reason']}。超时/未完成不增加预算，也不改科学门。",
             "源/实现/配置hash、依赖wheel来源及hash、worker命令/退出码/耗时、LP输入、预留/入口/终止回执分别见SOURCE_MANIFEST、IMPLEMENTATION_MANIFEST、ENVIRONMENT_LOCK、auxiliary_lp_inputs和recovery_call_ledger。原优化边界及唯一辅助入口的实际覆盖见optimizer_call_audit，不宣称通用原生代码沙箱。",
             "", "## 方法学风险检查", "",
             "|风险|本轮处理|", "|---|---|",
             "|Simpson悖论|逐ordinal及原状态列结果；汇总覆盖数不替代分组证书事实。|",
             "|生态谬误|这些有限保存案例的代数证书不外推机器人部署或总体性能。|",
             "|Berkson选择偏差|固定F停止序列全部20条含拒收点；不是随机样本。|",
             "|Collider bias|没有因果估计；不据选择后的恢复结果解释solver状态。|",
             "|基率忽略|保留20条固定分母以及剩余26回归/245全面板未运行事实。|",
             "|回归均值|不作统计改善推断；仅一次恢复、无按结果重试。|",
             "|幸存者偏差|失败、超时、NOT RUN及浮点导出失败同表保留。|",
             "|Look-elsewhere effect|单一指定恢复方法，无算法择优；不设事后gap门。|",
             "|分析路径自由度|真实调用前冻结，真实开始后错误停止并交回审计。|",
             "|相关不等于因果|端点舍入、恢复距离不自动解释AlmostSolved根因。|",
             "|反向因果|无因果模型，此项不适用于代数证书；不赋予状态/误差因果方向。|",
             "", "无p值、抽样置信区间或统计功效推断；这些项目不适用于本次确定性证书复核。两路径使用同一辅助工具，不算新的独立优化实现等价证据。",
             "", "## 科研含义与停止", "",
             (f"新增{certified}个经验证有理点为对应原QP提供严格可行性与上界证据，补齐这些记录的原G上界缺口。" if certified else "本轮未产生经独立验证的新原QP上界；固定方法在已消耗资源和停机规则下的能力边界如实保留。") +
             "原生产solver状态、运行性能、实时控制适用性及独立实现等价性仍未由这条证书支线解决。不得把H覆盖完成当F通过，或以区间宽度自动授权下一实验。",
             "严格证书诊断支线到此停止；原剩余回归、全面板、Stage-A、B1-soft与E1均未执行。后续方向只交回科研审计，不自动寻找另一个恢复方法。",
             "", f"工作树：{ROOT}", f"分支：{result['branch']}", f"源G提交：{BASE}",
             "结果提交在最终交付与GIT_DELIVERY.json中记录；本文件不嵌入自身提交hash。未推送。", "",
             "STEP02F_RESULT_UNCHANGED = FAIL / REVISE", "STEP02G_RESULT_UNCHANGED = AUDIT_COMPLETED",
             f"SAVED_RECORD_AUXILIARY_LP_CALLS = {_count_text(saved)}/20",
             f"SYNTHETIC_FIXTURE_LP_CALLS = {_count_text(synthetic)}/16",
             f"TOTAL_NEW_OPTIMIZATION_CALLS = {total}", f"NEW_CERTIFICATE_WITNESSES = {certified}/20",
             f"ORIGINAL_STAGE_A_B_SOLVE_CALLS = {guards['original_stage_a_b_solve_calls']}",
             "REMAINING_STEP02F_REGRESSIONS = NOT RUN", "STEP02F_FULL_PANEL = NOT RUN",
             "FURTHER_SOLVE_AUTHORIZED = FALSE", "E1_AUTHORIZED = FALSE", ""]
    (OUT / "STEP02H_REPORT.md").write_text("\n".join(text), encoding="utf-8", newline="\n")
    handoff = ["# STEP02H execution handoff", "", "Verification level: ANALYZED; post-hoc certificate recovery and exact checking only.",
               f"Status: {result['status']}; independently certified new witnesses: {certified}/20.",
               "Read STEP02H_REPORT.md, STEP02H_RESULT.json, primal_dual_intervals.jsonl and recovery_summary.csv; inspect independent_verification.jsonl, recovered_rational_witnesses and original LP inputs for exact evidence.",
               f"Confirmed real/synthetic calls: {_count_text(saved)}/{_count_text(synthetic)}; total: {total}. Reservations and unknown dispatches are separate in optimizer_call_audit.json. Never retry a consumed ordinal.",
               f"Worktree: {ROOT}", f"Branch: {result['branch']}", f"G baseline: {BASE}",
               "Result commit: final delivery and GIT_DELIVERY.json; artifact hashes are produced after review.",
               "This reporting pass constructs no optimizer and calls no LP. Old F/G files and statuses remain unchanged.", "",
               "STEP02F_RESULT_UNCHANGED = FAIL / REVISE", "STEP02G_RESULT_UNCHANGED = AUDIT_COMPLETED",
               "REMAINING_STEP02F_REGRESSIONS = NOT RUN", "STEP02F_FULL_PANEL = NOT RUN",
               "FURTHER_SOLVE_AUTHORIZED = FALSE", "E1_AUTHORIZED = FALSE", ""]
    (OUT / "EXECUTION_HANDOFF.md").write_text("\n".join(handoff), encoding="utf-8", newline="\n")


if __name__ == "__main__":
    delivered = deliver()
    print(json.dumps({key: delivered[key] for key in
                      ("status", "fixed_rows", "new_certificate_witnesses", "reporting_optimization_calls")},
                     ensure_ascii=False, sort_keys=True))
