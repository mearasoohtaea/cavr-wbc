"""Frozen miniature STEP02H inputs; defining them performs no optimization.

The parent runner may dispatch each stable identity once through the same
budgeted auxiliary entry used for saved records.  These are hand-constructed
2D examples, not research candidates or new certificates for historical data.
"""

from fractions import Fraction as F


EPSILON_BINARY64 = F(3022314549036573, 1 << 78)


def _case(identity, ordinal, *, equality_rhs, saved, lower, upper, target):
    """Every supplied box face is itself an original G/h inequality."""
    return {
        "case_id": identity,
        "path": "synthetic_fixture",
        "solve_ordinal": ordinal,
        "expected_schema": False,
        "P": [[F(1, 4), F(0)], [F(0), F(2, 3)]],
        "q": [F(0), F(0)],
        "E": [[F(1), F(1)]],
        "d": [F(equality_rhs)],
        "G": [[F(1), F(0)], [F(-1), F(0)],
              [F(0), F(1)], [F(0), F(-1)]],
        "h": [F(upper[0]), -F(lower[0]), F(upper[1]), -F(lower[1])],
        "equality_labels": ["synthetic_sum[0]"],
        "inequality_labels": ["synthetic_upper[0]", "synthetic_lower[0]",
                              "synthetic_upper[1]", "synthetic_lower[1]"],
        "c_original": F(0),
        "w_saved": [F(value) for value in saved],
        "D": [F(1), F(1)],
        "ell": [F(value) for value in lower],
        "u": [F(value) for value in upper],
        "task_matrix": [[F(1), F(0)]],
        "task_bias": [F(0)],
        "target": [F(target)],
        "task_scales": [F(1)],
        "epsilon": EPSILON_BINARY64,
    }


def fixtures() -> list[dict]:
    """Return fresh exact inputs and hand-derived expectations in fixed order.

    ``expected_status`` names a runtime outcome, not independent certification
    of an optimizer's status.  The infeasible fixture has a direct hand proof
    for the original-G/literal intersection only.  Its original QP is feasible.
    The three feasible distance values below have elementary fixture-specific
    proofs; those proofs do not assert distance optimality for saved records.
    """
    half = "h_fixture_01_half_distance"
    negative = "h_fixture_02_negative_bounds"
    active = "h_fixture_03_thin_band_active_normal"
    intersection = "h_fixture_04_literal_intersection_infeasible"
    active_case = _case(active, 3, equality_rhs=0, saved=(0, 1),
                        lower=(-2, -2), upper=(2, 0), target=0)
    active_case["inequality_labels"][2] = "normal_upper[synthetic]"
    return [
        {
            "identity": half,
            "case": _case(half, 1, equality_rhs=1, saved=(0, 0),
                          lower=(-2, -2), upper=(2, 2), target=F(1, 2)),
            "expected_rank": 1,
            "expected_status": "BACKEND_RETURNED",
            "expected_t": F(1, 2),
            "expected_w": [F(1, 2), F(1, 2)],
            "hand_proof": "x+y=1 and |x|,|y|<=t imply 1<=2t; (1/2,1/2) attains it.",
        },
        {
            "identity": negative,
            "case": _case(negative, 2, equality_rhs=-3, saved=(-1, -1),
                          lower=(-3, -3), upper=(-1, -1), target=F(-3, 2)),
            "expected_rank": 1,
            "expected_status": "BACKEND_RETURNED",
            "expected_t": F(1, 2),
            "expected_w": [F(-3, 2), F(-3, 2)],
            "hand_proof": "(x+1)+(y+1)=-1 and both deviations have magnitude<=t, so t>=1/2.",
        },
        {
            "identity": active,
            "case": active_case,
            "expected_rank": 1,
            "expected_status": "BACKEND_RETURNED",
            "expected_t": F(1),
            "expected_w": [F(0), F(0)],
            "equality_only_projection": [F(-1, 2), F(1, 2)],
            "hand_proof": "y<=0 gives |y-1|>=1; (0,0) attains t=1. Projection (-1/2,1/2) violates y<=0 and the literal band.",
        },
        {
            "identity": intersection,
            "case": _case(intersection, 4, equality_rhs=0, saved=(1, -1),
                          lower=(1, -2), upper=(2, -1), target=0),
            "expected_rank": 1,
            "expected_status": "SOLVER_REPORTED_INFEASIBLE",
            "expected_t": None,
            "original_feasible_witness": [F(1), F(-1)],
            "hand_proof": "Original x>=1 contradicts literal x<=epsilon<1; (1,-1) remains original-QP feasible.",
            "infeasibility_scope": "original_G_and_literal_intersection_only",
        },
    ]
