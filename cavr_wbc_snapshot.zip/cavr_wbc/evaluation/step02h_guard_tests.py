"""Explicit negative boundary probes: no optimizer backend is ever dispatched.

Each probe installs a fresh guard, calls one prohibited entry and requires the
known fail-fast exception before implementation. These probes are neither LP
fixtures nor positive solves and never access the task's persistent ledger.
"""
from __future__ import annotations

import importlib
import sys

from cavr_wbc.evaluation import step02h_runtime as runtime
from cavr_wbc.evaluation import step02g_no_solve as historical_boundary


_DIRECT = (
    ("sympy.solvers.simplex", "linprog"),
    ("sympy.solvers.simplex", "lpmin"),
    ("sympy.solvers.simplex", "lpmax"),
    ("sympy.solvers.simplex", "_lp"),
    ("sympy.solvers.simplex", "_simplex"),
    ("scipy.optimize", "linprog"),
    ("scipy.optimize", "minimize"),
    ("scipy.optimize", "milp"),
    ("clarabel", "DefaultSolver"),
    ("clarabel.clarabel", "DefaultSolver"),
    ("osqp", "OSQP"),
    ("osqp.interface", "OSQP"),
    ("osqp.ext_builtin", "OSQPSolver"),
)


def run_guard_selftests():
    """Return separately labelled zero-dispatch coverage; do not persist files.

    Must run outside an existing boundary so a deliberate exception in a
    profile callback cannot leave a later probe sharing that callback's state.
    Protected exports need no arguments. Cached functions receive their
    required positional arguments so Python enters the profile hook rather
    than rejecting the signature before that hook. No optimizer is constructed.
    """
    if runtime._ACTIVE.get() is not None or historical_boundary._ACTIVE_GUARD.get() is not None:
        raise ValueError("Negative guard selftests require fresh, nonnested contexts")
    plan = [{"module": module, "attribute": attribute, "kind": "direct_export"}
            for module, attribute in _DIRECT]
    for module_name, class_name in historical_boundary._WRAPPERS:
        cls = getattr(importlib.import_module(module_name), class_name)
        methods = sorted(name for name in vars(cls) if name == "_solve" or name.startswith("solve_"))
        if "_solve" not in methods:
            raise ValueError("Frozen wrapper route schema changed")
        plan.extend({"module": module_name, "class": class_name, "attribute": name, "kind": "frozen_wrapper"}
                    for name in methods)
    wrapper_count = sum(row["kind"] == "frozen_wrapper" for row in plan)
    if wrapper_count != 19:
        raise ValueError("Expected the independently inspected 19 frozen wrapper routes")

    # Capture cached function aliases before installing any H guard. Calling
    # these later must be stopped by the profile hook, not export replacement.
    for module_name, attribute in (("sympy.solvers.simplex", "linprog"),
                                    ("sympy.solvers.simplex", "_simplex"),
                                    ("scipy.optimize", "linprog")):
        plan.append({"module": module_name, "attribute": attribute,
                     "kind": "cached_python_function",
                     "cached": getattr(importlib.import_module(module_name), attribute),
                     "args": (None, None, None) if attribute == "_simplex" else
                             ([importlib.import_module("sympy").Integer(0)],)})

    outcomes = []
    known = (runtime.OptimizerBoundaryError, historical_boundary.ZeroSolveBoundaryError)
    for item in plan:
        path = item["module"] + "." + ((item["class"] + ".") if "class" in item else "") + item["attribute"]
        caught = None
        with runtime.auxiliary_optimizer_guard() as boundary:
            log, original = boundary.guard_log, boundary.guard_log["original_guard"]
            if log["nested_entries"] != 0 or log["allowed_calls"] or log["blocked_attempts"] or original["blocked_attempts"]:
                raise AssertionError("Negative probe did not obtain a fresh clean boundary")
            module = importlib.import_module(item["module"])
            owner = getattr(module, item["class"]) if "class" in item else module
            entry = item.get("cached") if item["kind"] == "cached_python_function" else getattr(owner, item["attribute"])
            if item["kind"] == "cached_python_function":
                profile = sys.getprofile()
                if profile is None or profile.__module__ != runtime.__name__:
                    raise AssertionError("Cached probe requires the installed H pre-entry profile guard")
            try:
                entry(*item.get("args", ()))
            except known as exc:
                caught = {"type": type(exc).__name__, "message": str(exc)}
            blocked = list(log["blocked_attempts"]) + list(original["blocked_attempts"])
            if caught is None or len(blocked) != 1:
                raise AssertionError(f"Expected one pre-dispatch rejection: {path}")
            if log["allowed_calls"] or original["actual_constructions"] != 0 or original["actual_solve_calls"] != 0:
                raise AssertionError("Negative probe entered an optimizer backend")
            if log["actual_original_stage_a_b_calls"] != 0 or log["actual_original_optimizer_constructions"] != 0:
                raise AssertionError("Original optimization counter changed")
            if not all(row.get("intercepted_before_dispatch", row.get("intercepted_before_backend_dispatch", False)) for row in blocked):
                raise AssertionError("Rejection does not attest interception before dispatch")
        if not log["guard_restored"] or not original["guard_restored"]:
            raise AssertionError("Fresh negative probe guard was not restored")
        outcomes.append({"entrypoint": path, "probe_kind": item["kind"], "status": "DENIED_BEFORE_BACKEND_DISPATCH",
                         "expected_exception": caught, "deliberate_test_blocked_attempts": blocked,
                         "allowed_auxiliary_calls": 0, "actual_original_constructions": 0,
                         "actual_original_solve_calls": 0, "guard_restored": True,
                         "patched_H_entrypoints": log["patched_entrypoints"],
                         "patched_original_entrypoints": original["patched_entrypoints"]})
    return {"status": "PASS", "scope": "Deliberate negative guard selftests, not positive LP fixtures",
            "fresh_contexts": len(outcomes), "negative_probes": outcomes,
            "frozen_wrapper_routes_checked": wrapper_count,
            "actual_optimizer_constructions": 0, "actual_optimization_solve_calls": 0,
            "allowed_auxiliary_lp_calls": 0, "task_call_ledger_accessed": False,
            "all_denied_before_backend_dispatch": True}
