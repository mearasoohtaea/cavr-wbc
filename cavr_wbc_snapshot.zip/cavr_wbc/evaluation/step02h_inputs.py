"""Read frozen F/G inputs without calling their experiment or audit runners."""
from __future__ import annotations
from datetime import datetime, timezone
from fractions import Fraction
import hashlib
import importlib.metadata
import json
from pathlib import Path
import subprocess
import sys
import numpy as np
import yaml
from cavr_wbc.evaluation.step02g_saved_certificates import checked_path, load_problem, read_json, read_jsonl, sha256, verify_hash, serialize_exact, write_json, append_jsonl, join_records
from cavr_wbc.evaluation.step02g_endpoints import canonical_label, _expected_labels

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT.parent / 'cavr_step02g_saved_certificate_audit_20260918'
OUT = ROOT / 'artifacts/step02h_exact_primal_certificate'
GF = ROOT / 'artifacts/step02g_saved_certificate_audit'
FF = ROOT / 'artifacts/step02f_coordinate_equivalence'
BASE = '7abc4d489a9266684e5672414415394e111ddd23'
CONFIG_SHA = 'fd14b1fe8a4a6ba689d73ca94e128095c1d8726ecac6438eadd1bc1587c96a6b'
VERSION = 'STEP02H_EXACT_LINF_RECOVERY_V1'
PROTOCOL_SOURCE = ROOT.parent / 'step02g_scientific_audit_20260918'
PROTOCOLS = {'NEXT_CODEX_INSTRUCTIONS_STEP02H.md':'c6f32c194e4520ea896b4c0a4d06abb7cdbd882f6cb73d947639a45d04f8b3ef',
             'STEP02G_SCIENTIFIC_REVIEW.md':'a498e3fb101a2831d9fd1f69b80b67a092d27f93947594d53693229f261c8251'}

def utc():
    return datetime.now(timezone.utc).isoformat()

def require(condition, message):
    if not condition:
        raise ValueError(message)

def git(root, *args):
    return subprocess.check_output(['git','-c','core.quotepath=false','-C',str(root),*args]).decode('utf-8').strip()

def rational_decode(value):
    """Exact persisted rational objects are decoded from integer strings only."""
    if isinstance(value, dict):
        if 'numerator' in value or 'denominator' in value:
            a,b=value['numerator'],value['denominator']
            require(isinstance(a,str) and isinstance(b,str), 'Rational numerator/denominator must be integer strings')
            require(str(int(a))==a and str(int(b))==b and int(b)>0, 'Invalid canonical rational encoding')
            return Fraction(int(a),int(b))
        return {k:rational_decode(v) for k,v in value.items()}
    if isinstance(value,list):
        return [rational_decode(v) for v in value]
    return value

def compact(value):
    if isinstance(value,Fraction):
        return {'numerator':str(value.numerator),'denominator':str(value.denominator)}
    if isinstance(value,dict):
        return {str(k):compact(v) for k,v in value.items()}
    if isinstance(value,(tuple,list)):
        return [compact(v) for v in value]
    return value

def exact_hash(value):
    return hashlib.sha256(json.dumps(compact(value),sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf-8')).hexdigest()

def write_compact(path,value):
    Path(path).write_text(json.dumps(compact(value),ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n',encoding='utf-8',newline='\n')

def binary_exact(value):
    if isinstance(value,np.ndarray):
        return binary_exact(value.tolist())
    if isinstance(value,list):
        return [binary_exact(v) for v in value]
    require(isinstance(value,(int,float,np.floating)) and not isinstance(value,bool) and np.isfinite(value), 'Nonfinite/nonbinary saved coefficient')
    return Fraction.from_float(float(value))

def configuration():
    verify_hash(FF/'config.yaml',CONFIG_SHA)
    config=yaml.safe_load((FF/'config.yaml').read_text(encoding='utf-8'))
    entries=read_json(ROOT/'artifacts/step01b_platform_freeze/actuator_joint_map.json')['entries']
    require([v['actuator_index'] for v in entries]==list(range(12)), 'Actuator map order')
    config['_audited_actuator_names']=[v['actuator_name'] for v in entries]
    require(config['objectives']['secondary_task_fix_normalized_tolerance']==1e-8,'Literal tolerance changed')
    require(config['task_stack']['c_at_primary_zero_velocity']==[0.0]*8,'Nonzero task bias unsupported')
    return config

def records():
    joined=join_records(read_jsonl(FF/'raw_solver_diagnostics.jsonl'),read_jsonl(FF/'original_unit_certificates.jsonl'),read_jsonl(FF/'solver_call_ledger.jsonl'),read_jsonl(FF/'solve_attempt_ledger.jsonl'))
    g=read_jsonl(GF/'candidate_audit.jsonl')
    require(len(g)==20,'G record count')
    for group,row in zip(joined,g):
        raw,cert,_,_=group
        require(all(raw[k]==row[k] for k in ('solve_ordinal','case_id','path')),'G/F record join mismatch')
        require(row['strict_primal_upper_bound'] is None and row['strict_optimality_gap'] is None and row['lower_bound_status']=='CERTIFIED','G history changed')
    return joined,g

def load_case(ordinal):
    require(type(ordinal) is int and 1<=ordinal<=20,'Saved ordinal range')
    joined,gs=records(); raw,cert,_,_=joined[ordinal-1]; grow=gs[ordinal-1]
    index=read_json(FF/'represented_problem_index.json'); entry=index[raw['case_id']][raw['path']]
    npz=checked_path(ROOT,entry['file']); verify_hash(npz,entry['sha256']); problem=load_problem(npz)
    gpath=checked_path(GF,grow['exact_evidence_file']); verify_hash(gpath,grow['exact_evidence_sha256'])
    ge=rational_decode(read_json(gpath)); gsummary=rational_decode(grow); cfg=configuration()
    eql=[canonical_label(x,equality=True) for x in problem['equality_labels']]
    inql=[canonical_label(x,equality=False) for x in problem['inequality_labels']]
    require((eql,inql)==_expected_labels(),'Unknown/duplicate/incorrect original row order')
    stagefile='p0_clarabel_diagnostics.jsonl' if raw['path']=='production' else 'reference_diagnostics.jsonl'
    stagepath='p0_a' if raw['path']=='production' else 'ref_a'
    stages=[r for r in read_jsonl(ROOT/'artifacts/step02d_exact_band_equivalence'/stagefile) if r['phase']=='full_panel' and r['path']==stagepath and r['case_id']==raw['case_id']]
    require(len(stages)==1 and stages[0]['success'] and stages[0]['status']=='Solved','Stage-A accepted full_panel linkage')
    require(stages[0]['task_output']==cert['cached_stage_a_target'],'Cached target changed')
    case={key:binary_exact(problem[source]) for key,source in (('P','original_P'),('q','original_q'),('E','original_E'),('d','original_f'),('G','original_G'),('h','original_h'),('D','D'),('equality_row_scales','equality_row_scales'),('inequality_row_scales','inequality_row_scales'))}
    task=[]
    for j in range(8):
        upper=case['G'][inql.index(f'fixed_task_upper[{j}]')]; lower=case['G'][inql.index(f'fixed_task_lower[{j}]')]
        nonzero=[i for i,x in enumerate(upper) if x]
        require(len(nonzero)==1 and nonzero[0]<18 and upper[nonzero[0]]==1 and lower==[-x for x in upper],'Task selector structure')
        task.append(upper)
    case.update(solve_ordinal=ordinal,case_id=raw['case_id'],path=raw['path'],original_status=raw['status'],
                c_original=Fraction(0),w_saved=binary_exact(cert['original_witness']),
                ell=ge['box_certificate']['lower'],u=ge['box_certificate']['upper'],
                task_matrix=task,task_bias=[Fraction(0)]*8,target=binary_exact(cert['cached_stage_a_target']),
                task_scales=binary_exact(cfg['task_stack']['normalization_scales']),epsilon=binary_exact(cfg['objectives']['secondary_task_fix_normalized_tolerance']),
                L=gsummary['strict_lower_bound'],nu=ge['nu_original'],mu=ge['mu_original'],saved_dual=binary_exact(raw['dual']),
                equality_labels=[str(x) for x in problem['equality_labels']],inequality_labels=[str(x) for x in problem['inequality_labels']],
                canonical_equality_labels=eql,canonical_inequality_labels=inql,expected_schema=True,
                original_g_upper_bound=gsummary['strict_primal_upper_bound'],original_g_gap=gsummary['strict_optimality_gap'],
                saved_candidate_objective=gsummary['candidate_objective'],saved_candidate_objective_minus_L=gsummary['candidate_objective_minus_lower_bound'])
    require(case['w_saved']==ge['original_saved_witness'] and case['epsilon']==ge['literal_binary64_band'],'Exact encoding mismatch')
    require(ge['original_objective_constant']==0 and ge['objective_evidence']['frozen_objective_pattern_verified'],'Original objective source not verified')
    require(all(x>0 for x in case['D']) and all(x>0 for x in case['task_scales']),'Nonpositive physical/task scales')
    case['provenance']={'npz':entry,'g_exact_file':str(gpath.relative_to(ROOT)).replace('\\','/'),'g_exact_sha256':grow['exact_evidence_sha256'],
                        'config_sha256':CONFIG_SHA,'stage_a_file':str((ROOT/'artifacts/step02d_exact_band_equivalence'/stagefile).relative_to(ROOT)).replace('\\','/'),
                        'source_dtype':'binary64 coefficients; persisted rational G values decoded directly from integer strings',
                        'original_constant_source':'Frozen production/reference Stage-B desired_task=None; q=0; original c=0, distinct from affine objective_constant'}
    return case,ge,problem,cfg

def source_manifest():
    require(git(SOURCE,'rev-parse','HEAD')==BASE and git(SOURCE,'status','--porcelain=v1')=='','G source state mismatch')
    require(git(ROOT,'rev-parse','HEAD')==BASE,'H base must be exactG before freezing')
    require(git(ROOT,'diff','--name-only',BASE)=='','Tracked baseline changed')
    names=git(ROOT,'ls-tree','-r','--name-only',BASE).splitlines()
    files={}
    for name in names:
        digest=sha256(SOURCE/name); verify_hash(ROOT/name,digest)
        files[name]=digest
    # G's three manifests and all represented-problem hashes are verified as data,
    # without executing G's runner or repeating any historical experiment.
    checks={}
    for name,key in (('SOURCE_MANIFEST.json','source_tracked_files'),('AUDIT_IMPLEMENTATION_MANIFEST.json','files'),('artifact_hashes.json','files')):
        data=read_json(GF/name)[key]
        for rel,item in data.items():
            verify_hash(ROOT/rel,item if isinstance(item,str) else item['sha256'])
        checks[name]=len(data)
    implementation=read_json(GF/'AUDIT_IMPLEMENTATION_MANIFEST.json')
    verify_hash(GF/'SOURCE_MANIFEST.json',implementation['source_manifest_sha256'])
    repr_index=read_json(FF/'represented_problem_index.json')
    for paths in repr_index.values():
        for entry in paths.values(): verify_hash(ROOT/entry['file'],entry['sha256'])
    protocols=[]
    for name,digest in PROTOCOLS.items():
        verify_hash(PROTOCOL_SOURCE/name,digest); verify_hash(OUT/'protocol'/name,digest)
        protocols.append({'source_path':str(PROTOCOL_SOURCE/name),'copy_path':str(OUT/'protocol'/name),'sha256':digest})
    legacy=read_json(GF/'SOURCE_MANIFEST.json')
    original=Path('C:/Users/ZhuanZ（无密码）/OneDrive - 고려대학교/文档/ChatGPT/保密实验')
    oldf=Path(legacy['source_worktree'])
    inherited_checks={'C_original_head':git(original,'rev-parse','HEAD'),'C_original_status':git(original,'status','--porcelain=v1'),'F_head':git(oldf,'rev-parse','HEAD'),'F_status':git(oldf,'status','--porcelain=v1')}
    original_untracked={rel:sha256(original/rel) for rel in git(original,'ls-files','--others','--exclude-standard').splitlines()}
    return {'created_utc':utc(),'source_commit':BASE,'source_worktree':str(SOURCE),'worktree':str(ROOT),'branch':git(ROOT,'branch','--show-current'),
            'source_status':'','tracked_file_count':len(files),'tracked_files_sha256':files,'g_manifest_checks':checks,'represented_npz_hashes_checked':490,
            'protocols':protocols,'config_sha256':CONFIG_SHA,'original_workspace':str(original),'legacy_worktree':str(oldf),
            'legacy_states':inherited_checks,'original_untracked_sha256':original_untracked}

def verify_sources():
    manifest=read_json(OUT/'SOURCE_MANIFEST.json')
    for name,digest in manifest['tracked_files_sha256'].items():
        verify_hash(ROOT/name,digest); verify_hash(SOURCE/name,digest)
    require(git(SOURCE,'rev-parse','HEAD')==BASE and git(SOURCE,'status','--porcelain=v1')=='','G source altered')
    original=Path(manifest['original_workspace']); oldf=Path(manifest['legacy_worktree']); expected=manifest['legacy_states']
    observed={'C_original_head':git(original,'rev-parse','HEAD'),'C_original_status':git(original,'status','--porcelain=v1'),'F_head':git(oldf,'rev-parse','HEAD'),'F_status':git(oldf,'status','--porcelain=v1')}
    require(expected==observed,'Older workspace states changed')
    for name,digest in manifest['original_untracked_sha256'].items():verify_hash(original/name,digest)
    for row in manifest['protocols']:
        verify_hash(row['source_path'],row['sha256']);verify_hash(row['copy_path'],row['sha256'])
    return {'utc':utc(),'source_and_local_baseline_hashes':len(manifest['tracked_files_sha256']),'source_legacy_states_unchanged':True}

def environment_lock():
    import sympy,mpmath
    require(sympy.__version__=='1.14.0' and mpmath.__version__=='1.3.0','PREPARATION_BLOCKED: backend version')
    require(Path(sys.prefix).resolve()==(ROOT/'.venv-step02h').resolve(),'Dedicated H venv required')
    report=read_json(OUT/'pip_install_report.json')
    wheels=[]
    for entry in report['install']:
        info=entry['download_info']; url=info['url']
        require(url.startswith('https://files.pythonhosted.org/'),'Nonofficial wheel source')
        wheels.append({'name':entry['metadata']['name'],'version':entry['metadata']['version'],'url':url,'sha256':info['archive_info']['hashes']['sha256']})
    import sympy.solvers.simplex as simplex
    return {'python':sys.version,'executable':sys.executable,'prefix':sys.prefix,'pip_source':'https://pypi.org/simple','wheel_artifacts':wheels,
            'installed_versions':{d.metadata['Name']:d.version for d in importlib.metadata.distributions()},
            'simplex_source_path':simplex.__file__,'simplex_source_sha256':sha256(simplex.__file__),
            'official_version_source':'https://github.com/sympy/sympy/blob/1.14.0/sympy/solvers/simplex.py',
            'backend':'sympy.solvers.simplex.linprog','backend_version':'1.14.0','exact_inputs_only':True,
            'dependency_purpose':'NumPy/PyYAML read saved data; frozen numeric validator and existing guard need original-version SciPy/Clarabel/OSQP/MuJoCo definitions; no instances or model construction. SymPy is the only enabled optimizer.'}
