"""Pure exact-algebra construction of the sole STEP-02H auxiliary LP.

No optimization package is imported or called here. Equality elimination is
deterministic Gauss-Jordan arithmetic in the original column order; every
inequality is retained, including redundant box and nonnegative-t rows.
"""

from __future__ import annotations

from fractions import Fraction
from numbers import Integral
import re

ZERO = Fraction(0)
ONE = Fraction(1)
EPSILON_BINARY64 = Fraction(3022314549036573, 1 << 78)


def _fraction(value):
    if isinstance(value, Fraction):
        return value
    if isinstance(value, Integral) and not isinstance(value, bool):
        return Fraction(int(value))
    raise ValueError("EXACT_RATIONAL_INPUT_REQUIRED:" + type(value).__name__)


def _vector(values, length=None):
    result = [_fraction(value) for value in values]
    if length is not None and len(result) != length:
        raise ValueError("VECTOR_DIMENSION_MISMATCH")
    return result


def _matrix(values, columns):
    return [_vector(row, columns) for row in values]


def _dot(left, right):
    if len(left) != len(right):
        raise ValueError("DOT_DIMENSION_MISMATCH")
    return sum((a * b for a, b in zip(left, right) if a and b), ZERO)


def _identity(n):
    return [[Fraction(i == j) for j in range(n)] for i in range(n)]


def _matmul(left, right, right_columns):
    return [[sum((row[k] * right[k][j] for k in range(len(right)) if row[k] and right[k][j]), ZERO)
             for j in range(right_columns)] for row in left]


def eliminate_equalities(E, d, n_variables=None):
    """Return w=p+Nz plus an exact verified row-transformation proof.

    At each original column, choose the first nonzero row at or below the
    current pivot position. No column permutation or numerical pivoting occurs.
    """
    if n_variables is None:
        if not E:
            raise ValueError("N_VARIABLES_REQUIRED_FOR_EMPTY_EQUALITY_SYSTEM")
        n_variables = len(E[0])
    if not isinstance(n_variables, Integral) or n_variables <= 0:
        raise ValueError("POSITIVE_VARIABLE_DIMENSION_REQUIRED")
    n = int(n_variables)
    original_E = _matrix(E, n)
    original_d = _vector(d, len(original_E))
    m = len(original_E)
    reduced = [row.copy() for row in original_E]
    rhs, T = original_d.copy(), _identity(m)
    pivots, operations = [], []
    pivot_row = 0
    for col in range(n):
        selected = next((row for row in range(pivot_row, m) if reduced[row][col] != ZERO), None)
        if selected is None:
            continue
        if selected != pivot_row:
            reduced[pivot_row], reduced[selected] = reduced[selected], reduced[pivot_row]
            rhs[pivot_row], rhs[selected] = rhs[selected], rhs[pivot_row]
            T[pivot_row], T[selected] = T[selected], T[pivot_row]
            operations.append({"operation": "swap", "rows": [pivot_row, selected]})
        pivot = reduced[pivot_row][col]
        scale = ONE / pivot
        reduced[pivot_row] = [value * scale for value in reduced[pivot_row]]
        rhs[pivot_row] *= scale
        T[pivot_row] = [value * scale for value in T[pivot_row]]
        operations.append({"operation": "scale", "row": pivot_row, "factor": scale})
        for row in range(m):
            if row == pivot_row or reduced[row][col] == ZERO:
                continue
            factor = -reduced[row][col]
            reduced[row] = [value + factor * pivot_value for value, pivot_value in zip(reduced[row], reduced[pivot_row])]
            rhs[row] += factor * rhs[pivot_row]
            T[row] = [value + factor * pivot_value for value, pivot_value in zip(T[row], T[pivot_row])]
            operations.append({"operation": "add_scaled_row", "destination": row,
                               "source": pivot_row, "factor": factor})
        pivots.append(col)
        pivot_row += 1
        if pivot_row == m:
            break
    for row in range(pivot_row, m):
        if any(reduced[row]):
            raise ArithmeticError("GAUSS_JORDAN_NONZERO_UNPIVOTED_ROW")
        if rhs[row] != ZERO:
            raise ValueError("EQUALITY_SYSTEM_INCONSISTENT")
    free = [col for col in range(n) if col not in pivots]
    p = [ZERO] * n
    N = [[ZERO] * len(free) for _ in range(n)]
    for row, pivot in enumerate(pivots):
        p[pivot] = rhs[row]
        for j, col in enumerate(free):
            N[pivot][j] = -reduced[row][col]
    for j, col in enumerate(free):
        N[col][j] = ONE
    transformed_E = _matmul(T, original_E, n)
    transformed_d = [_dot(row, original_d) for row in T]
    Ep = [_dot(row, p) for row in original_E]
    EN = _matmul(original_E, N, len(free))
    free_identity = [N[col] for col in free] == _identity(len(free))
    pivot_identity = all(reduced[row][col] == Fraction(row == j)
                         for row in range(m) for j, col in enumerate(pivots))
    verification = {
        "T_E_equals_rref_E": transformed_E == reduced,
        "T_d_equals_rref_d": transformed_d == rhs,
        "E_p_equals_d": Ep == original_d,
        "E_N_zero": all(all(value == ZERO for value in row) for row in EN),
        "free_rows_of_N_identity": free_identity,
        "free_coordinates_of_p_zero": all(p[col] == ZERO for col in free),
        "pivot_columns_identity": pivot_identity,
        "rank_equals_pivot_count": pivot_row == len(pivots),
        "full_solution_coverage": free_identity and pivot_identity,
    }
    if not all(verification.values()):
        raise ArithmeticError("EXACT_ELIMINATION_VERIFICATION_FAILED")
    return {"algorithm": "ORIGINAL_COLUMN_FIRST_NONZERO_ROW_GAUSS_JORDAN_V1",
            "rank": pivot_row, "free_dimension": len(free),
            "pivots": pivots, "free": free, "T": T,
            "rref_E": reduced, "rref_d": rhs, "p": p, "N": N,
            "row_operations": operations, "verification": verification}


def _label_maps(case, ne, ng, real_schema):
    result, canonical_sets = {}, {}
    for kind, count in (("equality", ne), ("inequality", ng)):
        key = kind + "_labels"
        if key not in case:
            if real_schema:
                raise ValueError("REAL_SAVED_LABELS_REQUIRED:" + key)
            labels = [f"synthetic_{kind}[{i}]" for i in range(count)]
        else:
            labels = list(case[key])
        if len(labels) != count:
            raise ValueError("LABEL_ROW_COUNT_MISMATCH")
        normalized = []
        for i, label in enumerate(labels):
            if not isinstance(label, str):
                raise ValueError("STRING_LABEL_REQUIRED")
            canonical = label
            if canonical.startswith("p0_"):
                canonical = canonical[3:]
            elif canonical.startswith("reference_"):
                canonical = canonical[10:]
            normalized.append({"row": i, "original": label, "canonical": canonical})
        canonical = [entry["canonical"] for entry in normalized]
        if len(canonical) != len(set(canonical)):
            raise ValueError("DUPLICATE_CANONICAL_LABEL")
        result[kind], canonical_sets[kind] = normalized, set(canonical)
    if real_schema:
        expected_eq = {f"dynamics[{i}]" for i in range(18)} | {f"contact_acceleration[{i}]" for i in range(12)}
        feet = {match.group(1) for label in canonical_sets["inequality"]
                if (match := re.fullmatch(r"normal_upper\[([A-Za-z0-9_]+)\]", label))}
        expected_ineq = (
            {f"torque_{side}[{i}]" for i in range(12) for side in ("upper", "lower")}
            | {f"fixed_task_{side}[{i}]" for i in range(8) for side in ("upper", "lower")}
            | {f"normal_{side}[{foot}]" for foot in feet for side in ("upper", "lower")}
            | {f"friction[{foot},{i}]" for foot in feet for i in range(4)}
        )
        if canonical_sets["equality"] != expected_eq or len(feet) != 4 or canonical_sets["inequality"] != expected_ineq:
            raise ValueError("UNSUPPORTED_REAL_CANONICAL_LABEL_SET")
    return result


def build_recovery_lp(case, expected_rank=None) -> dict:
    """Build min t over all original/literal/box/distance constraints exactly.

    ``case`` uses actual saved coefficients as Fraction values. Bare integer
    constants are also exact; binary floats and SymPy Float are rejected.
    The proven-box premise is verified independently by the caller before a
    real LP call; this constructor records the supplied box without inventing
    a different one. ``A @ [z,t] <= b`` is the only resulting constraint form.
    """
    w_saved = _vector(case["w_saved"])
    n = len(w_saved)
    if n <= 0:
        raise ValueError("EMPTY_VARIABLE_SET")
    P, q = _matrix(case["P"], n), _vector(case["q"], n)
    if len(P) != n:
        raise ValueError("P_DIMENSION_MISMATCH")
    E, G = _matrix(case["E"], n), _matrix(case["G"], n)
    d, h = _vector(case["d"], len(E)), _vector(case["h"], len(G))
    D, ell, upper = (_vector(case[name], n) for name in ("D", "ell", "u"))
    if any(value <= ZERO for value in D):
        raise ValueError("DISTANCE_SCALE_NOT_POSITIVE")
    if any(lo > hi for lo, hi in zip(ell, upper)):
        raise ValueError("PROVEN_BOX_EMPTY_INTERVAL")
    c_original = _fraction(case["c_original"])
    task_rows = list(case["task_matrix"])
    task_width = len(task_rows[0]) if task_rows else n
    if task_width > n:
        raise ValueError("TASK_WIDTH_EXCEEDS_PHYSICAL_DIMENSION")
    task_matrix_original = _matrix(task_rows, task_width)
    task_matrix = [row + [ZERO] * (n - task_width) for row in task_matrix_original]
    nt = len(task_matrix)
    task_bias, target, task_scales = (_vector(case[name], nt) for name in ("task_bias", "target", "task_scales"))
    epsilon = _fraction(case["epsilon"])
    if epsilon <= ZERO or any(value <= ZERO for value in task_scales):
        raise ValueError("NONPOSITIVE_LITERAL_BAND_OR_TASK_SCALE")
    real_schema = n == 42
    if real_schema:
        if (len(E), len(G), nt, task_width) not in ((30, 64, 8, 18), (30, 64, 8, 42)):
            raise ValueError("REAL_INPUT_SCHEMA_NOT_42_30_64_8")
        if epsilon != EPSILON_BINARY64:
            raise ValueError("FROZEN_BINARY64_EPSILON_MISMATCH")
        selectors = []
        for row in task_matrix:
            nonzero = [i for i, value in enumerate(row) if value != ZERO]
            if len(nonzero) != 1 or nonzero[0] >= 18 or row[nonzero[0]] != ONE:
                raise ValueError("TASK_NOT_UNIT_QDD_SELECTOR")
            selectors.extend(nonzero)
        if len(set(selectors)) != 8 or any(task_bias):
            raise ValueError("TASK_SELECTOR_DUPLICATION_OR_NONZERO_FROZEN_BIAS")
    label_map = _label_maps(case, len(E), len(G), real_schema)
    elimination = eliminate_equalities(E, d, n)
    if expected_rank is None and real_schema:
        expected_rank = 30
    if expected_rank is not None and elimination["rank"] != expected_rank:
        raise ValueError("UNEXPECTED_EQUALITY_RANK")
    if real_schema and (elimination["rank"], elimination["free_dimension"]) != (30, 12):
        raise ValueError("REAL_ELIMINATION_NOT_RANK30_FREE12")
    p, N, free = elimination["p"], elimination["N"], elimination["free"]
    nf = len(free)
    A, b, labels, row_sources = [], [], [], []
    original_augmented_rows, original_augmented_rhs = [], []

    def add_row(label, row, t_coefficient, rhs, source):
        row, t_coefficient, rhs = _vector(row, n), _fraction(t_coefficient), _fraction(rhs)
        transformed = [_dot(row, [N[i][j] for i in range(n)]) for j in range(nf)] + [t_coefficient]
        shifted_rhs = rhs - _dot(row, p)
        A.append(transformed)
        b.append(shifted_rhs)
        labels.append(label)
        row_sources.append({"row": len(A) - 1, "label": label, **source})
        original_augmented_rows.append(row + [t_coefficient])
        original_augmented_rhs.append(rhs)

    for i, (row, rhs) in enumerate(zip(G, h)):
        label = label_map["inequality"][i]["canonical"]
        add_row(label, row, ZERO, rhs, {"group": "original_G", "original_row": i,
                                      "original_label": label_map["inequality"][i]["original"]})
    for i in range(n):
        row = [ZERO] * n
        row[i] = ONE
        add_row(f"box_upper[{i}]", row, ZERO, upper[i], {"group": "box", "coordinate": i, "side": "upper"})
        add_row(f"box_lower[{i}]", [-value for value in row], ZERO, -ell[i], {"group": "box", "coordinate": i, "side": "lower"})
    for j, row in enumerate(task_matrix):
        radius = epsilon * task_scales[j]
        center = target[j] - task_bias[j]
        add_row(f"literal_task_upper[{j}]", row, ZERO, center + radius, {"group": "literal_binary64_contract", "task": j, "side": "upper"})
        add_row(f"literal_task_lower[{j}]", [-value for value in row], ZERO, -center + radius, {"group": "literal_binary64_contract", "task": j, "side": "lower"})
    for i in range(n):
        row = [ZERO] * n
        row[i] = ONE
        add_row(f"distance_upper[{i}]", row, -D[i], w_saved[i], {"group": "scaled_linf_distance", "coordinate": i, "side": "upper"})
        add_row(f"distance_lower[{i}]", [-value for value in row], -D[i], -w_saved[i], {"group": "scaled_linf_distance", "coordinate": i, "side": "lower"})
    add_row("t_nonnegative", [ZERO] * n, -ONE, ZERO, {"group": "t_nonnegative"})
    expected_rows = len(G) + 4 * n + 2 * nt + 1
    if len(A) != expected_rows or len(set(labels)) != expected_rows:
        raise ArithmeticError("FULL_INEQUALITY_ROW_COVERAGE_FAILED")
    bounds = [(ell[i], upper[i]) for i in free] + [(ZERO, None)]
    objective = [ZERO] * nf + [ONE]
    ids = {key: case.get(key) for key in ("case_id", "path", "solve_ordinal")}
    return {
        "status": "EXACT_LP_CONSTRUCTED_NOT_SOLVED", "algorithm": "STEP02H_FIXED_EXACT_EQUALITY_ELIMINATION_LINF_RECOVERY_V1",
        **ids, "elimination": elimination, "p": p, "N": N, "pivots": elimination["pivots"], "free": free,
        "c": objective, "A": A, "b": b, "A_ub": A, "b_ub": b,
        "bounds": bounds, "variable_order": [f"w[{i}]" for i in free] + ["t"],
        "row_labels": labels, "row_sources": row_sources, "label_map": label_map,
        "original_augmented_inequality_matrix": original_augmented_rows,
        "original_augmented_inequality_rhs": original_augmented_rhs,
        "original_inputs": {"P": P, "q": q, "E": E, "d": d, "G": G, "h": h,
                            "c_original": c_original, "w_saved": w_saved, "D": D, "ell": ell, "u": upper,
                            "task_matrix": task_matrix_original, "task_bias": task_bias, "target": target,
                            "task_scales": task_scales, "epsilon": epsilon},
        "task_matrix_full_width": task_matrix, "task_matrix_original_width": task_width,
        "dimensions": {"physical_variables": n, "equalities": len(E), "original_inequalities": len(G),
                       "tasks": nt, "rank": elimination["rank"], "free_variables": nf, "lp_variables": nf + 1,
                       "lp_inequality_rows": len(A)},
        "row_group_counts": {"original_G": len(G), "box": 2 * n, "literal_binary64_contract": 2 * nt,
                             "scaled_linf_distance": 2 * n, "t_nonnegative": 1},
        "objective_is_only_scaled_linf_distance": True,
        "new_lp_calls": 0,
        "literal_intersection_infeasibility_does_not_prove_original_qp_infeasible": True,
    }


def backmap(lp, z, t):
    """Map an exact returned free vector once; floats are never rationalized."""
    free_values = _vector(z, len(lp["free"]))
    _fraction(t)  # Validate backend output type even though t is not a coordinate of w.
    p = _vector(lp["p"])
    N = _matrix(lp["N"], len(free_values))
    if len(N) != len(p):
        raise ValueError("BACKMAP_DIMENSION_MISMATCH")
    return [origin + _dot(row, free_values) for origin, row in zip(p, N)]
