"""Persistent STEP02H budgets and the sole authorized exact-LP boundary.

Installation imports definitions only; it never creates an optimizer or calls
an LP. A consumed reservation is never released, including after a crash.
The process supervisor, timeout handling and scientific verification belong
to the H runner, not this boundary.
"""
from __future__ import annotations

from contextlib import ExitStack, contextmanager
from contextvars import ContextVar
from datetime import datetime, timezone
from functools import wraps
import hashlib
import importlib
import json
import os
from pathlib import Path
import re
import sys
import threading
import time
from unittest.mock import patch
import uuid

ROOT = Path(__file__).resolve().parents[2]
BUDGETS = {"saved_record": 20, "synthetic_fixture": 16}
_ACTIVE = ContextVar("step02h_active_boundary", default=None)
_PERMISSION = ContextVar("step02h_linprog_permission", default=None)
_DIGEST = re.compile(r"[0-9a-f]{64}\Z")


class LedgerError(ValueError):
    """Corrupt, ambiguous or duplicate persisted attempt; fail closed."""


class BudgetExceeded(LedgerError):
    pass


class OptimizerBoundaryError(BaseException):
    """Cannot be swallowed by historical controller ``except Exception``."""


def _utc():
    return datetime.now(timezone.utc).isoformat()


def _json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _digest(value):
    return hashlib.sha256(_json(value).encode("utf-8")).hexdigest()


def _identity(category, identity):
    if category not in BUDGETS:
        raise LedgerError("Unknown budget category")
    if category == "saved_record":
        if type(identity) is not int or not 1 <= identity <= 20:
            raise LedgerError("Saved identity must be original integer ordinal 1..20")
    elif not isinstance(identity, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,159}", identity):
        raise LedgerError("Synthetic identity must be one stable nonempty fixture ID")


class Ledger:
    """Append/fsync hash-chained JSONL under an exclusive fail-closed lock.

    A stale lock is deliberately not reclaimed automatically: after an
    interrupted write, operator audit must precede any further reservation.
    Tokens are portable between parent and worker, but verified against disk
    for every transition. ``start`` counts a durable dispatch intent; a crash
    in the interval before backend entry has unknown outcome, never a retry.
    """

    def __init__(self, path):
        self.path = Path(path).resolve()
        if not self.path.is_relative_to(ROOT) or self.path == ROOT:
            raise LedgerError("H ledger must stay inside the new H worktree")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.lock_path = self.path.with_name(self.path.name + ".lock")

    @contextmanager
    def _lock(self):
        try:
            fd = os.open(self.lock_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        except FileExistsError as exc:
            raise LedgerError("Ledger lock exists: concurrent writer or interrupted operation; no retry") from exc
        try:
            with os.fdopen(fd, "wb") as stream:
                stream.write((_json({"pid": os.getpid(), "created_utc": _utc()}) + "\n").encode("utf-8"))
                stream.flush()
                os.fsync(stream.fileno())
            yield
        finally:
            self.lock_path.unlink()

    def _read(self):
        if not self.path.exists():
            return []
        data = self.path.read_bytes()
        if data and not data.endswith(b"\n"):
            raise LedgerError("Truncated ledger tail; reservations cannot be reconstructed safely")
        try:
            events = [json.loads(line) for line in data.splitlines()]
        except (ValueError, UnicodeDecodeError) as exc:
            raise LedgerError("Malformed ledger") from exc
        previous, states, identities = "0" * 64, {}, set()
        for sequence, row in enumerate(events, 1):
            if not isinstance(row, dict):
                raise LedgerError("Ledger event must be an object")
            payload = {key: value for key, value in row.items() if key != "event_sha256"}
            if row.get("sequence") != sequence or row.get("previous_sha256") != previous or row.get("event_sha256") != _digest(payload):
                raise LedgerError("Ledger sequence/hash chain mismatch")
            previous = row["event_sha256"]
            token = row.get("token", {})
            self._validate_token_shape(token)
            key = token["reservation_id"]
            if row.get("event") == "RESERVED":
                identity_key = (token["category"], token["identity"])
                if key in states or identity_key in identities:
                    raise LedgerError("Duplicated reservation/identity")
                identities.add(identity_key)
                states[key] = {"token": token, "started": False, "finished": False}
            else:
                if key not in states or states[key]["token"] != token:
                    raise LedgerError("Event has no matching immutable reservation")
                state = states[key]
                if state["finished"]:
                    raise LedgerError("Event follows terminal outcome")
                if row.get("event") == "LINPROG_STARTED":
                    if state["started"]:
                        raise LedgerError("Repeated top-level LP dispatch")
                    state["started"] = True
                elif row.get("event") == "FINISHED":
                    state["finished"] = True
                elif row.get("event") not in ("ELIMINATION_START", "ELIMINATION_FINISH", "LP_INPUT_SAVED", "WORKER_START", "PROGRESS"):
                    raise LedgerError("Unknown ledger event")
        for category, limit in BUDGETS.items():
            if sum(item["token"]["category"] == category for item in states.values()) > limit:
                raise LedgerError("Persisted category budget exceeded")
        return events

    @staticmethod
    def _validate_token_shape(token):
        if not isinstance(token, dict) or set(token) != {"reservation_id", "category", "identity", "input_hash"}:
            raise LedgerError("Invalid reservation token shape")
        _identity(token["category"], token["identity"])
        if not isinstance(token["input_hash"], str) or not _DIGEST.fullmatch(token["input_hash"]):
            raise LedgerError("Input hash must be lowercase SHA256")
        if not isinstance(token["reservation_id"], str) or not re.fullmatch(r"[0-9a-f]{32}", token["reservation_id"]):
            raise LedgerError("Invalid reservation ID")

    def _append(self, events, event, token, metadata):
        row = {"sequence": len(events) + 1, "previous_sha256": events[-1]["event_sha256"] if events else "0" * 64,
               "event": event, "token": token, "utc": _utc(), "pid": os.getpid(), "metadata": metadata}
        row["event_sha256"] = _digest(row)
        with self.path.open("ab") as stream:
            stream.write((_json(row) + "\n").encode("utf-8"))
            stream.flush()
            os.fsync(stream.fileno())
        return row

    def reserve(self, category, identity, input_hash):
        _identity(category, identity)
        token = {"reservation_id": uuid.uuid4().hex, "category": category, "identity": identity, "input_hash": input_hash}
        self._validate_token_shape(token)
        with self._lock():
            events = self._read()
            reserved = [row for row in events if row["event"] == "RESERVED"]
            if any(row["token"]["category"] == category and row["token"]["identity"] == identity for row in reserved):
                raise LedgerError("Identity already reserved: completed, failed and unknown outcomes cannot retry")
            if sum(row["token"]["category"] == category for row in reserved) >= BUDGETS[category]:
                raise BudgetExceeded(f"Persistent {category} reservation budget exhausted")
            self._append(events, "RESERVED", token, {"category_limit": BUDGETS[category]})
        return token

    def _matching(self, events, token):
        self._validate_token_shape(token)
        matching = [row for row in events if row["token"]["reservation_id"] == token["reservation_id"]]
        if not matching or any(row["token"] != token for row in matching):
            raise LedgerError("Reservation token does not match this persistent ledger")
        return matching

    def start(self, token, lp_input_hash):
        if not isinstance(lp_input_hash, str) or not _DIGEST.fullmatch(lp_input_hash):
            raise LedgerError("LP input hash must be SHA256")
        with self._lock():
            events = self._read()
            matching = self._matching(events, token)
            if any(row["event"] in ("LINPROG_STARTED", "FINISHED") for row in matching):
                raise LedgerError("Reservation already attempted or finished; no second LP dispatch")
            return self._append(events, "LINPROG_STARTED", token, {"lp_input_hash": lp_input_hash,
                "count_interpretation": "durable dispatch intent immediately before backend entry; interruption may leave actual outcome unknown"})

    def note(self, token, event, **metadata):
        if event not in ("ELIMINATION_START", "ELIMINATION_FINISH", "LP_INPUT_SAVED", "WORKER_START", "PROGRESS"):
            raise LedgerError("Reserved ledger transitions require their dedicated methods")
        with self._lock():
            events = self._read()
            if any(row["event"] == "FINISHED" for row in self._matching(events, token)):
                raise LedgerError("Cannot append progress after terminal outcome")
            return self._append(events, event, token, metadata)

    def finish(self, token, status, **metadata):
        if not isinstance(status, str) or not status.strip():
            raise LedgerError("Terminal status is required")
        with self._lock():
            events = self._read()
            existing = [row for row in self._matching(events, token) if row["event"] == "FINISHED"]
            if existing:
                return existing[0]  # Supervisor never overwrites a worker's known outcome.
            return self._append(events, "FINISHED", token, {**metadata, "status": status})

    def events(self):
        with self._lock():
            return self._read()

    def is_finished(self, token):
        return any(row["event"] == "FINISHED" for row in self._matching(self.events(), token))

    def snapshot(self):
        with self._lock():
            events = self._read()
            ledger_hash = hashlib.sha256(self.path.read_bytes()).hexdigest() if self.path.exists() else None
        categories = {}
        for category, limit in BUDGETS.items():
            selected = [row for row in events if row["token"]["category"] == category]
            categories[category] = {"limit": limit, "reserved": sum(row["event"] == "RESERVED" for row in selected),
                "linprog_started": sum(row["event"] == "LINPROG_STARTED" for row in selected),
                "finished": sum(row["event"] == "FINISHED" for row in selected)}
        attempts = []
        for row in events:
            if row["event"] != "RESERVED":
                continue
            matching = self._matching(events, row["token"])
            terminal = next((item for item in matching if item["event"] == "FINISHED"), None)
            attempts.append({"token": row["token"], "linprog_started": any(item["event"] == "LINPROG_STARTED" for item in matching),
                "status": terminal["metadata"]["status"] if terminal else "ATTEMPT_OUTCOME_UNKNOWN",
                "terminal": terminal is not None, "retry_allowed": False})
        return {"categories": categories, "attempts": attempts, "event_count": len(events),
                "total_reserved": sum(row["reserved"] for row in categories.values()),
                "total_linprog_started": sum(row["linprog_started"] for row in categories.values()),
                "ledger_sha256": ledger_hash}


def _exact_payload(value, sympy, *, allow_none=False):
    """Validate without converting input scalars or doing numeric approximation."""
    if value is None and allow_none:
        return None
    if isinstance(value, sympy.Rational):
        return [str(value.p), str(value.q)]
    if isinstance(value, sympy.matrices.matrixbase.MatrixBase):
        return {"shape": list(value.shape), "data": [_exact_payload(item, sympy) for item in value]}
    if isinstance(value, (list, tuple)):
        return [_exact_payload(item, sympy, allow_none=allow_none) for item in value]
    raise OptimizerBoundaryError("LP scalars must already be SymPy Integer/Rational; Float/Python float/implicit conversion forbidden")


class _Boundary:
    def __init__(self, log, original, sympy):
        self.guard_log = self.log = log
        self._original = original
        self._sympy = sympy
        self._owner = threading.get_ident()

    def linprog(self, ledger, token, c, A=None, b=None, A_eq=None, b_eq=None, bounds=None):
        if _ACTIVE.get() is not self or threading.get_ident() != self._owner or _PERMISSION.get() is not None:
            raise OptimizerBoundaryError("Whitelisted LP entry requires its active owner-thread boundary")
        if not isinstance(ledger, Ledger):
            raise OptimizerBoundaryError("Whitelisted LP entry requires the persistent H Ledger")
        # Explicit list-of-tuples bounds cannot silently inherit nonnegativity.
        if not isinstance(bounds, list) or not bounds or any(type(pair) is not tuple or len(pair) != 2 for pair in bounds):
            raise OptimizerBoundaryError("Explicit per-variable bounds list of pairs required")
        payload = {"c": _exact_payload(c, self._sympy), "A": _exact_payload(A, self._sympy, allow_none=A is None),
            "b": _exact_payload(b, self._sympy, allow_none=b is None),
            "A_eq": _exact_payload(A_eq, self._sympy, allow_none=A_eq is None),
            "b_eq": _exact_payload(b_eq, self._sympy, allow_none=b_eq is None),
            "bounds": _exact_payload(bounds, self._sympy, allow_none=True)}
        objective = self._sympy.Matrix(c)
        if min(objective.shape) != 1 or len(objective) != len(bounds):
            raise OptimizerBoundaryError("Objective dimension and explicit bounds disagree")
        ledger.start(token, _digest(payload))
        receipt = {"reservation_id": token["reservation_id"], "category": token["category"], "identity": token["identity"],
            "input_hash": token["input_hash"], "lp_input_hash": _digest(payload), "top_level_entries": 0, "internal_simplex_entries": 0, "pivot_calls": 0}
        self.guard_log["allowed_calls"].append(receipt)
        permission = _PERMISSION.set(receipt)
        started = time.perf_counter()
        try:
            result = self._original(c, A=A, b=b, A_eq=A_eq, b_eq=b_eq, bounds=bounds)
        except BaseException as exc:
            ledger.finish(token, "BACKEND_EXCEPTION", exception_type=type(exc).__name__, exception_message=str(exc),
                          elapsed_seconds=time.perf_counter() - started, receipt=receipt)
            raise
        else:
            ledger.finish(token, "BACKEND_RETURNED", elapsed_seconds=time.perf_counter() - started, receipt=receipt)
            return result
        finally:
            _PERMISSION.reset(permission)


@contextmanager
def auxiliary_optimizer_guard():
    """Block original optimizers and whitelist one persisted SymPy LP attempt.

    Scope is inspected installed routes, not an adversarial native-code sandbox.
    Cached Python function aliases are also checked by a chained profile hook.
    No library algorithm, numerical signature, or solver settings are modified.
    """
    active = _ACTIVE.get()
    if active is not None:
        if active._owner != threading.get_ident():
            raise OptimizerBoundaryError("H boundary is owner-thread only")
        active.guard_log["nested_entries"] += 1
        yield active
        return
    from cavr_wbc.evaluation.step02g_no_solve import optimizer_guard
    with optimizer_guard() as original_guard, ExitStack() as stack:
        if not original_guard["guard_installed"] or original_guard["patch_failures"]:
            raise OptimizerBoundaryError("Original optimizer boundary incomplete")
        sympy = importlib.import_module("sympy")
        if sympy.__version__ != "1.14.0":
            raise OptimizerBoundaryError("STEP02H requires exactly SymPy 1.14.0")
        simplex = importlib.import_module("sympy.solvers.simplex")
        scipy = importlib.import_module("scipy.optimize")
        log = {"guard_installed": False, "guard_restored": False, "original_guard": original_guard,
            "actual_original_stage_a_b_calls": 0, "actual_original_optimizer_constructions": 0,
            "allowed_calls": [], "blocked_attempts": [], "patched_entrypoints": [], "nested_entries": 0,
            "backend": "sympy.solvers.simplex.linprog", "backend_version": sympy.__version__}
        originals = {name: getattr(simplex, name) for name in ("linprog", "lpmin", "lpmax", "_lp", "_simplex")}
        originals.update({"scipy." + name: getattr(scipy, name) for name in ("linprog", "minimize", "milp")})
        boundary = _Boundary(log, originals["linprog"], sympy)
        denied_codes = {func.__code__: name for name, func in originals.items() if name not in ("linprog", "_simplex") and hasattr(func, "__code__")}

        def reject(label):
            log["blocked_attempts"].append({"entrypoint": label, "utc": _utc(), "intercepted_before_dispatch": True})
            raise OptimizerBoundaryError("Non-whitelisted optimizer entry: " + label)

        def replacement(name, original):
            @wraps(original)
            def invoke(*args, **kwargs):
                if name == "_simplex" and _PERMISSION.get() is not None and _ACTIVE.get() is boundary and threading.get_ident() == boundary._owner:
                    return original(*args, **kwargs)
                reject(name)
            return invoke

        # Identity replacement covers already-imported module aliases, while
        # the profile hook also catches aliases cached inside objects/closures.
        replacements = {name: replacement(name, func) for name, func in originals.items()}
        for module_name, module in tuple(sys.modules.items()):
            namespace = getattr(module, "__dict__", None)
            if not isinstance(namespace, dict):
                continue
            for attribute, value in tuple(namespace.items()):
                for name, original in originals.items():
                    if value is original:
                        stack.enter_context(patch.object(module, attribute, replacements[name]))
                        log["patched_entrypoints"].append(module_name + "." + attribute)
                        break
        old_profile, old_thread_profile = sys.getprofile(), threading.getprofile()

        def profile(frame, event, arg):
            if event == "call":
                code, permission = frame.f_code, _PERMISSION.get()
                if code in denied_codes:
                    reject("cached:" + denied_codes[code])
                if code is originals["linprog"].__code__:
                    if permission is None or _ACTIVE.get() is not boundary or threading.get_ident() != boundary._owner:
                        reject("cached:linprog")
                    permission["top_level_entries"] += 1
                    if permission["top_level_entries"] != 1:
                        reject("repeated:linprog")
                if code is originals["_simplex"].__code__:
                    if permission is None or permission["top_level_entries"] != 1 or threading.get_ident() != boundary._owner:
                        reject("cached:_simplex")
                    permission["internal_simplex_entries"] += 1
                if code is simplex._pivot.__code__ and permission is not None:
                    permission["pivot_calls"] += 1
            if old_profile is not None:
                old_profile(frame, event, arg)

        token = _ACTIVE.set(boundary)
        sys.setprofile(profile)
        threading.setprofile(profile)
        log["guard_installed"] = True
        try:
            yield boundary
        finally:
            sys.setprofile(old_profile)
            threading.setprofile(old_thread_profile)
            _ACTIVE.reset(token)
            log["guard_restored"] = True
