"""Independent Fraction verification of H witnesses against saved original QPs.

This module imports neither the recovery/LP/elimination implementation nor G's
bound-computation code. G proof weights and multipliers are checked, not repaired.
"""

from __future__ import annotations

from fractions import Fraction
import hashlib
import json
import math
from typing import Any


ZERO = Fraction(0)
BINARY64_EPSILON = Fraction.from_float(1.0e-8)
DECIMAL_EPSILON = Fraction(1, 100000000)


def _r(value: Any) -> Fraction:
    if isinstance(value, Fraction):
        return value
    if type(value) is int:
        return Fraction(value)
    if isinstance(value, dict) and "numerator" in value and "denominator" in value:
        numerator, denominator = value["numerator"], value["denominator"]
        if type(numerator) not in (int, str) or type(denominator) not in (int, str):
            raise ValueError("Rational numerator/denominator must be integer values or strings")
        n, d = int(numerator), int(denominator)
        if str(n) != str(numerator) or str(d) != str(denominator) or d <= 0:
            raise ValueError("Invalid/noncanonical rational numerator or positive denominator")
        return Fraction(n, d)
    raise ValueError("Exact input required; floating returns and decimal approximations are rejected")


def _v(values, n=None):
    vector = [_r(value) for value in values]
    if n is not None and len(vector) != n:
        raise ValueError("Exact vector dimension mismatch")
    return vector


def _m(rows, n):
    return [_v(row, n) for row in rows]


def _dot(left, right):
    if len(left) != len(right):
        raise ValueError("Dot product dimension mismatch")
    return sum((a * b for a, b in zip(left, right) if a and b), ZERO)


def _problem(case):
    q = _v(case["q"])
    n = len(q)
    if not n:
        raise ValueError("Empty QP")
    P, E, G = (_m(case[key], n) for key in ("P", "E", "G"))
    if len(P) != n:
        raise ValueError("P must be square")
    d, h = _v(case["d"], len(E)), _v(case["h"], len(G))
    c = _r(case["c_original"])
    if c != 0:
        raise ValueError("Frozen original Stage-B constant must be zero")
    D, saved, ell, upper = (_v(case[key], n) for key in ("D", "w_saved", "ell", "u"))
    if any(value <= 0 for value in D) or any(lo > hi for lo, hi in zip(ell, upper)):
        raise ValueError("Nonpositive D or empty box")
    target = _v(case["target"])
    task_bias, scales = _v(case["task_bias"], len(target)), _v(case["task_scales"], len(target))
    if any(scale <= 0 for scale in scales):
        raise ValueError("Task scales must be positive")
    tasks = []
    for row in case["task_matrix"]:
        row = _v(row)
        if len(row) == 18 and n == 42:
            row += [ZERO] * 24
        if len(row) != n:
            raise ValueError("Task operator dimension mismatch")
        tasks.append(row)
    if len(tasks) != len(target):
        raise ValueError("Task count mismatch")
    epsilon = _r(case["epsilon"])
    if epsilon != BINARY64_EPSILON:
        raise ValueError("Frozen epsilon must be exact saved binary64(1e-8)")
    if case.get("expected_schema", True):
        if (n, len(E), len(G), len(tasks)) != (42, 30, 64, 8):
            raise ValueError("Frozen schema must be 42 variables, 30 equalities, 64 inequalities, 8 tasks")
        if any(q) or any(task_bias):
            raise ValueError("Frozen Stage-B linear term and task bias must be zero")
        selectors = []
        for row in tasks:
            selected = [i for i, value in enumerate(row) if value]
            if len(selected) != 1 or selected[0] >= 18 or row[selected[0]] != 1:
                raise ValueError("Frozen task must be an original qdd unit selector")
            selectors.append(selected[0])
        if len(set(selectors)) != 8:
            raise ValueError("Frozen task selectors must be unique")
    return dict(n=n, P=P, q=q, E=E, d=d, G=G, h=h, c_original=c,
                D=D, w_saved=saved, ell=ell, u=upper, task_matrix=tasks,
                task_bias=task_bias, target=target, task_scales=scales, epsilon=epsilon)


def _fingerprint(problem, L):
    def encoded(value):
        if isinstance(value, Fraction):
            return [str(value.numerator), str(value.denominator)]
        if isinstance(value, list):
            return [encoded(item) for item in value]
        if isinstance(value, dict):
            return {key: encoded(item) for key, item in value.items()}
        return value
    data = json.dumps(encoded({**problem, "L": L}), sort_keys=True, separators=(",", ":")).encode("ascii")
    return hashlib.sha256(data).hexdigest()


def _objective(problem, w):
    return sum((w[i] * _dot(row, w) for i, row in enumerate(problem["P"])), ZERO) / 2 + _dot(problem["q"], w) + problem["c_original"]


def _verify_face(face, variable, sign, bound, problem):
    if face["variable"] != variable or face["sign"] != sign:
        raise ValueError("G box face identity mismatch")
    coefficients = [ZERO] * problem["n"]
    rhs = ZERO
    for name, matrix_key, rhs_key, nonnegative in (
        ("equality_weights", "E", "d", False), ("inequality_weights", "G", "h", True)
    ):
        seen = set()
        for row_key, raw_weight in face[name].items():
            row = int(row_key)
            if str(row) != str(row_key) or row in seen or not 0 <= row < len(problem[matrix_key]):
                raise ValueError("G box face row index invalid")
            seen.add(row)
            weight = _r(raw_weight)
            if nonnegative and weight < 0:
                raise ValueError("G box face has negative inequality combination weight")
            for i, value in enumerate(problem[matrix_key][row]):
                coefficients[i] += weight * value
            rhs += weight * problem[rhs_key][row]
    expected = [ZERO] * problem["n"]
    expected[variable] = Fraction(sign)
    if coefficients != expected or rhs != sign * bound or _r(face["rhs"]) != rhs:
        raise ValueError("G box face is not an exact consequence of original rows")


def _verify_label_identity(case, box, p):
    if not case.get("expected_schema", True):
        return 0
    expected_e = [f"dynamics[{i}]" for i in range(18)] + [f"contact_acceleration[{i}]" for i in range(12)]
    expected_g = [f"torque_{side}[{i}]" for i in range(12) for side in ("upper", "lower")]
    for foot in ("FL", "FR", "RL", "RR"):
        expected_g += [f"friction[{foot},{face}]" for face in range(4)]
        expected_g += [f"normal_lower[{foot}]", f"normal_upper[{foot}]"]
    expected_g += [f"fixed_task_{side}[{i}]" for i in range(8) for side in ("upper", "lower")]
    mappings = box["label_map"]
    if len(mappings) != 94:
        raise ValueError("G row label mapping coverage incomplete")
    seen = set()
    for kind, expected in (("equality", expected_e), ("inequality", expected_g)):
        raw_labels = case[kind + "_labels"]
        if len(raw_labels) != len(expected):
            raise ValueError("H original row labels incomplete")
        for row, (raw, want) in enumerate(zip(raw_labels, expected)):
            if not isinstance(raw, str):
                raise ValueError("Original row label must be a string")
            canonical = raw
            for prefix in ("p0_", "reference_"):
                if canonical.startswith(prefix):
                    canonical = canonical[len(prefix):]
                    break
            if canonical != want or canonical in seen:
                raise ValueError("Unknown, duplicated or reordered frozen row label")
            seen.add(canonical)
            matched = [item for item in mappings if item["kind"] == kind and item["row"] == row]
            if len(matched) != 1 or matched[0]["original"] != raw or matched[0]["canonical"] != canonical:
                raise ValueError("G/H original row label mapping differs")
    for task, row in enumerate(p["task_matrix"]):
        upper = expected_g.index(f"fixed_task_upper[{task}]")
        lower = expected_g.index(f"fixed_task_lower[{task}]")
        if p["G"][upper] != row or p["G"][lower] != [-value for value in row]:
            raise ValueError("Literal task operator differs from saved original selector rows")
    return len(mappings)


def verify_g_evidence(case, g_exact) -> dict:
    """Independently recheck G's 84 box faces, multiplier map and exact L."""
    try:
        p = _problem(case)
        box, lower = g_exact["box_certificate"], g_exact["lower_bound_certificate"]
        if box["status"] != "CERTIFIED" or lower["status"] != "CERTIFIED":
            raise ValueError("G evidence does not claim the required certified box/lower bound")
        original = box["proof"]["inputs"]
        for key in ("P", "q", "E", "d", "G", "h"):
            decoded = _m(original[key], p["n"]) if key in ("P", "E", "G") else _v(original[key])
            if decoded != p[key]:
                raise ValueError("G original input differs from H input: " + key)
        if _v(box["lower"], p["n"]) != p["ell"] or _v(box["upper"], p["n"]) != p["u"]:
            raise ValueError("G/H box bounds differ")
        if _r(g_exact["original_objective_constant"]) != p["c_original"] or _r(lower["c_original"]) != p["c_original"]:
            raise ValueError("G/H original constant differs")
        if _v(g_exact["original_saved_witness"], p["n"]) != p["w_saved"]:
            raise ValueError("G/H saved original witness differs")
        labels_verified = _verify_label_identity(case, box, p)
        if case.get("expected_schema", True):
            offsets = [(_dot(row, p["w_saved"]) + bias - target) / scale for row, bias, target, scale in
                       zip(p["task_matrix"], p["task_bias"], p["target"], p["task_scales"])]
            if offsets != _v(g_exact["task_signed_normalized_offsets"]) or _r(g_exact["literal_binary64_band"]) != p["epsilon"]:
                raise ValueError("G/H cached target/scales/literal contract interpretation differs")
        faces_verified = 0
        for key, sign, bounds in (("lower_certificates", -1, p["ell"]), ("upper_certificates", 1, p["u"])):
            faces = box["proof"][key]
            if len(faces) != p["n"]:
                raise ValueError("G box face coverage incomplete")
            for i, face in enumerate(faces):
                _verify_face(face, i, sign, bounds[i], p)
                faces_verified += 1
        dual = _v(case["saved_dual"], len(p["E"]) + len(p["G"]))
        eq_scales = _v(case["equality_row_scales"], len(p["E"]))
        ineq_scales = _v(case["inequality_row_scales"], len(p["G"]))
        if any(value <= 0 for value in eq_scales + ineq_scales):
            raise ValueError("Saved row scales must be positive")
        nu = [scale * value for scale, value in zip(eq_scales, dual[:len(p["E"])])]
        mu = [scale * value for scale, value in zip(ineq_scales, dual[len(p["E"]):])]
        if any(value < 0 for value in mu):
            raise ValueError("Saved mapped inequality multiplier is negative")
        for key, mapped, evidence_key in (("nu", nu, "nu_original"), ("mu", mu, "mu_original")):
            if _v(g_exact[evidence_key]) != mapped or _v(lower[key]) != mapped:
                raise ValueError("G multiplier does not equal saved cone dual times its row scale once")
            if key in case and _v(case[key]) != mapped:
                raise ValueError("H supplied multiplier differs from independent saved-dual mapping")
        for i, row in enumerate(p["P"]):
            for j, value in enumerate(row):
                if (i != j and value) or (i == j and value < 0):
                    raise ValueError("Original P is not symmetric diagonal positive semidefinite")
        if case.get("expected_schema", True):
            if any((p["P"][i][i] > 0) != (18 <= i < 30) for i in range(p["n"])):
                raise ValueError("Frozen positive Hessian diagonal must cover exactly twelve torque coordinates")
        k = [p["q"][i] + sum((row[i] * value for row, value in zip(p["E"], nu)), ZERO)
             + sum((row[i] * value for row, value in zip(p["G"], mu)), ZERO) for i in range(p["n"])]
        constant = p["c_original"] - _dot(nu, p["d"]) - _dot(mu, p["h"])
        if _v(lower["k"]) != k or _r(lower["constant"]) != constant:
            raise ValueError("G fixed-multiplier Lagrangian coefficients differ")
        minima = lower["coordinate_minima"]
        if len(minima) != p["n"]:
            raise ValueError("G coordinate minimum coverage incomplete")
        recomputed_minima = []
        for i in range(p["n"]):
            diag, lo, hi = p["P"][i][i], p["ell"][i], p["u"][i]
            points = [("lower", lo), ("upper", hi)]
            if diag:
                stationary = -k[i] / diag
                if lo <= stationary <= hi:
                    points.append(("stationary", stationary))
            values = [(kind, t, diag * t * t / 2 + k[i] * t) for kind, t in points]
            minimum = min(value for _, _, value in values)
            record = minima[i]
            if record["coordinate"] != i or any(_r(record[key]) != value for key, value in (
                ("P_diagonal", diag), ("k", k[i]), ("lower", lo), ("upper", hi), ("minimum", minimum)
            )):
                raise ValueError("G coordinate closed-form minimum differs")
            recorded_points = [(item["kind"], _r(item["argument"]), _r(item["value"])) for item in record["evaluated_candidates"]]
            if recorded_points != values:
                raise ValueError("G closed-form endpoint/stationary candidates differ")
            minimizing = (_r(record["minimizer"]), _r(record["minimum"]))
            if (record["selected_kind"], *minimizing) not in values or minimizing[1] != minimum:
                raise ValueError("G selected coordinate minimum invalid")
            recomputed_minima.append(minimum)
        L = constant + sum(recomputed_minima, ZERO)
        if L != _r(lower["L"]) or L != _r(case["L"]):
            raise ValueError("G/H claimed lower bound differs from exact closed-form sum")
        f_saved = _objective(p, p["w_saved"])
        objective_evidence = g_exact["objective_evidence"]
        if _r(objective_evidence["candidate_objective"]) != f_saved or _r(objective_evidence["strict_lower_bound"]) != L or _r(objective_evidence["candidate_objective_minus_lower_bound"]) != f_saved - L:
            raise ValueError("G saved-objective/lower-bound diagnostic differs")
        return {"status": "G_EVIDENCE_VERIFIED", "verified": True, "failures": [],
                "L": L, "ell": p["ell"], "u": p["u"], "nu": nu, "mu": mu,
                "box_faces_verified": faces_verified, "coordinate_minima_verified": p["n"],
                "row_label_mappings_verified": labels_verified,
                "saved_candidate_objective": f_saved, "saved_candidate_objective_minus_L_diagnostic": f_saved - L,
                "verification_binding_sha256": _fingerprint(p, L),
                "objective_units": "actual weighted original Stage-B QP; no lambda conversion",
                "requires_no_stationarity_assumption": True}
    except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError, OverflowError) as exc:
        return {"status": "G_EVIDENCE_INVALID", "verified": False, "failures": [str(exc)], "L": None}


def _witness_checks(p, w):
    equality = [_dot(row, w) - rhs for row, rhs in zip(p["E"], p["d"])]
    inequality = [_dot(row, w) - rhs for row, rhs in zip(p["G"], p["h"])]
    offsets = [(_dot(row, w) + bias - target) / scale for row, bias, target, scale in
               zip(p["task_matrix"], p["task_bias"], p["target"], p["task_scales"])]
    return {"equality_residuals": equality, "inequality_residuals": inequality,
            "task_normalized_offsets": offsets,
            "exact_equalities_pass": all(value == 0 for value in equality),
            "exact_original_inequalities_pass": all(value <= 0 for value in inequality),
            "literal_binary64_band_pass": all(abs(value) <= p["epsilon"] for value in offsets),
            "decimal_band_report_only_pass": all(abs(value) <= DECIMAL_EPSILON for value in offsets)}


def verify_witness(case, g_verified, w_certificate, t) -> dict:
    """Check a new rational witness independently; no distance-optimality claim."""
    failed = {"status": "RETURNED_WITNESS_INVALID", "certified": False, "U": None,
              "certified_interval": None, "certified_gap_bound": None}
    try:
        p = _problem(case)
        if not g_verified.get("verified") or g_verified.get("status") != "G_EVIDENCE_VERIFIED":
            raise ValueError("G lower-bound evidence was not independently verified")
        L = _r(g_verified["L"])
        if L != _r(case["L"]) or g_verified["verification_binding_sha256"] != _fingerprint(p, L):
            raise ValueError("Verified G evidence is not bound to this original input/L")
        w, returned_t = _v(w_certificate, p["n"]), _r(t)
        checks = _witness_checks(p, w)
        box_lower = [lo - value for lo, value in zip(p["ell"], w)]
        box_upper = [value - hi for value, hi in zip(w, p["u"])]
        displacement = [value - saved for value, saved in zip(w, p["w_saved"])]
        distance_rows = [{"coordinate": i, "positive_residual": delta - returned_t * scale,
                          "negative_residual": -delta - returned_t * scale}
                         for i, (delta, scale) in enumerate(zip(displacement, p["D"]))]
        distance = max(abs(delta) / scale for delta, scale in zip(displacement, p["D"]))
        gates = {
            "exact_equalities": checks["exact_equalities_pass"],
            "exact_original_inequalities": checks["exact_original_inequalities_pass"],
            "literal_binary64_band": checks["literal_binary64_band_pass"],
            "box": all(value <= 0 for value in box_lower + box_upper),
            "all_distance_sides": all(row["positive_residual"] <= 0 and row["negative_residual"] <= 0 for row in distance_rows),
            "t_nonnegative": returned_t >= 0,
        }
        value = _objective(p, w)
        evidence = {**checks, "box_lower_residuals": box_lower, "box_upper_residuals": box_upper,
                    "distance_constraints": distance_rows, "returned_t": returned_t,
                    "verified_scaled_linf_distance": distance, "distance_optimality_proved": False,
                    "gates": gates, "evaluated_witness_objective": value,
                    "saved_candidate_objective_minus_L_diagnostic": _objective(p, p["w_saved"]) - L,
                    "L": L, "objective_units": "actual weighted original Stage-B QP; no lambda conversion"}
        if not all(gates.values()):
            return {**failed, **evidence, "failures": [key for key, passed in gates.items() if not passed]}
        if value < L:
            return {**failed, **evidence, "status": "CERTIFICATE_INCONSISTENCY",
                    "signed_U_minus_L": value - L, "failures": ["Exact feasible witness objective is below verified lower bound"]}
        return {**evidence, "status": "CERTIFIED_PRIMAL_WITNESS", "certified": True,
                "U": value, "certified_interval": [L, value], "certified_gap_bound": value - L,
                "w_certificate": w, "failures": [],
                "interpretation": "New exact primal certificate only; does not change any F/G candidate, solver status or historical null field."}
    except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError, OverflowError) as exc:
        return {**failed, "failures": [str(exc)]}


def binary64_export(case, w_certificate) -> dict:
    """Round each exact coordinate once; retain a separate usability diagnostic.

    Root additionally calls the unchanged frozen numeric validator on this
    returned list. This function does not repair an unacceptable export.
    """
    try:
        p = _problem(case)
        w = _v(w_certificate, p["n"])
        exported = [float(value) for value in w]
        if not all(math.isfinite(value) for value in exported):
            raise ValueError("Nonfinite binary64 export")
        exact_export = [Fraction.from_float(value) for value in exported]
        checks = _witness_checks(p, exact_export)
        return {"status": "BINARY64_EXPORT_DIAGNOSTIC_ONLY", "w_binary64": exported,
                "binary64_hex": [value.hex() for value in exported],
                "exact_binary64_values": exact_export,
                "signed_export_rounding": [new - old for new, old in zip(exact_export, w)],
                **checks, "frozen_numeric_validator_not_run_here": True,
                "rational_certificate_unchanged": True, "clipping_or_projection": False}
    except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError, OverflowError) as exc:
        return {"status": "BINARY64_EXPORT_NOT_ACCEPTABLE", "failures": [str(exc)],
                "w_binary64": None, "rational_certificate_unchanged": True}
