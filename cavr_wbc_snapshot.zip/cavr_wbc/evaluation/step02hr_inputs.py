"""HR-specific sources/environment/output ownership; frozen readers are read-only."""
from pathlib import Path
import hashlib
import importlib.metadata
import json
import os
import subprocess
import sys
from datetime import datetime,timezone

from cavr_wbc.evaluation.step02h_inputs import (
    compact, rational_decode, exact_hash, write_compact, binary_exact, require,
    read_json, read_jsonl, sha256, verify_hash,
)

ROOT=Path(__file__).resolve().parents[2]
SOURCE=ROOT.parent/'cavr_step02h_exact_primal_certificate_20260918'
OUT=ROOT/'artifacts/step02hr_nonnegative_adapter'
HF=ROOT/'artifacts/step02h_exact_primal_certificate'
GF=ROOT/'artifacts/step02g_saved_certificate_audit'
FF=ROOT/'artifacts/step02f_coordinate_equivalence'
BASE='8c1f16b46ba23b58d42b102909e9c0554b88416e'
VERSION='STEP02HR_STANDARD_FORM_V1'
CONFIG_SHA='fd14b1fe8a4a6ba689d73ca94e128095c1d8726ecac6438eadd1bc1587c96a6b'
PRIOR_LEDGER_SHA='93e1ad54348c3383342c01341fe9c8492f304eda17a9a6815e2b229d769cc4e4'
PROTOCOL_SOURCE=ROOT.parent/'step02h_scientific_audit_20260918'
PROTOCOLS={'NEXT_CODEX_INSTRUCTIONS_STEP02HR.md':'905264a565de4e36dc76effe7a1f01ca97d51a504497ba23a51485ccf5ea9a22',
           'STEP02H_SCIENTIFIC_REVIEW.md':'09d0158f51fd6311698a2591c7e4330799b28960f44216c0a72f1f2123fb2c91'}
PYTHON=SOURCE/'.venv-step02h/Scripts/python.exe'


def utc():return datetime.now(timezone.utc).isoformat()


def git(root,*args):
    return subprocess.check_output(['git','-c','core.quotepath=false','-C',str(root),*args]).decode('utf-8').strip()


def load_case(ordinal,source_root=ROOT):
    """Bind the old pure reader explicitly to HR's byte-checked frozen F/G copies.

    No H prepare/environment/manifest/output helper or experiment entry is run.
    The reused load_case function only reads F/G/config and returns values.
    """
    import cavr_wbc.evaluation.step02h_inputs as frozen
    require(Path(source_root).resolve()==ROOT==frozen.ROOT and frozen.FF==FF and frozen.GF==GF,
            'Frozen reader root is not the explicit HR source root')
    result=frozen.load_case(ordinal)
    case=result[0]
    old=HF/f'auxiliary_lp_inputs/saved_{ordinal:02d}/original_input.json'
    item=read_json(HF/'CASE_MANIFEST.json')['cases'][ordinal-1]
    verify_hash(old,item['input_file_sha256'])
    require(exact_hash(case)==item['exact_input_hash']==exact_hash(rational_decode(read_json(old))),
            'HR input differs from saved H original case')
    return result


def fixtures():
    plan=rational_decode(read_json(HF/'SYNTHETIC_PLAN.json'))['fixtures']
    require(len(plan)==4,'Original four fixture coverage')
    rows=[]
    for index,fixture in enumerate(plan,1):
        row=dict(fixture)
        row.update(prior_identity=fixture['identity'],identity=VERSION+'.'+fixture['identity'],
                   original_input_hash=exact_hash(fixture['case']))
        # Changing execution identity never changes any physical fixture field.
        if index<=2:
            request=read_json(HF/f"auxiliary_lp_inputs/fixture_{fixture['identity']}/worker_request.json")
            require(row['original_input_hash']==request['token']['input_hash'],'Prior fixture input mismatch')
        rows.append(row)
    return rows


def source_manifest():
    require(git(SOURCE,'rev-parse','HEAD')==BASE and git(SOURCE,'status','--porcelain=v1')=='','H source must stay clean at frozen commit')
    require(git(ROOT,'rev-parse','HEAD')==BASE and git(ROOT,'diff','--name-only')=='','HR initial tracked baseline changed')
    names=git(SOURCE,'ls-tree','-r','--name-only',BASE).splitlines()
    source,checkout,differences={},{},[]
    allowed={'cavr_wbc/evaluation/.gitattributes','cavr_wbc/experiments/.gitattributes','tests/.gitattributes'}
    for name in names:
        source[name]=sha256(SOURCE/name);checkout[name]=sha256(ROOT/name)
        if source[name]!=checkout[name]:
            a=(SOURCE/name).read_bytes();b=(ROOT/name).read_bytes()
            require(name in allowed and a.replace(b'\r\n',b'\n')==b.replace(b'\r\n',b'\n'),'Unexpected baseline byte difference '+name)
            differences.append({'file':name,'source_sha256':source[name],'checkout_sha256':checkout[name],
                                'reason':'Git checkout newline conversion only; neither old attributes file edited; semantic rules unchanged'})
    for rel,digest in read_json(HF/'artifact_hashes.json')['files'].items():verify_hash(ROOT/rel,digest)
    for rel,digest in read_json(HF/'SYNTHETIC_PLAN.json')['files'].items():verify_hash(ROOT/rel,digest)
    old_manifest=read_json(HF/'SOURCE_MANIFEST.json')
    for name,digest in old_manifest['tracked_files_sha256'].items():verify_hash(SOURCE/name,digest)
    verify_hash(HF/'recovery_call_ledger.jsonl',PRIOR_LEDGER_SHA)
    verify_hash(FF/'config.yaml',CONFIG_SHA)
    result=read_json(HF/'STEP02H_RESULT.json')
    require(result['status']=='PREPARATION_FAILED' and result['recovery_status_counts']=={'NOT RUN':20},'Historical H result changed')
    require(result['call_accounting']['total_actual_call_count']==2 and result['call_accounting']['categories']['saved_record']['actual_call_count']==0,'Historical H call count changed')
    protocols=[]
    for name,digest in PROTOCOLS.items():
        verify_hash(PROTOCOL_SOURCE/name,digest);verify_hash(OUT/'protocol'/name,digest)
        protocols.append({'source':str(PROTOCOL_SOURCE/name),'copy':str(OUT/'protocol'/name),'sha256':digest})
    legacy={'G':str(ROOT.parent/'cavr_step02g_saved_certificate_audit_20260918'),
            'F':old_manifest['legacy_worktree'],'C':old_manifest['original_workspace']}
    states={name:{'path':path,'head':git(path,'rev-parse','HEAD'),'status':git(path,'status','--porcelain=v1')} for name,path in legacy.items()}
    old_files={}
    for rel,digest in old_manifest['original_untracked_sha256'].items():
        path=Path(old_manifest['original_workspace'])/rel;verify_hash(path,digest);old_files[str(path)]=digest
    return {'utc':utc(),'source_worktree':str(SOURCE),'source_commit':BASE,'source_status':'','worktree':str(ROOT),
            'tracked_file_count':len(names),'source_files':source,'checkout_files':checkout,'checkout_newline_provenance':differences,
            'protocols':protocols,'legacy_states':states,'original_untracked_files':old_files,'config_sha256':CONFIG_SHA,
            'prior_ledger_sha256':PRIOR_LEDGER_SHA,'history_validation':{'H_artifact_hashes':91,'H_implementation_hashes':18,'H_source_hashes':835}}


def verify_sources():
    m=read_json(OUT/'SOURCE_MANIFEST.json')
    for name,digest in m['source_files'].items():verify_hash(SOURCE/name,digest)
    for name,digest in m['checkout_files'].items():verify_hash(ROOT/name,digest)
    require(git(SOURCE,'rev-parse','HEAD')==BASE and git(SOURCE,'status','--porcelain=v1')=='','Historical H changed')
    for state in m['legacy_states'].values():
        require(git(state['path'],'rev-parse','HEAD')==state['head'] and git(state['path'],'status','--porcelain=v1')==state['status'],'Legacy worktree changed')
    for name,digest in m['original_untracked_files'].items():verify_hash(name,digest)
    for row in m['protocols']:verify_hash(row['source'],row['sha256']);verify_hash(row['copy'],row['sha256'])
    return {'utc':utc(),'source_and_checkout_files_checked':len(m['source_files']),'historical_workspaces_unchanged':True,'old_files_edited':False}


def environment_lock():
    import sympy.solvers.simplex as simplex
    old=read_json(HF/'ENVIRONMENT_LOCK.json')
    require(Path(sys.executable).resolve()==PYTHON.resolve() and Path(sys.prefix).resolve()==(SOURCE/'.venv-step02h').resolve(),'Only locked H environment read-only is selected')
    require(sys.dont_write_bytecode and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1','Historical bytecode writes must be disabled')
    require(Path(os.environ.get('TEMP','')).resolve().is_relative_to(ROOT) and Path(os.environ.get('TMP','')).resolve().is_relative_to(ROOT),'Temporary paths must be HR-local')
    versions={d.metadata['Name']:d.version for d in importlib.metadata.distributions()}
    require(versions==old['installed_versions'],'Installed dependency versions changed')
    verify_hash(simplex.__file__,old['simplex_source_sha256'])
    require(sys.version==old['python'],'Locked Python changed')
    return {'selection':'READ_ONLY_FROZEN_H_ENVIRONMENT','executable':str(PYTHON),'prefix':sys.prefix,'python':sys.version,
            'installed_versions':versions,'simplex_source_path':simplex.__file__,'simplex_source_sha256':old['simplex_source_sha256'],
            'wheel_artifacts':old['wheel_artifacts'],'source_H_lock_sha256':sha256(HF/'ENVIRONMENT_LOCK.json'),
            'dont_write_bytecode':True,'temporary_root':str(ROOT/'.step02hr-local'),'no_new_installation':True,
            'backend':'sympy.solvers.simplex.linprog','backend_version':'1.14.0','bounds_argument':'OMITTED','A_eq_b_eq':'OMITTED'}


def check_environment():
    require(environment_lock()==read_json(OUT/'ENVIRONMENT_LOCK.json'),'Frozen HR environment changed')
