"""STEP02HR durable budgets and the proof-bound nonnegative LP entry.

Imports and pure validation never construct an optimizer or dispatch an LP.
Historical H is read-only. A reservation is permanently consumed, including
after an unknown outcome; this module never retries or reclaims stale locks.
"""
from __future__ import annotations

from contextlib import ExitStack, contextmanager
from contextvars import ContextVar
from datetime import datetime, timezone
from fractions import Fraction
from functools import wraps
import hashlib
import importlib
import json
import os
from pathlib import Path
import re
import sys
import threading
import time
from unittest.mock import patch
import uuid

ROOT = Path(__file__).resolve().parents[2]
STAGE = "STEP02HR_STANDARD_FORM_V1"
BUDGETS = {"saved_record": 20, "synthetic_fixture": 4}
TOTAL_LIMIT = 24
HISTORICAL_H_LEDGER = Path("E:/CAVR-WBC/cavr_step02h_exact_primal_certificate_20260918/artifacts/step02h_exact_primal_certificate/recovery_call_ledger.jsonl")
HISTORICAL_H_LEDGER_SHA256 = "93e1ad54348c3383342c01341fe9c8492f304eda17a9a6815e2b229d769cc4e4"
SYMPY_SIMPLEX_SHA256 = "a5e46fe38683337d14ff4c24f3166fdede8cfdca66fdaf610402e2cabef39dd6"
FIXTURE_IDS = ("h_fixture_01_half_distance", "h_fixture_02_negative_bounds",
               "h_fixture_03_thin_band_active_normal", "h_fixture_04_literal_intersection_infeasible")
_ACTIVE = ContextVar("step02hr_active_boundary", default=None)
_PERMISSION = ContextVar("step02hr_linprog_permission", default=None)
_DIGEST = re.compile(r"[0-9a-f]{64}\Z")
_NOTES = {"WORKER_START", "ELIMINATION_START", "ELIMINATION_FINISH", "LP_INPUT_SAVED",
          "STANDARD_FORM_START", "STANDARD_FORM_VERIFIED", "STANDARD_FORM_INPUT_SAVED", "PROGRESS"}


class LedgerError(ValueError):
    """Corrupt, ambiguous or duplicate persisted attempt; fail closed."""


class BudgetExceeded(LedgerError):
    pass


class OptimizerBoundaryError(BaseException):
    """Not swallowed by historical controller ``except Exception`` clauses."""


def _utc():
    return datetime.now(timezone.utc).isoformat()


def _json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _digest(value):
    return hashlib.sha256(_json(value).encode("utf-8")).hexdigest()


def _sha(value, label):
    if not isinstance(value, str) or not _DIGEST.fullmatch(value):
        raise LedgerError(label + " must be lowercase SHA256")


def _chain(data):
    if not data or not data.endswith(b"\n"):
        raise LedgerError("Empty/truncated ledger; no reservation reconstruction or retry")
    try:
        rows = [json.loads(line) for line in data.splitlines()]
    except (ValueError, UnicodeDecodeError) as exc:
        raise LedgerError("Malformed ledger") from exc
    previous = "0" * 64
    for sequence, row in enumerate(rows, 1):
        if not isinstance(row, dict):
            raise LedgerError("Ledger event must be an object")
        payload = {key: value for key, value in row.items() if key != "event_sha256"}
        if row.get("sequence") != sequence or row.get("previous_sha256") != previous or row.get("event_sha256") != _digest(payload):
            raise LedgerError("Ledger sequence/hash chain mismatch")
        previous = row["event_sha256"]
    return rows


def prior_call_accounting():
    """Read and verify H's two completed receipts, without touching H files."""
    data = HISTORICAL_H_LEDGER.read_bytes()
    if hashlib.sha256(data).hexdigest() != HISTORICAL_H_LEDGER_SHA256:
        raise LedgerError("Historical H ledger changed")
    rows = _chain(data)
    reservations = [row for row in rows if row["event"] == "RESERVED"]
    if len(reservations) != 2 or len(rows) != 14:
        raise LedgerError("Historical H event/reservation count changed")
    for index, reserved in enumerate(reservations):
        token = reserved["token"]
        if token["category"] != "synthetic_fixture" or token["identity"] != FIXTURE_IDS[index]:
            raise LedgerError("Historical H identities changed")
        same = [row for row in rows if row["token"]["reservation_id"] == token["reservation_id"]]
        if any(row["token"] != token for row in same):
            raise LedgerError("Historical H immutable token mismatch")
        started = [row for row in same if row["event"] == "LINPROG_STARTED"]
        terminal = [row for row in same if row["event"] == "FINISHED"]
        if len(started) != 1 or len(terminal) != 1 or same[-1] != terminal[0]:
            raise LedgerError("Historical H attempt is not known and terminal")
        receipt = terminal[0]["metadata"].get("receipt", {})
        if receipt.get("top_level_entries") != 1 or receipt.get("internal_simplex_entries") != 1:
            raise LedgerError("Historical H confirmed entry counts changed")
        if any(receipt.get(key) != token[key] for key in token):
            raise LedgerError("Historical H receipt/token mismatch")
    return {"stage": STAGE, "historical_h_ledger": str(HISTORICAL_H_LEDGER),
            "historical_h_ledger_sha256": HISTORICAL_H_LEDGER_SHA256,
            "historical_h_event_count": 14, "historical_synthetic_confirmed_calls": 2,
            "historical_saved_record_confirmed_calls": 0, "historical_unknown_calls": 0,
            "new_limits": dict(BUDGETS), "new_total_limit": TOTAL_LIMIT,
            "h_plus_hr_authorized_synthetic_limit": 6, "historical_synthetic_cap": 16,
            "remaining_historical_synthetic_capacity_authorized": False,
            "original_stage_a_b_calls": 0, "e1_authorized": False}


def _identity(category, identity):
    if category not in BUDGETS:
        raise LedgerError("Unknown budget category")
    if category == "saved_record":
        if type(identity) is not int or not 1 <= identity <= 20:
            raise LedgerError("Saved identity must be original integer ordinal 1..20")
    elif identity not in tuple(STAGE + "." + item for item in FIXTURE_IDS):
        raise LedgerError("Only the four declared versioned fixture identities are authorized")


class Ledger:
    """Append/fsync hash chain, portable immutable tokens, fail-closed locking."""

    def __init__(self, path):
        self.path = Path(path).resolve()
        # Only new HR artifact and HR-local synthetic test files are writable.
        allowed = (ROOT / "artifacts/step02hr_nonnegative_adapter", ROOT / ".step02hr-local")
        if not any(self.path.is_relative_to(directory) and self.path != directory for directory in allowed):
            raise LedgerError("HR ledger must be in its new artifact or HR-local test directory")
        self.prior = prior_call_accounting()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.lock_path = self.path.with_name(self.path.name + ".lock")
        with self._lock():
            if not self.path.exists():
                self._append([], "GENESIS", None, self.prior)
            self._read()

    @contextmanager
    def _lock(self):
        try:
            fd = os.open(self.lock_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        except FileExistsError as exc:
            raise LedgerError("Ledger lock exists: concurrent/interrupted operation; no automatic retry") from exc
        try:
            with os.fdopen(fd, "wb") as stream:
                stream.write((_json({"pid": os.getpid(), "created_utc": _utc()}) + "\n").encode("utf-8"))
                stream.flush()
                os.fsync(stream.fileno())
            yield
        finally:
            self.lock_path.unlink()

    def _read(self):
        if hashlib.sha256(HISTORICAL_H_LEDGER.read_bytes()).hexdigest() != HISTORICAL_H_LEDGER_SHA256:
            raise LedgerError("Historical H ledger changed after initialization")
        rows = _chain(self.path.read_bytes())
        if rows[0].get("event") != "GENESIS" or rows[0].get("token") is not None or rows[0].get("metadata") != self.prior:
            raise LedgerError("HR genesis does not bind the verified historical accounting")
        states, identities = {}, set()
        for row in rows[1:]:
            token = row.get("token")
            self._validate_token_shape(token)
            key = token["reservation_id"]
            if row.get("event") == "RESERVED":
                identity = (token["category"], token["identity"])
                if key in states or identity in identities:
                    raise LedgerError("Duplicate reservation or identity")
                identities.add(identity)
                states[key] = {"token": token, "started": False, "finished": False, "start_metadata": None}
                continue
            if key not in states or states[key]["token"] != token:
                raise LedgerError("Event has no matching immutable reservation")
            state = states[key]
            if state["finished"]:
                raise LedgerError("Event follows terminal outcome")
            if row["event"] == "LINPROG_STARTED":
                if state["started"]:
                    raise LedgerError("Repeated top-level dispatch")
                _sha(row["metadata"].get("lp_input_hash"), "LP input hash")
                _sha(row["metadata"].get("standard_proof_hash"), "Standard proof hash")
                state["started"] = True
                state["start_metadata"] = row["metadata"]
            elif row["event"] == "FINISHED":
                if not isinstance(row["metadata"].get("status"), str) or not row["metadata"]["status"].strip():
                    raise LedgerError("Terminal outcome requires a status")
                receipt = row["metadata"].get("receipt")
                if receipt is not None:
                    if not isinstance(receipt, dict) or not state["started"]:
                        raise LedgerError("Backend receipt requires a preceding durable dispatch")
                    if any(receipt.get(name) != value for name, value in token.items()):
                        raise LedgerError("Backend receipt immutable token mismatch")
                    for name in ("lp_input_hash", "standard_proof_hash"):
                        if receipt.get(name) != state["start_metadata"][name]:
                            raise LedgerError("Backend receipt differs from bound dispatch inputs/proof")
                    for name in ("top_level_entries", "internal_simplex_entries", "pivot_calls", "handle_bounds_entries"):
                        if type(receipt.get(name)) is not int or receipt[name] < 0:
                            raise LedgerError("Backend receipt counters must be nonnegative exact integers")
                    if receipt["top_level_entries"] > 1 or receipt["internal_simplex_entries"] > 1:
                        raise LedgerError("Backend receipt violates single-entry authorization")
                state["finished"] = True
            elif row["event"] not in _NOTES:
                raise LedgerError("Unknown ledger event")
        if len(states) > TOTAL_LIMIT:
            raise LedgerError("Persisted total budget exceeded")
        for category, limit in BUDGETS.items():
            if sum(state["token"]["category"] == category for state in states.values()) > limit:
                raise LedgerError("Persisted category budget exceeded")
        return rows

    @staticmethod
    def _validate_token_shape(token):
        keys = {"stage", "historical_h_ledger_sha256", "reservation_id", "category", "identity", "input_hash", "case_id", "path"}
        if not isinstance(token, dict) or set(token) != keys:
            raise LedgerError("Invalid reservation token shape")
        if token["stage"] != STAGE or token["historical_h_ledger_sha256"] != HISTORICAL_H_LEDGER_SHA256:
            raise LedgerError("Reservation stage/history mismatch")
        _identity(token["category"], token["identity"])
        _sha(token["input_hash"], "Original input hash")
        if not isinstance(token["reservation_id"], str) or not re.fullmatch(r"[0-9a-f]{32}", token["reservation_id"]):
            raise LedgerError("Invalid reservation ID")
        if not isinstance(token["case_id"], str) or not token["case_id"].strip():
            raise LedgerError("Original case identity required")
        if token["category"] == "synthetic_fixture":
            if token["identity"] != STAGE + "." + token["case_id"] or token["path"] != "synthetic_fixture":
                raise LedgerError("Versioned fixture must bind its unchanged original case/path")
        elif token["path"] not in ("production", "reference"):
            raise LedgerError("Saved path must be production or reference")

    def _append(self, rows, event, token, metadata):
        row = {"sequence": len(rows) + 1, "previous_sha256": rows[-1]["event_sha256"] if rows else "0" * 64,
               "event": event, "token": token, "utc": _utc(), "pid": os.getpid(), "metadata": metadata}
        row["event_sha256"] = _digest(row)
        with self.path.open("ab") as stream:
            stream.write((_json(row) + "\n").encode("utf-8"))
            stream.flush()
            os.fsync(stream.fileno())
        return row

    def reserve(self, category, identity, input_hash, *, case_id, path):
        token = {"stage": STAGE, "historical_h_ledger_sha256": HISTORICAL_H_LEDGER_SHA256,
                 "reservation_id": uuid.uuid4().hex, "category": category, "identity": identity,
                 "input_hash": input_hash, "case_id": case_id, "path": path}
        self._validate_token_shape(token)
        with self._lock():
            rows = self._read()
            reserved = [row for row in rows if row["event"] == "RESERVED"]
            if any(row["token"]["category"] == category and row["token"]["identity"] == identity for row in reserved):
                raise LedgerError("Identity already reserved: failures and unknown outcomes never retry")
            if len(reserved) >= TOTAL_LIMIT or sum(row["token"]["category"] == category for row in reserved) >= BUDGETS[category]:
                raise BudgetExceeded("Persistent HR reservation budget exhausted")
            self._append(rows, "RESERVED", token, {"category_limit": BUDGETS[category], "total_limit": TOTAL_LIMIT})
        return token

    def _matching(self, rows, token):
        self._validate_token_shape(token)
        matching = [row for row in rows if row["token"] is not None and row["token"]["reservation_id"] == token["reservation_id"]]
        if not matching or any(row["token"] != token for row in matching):
            raise LedgerError("Reservation does not match this ledger")
        return matching

    def start(self, token, lp_input_hash, standard_proof_hash):
        _sha(lp_input_hash, "LP input hash")
        _sha(standard_proof_hash, "Standard proof hash")
        with self._lock():
            rows = self._read()
            if any(row["event"] in ("LINPROG_STARTED", "FINISHED") for row in self._matching(rows, token)):
                raise LedgerError("Reservation already attempted/finished; no second dispatch")
            return self._append(rows, "LINPROG_STARTED", token, {"lp_input_hash": lp_input_hash,
                "standard_proof_hash": standard_proof_hash,
                "count_interpretation": "durable dispatch intent before backend; interruption can leave actual entry unknown"})

    def note(self, token, event, **metadata):
        if event not in _NOTES:
            raise LedgerError("Reserved transition requires its dedicated method")
        with self._lock():
            rows = self._read()
            if any(row["event"] == "FINISHED" for row in self._matching(rows, token)):
                raise LedgerError("Progress after terminal outcome")
            return self._append(rows, event, token, metadata)

    def finish(self, token, status, **metadata):
        if not isinstance(status, str) or not status.strip():
            raise LedgerError("Terminal status required")
        with self._lock():
            rows = self._read()
            existing = [row for row in self._matching(rows, token) if row["event"] == "FINISHED"]
            if existing:
                return existing[0]
            return self._append(rows, "FINISHED", token, {**metadata, "status": status})

    def events(self):
        with self._lock():
            return self._read()

    def is_finished(self, token):
        return any(row["event"] == "FINISHED" for row in self._matching(self.events(), token))

    def snapshot(self):
        with self._lock():
            rows = self._read()
            ledger_hash = hashlib.sha256(self.path.read_bytes()).hexdigest()
        categories, attempts = {}, []
        for category, limit in BUDGETS.items():
            selected = [row for row in rows if row["token"] is not None and row["token"]["category"] == category]
            categories[category] = {"limit": limit, "reserved": sum(row["event"] == "RESERVED" for row in selected),
                "linprog_started": sum(row["event"] == "LINPROG_STARTED" for row in selected),
                "finished": sum(row["event"] == "FINISHED" for row in selected), "confirmed_calls": 0, "unknown_call_upper_bound": 0}
        for row in rows:
            if row["event"] != "RESERVED":
                continue
            matching = self._matching(rows, row["token"])
            started = any(item["event"] == "LINPROG_STARTED" for item in matching)
            terminal = next((item for item in matching if item["event"] == "FINISHED"), None)
            receipt = terminal["metadata"].get("receipt") if terminal else None
            known = isinstance(receipt, dict) and receipt.get("top_level_entries") in (0, 1)
            count = receipt["top_level_entries"] if known else 0
            unknown = int(started and not known)
            category = categories[row["token"]["category"]]
            category["confirmed_calls"] += count
            category["unknown_call_upper_bound"] += unknown
            attempts.append({"token": row["token"], "linprog_started": started,
                "status": terminal["metadata"]["status"] if terminal else "ATTEMPT_OUTCOME_UNKNOWN",
                "terminal": terminal is not None, "confirmed_calls": count, "unknown_call_upper_bound": unknown,
                "retry_allowed": False})
        confirmed = sum(value["confirmed_calls"] for value in categories.values())
        unknown = sum(value["unknown_call_upper_bound"] for value in categories.values())
        return {"stage": STAGE, "prior": self.prior, "categories": categories, "attempts": attempts,
                "event_count": len(rows), "total_reserved": sum(value["reserved"] for value in categories.values()),
                "total_linprog_started": sum(value["linprog_started"] for value in categories.values()),
                "new_confirmed_calls": confirmed, "new_calls_lower_bound": confirmed, "new_calls_upper_bound": confirmed + unknown,
                "h_plus_hr_calls_lower_bound": 2 + confirmed, "h_plus_hr_calls_upper_bound": 2 + confirmed + unknown,
                "h_plus_hr_synthetic_calls_lower_bound": 2 + categories["synthetic_fixture"]["confirmed_calls"],
                "h_plus_hr_synthetic_calls_upper_bound": 2 + categories["synthetic_fixture"]["confirmed_calls"] + categories["synthetic_fixture"]["unknown_call_upper_bound"],
                "ledger_sha256": ledger_hash}


def _exact_payload(value, sympy):
    """Exact backend leaves only; return Fraction views without approximation."""
    if type(value) is int:
        return Fraction(value)
    if isinstance(value, sympy.Rational):
        return Fraction(int(value.p), int(value.q))
    if isinstance(value, (list, tuple)):
        return [_exact_payload(item, sympy) for item in value]
    raise OptimizerBoundaryError("LP leaves must already be exact int/SymPy Integer/Rational; implicit conversion forbidden")


class _Boundary:
    def __init__(self, log, original, sympy):
        self.guard_log = self.log = log
        self._original, self._sympy = original, sympy
        self._owner = threading.get_ident()

    def _reject(self, label):
        self.log["blocked_attempts"].append({"entrypoint": label, "utc": _utc(), "intercepted_before_dispatch": True})
        raise OptimizerBoundaryError(label)

    def linprog(self, ledger, token, c, *, A, b, old_lp, standard_form, proof, physical_input, **forbidden):
        if forbidden:
            self._reject("Forbidden backend keyword(s): " + ",".join(sorted(forbidden)))
        if _ACTIVE.get() is not self or threading.get_ident() != self._owner or _PERMISSION.get() is not None:
            self._reject("Whitelist requires its active owner-thread boundary")
        if not isinstance(ledger, Ledger):
            self._reject("Whitelist requires the persistent HR Ledger")
        from cavr_wbc.evaluation.step02hr_standard_verify import exact_hash, verify_bound_proof
        try:
            valid = verify_bound_proof(proof, old_lp, standard_form, physical_input)
        except (ValueError, KeyError, TypeError, OverflowError) as exc:
            self._reject("Independent standard-form proof validation raised: " + str(exc))
        if not valid or proof["version"] != STAGE:
            self._reject("Independent standard-form proof rejected")
        ledger._validate_token_shape(token)
        binding = proof["binding"]
        if proof["physical_input_hash"] != token["input_hash"] or exact_hash(physical_input) != token["input_hash"]:
            self._reject("Physical input/reservation hash mismatch")
        if any(binding[key] != token[key] for key in ("case_id", "path")):
            self._reject("Proof/reservation case/path mismatch")
        expected_ordinal = token["identity"] if token["category"] == "saved_record" else FIXTURE_IDS.index(token["case_id"]) + 1
        if binding["solve_ordinal"] != expected_ordinal:
            self._reject("Proof/reservation original ordinal mismatch")
        try:
            payload = {"c": _exact_payload(c, self._sympy), "A": _exact_payload(A, self._sympy), "b": _exact_payload(b, self._sympy)}
        except OptimizerBoundaryError:
            self._reject("Inexact or unsupported backend input container/leaf")
        if any(payload[key] != standard_form["new_lp"][key] for key in payload):
            self._reject("Actual backend arguments differ from independently proved standard form")
        lp_hash, proof_hash = exact_hash(payload), proof["proof_sha256"]
        ledger.start(token, lp_hash, proof_hash)
        receipt = {**token, "lp_input_hash": lp_hash, "standard_proof_hash": proof_hash,
                   "standard_hash": proof["standard_hash"], "old_lp_hash": proof["old_lp_hash"],
                   "top_level_entries": 0, "internal_simplex_entries": 0, "pivot_calls": 0, "handle_bounds_entries": 0}
        self.log["allowed_calls"].append(receipt)
        permission = _PERMISSION.set(receipt)
        started = time.perf_counter()
        try:
            # This exact signature is the entire authorized backend contract.
            result = self._original(c, A=A, b=b)
            if receipt["top_level_entries"] != 1 or receipt["internal_simplex_entries"] != 1:
                self._reject("Backend entry receipt is not exactly one linprog and one internal simplex")
            _exact_payload(result, self._sympy)
        except BaseException as exc:
            ledger.finish(token, "BACKEND_EXCEPTION", exception_type=type(exc).__name__, exception_message=str(exc),
                          elapsed_seconds=time.perf_counter() - started, receipt=receipt)
            raise
        else:
            ledger.finish(token, "BACKEND_RETURNED", elapsed_seconds=time.perf_counter() - started, receipt=receipt)
            return result
        finally:
            _PERMISSION.reset(permission)


@contextmanager
def auxiliary_optimizer_guard():
    """Definition-only guard; no constructor, algorithm or LP is executed.

    Loaded exports are replaced and cached Python aliases are intercepted by
    a chained profile hook. This is a checked runtime boundary, not a hostile
    native-code sandbox. The unmodified G guard protects old optimizer routes.
    """
    active = _ACTIVE.get()
    if active is not None:
        if active._owner != threading.get_ident():
            raise OptimizerBoundaryError("HR boundary is owner-thread only")
        active.log["nested_entries"] += 1
        yield active
        return
    from cavr_wbc.evaluation.step02g_no_solve import optimizer_guard
    with optimizer_guard() as original_guard, ExitStack() as stack:
        if not original_guard["guard_installed"] or original_guard["patch_failures"]:
            raise OptimizerBoundaryError("Original optimizer guard incomplete")
        sympy = importlib.import_module("sympy")
        simplex = importlib.import_module("sympy.solvers.simplex")
        scipy = importlib.import_module("scipy.optimize")
        if sympy.__version__ != "1.14.0" or hashlib.sha256(Path(simplex.__file__).read_bytes()).hexdigest() != SYMPY_SIMPLEX_SHA256:
            raise OptimizerBoundaryError("Frozen SymPy version/source changed")
        log = {"stage": STAGE, "guard_installed": False, "guard_restored": False, "original_guard": original_guard,
            "actual_original_stage_a_b_calls": 0, "actual_original_optimizer_constructions": 0,
            "allowed_calls": [], "blocked_attempts": [], "patched_entrypoints": [], "nested_entries": 0,
            "backend": "sympy.solvers.simplex.linprog", "backend_version": sympy.__version__,
            "simplex_source_sha256": SYMPY_SIMPLEX_SHA256, "bounds_argument_permitted": False}
        originals = {name: getattr(simplex, name) for name in ("linprog", "lpmin", "lpmax", "_lp", "_simplex", "_handle_bounds")}
        originals.update({"scipy." + name: getattr(scipy, name) for name in ("linprog", "minimize", "milp")})
        boundary = _Boundary(log, originals["linprog"], sympy)
        denied_codes = {func.__code__: name for name, func in originals.items() if name not in ("linprog", "_simplex") and hasattr(func, "__code__")}

        def reject(label):
            boundary._reject("Non-whitelisted optimizer entry: " + label)

        def replacement(name, original):
            @wraps(original)
            def invoke(*args, **kwargs):
                if name == "_simplex" and _PERMISSION.get() is not None and _ACTIVE.get() is boundary and threading.get_ident() == boundary._owner:
                    return original(*args, **kwargs)
                reject(name)
            return invoke

        replacements = {name: replacement(name, func) for name, func in originals.items()}
        for module_name, module in tuple(sys.modules.items()):
            namespace = getattr(module, "__dict__", None)
            if not isinstance(namespace, dict):
                continue
            for attribute, value in tuple(namespace.items()):
                for name, original in originals.items():
                    if value is original:
                        stack.enter_context(patch.object(module, attribute, replacements[name]))
                        log["patched_entrypoints"].append(module_name + "." + attribute)
                        break
        old_profile, old_thread_profile = sys.getprofile(), threading.getprofile()

        def profile(frame, event, arg):
            if event == "call":
                code, permission = frame.f_code, _PERMISSION.get()
                if code in denied_codes:
                    if code is originals["_handle_bounds"].__code__ and permission is not None:
                        permission["handle_bounds_entries"] += 1
                    reject("cached:" + denied_codes[code])
                if code is originals["linprog"].__code__:
                    if permission is None or _ACTIVE.get() is not boundary or threading.get_ident() != boundary._owner:
                        reject("cached:linprog")
                    permission["top_level_entries"] += 1
                    if permission["top_level_entries"] != 1:
                        reject("repeated:linprog")
                if code is originals["_simplex"].__code__:
                    if permission is None or _ACTIVE.get() is not boundary or permission["top_level_entries"] != 1 or threading.get_ident() != boundary._owner:
                        reject("cached:_simplex")
                    permission["internal_simplex_entries"] += 1
                    if permission["internal_simplex_entries"] != 1:
                        reject("repeated:_simplex")
                if code is simplex._pivot.__code__ and permission is not None:
                    permission["pivot_calls"] += 1
            if old_profile is not None:
                old_profile(frame, event, arg)

        context_token = _ACTIVE.set(boundary)
        sys.setprofile(profile)
        threading.setprofile(profile)
        log["guard_installed"] = True
        try:
            yield boundary
        finally:
            sys.setprofile(old_profile)
            threading.setprofile(old_thread_profile)
            _ACTIVE.reset(context_token)
            log["guard_restored"] = True


def run_guard_selftests():
    """Separate fresh negative probes; zero LPs and no task ledger access.

    The runner calls this after its pure-test outer guard has exited. Every
    attempted prohibited entry must raise before its original body runs.
    Cached aliases receive their required arguments so the profile hook, not
    Python's missing-argument rejection, is the tested interception layer.
    """
    from cavr_wbc.evaluation import step02g_no_solve as historical
    if _ACTIVE.get() is not None or historical._ACTIVE_GUARD.get() is not None:
        raise ValueError("Negative guard probes require fresh nonnested contexts")
    routes = [("sympy.solvers.simplex", name) for name in ("linprog", "lpmin", "lpmax", "_lp", "_simplex", "_handle_bounds")]
    routes += [("scipy.optimize", name) for name in ("linprog", "minimize", "milp")]
    routes += [("clarabel", "DefaultSolver"), ("clarabel.clarabel", "DefaultSolver"),
               ("osqp", "OSQP"), ("osqp.interface", "OSQP"), ("osqp.ext_builtin", "OSQPSolver")]
    plan = [{"module": module, "attribute": attribute, "kind": "direct_export"} for module, attribute in routes]
    for module_name, class_name in historical._WRAPPERS:
        cls = getattr(importlib.import_module(module_name), class_name)
        methods = sorted(name for name in vars(cls) if name == "_solve" or name.startswith("solve_"))
        if "_solve" not in methods:
            raise AssertionError("Frozen original wrapper schema changed")
        plan.extend({"module": module_name, "class": class_name, "attribute": name, "kind": "frozen_wrapper"} for name in methods)
    wrapper_count = sum(item["kind"] == "frozen_wrapper" for item in plan)
    if wrapper_count != 19:
        raise AssertionError("Expected exactly 19 inspected original wrapper entrypoints")
    for module_name, attribute, args in (
        ("sympy.solvers.simplex", "linprog", ([0],)),
        ("sympy.solvers.simplex", "_simplex", (None, None, None)),
        ("sympy.solvers.simplex", "_handle_bounds", (None,)),
        ("scipy.optimize", "linprog", ([0],)),
    ):
        plan.append({"module": module_name, "attribute": attribute, "kind": "cached_python_function",
                     "cached": getattr(importlib.import_module(module_name), attribute), "args": args})
    outcomes = []
    for item in plan:
        label = item["module"] + "." + (item.get("class", "") + "." if "class" in item else "") + item["attribute"]
        caught = None
        with auxiliary_optimizer_guard() as boundary:
            log, old = boundary.log, boundary.log["original_guard"]
            if log["nested_entries"] or log["allowed_calls"] or log["blocked_attempts"] or old["blocked_attempts"]:
                raise AssertionError("Negative probe did not get a fresh clean context")
            module = importlib.import_module(item["module"])
            owner = getattr(module, item["class"]) if "class" in item else module
            entry = item["cached"] if "cached" in item else getattr(owner, item["attribute"])
            try:
                entry(*item.get("args", ()))
            except (OptimizerBoundaryError, historical.ZeroSolveBoundaryError) as exc:
                caught = {"type": type(exc).__name__, "message": str(exc)}
            blocked = list(log["blocked_attempts"]) + list(old["blocked_attempts"])
            if caught is None or len(blocked) != 1:
                raise AssertionError("Expected one fail-fast boundary rejection: " + label)
            if log["allowed_calls"] or old["actual_constructions"] or old["actual_solve_calls"]:
                raise AssertionError("Negative probe entered an optimizer")
            if not all(row.get("intercepted_before_dispatch", row.get("intercepted_before_backend_dispatch", False)) for row in blocked):
                raise AssertionError("Negative probe not intercepted before dispatch")
        if not log["guard_restored"] or not old["guard_restored"]:
            raise AssertionError("Negative probe did not restore its fresh context")
        outcomes.append({"entrypoint": label, "probe_kind": item["kind"], "status": "DENIED_BEFORE_BACKEND_DISPATCH",
                         "expected_exception": caught, "deliberate_test_blocked_attempts": blocked,
                         "allowed_auxiliary_calls": 0, "actual_original_constructions": 0,
                         "actual_original_solve_calls": 0, "guard_restored": True,
                         "patched_HR_entrypoints": log["patched_entrypoints"], "patched_original_entrypoints": old["patched_entrypoints"]})
    return {"status": "PASS", "scope": "Deliberate negative probes, not LP fixtures",
            "fresh_contexts": len(outcomes), "negative_probes": outcomes, "frozen_wrapper_routes_checked": wrapper_count,
            "actual_optimizer_constructions": 0, "actual_optimization_solve_calls": 0,
            "allowed_auxiliary_lp_calls": 0, "task_call_ledger_accessed": False,
            "all_denied_before_backend_dispatch": True}
