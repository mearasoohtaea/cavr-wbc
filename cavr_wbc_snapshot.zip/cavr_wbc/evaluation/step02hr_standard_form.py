"""Pure exact translation of the frozen H recovery LP to nonnegative form.

This module neither imports nor invokes an optimizer.  Independent proof and
original-space validation remain mandatory before and after the sole budgeted
H-R backend entry, respectively.  All old rows, including box lower bounds and
t nonnegativity, are retained in their original order.
"""

from copy import deepcopy
from fractions import Fraction
import hashlib
import json


VERSION = "STEP02HR_STANDARD_FORM_V1"
ZERO = Fraction(0)
ONE = Fraction(1)


def _fraction(value):
    if isinstance(value, Fraction):
        return value
    if type(value) is int:
        return Fraction(value)
    raise ValueError("EXACT_RATIONAL_REQUIRED:" + type(value).__name__)


def _vector(values, length=None):
    result = [_fraction(value) for value in values]
    if length is not None and len(result) != length:
        raise ValueError("VECTOR_DIMENSION_MISMATCH")
    return result


def _matrix(values, columns):
    return [_vector(row, columns) for row in values]


def _dot(left, right):
    if len(left) != len(right):
        raise ValueError("DOT_DIMENSION_MISMATCH")
    return sum((a * b for a, b in zip(left, right)), ZERO)


def canonical_payload(value):
    """Canonical hash encoding; fractions never pass through binary64."""
    if isinstance(value, Fraction):
        return {"numerator": str(value.numerator), "denominator": str(value.denominator)}
    if isinstance(value, dict):
        if not all(isinstance(key, str) for key in value):
            raise ValueError("CANONICAL_HASH_REQUIRES_STRING_KEYS")
        return {key: canonical_payload(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [canonical_payload(item) for item in value]
    if value is None or type(value) in (str, int, bool):
        return value
    raise ValueError("NONEXACT_OR_UNSUPPORTED_HASH_VALUE:" + type(value).__name__)


def exact_hash(value):
    encoded = json.dumps(canonical_payload(value), sort_keys=True, ensure_ascii=False,
                         separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def adapt_standard_form(h_lp) -> dict:
    """Translate z=l+v uniformly, keeping t unchanged and every H row.

    ``h_lp`` is the unmodified output of the historical pure Fraction builder.
    The solver payload is ``new_lp`` (and top-level c/A/b aliases).  It has no
    bounds/equality-argument keys: its entire coordinate domain is nonnegative.
    The nested old LP retains its bounds as historical proof input only.
    """
    old_lp = deepcopy(h_lp)
    # Hashing also rejects hidden float metadata rather than approximating it.
    old_lp_hash = exact_hash(old_lp)
    free = list(old_lp["free"])
    nf = len(free)
    p = _vector(old_lp["p"])
    n = len(p)
    if any(type(index) is not int for index in free) or free != sorted(set(free)):
        raise ValueError("FREE_COLUMNS_NOT_DISTINCT_ORIGINAL_ORDER")
    if n <= 0 or any(index < 0 or index >= n for index in free):
        raise ValueError("PHYSICAL_OR_FREE_DIMENSION_INVALID")
    N = _matrix(old_lp["N"], nf)
    if len(N) != n:
        raise ValueError("AFFINE_MAP_DIMENSION_MISMATCH")
    if any(N[index] != [ONE if j == k else ZERO for j in range(nf)]
           or p[index] != ZERO for k, index in enumerate(free)):
        raise ValueError("FREE_COORDINATES_NOT_ORIGINAL_VARIABLES")
    c = _vector(old_lp["c"], nf + 1)
    if c != [ZERO] * nf + [ONE]:
        raise ValueError("FROZEN_DISTANCE_OBJECTIVE_CHANGED")
    old_A = _matrix(old_lp["A"], nf + 1)
    old_b = _vector(old_lp["b"], len(old_A))
    bounds = list(old_lp["bounds"])
    if len(bounds) != nf + 1 or any(len(pair) != 2 for pair in bounds):
        raise ValueError("OLD_BOUND_DIMENSION_MISMATCH")
    if _fraction(bounds[-1][0]) != ZERO or bounds[-1][1] is not None:
        raise ValueError("T_DOMAIN_NOT_UNSHIFTED_NONNEGATIVE")
    l = [_fraction(pair[0]) for pair in bounds[:-1]]
    u = [_fraction(pair[1]) for pair in bounds[:-1]]
    if any(lo > hi for lo, hi in zip(l, u)):
        raise ValueError("EMPTY_FREE_BOUND_INTERVAL")
    physical = old_lp["original_inputs"]
    ell, upper = (_vector(physical[name], n) for name in ("ell", "u"))
    if l != [ell[index] for index in free] or u != [upper[index] for index in free]:
        raise ValueError("FREE_BOUNDS_NOT_ORIGINAL_PROVEN_BOX")
    labels = deepcopy(old_lp["row_labels"])
    sources = deepcopy(old_lp["row_sources"])
    m = len(old_A)
    if len(labels) != m or len(sources) != m or any(not isinstance(label, str) for label in labels):
        raise ValueError("OLD_ROW_METADATA_DIMENSION_MISMATCH")
    if len(set(labels)) != m:
        raise ValueError("OLD_ROW_LABEL_DUPLICATION")
    if n == 42 and (nf, m) != (12, 249):
        raise ValueError("REAL_H_LP_NOT_249_BY_13")
    s = l + [ZERO]
    constant_shift = _dot(c, s)
    if constant_shift != ZERO:
        raise ValueError("NONZERO_AUXILIARY_OBJECTIVE_SHIFT")
    A = deepcopy(old_A)
    b = [rhs - _dot(row, s) for row, rhs in zip(old_A, old_b)]
    row_map = [{"new_row": i, "old_row": i, "kind": "retained_shifted_row",
                "label": labels[i]} for i in range(m)]
    for j, (lo, hi) in enumerate(zip(l, u)):
        label = f"free_upper[{j}]"
        if label in labels:
            raise ValueError("APPENDED_LABEL_COLLIDES_WITH_OLD_ROW")
        A.append([ONE if column == j else ZERO for column in range(nf + 1)])
        b.append(hi - lo)
        labels.append(label)
        sources.append({"row": m + j, "label": label, "group": "translated_free_upper",
                        "free_index": j, "physical_coordinate": free[j], "side": "upper"})
        row_map.append({"new_row": m + j, "old_row": None, "kind": "translated_free_upper",
                        "free_index": j, "physical_coordinate": free[j], "label": label})
    p_standard = [value + _dot(row, l) for value, row in zip(p, N)]
    variable_order = [f"v[{j}]" for j in range(nf)] + ["t"]
    new_lp = {"c": c, "A": A, "b": b, "row_labels": labels, "row_sources": sources,
              "variable_order": variable_order, "domain": "all_variables_nonnegative",
              "objective_constant": constant_shift, "bounds_argument_absent": True}
    return {"version": VERSION, "status": "STANDARD_FORM_CONSTRUCTED_NOT_SOLVED",
            "old_lp": old_lp, "new_lp": new_lp, "c": c, "A": A, "b": b,
            "l": l, "u": u, "s": s, "p_standard": p_standard, "N": N,
            "row_labels": labels, "row_sources": sources, "row_map": row_map,
            "variable_order": variable_order, "free": free,
            "objective_constant_shift": constant_shift,
            "old_lp_hash": old_lp_hash, "standard_hash": exact_hash(new_lp),
            "dimensions": {"physical_variables": n, "free_variables": nf,
                           "lp_variables": nf + 1, "old_rows": m, "new_rows": m + nf},
            "new_lp_calls": 0, "requires_independent_equivalence_proof": True}


def inverse_map(standard, v, t):
    """Return p+Nl+Nv exactly once, without clipping or post-recovery repair.

    Domain and all original constraints are independently verified by the
    caller.  This algebraic inverse is defined even for a rejected exact point.
    """
    p_standard = _vector(standard["p_standard"])
    free_values = _vector(v, len(standard["l"]))
    _fraction(t)
    N = _matrix(standard["N"], len(free_values))
    if len(N) != len(p_standard):
        raise ValueError("AFFINE_MAP_DIMENSION_MISMATCH")
    return [constant + _dot(row, free_values) for constant, row in zip(p_standard, N)]
