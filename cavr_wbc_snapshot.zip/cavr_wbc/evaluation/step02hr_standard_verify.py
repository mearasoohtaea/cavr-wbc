"""Independent exact proof checker for STEP02HR's nonnegative translation.

Only standard-library Fraction algebra is used. No adapter, H constructor,
eliminator or optimizer is imported; construction flags are never evidence.
"""

from __future__ import annotations

from fractions import Fraction
import hashlib
import json
from numbers import Integral


VERSION = "STEP02HR_STANDARD_FORM_V1"
ZERO = Fraction(0)
ONE = Fraction(1)
PHYSICAL_FIELDS = ("P", "q", "E", "d", "G", "h", "c_original", "w_saved", "D",
                   "ell", "u", "task_matrix", "task_bias", "target", "task_scales", "epsilon")


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def _f(value):
    if isinstance(value, Fraction):
        return value
    if isinstance(value, Integral) and not isinstance(value, bool):
        return Fraction(int(value))
    if isinstance(value, dict) and set(value) == {"numerator", "denominator"}:
        numerator, denominator = value["numerator"], value["denominator"]
        _require(isinstance(numerator, str) and isinstance(denominator, str), "RATIONAL_INTEGER_STRINGS_REQUIRED")
        return Fraction(int(numerator), int(denominator))
    raise ValueError("EXACT_RATIONAL_REQUIRED:" + type(value).__name__)


def exact_payload(value):
    """Canonical persisted representation; binary/decimal floats are forbidden."""
    if isinstance(value, Fraction):
        return {"numerator": str(value.numerator), "denominator": str(value.denominator)}
    if isinstance(value, dict):
        _require(all(isinstance(key, str) for key in value), "STRING_DICTIONARY_KEYS_REQUIRED")
        return {key: exact_payload(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [exact_payload(item) for item in value]
    if value is None or isinstance(value, (str, bool)):
        return value
    if isinstance(value, Integral):
        return int(value)
    raise ValueError("UNSUPPORTED_OR_INEXACT_PAYLOAD:" + type(value).__name__)


def exact_hash(value):
    encoded = json.dumps(exact_payload(value), sort_keys=True, ensure_ascii=False,
                         separators=(",", ":"), allow_nan=False).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _v(values, size=None):
    _require(isinstance(values, (list, tuple)), "VECTOR_SEQUENCE_REQUIRED")
    result = [_f(value) for value in values]
    _require(size is None or len(result) == size, "VECTOR_DIMENSION_MISMATCH")
    return result


def _m(rows, columns, count=None):
    _require(isinstance(rows, (list, tuple)), "MATRIX_SEQUENCE_REQUIRED")
    result = [_v(row, columns) for row in rows]
    _require(count is None or len(result) == count, "MATRIX_ROW_COUNT_MISMATCH")
    return result


def _dot(left, right):
    _require(len(left) == len(right), "DOT_DIMENSION_MISMATCH")
    return sum((a * b for a, b in zip(left, right) if a and b), ZERO)


def _identity(n):
    return [[Fraction(i == j) for j in range(n)] for i in range(n)]


def _matmul(left, right, columns):
    return [[_dot(row, [values[j] for values in right]) for j in range(columns)] for row in left]


def _same(left, right, label):
    _require(exact_payload(left) == exact_payload(right), label)


def _canonical_label(label):
    _require(isinstance(label, str), "STRING_ROW_LABEL_REQUIRED")
    return label[3:] if label.startswith("p0_") else label[10:] if label.startswith("reference_") else label


def _physical(case):
    saved = _v(case["w_saved"])
    n = len(saved)
    _require(n > 0, "EMPTY_PHYSICAL_DIMENSION")
    P, q = _m(case["P"], n, n), _v(case["q"], n)
    E, G = _m(case["E"], n), _m(case["G"], n)
    d, h = _v(case["d"], len(E)), _v(case["h"], len(G))
    ell, upper, D = (_v(case[key], n) for key in ("ell", "u", "D"))
    _require(all(lo <= hi for lo, hi in zip(ell, upper)), "EMPTY_PHYSICAL_BOX")
    _require(all(value > 0 for value in D), "NONPOSITIVE_DISTANCE_SCALE")
    c0 = _f(case["c_original"])
    _require(c0 == 0, "ORIGINAL_OBJECTIVE_CONSTANT_NOT_ZERO")
    task = case["task_matrix"]
    width = len(task[0]) if task else n
    _require(0 < width <= n, "TASK_WIDTH_INVALID")
    task_original = _m(task, width)
    task = [row + [ZERO] * (n - width) for row in task_original]
    nt = len(task)
    bias, target, scales = (_v(case[key], nt) for key in ("task_bias", "target", "task_scales"))
    epsilon = _f(case["epsilon"])
    _require(epsilon > 0 and all(value > 0 for value in scales), "NONPOSITIVE_TASK_SCALE_OR_BAND")
    label_map = {}
    for kind, count in (("equality", len(E)), ("inequality", len(G))):
        labels = case.get(kind + "_labels", [f"synthetic_{kind}[{i}]" for i in range(count)])
        _require(len(labels) == count, "PHYSICAL_LABEL_COUNT_MISMATCH")
        canonical = [_canonical_label(label) for label in labels]
        _require(len(set(canonical)) == count, "DUPLICATE_PHYSICAL_LABEL")
        label_map[kind] = [{"row": i, "original": label, "canonical": canonical[i]} for i, label in enumerate(labels)]
    if n == 42 or case.get("expected_schema") is True:
        _require((n, len(E), len(G), nt) == (42, 30, 64, 8), "REAL_PHYSICAL_DIMENSIONS_MISMATCH")
        _require(epsilon == Fraction(3022314549036573, 1 << 78), "REAL_BINARY64_LITERAL_CHANGED")
    return {"P": P, "q": q, "E": E, "d": d, "G": G, "h": h, "c_original": c0,
            "w_saved": saved, "D": D, "ell": ell, "u": upper,
            "task_matrix": task_original, "task_bias": bias, "target": target,
            "task_scales": scales, "epsilon": epsilon}, task, label_map


def _elimination(old, physical):
    """Prove a full affine solution set from invertible elementary row steps."""
    E, d = physical["E"], physical["d"]
    n, m = len(physical["w_saved"]), len(E)
    evidence = old["elimination"]
    p, N = _v(old["p"], n), _m(old["N"], len(old["free"]), n)
    free, pivots = list(old["free"]), list(old["pivots"])
    _require(all(type(j) is int for j in free + pivots), "INTEGER_COLUMN_INDICES_REQUIRED")
    _require(free == sorted(set(free)) and pivots == sorted(set(pivots))
             and sorted(free + pivots) == list(range(n)), "FREE_PIVOT_PARTITION_INVALID")
    nf, rank = len(free), len(pivots)
    _require(rank <= m, "RANK_EXCEEDS_EQUALITY_ROWS")
    for key, expected in (("p", p), ("N", N), ("free", free), ("pivots", pivots)):
        _same(evidence[key], expected, "ELIMINATION_DUPLICATE_FIELD_MISMATCH:" + key)
    _require(evidence["rank"] == rank and evidence["free_dimension"] == nf, "ELIMINATION_DIMENSIONS_MISMATCH")
    T = _identity(m)
    for operation in evidence["row_operations"]:
        name = operation["operation"]
        if name == "swap":
            rows = operation["rows"]
            _require(len(rows) == 2 and all(type(i) is int and 0 <= i < m for i in rows), "BAD_SWAP_ROWS")
            i, j = rows
            T[i], T[j] = T[j], T[i]
        elif name == "scale":
            i, factor = operation["row"], _f(operation["factor"])
            _require(type(i) is int and 0 <= i < m and factor != 0, "NONINVERTIBLE_SCALE")
            T[i] = [factor * value for value in T[i]]
        elif name == "add_scaled_row":
            i, j, factor = operation["destination"], operation["source"], _f(operation["factor"])
            _require(type(i) is int and type(j) is int and 0 <= i < m and 0 <= j < m and i != j, "NONINVERTIBLE_ROW_ADDITION")
            T[i] = [value + factor * source for value, source in zip(T[i], T[j])]
        else:
            raise ValueError("UNKNOWN_ELEMENTARY_ROW_OPERATION")
    _require(T == _m(evidence["T"], m, m), "ELEMENTARY_TRANSFORM_MISMATCH")
    reduced = _matmul(T, E, n)
    rhs = [_dot(row, d) for row in T]
    _require(reduced == _m(evidence["rref_E"], n, m) and rhs == _v(evidence["rref_d"], m), "TRANSFORMED_EQUALITY_MISMATCH")
    expected_p, expected_N = [ZERO] * n, [[ZERO] * nf for _ in range(n)]
    for i, col in enumerate(pivots):
        _require(all(reduced[row][col] == Fraction(row == i) for row in range(m)), "PIVOT_COLUMNS_NOT_IDENTITY")
        _require(all(value == 0 for value in reduced[i][:col]), "PIVOT_NOT_FIRST_NONZERO")
        expected_p[col] = rhs[i]
        expected_N[col] = [-reduced[i][j] for j in free]
    _require(all(not any(row) and value == 0 for row, value in zip(reduced[rank:], rhs[rank:])), "NONZERO_UNPIVOTED_EQUALITY")
    for j, col in enumerate(free):
        expected_N[col][j] = ONE
    _require(p == expected_p and N == expected_N, "AFFINE_MAP_NOT_FULL_EQUALITY_SOLUTION_SET")
    _require([_dot(row, p) for row in E] == d and all(not any(row) for row in _matmul(E, N, nf)), "AFFINE_EQUALITY_IDENTITIES_FAILED")
    if n == 42:
        _require((rank, nf) == (30, 12), "REAL_AFFINE_DIMENSIONS_CHANGED")
    return p, N, free, {"invertible_elementary_steps": len(evidence["row_operations"]),
                       "rank": rank, "free_dimension": nf,
                       "inverse_free_coordinates": free,
                       "full_equality_solution_coverage": True}


def _physical_rows(physical, task, label_map):
    n = len(physical["w_saved"])
    rows, rhs, labels, sources = [], [], [], []

    def add(label, row, t, bound, source):
        rows.append(list(row) + [t]); rhs.append(bound); labels.append(label)
        sources.append({"row": len(rows) - 1, "label": label, **source})

    for i, (row, bound) in enumerate(zip(physical["G"], physical["h"])):
        entry = label_map["inequality"][i]
        add(entry["canonical"], row, ZERO, bound,
            {"group": "original_G", "original_row": i, "original_label": entry["original"]})
    for i in range(n):
        row = [Fraction(j == i) for j in range(n)]
        add(f"box_upper[{i}]", row, ZERO, physical["u"][i], {"group": "box", "coordinate": i, "side": "upper"})
        add(f"box_lower[{i}]", [-v for v in row], ZERO, -physical["ell"][i], {"group": "box", "coordinate": i, "side": "lower"})
    for i, row in enumerate(task):
        center = physical["target"][i] - physical["task_bias"][i]
        radius = physical["epsilon"] * physical["task_scales"][i]
        add(f"literal_task_upper[{i}]", row, ZERO, center + radius, {"group": "literal_binary64_contract", "task": i, "side": "upper"})
        add(f"literal_task_lower[{i}]", [-v for v in row], ZERO, -center + radius, {"group": "literal_binary64_contract", "task": i, "side": "lower"})
    for i in range(n):
        row = [Fraction(j == i) for j in range(n)]
        add(f"distance_upper[{i}]", row, -physical["D"][i], physical["w_saved"][i], {"group": "scaled_linf_distance", "coordinate": i, "side": "upper"})
        add(f"distance_lower[{i}]", [-v for v in row], -physical["D"][i], -physical["w_saved"][i], {"group": "scaled_linf_distance", "coordinate": i, "side": "lower"})
    add("t_nonnegative", [ZERO] * n, -ONE, ZERO, {"group": "t_nonnegative"})
    _require(len(labels) == len(set(labels)), "DUPLICATE_AUGMENTED_LABEL")
    return rows, rhs, labels, sources


def verify_standard_form(old_lp, standard_lp, physical_input) -> dict:
    """Return an independently checked, input-bound coefficient proof or reject.

    ``standard_lp`` is the complete adapter payload, including ``new_lp``.
    The runtime must call this checker (or ``verify_bound_proof``), rather than
    accepting a self-asserted success flag or a caller-generated hash alone.
    """
    failed = {"status": "STANDARD_FORM_INVALID", "verified": False, "proof_sha256": None}
    try:
        # Hash complete inputs first: even unused metadata cannot hide floats.
        old_hash, standard_payload_hash, physical_hash = map(exact_hash, (old_lp, standard_lp, physical_input))
        physical, task, label_map = _physical(physical_input)
        n, nt = len(physical["w_saved"]), len(task)
        for key in PHYSICAL_FIELDS:
            _same(old_lp["original_inputs"][key], physical[key], "ORIGINAL_PHYSICAL_INPUT_CHANGED:" + key)
        _same(old_lp["label_map"], label_map, "PHYSICAL_LABEL_MAPPING_CHANGED")
        for key in ("case_id", "path", "solve_ordinal"):
            _require(old_lp.get(key) == physical_input.get(key), "PHYSICAL_CASE_IDENTITY_CHANGED:" + key)
        p, N, free, elimination = _elimination(old_lp, physical)
        nf, nv = len(free), len(free) + 1
        original_A, original_b, labels, sources = _physical_rows(physical, task, label_map)
        nr = len(original_A)
        _require(nr == len(physical["G"]) + 4 * n + 2 * nt + 1, "PHYSICAL_ROW_COVERAGE_MISMATCH")
        _require(_m(old_lp["original_augmented_inequality_matrix"], n + 1, nr) == original_A
                 and _v(old_lp["original_augmented_inequality_rhs"], nr) == original_b, "ORIGINAL_AUGMENTED_ROWS_CHANGED")
        _same(old_lp["row_labels"], labels, "OLD_ROW_LABEL_ORDER_CHANGED")
        _same(old_lp["row_sources"], sources, "OLD_ROW_SOURCE_COVERAGE_CHANGED")
        expected_A = [[_dot(row[:-1], [N[i][j] for i in range(n)]) for j in range(nf)] + [row[-1]] for row in original_A]
        expected_b = [bound - _dot(row[:-1], p) for row, bound in zip(original_A, original_b)]
        old_dimensions = {"physical_variables": n, "equalities": len(physical["E"]),
                          "original_inequalities": len(physical["G"]), "tasks": nt,
                          "rank": n - nf, "free_variables": nf,
                          "lp_variables": nv, "lp_inequality_rows": nr}
        if "dimensions" in old_lp:
            _same(old_lp["dimensions"], old_dimensions, "OLD_DIMENSION_METADATA_CHANGED")
        if "row_group_counts" in old_lp:
            _same(old_lp["row_group_counts"], {"original_G": len(physical["G"]), "box": 2 * n,
                  "literal_binary64_contract": 2 * nt, "scaled_linf_distance": 2 * n,
                  "t_nonnegative": 1}, "OLD_GROUP_COVERAGE_CHANGED")
        if "task_matrix_full_width" in old_lp:
            _same(old_lp["task_matrix_full_width"], task, "OLD_FULL_TASK_OPERATOR_CHANGED")
        if "task_matrix_original_width" in old_lp:
            _require(old_lp["task_matrix_original_width"] == (len(physical["task_matrix"][0]) if nt else n), "OLD_TASK_WIDTH_CHANGED")
        A, b, c = _m(old_lp["A"], nv, nr), _v(old_lp["b"], nr), _v(old_lp["c"], nv)
        _require(A == expected_A and b == expected_b, "OLD_ELIMINATED_ROW_IDENTITIES_FAILED")
        _require(c == [ZERO] * nf + [ONE], "AUXILIARY_OBJECTIVE_IS_NOT_T_ONLY")
        _same(old_lp["variable_order"], [f"w[{i}]" for i in free] + ["t"], "OLD_VARIABLE_ORDER_CHANGED")
        for alias, expected in (("A_ub", A), ("b_ub", b)):
            _same(old_lp[alias], expected, "OLD_LP_ALIAS_CHANGED:" + alias)
        l, u = [physical["ell"][i] for i in free], [physical["u"][i] for i in free]
        bounds = old_lp["bounds"]
        _require(len(bounds) == nv and all(len(pair) == 2 for pair in bounds), "OLD_FREE_BOUNDS_DIMENSIONS_CHANGED")
        _require([(_f(pair[0]), _f(pair[1])) for pair in bounds[:-1]] == list(zip(l, u))
                 and _f(bounds[-1][0]) == 0 and bounds[-1][1] is None, "OLD_FREE_BOUNDS_CHANGED")
        s = l + [ZERO]
        new = standard_lp["new_lp"]
        _require(not any(key in obj for obj in (standard_lp, new) for key in ("bounds", "A_eq", "b_eq")), "FORBIDDEN_BACKEND_ARGUMENT")
        _same(standard_lp["old_lp"], old_lp, "EMBEDDED_OLD_LP_CHANGED")
        _require(standard_lp["old_lp_hash"] == old_hash, "OLD_LP_HASH_MISMATCH")
        new_hash = exact_hash(new)
        _require(standard_lp["standard_hash"] == new_hash, "STANDARD_LP_HASH_MISMATCH")
        _require(new["domain"] == "all_variables_nonnegative" and new["bounds_argument_absent"] is True, "DEFAULT_NONNEGATIVE_DOMAIN_REQUIRED")
        _require(_f(new["objective_constant"]) == _dot(c, s) == 0, "OBJECTIVE_CONSTANT_SHIFT_NOT_ZERO")
        if "objective_constant_shift" in standard_lp:
            _require(_f(standard_lp["objective_constant_shift"]) == 0, "OBJECTIVE_SHIFT_METADATA_CHANGED")
        if "version" in standard_lp:
            _require(standard_lp["version"] == VERSION, "STANDARD_VERSION_CHANGED")
        if "free" in standard_lp:
            _same(standard_lp["free"], free, "STANDARD_FREE_ORDER_CHANGED")
        if "dimensions" in standard_lp:
            _same(standard_lp["dimensions"], {"physical_variables": n, "free_variables": nf,
                  "lp_variables": nv, "old_rows": nr, "new_rows": nr + nf}, "STANDARD_DIMENSION_METADATA_CHANGED")
        for key, expected in (("l", l), ("u", u), ("s", s)):
            _require(_v(standard_lp[key], len(expected)) == expected, "TRANSLATION_VECTOR_CHANGED:" + key)
        new_A, new_b, new_c = _m(new["A"], nv, nr + nf), _v(new["b"], nr + nf), _v(new["c"], nv)
        _require(new_A[:nr] == A and new_b[:nr] == [value - _dot(row, s) for row, value in zip(A, b)], "STANDARD_ROW_COEFFICIENT_IDENTITY_FAILED")
        _require(new_c == c, "STANDARD_OBJECTIVE_CHANGED")
        upper_rows = [[Fraction(i == j) for i in range(nv)] for j in range(nf)]
        _require(new_A[nr:] == upper_rows and new_b[nr:] == [hi - lo for lo, hi in zip(l, u)], "TRANSLATED_UPPER_ROWS_CHANGED")
        upper_labels = [f"free_upper[{j}]" for j in range(nf)]
        upper_sources = [{"row": nr + j, "label": upper_labels[j], "group": "translated_free_upper",
                          "free_index": j, "physical_coordinate": free[j], "side": "upper"} for j in range(nf)]
        _same(new["row_labels"], labels + upper_labels, "STANDARD_LABEL_ORDER_CHANGED")
        _same(new["row_sources"], sources + upper_sources, "STANDARD_ROW_SOURCES_CHANGED")
        if "row_map" in standard_lp:
            row_map = [{"new_row": i, "old_row": i, "kind": "retained_shifted_row", "label": labels[i]} for i in range(nr)]
            row_map += [{"new_row": nr + j, "old_row": None, "kind": "translated_free_upper",
                         "free_index": j, "physical_coordinate": free[j], "label": upper_labels[j]} for j in range(nf)]
            _same(standard_lp["row_map"], row_map, "STANDARD_ROW_MAP_CHANGED")
        _same(new["variable_order"], [f"v[{j}]" for j in range(nf)] + ["t"], "STANDARD_VARIABLE_ORDER_CHANGED")
        for key in ("A", "b", "c", "row_labels", "row_sources", "variable_order"):
            _same(standard_lp[key], new[key], "STANDARD_DUPLICATE_FIELD_CHANGED:" + key)
        p_standard = [value + _dot(row, l) for value, row in zip(p, N)]
        _require(_v(standard_lp["p_standard"], n) == p_standard and _m(standard_lp["N"], nf, n) == N, "COMPOSED_PHYSICAL_MAP_CHANGED")
        _require([p_standard[i] for i in free] == l and [N[i] for i in free] == _identity(nf), "INVERSE_PHYSICAL_FREE_COVERAGE_FAILED")
        if n == 42:
            _require((nv, nr, len(new_A)) == (13, 249, 261), "REAL_STANDARD_DIMENSIONS_CHANGED")
        proof = {"status": "STANDARD_FORM_VERIFIED", "verified": True, "version": VERSION,
                 "old_lp_hash": old_hash, "standard_hash": new_hash,
                 "standard_payload_hash": standard_payload_hash, "physical_input_hash": physical_hash,
                 "binding": {key: physical_input.get(key) for key in ("case_id", "path", "solve_ordinal")},
                 "dimensions": {"physical_variables": n, "free_variables": nf, "lp_variables": nv,
                                "retained_rows": nr, "appended_upper_rows": nf, "standard_rows": nr + nf},
                 "l": l, "u": u, "s": s, "objective_constant_shift": ZERO,
                 "elimination_coverage": elimination,
                 "retained_row_proofs": [{"row": i, "label": label, "source": sources[i],
                                          "coefficients_equal": True, "rhs_translation": _dot(A[i], s),
                                          "residual_identity_for_all_coordinates": True} for i, label in enumerate(labels)],
                 "bounds_bijection": [{"free_index": j, "physical_coordinate": free[j], "lower": l[j],
                                        "upper": u[j], "translated_upper": u[j] - l[j],
                                        "forward": "z=l+v", "inverse": "v=z-l",
                                        "zero_width_row_retained": l[j] == u[j]} for j in range(nf)],
                 "composed_map": {"p_standard": p_standard, "N": N, "inverse_free_coordinates": free},
                 "all_original_auxiliary_feasible_points_covered": True,
                 "t_unshifted": True, "optimization_calls": 0, "failures": []}
        proof["proof_sha256"] = exact_hash(proof)
        return proof
    except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError, OverflowError) as exc:
        return {**failed, "failures": [str(exc)], "optimization_calls": 0}


def verify_bound_proof(proof, old_lp, standard_lp, physical_input) -> bool:
    """Recompute every identity, rejecting forged flags or stale proof hashes."""
    try:
        checked = verify_standard_form(old_lp, standard_lp, physical_input)
        return checked["verified"] and exact_payload(proof) == exact_payload(checked)
    except (ValueError, TypeError, KeyError):
        return False
