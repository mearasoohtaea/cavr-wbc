"""Scoped STEP02I frozen input transport and original-unit numerical gates.

Only saved F matrices, D cached Stage-A, and the frozen scientific configuration
are read. No historical experiment runner or exact-certificate module is used.
Binary64 coefficients cross the Julia boundary as raw uint64 hexadecimal bits.
"""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import struct
import subprocess
from types import SimpleNamespace

import numpy as np
import yaml


ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT.parent / "cavr_step02hr_nonnegative_adapter_20260918"
OUT = ROOT / "artifacts/step02i_bigfloat_full_panel"
FF = ROOT / "artifacts/step02f_coordinate_equivalence"
DD = ROOT / "artifacts/step02d_exact_band_equivalence"
BASE = "8def274247ec8ee68d78496e0237ca10d74173a8"
CONFIG_SHA = "fd14b1fe8a4a6ba689d73ca94e128095c1d8726ecac6438eadd1bc1587c96a6b"
PATHS = ("production", "reference")
METRIC_FIELDS = (
    "stage_a_normalized_task_output_inf_difference", "stage_a_task_objective_abs_difference",
    "stage_b_normalized_task_output_inf_difference", "stage_b_task_objective_abs_difference",
    "stage_b_torque_regularizer_abs_difference",
)
METRIC_GATES = dict(zip(METRIC_FIELDS, (1e-6, 1e-7, 1e-6, 1e-7, 1e-6)))
_CONTEXT = None


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def read_jsonl(path):
    with Path(path).open(encoding="utf-8") as stream:
        return [json.loads(line) for line in stream if line.strip()]


def json_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode("utf-8")).hexdigest()


def binary64_bits(value):
    if isinstance(value, np.ndarray):
        require(value.dtype == np.dtype("float64"), "Binary64 transport requires float64 ndarray")
        return binary64_bits(value.tolist())
    if isinstance(value, (list, tuple)):
        return [binary64_bits(item) for item in value]
    require(type(value) in (float, int) or isinstance(value, np.float64), "Unsupported binary64 input leaf")
    value = float(value)
    require(np.isfinite(value), "Nonfinite binary64 input")
    return struct.pack(">d", value).hex()


def decode_bits(value):
    if isinstance(value, list):
        return [decode_bits(item) for item in value]
    require(isinstance(value, str) and len(value) == 16 and all(c in "0123456789abcdef" for c in value), "Expected exact 16-character uint64 hexadecimal encoding")
    number = struct.unpack(">d", bytes.fromhex(value))[0]
    require(np.isfinite(number), "Nonfinite transported Float64")
    return number


def canonical_labels(labels, expected, path):
    result = []
    prefix = "p0_" if path == "production" else "reference_"
    for value in labels:
        label = str(value)
        if label.startswith(prefix):
            label = label[len(prefix):]
        require(not label.startswith(("p0_", "reference_")), "Wrong or repeated route prefix")
        result.append(label)
    require(result == expected and len(result) == len(set(result)), "Unknown, duplicated, or reordered frozen constraint labels")
    return result


def expected_labels():
    equality = [f"dynamics[{i}]" for i in range(18)] + [f"contact_acceleration[{i}]" for i in range(12)]
    inequality = [f"torque_{side}[{i}]" for i in range(12) for side in ("upper", "lower")]
    for foot in ("FL", "FR", "RL", "RR"):
        inequality += [f"friction[{foot},{i}]" for i in range(4)] + [f"normal_lower[{foot}]", f"normal_upper[{foot}]"]
    inequality += [f"fixed_task_{side}[{i}]" for i in range(8) for side in ("upper", "lower")]
    return equality, inequality


def _checked_problem(path, entry):
    resolved = (ROOT / entry["file"]).resolve()
    require(resolved.is_relative_to(FF.resolve()), "Represented NPZ is outside frozen F input directory")
    require(sha256(resolved) == entry["sha256"], "Represented NPZ hash mismatch")
    with np.load(resolved, allow_pickle=False) as data:
        problem = {key: data[key].copy() for key in data.files}
    for key, shape in {"original_P": (42, 42), "original_q": (42,), "original_E": (30, 42),
            "original_f": (30,), "original_G": (64, 42), "original_h": (64,), "D": (42,)}.items():
        array = problem[key]
        require(array.dtype == np.dtype("float64") and array.shape == shape and np.isfinite(array).all(), "Invalid saved physical array: " + key)
    require(np.all(problem["D"] > 0), "Nonpositive original D variable scale")
    P = problem["original_P"]
    require(np.array_equal(P, P.T) and np.array_equal(P, np.diag(np.diag(P))) and np.all(np.diag(P) >= 0), "Unexpected original objective structure")
    require(not np.any(problem["original_q"]), "Frozen Stage-B original q changed")
    expected_eq, expected_ineq = expected_labels()
    problem["canonical_equality_labels"] = canonical_labels(problem["equality_labels"], expected_eq, path)
    problem["canonical_inequality_labels"] = canonical_labels(problem["inequality_labels"], expected_ineq, path)
    return problem


def reconstruct_snapshot(problem, config, health_id):
    """Extract frozen validator inputs solely from original physical rows.

    Matches the established saved-array reconstruction convention without
    importing its adjacent G exact-certificate machinery or reading certificates.
    """
    E, f, G, h, D = (problem[name] for name in ("original_E", "original_f", "original_G", "original_h", "D"))
    labels = problem["canonical_inequality_labels"]
    index = {label: i for i, label in enumerate(labels)}
    J = E[18:, :18]
    require(np.array_equal(E[:18, 30:], -J.T) and not np.any(E[18:, 18:]), "Saved dynamics/contact structure mismatch")
    torque_scales = D[18:30]
    torque_bounds = np.zeros(12)
    for i in range(12):
        for side, sign in (("upper", 1.0), ("lower", -1.0)):
            row = np.zeros(42); row[18 + i] = sign
            require(np.array_equal(G[index[f"torque_{side}[{i}]"]], row), "Saved torque coefficient mismatch")
        torque_bounds[i] = h[index[f"torque_upper[{i}]"]]
        require(torque_bounds[i] == h[index[f"torque_lower[{i}]"]], "Asymmetric frozen torque bounds")
    rho = torque_bounds / torque_scales
    health = [row for row in config["health_panel"] if row["health_id"] == health_id]
    require(len(health) == 1, "Unknown health ID")
    expected_rho = np.ones(12)
    if health[0]["actuator"] is not None:
        expected_rho[config["_audited_actuator_names"].index(health[0]["actuator"])] = health[0]["rho"]
    require(np.array_equal(rho, expected_rho) and np.array_equal(rho * torque_scales, torque_bounds), "Named health and saved bounds differ")
    feet = tuple(config["physical_model"]["fixed_feet"])
    require(feet == ("FL", "FR", "RL", "RR"), "Frozen foot order changed")
    friction, normal = [], []
    for k, foot in enumerate(feet):
        start = 30 + 3 * k
        mu = -G[index[f"friction[{foot},0]"], start + 2]
        require(mu > 0, "Nonpositive friction coefficient")
        for face, (sx, sy) in enumerate(((1, 1), (1, -1), (-1, 1), (-1, -1))):
            row = np.zeros(42); row[start:start + 3] = [sx, sy, -mu]
            require(np.array_equal(G[index[f"friction[{foot},{face}]"]], row) and h[index[f"friction[{foot},{face}]"]] == 0, "Frozen four-face L1 friction mismatch")
        for side, sign in (("lower", -1), ("upper", 1)):
            row = np.zeros(42); row[start + 2] = sign
            require(np.array_equal(G[index[f"normal_{side}[{foot}]"]], row), "Frozen normal coefficient mismatch")
        require(h[index[f"normal_lower[{foot}]"]] == 0, "Normal lower bound changed")
        friction.append(mu); normal.append(h[index[f"normal_upper[{foot}]"]])
    task = []
    for j in range(8):
        upper, lower = (G[index[f"fixed_task_{side}[{j}]"]] for side in ("upper", "lower"))
        nz = np.flatnonzero(upper)
        require(len(nz) == 1 and nz[0] < 18 and upper[nz[0]] == 1 and np.array_equal(lower, -upper), "Task is not a signed qdd unit selector pair")
        task.append(upper[:18])
    task = np.asarray(task)
    require(len(set(np.argmax(task, axis=1))) == 8, "Task selectors duplicated")
    return SimpleNamespace(nv=18, nu=12, nlambda=12, decision_dimension=42, task_dimension=8,
        mass_matrix=E[:18, :18], bias_force=-f[:18], selection_matrix=-E[:18, 18:30],
        contact_jacobian=J, contact_acceleration_bias=-f[18:], torque_scales=torque_scales,
        friction_mu=np.asarray(friction), normal_force_upper=np.asarray(normal), foot_names=feet,
        task_matrix=task, task_bias=np.asarray(config["task_stack"]["c_at_primary_zero_velocity"], dtype=float),
        task_scales=np.asarray(config["task_stack"]["normalization_scales"], dtype=float),
        task_weights=np.asarray(config["task_stack"]["weight_diagonal"], dtype=float)), rho


def physical_pass(validation, config):
    mapping = {"dynamics_infinity_norm": "dynamics_infinity_norm", "contact_infinity_norm": "contact_infinity_norm",
        "hard_inequality_violation": "hard_inequality_violation", "health_adapter_identity_error": "health_adapter_identity"}
    return bool(validation.get("available") and all(np.isfinite(validation.get(key, np.inf))
        and validation[key] <= config["validation"][limit] for key, limit in mapping.items()))


def task_objective(task, desired, scales, weights):
    return float(np.sum(np.asarray(weights) * np.square((np.asarray(task) - np.asarray(desired)) / np.asarray(scales))))


def load_all():
    """Read the fixed panel and hash only the actual scientific inputs/code."""
    global _CONTEXT
    require(sha256(FF / "config.yaml") == CONFIG_SHA and sha256(DD / "config.yaml") == CONFIG_SHA, "Scientific config hash changed")
    config = yaml.safe_load((FF / "config.yaml").read_text(encoding="utf-8"))
    require(config["objectives"]["lambda_tau"] == 0.001
        and config["objectives"]["secondary_task_fix_normalized_tolerance"] == 1e-8
        and config["production_numerical_contract"]["internal_fixed_task_guard_fraction"] == 0.0
        and config["task_stack"]["c_at_primary_zero_velocity"] == [0.0] * 8, "Frozen objective/band/bias changed")
    for key, value in {"dynamics_infinity_norm": 1e-6, "contact_infinity_norm": 1e-6, "hard_inequality_violation": 1e-7,
                      "normalized_task_equivalence": 1e-6, "task_objective_difference": 1e-7,
                      "torque_regularizer_difference": 1e-6, "health_adapter_identity": 1e-9}.items():
        require(config["validation"][key] == value, "Frozen external gate changed: " + key)
    actuator_file = ROOT / "artifacts/step01b_platform_freeze/actuator_joint_map.json"
    entries = read_json(actuator_file)["entries"]
    require([row["actuator_index"] for row in entries] == list(range(12)), "Actuator map order changed")
    config["_audited_actuator_names"] = [row["actuator_name"] for row in entries]
    cases = read_json(FF / "case_manifest.json")["cases"]
    index = read_json(FF / "represented_problem_index.json")
    regressions = read_json(FF / "regression_case_ids.json")["cases"]
    ids = [row["case_id"] for row in cases]
    require(len(ids) == len(set(ids)) == 245 and set(index) == set(ids), "Fixed 245-case panel changed")
    require(len({row["snapshot_id"] for row in cases}) == 5 and len({row["health_id"] for row in cases}) == 7
            and len({row["demand_id"] for row in cases}) == 7, "Fixed 5x7x7 factors changed")
    require(len(regressions) == 36 and len({row["case_id"] for row in regressions}) == 36
            and all(row["case_id"] in ids for row in regressions), "Regression subset changed")
    files = [FF / name for name in ("case_manifest.json", "represented_problem_index.json", "regression_case_ids.json", "config.yaml")]
    files += [DD / "config.yaml", actuator_file]
    stage_a, stage_sources = {}, {}
    for path, filename, route in (("production", "p0_clarabel_diagnostics.jsonl", "p0_a"), ("reference", "reference_diagnostics.jsonl", "ref_a")):
        file = DD / filename; files.append(file)
        selected = [row for row in read_jsonl(file) if row["phase"] == "full_panel" and row["path"] == route]
        require(len(selected) == 245 and {row["case_id"] for row in selected} == set(ids), "Cached Stage-A panel linkage changed")
        for row in selected:
            require(row["success"] is True and row["status"] == "Solved" and physical_pass(row["validation"], config), "Cached Stage-A was not accepted")
            stage_a[(row["case_id"], path)] = row
            stage_sources[(row["case_id"], path)] = str(file.relative_to(ROOT)).replace("\\", "/")
    journal_file = DD / "full_panel_cases_journal.jsonl"; files.append(journal_file)
    old_rows = read_jsonl(journal_file)
    require(len(old_rows) == 245 and {row["case_id"] for row in old_rows} == set(ids), "D full-panel journal changed")
    failures = [row["case_id"] for row in old_rows if not row["case_pass"]]
    require(len(failures) == 24, "D failure subset is not frozen 24")
    for cid in ids:
        require(set(index[cid]) == set(PATHS), "Missing independent physical input path")
        for path in PATHS:
            entry = index[cid][path]
            filename = (ROOT / entry["file"]).resolve()
            require(filename.is_relative_to(FF.resolve()) and filename.suffix == ".npz" and sha256(filename) == entry["sha256"], "Frozen represented input hash changed")
            files.append(filename)
    # Only the original validator and its local imported model definitions are
    # scientific code dependencies; no G/H proof directories are traversed.
    for relative in ("cavr_wbc/control/scaled_fixed_support_qp.py", "cavr_wbc/control/fixed_support_qp.py",
                     "cavr_wbc/models/__init__.py", "cavr_wbc/models/actuator_health.py",
                     "cavr_wbc/models/actuator_mapping.py", "cavr_wbc/platforms/go2_mujoco.py"):
        file = ROOT / relative
        if file.exists(): files.append(file)
    sources = {}
    for file in files:
        relative = str(file.relative_to(ROOT)).replace("\\", "/")
        digest = sha256(file)
        require(sha256(SOURCE / relative) == digest, "Used source differs from frozen H-R copy: " + relative)
        sources[relative] = digest
    source_head = subprocess.check_output(["git", "-C", str(SOURCE), "rev-parse", "HEAD"], text=True).strip()
    require(source_head == BASE, "Direct source HEAD differs")
    manifest = {"source_worktree": str(SOURCE), "source_commit": BASE, "worktree": str(ROOT),
        "config_sha256": CONFIG_SHA, "files": sources, "represented_npz_count": 490,
        "case_count": 245, "cached_stage_a_count": 490, "stage_a_new_solves": 0,
        "scope": "Only actual frozen input/code/config, 490 NPZ, manifest, cached Stage-A and D subset journal. No G/H/H-R certificates traversed."}
    _CONTEXT = {"config": config, "cases": cases, "case_by_id": {row["case_id"]: row for row in cases},
        "index": index, "regression_case_ids": [row["case_id"] for row in regressions], "stage_a": stage_a,
        "stage_a_sources": stage_sources, "D_failure_case_ids": failures, "source_manifest": manifest,
        "case_order": {cid: i + 1 for i, cid in enumerate(ids)}}
    return _CONTEXT


def verify_sources(manifest):
    for relative, digest in manifest["files"].items():
        require(sha256(ROOT / relative) == digest and sha256(SOURCE / relative) == digest, "Frozen used source changed: " + relative)
    return {"used_files_checked": len(manifest["files"]), "inputs_unchanged": True, "certificate_tree_walk_performed": False}


def load_case_path(case_id, path, context=None):
    context = context if context is not None else _CONTEXT if _CONTEXT is not None else load_all()
    require(path in PATHS and case_id in context["case_by_id"], "Unknown case/path identity")
    case, config = context["case_by_id"][case_id], context["config"]
    problem = _checked_problem(path, context["index"][case_id][path])
    snapshot, rho = reconstruct_snapshot(problem, config, case["health_id"])
    cached = context["stage_a"][(case_id, path)]
    desired = np.asarray(next(row["y_d"] for row in config["task_demands"] if row["demand_id"] == case["demand_id"]), dtype=float)
    target = np.asarray(cached["task_output"], dtype=float)
    require(target.shape == (8,) and np.isfinite(target).all(), "Invalid cached Stage-A target")
    witness = [np.asarray(cached[key], dtype=float) for key in ("qdd", "tau", "contact_force")]
    require([array.shape for array in witness] == [(18,), (12,), (12,)] and all(np.isfinite(array).all() for array in witness), "Invalid cached Stage-A witness")
    from cavr_wbc.control.scaled_fixed_support_qp import validate_original_witness
    cached_validation = validate_original_witness(snapshot, rho, *witness)
    task = snapshot.task_matrix @ witness[0] + snapshot.task_bias
    require(np.array_equal(task, target) and physical_pass(cached_validation, config), "Cached Stage-A target/physical revalidation failed")
    if "a" in problem:
        require(np.array_equal(snapshot.task_matrix @ problem["a"][:18] + snapshot.task_bias, target), "F own-path saved target differs from D cache")
    task_rows = np.pad(snapshot.task_matrix, ((0, 0), (0, 24)))
    labels = problem["canonical_inequality_labels"]
    case_ordinal = context["case_order"][case_id]
    transport = {"schema": "STEP02I_BINARY64_BITS_V1", "identity": {"case_id": case_id, "path": path,
        "case_ordinal": case_ordinal, "solve_ordinal": 2 * (case_ordinal - 1) + PATHS.index(path) + 1}}
    for key, original in (("P", "original_P"), ("q", "original_q"), ("E", "original_E"), ("f", "original_f"),
                          ("G", "original_G"), ("h", "original_h"), ("D", "D")):
        transport[key] = binary64_bits(problem[original])
    transport.update(task_matrix=binary64_bits(task_rows), task_bias=binary64_bits(snapshot.task_bias),
        target=binary64_bits(target), task_scales=binary64_bits(snapshot.task_scales), task_weights=binary64_bits(snapshot.task_weights),
        desired_task=binary64_bits(desired), torque_scales=binary64_bits(snapshot.torque_scales),
        epsilon=binary64_bits(config["objectives"]["secondary_task_fix_normalized_tolerance"]), c_original=binary64_bits(0.0),
        equality_labels=[str(value) for value in problem["equality_labels"]], inequality_labels=[str(value) for value in problem["inequality_labels"]],
        canonical_equality_labels=problem["canonical_equality_labels"], canonical_inequality_labels=labels,
        task_upper_rows=[labels.index(f"fixed_task_upper[{j}]") for j in range(8)],
        task_lower_rows=[labels.index(f"fixed_task_lower[{j}]") for j in range(8)])
    info = {"case": case, "config": config, "snapshot": snapshot, "rho": rho, "target": target, "desired": desired,
        "task_scales": snapshot.task_scales, "task_weights": snapshot.task_weights,
        "cached_stage_a_validation": cached_validation, "cached_stage_a_pass": True,
        "cached_stage_a_task_objective": task_objective(target, desired, snapshot.task_scales, snapshot.task_weights),
        "stage_a_source": context["stage_a_sources"][(case_id, path)],
        "npz_source": context["index"][case_id][path], "input_hash": json_hash(transport),
        "case_ordinal": case_ordinal, "path": path}
    return transport, problem, cached, info


def validate_export(problem, cached, info, w, status, all_output_finite=True):
    """Validate Julia's one already-rounded export; never round/repair it again."""
    result = {"status": status, "status_accepted": status == "Solved", "raw_candidate_available": False,
        "raw_candidate_physical_pass": False, "raw_candidate_fixed_band_pass": False,
        "float64_export_accepted": False, "frozen_accepted_witness": False,
        "validation": {"available": False}, "task_output": None, "task_objective": None, "torque_regularizer": None,
        "all_output_finite": bool(all_output_finite), "cached_stage_a_pass": info["cached_stage_a_pass"]}
    if w is None:
        return result
    witness = np.asarray(w, dtype=float)
    require(witness.shape == (42,), "Julia Float64 export shape mismatch")
    if not np.isfinite(witness).all():
        result["all_output_finite"] = False
        return result
    from cavr_wbc.control.scaled_fixed_support_qp import validate_original_witness
    snapshot, config = info["snapshot"], info["config"]
    validation = validate_original_witness(snapshot, info["rho"], witness[:18], witness[18:30], witness[30:], fixed_task_output=info["target"])
    task = snapshot.task_matrix @ witness[:18] + snapshot.task_bias
    physical = physical_pass(validation, config)
    band = bool(np.isfinite(validation["fixed_task_normalized_infinity_error"]) and
                validation["fixed_task_normalized_infinity_error"] <= config["objectives"]["secondary_task_fix_normalized_tolerance"])
    result.update(raw_candidate_available=True, raw_candidate_physical_pass=physical, raw_candidate_fixed_band_pass=band,
        float64_export_accepted=bool(physical and band and all_output_finite),
        frozen_accepted_witness=bool(status == "Solved" and physical and band and all_output_finite),
        validation=validation, task_output=task.tolist(), task_objective=task_objective(task, info["desired"], snapshot.task_scales, snapshot.task_weights),
        torque_regularizer=float(np.sum(np.square(witness[18:30] / snapshot.torque_scales))), w_float64=witness.tolist())
    return result


def combine_case(case_id, production_result, reference_result, context=None):
    context = context if context is not None else _CONTEXT if _CONTEXT is not None else load_all()
    case, config = context["case_by_id"][case_id], context["config"]
    scales, weights = (np.asarray(config["task_stack"][key]) for key in ("normalization_scales", "weight_diagonal"))
    desired = np.asarray(next(row["y_d"] for row in config["task_demands"] if row["demand_id"] == case["demand_id"]))
    pa, ra = (context["stage_a"][(case_id, path)] for path in PATHS)
    metrics = {METRIC_FIELDS[0]: float(np.max(np.abs((np.asarray(pa["task_output"]) - ra["task_output"]) / scales))),
        METRIC_FIELDS[1]: abs(task_objective(pa["task_output"], desired, scales, weights) - task_objective(ra["task_output"], desired, scales, weights)),
        **{key: None for key in METRIC_FIELDS[2:]}}
    p, r = production_result, reference_result
    raw = {key: None for key in METRIC_FIELDS[2:]}
    if p.get("raw_candidate_available") and r.get("raw_candidate_available"):
        raw = {METRIC_FIELDS[2]: float(np.max(np.abs((np.asarray(p["task_output"]) - r["task_output"]) / scales))),
            METRIC_FIELDS[3]: abs(p["task_objective"] - r["task_objective"]),
            METRIC_FIELDS[4]: abs(p["torque_regularizer"] - r["torque_regularizer"])}
        if p.get("status_accepted") and r.get("status_accepted"):
            metrics.update(raw)
    gates = {key: value is not None and np.isfinite(value) and value <= METRIC_GATES[key] for key, value in metrics.items()}
    a_pass = bool(all(row["status"] == "Solved" and row["success"] and physical_pass(row["validation"], config) for row in (pa, ra))
                  and all(gates[key] for key in METRIC_FIELDS[:2]))
    hp = [row.get("high_precision_feasible") for row in (p, r)]
    hp_both = all(hp) if all(value is not None for value in hp) else None
    export_pass = all(row.get("float64_export_accepted", False) for row in (p, r))
    final = bool(a_pass and all(gates.values()) and all(row.get("frozen_accepted_witness", False) for row in (p, r)))
    def path_completed(row):
        if "completed" in row:
            return bool(row["completed"])
        return row.get("kind") != "infrastructure_error" and not row.get("status", "NOT RUN").startswith("NOT RUN")

    completed = all(path_completed(row) for row in (p, r))
    failures = []
    if completed:
        if not all(row.get("status_accepted", False) for row in (p, r)): failures.append("STATUS_FAILURE")
        if any(row.get("raw_candidate_available") and not row.get("raw_candidate_physical_pass") for row in (p, r)): failures.append("PHYSICAL_FAILURE")
        if any(row.get("raw_candidate_available") and not row.get("raw_candidate_fixed_band_pass") for row in (p, r)): failures.append("BAND_FAILURE")
        if any(row.get("high_precision_feasible") and not row.get("float64_export_accepted") for row in (p, r)): failures.append("FLOAT64_EXPORT_FAILURE")
        if not all(gates.values()): failures.append("EQUIVALENCE_FAILURE")
        if not a_pass: failures.append("CACHED_STAGE_A_FAILURE")
        if any("TIMEOUT" in row.get("status", "") for row in (p, r)): failures.append("TIMEOUT")
    else:
        failures.append("NOT_RUN")
        if any("RESOURCE_LIMIT" in row.get("status", "") or row.get("reason") == "RESOURCE_LIMIT" for row in (p, r)):
            failures.append("RESOURCE_LIMIT")
        if any(row.get("kind") == "infrastructure_error" or row.get("reason") == "IMPLEMENTATION_OR_INFRASTRUCTURE_ERROR" for row in (p, r)):
            failures.append("INFRASTRUCTURE_FAILURE")
    final = bool(final and completed)
    return {**case, "case_ordinal": context["case_order"][case_id], "completed": completed,
        "all_frozen_gate_metrics": metrics, "diagnostic_raw_stage_b_comparison": raw,
        "metric_pass": {key: bool(value) for key, value in gates.items()}, "equivalence_pass": bool(all(gates.values())),
        "metric_sources": {key: "STEP02D full_panel cached Stage-A" if key in METRIC_FIELDS[:2] else "STEP02I new Stage-B Float64 export" for key in METRIC_FIELDS},
        "cached_stage_a_pass": a_pass, "high_precision_feasible": hp_both, "float64_export_accepted": bool(export_pass),
        "final_case_pass": final, "failure_categories": failures,
        "regression_member": case_id in context["regression_case_ids"], "old_step02d_failure_member": case_id in context["D_failure_case_ids"],
        "paths": {path: {key: row.get(key) for key in ("status", "status_accepted", "raw_candidate_available", "raw_candidate_physical_pass", "raw_candidate_fixed_band_pass", "float64_export_accepted", "high_precision_feasible", "frozen_accepted_witness")}
                  for path, row in zip(PATHS, (p, r))}}
