"""No-solve STEP02I smoke reassessment; only the synthetic optimum gate changes.

High-precision result strings never pass through binary64. Binary64 *inputs*
are lifted exactly. Decimal serialization intervals check the coordinate map,
not an additional empirical tolerance on distance to the optimum.
"""
from decimal import Decimal, InvalidOperation, localcontext
import math
import struct


PRECISION = 120
ZERO = Decimal(0)
ONE = Decimal(1)


def _bits(value):
    if not isinstance(value, str) or len(value) != 16:
        raise ValueError("Expected 16-digit binary64 input")
    number = struct.unpack(">d", bytes.fromhex(value))[0]
    if not math.isfinite(number):
        raise ValueError("Nonfinite binary64 input")
    return Decimal.from_float(number)


def _decimal(value):
    if not isinstance(value, str):
        raise ValueError("High-precision numeric output must be a string")
    result = Decimal(value)
    if not result.is_finite():
        raise ValueError("Nonfinite high-precision output")
    return result


def _dot(left, right):
    if len(left) != len(right):
        raise ValueError("Vector dimension mismatch")
    return sum((a * b for a, b in zip(left, right)), ZERO)


def _maximum_abs(values):
    return max((abs(x) for x in values), default=ZERO)


def _positive_maximum(values):
    return max(ZERO, max(values, default=ZERO))


def _half_decimal_place(value):
    # A decimal printed at exponent e denotes a rounding interval +/- 10^e/2.
    # This comes from the serialized precision, not observed solver accuracy.
    return Decimal(5).scaleb(value.as_tuple().exponent - 1)


def assess(transport, output, atol="1e-20", rtol="1e-20"):
    """Return a JSON-safe reassessment without constructing/calling a solver.

    Malformed/incomplete/nonfinite output is rejected rather than repaired.
    The original physical thresholds are retained; only the old 1e-17
    synthetic coordinate-error gate is replaced by the protocol objective gate.
    """
    result = {
        "contract": "STEP02I_SMOKE_CONTRACT_V2", "decimal_precision": PRECISION,
        "identity": transport.get("identity"), "status": output.get("status"),
        "passed": False, "checks": {}, "metrics": {}, "reasons": [],
        "new_optimization_calls": 0,
        "coordinate_error_is_acceptance_gate": False,
        "mapping_budget_kind": "overlapping decimal serialization rounding intervals",
    }
    try:
        with localcontext() as context:
            context.prec = PRECISION
            if Decimal(atol) != Decimal("1e-20") or Decimal(rtol) != Decimal("1e-20"):
                raise ValueError("Frozen smoke objective tolerances changed")
            if transport["schema"] != "STEP02I_BINARY64_BITS_V1":
                raise ValueError("Unknown input schema")
            identity = transport["identity"]
            if identity != output["identity"] or identity["path"] != "smoke":
                raise ValueError("Input/output smoke identity mismatch")
            case = identity["case_id"]
            if case not in ("interior_optimum", "negative_active_thin_band"):
                raise ValueError("Unknown fixed analytic smoke")
            vectors = {k: list(map(_bits, transport[k])) for k in
                       ("q", "D", "f", "h", "task_bias", "target", "task_scales")}
            matrices = {k: [list(map(_bits, row)) for row in transport[k]]
                        for k in ("P", "E", "G", "task_matrix")}
            q, D, f, old_h = (vectors[k] for k in ("q", "D", "f", "h"))
            P, E, G, task = (matrices[k] for k in ("P", "E", "G", "task_matrix"))
            bias, target, scales = (vectors[k] for k in ("task_bias", "target", "task_scales"))
            epsilon, constant = _bits(transport["epsilon"]), _bits(transport["c_original"])
            first = case == "interior_optimum"
            center = ONE if first else Decimal("-1.5")
            v_star = Decimal(2) if first else Decimal("-.5")
            # These identities are the assumptions of the two analytic formulas.
            expected_q = [Decimal(-2), Decimal(-4)] if first else [Decimal(4), ONE]
            reference_valid = (
                P == [[Decimal(2), ZERO], [ZERO, Decimal(2)]] and q == expected_q
                and constant == ZERO and task == [[ONE, ZERO]]
                and bias == [ZERO] and target == [center] and scales == [ONE]
                and transport["epsilon"] == "3e45798ee2308c3a"
                and E == [[ZERO, ONE]] and f == [v_star]
                and D == ([Decimal(2), Decimal(4)] if first else [Decimal(2), ONE])
            )
            if not reference_valid:
                raise ValueError("Original objective/task/map does not match frozen analytic reference")
            if len(G) != 6 or len(old_h) != 6 or any(len(row) != 2 for row in G):
                raise ValueError("Smoke inequality dimensions changed")
            upper, lower = transport["task_upper_rows"], transport["task_lower_rows"]
            if upper != [4] or lower != [5] or G[4] != task[0] or G[5] != [-v for v in task[0]]:
                raise ValueError("Task selectors changed")
            h = list(old_h)
            h[4], h[5] = center + epsilon, -center + epsilon
            w, x = (list(map(_decimal, output[k])) for k in ("w", "x"))
            if len(w) != 2 or len(x) != 2:
                raise ValueError("Primal dimensions changed")
            for key in ("slack", "dual"):
                if len(output[key]) != len(E) + len(G):
                    raise ValueError("Cone output dimensions changed")
                list(map(_decimal, output[key]))
            for key in ("objective", "objective_dual", "res_primal", "res_dual", "gap_abs", "gap_rel"):
                _decimal(output[key])
            for key in ("iterations", "solve_time_seconds", "worker_elapsed_seconds"):
                if not math.isfinite(output[key]):
                    raise ValueError("Nonfinite solver diagnostics")
            # Native numeric and high-precision string diagnostics are finite too.
            for value in output["solver_info"].values():
                if isinstance(value, str):
                    _decimal(value)
                elif isinstance(value, (int, float)) and not math.isfinite(value):
                    raise ValueError("Nonfinite solver info")
            map_errors = [abs(a - d * b) for a, d, b in zip(w, D, x)]
            map_budgets = [_half_decimal_place(a) + abs(d) * _half_decimal_place(b)
                           for a, d, b in zip(w, D, x)]
            equality = [_dot(row, w) - rhs for row, rhs in zip(E, f)]
            inequality = [_dot(row, w) - rhs for row, rhs in zip(G, h)]
            offsets = [(_dot(row, w) + b - t) / s
                       for row, b, t, s in zip(task, bias, target, scales)]
            equality_inf = _maximum_abs(equality)
            hard_violation = _positive_maximum(inequality[:4])
            band = _maximum_abs(offsets)
            objective = _dot(w, [_dot(row, w) for row in P]) / 2 + _dot(q, w) + constant
            u_star = ONE if first else center - epsilon
            du, dv = w[0] - u_star, w[1] - v_star
            f_star = Decimal(-5) if first else Decimal(-4) - epsilon + epsilon * epsilon
            difference = du * du + dv * dv if first else (ONE - 2 * epsilon) * du + du * du + dv * dv
            eta = max(Decimal(atol), Decimal(rtol) * max(ONE, abs(f_star)))
            checks = {
                "status_solved": output["status"] == "Solved",
                "complete_finite_output": True,
                "original_reference_valid": reference_valid,
                "coordinate_map_consistent": all(a <= b for a, b in zip(map_errors, map_budgets)),
                "physical_pass": equality_inf <= Decimal("1e-6") and hard_violation <= Decimal("1e-7"),
                "fixed_literal_band_pass": band <= epsilon,
                "pass_known_optimum": abs(difference) <= eta,
            }
            metrics = {
                "original_objective": objective, "f_star": f_star, "eta": eta,
                "stable_objective_difference": difference,
                "direct_objective_difference": objective - f_star,
                "absolute_stable_objective_difference": abs(difference),
                "max_coordinate_error": max(abs(du), abs(dv)),
                "epsilon_exact_binary64": epsilon, "equality_inf": equality_inf,
                "hard_inequality_violation": hard_violation,
                "all_inequality_violation": _positive_maximum(inequality),
                "fixed_task_normalized_band": band,
            }
            result.update(checks=checks, metrics={k: str(v) for k, v in metrics.items()},
                          w_star=[str(u_star), str(v_star)],
                          coordinate_map_absolute_errors=list(map(str, map_errors)),
                          coordinate_map_serialization_budgets=list(map(str, map_budgets)),
                          recomputed_task_rhs=[str(h[4]), str(h[5])],
                          original_rounded_task_rhs=[str(old_h[4]), str(old_h[5])],
                          reasons=[k for k, passed in checks.items() if not passed],
                          passed=all(checks.values()))
    except (KeyError, ValueError, TypeError, InvalidOperation, IndexError, OverflowError) as error:
        result["reasons"].append(f"invalid_input_or_output: {error}")
    return result
