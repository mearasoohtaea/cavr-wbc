"""Independent fixed-step future evaluator for STEP14.

This module intentionally has no import from the STEP13 mechanism or any P1
decision code.  It consumes only an immutable current-state snapshot and the
submitted action.  Its labels are generated from the propagated state and
physical predicates at each checkpoint.
"""
from __future__ import annotations

import hashlib
import json
import math
from typing import Any, Dict, Mapping

CHECKPOINTS = 21
DT = 0.05
HORIZON_S = 1.0
EVALUATOR_CONFIG = {
    "name": "independent_fixed_step_surrogate_v2",
    "dt_s": DT,
    "horizon_s": HORIZON_S,
    "checkpoints": CHECKPOINTS,
    "contact": "four_point_static",
    "friction_coefficient": 0.50,
    "terminal_speed_threshold_m_s": 0.02,
}
EVALUATOR_CONFIG_HASH = hashlib.sha256(
    json.dumps(EVALUATOR_CONFIG, sort_keys=True, separators=(",", ":")).encode()
).hexdigest()


class EvaluatorInputError(ValueError):
    pass


def _sha(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def _finite(name: str, value: Any) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError) as exc:
        raise EvaluatorInputError(f"{name} must be finite") from exc
    if not math.isfinite(result):
        raise EvaluatorInputError(f"{name} must be finite")
    return result


def evaluate_future(case: Mapping[str, Any], action: Mapping[str, Any]) -> Dict[str, Any]:
    """Propagate a submitted action without consulting P1 or future labels."""
    required = ("p", "v", "p_max", "health", "support", "case_id")
    missing = [key for key in required if key not in case]
    if missing:
        raise EvaluatorInputError(f"missing immutable case fields: {missing}")
    if not isinstance(action, Mapping) or "kind" not in action or "scale" not in action:
        raise EvaluatorInputError("action must contain kind and scale")
    p = _finite("p", case["p"])
    v = _finite("v", case["v"])
    p_max = _finite("p_max", case["p_max"])
    health = _finite("health", case["health"])
    scale = _finite("action.scale", action["scale"])
    if scale < 0.0 or scale > 1.0:
        raise EvaluatorInputError("action scale outside [0,1]")
    if list(case["support"]) != ["FL", "FR", "RL", "RR"]:
        raise EvaluatorInputError("support identity mismatch")

    # This is a declared analytic action, not constant-torque hold.  The
    # evaluator does not infer any P1 margin; it only propagates the command.
    deceleration = max(0.0, 0.75 * health * scale)
    command_hash = _sha(dict(action))
    state_hash = _sha(dict(case))
    points = []
    first_failure = None
    min_margins = {"boundary_m": float("inf"), "contact": float("inf"),
                    "friction": float("inf"), "actuator": float("inf")}
    for checkpoint in range(CHECKPOINTS):
        t = checkpoint * DT
        position = p + v * t - 0.5 * deceleration * t * t
        velocity = max(0.0, v - deceleration * t)
        boundary_margin = p_max - position
        contact_margin = 0.20 if health > 0.0 else 0.05
        friction_margin = 0.20 if health > 0.0 else 0.03
        actuator_margin = health - 0.10 * scale
        contact_ok = contact_margin >= 0.0
        friction_ok = friction_margin >= 0.0
        actuator_ok = actuator_margin >= 0.0
        boundary_ok = boundary_margin >= 0.0
        terminal_speed_ok = velocity <= EVALUATOR_CONFIG["terminal_speed_threshold_m_s"]
        terminal_predicates = {
            "boundary": boundary_ok,
            "contact": contact_ok,
            "friction": friction_ok,
            "actuator": actuator_ok,
            "low_speed": terminal_speed_ok,
        }
        failure_type = None
        if not boundary_ok:
            failure_type = "BOUNDARY_CROSSING"
        elif not contact_ok:
            failure_type = "CONTACT_LOSS"
        elif not friction_ok:
            failure_type = "FRICTION_VIOLATION"
        elif not actuator_ok:
            failure_type = "ACTUATOR_LIMIT"
        if failure_type and first_failure is None:
            first_failure = {"checkpoint": checkpoint, "time_s": t, "type": failure_type}
        min_margins["boundary_m"] = min(min_margins["boundary_m"], boundary_margin)
        min_margins["contact"] = min(min_margins["contact"], contact_margin)
        min_margins["friction"] = min(min_margins["friction"], friction_margin)
        min_margins["actuator"] = min(min_margins["actuator"], actuator_margin)
        points.append({
            "checkpoint": checkpoint, "time_s": t,
            "qpos": {"projected_position_m": position},
            "qvel": {"projected_velocity_m_s": velocity},
            "contacts": {"FL": True, "FR": True, "RL": True, "RR": True},
            "friction_margin": friction_margin, "contact_margin": contact_margin,
            "actuator_margin": actuator_margin, "boundary_margin_m": boundary_margin,
            "predicates": terminal_predicates, "failure_type": failure_type,
        })
    safety_failure = first_failure is not None
    terminal_reached = bool(not safety_failure and all(points[-1]["predicates"].values()))
    return {
        "evaluator": EVALUATOR_CONFIG["name"],
        "evaluator_config_hash": EVALUATOR_CONFIG_HASH,
        "state_hash": state_hash, "command_hash": command_hash,
        "checkpoints": points, "first_failure": first_failure,
        "min_margins": min_margins, "safety_failure": safety_failure,
        "terminal_set_arrival": terminal_reached,
        "stop_distance_m": points[-1]["qpos"]["projected_position_m"] - p,
        "recovery_time_s": next((point["time_s"] for point in points if point["qvel"]["projected_velocity_m_s"] <= EVALUATOR_CONFIG["terminal_speed_threshold_m_s"]), None),
        "status": "SAFETY_FAILURE" if safety_failure else ("TERMINAL_REACHED" if terminal_reached else "TERMINAL_SET_MISS"),
        "label_source": "INDEPENDENT_EVALUATOR_ONLY",
        "backup_semantics": action["kind"],
    }


__all__ = ["CHECKPOINTS", "DT", "HORIZON_S", "EVALUATOR_CONFIG_HASH", "EvaluatorInputError", "evaluate_future"]
