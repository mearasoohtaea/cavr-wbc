"""Independent reduced-order trajectory evaluator for STEP15.

The evaluator consumes only a submitted per-tick action trajectory and an
immutable current-state case.  It does not import STEP13/P1 or use any
initial scale/future label.  This is semantic/reduced-order evidence only.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
import math
from typing import Any, Mapping, Sequence


class IndependentEvaluatorInputError(ValueError):
    pass


@dataclass(frozen=True)
class IndependentEvaluatorConfig:
    schema: str = "step15_independent_evaluator_config_v1"
    dt_s: float = 0.05
    horizon_s: float = 1.0
    terminal_speed_mps: float = 0.02
    terminal_margin_m: float = 0.01
    friction_demand_scale: float = 1.0
    max_abs_action: float = 1.0
    action_unit: str = "m/s^2"
    channel: str = "base_x_acceleration"
    semantics: str = "SEMANTIC_REDUCED_ORDER"
    contact_predicate: str = "case.support_is_valid"
    friction_predicate: str = "mu * normal_force >= abs(tangent_force)"
    actuator_predicate: str = "health * actuator_limit >= abs(action)"

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def _sha(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


DEFAULT_CONFIG = IndependentEvaluatorConfig()
EVALUATOR_CONFIG = DEFAULT_CONFIG.as_dict()
EVALUATOR_CONFIG_HASH = _sha(EVALUATOR_CONFIG)


def _finite(name: str, value: Any) -> float:
    try:
        x = float(value)
    except (TypeError, ValueError) as exc:
        raise IndependentEvaluatorInputError(f"{name} must be finite") from exc
    if not math.isfinite(x):
        raise IndependentEvaluatorInputError(f"{name} must be finite")
    return x


def _contact_ok(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, Mapping):
        return bool(value) and all(bool(v) for v in value.values())
    if isinstance(value, (tuple, list)):
        return bool(value) and all(bool(v) for v in value)
    return bool(value)


def _step(p: float, v: float, a: float, dt: float) -> tuple[float, float]:
    raw_v = v + a * dt
    if a < 0.0 and v > 0.0 and raw_v < 0.0:
        stop_t = v / (-a)
        stop_p = p + v * stop_t + 0.5 * a * stop_t * stop_t
        return stop_p, 0.0
    return p + v * dt + 0.5 * a * dt * dt, raw_v


def evaluate_trajectory(case: Mapping[str, Any], actions: Sequence[Mapping[str, Any]], config: IndependentEvaluatorConfig | None = None) -> dict[str, Any]:
    """Evaluate a submitted action trajectory tick by tick."""
    cfg = config or DEFAULT_CONFIG
    required = ("case_id", "p", "v", "p_max", "health", "support", "actuator_limit")
    missing = [key for key in required if key not in case]
    if missing:
        raise IndependentEvaluatorInputError(f"case missing {missing}")
    if not actions:
        raise IndependentEvaluatorInputError("trajectory must contain at least one action")
    p = _finite("case.p", case["p"])
    v = _finite("case.v", case["v"])
    p_max = _finite("case.p_max", case["p_max"])
    health = _finite("case.health", case["health"])
    friction_value = case.get("friction_coeff", case.get("friction_coefficient"))
    if friction_value is None:
        raise IndependentEvaluatorInputError("case missing friction_coeff/friction_coefficient")
    mu = _finite("case.friction_coeff", friction_value)
    normal_value = case.get("normal_force")
    if normal_value is None and isinstance(case.get("model"), Mapping):
        model = case["model"]
        normal_value = _finite("model.mass_kg", model.get("mass_kg")) * _finite("model.gravity_m_s2", model.get("gravity_m_s2")) / 4.0
    if normal_value is None:
        raise IndependentEvaluatorInputError("case missing normal_force or model mass/gravity")
    normal_force = _finite("case.normal_force", normal_value)
    actuator_limit = _finite("case.actuator_limit", case["actuator_limit"])
    if not 0.0 <= health <= 1.0 or mu < 0.0 or normal_force < 0.0 or actuator_limit < 0.0:
        raise IndependentEvaluatorInputError("invalid case physical values")
    model = case.get("model") if isinstance(case.get("model"), Mapping) else {}
    mass_kg = _finite("case.mass_kg", case.get("mass_kg", model.get("mass_kg", 1.0)))
    if mass_kg <= 0.0:
        raise IndependentEvaluatorInputError("mass_kg must be positive")
    backup_ids = {str(a.get("backup_id")) for a in actions}
    if len(backup_ids) != 1 or "None" in backup_ids:
        raise IndependentEvaluatorInputError("backup_id must be continuous across trajectory")
    trajectory_hash = _sha(list(actions))
    points: list[dict[str, Any]] = []
    first_failure: dict[str, Any] | None = None
    min_margins = {"boundary_m": float("inf"), "contact": float("inf"), "friction": float("inf"), "actuator": float("inf")}
    for index, action_record in enumerate(actions):
        if not isinstance(action_record, Mapping):
            raise IndependentEvaluatorInputError("each action must be a mapping")
        action = action_record.get("backup_action", action_record)
        if not isinstance(action, Mapping):
            raise IndependentEvaluatorInputError("action record missing backup_action")
        if action.get("unit") != cfg.action_unit or action.get("channel") != cfg.channel:
            raise IndependentEvaluatorInputError("action unit/channel mismatch")
        if "tick" in action_record and int(action_record["tick"]) != index:
            raise IndependentEvaluatorInputError("trajectory tick sequence must be contiguous")
        raw_value = action.get("value", action.get("acceleration_mps2"))
        a = _finite("action.value", raw_value)
        effective_actuator_limit = health * actuator_limit
        actuator_margin = effective_actuator_limit - abs(a)
        contact_margin = 1.0 if _contact_ok(case["support"]) else -1.0
        action_force_n = abs(a) * mass_kg * cfg.friction_demand_scale
        friction_margin = mu * normal_force - action_force_n
        boundary_margin = p_max - p
        contact_ok = contact_margin >= 0.0
        friction_ok = friction_margin >= 0.0
        actuator_ok = actuator_margin >= 0.0 and abs(a) <= cfg.max_abs_action + 1e-12
        boundary_ok = boundary_margin >= 0.0
        failure_type = None
        if not boundary_ok:
            failure_type = "BOUNDARY_CROSSING"
        elif not contact_ok:
            failure_type = "CONTACT_LOSS"
        elif not friction_ok:
            failure_type = "FRICTION_VIOLATION"
        elif not actuator_ok:
            failure_type = "ACTUATOR_LIMIT"
        if failure_type and first_failure is None:
            first_failure = {"tick": index, "time_s": index * cfg.dt_s, "type": failure_type}
        min_margins["boundary_m"] = min(min_margins["boundary_m"], boundary_margin)
        min_margins["contact"] = min(min_margins["contact"], contact_margin)
        min_margins["friction"] = min(min_margins["friction"], friction_margin)
        min_margins["actuator"] = min(min_margins["actuator"], actuator_margin)
        next_p, next_v = _step(p, v, a, cfg.dt_s)
        points.append({
            "tick": index, "time_s": index * cfg.dt_s,
            "state_before": {"p": p, "v": v}, "state_after": {"p": next_p, "v": next_v},
            "action": dict(action), "acceleration_mps2": a, "action_force_N": action_force_n, "boundary_margin_m": boundary_margin,
            "contact_margin": contact_margin, "friction_margin": friction_margin,
            "actuator_margin": actuator_margin,
            "predicates": {"boundary": boundary_ok, "contact": contact_ok, "friction": friction_ok, "actuator": actuator_ok},
            "failure_type": failure_type,
        })
        p, v = next_p, next_v
    terminal = {
        "boundary": p_max - p >= cfg.terminal_margin_m,
        "speed": abs(v) <= cfg.terminal_speed_mps,
        "contact": _contact_ok(case["support"]),
        "friction": min_margins["friction"] >= 0.0,
        "actuator": min_margins["actuator"] >= 0.0,
    }
    terminal_arrival = bool(all(terminal.values()) and first_failure is None)
    return {
        "evaluator": "step15_independent_reduced_order",
        "evaluator_config_hash": EVALUATOR_CONFIG_HASH,
        "semantics": cfg.semantics,
        "case_id": case["case_id"], "backup_id": next(iter(backup_ids)), "mass_kg": mass_kg,
        "action_count": len(points), "checkpoints": points,
        "trajectory_hash": trajectory_hash, "points": points,
        "first_failure": first_failure, "min_margins": min_margins,
        "terminal_set": terminal, "terminal_set_arrival": terminal_arrival,
        "status": "PASS" if terminal_arrival else ("FAIL" if first_failure else "TERMINAL_SET_MISS"),
        "label_source": "INDEPENDENT_TRAJECTORY_EVALUATOR",
        "future_reads": [], "step13_import": False,
    }


__all__ = ["IndependentEvaluatorConfig", "EVALUATOR_CONFIG", "EVALUATOR_CONFIG_HASH", "IndependentEvaluatorInputError", "evaluate_trajectory"]
