"""Independent evaluator for the STEP16 physical feedback panel.

The panel runner serialises the *facts observed by MuJoCo* at each control
tick.  This module consumes only that serialised trajectory.  It deliberately
does not import a backup policy, controller, scenario generator, or any of
the STEP13--STEP15 decision helpers.  Consequently labels produced here are
computed from state/action/torque/contact facts rather than copied from a
controller's decision.

The public entry point is :func:`evaluate_serialized_trajectory`.  Both
``(case, trajectory)`` and ``(trajectory, case)`` argument orderings are
accepted to make the evaluator convenient for JSONL readers; the explicit
keyword form is preferred.  ``evaluate_trajectory`` is an alias retained for
small harnesses which use the older evaluator naming convention.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
import math
from statistics import median
from typing import Any, Mapping, Sequence


FOOT_NAMES = ("FL", "FR", "RL", "RR")
CHECKPOINTS = 21
DT = 0.05
HORIZON_S = 1.0


@dataclass(frozen=True)
class Step16EvaluatorConfig:
    """Frozen independent-evaluator constants.

    The physical limits mirror the E2B physical evaluator's declared
    boundary.  They are constants here (rather than values read from policy
    output) so that a result can be recomputed from the JSONL evidence.
    """

    schema: str = "step17_independent_physical_evaluator_v1"
    checkpoint_count: int = CHECKPOINTS
    checkpoint_dt_s: float = DT
    horizon_s: float = HORIZON_S
    control_dt_s: float = 0.02
    deadline_ms: float = 20.0
    # Hard task boundary from the frozen physical evaluator.  The terminal
    # set has its own tighter 0.25 m/s endpoint below.
    velocity_limit_m_s: float = 2.0
    angular_velocity_limit_rad_s: float = 2.0
    roll_limit_rad: float = 0.55
    pitch_limit_rad: float = 0.55
    terminal_velocity_max_m_s: float = 0.25
    terminal_angle_max_rad: float = 0.20
    friction_margin_min_n: float = 0.0
    # The frozen physical predicate is strict: a zero margin is admissible,
    # but no numerical slack is introduced by this evaluator.
    torque_tolerance_nm: float = 0.0
    exact_grid_tolerance_s: float = 1.0e-9
    residual_tolerance_nm: float = 1.0e-5
    action_channel: str = "base_x_acceleration"
    action_unit: str = "m/s^2"
    semantics: str = "SERIALIZED_MUJOCO_FACTS_ONLY"

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


DEFAULT_CONFIG = Step16EvaluatorConfig()
EVALUATOR_CONFIG = DEFAULT_CONFIG.as_dict()
IndependentEvaluatorConfig = Step16EvaluatorConfig


def _canonical(value: Any) -> Any:
    """Return a JSON-safe deterministic representation for evidence hashes."""

    if isinstance(value, Mapping):
        return {str(k): _canonical(v) for k, v in sorted(value.items(), key=lambda kv: str(kv[0]))}
    if isinstance(value, (list, tuple)):
        return [_canonical(v) for v in value]
    # numpy scalar values are intentionally handled without importing numpy.
    if hasattr(value, "item") and callable(value.item):
        try:
            return _canonical(value.item())
        except Exception:
            pass
    if isinstance(value, float):
        if not math.isfinite(value):
            raise EvaluatorInputError("non-finite value in serialised evidence")
        return float(value)
    if isinstance(value, (str, int, bool)) or value is None:
        return value
    return str(value)


def _sha(value: Any) -> str:
    payload = json.dumps(_canonical(value), sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


EVALUATOR_CONFIG_HASH = _sha(EVALUATOR_CONFIG)


class EvaluatorInputError(ValueError):
    """Raised when a serialized trajectory is incomplete or inconsistent."""


# STEP15 used this longer name; exposing it avoids needless adapter code while
# making the new evaluator's independent semantics explicit.
IndependentEvaluatorInputError = EvaluatorInputError


def _finite(name: str, value: Any, *, default: float | None = None) -> float:
    if value is None:
        if default is not None:
            return float(default)
        raise EvaluatorInputError(f"{name} is missing")
    try:
        result = float(value)
    except (TypeError, ValueError) as exc:
        raise EvaluatorInputError(f"{name} must be finite") from exc
    if not math.isfinite(result):
        raise EvaluatorInputError(f"{name} must be finite")
    return result


def _vector(value: Any, name: str) -> list[float]:
    if value is None or isinstance(value, (str, bytes)):
        raise EvaluatorInputError(f"{name} must be a numeric vector")
    try:
        values = list(value)
    except TypeError as exc:
        raise EvaluatorInputError(f"{name} must be a numeric vector") from exc
    return [_finite(f"{name}[{i}]", v) for i, v in enumerate(values)]


def _lookup(mapping: Mapping[str, Any] | None, *names: str) -> Any:
    if not isinstance(mapping, Mapping):
        return None
    for name in names:
        if name in mapping:
            return mapping[name]
    return None


def _state(row: Mapping[str, Any]) -> Mapping[str, Any]:
    state = row.get("state")
    return state if isinstance(state, Mapping) else row


def _time(row: Mapping[str, Any], index: int, cfg: Step16EvaluatorConfig) -> float:
    value = _lookup(row, "time_s", "sim_time_s", "timestamp_s", "t_s")
    return _finite("trajectory.time_s", value, default=index * cfg.control_dt_s)


def _action(row: Mapping[str, Any], cfg: Step16EvaluatorConfig) -> dict[str, Any]:
    value = row.get("action", row.get("backup_action"))
    if not isinstance(value, Mapping):
        # Some trajectory writers store the scalar plus metadata directly.
        value = row
    channel = _lookup(value, "channel", "name")
    unit = _lookup(value, "unit", "units")
    scalar = _lookup(value, "value", "base_x_acceleration", "acceleration_mps2", "value_m_s2")
    if scalar is None:
        # Keep the evaluator useful for a trajectory where only a policy action
        # is present under the conventional key.
        scalar = row.get("base_x_acceleration")
    if scalar is None:
        raise EvaluatorInputError("trajectory row has no base_x_acceleration action")
    if channel is not None and str(channel) != cfg.action_channel:
        raise EvaluatorInputError(f"action channel mismatch: {channel!r}")
    if unit is not None and str(unit) != cfg.action_unit:
        raise EvaluatorInputError(f"action unit mismatch: {unit!r}")
    return {"channel": cfg.action_channel, "unit": cfg.action_unit, "value": _finite("action.value", scalar)}


def _contacts(row: Mapping[str, Any]) -> Mapping[str, Any]:
    value = row.get("contacts", row.get("contact"))
    if value is None and isinstance(row.get("physical_evaluation"), Mapping):
        value = row["physical_evaluation"].get("contacts")
    if not isinstance(value, Mapping):
        raise EvaluatorInputError("trajectory row has no contacts mapping")
    return value


def _contact_record(contacts: Mapping[str, Any], foot: str) -> Mapping[str, Any]:
    record = contacts.get(foot)
    if isinstance(record, Mapping):
        return record
    # A bare bool is accepted as a contact-presence fact; no friction force is
    # then inferred and the corresponding margin remains unknown (failure).
    return {"present": bool(record)}


def _contact_facts(row: Mapping[str, Any], case: Mapping[str, Any]) -> tuple[dict[str, Any], bool, float, bool]:
    contacts = _contacts(row)
    friction_default = _lookup(row, "friction_coefficient", "friction_coeff", "mu")
    if friction_default is None:
        friction_default = _lookup(case, "friction_coefficient", "friction_coeff", "mu")
    mu = _finite("friction_coefficient", friction_default, default=0.5)
    if mu < 0.0:
        raise EvaluatorInputError("friction coefficient must be non-negative")
    rows: dict[str, Any] = {}
    all_present = True
    all_normal = True
    min_margin = float("inf")
    for foot in FOOT_NAMES:
        record = _contact_record(contacts, foot)
        present_value = _lookup(record, "present", "in_contact", "contact", "support", "valid")
        if present_value is None and _lookup(record, "contact_count", "n_contact") is not None:
            present_value = _finite(f"{foot}.contact_count", _lookup(record, "contact_count", "n_contact")) > 0.0
        present = bool(present_value)
        normal = _lookup(record, "normal_force_n", "normal_force", "normal_n")
        tangent = _lookup(record, "tangential_force_n", "tangential_force", "tangent_force_n", "tangent_n")
        margin = _lookup(record, "friction_margin_n", "friction_margin", "friction_margin_N")
        if margin is None and normal is not None and tangent is not None:
            margin = mu * _finite(f"{foot}.normal_force_n", normal) - abs(_finite(f"{foot}.tangential_force_n", tangent))
        if margin is None:
            margin = float("-inf")
        else:
            margin = _finite(f"{foot}.friction_margin_n", margin)
        normal_value = None if normal is None else _finite(f"{foot}.normal_force_n", normal)
        tangent_value = None if tangent is None else _finite(f"{foot}.tangential_force_n", tangent)
        rows[foot] = {"present": present, "normal_force_n": normal_value, "tangential_force_n": tangent_value, "friction_margin_n": margin}
        all_present = all_present and present
        all_normal = all_normal and normal_value is not None and normal_value >= 0.0
        min_margin = min(min_margin, margin)
    return rows, all_present, min_margin, all_normal


def _health(row: Mapping[str, Any], case: Mapping[str, Any]) -> float:
    value = _lookup(row, "health", "active_health")
    if value is None:
        value = _lookup(case, "health", "active_health")
    if isinstance(value, Mapping):
        value = _lookup(value, "FR_thigh", "FR_THIGH", "fr_thigh")
    result = _finite("health", value, default=1.0)
    if result < 0.0 or result > 1.0:
        raise EvaluatorInputError("health outside [0,1]")
    return result


def _torque_facts(row: Mapping[str, Any], case: Mapping[str, Any], health: float, cfg: Step16EvaluatorConfig) -> tuple[float, float, bool, dict[str, Any]]:
    tau_applied = row.get("tau_applied", row.get("joint_tau_applied", row.get("actuator_force")))
    if tau_applied is None and isinstance(row.get("physical_evaluation"), Mapping):
        tau_applied = row["physical_evaluation"].get("actuator_force")
    applied = _vector(tau_applied, "tau_applied")
    tau_cmd = row.get("tau_cmd", row.get("command", row.get("ctrl_written")))
    command = None if tau_cmd is None else _vector(tau_cmd, "tau_cmd")
    limits = row.get("actuator_limits", row.get("torque_limits"))
    if limits is None:
        limits = case.get("actuator_limits", case.get("torque_limits"))
    if limits is None:
        # A trajectory can carry per-actuator ranges in the physical block.
        physical = row.get("physical_evaluation")
        if isinstance(physical, Mapping):
            limits = physical.get("actuator_limits")
    limits_vec = None if limits is None else _vector(limits, "actuator_limits")
    if limits_vec is not None and len(limits_vec) != len(applied):
        raise EvaluatorInputError("actuator_limits length differs from tau_applied")
    # If no model limits were serialized, health-scaled unit limits are not a
    # defensible physical fact; mark the predicate unknown/failed and expose
    # the absence in the ledger rather than silently inventing a limit.
    # A scalar health value in the panel denotes the FR_thigh damage channel;
    # all other actuators remain healthy.  Prefer the serialized per-channel
    # vector when available so the physical predicate is not accidentally
    # applied to every joint.
    health_raw = row.get("health_vector", case.get("health_vector"))
    # A runner that elects to serialize already health-scaled limits can mark
    # that fact explicitly; otherwise limits are interpreted as healthy model
    # limits and scaled exactly once below.
    limits_already_scaled = bool(row.get("actuator_limits_are_scaled", False))
    if limits_already_scaled:
        health_vec = [1.0] * len(applied)
    elif health_raw is None:
        health_vec = [1.0] * len(applied)
        if len(health_vec) > 1:
            health_vec[1] = health
    elif isinstance(health_raw, Mapping):
        health_vec = [1.0] * len(applied)
        for idx in range(len(applied)):
            value = _lookup(health_raw, str(idx), idx)
            if value is not None:
                health_vec[idx] = _finite(f"health_vector[{idx}]", value)
    else:
        health_vec = _vector(health_raw, "health_vector")
        if len(health_vec) != len(applied):
            raise EvaluatorInputError("health_vector length differs from tau_applied")
    if any(value < 0.0 or value > 1.0 for value in health_vec):
        raise EvaluatorInputError("health_vector outside [0,1]")
    # Both command and applied torques are independently checked against the
    # same health-scaled frozen limits.  Missing command/limits is a hard
    # failure: inventing a unit limit would turn incomplete evidence into a
    # passing physical predicate.
    if command is not None and len(command) != len(applied):
        raise EvaluatorInputError("tau_cmd length differs from tau_applied")
    def margin_for(values: list[float] | None) -> float:
        if values is None or limits_vec is None:
            return float("-inf")
        return min((factor * limit - abs(value) for factor, limit, value in zip(health_vec, limits_vec, values)), default=float("-inf"))
    command_margin = margin_for(command)
    applied_margin = margin_for(applied)
    command_ok = command is not None and limits_vec is not None and command_margin >= 0.0
    applied_ok = limits_vec is not None and applied_margin >= 0.0
    residual = None if command is None else max((abs(a - c) for a, c in zip(applied, command)), default=0.0)
    return applied_margin, (float(residual) if residual is not None else float("nan")), (command_ok and applied_ok), {
        "tau_applied": applied,
        "tau_cmd": command,
        "actuator_limits": limits_vec,
        "health_vector": health_vec,
        "command_torque_margin_nm": command_margin,
        "applied_torque_margin_nm": applied_margin,
        "command_torque_ok": command_ok,
        "applied_torque_ok": applied_ok,
    }


def _orientation(state: Mapping[str, Any]) -> tuple[float | None, float | None]:
    # qpos[3:7] is MuJoCo's wxyz root quaternion.  A directly serialized
    # roll/pitch pair is preferred when available.
    roll = _lookup(state, "roll_rad", "roll")
    pitch = _lookup(state, "pitch_rad", "pitch")
    qpos = state.get("qpos")
    if (roll is None or pitch is None) and qpos is not None:
        try:
            q = _vector(qpos, "state.qpos")
            if len(q) >= 7:
                w, x, y, z = q[3:7]
                roll = math.atan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y))
                pitch = math.asin(max(-1.0, min(1.0, 2 * (w * y - z * x))))
        except EvaluatorInputError:
            pass
    return (None if roll is None else _finite("roll", roll), None if pitch is None else _finite("pitch", pitch))


def _subtree_com_height(state: Mapping[str, Any], row: Mapping[str, Any]) -> tuple[float | None, Any]:
    """Read the frozen MuJoCo ``subtree_com[base_id][2]`` fact.

    ``qpos[2]`` is deliberately retained only as a diagnostic.  The runner
    may serialize ``subtree_com`` as a body-indexed mapping or as a dense
    list; both forms are accepted as long as the base body id is explicit.
    """
    base_id = _lookup(state, "subtree_com_base_id", "base_body_id", "base_id")
    if base_id is None:
        base_id = _lookup(row, "subtree_com_base_id", "base_body_id", "base_id")
    values = _lookup(state, "subtree_com")
    if values is None:
        values = _lookup(row, "subtree_com")
    if isinstance(values, Mapping):
        if base_id is not None:
            value = values.get(str(base_id), values.get(base_id))
        else:
            value = values.get("base", values.get("base_link"))
    elif values is not None:
        try:
            seq = list(values)
        except TypeError:
            seq = []
        # The runner serializes the selected ``subtree_com[base_id]`` as a
        # direct xyz vector.  A dense all-body array is also accepted.
        if len(seq) >= 3 and all(not isinstance(v, (list, tuple, Mapping)) for v in seq[:3]):
            value = seq
        else:
            value = seq[int(base_id)] if base_id is not None and int(base_id) < len(seq) else None
    else:
        # A scalar z fact is still accepted when explicitly named; unnamed
        # qpos height is never used as a substitute.
        value = _lookup(state, "subtree_com_z_m", "subtree_com_height_m")
        if value is None:
            value = _lookup(row, "subtree_com_z_m", "subtree_com_height_m")
    if value is None:
        return None, base_id
    vec = _vector(value, "subtree_com")
    if len(vec) < 3:
        raise EvaluatorInputError("subtree_com must contain x,y,z")
    return _finite("subtree_com[base_id][2]", vec[2]), base_id


def _state_facts(row: Mapping[str, Any], cfg: Step16EvaluatorConfig) -> dict[str, Any]:
    state = _state(row)
    qvel_value = state.get("qvel")
    qvel = None if qvel_value is None else _vector(qvel_value, "state.qvel")
    # Frozen task-speed fact: exactly qvel[0].  Lateral velocity remains a
    # diagnostic and cannot change this predicate.
    linear_speed_value = None if qvel is None or len(qvel) < 1 else float(qvel[0])
    angular_speed = _lookup(state, "angular_speed_rad_s")
    if angular_speed is None and qvel is not None and len(qvel) >= 6:
        angular_speed = math.sqrt(sum(v * v for v in qvel[3:6]))
    angular_speed_value = None if angular_speed is None else _finite("angular_speed_rad_s", angular_speed)
    roll, pitch = _orientation(state)
    qpos_value = state.get("qpos")
    base_joint_height = None
    if qpos_value is not None:
        qpos = _vector(qpos_value, "state.qpos")
        if len(qpos) >= 3:
            base_joint_height = _finite("state.base_joint_height_m", qpos[2])
    height, base_id = _subtree_com_height(state, row)
    return {"linear_speed_m_s": linear_speed_value, "angular_speed_rad_s": angular_speed_value, "roll_rad": roll, "pitch_rad": pitch,
            "velocity_x_m_s": None if qvel is None or len(qvel) < 1 else float(qvel[0]),
            "velocity_y_m_s": None if qvel is None or len(qvel) < 2 else float(qvel[1]),
            "height_m": height, "base_joint_height_m": base_joint_height,
            "subtree_com_base_id": base_id}


def _sample_indices(rows: Sequence[Mapping[str, Any]], cfg: Step16EvaluatorConfig, start_index: int | None = None, fault_onset_s: float | None = None) -> list[int]:
    if len(rows) < 2:
        raise EvaluatorInputError("trajectory must contain at least two rows")
    times = [_time(row, i, cfg) for i, row in enumerate(rows)]
    if any(times[i + 1] < times[i] for i in range(len(times) - 1)):
        raise EvaluatorInputError("trajectory timestamps must be monotonic")
    if fault_onset_s is not None:
        fault_onset_s = _finite("fault_onset_s", fault_onset_s)
        first_after = next((i for i, value in enumerate(times) if value >= fault_onset_s), None)
        if first_after is None:
            raise EvaluatorInputError("trajectory has no checkpoint at or after fault onset")
        if start_index is None:
            start_index = first_after
        elif start_index != first_after:
            raise EvaluatorInputError("start_index must be the first checkpoint at or after fault onset")
    if start_index is None:
        start_index = 0
    if start_index < 0 or start_index >= len(rows):
        raise EvaluatorInputError("start_index outside trajectory")
    start_time = times[start_index]
    if fault_onset_s is not None and start_time + cfg.exact_grid_tolerance_s < fault_onset_s:
        raise EvaluatorInputError("backup window starts before fault onset")
    if times[-1] + 1.0e-9 < start_time + cfg.horizon_s:
        raise EvaluatorInputError("trajectory does not cover the 1 s evaluator horizon")
    indices: list[int] = []
    for checkpoint in range(cfg.checkpoint_count):
        target = start_time + checkpoint * cfg.checkpoint_dt_s
        matches = [i for i, value in enumerate(times) if abs(value - target) <= cfg.exact_grid_tolerance_s]
        if len(matches) != 1:
            raise EvaluatorInputError(f"missing exact checkpoint at t={target:.12f}s")
        indices.append(matches[0])
    selected_times = [times[i] for i in indices]
    if any(abs((selected_times[i + 1] - selected_times[i]) - cfg.checkpoint_dt_s) > cfg.exact_grid_tolerance_s for i in range(len(selected_times) - 1)):
        raise EvaluatorInputError("checkpoint grid is not exactly 0.05 s")
    return indices


def _normalise_args(first: Any, second: Any) -> tuple[Mapping[str, Any], Sequence[Mapping[str, Any]]]:
    if isinstance(first, Mapping) and isinstance(second, Sequence) and not isinstance(second, (str, bytes)):
        return first, second
    if isinstance(second, Mapping) and isinstance(first, Sequence) and not isinstance(first, (str, bytes)):
        return second, first
    raise EvaluatorInputError("expected (case, trajectory) or (trajectory, case)")


def evaluate_serialized_trajectory(
    first: Mapping[str, Any] | Sequence[Mapping[str, Any]] | None = None,
    second: Sequence[Mapping[str, Any]] | Mapping[str, Any] | None = None,
    config: Step16EvaluatorConfig | None = None,
    *,
    case: Mapping[str, Any] | None = None,
    trajectory: Sequence[Mapping[str, Any]] | None = None,
    start_index: int | None = None,
) -> dict[str, Any]:
    """Evaluate one serialized physical backup trajectory.

    ``trajectory`` must contain state/action/tau/contact facts and a stable
    ``backup_id``.  Exactly 21 serialized checkpoints on an exact 0.05 s grid
    covering ``[0, 1]`` seconds are evaluated; non-exact grids are rejected.
    No policy decision or future label is consulted by this function.
    """

    cfg = config or DEFAULT_CONFIG
    if case is not None or trajectory is not None:
        if case is None or trajectory is None:
            raise EvaluatorInputError("case and trajectory must be supplied together")
        case_value, rows_value = case, trajectory
    else:
        if second is None:
            raise EvaluatorInputError("trajectory is missing")
        case_value, rows_value = _normalise_args(first, second)
    if not isinstance(case_value, Mapping):
        raise EvaluatorInputError("case must be a mapping")
    rows = list(rows_value)
    if not rows or any(not isinstance(row, Mapping) for row in rows):
        raise EvaluatorInputError("trajectory must be a non-empty sequence of mappings")
    backup_values = {str(row.get("backup_id")) for row in rows}
    if len(backup_values) != 1 or "None" in backup_values:
        raise EvaluatorInputError("backup_id must be present and continuous")
    backup_id = next(iter(backup_values))
    onset = _lookup(case_value, "fault_onset_s", "onset_s", "fault_start_time_s")
    onset_value = None if onset is None else _finite("fault_onset_s", onset)
    checkpoint_indices = _sample_indices(rows, cfg, None if start_index is None else int(start_index), onset_value)
    points: list[dict[str, Any]] = []
    first_failure: dict[str, Any] | None = None
    min_margins = {"friction_n": float("inf"), "torque_nm": float("inf"), "contact": float("inf"), "boundary_m": float("inf")}
    latencies: list[float] = []
    endpoint_misses = 0
    missing_deadline_count = 0
    for checkpoint, index in enumerate(checkpoint_indices):
        row = rows[index]
        t = _time(row, index, cfg)
        action = _action(row, cfg)
        health = _health(row, case_value)
        contacts, contact_ok, friction_margin, normal_ok = _contact_facts(row, case_value)
        torque_margin, torque_residual, torque_ok, torque = _torque_facts(row, case_value, health, cfg)
        state = _state_facts(row, cfg)
        latency = _lookup(row, "latency_ms", "online_decision_ms", "decision_latency_ms", "tick_latency_ms")
        if latency is None:
            missing_deadline_count += 1
        else:
            latency = _finite("latency_ms", latency)
            latencies.append(latency)
        deadline_ok = latency is not None and latency <= cfg.deadline_ms
        boundary_margin = _lookup(row, "boundary_margin_m", "task_boundary_margin_m")
        if boundary_margin is None and isinstance(row.get("physical_evaluation"), Mapping):
            boundary_margin = _lookup(row["physical_evaluation"], "boundary_margin_m", "minimum_margin")
        boundary_margin_value = float("inf") if boundary_margin is None else _finite("boundary_margin_m", boundary_margin)
        boundary_ok = boundary_margin_value >= 0.0
        speed_ok = state["linear_speed_m_s"] is not None and abs(state["linear_speed_m_s"]) <= cfg.velocity_limit_m_s
        angular_ok = state["angular_speed_rad_s"] is None or state["angular_speed_rad_s"] <= cfg.angular_velocity_limit_rad_s
        angle_ok = (state["roll_rad"] is None or abs(state["roll_rad"]) <= cfg.roll_limit_rad) and (state["pitch_rad"] is None or abs(state["pitch_rad"]) <= cfg.pitch_limit_rad)
        height_ok = state["height_m"] is not None and 0.16 <= state["height_m"] <= 0.60
        joint_ok = True
        physical = row.get("physical_evaluation")
        if isinstance(physical, Mapping):
            margins = physical.get("joint_limit_margins")
            if margins is not None:
                joint_ok = all(_finite("joint_limit_margin", x) >= 0.0 for x in margins)
        # Deadline is a separate endpoint, never a physical safety predicate.
        predicates = {"contact": contact_ok, "normal_force": normal_ok, "friction": friction_margin >= cfg.friction_margin_min_n, "torque": torque_ok, "command_torque": torque["command_torque_ok"], "applied_torque": torque["applied_torque_ok"], "joint_limit": joint_ok, "height": height_ok, "boundary": boundary_ok, "speed": speed_ok, "angular_speed": angular_ok, "angle": angle_ok, "deadline": deadline_ok}
        failure_type = None
        for name, label in (("contact", "CONTACT_LOSS"), ("normal_force", "NEGATIVE_NORMAL_FORCE"), ("friction", "FRICTION_VIOLATION"), ("command_torque", "COMMAND_ACTUATOR_LIMIT"), ("applied_torque", "APPLIED_ACTUATOR_LIMIT"), ("joint_limit", "JOINT_LIMIT"), ("height", "HEIGHT_BOUNDARY"), ("boundary", "BOUNDARY_CROSSING"), ("speed", "TASK_SPEED_LIMIT"), ("angle", "TASK_ANGLE_LIMIT")):
            if not predicates[name]:
                failure_type = label
                break
        if failure_type and first_failure is None:
            first_failure = {"checkpoint": checkpoint, "row_index": index, "time_s": t, "type": failure_type}
        min_margins["friction_n"] = min(min_margins["friction_n"], friction_margin)
        min_margins["torque_nm"] = min(min_margins["torque_nm"], torque_margin)
        min_margins["contact"] = min(min_margins["contact"], 1.0 if contact_ok else -1.0)
        min_margins["boundary_m"] = min(min_margins["boundary_m"], boundary_margin_value)
        if not deadline_ok:
            endpoint_misses += 1
        points.append({"checkpoint": checkpoint, "row_index": index, "time_s": t, "backup_id": backup_id, "state": state, "terminal_fields": row.get("terminal_fields", {}), "action": action, "tau_applied": torque["tau_applied"], "tau_cmd": torque["tau_cmd"], "torque_residual_nm": torque_residual, "contacts": contacts, "friction_margin_n": friction_margin, "torque_margin_nm": torque_margin, "command_torque_margin_nm": torque["command_torque_margin_nm"], "applied_torque_margin_nm": torque["applied_torque_margin_nm"], "command_torque_ok": torque["command_torque_ok"], "applied_torque_ok": torque["applied_torque_ok"], "boundary_margin_m": boundary_margin_value, "latency_ms": latency, "predicates": predicates, "failure_type": failure_type})
    terminal_point = points[-1]
    terminal = {
        "contact": bool(terminal_point["predicates"]["contact"]),
        "normal_force": bool(terminal_point["predicates"]["normal_force"]),
        "friction": bool(terminal_point["predicates"]["friction"]),
        "torque": bool(terminal_point["predicates"]["torque"]),
        "command_torque": bool(terminal_point["predicates"]["command_torque"]),
        "applied_torque": bool(terminal_point["predicates"]["applied_torque"]),
        "joint_limit": bool(terminal_point["predicates"]["joint_limit"]),
        "height": bool(terminal_point["predicates"]["height"]),
        "boundary": bool(terminal_point["predicates"]["boundary"]),
        "speed": bool(terminal_point["state"]["velocity_x_m_s"] is not None and abs(terminal_point["state"]["velocity_x_m_s"]) <= cfg.terminal_velocity_max_m_s and terminal_point["state"]["velocity_y_m_s"] is not None and abs(terminal_point["state"]["velocity_y_m_s"]) <= cfg.terminal_velocity_max_m_s),
        "angle": bool((terminal_point["state"]["roll_rad"] is None or abs(terminal_point["state"]["roll_rad"]) <= cfg.terminal_angle_max_rad) and (terminal_point["state"]["pitch_rad"] is None or abs(terminal_point["state"]["pitch_rad"]) <= cfg.terminal_angle_max_rad)),
    }
    terminal_arrival = bool(all(terminal.values()) and first_failure is None)
    trajectory_hash = _sha(rows)
    case_hash = _sha(case_value)
    status = "PASS" if terminal_arrival else ("DEADLINE_MISS" if endpoint_misses else "FAIL")
    physical_status = "PASS" if terminal_arrival else "FAIL"
    if terminal_arrival and endpoint_misses:
        status = "OFFLINE_PHYSICAL_BOUNDARY"
    return {
        "evaluator": "step16_independent_physical_serialized",
        "evaluator_config_hash": _sha(cfg.as_dict()),
        "evaluator_config": cfg.as_dict(),
        "case_id": case_value.get("case_id", case_value.get("scenario_id")),
        "case_hash": case_hash,
        "backup_id": backup_id,
        "trajectory_hash": trajectory_hash,
        "input_row_count": len(rows),
        "checkpoint_count": len(points),
        "fault_onset_s": onset_value,
        "fault_start_time_s": points[0]["time_s"],
        "fault_start_row_index": checkpoint_indices[0],
        "fault_start_time_at_or_after_onset": onset_value is None or points[0]["time_s"] >= onset_value,
        "checkpoints": points,
        "first_failure": first_failure,
        "min_margins": min_margins,
        "terminal_set": terminal,
        "terminal_set_arrival": terminal_arrival,
        "safety_failure": first_failure is not None,
        "deadline_ms": cfg.deadline_ms,
        "latency_count": len(latencies),
        "latency_missing_count": missing_deadline_count,
        "latency_p50_ms": median(latencies) if latencies else None,
        "latency_max_ms": max(latencies) if latencies else None,
        "deadline_miss_count": endpoint_misses,
        "status": status,
        "physical_status": physical_status,
        "semantics": cfg.semantics,
        "label_source": "INDEPENDENT_SERIALIZED_MUJOCO_FACTS",
        "future_reads": [],
        "policy_imports": False,
        "old_evaluate_method": False,
    }


def evaluate_trajectory(case: Mapping[str, Any], trajectory: Sequence[Mapping[str, Any]], config: Step16EvaluatorConfig | None = None) -> dict[str, Any]:
    """Compatibility alias for :func:`evaluate_serialized_trajectory`."""

    return evaluate_serialized_trajectory(case, trajectory, config=config)


evaluate = evaluate_serialized_trajectory


__all__ = [
    "CHECKPOINTS",
    "DT",
    "HORIZON_S",
    "EvaluatorInputError",
    "IndependentEvaluatorInputError",
    "EVALUATOR_CONFIG",
    "EVALUATOR_CONFIG_HASH",
    "Step16EvaluatorConfig",
    "IndependentEvaluatorConfig",
    "evaluate_serialized_trajectory",
    "evaluate_trajectory",
    "evaluate",
]
