"""Independent STEP23 actual-trajectory evaluator, never used for selection."""
import math
from cavr_wbc.evaluation.step16_independent_evaluator import evaluate_serialized_trajectory


def actual_reasons(row):
    if row.get('numerical_failure') or 'qpos' not in row or 'qvel' not in row:
        return ['NUMERICAL_OR_INCOMPLETE_STATE']
    reasons=[];qpos=row['qpos'];qvel=row['qvel']
    if not all(math.isfinite(v) for v in qpos+qvel): reasons.append('NONFINITE_STATE')
    if row['boundary_margin_m']<0: reasons.append('WORKSPACE_BOUNDARY_CROSSING')
    if abs(qvel[0])>2.: reasons.append('BASE_X_SPEED_LIMIT')
    if math.sqrt(sum(v*v for v in qvel[3:6]))>2.: reasons.append('ANGULAR_SPEED_LIMIT')
    if abs(row['roll'])>.55: reasons.append('ROLL_BOUNDARY')
    if abs(row['pitch'])>.55: reasons.append('PITCH_BOUNDARY')
    if not .16<=row['subtree_com_height_m']<=.60: reasons.append('HEIGHT_BOUNDARY')
    if any(v<0 for v in row['joint_limit_margins']): reasons.append('JOINT_LIMIT')
    for name,c in row['contacts'].items():
        if not c['present']: reasons.append('CONTACT_LOSS:'+name)
        if c['normal_force_n']<0: reasons.append('NEGATIVE_NORMAL_FORCE:'+name)
        if c['friction_margin_n']<0: reasons.append('FRICTION_VIOLATION:'+name)
    for tau,applied,limit,h in zip(row['tau_cmd'],row['tau_applied'],row['actuator_limits'],row['health_vector']):
        if abs(tau)>h*limit: reasons.append('COMMAND_TORQUE_BOUND')
        if abs(applied)>h*limit: reasons.append('APPLIED_TORQUE_BOUND')
    return list(dict.fromkeys(reasons))


def evaluate_actual(result,anchor):
    if not result['kind'].startswith('ACTUAL_'): raise ValueError('Actual evaluator refuses prediction/preview branch')
    rows=[result['initial_fact']]+result['physics_trajectory'] if result.get('initial_fact') else result['physics_trajectory']
    failures=[{'time_s':r['time_s'],'physics_step':r['physics_step'],'reasons':actual_reasons(r)} for r in rows if actual_reasons(r)]
    cp=result['checkpoints'];independent={'physical_status':'INCOMPLETE','terminal_set_arrival':False}
    if len(cp)==21 and result['counts']['physical_steps']==500:
        independent=evaluate_serialized_trajectory(case={'scenario_id':result['branch_id'],
            'health':result['health_vector'][1],'fault_onset_s':0.},trajectory=cp,start_index=0)
    complete=result['counts']['physical_steps']==500 and len(cp)==21 and result['status']=='COMPLETE'
    last=rows[-1] if rows and 'qpos' in rows[-1] and 'qvel' in rows[-1] else None
    x_error=last['qpos'][0]-anchor[0] if last else None
    vx=last['qvel'][0] if last else None
    terminal_numeric=bool(complete and last and abs(x_error)<=.002 and abs(vx)<=.001
        and abs(last['qvel'][1])<=.25 and abs(last['roll'])<=.20 and abs(last['pitch'])<=.20 and not actual_reasons(last))
    safe=complete and not failures
    sampled_times={round(r['time_s'],9) for r in cp}
    between=[r for r in failures if round(r['time_s'],9) not in sampled_times]
    return {'schema':'STEP23_INDEPENDENT_ACTUAL_EVALUATION_V1','complete':complete,
        'actual_safe_all_physics_states':safe,'actual_terminal_pass':terminal_numeric,
        'actual_safe_and_terminal':safe and terminal_numeric,
        'physical_failure_state_count':len(failures),'first_physical_failure':failures[0] if failures else None,
        'between_checkpoint_failure_count':len(between),'first_between_checkpoint_failure':between[0] if between else None,
        'sampled_independent_evaluation':independent,'terminal_anchor_x_error_m':x_error,'terminal_base_vx_m_s':vx,
        'min_workspace_margin_m':min((r['boundary_margin_m'] for r in rows if 'boundary_margin_m' in r),default=None),
        'min_command_torque_margin_nm':min((h*l-abs(t) for r in rows if 'tau_cmd' in r for t,l,h in zip(r['tau_cmd'],r['actuator_limits'],r['health_vector'])),default=None),
        'min_applied_torque_margin_nm':min((h*l-abs(t) for r in rows if 'tau_applied' in r for t,l,h in zip(r['tau_applied'],r['actuator_limits'],r['health_vector'])),default=None),
        'workspace_failure':any('WORKSPACE_BOUNDARY_CROSSING' in r['reasons'] for r in failures),
        'height_failure':any('HEIGHT_BOUNDARY' in r['reasons'] for r in failures),
        'pose_failure':any(any(k in r['reasons'] for k in ('ROLL_BOUNDARY','PITCH_BOUNDARY','ANGULAR_SPEED_LIMIT')) for r in failures),
        'solver_or_numerical_branch_failure':result['status']!='COMPLETE'}
