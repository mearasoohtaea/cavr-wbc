"""Independent actual evaluation with explicit fault-channel metadata."""
from cavr_wbc.evaluation.step23_actual import actual_reasons
from cavr_wbc.evaluation.step16_independent_evaluator import evaluate_serialized_trajectory


def evaluate_actual(result,anchor,context):
    if not result['kind'].startswith('ACTUAL_'):
        raise ValueError('STEP25 actual evaluator refuses prediction/preview')
    vector=context['health_vector']
    rows=([result['initial_fact']] if result.get('initial_fact') else [])+result['physics_trajectory']
    for row in rows:
        if 'qpos' in row and row.get('health_vector')!=vector:
            raise ValueError('Actual numeric facts lost the declared full health vector')
    failures=[{'time_s':r['time_s'],'physics_step':r['physics_step'],'reasons':actual_reasons(r)}
        for r in rows if actual_reasons(r)]
    cp=result['checkpoints'];complete=result['status']=='COMPLETE' and result['counts']['physical_steps']==500 and len(cp)==21
    case={k:context[k] for k in ('health_vector','faulted_actuator_name','faulted_actuator_index','faulted_health')}
    case.update(scenario_id=result['branch_id'],fault_onset_s=0.)
    independent=evaluate_serialized_trajectory(case=case,trajectory=cp,start_index=0) if complete else {'physical_status':'INCOMPLETE','terminal_set_arrival':False}
    last=rows[-1] if rows and 'qpos' in rows[-1] and 'qvel' in rows[-1] else None
    x_error=last['qpos'][0]-anchor[0] if last else None
    vx=last['qvel'][0] if last else None
    terminal=bool(complete and last and abs(x_error)<=.002 and abs(vx)<=.001 and abs(last['qvel'][1])<=.25
        and abs(last['roll'])<=.20 and abs(last['pitch'])<=.20 and not actual_reasons(last))
    sampled_times={round(r['time_s'],9) for r in cp}
    between=[r for r in failures if round(r['time_s'],9) not in sampled_times]
    safe=complete and not failures
    return {'schema':'STEP25_INDEPENDENT_ACTUAL_EVALUATION_V1','complete':complete,
        'case_metadata':case,'health_vector_used':vector,'scalar_health_fallback_used':False,
        'actual_safe_all_physics_states':safe,'actual_terminal_pass':terminal,'actual_safe_and_terminal':safe and terminal,
        'physical_failure_state_count':len(failures),'first_physical_failure':failures[0] if failures else None,
        'between_checkpoint_failure_count':len(between),'first_between_checkpoint_failure':between[0] if between else None,
        'sampled_independent_evaluation':independent,'terminal_anchor_x_error_m':x_error,'terminal_base_vx_m_s':vx,
        'solver_or_numerical_branch_failure':not complete}
