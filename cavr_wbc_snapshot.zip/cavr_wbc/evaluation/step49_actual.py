"""Frozen two-phase evaluator and O(1) online prefix gate, no future labels."""
import numpy as np
from cavr_wbc.evaluation.step23_actual import actual_reasons
from cavr_wbc.control.step20_task_reference import reference

def terminal(row,x):
    return bool(row and not actual_reasons(row) and abs(row['qpos'][0]-x)<=.002
        and abs(row['qvel'][0])<=.001 and abs(row['qvel'][1])<=.25
        and abs(row['roll'])<=.2 and abs(row['pitch'])<=.2)
class PrefixSummary:
    def __init__(self,context,packet):
        self.anchor=float(context['backup_anchor_q_init'][0]);self.direction=float(context['direction'])
        self.health=np.asarray(context['health_vector']).tolist()
        self.n=0;self.last=None;self.D=0.;self.physical=True;self.valid=True
        self.timely=bool(packet['experimental_committed'] and packet['prepared_commit_ms']<=17 and packet['command_ready_ms']<=20)
        self.control_count=0
    def fact(self,row):
        if row['physics_step']>500:return
        if 'qpos' in row and row.get('health_vector')!=self.health:raise ValueError('health changed in phase1')
        if row['physics_step']!=self.n:raise ValueError('non-contiguous phase1 sample')
        self.n+=1;self.last=row
        self.physical &= not bool(actual_reasons(row))
        if 'qpos' in row:self.D=max(self.D,self.direction*(row['qpos'][0]-self.anchor))
    def control(self,row):
        if row['slot']>=50:return
        self.control_count+=1;self.valid &= bool(row.get('valid_command') and row.get('tau_applied') is not None)
        self.timely &= bool(row.get('within_online_deadline') and (
            row['slot']<=1 or row.get('timing',{}).get('prepared_commit_ms',float('inf'))<=17))
    def gate(self):
        complete=bool(self.n==501 and self.control_count==50 and self.last and abs(self.last['time_s']-1.)<=1e-9)
        term=terminal(self.last,self.anchor) if complete else False
        return dict(**{'pass':bool(complete and self.physical and self.valid and self.timely and self.D<=.006 and term)},
            complete=complete,physical=self.physical,command_valid=self.valid,timely=self.timely,D_m=self.D,
            terminal=term,dense_count=self.n,control_count=self.control_count,
            only_observed_prefix=True,last_time_s=self.last['time_s'] if self.last else None)

def evaluate(branch,c,packet):
    rows=([branch['initial_fact']] if branch.get('initial_fact') else [])+branch.get('physics_trajectory',[])
    controls=branch.get('controls',[])
    summary=PrefixSummary(c,packet)
    for r in rows:
        if r['physics_step']<=500:summary.fact(r)
    for r in controls:
        if r['slot']<50:summary.control(r)
    phase=summary.gate()
    full=bool(len(rows)==2001 and len(controls)==200 and branch.get('counts',{}).get('physical_steps')==2000
        and [r['physics_step'] for r in rows]==list(range(2001)) and
        all(abs(r['time_s']-r['physics_step']*.002)<=1e-9 for r in rows))
    health=np.asarray(c['health_vector']).tolist()
    if any(r.get('health_vector')!=health for r in rows if 'qpos' in r):raise ValueError('whole mission health mismatch')
    failures=[dict(time_s=r['time_s'],reasons=actual_reasons(r)) for r in rows if actual_reasons(r)]
    goal=float(c['nominal_q_init'][0])+float(c['nominal_d_m'])
    last=rows[-1] if rows and 'qpos' in rows[-1] else None
    rms=float(np.sqrt(np.mean([r['qvel'][0]**2 for r in rows[1750:2001]]))) if full else None
    term=bool(full and terminal(last,goal) and rms<=.001)
    timely=bool(full and packet['prepared_commit_ms']<=17 and packet['command_ready_ms']<=20 and
        all(r.get('valid_command') and r.get('within_online_deadline') and
        (r['slot']<=1 or r.get('timing',{}).get('prepared_commit_ms',float('inf'))<=17) for r in controls))
    safe=bool(full and not failures); forced=c['experimental_arm']!='IMMEDIATE_MISSION'
    success=bool(safe and timely and term and (not forced or phase['pass']))
    signed=[float(c['direction']*(r['qpos'][0]-summary.anchor)) for r in rows if 'qpos' in r]
    errors=[abs(r['qpos'][0]-reference(float(c['nominal_q_init'][0]),float(c['nominal_d_m']),c['source_tick']*.02+r['time_s'])['p_ref_m']) for r in rows if 'qpos' in r]
    measured=[r for r in rows if 'qpos' in r]
    integrate=lambda lo:float(np.trapezoid([e for e,r in zip(errors,measured) if r['time_s']>=lo],[r['time_s'] for r in measured if r['time_s']>=lo])) if any(r['time_s']>=lo for r in measured) else None
    settled=None
    if full:
        good=np.array([abs(r['qpos'][0]-goal)<=.002 and abs(r['qvel'][0])<=.001 for r in rows])
        tail=np.logical_and.accumulate(good[::-1])[::-1];ids=np.flatnonzero(tail)
        settled=float(rows[ids[0]]['time_s']) if len(ids) else None
    return dict(phase1=phase,whole_complete=full,dense_count=len(rows),checkpoint_count=len(branch.get('checkpoints',[])),
        physical_safe=safe,timing_qualified=timely,mission_terminal=term,mission_success=success,
        goal_m=goal,original_anchor_m=summary.anchor,D_0to1_m=phase['D_m'],D_0to4_available_m=max([0.]+signed),
        final_goal_error_m=last['qpos'][0]-goal if last else None,final_anchor_displacement_m=last['qpos'][0]-summary.anchor if last else None,
        final_vx_m_s=last['qvel'][0] if last else None,final_half_second_vx_RMS_m_s=rms,sustained_goal_stop_time_s=settled,
        external_reference_error_integral_0to4_available_m_s=integrate(0.),external_reference_error_integral_1to4_available_m_s=integrate(1.),
        physical_failure_count=len(failures),first_physical_failure=failures[0] if failures else None,
        min_workspace_margin_m=min((r['boundary_margin_m'] for r in rows if 'boundary_margin_m'in r),default=None),
        min_friction_margin_n=min((v['friction_margin_n'] for r in rows for v in r.get('contacts',{}).values()),default=None),
        min_command_torque_margin_nm=min((r['command_torque_margin_nm'] for r in rows if 'command_torque_margin_nm'in r),default=None),
        min_applied_torque_margin_nm=min((r['applied_torque_margin_nm'] for r in rows if 'applied_torque_margin_nm'in r),default=None),
        last_observed_time_s=rows[-1]['time_s'] if rows else None,forced_recovery_gate=forced,
        final_classification='MISSION_COMPLETED' if success else 'PHYSICAL_FAILURE' if failures else
            'TASK_NOT_COMPLETED' if full and timely else 'LATE_OR_NUMERICAL_PARTIAL',
        phase2_D_is_not_physical_failure=True)
