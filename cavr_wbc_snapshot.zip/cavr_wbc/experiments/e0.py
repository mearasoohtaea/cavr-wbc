"""E0 real-stack output-torque-capacity audit for the pinned Go2 model."""

from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mujoco
import numpy as np
import yaml

from cavr_wbc.experiments.go2_standing import run_go2_standing
from cavr_wbc.models import ActuatorHealthModel
from cavr_wbc.platforms.go2_mujoco import (
    DEFAULT_GO2_MODEL_PATH,
    extract_actuator_joint_map,
    extract_healthy_torque_limits,
    joint_tau_from_qfrc,
    load_go2_model,
)


def _write_json(path: Path, value: Any) -> None:
    path.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n",
        encoding="utf-8",
    )


def _sha256(path: Path) -> str:
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    return digest


def _git_head() -> str:
    return subprocess.check_output(
        ["git", "rev-parse", "HEAD"], text=True, encoding="utf-8"
    ).strip()


def _rho_label(value: float) -> str:
    return f"{value:.2f}"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/dev/e0_go2_fault_model_audit.yaml")
    parser.add_argument(
        "--step01b-result",
        default="artifacts/step01b_platform_freeze/STEP01B_RESULT.json",
    )
    parser.add_argument("--output", default="artifacts/E0_fault_model_audit")
    args = parser.parse_args()

    step01b = json.loads(Path(args.step01b_result).read_text(encoding="utf-8"))
    if step01b["status"] != "PASS":
        raise RuntimeError("E0 forbidden: STEP-01B did not pass")

    config_path = Path(args.config)
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    healthy_config = yaml.safe_load(
        Path("configs/dev/step01b_go2_healthy.yaml").read_text(encoding="utf-8")
    )
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    (output / "config.yaml").write_text(
        config_path.read_text(encoding="utf-8"), encoding="utf-8"
    )

    model = load_go2_model()
    mapping = extract_actuator_joint_map(model)
    limits = extract_healthy_torque_limits(model)
    names = [entry.actuator_name for entry in mapping]
    target_name = str(config["target_actuator"])
    target = names.index(target_name)
    target_mapping = mapping[target]
    healthy_limit = float(limits[target])
    health_levels = [float(value) for value in config["health_levels"]]
    normalized_commands = [
        float(value) for value in config["normalized_command_samples"]
    ]
    tolerance = float(config["comparison_tolerance"])
    health_model = ActuatorHealthModel()
    home_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_KEY, "home")

    sweep_rows = []
    violations = []
    unexpected_clipping = []
    for rho_value in health_levels:
        rho = np.ones(model.nu, dtype=float)
        rho[target] = rho_value
        expected_bound = rho_value * healthy_limit
        for normalized in normalized_commands:
            u_raw = np.zeros(model.nu, dtype=float)
            u_raw[target] = normalized * healthy_limit
            health_result = health_model.apply(u_raw, rho, limits)
            u_health = np.asarray(health_result.u_health, dtype=float)
            data = mujoco.MjData(model)
            mujoco.mj_resetDataKeyframe(model, data, home_id)
            data.ctrl[:] = u_health
            mujoco.mj_forward(model, data)
            joint_tau = joint_tau_from_qfrc(model, data)
            ctrl = float(data.ctrl[target])
            force = float(data.actuator_force[target])
            applied = float(joint_tau[target])
            bound_ok = abs(applied) <= expected_bound + tolerance
            chain_ok = (
                abs(ctrl - float(u_health[target])) <= tolerance
                and abs(force - ctrl) <= tolerance
                and abs(applied - force) <= tolerance
            )
            if not bound_ok:
                violations.append(
                    {
                        "rho": rho_value,
                        "normalized_command": normalized,
                        "applied": applied,
                        "expected_bound": expected_bound,
                    }
                )
            if not chain_ok:
                unexpected_clipping.append(
                    {
                        "rho": rho_value,
                        "normalized_command": normalized,
                        "u_health": float(u_health[target]),
                        "ctrl_written": ctrl,
                        "actuator_force": force,
                        "joint_tau_applied": applied,
                    }
                )
            sweep_rows.append(
                {
                    "rho": rho_value,
                    "normalized_command": normalized,
                    "u_raw": float(u_raw[target]),
                    "lower_bound": -expected_bound,
                    "upper_bound": expected_bound,
                    "u_health": float(u_health[target]),
                    "ctrl_written": ctrl,
                    "actuator_force": force,
                    "joint_tau_applied": applied,
                    "saturated": bool(health_result.saturation_mask[target]),
                    "bound_ok": bound_ok,
                    "runtime_chain_ok": chain_ok,
                }
            )

    with (output / "raw_sweep.csv").open(
        "w", encoding="utf-8", newline=""
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=list(sweep_rows[0]))
        writer.writeheader()
        writer.writerows(sweep_rows)

    measured_ratios = {}
    measured_maxima = {}
    for rho_value in health_levels:
        values = [
            abs(float(row["joint_tau_applied"]))
            for row in sweep_rows
            if float(row["rho"]) == rho_value
        ]
        maximum = max(values)
        measured_maxima[_rho_label(rho_value)] = maximum
        measured_ratios[_rho_label(rho_value)] = maximum / healthy_limit
    half_ratio = measured_ratios["0.50"]
    double_scaling_detected = abs(half_ratio - 0.25) < abs(half_ratio - 0.5)

    # The target was frozen in configuration before this run. Verify the
    # predeclared selection criterion using the rho=1 replay; do not reselect.
    duration = float(config["dynamic_duration_s"])
    kp = (float(healthy_config["controller"]["kp_all"]),) * model.nu
    kd = (float(healthy_config["controller"]["kd_all"]),) * model.nu
    dynamic_path = output / "dynamic_replay.jsonl"
    dynamic_summaries = {}
    dynamic_traces = {}
    dynamic_violations = []
    for run_index, rho_value in enumerate(health_levels):
        rho = np.ones(model.nu, dtype=float)
        rho[target] = rho_value
        result = run_go2_standing(
            duration_s=duration,
            kp=kp,
            kd=kd,
            rho=rho,
            health_adapter_active=True,
            run_id=f"E0_DYNAMIC_RHO_{_rho_label(rho_value)}",
            output_jsonl=dynamic_path,
            append_jsonl=run_index > 0,
        )
        expected_bound = rho_value * healthy_limit
        target_applied = result.traces["joint_tau_applied"][:, target]
        target_health = result.traces["u_health"][:, target]
        target_ctrl = result.traces["ctrl_written"][:, target]
        target_force = result.traces["actuator_force"][:, target]
        maximum_violation = max(
            0.0, float(np.max(np.abs(target_applied))) - expected_bound
        )
        chain_error = max(
            float(np.max(np.abs(target_health - target_ctrl))),
            float(np.max(np.abs(target_ctrl - target_force))),
            float(np.max(np.abs(target_force - target_applied))),
        )
        if maximum_violation > tolerance or chain_error > tolerance:
            dynamic_violations.append(
                {
                    "rho": rho_value,
                    "maximum_bound_violation": maximum_violation,
                    "maximum_runtime_chain_error": chain_error,
                }
            )
        dynamic_summaries[_rho_label(rho_value)] = {
            **result.summary,
            "target_max_abs_u_raw": float(
                np.max(np.abs(result.traces["u_raw"][:, target]))
            ),
            "target_max_abs_joint_tau_applied": float(
                np.max(np.abs(target_applied))
            ),
            "expected_bound": expected_bound,
            "maximum_bound_violation": maximum_violation,
            "maximum_runtime_chain_error": chain_error,
        }
        dynamic_traces[rho_value] = result.traces

    target_excited = dynamic_summaries["1.00"]["target_max_abs_u_raw"] > 1e-6

    # Plots are generated directly from the raw sweep rows and dynamic traces.
    fig, axis = plt.subplots(figsize=(7, 5))
    for rho_value in health_levels:
        rows = [row for row in sweep_rows if float(row["rho"]) == rho_value]
        axis.plot(
            [float(row["u_raw"]) for row in rows],
            [float(row["joint_tau_applied"]) for row in rows],
            marker="o",
            label=f"rho={rho_value:.2f}",
        )
    axis.set_xlabel("u_raw (N m)")
    axis.set_ylabel("joint_tau_applied (N m)")
    axis.grid(True, alpha=0.3)
    axis.legend()
    fig.tight_layout()
    fig.savefig(output / "command_vs_applied.png", dpi=160)
    plt.close(fig)

    fig, axis = plt.subplots(figsize=(6, 4))
    ordered = sorted(health_levels)
    axis.plot(
        ordered,
        [healthy_limit * value for value in ordered],
        "k--",
        label="theory rho * healthy_limit",
    )
    axis.plot(
        ordered,
        [measured_maxima[_rho_label(value)] for value in ordered],
        "o-",
        label="measured joint torque",
    )
    axis.set_xlabel("rho")
    axis.set_ylabel("maximum |joint_tau_applied| (N m)")
    axis.grid(True, alpha=0.3)
    axis.legend()
    fig.tight_layout()
    fig.savefig(output / "max_torque_vs_rho.png", dpi=160)
    plt.close(fig)

    fig, axes = plt.subplots(len(health_levels), 1, figsize=(9, 12), sharex=True)
    time_axis = np.arange(int(round(duration / model.opt.timestep))) * model.opt.timestep
    for axis, rho_value in zip(axes, health_levels):
        traces = dynamic_traces[rho_value]
        bound = rho_value * healthy_limit
        axis.plot(time_axis, traces["u_raw"][:, target], label="u_raw", alpha=0.65)
        axis.plot(time_axis, traces["u_health"][:, target], label="u_health")
        axis.plot(
            time_axis,
            traces["joint_tau_applied"][:, target],
            label="joint_tau_applied",
            linestyle="--",
        )
        axis.axhline(bound, color="black", linewidth=0.8)
        axis.axhline(-bound, color="black", linewidth=0.8)
        axis.set_ylabel(f"rho={rho_value:.2f}")
        axis.grid(True, alpha=0.25)
    axes[0].legend(ncol=3, fontsize=8)
    axes[-1].set_xlabel("time (s)")
    fig.tight_layout()
    fig.savefig(output / "dynamic_torque_trace.png", dpi=160)
    plt.close(fig)

    ratio_errors = {
        label: abs(value - float(label)) for label, value in measured_ratios.items()
    }
    scaling_summary = {
        "fault_model": "output_torque_capacity",
        "target_actuator": target_name,
        "target_actuator_index": target,
        "target_joint": target_mapping.joint_name,
        "target_joint_id": target_mapping.joint_id,
        "target_dof_index": target_mapping.dof_index,
        "target_selection_rule": config["target_selection_rule"],
        "target_excited_in_healthy_replay": target_excited,
        "healthy_limit": healthy_limit,
        "health_levels": health_levels,
        "measured_maxima": measured_maxima,
        "measured_max_ratios": measured_ratios,
        "ratio_absolute_errors": ratio_errors,
        "rho_half_measured_ratio": half_ratio,
        "double_scaling_detected": double_scaling_detected,
        "static_violations": violations,
        "unexpected_clipping": unexpected_clipping,
        "dynamic_violations": dynamic_violations,
        "dynamic_summaries": dynamic_summaries,
    }
    _write_json(output / "fault_scaling_summary.json", scaling_summary)

    passed = (
        target_excited
        and not violations
        and not unexpected_clipping
        and not dynamic_violations
        and not double_scaling_detected
        and all(error <= tolerance for error in ratio_errors.values())
    )
    status = "PASS" if passed else "FAIL"
    result = {
        "status": status,
        "fault_model": "output_torque_capacity",
        "joint": target_mapping.joint_name,
        "actuator": target_name,
        "health_levels": health_levels,
        "healthy_limit": healthy_limit,
        "measured_max_ratios": measured_ratios,
        "rho_half_measured_real_ratio": half_ratio,
        "double_scaling_detected": double_scaling_detected,
        "mapping_verified": True,
        "unexpected_clipping": unexpected_clipping,
        "violations": violations + dynamic_violations,
        "git_head_at_execution": _git_head(),
        "model": DEFAULT_GO2_MODEL_PATH.as_posix(),
        "model_sha256": step01b["robot_model_sha256"],
        "config_sha256": _sha256(config_path),
        "generated_at": datetime.now(timezone.utc).astimezone().isoformat(),
        "next_stage_allowed": passed,
    }
    _write_json(output / "E0_RESULT.json", result)

    artifact_files = [
        path
        for path in output.iterdir()
        if path.is_file() and path.name != "manifest.json"
    ]
    manifest = {
        "stage": "E0",
        "git_head_at_execution": result["git_head_at_execution"],
        "model_sha256": result["model_sha256"],
        "config_sha256": result["config_sha256"],
        "files": [
            {
                "path": path.as_posix(),
                "size_bytes": path.stat().st_size,
                "sha256": _sha256(path),
            }
            for path in sorted(artifact_files)
        ],
    }
    _write_json(output / "manifest.json", manifest)

    report = f"""# CAVR-WBC E0 Fault Model Audit

## Material Passport

- Origin Skill: experiment-agent
- Origin Mode: run
- Origin Date: {result['generated_at']}
- Verification Status: VERIFIED DEV actuator-level audit
- Version Label: e0_go2_v1

## Result

**E0: {status}**. This validates actuator-path implementation; it does not prove
control performance or robust stability.

- Model: `{result['model']}`
- Target actuator: `{target_name}` (index {target})
- Joint/dof: `{target_mapping.joint_name}` / {target_mapping.dof_index}
- Healthy limit: {healthy_limit} N m
- Selection rule frozen before E0: {config['target_selection_rule']}
- Healthy replay target was nonzero: {target_excited}

## Static saturation sweep

Measured maximum ratios by rho: `{measured_ratios}`.

At rho=0.5, the real mapped joint-torque ratio was **{half_ratio}**. Double
damage scaling detected: **{double_scaling_detected}**.

Static violations: {len(violations)}. Unexpected runtime clipping or chain
mismatches: {len(unexpected_clipping)}.

## Dynamic short replay

The same 3 s torque-PD DEV scenario ran at all five health levels. E0 evaluates
only actuator-path correctness; standing loss under severe damage is retained
and is not used as a method-quality verdict. Dynamic actuator-path violations:
{len(dynamic_violations)}.

## Stop rule

No B1, task projection, E1/E2, recovery filter, MPC, or RL was implemented.
"""
    (output / "E0_REPORT.md").write_text(report, encoding="utf-8")
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0 if passed else 2


if __name__ == "__main__":
    raise SystemExit(main())

