"""E2-A: continuous-time analytic braking, with no optimizer or robot imports.

Finite-decimal inputs are parsed exactly with the standard-library Fraction.
This is elementary analytic calculation, not an extension of the closed
G/H/HR QP-certificate branch. Trajectory sampling is only for visualization.
"""
from __future__ import annotations

import argparse
from collections import Counter
import csv
from datetime import datetime, timezone
from decimal import Decimal, localcontext
from fractions import Fraction
import hashlib
from html import escape
import io
import json
from pathlib import Path
import subprocess
import sys
import time
import unittest


ROOT = Path(__file__).resolve().parents[2]
VERSION = "E2_ANALYTIC_DEV_V1"
ZERO, ONE = Fraction(0), Fraction(1)
DEVELOPMENT_LIMIT_S = 90 * 60
EXPORT_LIMIT_S = 15 * 60
EXPECTED_CONFIG = {
    "experiment": "E2_analytic_dev", "position_boundary_m": "0.0",
    "distance_to_boundary_m": ["0.25", "0.5", "1.0", "2.0"],
    "initial_velocity_mps": ["-0.5", "0.0", "0.5", "1.0", "1.5"],
    "braking_acceleration_mps2": ["0.0", "0.25", "0.5", "1.0"],
    "detection_delay_s": ["0.0", "0.05", "0.20"], "commit_interval_s": "0.02",
    "candidate_input_factors": ["-1.0", "0.0", "1.0"],
    "model": "analytic_double_integrator", "inference_scope": "mechanism_and_implementation_only",
}
PASSPORT = """## Material Passport

- Origin Skill: experiment-agent / academic-research-suite
- Origin Mode: bounded analytic execution and validation
- Verification Status: ANALYZED
- Version: E2_ANALYTIC_DEV_V1

"""


def exact(value):
    if isinstance(value, Fraction):
        return value
    if isinstance(value, str):
        return Fraction(value)
    if type(value) is int:
        return Fraction(value)
    raise ValueError("Use exact integer, Fraction or finite-decimal string; binary float rejected")


def number(value):
    if value is None:
        return ""
    if isinstance(value, Fraction):
        with localcontext() as context:
            context.prec = 60
            result = format(Decimal(value.numerator) / Decimal(value.denominator), "f")
        return result.rstrip("0").rstrip(".") if "." in result else result
    if type(value) is bool:
        return "true" if value else "false"
    return str(value)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def utc():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _jsonable(value):
    if isinstance(value, Fraction):
        return number(value)
    if isinstance(value, dict):
        return {key: _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(item) for item in value]
    return value


def save_result(output, result):
    (output / "E2_ANALYTIC_RESULT.json").write_text(
        json.dumps(_jsonable(result), ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8", newline="\n")


def load_config(path):
    """Read the deliberately small, flat YAML contract without extra packages."""
    parsed = {}
    for raw_line in Path(path).read_text(encoding="utf-8").splitlines():
        line = raw_line.split("#", 1)[0].strip()
        if not line:
            continue
        key, separator, raw = line.partition(":")
        require(separator and key.strip() not in parsed, "Invalid/duplicate flat YAML key")
        value = raw.strip()
        parsed[key.strip()] = [item.strip() for item in value[1:-1].split(",")] if value.startswith("[") and value.endswith("]") else value
    require(set(parsed) == set(EXPECTED_CONFIG), "Fixed DEV configuration keys changed")
    config = {}
    for key, expected in EXPECTED_CONFIG.items():
        if key in ("experiment", "model", "inference_scope"):
            require(parsed[key] == expected, "DEV semantic contract changed: " + key)
            config[key] = parsed[key]
        elif isinstance(expected, list):
            config[key] = [exact(item) for item in parsed[key]]
            require(config[key] == [exact(item) for item in expected], "Fixed DEV grid/order changed: " + key)
        else:
            config[key] = exact(parsed[key])
            require(config[key] == exact(expected), "Fixed DEV scalar changed: " + key)
    return config


def margin_class(margin):
    return "UNBOUNDED_FORWARD_DRIFT" if margin is None else "BOUNDARY" if margin == 0 else "INTERIOR" if margin > 0 else "EXTERIOR"


def immediate(distance, velocity, acceleration, position_boundary=ZERO):
    """One-sided infinite-horizon viability and safe zero-speed reachability.

    Maximal opposite-velocity input stops when a>0. With a=0 and v<0,
    the upper position bound remains viable, but v=0 cannot be reached.
    Both main flags include initial position safety and the entire path.
    """
    d, v, a, boundary = map(exact, (distance, velocity, acceleration, position_boundary))
    require(a >= 0, "Acceleration bound must be nonnegative")
    p0, initial_safe = boundary - d, d >= 0
    kinematic_terminal = a > 0 or v == 0
    if v == 0:
        stop_time, displacement, backup_u = ZERO, ZERO, ZERO
        max_position, unbounded, mode = p0, False, "HOLD_ZERO_VELOCITY"
    elif a == 0:
        stop_time = displacement = None
        backup_u = ZERO
        unbounded = v > 0
        max_position = None if unbounded else p0
        mode = "NO_BRAKING_FORWARD_DRIFT" if v > 0 else "RETREAT_VIABLE_NO_ZERO_TERMINAL"
    else:
        stop_time = abs(v) / a
        displacement = v * abs(v) / (2 * a)
        backup_u = -a if v > 0 else a
        max_position = max(p0, p0 + displacement)
        unbounded = False
        mode = "FORWARD_BRAKING" if v > 0 else "RETREAT_TO_ZERO"
    margin = None if unbounded else boundary - max_position
    viable = initial_safe and not unbounded and margin >= 0
    terminal = viable and kinematic_terminal
    return {"initial_position_m": p0, "initial_position_safe": initial_safe,
            "initial_velocity_mps": v, "braking_acceleration_mps2": a,
            "backup_mode": mode, "backup_input_mps2": backup_u,
            "stopping_time_s": stop_time, "signed_stopping_displacement_m": displacement,
            "zero_velocity_position_m": None if displacement is None else p0 + displacement,
            "maximum_position_m": max_position, "maximum_position_unbounded": unbounded,
            "recovery_margin_m": margin, "margin_class": margin_class(margin),
            "kinematic_zero_velocity_reachable": kinematic_terminal,
            "position_constraint_viable": viable, "zero_velocity_terminal_reachable": terminal}


def interval_extrema(position, velocity, constant_input, duration):
    p, v, u, T = map(exact, (position, velocity, constant_input, duration))
    require(T >= 0, "Interval duration must be nonnegative")
    p_end, v_end = p + v * T + u * T * T / 2, v + u * T
    candidates = [(ZERO, p), (T, p_end)]
    critical = -v / u if u != 0 else None
    interior = critical is not None and ZERO < critical < T
    if interior:
        candidates.append((critical, p + v * critical + u * critical * critical / 2))
    maximum = max(value for _, value in candidates)
    maximum_time = min(t for t, value in candidates if value == maximum)
    return {"endpoint_position_m": p_end, "endpoint_velocity_mps": v_end,
            "maximum_position_m": maximum, "maximum_time_s": maximum_time,
            "interior_velocity_zero_checked": interior,
            "interior_velocity_zero_time_s": critical if interior else None,
            "extrema_candidates_checked": len(candidates)}


def delay_case(distance, velocity, acceleration, delay, position_boundary=ZERO):
    d, v, a, tau, boundary = map(exact, (distance, velocity, acceleration, delay, position_boundary))
    require(tau >= 0 and a >= 0, "Negative delay or acceleration bound")
    prefix = interval_extrema(boundary - d, v, ZERO, tau)
    backup = immediate(boundary - prefix["endpoint_position_m"], v, a, boundary)
    prefix_safe = prefix["maximum_position_m"] <= boundary
    maximum = None if backup["maximum_position_unbounded"] else max(prefix["maximum_position_m"], backup["maximum_position_m"])
    margin = None if maximum is None else boundary - maximum
    return {"initial_position_m": boundary - d, "initial_velocity_mps": v,
            "braking_acceleration_mps2": a, "detection_delay_s": tau,
            "delay_input_mps2": ZERO, "delay_maximum_position_m": prefix["maximum_position_m"],
            "delay_interval_safe": prefix_safe, "backup_start_position_m": prefix["endpoint_position_m"],
            "backup_stopping_time_s": backup["stopping_time_s"],
            "scheduled_terminal_time_s": None if backup["stopping_time_s"] is None else tau + backup["stopping_time_s"],
            "zero_velocity_position_m": backup["zero_velocity_position_m"],
            "total_signed_displacement_to_zero_m": None if backup["signed_stopping_displacement_m"] is None else v * tau + backup["signed_stopping_displacement_m"],
            "maximum_position_m": maximum, "maximum_position_unbounded": maximum is None,
            "recovery_margin_m": margin, "margin_class": margin_class(margin),
            "backup_mode": backup["backup_mode"],
            "position_constraint_viable": prefix_safe and backup["position_constraint_viable"],
            "zero_velocity_terminal_reachable": prefix_safe and backup["zero_velocity_terminal_reachable"]}


def commit_case(distance, velocity, acceleration, factor, duration, position_boundary=ZERO):
    d, v, a, factor, duration, boundary = map(exact, (distance, velocity, acceleration, factor, duration, position_boundary))
    require(a >= 0 and duration >= 0 and abs(factor) <= 1, "Invalid input bound, factor or interval")
    u = factor * a
    segment = interval_extrema(boundary - d, v, u, duration)
    backup = immediate(boundary - segment["endpoint_position_m"], segment["endpoint_velocity_mps"], a, boundary)
    interval_safe = segment["maximum_position_m"] <= boundary
    maximum = None if backup["maximum_position_unbounded"] else max(segment["maximum_position_m"], backup["maximum_position_m"])
    margin = None if maximum is None else boundary - maximum
    return {"initial_position_m": boundary - d, "initial_velocity_mps": v,
            "braking_acceleration_mps2": a, "candidate_input_factor": factor,
            "candidate_input_mps2": u, "commit_interval_s": duration,
            "commit_endpoint_position_m": segment["endpoint_position_m"],
            "commit_endpoint_velocity_mps": segment["endpoint_velocity_mps"],
            "commit_endpoint_position_safe": segment["endpoint_position_m"] <= boundary,
            "commit_maximum_position_m": segment["maximum_position_m"],
            "commit_maximum_time_s": segment["maximum_time_s"],
            "interior_velocity_zero_checked": segment["interior_velocity_zero_checked"],
            "interior_velocity_zero_time_s": segment["interior_velocity_zero_time_s"],
            "extrema_candidates_checked": segment["extrema_candidates_checked"],
            "complete_commit_interval_safe": interval_safe,
            "backup_mode": backup["backup_mode"],
            "backup_stopping_time_s": backup["stopping_time_s"],
            "scheduled_terminal_time_s": None if backup["stopping_time_s"] is None else duration + backup["stopping_time_s"],
            "zero_velocity_position_m": backup["zero_velocity_position_m"],
            "endpoint_backup_position_viable": backup["position_constraint_viable"],
            "maximum_position_m": maximum, "maximum_position_unbounded": maximum is None,
            "recovery_margin_m": margin, "margin_class": margin_class(margin),
            "position_constraint_viable": interval_safe and backup["position_constraint_viable"],
            "zero_velocity_terminal_reachable": interval_safe and backup["zero_velocity_terminal_reachable"],
            "duplicate_action_within_base": a == 0}


def build_panels(config):
    base, delay, commit = [], [], []
    for d in config["distance_to_boundary_m"]:
        for v in config["initial_velocity_mps"]:
            for a in config["braking_acceleration_mps2"]:
                identity = f"d={number(d)}|v={number(v)}|a={number(a)}"
                common = {"base_identity": identity, "distance_to_boundary_m": d,
                          "position_boundary_m": config["position_boundary_m"], "dataset_role": "DETERMINISTIC_DEV"}
                base.append({"case_id": "base|" + identity, **common, **immediate(d, v, a, config["position_boundary_m"])})
                for tau in config["detection_delay_s"]:
                    delay.append({"case_id": f"delay|{identity}|tau={number(tau)}", **common,
                                  **delay_case(d, v, a, tau, config["position_boundary_m"])})
                for index, factor in enumerate(config["candidate_input_factors"]):
                    row = {"case_id": f"commit|{identity}|factor={number(factor)}", **common,
                           **commit_case(d, v, a, factor, config["commit_interval_s"], config["position_boundary_m"])}
                    row["action_equivalence_group"] = identity + "|u=" + number(row["candidate_input_mps2"])
                    row["action_representative"] = a != 0 or index == 0
                    commit.append(row)
    for rows, expected in ((base, 80), (delay, 240), (commit, 240)):
        require(len(rows) == len({row["case_id"] for row in rows}) == expected, "Fixed DEV identity coverage failed")
    return base, delay, commit


def illustrative_data():
    cases = [
        ("authority_loss", "a=1, immediate", "1", "1", "1", "0", "0.5"),
        ("authority_loss", "a=0.25, immediate", "1", "1", "0.25", "0", "2"),
        ("detection_delay", "tau=0, immediate", "2.1", "1", "0.25", "0", "2"),
        ("detection_delay", "tau=0.2, coast then brake", "2.1", "1", "0.25", "0.2", "2.2"),
    ]
    rows, metadata = [], []
    for group, label, ds, vs, acceleration, delay, expected_distance in cases:
        d, v, a, tau = map(exact, (ds, vs, acceleration, delay))
        analytic = delay_case(d, v, a, tau)
        require(analytic["total_signed_displacement_to_zero_m"] == exact(expected_distance), "Predeclared analytic trajectory expectation failed")
        stop = tau + v / a
        metadata.append({"group": group, "trajectory": label, "distance_to_boundary_m": d,
                         "initial_velocity_mps": v, "acceleration_mps2": a, "delay_s": tau,
                         "analytic_stopping_distance_m": analytic["total_signed_displacement_to_zero_m"],
                         "analytic_stop_time_s": stop, "analytic_maximum_position_m": analytic["maximum_position_m"],
                         "position_constraint_viable": analytic["position_constraint_viable"],
                         "zero_velocity_terminal_reachable": analytic["zero_velocity_terminal_reachable"]})
        for index in range(251):
            t = Fraction(index, 50)
            if t < tau:
                p, vel, u, phase = -d + v * t, v, ZERO, "DELAY_U_ZERO"
            elif t < stop:
                s = t - tau
                p, vel, u, phase = -d + v * tau + v * s - a * s * s / 2, v - a * s, -a, "MAX_BRAKING"
            else:
                p, vel, u, phase = -d + analytic["total_signed_displacement_to_zero_m"], ZERO, ZERO, "ZERO_SPEED_HOLD"
            rows.append({"trajectory_id": group + "|" + label, "group": group, "trajectory": label,
                         "sample_index": index, "time_s": t, "position_m": p, "velocity_mps": vel,
                         "input_mps2": u, "position_boundary_m": ZERO, "phase": phase,
                         "position_safe_at_display_sample": p <= 0,
                         "analytic_full_path_position_viable": analytic["position_constraint_viable"]})
    return rows, metadata


def write_csv(path, rows):
    with Path(path).open("x", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows({key: number(value) for key, value in row.items()} for row in rows)


def render_svg(path, rows, group, title, subtitle):
    """Native SVG from the same exact sampled rows as the trajectory CSV."""
    selected = [row for row in rows if row["group"] == group]
    names = list(dict.fromkeys(row["trajectory"] for row in selected))
    colors = ["#0072B2", "#D55E00"]
    W, H, left, right = 1020, 690, 86, 970
    chart_width = right - left
    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">',
             '<rect width="100%" height="100%" fill="white"/>',
             '<style>text{font-family:Arial,Helvetica,sans-serif;fill:#18212b} .tick{font-size:14px} .grid{stroke:#e2e6ea;stroke-width:1}</style>',
             f'<text x="86" y="36" font-size="24" font-weight="bold">{escape(title)}</text>',
             f'<text x="86" y="62" font-size="15">{escape(subtitle)}</text>']
    for j, name in enumerate(names):
        x = 100 + 420 * j
        parts += [f'<line x1="{x}" y1="91" x2="{x+34}" y2="91" stroke="{colors[j]}" stroke-width="3"/>',
                  f'<text x="{x+44}" y="96" font-size="16">{escape(name)}</text>']
    for panel, (key, label) in enumerate((("position_m", "Position p (m)"), ("velocity_mps", "Velocity v (m/s)"))):
        top, bottom = 125 + panel * 245, 325 + panel * 245
        values = [row[key] for row in selected] + [ZERO]
        lo, hi = float(min(values)), float(max(values))
        padding = max((hi - lo) * 0.08, 0.08)
        lo, hi = lo - padding, hi + padding
        px = lambda t: left + float(t) / 5 * chart_width
        py = lambda value: bottom - (float(value) - lo) / (hi - lo) * (bottom - top)
        for j in range(6):
            x = px(j)
            parts += [f'<line class="grid" x1="{x:.2f}" y1="{top}" x2="{x:.2f}" y2="{bottom}"/>',
                      f'<text class="tick" x="{x:.2f}" y="{bottom+23}" text-anchor="middle">{j}</text>']
        for j in range(5):
            value = lo + (hi - lo) * j / 4
            y = py(value)
            parts += [f'<line class="grid" x1="{left}" y1="{y:.2f}" x2="{right}" y2="{y:.2f}"/>',
                      f'<text class="tick" x="{left-10}" y="{y+5:.2f}" text-anchor="end">{value:.2f}</text>']
        parts += [f'<text x="{left}" y="{top-12}" font-size="16" font-weight="bold">{label}</text>',
                  f'<line x1="{left}" y1="{py(0):.2f}" x2="{right}" y2="{py(0):.2f}" stroke="#222" stroke-dasharray="7 5"/>']
        if panel == 0:
            parts.append(f'<text x="{right-4}" y="{py(0)-8:.2f}" text-anchor="end" font-size="13">p_max = 0</text>')
        for j, name in enumerate(names):
            points = " ".join(f'{px(row["time_s"]):.3f},{py(row[key]):.3f}' for row in selected if row["trajectory"] == name)
            parts.append(f'<polyline fill="none" stroke="{colors[j]}" stroke-width="3" points="{points}"/>')
        parts.append(f'<rect x="{left}" y="{top}" width="{chart_width}" height="{bottom-top}" fill="none" stroke="#68737d"/>')
    parts += ['<text x="528" y="622" text-anchor="middle" font-size="16">Time (s)</text>',
              '<text x="86" y="658" font-size="13">Closed-form trajectories; 0.02 s samples for display only. Continuous-time extrema determine safety.</text>',
              '</svg>']
    Path(path).write_text("\n".join(parts) + "\n", encoding="utf-8", newline="\n")


def source_hashes(config):
    paths = [Path(__file__), Path(config), ROOT / "tests/test_e2_analytic.py"]
    return {str(path.resolve().relative_to(ROOT)).replace("\\", "/"): sha(path) for path in paths}


def _development_elapsed(result):
    return (datetime.now(timezone.utc) - datetime.fromisoformat(result["development_started_utc"])).total_seconds()


def check_tests(config_path, output, result):
    require(result.get("formal_export_attempts", 0) == 0 and result["status"] != "CONFIG_FROZEN", "No tests/refinement after export freeze")
    require(_development_elapsed(result) < DEVELOPMENT_LIMIT_S, "Implementation/test time cap reached")
    started, begin = utc(), time.perf_counter()
    buffer = io.StringIO()
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"), pattern="test_e2_analytic.py")
    checked = unittest.TextTestRunner(stream=buffer, verbosity=2).run(suite)
    record = {"started_utc": started, "duration_s": time.perf_counter() - begin,
              "tests_run": checked.testsRun, "failures": len(checked.failures), "errors": len(checked.errors),
              "passed": checked.wasSuccessful(), "source_hashes": source_hashes(config_path),
              "command": "python -B -X utf8 -m cavr_wbc.experiments.e2_analytic --check",
              "log": buffer.getvalue(), "optimization_calls": 0}
    result.setdefault("development_runs", []).append(record)
    result.update(status="TESTED" if checked.wasSuccessful() else "DEVELOPMENT_TEST_FAILURE",
                  development_elapsed_s=_development_elapsed(result))
    save_result(output, result)
    print(buffer.getvalue(), flush=True)
    require(checked.wasSuccessful(), "E2 analytic development tests failed")


def freeze(config_path, output, result):
    require(result.get("formal_export_attempts", 0) == 0 and result["status"] != "CONFIG_FROZEN", "Freeze/export already exists")
    require(_development_elapsed(result) < DEVELOPMENT_LIMIT_S, "Implementation/test time cap reached")
    load_config(config_path)
    tests = result.get("development_runs", [])
    require(tests and tests[-1]["passed"] and tests[-1]["source_hashes"] == source_hashes(config_path), "Current source lacks passing tests")
    documentation = {name: sha(output / name) for name in ("E2_ANALYTIC_PROTOCOL.md", "E2_QUADRUPED_DESIGN.md")}
    result.update(status="CONFIG_FROZEN", freeze_utc=utc(), frozen_source_hashes=source_hashes(config_path),
                  frozen_documentation_hashes=documentation, development_elapsed_s=_development_elapsed(result))
    save_result(output, result)
    print("M CONFIG_FROZEN before formal export; 80/240/240 identities; zero optimizers", flush=True)


def report_text(result):
    counts = result["panel_summary"]
    text = PASSPORT + "# E2-A 解析机制结果\n\n"
    text += "E2_ANALYTIC_RESULT = PASS。固定 DEV 身份完整覆盖：基础80、延迟240、提交240；它们不是独立随机样本。全部分类由连续时间解析式给出，不由轨迹采样判定。\n\n"
    text += "模型为 p_dot=v、v_dot=u、|u|<=a、p<=0。初始位置必须安全；a>0,v>0 的停止距离 v²/(2a)，v<=0 的反向刹停不增加最大位置。a=0,v<0 可一直远离单侧上界，却无法到达零速度终端；两类标签严格分开。这里的安全零终端可达要求整个路径安全，不仅速度最终为零。\n\n"
    text += "|面板|身份|位置约束可维持|安全零速度终端可达|精确边界|\n|---|---:|---:|---:|---:|\n"
    for name in ("base", "delay", "commit"):
        row = counts[name]
        text += f"|{name}|{row['rows']}|{row['position_viable']}|{row['zero_terminal']}|{row['exact_boundary']}|\n"
    text += "\n这些计数仅描述固定输入覆盖，不是成功概率。a=0 的20个基础状态各产生三个相同提交动作：60行保留、200个独特状态-动作，不能把重复动作当新证据。\n\n"
    text += "精确边界身份单列（完整身份保留在CSV和RESULT）：\n\n|面板|d (m)|v (m/s)|a (m/s²)|附加参数|\n|---|---:|---:|---:|---|\n"
    for name, rows in result["boundary_cases"].items():
        for row in rows:
            extra = "—" if name == "base" else "tau=" + number(row["detection_delay_s"]) if name == "delay" else "factor=" + number(row["candidate_input_factor"])
            text += f"|{name}|{number(row['distance_to_boundary_m'])}|{number(row['initial_velocity_mps'])}|{number(row['braking_acceleration_mps2'])}|{extra}|\n"
    text += "\n"
    text += "## 两个预先指定机制对比\n\n"
    text += "1. d=1,v=1：a=1 停止距离0.5 m，a=0.25停止距离2 m；最大位置分别−0.5 m和1 m。第二条在故障发生时已在新停止域外，任何满足给定输入界的控制都无法在边界前制动；不要求过滤器救回该状态。\n"
    text += "2. d=2.1,v=1,a=0.25：立即制动2 m，先u=0延迟0.2 s再制动2.2 m；最大位置分别−0.1 m和0.1 m。延迟消耗原有0.1 m余量。延迟期间u=0是本例明确假设，不代表一般故障控制策略。\n\n"
    text += "两幅SVG与 illustrative_trajectories.csv 来自同一次代码计算；251采样点/轨迹，4轨迹共1004行。位置上界线、速度和停住后的保持段均使用同一数据；曲线是解析展示，不是机器人或离散仿真测量。\n\n"
    text += "## 提交区间与边界\n\n"
    text += "对恒定候选输入，检查t=0、t=Delta与内部v(t)=0处的连续位置极值，再检查终点备份全程及零速度终端。测试含两端安全而中间越界的手算反例：d=0.004,v=1,u=−100,Delta=0.02，峰值p=0.001>0；这不是固定DEV网格中的新增实验身份。边界使用有限小数到Fraction的精确转换，不用舍入差创造效果。所有a=0、v<=0、初始越界、延迟临界及零时长分支均覆盖。\n\n"
    text += "## 运行与范围\n\n"
    text += f"开发测试执行{len(result['development_runs'])}轮，最后{result['development_runs'][-1]['tests_run']}项通过；正式导出{result['formal_export_attempts']}次。开发耗时{result['development_elapsed_s']:.3f}s，上限5400s；导出耗时{result['export_elapsed_s']:.3f}s，上限900s。配置及代码/测试在导出前冻结，具体时间、SHA256、命令和全部开发测试日志保存在RESULT。\n\n"
    text += "只使用Python标准库，优化器导入/构造/调用均为0。零独立重跑，因此验证等级ANALYZED；单位测试与保存CSV结构核对不伪称独立研究复现。无新机器人执行、E1/E2-B、训练或性能数据。四足设计另见E2_QUADRUPED_DESIGN；真实制动能力须由全身约束、独立动力学、备份终端及完整提交区间验证。M与STEP-02I结果独立。\n\n"
    text += "统计/方法风险11/11检查：Simpson（按条件保留）、生态谬误（不外推四足）、Berkson（固定DEV非随机）、collider（无统计因果模型）、基率（完整分母）、回归均值（无重复试验改善）、幸存者（保留全部域外和退化条件）、look-elsewhere（两图预定）、分析路径自由度（记录开发与冻结、不称预注册）、相关非因果（机制来自声明方程）、反向因果（不从结果倒推一般故障机制）。p值、功效和抽样置信区间不适用。\n\n"
    text += "EXACT_CERTIFICATE_BRANCH = CLOSED\nE2_ANALYTIC_OPTIMIZATION_CALLS = 0\nE1_AUTHORIZED = FALSE\nE2_QUADRUPED_AUTHORIZED = FALSE\n"
    return text


def export(config_path, output, result):
    require(result["status"] == "CONFIG_FROZEN" and result.get("formal_export_attempts", 0) == 0, "One formal export requires prior freeze")
    require(result["frozen_source_hashes"] == source_hashes(config_path), "Source/config/test changed after freeze")
    for name, digest in result["frozen_documentation_hashes"].items():
        require(sha(output / name) == digest, "Protocol/design changed after freeze")
    result.update(status="EXPORT_RUNNING", formal_export_attempts=1, export_started_utc=utc(),
                  export_command="python -B -X utf8 -m cavr_wbc.experiments.e2_analytic --config configs/dev/e2_analytic.yaml --output artifacts/e2_analytic")
    save_result(output, result)
    start = time.perf_counter()
    try:
        config = load_config(config_path)
        base, delay, commit = build_panels(config)
        samples, trajectories = illustrative_data()
        baseline = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
        branch = subprocess.check_output(["git", "branch", "--show-current"], cwd=ROOT, text=True).strip()
        for filename, rows in (("base_cases.csv", base), ("delay_cases.csv", delay), ("commit_cases.csv", commit), ("illustrative_trajectories.csv", samples)):
            require(time.perf_counter() - start < EXPORT_LIMIT_S, "Analytic export time cap")
            write_csv(output / filename, rows)
            print(f"EXPORTED {filename}: {len(rows)} rows", flush=True)
        (output / "figures").mkdir(exist_ok=True)
        render_svg(output / "figures/braking_authority_comparison.svg", samples, "authority_loss", "Braking authority changes the stopping domain", "d = 1 m, v = 1 m/s; stopping distances: 0.5 m and 2 m")
        render_svg(output / "figures/detection_delay_comparison.svg", samples, "detection_delay", "Detection delay consumes the recovery margin", "d = 2.1 m, v = 1 m/s, a = 0.25 m/s²; stopping distances: 2 m and 2.2 m")
        panel_summary = {name: {"rows": len(rows), "unique_identities": len({r["case_id"] for r in rows}),
                                   "position_viable": sum(r["position_constraint_viable"] for r in rows),
                                   "zero_terminal": sum(r["zero_velocity_terminal_reachable"] for r in rows),
                                   "exact_boundary": sum(r["margin_class"] == "BOUNDARY" for r in rows),
                                   "mode_counts": dict(Counter(r["backup_mode"] for r in rows))}
                         for name, rows in (("base", base), ("delay", delay), ("commit", commit))}
        boundary_keys = ("case_id", "distance_to_boundary_m", "initial_velocity_mps", "braking_acceleration_mps2", "detection_delay_s", "candidate_input_factor")
        boundary_cases = {name: [{key: row[key] for key in boundary_keys if key in row}
                                 for row in rows if row["margin_class"] == "BOUNDARY"]
                          for name, rows in (("base", base), ("delay", delay), ("commit", commit))}
        for filename, expected_rows, key in (("base_cases.csv", base, "case_id"), ("delay_cases.csv", delay, "case_id"), ("commit_cases.csv", commit, "case_id"), ("illustrative_trajectories.csv", samples, "trajectory_id")):
            with (output / filename).open(encoding="utf-8", newline="") as stream:
                saved = list(csv.DictReader(stream))
            expected_saved = [{key: number(value) for key, value in row.items()} for row in expected_rows]
            require(saved == expected_saved, "Saved CSV differs from computed exact/display rows")
            identities = {row[key] if key == "case_id" else (row[key], row["sample_index"]) for row in saved}
            require(len(identities) == len(expected_rows), "Saved CSV identity check failed")
        require(time.perf_counter() - start < EXPORT_LIMIT_S, "Analytic export time cap")
        result.update(status="PASS", export_finished_utc=utc(), export_elapsed_s=time.perf_counter() - start,
                      panel_summary=panel_summary, boundary_cases=boundary_cases, trajectories=trajectories, illustrative_trajectory_rows=len(samples),
                      zero_acceleration_duplicate_action_rows=sum(r["duplicate_action_within_base"] for r in commit),
                      unique_commit_state_actions=len({r["action_equivalence_group"] for r in commit}),
                      boundary_classification="exact rational arithmetic on finite decimal inputs; no acceptance epsilon",
                      figures_generated_from_same_export_rows=True, saved_csv_coverage_checked=True,
                      environment={"python": sys.version, "executable": sys.executable, "stdlib_only": True,
                                   "bytecode_disabled": sys.dont_write_bytecode},
                      baseline_commit=baseline, branch=branch,
                      optimizer_imports=0, optimizer_constructions=0, optimization_calls=0,
                      E1_AUTHORIZED=False, E2_QUADRUPED_AUTHORIZED=False, exact_certificate_branch="CLOSED",
                      verification_status="ANALYZED", inference_scope=config["inference_scope"])
        (output / "E2_ANALYTIC_REPORT.md").write_text(report_text(result), encoding="utf-8", newline="\n")
        result["output_sha256"] = {str(path.relative_to(output)).replace("\\", "/"): sha(path)
                                   for path in sorted(output.rglob("*")) if path.is_file() and path.name != "E2_ANALYTIC_RESULT.json"}
        save_result(output, result)
        print("E2_ANALYTIC_RESULT = PASS; identities80/240/240; optimizer calls0", flush=True)
    except BaseException as exc:
        result.update(status="EXPORT_INCOMPLETE", export_elapsed_s=time.perf_counter() - start, error=repr(exc))
        save_result(output, result)
        raise


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/dev/e2_analytic.yaml")
    parser.add_argument("--output", default="artifacts/e2_analytic")
    action = parser.add_mutually_exclusive_group()
    action.add_argument("--check", action="store_true")
    action.add_argument("--freeze", action="store_true")
    args = parser.parse_args()
    config_path, output = (ROOT / args.config).resolve(), (ROOT / args.output).resolve()
    require(output == ROOT / "artifacts/e2_analytic", "E2 output is confined to its assigned artifact directory")
    require(config_path == ROOT / "configs/dev/e2_analytic.yaml", "Use fixed DEV config")
    result = json.loads((output / "E2_ANALYTIC_RESULT.json").read_text(encoding="utf-8"))
    if args.check:
        check_tests(config_path, output, result)
    elif args.freeze:
        freeze(config_path, output, result)
    else:
        export(config_path, output, result)


if __name__ == "__main__":
    main()
