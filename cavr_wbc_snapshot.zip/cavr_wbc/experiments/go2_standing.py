"""Deterministic healthy Go2 standing replay used by STEP-01B and E0."""

from __future__ import annotations

from dataclasses import dataclass
import json
import math
from pathlib import Path
import time
from typing import Any, Iterable

import mujoco
import numpy as np

from cavr_wbc.control import JointPdController
from cavr_wbc.models import ActuatorHealthModel, apply_physical_actuator_bounds
from cavr_wbc.platforms.go2_mujoco import (
    DEFAULT_GO2_MODEL_PATH,
    contact_diagnostics,
    extract_actuator_joint_map,
    extract_healthy_torque_limits,
    joint_tau_from_qfrc,
    load_go2_model,
)


RUNTIME_TIMING_KEYS = (
    "state_read",
    "controller_compute",
    "health_filter",
    "actuator_write",
    "physics_step",
    "logging",
    "total_control_latency",
)


def _finite_list(name: str, values: Iterable[float]) -> list[float]:
    result = [float(value) for value in values]
    if not all(math.isfinite(value) for value in result):
        raise ValueError(f"{name} must contain only finite values")
    return result


@dataclass(frozen=True)
class Go2RuntimeStepRecord:
    run_id: str
    scenario_id: str
    health_adapter_active: bool
    time: float
    q: tuple[float, ...]
    v: tuple[float, ...]
    u_raw: tuple[float, ...]
    u_health: tuple[float, ...]
    ctrl_written: tuple[float, ...]
    actuator_force: tuple[float, ...]
    qfrc_actuator: tuple[float, ...]
    joint_tau_applied: tuple[float, ...]
    rho: tuple[float, ...]
    actuator_saturation_mask: tuple[bool, ...]
    contact_state: dict[str, Any]
    simulation_step: int
    controller_step: int
    controller_diagnostics: dict[str, Any]
    timings: dict[str, float]

    def __post_init__(self) -> None:
        if not math.isfinite(float(self.time)) or self.time < 0.0:
            raise ValueError("time must be finite and non-negative")
        if self.simulation_step < 0 or self.controller_step < 0:
            raise ValueError("step indices must be non-negative")
        fields = (
            ("q", self.q),
            ("v", self.v),
            ("u_raw", self.u_raw),
            ("u_health", self.u_health),
            ("ctrl_written", self.ctrl_written),
            ("actuator_force", self.actuator_force),
            ("qfrc_actuator", self.qfrc_actuator),
            ("joint_tau_applied", self.joint_tau_applied),
            ("rho", self.rho),
        )
        checked = {name: _finite_list(name, values) for name, values in fields}
        actuator_lengths = {
            len(checked[name])
            for name in (
                "u_raw",
                "u_health",
                "ctrl_written",
                "actuator_force",
                "joint_tau_applied",
                "rho",
            )
        }
        actuator_lengths.add(len(self.actuator_saturation_mask))
        if len(actuator_lengths) != 1:
            raise ValueError("all actuator-space fields must have matching lengths")
        if not all(0.0 <= value <= 1.0 for value in checked["rho"]):
            raise ValueError("rho must lie in [0, 1]")
        if set(self.timings) != set(RUNTIME_TIMING_KEYS):
            raise ValueError("runtime timing keys are incomplete or contain extras")
        if not all(
            math.isfinite(float(value)) and float(value) >= 0.0
            for value in self.timings.values()
        ):
            raise ValueError("runtime timings must be finite and non-negative")

    def as_dict(self) -> dict[str, Any]:
        return {
            "run_id": self.run_id,
            "scenario_id": self.scenario_id,
            "health_adapter_active": self.health_adapter_active,
            "time": self.time,
            "q": list(self.q),
            "v": list(self.v),
            "u_raw": list(self.u_raw),
            "u_health": list(self.u_health),
            "ctrl_written": list(self.ctrl_written),
            "actuator_force": list(self.actuator_force),
            "qfrc_actuator": list(self.qfrc_actuator),
            "joint_tau_applied": list(self.joint_tau_applied),
            "rho": list(self.rho),
            "actuator_saturation_mask": list(self.actuator_saturation_mask),
            "contact_state": self.contact_state,
            "simulation_step": self.simulation_step,
            "controller_step": self.controller_step,
            "controller_diagnostics": self.controller_diagnostics,
            "timings": self.timings,
        }


@dataclass
class StandingRunResult:
    summary: dict[str, Any]
    traces: dict[str, np.ndarray]


def _roll_pitch(quaternion: np.ndarray) -> tuple[float, float]:
    w, x, y, z = (float(value) for value in quaternion)
    sin_roll = 2.0 * (w * x + y * z)
    cos_roll = 1.0 - 2.0 * (x * x + y * y)
    roll = math.atan2(sin_roll, cos_roll)
    sin_pitch = 2.0 * (w * y - z * x)
    pitch = math.asin(max(-1.0, min(1.0, sin_pitch)))
    return roll, pitch


def _warnings(data: mujoco.MjData) -> list[dict[str, int]]:
    result = []
    for index in range(len(data.warning)):
        warning = data.warning[index]
        if int(warning.number) > 0:
            result.append(
                {
                    "warning_index": index,
                    "number": int(warning.number),
                    "lastinfo": int(warning.lastinfo),
                }
            )
    return result


def run_go2_standing(
    *,
    duration_s: float,
    kp: Iterable[float],
    kd: Iterable[float],
    rho: Iterable[float],
    health_adapter_active: bool,
    run_id: str,
    scenario_id: str = "GO2_DEV_STAND_001",
    model_path: str | Path = DEFAULT_GO2_MODEL_PATH,
    output_jsonl: str | Path | None = None,
    append_jsonl: bool = False,
) -> StandingRunResult:
    """Run one deterministic torque-controlled standing replay."""

    model = load_go2_model(model_path)
    data = mujoco.MjData(model)
    home_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_KEY, "home")
    if home_id < 0:
        raise ValueError("Pinned Go2 model has no 'home' keyframe")
    mujoco.mj_resetDataKeyframe(model, data, home_id)
    data.ctrl[:] = 0.0
    mujoco.mj_forward(model, data)

    mapping = extract_actuator_joint_map(model)
    qpos_addresses = np.asarray([entry.joint_id for entry in mapping], dtype=int)
    qpos_addresses = model.jnt_qposadr[qpos_addresses]
    q_reference = data.qpos[qpos_addresses].copy()
    controller = JointPdController(
        kp=np.asarray(tuple(kp), dtype=float),
        kd=np.asarray(tuple(kd), dtype=float),
        q_reference=q_reference,
        include_bias_compensation=True,
    )
    health = np.asarray(tuple(rho), dtype=float)
    limits = extract_healthy_torque_limits(model)
    if health.shape != (model.nu,):
        raise ValueError("rho shape must equal model.nu")
    health_model = ActuatorHealthModel()

    steps_float = duration_s / model.opt.timestep
    number_of_steps = int(round(steps_float))
    if duration_s <= 0.0 or not math.isclose(
        steps_float, number_of_steps, rel_tol=0.0, abs_tol=1e-9
    ):
        raise ValueError("duration_s must be a positive integer multiple of timestep")

    output_handle = None
    if output_jsonl is not None:
        output = Path(output_jsonl)
        output.parent.mkdir(parents=True, exist_ok=True)
        output_handle = output.open(
            "a" if append_jsonl else "w", encoding="utf-8", newline="\n"
        )

    trace_names = (
        "q",
        "v",
        "u_raw",
        "u_health",
        "ctrl_written",
        "actuator_force",
        "qfrc_actuator",
        "joint_tau_applied",
    )
    trace_lists: dict[str, list[np.ndarray]] = {name: [] for name in trace_names}
    base_heights: list[float] = []
    rolls: list[float] = []
    pitches: list[float] = []
    contact_feet_counts: list[int] = []
    foot_contact_steps = {name: 0 for name in ("FL", "FR", "RL", "RR")}
    saturation_steps = 0
    max_ctrl_health_error = 0.0
    max_force_ctrl_error = 0.0
    max_joint_force_error = 0.0

    try:
        for step in range(number_of_steps):
            loop_start = time.perf_counter()

            start = time.perf_counter()
            q = data.qpos.copy()
            v = data.qvel.copy()
            state_read = time.perf_counter() - start

            start = time.perf_counter()
            u_raw, controller_diagnostics = controller.compute(model, data)
            controller_compute = time.perf_counter() - start

            start = time.perf_counter()
            if health_adapter_active:
                health_result = health_model.apply(u_raw, health, limits)
                u_health = np.asarray(health_result.u_health, dtype=float)
                saturation_mask = np.asarray(
                    health_result.saturation_mask, dtype=bool
                )
            else:
                u_health = np.asarray(
                    apply_physical_actuator_bounds(u_raw, limits), dtype=float
                )
                saturation_mask = np.not_equal(u_raw, u_health)
            health_filter = time.perf_counter() - start

            start = time.perf_counter()
            data.ctrl[:] = u_health
            ctrl_written = data.ctrl.copy()
            actuator_write = time.perf_counter() - start

            # Evaluate the actual MuJoCo actuator and transmission path at the
            # same pre-integration state and control value.
            mujoco.mj_forward(model, data)
            actuator_force = data.actuator_force.copy()
            qfrc_actuator = data.qfrc_actuator.copy()
            joint_tau_applied = joint_tau_from_qfrc(model, data)
            contacts = contact_diagnostics(model, data)

            start = time.perf_counter()
            mujoco.mj_step(model, data)
            physics_step = time.perf_counter() - start

            for name, value in (
                ("q", q),
                ("v", v),
                ("u_raw", u_raw),
                ("u_health", u_health),
                ("ctrl_written", ctrl_written),
                ("actuator_force", actuator_force),
                ("qfrc_actuator", qfrc_actuator),
                ("joint_tau_applied", joint_tau_applied),
            ):
                trace_lists[name].append(np.asarray(value, dtype=float).copy())

            base_heights.append(float(q[2]))
            roll, pitch = _roll_pitch(q[3:7])
            rolls.append(roll)
            pitches.append(pitch)
            count = sum(bool(value["present"]) for value in contacts.values())
            contact_feet_counts.append(count)
            for name, value in contacts.items():
                foot_contact_steps[name] += int(bool(value["present"]))
            saturation_steps += int(bool(np.any(saturation_mask)))
            max_ctrl_health_error = max(
                max_ctrl_health_error,
                float(np.max(np.abs(ctrl_written - u_health))),
            )
            max_force_ctrl_error = max(
                max_force_ctrl_error,
                float(np.max(np.abs(actuator_force - ctrl_written))),
            )
            max_joint_force_error = max(
                max_joint_force_error,
                float(np.max(np.abs(joint_tau_applied - actuator_force))),
            )

            timings = {
                "state_read": state_read,
                "controller_compute": controller_compute,
                "health_filter": health_filter,
                "actuator_write": actuator_write,
                "physics_step": physics_step,
                "logging": 0.0,
                "total_control_latency": 0.0,
            }
            record = Go2RuntimeStepRecord(
                run_id=run_id,
                scenario_id=scenario_id,
                health_adapter_active=health_adapter_active,
                time=float(step * model.opt.timestep),
                q=tuple(float(value) for value in q),
                v=tuple(float(value) for value in v),
                u_raw=tuple(float(value) for value in u_raw),
                u_health=tuple(float(value) for value in u_health),
                ctrl_written=tuple(float(value) for value in ctrl_written),
                actuator_force=tuple(float(value) for value in actuator_force),
                qfrc_actuator=tuple(float(value) for value in qfrc_actuator),
                joint_tau_applied=tuple(float(value) for value in joint_tau_applied),
                rho=tuple(float(value) for value in health),
                actuator_saturation_mask=tuple(
                    bool(value) for value in saturation_mask
                ),
                contact_state=contacts,
                simulation_step=step,
                controller_step=step,
                controller_diagnostics=controller_diagnostics,
                timings=timings,
            )
            start = time.perf_counter()
            json.dumps(record.as_dict(), allow_nan=False, separators=(",", ":"))
            logging_duration = time.perf_counter() - start
            timings["logging"] = logging_duration
            timings["total_control_latency"] = time.perf_counter() - loop_start
            if output_handle is not None:
                output_handle.write(
                    json.dumps(
                        record.as_dict(), allow_nan=False, separators=(",", ":")
                    )
                )
                output_handle.write("\n")
    finally:
        if output_handle is not None:
            output_handle.close()

    traces = {name: np.stack(values) for name, values in trace_lists.items()}
    all_finite = all(np.isfinite(values).all() for values in traces.values())
    max_joint_error = float(
        np.max(np.abs(traces["q"][:, qpos_addresses] - q_reference[None, :]))
    )
    warnings = _warnings(data)
    standing_valid = (
        all_finite
        and min(base_heights) >= 0.20
        and max(abs(value) for value in rolls) <= 0.35
        and max(abs(value) for value in pitches) <= 0.35
        and min(contact_feet_counts) == 4
        and not warnings
    )
    summary = {
        "run_id": run_id,
        "scenario_id": scenario_id,
        "health_adapter_active": health_adapter_active,
        "duration_s": duration_s,
        "physics_dt_s": float(model.opt.timestep),
        "controller_dt_s": float(model.opt.timestep),
        "steps": number_of_steps,
        "rho": health.astype(float).tolist(),
        "all_finite": all_finite,
        "mujoco_warnings": warnings,
        "min_base_height_m": min(base_heights),
        "max_base_height_m": max(base_heights),
        "max_abs_roll_rad": max(abs(value) for value in rolls),
        "max_abs_pitch_rad": max(abs(value) for value in pitches),
        "max_abs_joint_position_error_rad": max_joint_error,
        "minimum_simultaneous_foot_contacts": min(contact_feet_counts),
        "foot_contact_fraction": {
            name: count / number_of_steps
            for name, count in foot_contact_steps.items()
        },
        "actuator_saturation_steps": saturation_steps,
        "max_abs_ctrl_written_minus_u_health": max_ctrl_health_error,
        "max_abs_actuator_force_minus_ctrl_written": max_force_ctrl_error,
        "max_abs_joint_tau_minus_actuator_force": max_joint_force_error,
        "standing_valid": standing_valid,
        "standing_valid_definition": {
            "minimum_base_height_m": 0.20,
            "maximum_abs_roll_rad": 0.35,
            "maximum_abs_pitch_rad": 0.35,
            "required_simultaneous_foot_contacts": 4,
            "requires_finite_state": True,
            "requires_no_mujoco_warning": True,
        },
    }
    return StandingRunResult(summary=summary, traces=traces)


def compare_full_stack_identity(
    bypass: StandingRunResult,
    health: StandingRunResult,
    tolerance: float = 1e-12,
) -> dict[str, Any]:
    """Compare deterministic bypass and rho=1 health-adapter runs."""

    fields = (
        "u_raw",
        "u_health",
        "ctrl_written",
        "actuator_force",
        "joint_tau_applied",
        "qfrc_actuator",
        "q",
        "v",
    )
    comparisons: dict[str, Any] = {}
    for field in fields:
        left = bypass.traces[field]
        right = health.traces[field]
        if left.shape != right.shape:
            comparisons[field] = {
                "shape_match": False,
                "bypass_shape": list(left.shape),
                "health_shape": list(right.shape),
                "max_abs_difference": None,
                "exact_equal": False,
                "within_tolerance": False,
            }
            continue
        maximum = float(np.max(np.abs(left - right)))
        comparisons[field] = {
            "shape_match": True,
            "shape": list(left.shape),
            "max_abs_difference": maximum,
            "exact_equal": bool(np.array_equal(left, right)),
            "within_tolerance": maximum <= tolerance,
        }
    return {
        "tolerance": tolerance,
        "comparisons": comparisons,
        "all_within_tolerance": all(
            item["within_tolerance"] for item in comparisons.values()
        ),
        "all_exact_equal": all(item["exact_equal"] for item in comparisons.values()),
    }
