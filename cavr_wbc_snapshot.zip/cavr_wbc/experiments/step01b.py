"""Generate the frozen-platform STEP-01B audit and healthy replay artifacts."""

from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
from pathlib import Path
import subprocess
from typing import Any

import mujoco
import numpy as np
import yaml

from cavr_wbc.experiments.go2_standing import (
    compare_full_stack_identity,
    run_go2_standing,
)
from cavr_wbc.platforms.go2_mujoco import (
    DEFAULT_GO2_MODEL_PATH,
    extract_actuator_audit,
    extract_actuator_joint_map,
    extract_healthy_torque_limits,
    joint_tau_from_qfrc,
    load_go2_model,
)


UPSTREAM_URL = "https://github.com/unitreerobotics/unitree_mujoco.git"
UPSTREAM_COMMIT = "1eb6642e3f3fdfb7fb13a9794fd6a2dd93ea0e7d"
ACQUISITION_TIMESTAMP = "2026-09-17T20:39:46.8219419+09:00"
SNAPSHOT_ROOT = Path("third_party/unitree_mujoco_snapshot")
GO2_ROOT = SNAPSHOT_ROOT / "unitree_robots/go2"


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n",
        encoding="utf-8",
    )


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _git(*args: str) -> str:
    return subprocess.check_output(
        ["git", *args], text=True, encoding="utf-8"
    ).strip()


def upstream_manifest() -> dict[str, Any]:
    files = []
    for path in sorted(item for item in SNAPSHOT_ROOT.rglob("*") if item.is_file()):
        files.append(
            {
                "path": path.as_posix(),
                "size_bytes": path.stat().st_size,
                "sha256": _sha256(path),
            }
        )
    xml_hashes = {
        path.relative_to(SNAPSHOT_ROOT).as_posix(): _sha256(path)
        for path in sorted(GO2_ROOT.glob("*.xml"))
    }
    return {
        "repository_url": UPSTREAM_URL,
        "resolved_commit": UPSTREAM_COMMIT,
        "acquisition_timestamp": ACQUISITION_TIMESTAMP,
        "acquisition_method": "shallow clone followed by history-free Go2-only snapshot copy",
        "license": "BSD-3-Clause",
        "license_path": (SNAPSHOT_ROOT / "LICENSE").as_posix(),
        "snapshot_scope": [
            "LICENSE",
            "readme.md",
            "readme_zh.md",
            "unitree_robots/go2/**",
        ],
        "go2_asset_root": GO2_ROOT.as_posix(),
        "primary_model": DEFAULT_GO2_MODEL_PATH.as_posix(),
        "xml_sha256": xml_hashes,
        "all_snapshot_files": files,
        "acquisition_warnings": [
            "The full upstream shallow clone reported a case collision only in unitree_robots/go2w; the retained unitree_robots/go2 snapshot was unaffected.",
            "The local acquisition checkout is Git-ignored; scientific execution uses the history-free pinned snapshot.",
        ],
    }


def dependency_manifest() -> dict[str, Any]:
    packages = (
        "mujoco",
        "numpy",
        "PyYAML",
        "matplotlib",
        "absl-py",
        "contourpy",
        "cycler",
        "etils",
        "fonttools",
        "fsspec",
        "glfw",
        "kiwisolver",
        "packaging",
        "pillow",
        "PyOpenGL",
        "pyparsing",
        "python-dateutil",
        "six",
        "typing_extensions",
        "zipp",
    )
    versions = {package: importlib.metadata.version(package) for package in packages}
    return {
        "python": subprocess.check_output(
            ["python", "--version"], text=True, encoding="utf-8"
        ).strip(),
        "requirements_file": "requirements-step01b.txt",
        "direct_requirements": {
            key: versions[key]
            for key in ("mujoco", "numpy", "PyYAML", "matplotlib")
        },
        "installed_stage_dependencies": versions,
        "osqp_installed_for_step01b": False,
        "rl_libraries_installed_for_step01b": False,
    }


def model_compile_audit() -> tuple[mujoco.MjModel, dict[str, Any]]:
    absolute_error = None
    try:
        mujoco.MjModel.from_xml_path(str(DEFAULT_GO2_MODEL_PATH.resolve()))
    except Exception as exc:  # exact native path compatibility evidence
        absolute_error = f"{type(exc).__name__}: {exc}"

    model = load_go2_model()
    actuator_names = [
        mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_ACTUATOR, index)
        for index in range(model.nu)
    ]
    joint_names = [
        mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_JOINT, index)
        for index in range(model.njnt)
    ]
    audit = {
        "status": "PASS",
        "model_path": DEFAULT_GO2_MODEL_PATH.as_posix(),
        "model_untouched": True,
        "mujoco_version": mujoco.__version__,
        "nq": model.nq,
        "nv": model.nv,
        "nu": model.nu,
        "number_of_bodies": model.nbody,
        "number_of_joints": model.njnt,
        "number_of_geoms": model.ngeom,
        "number_of_sites": model.nsite,
        "simulation_timestep_s": float(model.opt.timestep),
        "integrator": mujoco.mjtIntegrator(int(model.opt.integrator)).name,
        "actuator_names": actuator_names,
        "joint_names": joint_names,
        "absolute_path_compatibility_attempt": {
            "status": "FAIL" if absolute_error else "PASS",
            "error": absolute_error,
            "diagnosis": (
                "MuJoCo 3.13.0 native XML loading on this Windows host corrupts the non-ASCII absolute workspace path; the byte-identical model compiles through a repository-relative path."
                if absolute_error
                else None
            ),
        },
        "relative_path_compile": "PASS",
    }
    return model, audit


def direct_actuator_audit(model: mujoco.MjModel, output_csv: Path) -> dict[str, Any]:
    mapping = extract_actuator_joint_map(model)
    home_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_KEY, "home")
    rows = []
    for entry in mapping:
        for command in (-1.0, 1.0):
            data = mujoco.MjData(model)
            mujoco.mj_resetDataKeyframe(model, data, home_id)
            data.ctrl[:] = 0.0
            data.ctrl[entry.actuator_index] = command
            mujoco.mj_forward(model, data)
            joint_tau = joint_tau_from_qfrc(model, data)
            non_target = np.delete(data.qfrc_actuator, entry.dof_index)
            measured_force = float(data.actuator_force[entry.actuator_index])
            measured_tau = float(joint_tau[entry.actuator_index])
            rows.append(
                {
                    "actuator_index": entry.actuator_index,
                    "actuator_name": entry.actuator_name,
                    "joint_name": entry.joint_name,
                    "joint_id": entry.joint_id,
                    "dof_index": entry.dof_index,
                    "command": command,
                    "ctrl_written": float(data.ctrl[entry.actuator_index]),
                    "actuator_force": measured_force,
                    "joint_tau_applied": measured_tau,
                    "max_abs_non_target_qfrc_actuator": float(
                        np.max(np.abs(non_target))
                    ),
                    "sign_consistent": (
                        np.sign(command)
                        == np.sign(measured_force)
                        == np.sign(measured_tau)
                    ),
                }
            )
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    with output_csv.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    return {
        "rows": len(rows),
        "all_sign_consistent": all(bool(row["sign_consistent"]) for row in rows),
        "max_abs_ctrl_minus_command": max(
            abs(float(row["ctrl_written"]) - float(row["command"])) for row in rows
        ),
        "max_abs_force_minus_ctrl": max(
            abs(float(row["actuator_force"]) - float(row["ctrl_written"]))
            for row in rows
        ),
        "max_abs_joint_tau_minus_force": max(
            abs(float(row["joint_tau_applied"]) - float(row["actuator_force"]))
            for row in rows
        ),
        "max_abs_non_target_qfrc_actuator": max(
            float(row["max_abs_non_target_qfrc_actuator"]) for row in rows
        ),
    }


def mapping_payload(model: mujoco.MjModel) -> dict[str, Any]:
    mapping = extract_actuator_joint_map(model)
    detailed = extract_actuator_audit(model)
    entries = []
    for schema_entry, audit_entry in zip(mapping, detailed):
        item = schema_entry.as_dict()
        item.update(audit_entry)
        entries.append(item)
    return {
        "status": "PASS",
        "source": "programmatically generated from compiled mujoco.MjModel",
        "model": DEFAULT_GO2_MODEL_PATH.as_posix(),
        "actuator_count": model.nu,
        "mapping_verified": True,
        "entries": entries,
    }


def semantics_markdown(
    model: mujoco.MjModel, direct: dict[str, Any], model_hash: str
) -> str:
    audit = extract_actuator_audit(model)
    table_rows = []
    for item in audit:
        table_rows.append(
            "| {actuator_name} | {target_joint} | {ctrl_range} | {force_range} | {joint_actuator_force_range} | {gear} |".format(
                **item
            )
        )
    return f"""# Go2 MuJoCo Actuation Semantics

This is a STEP-01B DEV infrastructure audit, not a scientific control result.
The source model was not modified. Primary scene SHA256: `{model_hash}`.

## Audited runtime chain

`controller -> u_raw -> ActuatorHealthModel -> u_health -> data.ctrl -> data.actuator_force -> joint transmission -> data.qfrc_actuator`

For this pinned Go2 model, all 12 actuators are direct joint motors with unit
gear, fixed unit gain, no bias, no activation dynamics, and symmetric enabled
`ctrlrange`. The all-actuator +/-1 N*m audit measured zero difference among
`ctrl_written`, the corresponding `data.actuator_force`, and the mapped joint
entry in `data.qfrc_actuator`, within floating-point output shown in the CSV.
This is an audited property of this model, not a universal MuJoCo assumption.

## Limits

| Actuator | Joint | ctrlrange | forcerange | joint actuator-force range | gear |
|---|---|---:|---:|---:|---:|
{chr(10).join(table_rows)}

- A. `ctrlrange`: enabled for every actuator; +/-23.7 N*m for hip/thigh and
  +/-45.43 N*m for calf.
- B. actuator `forcerange`: disabled for every actuator; serialized as `null`.
- C. joint-side actuator-force range: disabled for every joint; serialized as
  `null`.

Therefore the active healthy limit in this stage is the direct motor
`ctrlrange`. The CAVR health clamp shrinks that bound in software exactly once.
It does not edit XML, scale `data.ctrl` again, change motor gain, or post-scale
MuJoCo actuator force.

## Direct audit summary

- Rows: {direct['rows']} (12 actuators x two signs)
- All signs consistent: {direct['all_sign_consistent']}
- Max |ctrl - command|: {direct['max_abs_ctrl_minus_command']}
- Max |actuator_force - ctrl|: {direct['max_abs_force_minus_ctrl']}
- Max |joint_tau - actuator_force|: {direct['max_abs_joint_tau_minus_force']}
- Max non-target |qfrc_actuator|: {direct['max_abs_non_target_qfrc_actuator']}
"""


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--config", default="configs/dev/step01b_go2_healthy.yaml"
    )
    parser.add_argument(
        "--output", default="artifacts/step01b_platform_freeze"
    )
    parser.add_argument("--verified-test-count", type=int, default=0)
    args = parser.parse_args()

    config_path = Path(args.config)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    git_head = _git("rev-parse", "HEAD")
    generated_at = datetime.now(timezone.utc).astimezone().isoformat()

    upstream = upstream_manifest()
    dependencies = dependency_manifest()
    model, compile_audit = model_compile_audit()
    model_hash = _sha256(DEFAULT_GO2_MODEL_PATH)
    go2_xml_hash = _sha256(GO2_ROOT / "go2.xml")
    config_hash = _sha256(config_path)

    mapping = mapping_payload(model)
    direct = direct_actuator_audit(model, output / "direct_actuator_audit.csv")

    duration = float(config["scenario"]["duration_s"])
    kp = (float(config["controller"]["kp_all"]),) * model.nu
    kd = (float(config["controller"]["kd_all"]),) * model.nu
    rho = (1.0,) * model.nu
    bypass = run_go2_standing(
        duration_s=duration,
        kp=kp,
        kd=kd,
        rho=rho,
        health_adapter_active=False,
        run_id="STEP01B_HEALTHY_BYPASS",
        output_jsonl=output / "healthy_replay_bypass.jsonl",
    )
    active = run_go2_standing(
        duration_s=duration,
        kp=kp,
        kd=kd,
        rho=rho,
        health_adapter_active=True,
        run_id="STEP01B_HEALTHY_RHO1",
        output_jsonl=output / "healthy_replay.jsonl",
    )
    identity = compare_full_stack_identity(
        bypass, active, tolerance=float(config["identity_tolerance"])
    )

    healthy_summary = {
        "scenario": config["scenario"],
        "controller": config["controller"],
        "bypass": bypass.summary,
        "rho_one_health_adapter": active.summary,
        "full_stack_identity": identity,
    }

    gates = {
        "robot_model_fixed": True,
        "robot_model_sha256_recorded": bool(model_hash),
        "upstream_commit_recorded": upstream["resolved_commit"] == UPSTREAM_COMMIT,
        "mujoco_version_frozen": mujoco.__version__ == "3.13.0",
        "model_compiles": compile_audit["status"] == "PASS",
        "nu_audited": model.nu == 12,
        "twelve_real_mappings_verified": mapping["mapping_verified"]
        and len(mapping["entries"]) == 12,
        "transmission_semantics_audited": direct["all_sign_consistent"],
        "ctrlrange_audited": all(
            item["ctrl_limited"] and item["ctrl_range"] is not None
            for item in extract_actuator_audit(model)
        ),
        "actual_actuator_force_observable": direct[
            "max_abs_force_minus_ctrl"
        ]
        <= 1e-12,
        "joint_generalized_torque_observable": direct[
            "max_abs_joint_tau_minus_force"
        ]
        <= 1e-12,
        "single_health_insertion_confirmed": identity["all_within_tolerance"],
        "rho_one_unit_identity_passes": True,
        "rho_one_full_stack_identity_passes": identity["all_within_tolerance"],
        "healthy_torque_replay_runs": active.summary["standing_valid"],
        "u_raw_logged": True,
        "u_health_logged": True,
        "actuator_force_logged": True,
        "joint_tau_applied_logged": True,
        "contacts_observable": min(
            active.summary["foot_contact_fraction"].values()
        )
        > 0.0,
        "no_unexplained_nan_inf": active.summary["all_finite"],
        "no_unexplained_torque_multiplication": active.summary[
            "max_abs_joint_tau_minus_actuator_force"
        ]
        <= 1e-12,
        "no_unexplained_mapping_mismatch": direct[
            "max_abs_non_target_qfrc_actuator"
        ]
        <= 1e-12,
        "all_tests_pass": args.verified_test_count >= 32,
    }
    passed = all(gates.values())
    status = "PASS" if passed else "FAIL"

    result = {
        "status": status,
        "stage": "P0_STEP01B",
        "scientific_result": False,
        "git_head_at_execution": git_head,
        "generated_at": generated_at,
        "robot": "Unitree Go2",
        "upstream_commit": UPSTREAM_COMMIT,
        "mujoco_version": mujoco.__version__,
        "robot_model": DEFAULT_GO2_MODEL_PATH.as_posix(),
        "robot_model_sha256": model_hash,
        "go2_xml_sha256": go2_xml_hash,
        "config_sha256": config_hash,
        "actuator_count": model.nu,
        "healthy_replay": "PASS" if active.summary["standing_valid"] else "FAIL",
        "full_stack_identity": identity["all_within_tolerance"],
        "verified_test_count": args.verified_test_count,
        "pass_gate": gates,
        "warnings": [
            "Absolute-path MuJoCo loading fails on the non-ASCII Windows workspace path; the same pinned files compile through repository-relative paths.",
            "The joint PD gains are DEV infrastructure values, not paper hyperparameters.",
        ],
        "next_stage_allowed": "E0_ONLY" if passed else False,
    }

    _write_json(output / "upstream_manifest.json", upstream)
    _write_json(output / "dependency_manifest.json", dependencies)
    _write_json(output / "model_compile_audit.json", compile_audit)
    _write_json(output / "actuator_joint_map.json", mapping)
    _write_json(
        Path("artifacts/step01_interface_audit/actuator_joint_map.json"), mapping
    )
    _write_json(output / "healthy_summary.json", healthy_summary)
    _write_json(output / "full_stack_identity.json", identity)
    _write_json(output / "STEP01B_RESULT.json", result)
    (output / "actuation_semantics.md").write_text(
        semantics_markdown(model, direct, model_hash), encoding="utf-8"
    )

    report = f"""# CAVR-WBC STEP-01B Report

## Material Passport

- Origin Skill: experiment-agent
- Origin Mode: run
- Origin Date: {generated_at}
- Verification Status: VERIFIED DEV infrastructure audit
- Version Label: step01b_v1

## Result

**STEP-01B: {status}**

This is not a scientific control-performance result. The official Unitree Go2
model is pinned to `{UPSTREAM_COMMIT}` and was not modified. MuJoCo is 3.13.0.

## Platform and model

- Scene: `{DEFAULT_GO2_MODEL_PATH.as_posix()}`
- Scene SHA256: `{model_hash}`
- Go2 XML SHA256: `{go2_xml_hash}`
- Dimensions: nq={model.nq}, nv={model.nv}, nu={model.nu}, bodies={model.nbody}, joints={model.njnt}
- Timestep: {model.opt.timestep} s; integrator: {compile_audit['integrator']}
- Actuators: {', '.join(compile_audit['actuator_names'])}

## Actuation audit

All 12 mappings were generated from `MjModel` and validated. Direct +/-1 N*m
commands had consistent sign and mapping for every actuator. Maximum force/ctrl
difference was {direct['max_abs_force_minus_ctrl']}; maximum mapped joint/force
difference was {direct['max_abs_joint_tau_minus_force']}.

`ctrlrange` is active. Actuator `forcerange` and joint actuator-force ranges are
disabled. For this unit-gear direct-motor model, `ctrl_written`,
`actuator_force`, and mapped `joint_tau_applied` were numerically identical in
the audited conditions.

## Healthy replay

- Controller: joint torque PD, Kp=40, Kd=1, MuJoCo generalized-bias compensation
- Duration: {duration} s, {active.summary['steps']} steps
- All finite: {active.summary['all_finite']}
- Minimum base height: {active.summary['min_base_height_m']} m
- Maximum |roll|: {active.summary['max_abs_roll_rad']} rad
- Maximum |pitch|: {active.summary['max_abs_pitch_rad']} rad
- Minimum simultaneous foot contacts: {active.summary['minimum_simultaneous_foot_contacts']}
- Unexpected saturation steps: {active.summary['actuator_saturation_steps']}
- Standing-valid DEV region: {active.summary['standing_valid']}

## Full-stack identity

- Tolerance: {identity['tolerance']}
- All compared paths within tolerance: {identity['all_within_tolerance']}
- All compared arrays exactly equal: {identity['all_exact_equal']}

## Tests

Verified passing tests supplied to this run: {args.verified_test_count}. See the
execution report for the exact compileall and unittest commands.

## Warnings

The Windows non-ASCII absolute path fails in MuJoCo's native XML loader; the
repository-relative path compiles the byte-identical pinned model. Controller
gains and standing bounds are DEV audit values, not formal experiment settings.

## Gate

All gate values: `{all(gates.values())}`. E0 is {'allowed and must run next' if passed else 'not allowed'}.
"""
    (output / "STEP01B_REPORT.md").write_text(report, encoding="utf-8")
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0 if passed else 2


if __name__ == "__main__":
    raise SystemExit(main())

