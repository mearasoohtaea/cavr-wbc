"""Execute the frozen STEP-02 B1--P0 fixed-support equivalence audit."""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import math
from pathlib import Path
import subprocess
from typing import Any, Iterable

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mujoco
import numpy as np
import yaml

from cavr_wbc.control.fixed_support_qp import (
    FixedSupportPhysicalQp,
    PhysicalSnapshot,
    QpSolveResult,
    SolverSettings,
    build_contact_template,
    build_physical_snapshot,
    generate_snapshot_panel,
)
from cavr_wbc.platforms.go2_mujoco import (
    DEFAULT_GO2_MODEL_PATH,
    extract_actuator_joint_map,
    load_go2_model,
)


UPSTREAM_COMMIT = "1eb6642e3f3fdfb7fb13a9794fd6a2dd93ea0e7d"


def _json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    if isinstance(value, np.ndarray):
        return _json_safe(value.tolist())
    if isinstance(value, (np.floating, float)):
        number = float(value)
        return number if math.isfinite(number) else None
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.bool_,)):
        return bool(value)
    return value


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            _json_safe(value), indent=2, ensure_ascii=False, allow_nan=False
        )
        + "\n",
        encoding="utf-8",
    )


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _git(*args: str) -> str:
    return subprocess.check_output(
        ["git", *args], text=True, encoding="utf-8"
    ).strip()


def _package_version(name: str) -> str | None:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return None


def dependency_manifest() -> dict[str, Any]:
    packages = (
        "mujoco",
        "numpy",
        "PyYAML",
        "matplotlib",
        "osqp",
        "scipy",
        "jinja2",
        "joblib",
        "cloudpickle",
        "MarkupSafe",
    )
    versions = {name: _package_version(name) for name in packages}
    return {
        "python": subprocess.check_output(
            ["python", "--version"], text=True, encoding="utf-8"
        ).strip(),
        "requirements_file": "requirements-step02.txt",
        "installation_command": "python -m pip install osqp",
        "direct_qp_requirement": {"osqp": versions["osqp"]},
        "qp_dependency_resolution": {
            name: versions[name]
            for name in (
                "numpy",
                "scipy",
                "jinja2",
                "joblib",
                "cloudpickle",
                "MarkupSafe",
            )
        },
        "stage_runtime_dependencies": versions,
        "cvxpy_installed": _package_version("cvxpy") is not None,
        "rl_libraries_installed_by_step02": False,
        "installation_failures": [],
    }


def _result_record(
    case: dict[str, str], result: QpSolveResult | None, stage: str
) -> dict[str, Any]:
    if result is None:
        return {
            **case,
            "stage": stage,
            "status": "not_run_due_to_preceding_stage_failure",
            "success": False,
            "validation": {"available": False},
        }
    return {
        **case,
        "stage": stage,
        "method": result.method,
        "status": result.status,
        "status_val": result.status_val,
        "success": result.success,
        "iterations": result.iterations,
        "solve_time_s": result.solve_time_s,
        "setup_time_s": result.setup_time_s,
        "primal_residual": result.primal_residual,
        "dual_residual": result.dual_residual,
        "solver_objective": result.solver_objective,
        "qdd": result.qdd,
        "tau": result.tau,
        "contact_force_world_xyz_by_foot": (
            None
            if result.contact_force is None
            else result.contact_force.reshape(-1, 3)
        ),
        "task_output": result.task_output,
        "normalized_task_residual": result.normalized_task_residual,
        "task_objective": result.task_objective,
        "torque_regularizer": result.torque_regularizer,
        "validation": result.validation,
    }


def _task_objective(
    snapshot: PhysicalSnapshot, output: np.ndarray, desired: np.ndarray
) -> float:
    residual = (output - desired) / snapshot.task_scales
    return float(np.sum(snapshot.task_weights * np.square(residual)))


def _task_error_norm(
    snapshot: PhysicalSnapshot, output: np.ndarray, desired: np.ndarray
) -> float:
    return float(np.linalg.norm((output - desired) / snapshot.task_scales))


def _physical_pass(result: QpSolveResult | None, thresholds: dict[str, float]) -> bool:
    if result is None or not result.success or not result.validation.get("available"):
        return False
    validation = result.validation
    return bool(
        validation["dynamics_infinity_norm"]
        <= thresholds["dynamics_infinity_norm"]
        and validation["contact_infinity_norm"]
        <= thresholds["contact_infinity_norm"]
        and validation["hard_inequality_violation"]
        <= thresholds["hard_inequality_violation"]
    )


def _status(result: QpSolveResult | None) -> str:
    return (
        "not_run_due_to_preceding_stage_failure"
        if result is None
        else result.status
    )


def _write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        raise ValueError(f"Refusing to write empty audit table: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = list(rows[0])
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(_json_safe(rows))


def _percentiles(values: Iterable[float]) -> dict[str, float] | None:
    array = np.asarray(tuple(values), dtype=float)
    if array.size == 0:
        return None
    return {
        "min": float(np.min(array)),
        "p25": float(np.percentile(array, 25)),
        "median": float(np.median(array)),
        "p75": float(np.percentile(array, 75)),
        "p95": float(np.percentile(array, 95)),
        "max": float(np.max(array)),
    }


def _save_figures(
    output: Path,
    eq_rows: list[dict[str, Any]],
    soft_rows: list[dict[str, Any]],
    diagnostics: list[dict[str, Any]],
) -> None:
    plt.rcParams.update({"figure.dpi": 150, "font.size": 9})

    p0_values: list[float] = []
    lex_values: list[float] = []
    for row in eq_rows:
        if row["p0_task_output_json"] and row["b1lex_task_output_json"]:
            p0_values.extend(json.loads(row["p0_task_output_json"]))
            lex_values.extend(json.loads(row["b1lex_task_output_json"]))
    fig, ax = plt.subplots(figsize=(5.2, 5.0))
    if p0_values:
        ax.scatter(p0_values, lex_values, s=9, alpha=0.45)
        lower = min(p0_values + lex_values)
        upper = max(p0_values + lex_values)
        ax.plot([lower, upper], [lower, upper], color="black", linewidth=1)
    ax.set_xlabel("P0 task output")
    ax.set_ylabel("B1-LEX task output")
    ax.set_title("STEP-02 task-output equivalence")
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(output / "eq_p0_vs_b1lex_task_output.png")
    plt.close(fig)

    objective_differences = [
        float(row["task_objective_abs_difference"])
        for row in eq_rows
        if row["task_objective_abs_difference"] is not None
    ]
    fig, ax = plt.subplots(figsize=(6.0, 4.0))
    ax.hist(objective_differences, bins=30, color="#3569a8", alpha=0.85)
    ax.set_xlabel("absolute normalized task-objective difference")
    ax.set_ylabel("case count")
    ax.set_title("P0 vs B1-LEX primary objective")
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(output / "eq_task_objective_difference.png")
    plt.close(fig)

    soft_differences = [
        float(row["normalized_p0_b1soft_task_difference_l2"])
        for row in soft_rows
        if row["normalized_p0_b1soft_task_difference_l2"] is not None
    ]
    fig, ax = plt.subplots(figsize=(6.0, 4.0))
    ax.hist(soft_differences, bins=30, color="#ad5a2a", alpha=0.85)
    ax.set_xlabel("normalized ||y_P0 - y_B1-soft||2")
    ax.set_ylabel("case count")
    ax.set_title("Weighted regularization task difference")
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(output / "b1soft_vs_p0_task_difference.png")
    plt.close(fig)

    p0_torque = [
        float(row["p0_torque_normalized_l2"])
        for row in soft_rows
        if row["p0_torque_normalized_l2"] is not None
    ]
    soft_torque = [
        float(row["b1soft_torque_normalized_l2"])
        for row in soft_rows
        if row["b1soft_torque_normalized_l2"] is not None
    ]
    fig, ax = plt.subplots(figsize=(5.2, 5.0))
    if p0_torque:
        ax.scatter(p0_torque, soft_torque, s=13, alpha=0.55)
        lower = min(p0_torque + soft_torque)
        upper = max(p0_torque + soft_torque)
        ax.plot([lower, upper], [lower, upper], color="black", linewidth=1)
    ax.set_xlabel("P0 normalized torque norm")
    ax.set_ylabel("B1-soft normalized torque norm")
    ax.set_title("Torque regularization comparison")
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(output / "b1soft_vs_p0_torque_norm.png")
    plt.close(fig)

    method_order = [
        "P0_STAGE1",
        "P0_STAGE2",
        "B1_LEX_STAGE_A",
        "B1_LEX_STAGE_B",
        "B1_SOFT",
    ]
    runtime_values = [
        [
            float(item["solve_time_s"]) * 1000.0
            for item in diagnostics
            if item.get("method") == method and item.get("solve_time_s") is not None
        ]
        for method in method_order
    ]
    fig, ax = plt.subplots(figsize=(8.0, 4.4))
    ax.boxplot(runtime_values, tick_labels=method_order, showfliers=False)
    ax.set_ylabel("OSQP solve time (ms)")
    ax.set_title("Solver runtime distributions")
    ax.tick_params(axis="x", rotation=20)
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(output / "runtime_comparison.png")
    plt.close(fig)


def _physical_model_audit(
    model: mujoco.MjModel,
    snapshot: PhysicalSnapshot,
    template: Any,
    normal_force_upper: float,
) -> dict[str, Any]:
    mapping = extract_actuator_joint_map(model)
    mass_eigenvalues = np.linalg.eigvalsh(snapshot.mass_matrix)
    return {
        "platform": {
            "robot": "Unitree Go2",
            "simulator": "MuJoCo",
            "simulator_version": mujoco.__version__,
            "model": DEFAULT_GO2_MODEL_PATH.as_posix(),
            "model_sha256": _sha256(DEFAULT_GO2_MODEL_PATH),
            "upstream_commit": UPSTREAM_COMMIT,
            "upstream_xml_modified": False,
        },
        "dimensions": {
            "nq": model.nq,
            "nv": snapshot.nv,
            "nu": snapshot.nu,
            "contact_force_dimension": snapshot.nlambda,
            "decision_dimension": snapshot.decision_dimension,
            "programmatic_identity": (
                f"{snapshot.nv}+{snapshot.nu}+{snapshot.nlambda}="
                f"{snapshot.decision_dimension}"
            ),
        },
        "state": {
            "snapshot_id": snapshot.snapshot_id,
            "qpos": snapshot.qpos,
            "qvel": snapshot.qvel,
            "velocity_assumption": "exactly zero",
            "jdot_v": np.zeros(snapshot.nlambda),
            "jdot_v_general_nonzero_velocity_implemented": False,
        },
        "dynamics": {
            "equation": "M qdd + b = B tau + Jc^T lambda",
            "mass_matrix_source": "mujoco.mj_fullM(model, data, dense_M)",
            "M": snapshot.mass_matrix,
            "mass_matrix_symmetry_infinity_norm": float(
                np.max(np.abs(snapshot.mass_matrix - snapshot.mass_matrix.T))
            ),
            "mass_matrix_minimum_eigenvalue": float(np.min(mass_eigenvalues)),
            "bias_source": "MjData.qfrc_bias after mj_forward",
            "b": snapshot.bias_force,
            "actuated_selection_source": "compiled sparse actuator moment",
            "B": snapshot.selection_matrix,
            "actuator_mapping": [entry.as_dict() for entry in mapping],
        },
        "fixed_contact": {
            "foot_order": list(template.foot_names),
            "force_frame": "world xyz",
            "nominal_world_points_m": template.nominal_world_points,
            "body_local_points_m": template.local_points,
            "Jc": snapshot.contact_jacobian,
            "Jc_shape": list(snapshot.contact_jacobian.shape),
            "Jc_rank": int(np.linalg.matrix_rank(snapshot.contact_jacobian)),
            "constraint_at_primary_state": "Jc qdd = 0",
            "friction_mu_by_foot": snapshot.friction_mu,
            "friction_model": "|lambda_x|+|lambda_y| <= mu*lambda_z",
            "normal_lower_n": 0.0,
            "normal_upper_n_by_foot": snapshot.normal_force_upper,
            "normal_upper_rule": "total robot weight per foot",
            "total_robot_mass_kg": float(np.sum(model.body_mass)),
            "total_robot_weight_n": normal_force_upper,
            "rule_frozen_before_comparison": True,
        },
        "task": {
            "equation": "y = T qdd + c",
            "components": [
                "base_linear_generalized_acceleration_x",
                "base_linear_generalized_acceleration_y",
                "base_linear_generalized_acceleration_z",
                "base_angular_generalized_acceleration_x",
                "base_angular_generalized_acceleration_y",
                "base_angular_generalized_acceleration_z",
                "FR_thigh_joint_acceleration",
                "RL_thigh_joint_acceleration",
            ],
            "T": snapshot.task_matrix,
            "c": snapshot.task_bias,
            "normalization_scales": snapshot.task_scales,
            "weights": snapshot.task_weights,
            "composition_frozen_before_comparison": True,
        },
        "health_semantics": {
            "fault_model": "output_torque_capacity",
            "oracle_rho": True,
            "torque_constraint": "-rho*tau_bar <= tau <= rho*tau_bar",
            "tau_is_actual_desired_joint_torque": True,
            "post_qp_rho_multiplication": False,
        },
        "numerical_formulation": {
            "single_physical_constraint_builder": (
                "FixedSupportPhysicalQp._physical_constraints"
            ),
            "zero_rhs_friction_row_scale": 10.0,
            "row_scale_changes_feasible_set": False,
            "all_reported_residuals_recomputed_in_original_units": True,
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--config", default="configs/dev/step02_b1_p0_equivalence.yaml"
    )
    parser.add_argument(
        "--output", default="artifacts/step02_b1_p0_equivalence"
    )
    parser.add_argument("--verified-test-count", type=int, default=0)
    args = parser.parse_args()

    config_path = Path(args.config)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    config_text = config_path.read_text(encoding="utf-8")
    config = yaml.safe_load(config_text)
    (output / "config.yaml").write_text(config_text, encoding="utf-8")
    _write_json(output / "dependency_manifest.json", dependency_manifest())

    generated_at = datetime.now(timezone.utc).astimezone().isoformat()
    git_head = _git("rev-parse", "HEAD")
    model = load_go2_model()
    nominal_data = mujoco.MjData(model)
    home_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_KEY, "home")
    mujoco.mj_resetDataKeyframe(model, nominal_data, home_id)
    nominal_data.qvel[:] = 0.0
    nominal_data.ctrl[:] = 0.0
    mujoco.mj_forward(model, nominal_data)
    template = build_contact_template(model, nominal_data)

    snapshot_config = config["snapshot_panel"]
    panel = generate_snapshot_panel(
        model,
        template,
        perturbation_max_rad=float(snapshot_config["joint_perturbation_max_rad"]),
        joint_limit_margin_rad=float(snapshot_config["joint_limit_margin_rad"]),
        maximum_contact_displacement_m=float(
            snapshot_config["maximum_contact_point_displacement_m"]
        ),
        required_actual_foot_contacts=int(
            snapshot_config["required_actual_foot_contacts"]
        ),
    )
    _write_json(
        output / "snapshot_panel.json",
        {
            "frozen_before_method_execution": True,
            "count": len(panel),
            "states": panel,
        },
    )
    _write_json(
        output / "task_demand_panel.json",
        {
            "frozen_before_method_execution": True,
            "count": len(config["task_demands"]),
            "demands": config["task_demands"],
        },
    )

    total_weight = float(np.sum(model.body_mass) * abs(model.opt.gravity[2]))
    task_config = config["task_stack"]
    snapshots = [
        build_physical_snapshot(
            model,
            template,
            item["snapshot_id"],
            item["qpos"],
            task_scales=task_config["normalization_scales"],
            task_weights=task_config["weight_diagonal"],
            normal_force_upper=total_weight,
        )
        for item in panel
    ]
    _write_json(
        output / "physical_model_audit.json",
        _physical_model_audit(model, snapshots[0], template, total_weight),
    )

    settings = SolverSettings(**config["osqp"])
    lambda_tau = float(config["objectives"]["lambda_tau"])
    task_fix_tolerance = float(
        config["objectives"]["secondary_task_fix_normalized_tolerance"]
    )
    validation_thresholds = config["validation"]
    actuator_index = {
        entry.actuator_name: entry.actuator_index
        for entry in extract_actuator_joint_map(model)
    }

    diagnostics: list[dict[str, Any]] = []
    eq_rows: list[dict[str, Any]] = []
    soft_rows: list[dict[str, Any]] = []
    all_stage_results: list[QpSolveResult | None] = []
    case_count = len(snapshots) * len(config["health_panel"]) * len(
        config["task_demands"]
    )
    print(f"STEP-02 frozen panel: {case_count} cases, five QP stages per case")
    completed = 0

    for snapshot in snapshots:
        for health in config["health_panel"]:
            rho = np.ones(model.nu)
            if health["actuator"] is not None:
                rho[actuator_index[health["actuator"]]] = float(health["rho"])
            physical_qp = FixedSupportPhysicalQp(
                snapshot,
                rho,
                settings,
                secondary_task_fix_normalized_tolerance=task_fix_tolerance,
            )
            for demand in config["task_demands"]:
                desired = np.asarray(demand["y_d"], dtype=float)
                case_id = (
                    f"{snapshot.snapshot_id}__{health['health_id']}__"
                    f"{demand['demand_id']}"
                )
                case = {
                    "case_id": case_id,
                    "snapshot_id": snapshot.snapshot_id,
                    "health_id": health["health_id"],
                    "demand_id": demand["demand_id"],
                    "demand_class": demand["class"],
                }

                p0_stage1 = physical_qp.solve_p0_stage1(desired)
                p0_stage2 = (
                    physical_qp.solve_p0_stage2(
                        p0_stage1.task_output,
                        lambda_tau,
                        warm_start=p0_stage1,
                    )
                    if p0_stage1.success
                    else None
                )
                lex_stage_a = physical_qp.solve_b1_lex_stage_a(desired)
                lex_stage_b = (
                    physical_qp.solve_b1_lex_stage_b(
                        lex_stage_a.task_output,
                        lambda_tau,
                        warm_start=lex_stage_a,
                    )
                    if lex_stage_a.success
                    else None
                )
                b1_soft = physical_qp.solve_b1_soft(desired, lambda_tau)
                stage_results = (
                    (p0_stage1, "P0_STAGE1"),
                    (p0_stage2, "P0_STAGE2"),
                    (lex_stage_a, "B1_LEX_STAGE_A"),
                    (lex_stage_b, "B1_LEX_STAGE_B"),
                    (b1_soft, "B1_SOFT"),
                )
                for result, stage in stage_results:
                    diagnostics.append(_result_record(case, result, stage))
                    all_stage_results.append(result)

                complete_eq = (
                    p0_stage1.success
                    and p0_stage2 is not None
                    and p0_stage2.success
                    and lex_stage_a.success
                    and lex_stage_b is not None
                    and lex_stage_b.success
                )
                p0_physical = _physical_pass(
                    p0_stage2, validation_thresholds
                )
                lex_physical = _physical_pass(
                    lex_stage_b, validation_thresholds
                )
                if complete_eq:
                    stage_a_task_difference = float(
                        np.max(
                            np.abs(
                                (p0_stage1.task_output - lex_stage_a.task_output)
                                / snapshot.task_scales
                            )
                        )
                    )
                    task_difference = float(
                        np.max(
                            np.abs(
                                (p0_stage2.task_output - lex_stage_b.task_output)
                                / snapshot.task_scales
                            )
                        )
                    )
                    p0_objective = _task_objective(
                        snapshot, p0_stage2.task_output, desired
                    )
                    lex_objective = _task_objective(
                        snapshot, lex_stage_b.task_output, desired
                    )
                    objective_difference = abs(p0_objective - lex_objective)
                    regularizer_difference = abs(
                        p0_stage2.torque_regularizer
                        - lex_stage_b.torque_regularizer
                    )
                    eq_numeric = (
                        stage_a_task_difference
                        <= float(validation_thresholds["normalized_task_equivalence"])
                        and task_difference
                        <= float(validation_thresholds["normalized_task_equivalence"])
                        and objective_difference
                        <= float(validation_thresholds["task_objective_difference"])
                        and regularizer_difference
                        <= float(validation_thresholds["torque_regularizer_difference"])
                    )
                else:
                    stage_a_task_difference = None
                    task_difference = None
                    p0_objective = None
                    lex_objective = None
                    objective_difference = None
                    regularizer_difference = None
                    eq_numeric = False

                eq_pass = bool(
                    complete_eq and eq_numeric and p0_physical and lex_physical
                )
                eq_rows.append(
                    {
                        **case,
                        "p0_stage1_status": p0_stage1.status,
                        "p0_stage2_status": _status(p0_stage2),
                        "b1lex_stage_a_status": lex_stage_a.status,
                        "b1lex_stage_b_status": _status(lex_stage_b),
                        "p0_task_output_json": (
                            None
                            if p0_stage2 is None or p0_stage2.task_output is None
                            else json.dumps(p0_stage2.task_output.tolist())
                        ),
                        "b1lex_task_output_json": (
                            None
                            if lex_stage_b is None or lex_stage_b.task_output is None
                            else json.dumps(lex_stage_b.task_output.tolist())
                        ),
                        "stage_a_normalized_task_output_inf_difference": stage_a_task_difference,
                        "normalized_task_output_inf_difference": task_difference,
                        "p0_task_objective": p0_objective,
                        "b1lex_task_objective": lex_objective,
                        "task_objective_abs_difference": objective_difference,
                        "p0_torque_regularizer": (
                            None if p0_stage2 is None else p0_stage2.torque_regularizer
                        ),
                        "b1lex_torque_regularizer": (
                            None if lex_stage_b is None else lex_stage_b.torque_regularizer
                        ),
                        "torque_regularizer_abs_difference": regularizer_difference,
                        "p0_dynamics_inf": (
                            None
                            if p0_stage2 is None
                            else p0_stage2.validation.get("dynamics_infinity_norm")
                        ),
                        "b1lex_dynamics_inf": (
                            None
                            if lex_stage_b is None
                            else lex_stage_b.validation.get("dynamics_infinity_norm")
                        ),
                        "p0_contact_inf": (
                            None
                            if p0_stage2 is None
                            else p0_stage2.validation.get("contact_infinity_norm")
                        ),
                        "b1lex_contact_inf": (
                            None
                            if lex_stage_b is None
                            else lex_stage_b.validation.get("contact_infinity_norm")
                        ),
                        "p0_inequality_violation": (
                            None
                            if p0_stage2 is None
                            else p0_stage2.validation.get("hard_inequality_violation")
                        ),
                        "b1lex_inequality_violation": (
                            None
                            if lex_stage_b is None
                            else lex_stage_b.validation.get("hard_inequality_violation")
                        ),
                        "p0_physical_pass": p0_physical,
                        "b1lex_physical_pass": lex_physical,
                        "equivalence_numeric_pass": bool(eq_numeric),
                        "eq_a_pass": eq_pass,
                    }
                )

                soft_complete = (
                    p0_stage2 is not None
                    and p0_stage2.success
                    and b1_soft.success
                )
                if soft_complete:
                    output_difference = p0_stage2.task_output - b1_soft.task_output
                    p0_runtime = p0_stage1.solve_time_s + p0_stage2.solve_time_s
                    p0_validation = p0_stage2.validation
                    soft_validation = b1_soft.validation
                    soft_row_values = {
                        "p0_normalized_desired_task_error_l2": _task_error_norm(
                            snapshot, p0_stage2.task_output, desired
                        ),
                        "b1soft_normalized_desired_task_error_l2": _task_error_norm(
                            snapshot, b1_soft.task_output, desired
                        ),
                        "p0_b1soft_task_difference_l2": float(
                            np.linalg.norm(output_difference)
                        ),
                        "normalized_p0_b1soft_task_difference_l2": float(
                            np.linalg.norm(output_difference / snapshot.task_scales)
                        ),
                        "p0_torque_normalized_l2": p0_validation[
                            "torque_normalized_l2"
                        ],
                        "b1soft_torque_normalized_l2": soft_validation[
                            "torque_normalized_l2"
                        ],
                        "p0_contact_force_l2_n": p0_validation[
                            "contact_force_l2_n"
                        ],
                        "b1soft_contact_force_l2_n": soft_validation[
                            "contact_force_l2_n"
                        ],
                        "p0_active_torque_constraints": p0_validation[
                            "active_torque_constraints"
                        ],
                        "b1soft_active_torque_constraints": soft_validation[
                            "active_torque_constraints"
                        ],
                        "p0_active_friction_constraints": p0_validation[
                            "active_friction_constraints"
                        ],
                        "b1soft_active_friction_constraints": soft_validation[
                            "active_friction_constraints"
                        ],
                        "p0_two_stage_solve_time_s": p0_runtime,
                        "b1soft_solve_time_s": b1_soft.solve_time_s,
                    }
                else:
                    soft_row_values = {
                        "p0_normalized_desired_task_error_l2": None,
                        "b1soft_normalized_desired_task_error_l2": None,
                        "p0_b1soft_task_difference_l2": None,
                        "normalized_p0_b1soft_task_difference_l2": None,
                        "p0_torque_normalized_l2": None,
                        "b1soft_torque_normalized_l2": None,
                        "p0_contact_force_l2_n": None,
                        "b1soft_contact_force_l2_n": None,
                        "p0_active_torque_constraints": None,
                        "b1soft_active_torque_constraints": None,
                        "p0_active_friction_constraints": None,
                        "b1soft_active_friction_constraints": None,
                        "p0_two_stage_solve_time_s": None,
                        "b1soft_solve_time_s": None,
                    }
                soft_rows.append(
                    {
                        **case,
                        "p0_status": _status(p0_stage2),
                        "b1soft_status": b1_soft.status,
                        **soft_row_values,
                        "p0_physical_pass": _physical_pass(
                            p0_stage2, validation_thresholds
                        ),
                        "b1soft_physical_pass": _physical_pass(
                            b1_soft, validation_thresholds
                        ),
                    }
                )

                completed += 1
                if completed % 35 == 0 or completed == case_count:
                    print(f"STEP-02 progress: {completed}/{case_count} cases")

    _write_csv(output / "eq_cases.csv", eq_rows)
    _write_csv(output / "b1_soft_vs_p0.csv", soft_rows)
    with (output / "solver_diagnostics.jsonl").open(
        "w", encoding="utf-8", newline="\n"
    ) as handle:
        for record in diagnostics:
            handle.write(
                json.dumps(
                    _json_safe(record), ensure_ascii=False, allow_nan=False
                )
                + "\n"
            )
    _save_figures(output, eq_rows, soft_rows, diagnostics)

    available_results = [item for item in all_stage_results if item is not None]
    successful_results = [item for item in available_results if item.success]
    validation_results = [
        item.validation
        for item in successful_results
        if item.validation.get("available")
    ]
    eq_pass_count = sum(bool(row["eq_a_pass"]) for row in eq_rows)
    all_stages_converged = (
        len(available_results) == case_count * 5
        and all(item.success for item in available_results)
    )
    all_stage_physical_pass = (
        len(successful_results) == case_count * 5
        and all(
            _physical_pass(item, validation_thresholds)
            for item in successful_results
        )
    )
    all_identity_pass = bool(validation_results) and all(
        item["health_adapter_identity_error"]
        <= float(validation_thresholds["health_adapter_identity"])
        for item in validation_results
    )
    all_soft_explainable = all(
        row["p0_status"] == "solved"
        and row["b1soft_status"] == "solved"
        and row["p0_physical_pass"]
        and row["b1soft_physical_pass"]
        for row in soft_rows
    )
    panel_valid = all(
        bool(item["pre_method_geometry_validation"]["valid"])
        for item in panel
    )
    gates = {
        "snapshot_panel_prevalidated": panel_valid,
        "five_snapshots_present": len(panel) == 5,
        "decision_dimension_is_programmatic_42": (
            snapshots[0].decision_dimension == 42
            and snapshots[0].nv == 18
            and snapshots[0].nu == 12
            and snapshots[0].nlambda == 12
        ),
        "all_48_tests_passed": args.verified_test_count >= 48,
        "all_qp_stages_converged": all_stages_converged,
        "all_solve_witnesses_pass_physical_thresholds": all_stage_physical_pass,
        "eq_a_all_cases_pass": eq_pass_count == case_count,
        "b1soft_comparison_physically_valid_and_explainable": all_soft_explainable,
        "health_adapter_identity_all_witnesses": all_identity_pass,
        "single_shared_physical_constraint_builder": True,
        "no_post_qp_health_rescaling": True,
    }
    passed = all(gates.values())
    status_counts_by_stage: dict[str, dict[str, int]] = {}
    grouped_statuses: dict[str, Counter[str]] = defaultdict(Counter)
    for item in diagnostics:
        grouped_statuses[item["stage"]][item["status"]] += 1
    for stage, counts in grouped_statuses.items():
        status_counts_by_stage[stage] = dict(counts)

    physical_failure_counts = {
        "dynamics": sum(
            item["dynamics_infinity_norm"]
            > float(validation_thresholds["dynamics_infinity_norm"])
            for item in validation_results
        ),
        "contact": sum(
            item["contact_infinity_norm"]
            > float(validation_thresholds["contact_infinity_norm"])
            for item in validation_results
        ),
        "hard_inequality": sum(
            item["hard_inequality_violation"]
            > float(validation_thresholds["hard_inequality_violation"])
            for item in validation_results
        ),
    }
    worst_inequality_cases = sorted(
        (
            {
                "case_id": item["case_id"],
                "stage": item["stage"],
                "status": item["status"],
                "hard_inequality_violation": item["validation"].get(
                    "hard_inequality_violation"
                ),
                "torque_violation": item["validation"].get("torque_violation"),
                "friction_violation": item["validation"].get(
                    "friction_violation"
                ),
                "normal_force_upper_violation": item["validation"].get(
                    "normal_force_upper_violation"
                ),
            }
            for item in diagnostics
            if item.get("success") and item["validation"].get("available")
        ),
        key=lambda item: float(item["hard_inequality_violation"]),
        reverse=True,
    )[:10]
    max_value = lambda key: max(
        (
            float(item[key])
            for item in validation_results
            if item.get(key) is not None
        ),
        default=None,
    )
    eq_summary = {
        "stage": "CAVR-WBC/P0/STEP-02",
        "status": "PASS" if passed else "FAIL",
        "disposition": "GO_TO_E1" if passed else "REVISE",
        "scientific_scope": "instantaneous fixed-support equivalence only",
        "case_count": case_count,
        "qp_solve_stage_count": case_count * 5,
        "eq_a_pass_count": eq_pass_count,
        "eq_a_fail_count": case_count - eq_pass_count,
        "solver_success_count": len(successful_results),
        "solver_failure_count": case_count * 5 - len(successful_results),
        "solver_status_counts_by_stage": status_counts_by_stage,
        "physical_failure_counts_by_metric": physical_failure_counts,
        "eq_a_failure_breakdown": {
            "solver_incomplete": sum(
                "not_run" in row["p0_stage2_status"]
                or "not_run" in row["b1lex_stage_b_status"]
                or row["p0_stage1_status"] != "solved"
                or row["p0_stage2_status"] != "solved"
                or row["b1lex_stage_a_status"] != "solved"
                or row["b1lex_stage_b_status"] != "solved"
                for row in eq_rows
            ),
            "numeric_equivalence_failure": sum(
                not bool(row["equivalence_numeric_pass"]) for row in eq_rows
            ),
            "p0_physical_failure": sum(
                not bool(row["p0_physical_pass"]) for row in eq_rows
            ),
            "b1lex_physical_failure": sum(
                not bool(row["b1lex_physical_pass"]) for row in eq_rows
            ),
        },
        "worst_inequality_cases": worst_inequality_cases,
        "maxima_all_successful_witnesses_original_units": {
            "dynamics_infinity_norm": max_value("dynamics_infinity_norm"),
            "contact_infinity_norm": max_value("contact_infinity_norm"),
            "hard_inequality_violation": max_value(
                "hard_inequality_violation"
            ),
            "health_adapter_identity_error": max_value(
                "health_adapter_identity_error"
            ),
        },
        "equivalence_maxima": {
            "normalized_task_output_inf_difference": max(
                (
                    float(row["normalized_task_output_inf_difference"])
                    for row in eq_rows
                    if row["normalized_task_output_inf_difference"] is not None
                ),
                default=None,
            ),
            "task_objective_abs_difference": max(
                (
                    float(row["task_objective_abs_difference"])
                    for row in eq_rows
                    if row["task_objective_abs_difference"] is not None
                ),
                default=None,
            ),
            "torque_regularizer_abs_difference": max(
                (
                    float(row["torque_regularizer_abs_difference"])
                    for row in eq_rows
                    if row["torque_regularizer_abs_difference"] is not None
                ),
                default=None,
            ),
        },
        "b1soft_vs_p0_distributions": {
            "normalized_task_difference_l2": _percentiles(
                row["normalized_p0_b1soft_task_difference_l2"]
                for row in soft_rows
                if row["normalized_p0_b1soft_task_difference_l2"] is not None
            ),
            "p0_normalized_torque_l2": _percentiles(
                row["p0_torque_normalized_l2"]
                for row in soft_rows
                if row["p0_torque_normalized_l2"] is not None
            ),
            "b1soft_normalized_torque_l2": _percentiles(
                row["b1soft_torque_normalized_l2"]
                for row in soft_rows
                if row["b1soft_torque_normalized_l2"] is not None
            ),
        },
        "thresholds": validation_thresholds,
        "pass_gate": gates,
        "interpretation": (
            "The direct instantaneous projection implementation is numerically consistent with the equivalent lexicographic soft-task WBC formulation under the tested fixed-support convex model."
            if passed
            else "STEP-02 did not clear its frozen numerical/physical gate; no equivalence or recoverability claim is authorized."
        ),
        "b1soft_interpretation": (
            "Any case-level P0/B1-soft differences arise under the same physical constraints and are analyzed as consequences of the weighted torque regularizer; no method-superiority claim is made."
        ),
    }
    _write_json(output / "eq_summary.json", eq_summary)

    result = {
        "status": "PASS" if passed else "FAIL",
        "stage": "P0_STEP02_B1_P0_EQUIVALENCE",
        "generated_at": generated_at,
        "git_head_at_execution": git_head,
        "config_sha256": _sha256(config_path),
        "verified_test_count": args.verified_test_count,
        "case_count": case_count,
        "pass_gate": gates,
        "disposition": "GO_TO_E1" if passed else "REVISE",
        "next_stage_allowed": "E1_ONLY" if passed else False,
        "recoverability_evidence": False,
        "long_horizon_control_evidence": False,
        "optional_one_step_execution_sanity_check_run": False,
        "optional_check_reason": (
            "Not run because the complete snapshot equivalence/physical gate did not pass."
            if not passed
            else "Not required for STEP-02 equivalence and deliberately deferred."
        ),
    }
    _write_json(output / "STEP02_RESULT.json", result)

    failed_physical = sum(
        not _physical_pass(item, validation_thresholds)
        for item in successful_results
    )
    report = f"""# CAVR-WBC STEP-02 B1--P0 Equivalence Audit

## Material Passport

- Origin Skill: experiment-agent
- Origin Mode: run
- Generated: {generated_at}
- Verification Status: frozen DEV panel executed
- Platform: Unitree Go2, MuJoCo {mujoco.__version__}

## Result

**STEP-02: {'PASS' if passed else 'FAIL'} -- {'GO TO E1' if passed else 'REVISE'}**

This audit is limited to instantaneous, zero-velocity, four-foot fixed-support
convex QPs. It is not recoverability evidence, a walking result, or a safety
certificate.

## Frozen formulation

The programmatic decision dimension is {snapshots[0].nv} + {snapshots[0].nu} +
{snapshots[0].nlambda} = {snapshots[0].decision_dimension}. The same
`FixedSupportPhysicalQp` constraint builder supplies B1-soft, P0, and B1-LEX.
It uses the compiled MuJoCo mass matrix, generalized bias, sparse actuator
moment mapping, and one world-frame 3D contact force for each foot in the
order FL, FR, RL, RR. The primary snapshots use v=0 and Jc qdd=0.

The friction coefficient is model-derived ({snapshots[0].friction_mu.tolist()}).
Each foot normal force is bounded by total robot weight ({total_weight:.12g} N).
The 8D task and normalization are frozen in `config.yaml`; lambda_tau is
{lambda_tau} and the task-fix band is {task_fix_tolerance} in normalized units.

## Panel and solver outcomes

- Snapshot states: {len(panel)}; all geometry-prevalidated: {panel_valid}
- Health conditions: {len(config['health_panel'])}
- Authored task demands: {len(config['task_demands'])}
- Total cases: {case_count}
- QP solve stages: {case_count * 5}
- Strict OSQP successes: {len(successful_results)}
- Strict OSQP failures/not-run stages: {case_count * 5 - len(successful_results)}
- Successful witnesses failing an original-unit physical threshold: {failed_physical}

No failed solve was silently retried and no tolerance was relaxed.

## Comparison A: P0 vs B1-LEX

- Passing cases: {eq_pass_count}/{case_count}
- Maximum normalized task-output difference: {eq_summary['equivalence_maxima']['normalized_task_output_inf_difference']}
- Maximum task-objective difference: {eq_summary['equivalence_maxima']['task_objective_abs_difference']}
- Maximum torque-regularizer difference: {eq_summary['equivalence_maxima']['torque_regularizer_abs_difference']}

{'The direct instantaneous projection implementation is numerically consistent with the equivalent lexicographic soft-task WBC formulation under the tested fixed-support convex model.' if passed else 'The frozen all-case gate did not pass. No equivalence claim is issued; case-level causes are retained in eq_cases.csv and solver_diagnostics.jsonl.'}

## Comparison B: P0 vs B1-soft

The case table reports desired-task error, task-output separation, normalized
torque norm, contact-force norm, active torque/friction constraints, and solve
time. Differences are interpreted only as effects of the weighted torque
regularizer under shared constraints. They are not a win/loss score and do not
support a projection-superiority claim.

## Independent physical validation

Frozen thresholds are dynamics <= {validation_thresholds['dynamics_infinity_norm']},
contact <= {validation_thresholds['contact_infinity_norm']}, and hard inequality
violation <= {validation_thresholds['hard_inequality_violation']}. Maximum
successful-witness values were respectively
{eq_summary['maxima_all_successful_witnesses_original_units']['dynamics_infinity_norm']},
{eq_summary['maxima_all_successful_witnesses_original_units']['contact_infinity_norm']},
and {eq_summary['maxima_all_successful_witnesses_original_units']['hard_inequality_violation']}.
These values were recomputed in original units; solver status was never used as
a substitute for the certificate.

Threshold exceedance counts were: dynamics
{physical_failure_counts['dynamics']}, contact
{physical_failure_counts['contact']}, and hard inequalities
{physical_failure_counts['hard_inequality']}. Detailed worst cases and the
per-stage status distribution are stored in `eq_summary.json`.

## Tests and stage boundary

Compileall passed before execution. {args.verified_test_count} unit/integration
tests passed, preserving the prior 32 and adding the requested STEP-02 tests.
The optional single-step sanity check was not run because it is permitted only
after the complete snapshot gate passes. E1, E2, MPC, recoverability, walking,
contact switching, RL, and health estimation were not started.

NEXT_STAGE_ALLOWED = {'E1_ONLY' if passed else 'FALSE'}
"""
    (output / "STEP02_REPORT.md").write_text(report, encoding="utf-8")
    print(json.dumps(_json_safe(result), indent=2, ensure_ascii=False))
    return 0 if passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
