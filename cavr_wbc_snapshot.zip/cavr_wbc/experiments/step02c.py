"""Execute the frozen STEP-02C regression gate and one-shot 245-case panel."""

from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import math
from pathlib import Path
import subprocess
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mujoco
import numpy as np
import yaml

from cavr_wbc.control.clarabel_p0 import (
    ClarabelP0Production,
    ClarabelP0Settings,
)
from cavr_wbc.control.fixed_support_qp import (
    QpSolveResult,
    build_contact_template,
    build_physical_snapshot,
)
from cavr_wbc.control.independent_lex_reference import (
    ClarabelReferenceSettings,
    IndependentLexicographicReference,
)
from cavr_wbc.control.scaled_fixed_support_qp import (
    ScaledFixedSupportPhysicalQp,
    Step02rSolverSettings,
    physical_validation_pass,
)
from cavr_wbc.platforms.go2_mujoco import (
    extract_actuator_joint_map,
    load_go2_model,
)


PARENT_ROOT = Path("artifacts/step02_b1_p0_equivalence")
STEP02R_ROOT = Path("artifacts/step02r_b1_p0_equivalence")
DEFAULT_OUTPUT = Path("artifacts/step02c_b1_p0_equivalence")
REGRESSION_CASES = (
    {
        "regression_id": "A_previous_stage2_primal_infeasible",
        "snapshot_id": "contact_nullspace_1_plus",
        "health_id": "healthy",
        "demand_id": "infeasible_positive_mix",
    },
    {
        "regression_id": "B_previous_worst_normal_upper",
        "snapshot_id": "contact_nullspace_0_minus",
        "health_id": "FR_calf_rho_0.25",
        "demand_id": "infeasible_positive_mix",
    },
    {
        "regression_id": "C_damaged_actuator_boundary",
        "snapshot_id": "home_nominal",
        "health_id": "FR_calf_rho_0.25",
        "demand_id": "infeasible_positive_mix",
    },
    {
        "regression_id": "D_ordinary_feasible",
        "snapshot_id": "home_nominal",
        "health_id": "healthy",
        "demand_id": "small_zero",
    },
)
METRIC_FIELDS = (
    "stage_a_normalized_task_output_inf_difference",
    "stage_a_task_objective_abs_difference",
    "stage_b_normalized_task_output_inf_difference",
    "stage_b_task_objective_abs_difference",
    "stage_b_torque_regularizer_abs_difference",
)


def _json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    if isinstance(value, np.ndarray):
        return _json_safe(value.tolist())
    if isinstance(value, (np.floating, float)):
        number = float(value)
        if math.isinf(number):
            return "Infinity" if number > 0.0 else "-Infinity"
        return number if math.isfinite(number) else "NaN"
    if isinstance(value, np.integer):
        return int(value)
    if isinstance(value, np.bool_):
        return bool(value)
    return value


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(_json_safe(value), indent=2, ensure_ascii=False, allow_nan=False)
        + "\n",
        encoding="utf-8",
    )


def _write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(
                json.dumps(_json_safe(row), ensure_ascii=False, allow_nan=False)
                + "\n"
            )


def _write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        raise ValueError(f"empty required audit table: {path}")
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(_json_safe(rows))


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _version(name: str) -> str | None:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return None


def _result_record(case: dict[str, Any], result: QpSolveResult | None) -> dict[str, Any]:
    if result is None:
        return {
            **case,
            "method": "NOT_LAUNCHED",
            "status": "UPSTREAM_STAGE_INVALID",
            "success": False,
            "validation": {"available": False},
        }
    return {
        **case,
        "method": result.method,
        "status": result.status,
        "status_val": result.status_val,
        "success": result.success,
        "iterations": result.iterations,
        "solve_time_s": result.solve_time_s,
        "setup_time_s": result.setup_time_s,
        "primal_residual": result.primal_residual,
        "dual_residual": result.dual_residual,
        "duality_gap": result.validation.get("duality_gap"),
        "solver_objective": result.solver_objective,
        "solver_dual_objective": result.validation.get(
            "solver_dual_objective"
        ),
        "qdd": result.qdd,
        "tau": result.tau,
        "contact_force": result.contact_force,
        "task_output": result.task_output,
        "task_objective": result.task_objective,
        "torque_regularizer": result.torque_regularizer,
        "validation": result.validation,
    }


def _task_objective(snapshot: Any, desired: np.ndarray, output: np.ndarray) -> float:
    residual = (output - desired) / snapshot.task_scales
    return float(np.sum(snapshot.task_weights * np.square(residual)))


def _comparison_metrics(
    snapshot: Any,
    desired: np.ndarray,
    p0_a: QpSolveResult | None,
    p0_b: QpSolveResult | None,
    ref_a: QpSolveResult | None,
    ref_b: QpSolveResult | None,
) -> dict[str, float | None]:
    if not all(
        result is not None and result.success
        for result in (p0_a, p0_b, ref_a, ref_b)
    ):
        return {field: None for field in METRIC_FIELDS}
    return {
        "stage_a_normalized_task_output_inf_difference": float(
            np.max(
                np.abs(
                    (p0_a.task_output - ref_a.task_output)
                    / snapshot.task_scales
                )
            )
        ),
        "stage_a_task_objective_abs_difference": abs(
            float(p0_a.task_objective) - float(ref_a.task_objective)
        ),
        "stage_b_normalized_task_output_inf_difference": float(
            np.max(
                np.abs(
                    (p0_b.task_output - ref_b.task_output)
                    / snapshot.task_scales
                )
            )
        ),
        "stage_b_task_objective_abs_difference": abs(
            _task_objective(snapshot, desired, p0_b.task_output)
            - _task_objective(snapshot, desired, ref_b.task_output)
        ),
        "stage_b_torque_regularizer_abs_difference": abs(
            float(p0_b.torque_regularizer) - float(ref_b.torque_regularizer)
        ),
    }


def _equivalence_pass(metrics: dict[str, Any], thresholds: dict[str, float]) -> bool:
    return bool(
        all(metrics[field] is not None for field in METRIC_FIELDS)
        and metrics["stage_a_normalized_task_output_inf_difference"]
        <= thresholds["normalized_task_equivalence"]
        and metrics["stage_b_normalized_task_output_inf_difference"]
        <= thresholds["normalized_task_equivalence"]
        and metrics["stage_a_task_objective_abs_difference"]
        <= thresholds["task_objective_difference"]
        and metrics["stage_b_task_objective_abs_difference"]
        <= thresholds["task_objective_difference"]
        and metrics["stage_b_torque_regularizer_abs_difference"]
        <= thresholds["torque_regularizer_difference"]
    )


def _fixed_band_pass(result: QpSolveResult | None, tolerance: float) -> bool:
    return bool(
        result is not None
        and result.success
        and result.validation.get("fixed_task_normalized_infinity_error")
        is not None
        and result.validation["fixed_task_normalized_infinity_error"]
        <= tolerance
    )


def _stats(values: list[float]) -> dict[str, float | None]:
    if not values:
        return {"max": None, "p95": None, "median": None}
    data = np.asarray(values, dtype=float)
    return {
        "max": float(np.max(data)),
        "p95": float(np.percentile(data, 95)),
        "median": float(np.median(data)),
    }


def _stratified_stats(rows: list[dict[str, Any]]) -> dict[str, Any]:
    summary: dict[str, Any] = {
        "overall": {
            field: _stats([float(row[field]) for row in rows])
            for field in METRIC_FIELDS
        }
    }
    for key in ("snapshot_id", "health_id", "task_class"):
        summary[key] = {}
        for value in sorted({str(row[key]) for row in rows}):
            selected = [row for row in rows if str(row[key]) == value]
            summary[key][value] = {
                field: _stats([float(row[field]) for row in selected])
                for field in METRIC_FIELDS
            }
    return summary


def _rho_vector(
    model: mujoco.MjModel,
    health: dict[str, Any],
    actuator_index: dict[str, int],
) -> np.ndarray:
    rho = np.ones(model.nu)
    if health["actuator"] is not None:
        rho[actuator_index[health["actuator"]]] = float(health["rho"])
    return rho


def _solve_case(
    *,
    snapshot: Any,
    rho: np.ndarray,
    desired: np.ndarray,
    tolerance: float,
    lambda_tau: float,
    thresholds: dict[str, float],
    production_settings: ClarabelP0Settings,
    reference_settings: ClarabelReferenceSettings,
    osqp_settings: Step02rSolverSettings,
    guard_fraction: float,
) -> dict[str, QpSolveResult | None]:
    production = ClarabelP0Production(
        snapshot,
        rho,
        production_settings,
        secondary_task_fix_normalized_tolerance=tolerance,
        fixed_task_numerical_guard_fraction=guard_fraction,
    )
    p0_a = production.solve_stage_a(desired)
    p0_b = (
        production.solve_stage_b(p0_a.task_output, lambda_tau)
        if physical_validation_pass(p0_a, thresholds)
        else None
    )
    soft = production.solve_b1_soft(desired, lambda_tau)

    reference = IndependentLexicographicReference(
        snapshot,
        rho,
        reference_settings,
        secondary_task_fix_normalized_tolerance=tolerance,
    )
    ref_a = reference.solve_stage_a(desired)
    ref_b = (
        reference.solve_stage_b(ref_a.task_output, lambda_tau)
        if physical_validation_pass(ref_a, thresholds)
        else None
    )
    osqp = ScaledFixedSupportPhysicalQp(
        snapshot,
        rho,
        osqp_settings,
        secondary_task_fix_normalized_tolerance=tolerance,
    )
    osqp_a = osqp.solve_p0_stage1(desired)
    return {
        "p0_a": p0_a,
        "p0_b": p0_b,
        "ref_a": ref_a,
        "ref_b": ref_b,
        "soft": soft,
        "osqp_a": osqp_a,
        "production": production,
        "reference": reference,
        "osqp": osqp,
    }


def _figures(
    output: Path,
    eq_rows: list[dict[str, Any]],
    soft_rows: list[dict[str, Any]],
    diagnostics: dict[str, list[dict[str, Any]]],
) -> None:
    plt.rcParams.update({"figure.dpi": 150, "font.size": 9})

    fig, ax = plt.subplots(figsize=(5.4, 4.5))
    x = [row["p0_stage_b_task_norm"] for row in eq_rows]
    y = [row["reference_stage_b_task_norm"] for row in eq_rows]
    ax.scatter(x, y, s=12, alpha=0.65)
    low = min(x + y)
    high = max(x + y)
    ax.plot([low, high], [low, high], "k--", linewidth=1)
    ax.set_xlabel("P0 Clarabel final task norm")
    ax.set_ylabel("Independent reference final task norm")
    ax.set_title("P0 vs independent lexicographic reference")
    fig.tight_layout()
    fig.savefig(output / "p0_vs_independent_reference_task.png")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(6.2, 4.2))
    ax.plot(
        [max(row["stage_a_task_objective_abs_difference"], 1e-18) for row in eq_rows],
        label="Stage A",
        linewidth=1,
    )
    ax.plot(
        [max(row["stage_b_task_objective_abs_difference"], 1e-18) for row in eq_rows],
        label="Stage B",
        linewidth=1,
    )
    ax.axhline(1e-7, color="red", linestyle="--", label="gate")
    ax.set_yscale("log")
    ax.set_xlabel("frozen case index")
    ax.set_ylabel("absolute task-objective difference")
    ax.set_title("Task-objective equivalence")
    ax.legend()
    fig.tight_layout()
    fig.savefig(output / "task_objective_difference.png")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(6.2, 4.2))
    ax.plot(
        [max(row["stage_b_torque_regularizer_abs_difference"], 1e-18) for row in eq_rows],
        linewidth=1,
    )
    ax.axhline(1e-6, color="red", linestyle="--", label="gate")
    ax.set_yscale("log")
    ax.set_xlabel("frozen case index")
    ax.set_ylabel("absolute torque-regularizer difference")
    ax.set_title("Secondary regularizer equivalence")
    ax.legend()
    fig.tight_layout()
    fig.savefig(output / "torque_regularizer_difference.png")
    plt.close(fig)

    task_classes = sorted({row["task_class"] for row in eq_rows})
    fig, ax = plt.subplots(figsize=(7.0, 4.4))
    values = [
        [
            max(row["stage_b_normalized_task_output_inf_difference"], 1e-18)
            for row in eq_rows
            if row["task_class"] == task_class
        ]
        for task_class in task_classes
    ]
    ax.boxplot(values, tick_labels=task_classes, showfliers=True)
    ax.axhline(1e-6, color="red", linestyle="--", label="gate")
    ax.set_yscale("log")
    ax.tick_params(axis="x", rotation=18)
    ax.set_ylabel("normalized final-task infinity difference")
    ax.set_title("Equivalence error by task-demand class")
    ax.legend()
    fig.tight_layout()
    fig.savefig(output / "equivalence_error_by_task_class.png")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7.0, 4.4))
    labels: list[str] = []
    residuals: list[float] = []
    for name in ("p0", "reference", "soft"):
        for row in diagnostics[name]:
            validation = row.get("validation", {})
            if validation.get("available"):
                labels.append(name)
                residuals.append(
                    max(
                        validation["dynamics_infinity_norm"],
                        validation["contact_infinity_norm"],
                        validation["hard_inequality_violation"],
                        1e-18,
                    )
                )
    colors = {"p0": "tab:blue", "reference": "tab:orange", "soft": "tab:green"}
    for name in colors:
        indices = [index for index, label in enumerate(labels) if label == name]
        ax.scatter(indices, [residuals[index] for index in indices], s=7, alpha=0.6, label=name)
    ax.axhline(1e-7, color="red", linestyle="--", label="hard gate")
    ax.axhline(1e-6, color="purple", linestyle="--", label="equality gate")
    ax.set_yscale("log")
    ax.set_xlabel("successful Clarabel solve index")
    ax.set_ylabel("maximum original-unit residual")
    ax.set_title("Original-unit physical residuals")
    ax.legend()
    fig.tight_layout()
    fig.savefig(output / "physical_residuals.png")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(6.2, 4.4))
    cross = [
        row["osqp_to_p0_stage_a_normalized_task_output_inf_difference"]
        for row in eq_rows
        if row["osqp_to_p0_stage_a_normalized_task_output_inf_difference"] is not None
    ]
    ax.plot([max(value, 1e-18) for value in cross], linewidth=1)
    ax.axhline(1e-6, color="red", linestyle="--", label="primary equivalence gate")
    ax.set_yscale("log")
    ax.set_xlabel("OSQP-success diagnostic case index")
    ax.set_ylabel("OSQP A vs P0 A normalized task difference")
    ax.set_title("Scaled OSQP Stage-A cross-check")
    ax.legend()
    fig.tight_layout()
    fig.savefig(output / "osqp_stage_a_crosscheck.png")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(6.2, 4.4))
    ax.scatter(
        [row["p0_desired_task_error_l2"] for row in soft_rows],
        [row["b1soft_desired_task_error_l2"] for row in soft_rows],
        c=[row["normalized_task_output_difference_l2"] for row in soft_rows],
        s=14,
        alpha=0.7,
    )
    ax.set_xlabel("P0 desired-task error L2")
    ax.set_ylabel("B1-soft desired-task error L2")
    ax.set_title("B1-soft vs P0 task difference")
    fig.tight_layout()
    fig.savefig(output / "b1soft_vs_p0_task_difference.png")
    plt.close(fig)


def _one_step_diagnostics(
    model: mujoco.MjModel,
    config: dict[str, Any],
    snapshots: dict[str, Any],
    full_results: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for spec in config["optional_one_step_diagnostics"]["cases"]:
        case_id = (
            f"{spec['snapshot_id']}__{spec['health_id']}__{spec['demand_id']}"
        )
        result = full_results[case_id]["p0_b"]
        snapshot = snapshots[spec["snapshot_id"]]
        data = mujoco.MjData(model)
        data.qpos[:] = snapshot.qpos
        data.qvel[:] = 0.0
        data.ctrl[:] = result.tau
        mujoco.mj_forward(model, data)
        before = data.qvel.copy()
        contacts_before = int(data.ncon)
        mujoco.mj_step(model, data)
        observed = (data.qvel - before) / float(model.opt.timestep)
        difference = observed - result.qdd
        rows.append(
            {
                **spec,
                "case_id": case_id,
                "simulator_timestep_s": float(model.opt.timestep),
                "actual_contacts_before_step": contacts_before,
                "actual_contacts_after_step": int(data.ncon),
                "predicted_qdd": result.qdd,
                "observed_short_step_qdd": observed,
                "qdd_difference_l2": float(np.linalg.norm(difference)),
                "qdd_difference_infinity": float(np.max(np.abs(difference))),
                "interpretation": "implementation_sanity_check_not_E1",
            }
        )
    return rows


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--config", default="configs/dev/step02c_b1_p0_equivalence.yaml"
    )
    parser.add_argument("--output", default=str(DEFAULT_OUTPUT))
    parser.add_argument("--verified-test-count", type=int, default=0)
    args = parser.parse_args()
    config_path = Path(args.config)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    if not (output / "STEP02R_DISPOSITION.md").is_file():
        raise FileNotFoundError("STEP02R_DISPOSITION.md must precede implementation")
    if not STEP02R_ROOT.is_dir() or not PARENT_ROOT.is_dir():
        raise FileNotFoundError("frozen STEP-02 and STEP-02R parent artifacts required")

    config_text = config_path.read_text(encoding="utf-8")
    config = yaml.safe_load(config_text)
    v1_config = yaml.safe_load((PARENT_ROOT / "config.yaml").read_text(encoding="utf-8"))
    frozen_keys = (
        "platform",
        "physical_model",
        "snapshot_panel",
        "task_stack",
        "objectives",
        "validation",
        "health_panel",
        "task_demands",
    )
    scientific_freeze = {key: config[key] == v1_config[key] for key in frozen_keys}
    if not all(scientific_freeze.values()):
        raise ValueError(f"STEP-02C scientific freeze mismatch: {scientific_freeze}")
    if config["production_numerical_contract"][
        "external_fixed_task_normalized_tolerance"
    ] != config["objectives"]["secondary_task_fix_normalized_tolerance"]:
        raise ValueError("production external task band differs from frozen objective")

    panel = json.loads((PARENT_ROOT / "snapshot_panel.json").read_text(encoding="utf-8"))[
        "states"
    ]
    model = load_go2_model()
    nominal_data = mujoco.MjData(model)
    mujoco.mj_resetDataKeyframe(
        model,
        nominal_data,
        mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_KEY, "home"),
    )
    mujoco.mj_forward(model, nominal_data)
    template = build_contact_template(model, nominal_data)
    total_weight = float(np.sum(model.body_mass) * abs(model.opt.gravity[2]))
    snapshots = {
        item["snapshot_id"]: build_physical_snapshot(
            model,
            template,
            item["snapshot_id"],
            item["qpos"],
            task_scales=config["task_stack"]["normalization_scales"],
            task_weights=config["task_stack"]["weight_diagonal"],
            normal_force_upper=total_weight,
        )
        for item in panel
    }
    health_by_id = {item["health_id"]: item for item in config["health_panel"]}
    demand_by_id = {item["demand_id"]: item for item in config["task_demands"]}
    actuator_index = {
        item.actuator_name: item.actuator_index
        for item in extract_actuator_joint_map(model)
    }
    tolerance = float(config["objectives"]["secondary_task_fix_normalized_tolerance"])
    lambda_tau = float(config["objectives"]["lambda_tau"])
    thresholds = config["validation"]
    guard_fraction = float(
        config["production_numerical_contract"][
            "internal_fixed_task_guard_fraction"
        ]
    )
    production_settings = ClarabelP0Settings(**config["clarabel_production"])
    reference_settings = ClarabelReferenceSettings(**config["clarabel_reference"])
    osqp_settings = Step02rSolverSettings(**config["osqp_stage_a_diagnostic"])
    generated_at = datetime.now(timezone.utc).astimezone().isoformat()

    print("STEP-02C frozen regression gate: exactly 4 cases")
    regression_rows: list[dict[str, Any]] = []
    hybrid_rows: list[dict[str, Any]] = []
    representative_audit: dict[str, Any] | None = None
    accepted_settings: dict[str, Any] = {}
    for spec in REGRESSION_CASES:
        snapshot = snapshots[spec["snapshot_id"]]
        health = health_by_id[spec["health_id"]]
        demand = demand_by_id[spec["demand_id"]]
        desired = np.asarray(demand["y_d"], dtype=float)
        rho = _rho_vector(model, health, actuator_index)
        case = {
            **spec,
            "task_class": demand["class"],
            "case_id": f"{spec['snapshot_id']}__{spec['health_id']}__{spec['demand_id']}",
        }
        bundle = _solve_case(
            snapshot=snapshot,
            rho=rho,
            desired=desired,
            tolerance=tolerance,
            lambda_tau=lambda_tau,
            thresholds=thresholds,
            production_settings=production_settings,
            reference_settings=reference_settings,
            osqp_settings=osqp_settings,
            guard_fraction=guard_fraction,
        )
        p0_a = bundle["p0_a"]
        p0_b = bundle["p0_b"]
        ref_a = bundle["ref_a"]
        ref_b = bundle["ref_b"]
        soft = bundle["soft"]
        osqp_a = bundle["osqp_a"]
        metrics = _comparison_metrics(snapshot, desired, p0_a, p0_b, ref_a, ref_b)
        checks = {
            "p0_stage_a": physical_validation_pass(p0_a, thresholds),
            "p0_stage_b": physical_validation_pass(p0_b, thresholds),
            "p0_stage_b_fixed_band": _fixed_band_pass(p0_b, tolerance),
            "reference_stage_a": physical_validation_pass(ref_a, thresholds),
            "reference_stage_b": physical_validation_pass(ref_b, thresholds),
            "reference_stage_b_fixed_band": _fixed_band_pass(ref_b, tolerance),
            "b1_soft": physical_validation_pass(soft, thresholds),
            "equivalence": _equivalence_pass(metrics, thresholds),
        }
        regression_pass = all(checks.values())
        regression_rows.append(
            {
                **case,
                "checks": checks,
                "metrics": metrics,
                "statuses": {
                    key: None if bundle[key] is None else bundle[key].status
                    for key in ("p0_a", "p0_b", "ref_a", "ref_b", "soft", "osqp_a")
                },
                "p0_stage_b_fixed_task_error": (
                    None
                    if p0_b is None
                    else p0_b.validation.get("fixed_task_normalized_infinity_error")
                ),
                "reference_stage_b_fixed_task_error": (
                    None
                    if ref_b is None
                    else ref_b.validation.get("fixed_task_normalized_infinity_error")
                ),
                "regression_pass": regression_pass,
            }
        )

        hybrid_b = (
            bundle["production"].solve_stage_b(osqp_a.task_output, lambda_tau)
            if physical_validation_pass(osqp_a, thresholds)
            else None
        )
        hybrid_checks = {
            "osqp_stage_a_physical": physical_validation_pass(osqp_a, thresholds),
            "clarabel_stage_b_success": bool(hybrid_b is not None and hybrid_b.success),
            "clarabel_stage_b_physical": physical_validation_pass(hybrid_b, thresholds),
            "clarabel_stage_b_fixed_band": _fixed_band_pass(hybrid_b, tolerance),
        }
        hybrid_rows.append(
            {
                **case,
                "checks": hybrid_checks,
                "hybrid_pass": all(hybrid_checks.values()),
                "osqp_stage_a": _result_record(case, osqp_a),
                "clarabel_stage_b": _result_record(case, hybrid_b),
            }
        )
        if representative_audit is None:
            representative_audit = bundle["production"].audit_problem(
                desired_task=desired,
                torque_regularization_weight=lambda_tau,
                fixed_task_output=p0_a.task_output,
            )
        accepted_settings = {
            "clarabel_production": bundle["production"].accepted_settings,
            "clarabel_reference": bundle["reference"].accepted_settings,
            "osqp_stage_a_diagnostic": bundle["osqp"].accepted_osqp_settings,
        }
        print(f"  {spec['regression_id']}: {'PASS' if regression_pass else 'FAIL'}")

    regression_solver_pass = all(row["regression_pass"] for row in regression_rows)
    regression_gate_pass = regression_solver_pass and args.verified_test_count >= 62
    hybrid_all_pass = all(row["hybrid_pass"] for row in hybrid_rows)
    hybrid_classification = (
        "OSQP_STAGE_A_TARGETS_CERTIFIED_FEASIBLE_ON_REGRESSIONS"
        if hybrid_all_pass
        else "HYBRID_DIAGNOSTIC_FAILURE"
    )
    _write_json(
        output / "regression_results.json",
        {
            "generated_at": generated_at,
            "lineage": ["STEP02_FAIL", "STEP02R_FAIL", "STEP02C"],
            "verified_test_count": args.verified_test_count,
            "previous_test_requirement_met": args.verified_test_count >= 52,
            "new_test_requirement_met": args.verified_test_count >= 62,
            "regression_pass_count": sum(row["regression_pass"] for row in regression_rows),
            "regression_gate_pass": regression_gate_pass,
            "full_panel_authorized": regression_gate_pass,
            "cases": regression_rows,
        },
    )
    _write_json(
        output / "hybrid_osqp_a_clarabel_b.json",
        {
            "diagnostic_only": True,
            "classification": hybrid_classification,
            "pass_count": sum(row["hybrid_pass"] for row in hybrid_rows),
            "cases": hybrid_rows,
        },
    )
    _write_json(output / "p0_clarabel_assembly_audit.json", representative_audit)

    if not regression_gate_pass:
        result = {
            "stage": "STEP02C_SOLVER_AGNOSTIC_EQUIVALENCE_CLOSURE",
            "status": "FAIL",
            "stage_disposition": "STEP02C_FAIL_REVISE",
            "regression_gate_pass": False,
            "full_panel_executed": False,
            "next_stage_allowed": False,
            "e1_started": False,
        }
        _write_json(output / "STEP02C_RESULT.json", result)
        print(json.dumps(result, indent=2))
        return 2

    config_hash = _sha256(config_path)
    (output / "config.yaml").write_text(config_text, encoding="utf-8")
    (output / "config_sha256.txt").write_text(config_hash + "\n", encoding="utf-8")
    print(f"Regression gate PASS; config frozen: {config_hash}")
    print("Executing the frozen 245-case panel exactly once")

    p0_diagnostics: list[dict[str, Any]] = []
    reference_diagnostics: list[dict[str, Any]] = []
    osqp_diagnostics: list[dict[str, Any]] = []
    soft_diagnostics: list[dict[str, Any]] = []
    eq_rows: list[dict[str, Any]] = []
    soft_rows: list[dict[str, Any]] = []
    full_results: dict[str, dict[str, Any]] = {}
    count = 0
    for snapshot_item in panel:
        snapshot_id = snapshot_item["snapshot_id"]
        snapshot = snapshots[snapshot_id]
        for health in config["health_panel"]:
            rho = _rho_vector(model, health, actuator_index)
            for demand in config["task_demands"]:
                count += 1
                desired = np.asarray(demand["y_d"], dtype=float)
                case_id = f"{snapshot_id}__{health['health_id']}__{demand['demand_id']}"
                case = {
                    "case_index": count,
                    "case_id": case_id,
                    "snapshot_id": snapshot_id,
                    "health_id": health["health_id"],
                    "demand_id": demand["demand_id"],
                    "task_class": demand["class"],
                }
                bundle = _solve_case(
                    snapshot=snapshot,
                    rho=rho,
                    desired=desired,
                    tolerance=tolerance,
                    lambda_tau=lambda_tau,
                    thresholds=thresholds,
                    production_settings=production_settings,
                    reference_settings=reference_settings,
                    osqp_settings=osqp_settings,
                    guard_fraction=guard_fraction,
                )
                p0_a = bundle["p0_a"]
                p0_b = bundle["p0_b"]
                ref_a = bundle["ref_a"]
                ref_b = bundle["ref_b"]
                soft = bundle["soft"]
                osqp_a = bundle["osqp_a"]
                full_results[case_id] = bundle
                p0_diagnostics.extend(
                    (_result_record(case, p0_a), _result_record(case, p0_b))
                )
                reference_diagnostics.extend(
                    (_result_record(case, ref_a), _result_record(case, ref_b))
                )
                soft_diagnostics.append(_result_record(case, soft))
                osqp_diagnostics.append(_result_record(case, osqp_a))

                metrics = _comparison_metrics(
                    snapshot, desired, p0_a, p0_b, ref_a, ref_b
                )
                osqp_cross_task = (
                    None
                    if not (
                        physical_validation_pass(osqp_a, thresholds)
                        and physical_validation_pass(p0_a, thresholds)
                    )
                    else float(
                        np.max(
                            np.abs(
                                (osqp_a.task_output - p0_a.task_output)
                                / snapshot.task_scales
                            )
                        )
                    )
                )
                osqp_cross_objective = (
                    None
                    if osqp_cross_task is None
                    else abs(
                        float(osqp_a.task_objective) - float(p0_a.task_objective)
                    )
                )
                checks = {
                    "p0_stage_a_physical_pass": physical_validation_pass(p0_a, thresholds),
                    "p0_stage_b_physical_pass": physical_validation_pass(p0_b, thresholds),
                    "p0_stage_b_fixed_band_pass": _fixed_band_pass(p0_b, tolerance),
                    "reference_stage_a_physical_pass": physical_validation_pass(ref_a, thresholds),
                    "reference_stage_b_physical_pass": physical_validation_pass(ref_b, thresholds),
                    "reference_stage_b_fixed_band_pass": _fixed_band_pass(ref_b, tolerance),
                    "b1_soft_physical_pass": physical_validation_pass(soft, thresholds),
                    "equivalence_pass": _equivalence_pass(metrics, thresholds),
                }
                eq_rows.append(
                    {
                        **case,
                        **metrics,
                        **checks,
                        "p0_stage_b_fixed_task_error": (
                            None if p0_b is None else p0_b.validation.get("fixed_task_normalized_infinity_error")
                        ),
                        "reference_stage_b_fixed_task_error": (
                            None if ref_b is None else ref_b.validation.get("fixed_task_normalized_infinity_error")
                        ),
                        "p0_stage_b_task_norm": (
                            None if p0_b is None else float(np.linalg.norm(p0_b.task_output))
                        ),
                        "reference_stage_b_task_norm": (
                            None if ref_b is None else float(np.linalg.norm(ref_b.task_output))
                        ),
                        "osqp_stage_a_physical_pass": physical_validation_pass(osqp_a, thresholds),
                        "osqp_stage_a_status": osqp_a.status,
                        "osqp_to_p0_stage_a_normalized_task_output_inf_difference": osqp_cross_task,
                        "osqp_to_p0_stage_a_task_objective_abs_difference": osqp_cross_objective,
                    }
                )
                if p0_b is not None and soft is not None and p0_b.success and soft.success:
                    p0_error = (p0_b.task_output - desired) / snapshot.task_scales
                    soft_error = (soft.task_output - desired) / snapshot.task_scales
                    task_difference = (
                        soft.task_output - p0_b.task_output
                    ) / snapshot.task_scales
                    soft_rows.append(
                        {
                            **case,
                            "normalized_task_output_difference_l2": float(np.linalg.norm(task_difference)),
                            "p0_desired_task_error_l2": float(np.linalg.norm(p0_error)),
                            "b1soft_desired_task_error_l2": float(np.linalg.norm(soft_error)),
                            "p0_normalized_torque_norm": p0_b.validation["torque_normalized_l2"],
                            "b1soft_normalized_torque_norm": soft.validation["torque_normalized_l2"],
                            "p0_contact_force_norm_n": p0_b.validation["contact_force_l2_n"],
                            "b1soft_contact_force_norm_n": soft.validation["contact_force_l2_n"],
                            "p0_active_torque_constraints": p0_b.validation["active_torque_constraints"],
                            "b1soft_active_torque_constraints": soft.validation["active_torque_constraints"],
                            "p0_active_friction_constraints": p0_b.validation["active_friction_constraints"],
                            "b1soft_active_friction_constraints": soft.validation["active_friction_constraints"],
                        }
                    )
                if count % 35 == 0 or count == 245:
                    print(f"  completed {count}/245 frozen cases")

    if count != 245:
        raise RuntimeError(f"frozen panel cardinality changed: {count}")
    config_hash_after = _sha256(config_path)
    config_unchanged = config_hash_after == config_hash
    gate_counts = {
        key: sum(bool(row[key]) for row in eq_rows)
        for key in (
            "p0_stage_a_physical_pass",
            "p0_stage_b_physical_pass",
            "p0_stage_b_fixed_band_pass",
            "reference_stage_a_physical_pass",
            "reference_stage_b_physical_pass",
            "reference_stage_b_fixed_band_pass",
            "b1_soft_physical_pass",
            "equivalence_pass",
        )
    }
    full_gate_pass = bool(
        len(eq_rows) == 245
        and all(value == 245 for value in gate_counts.values())
        and all(scientific_freeze.values())
        and config_unchanged
    )
    if gate_counts["b1_soft_physical_pass"] == 245:
        _write_csv(output / "b1_soft_vs_p0.csv", soft_rows)
    else:
        _write_csv(
            output / "b1_soft_vs_p0.csv",
            [{"status": "WITHHELD_UNTIL_ALL_B1_SOFT_PHYSICAL_GATES_PASS"}],
        )
    _write_csv(output / "eq_cases.csv", eq_rows)
    _write_jsonl(output / "p0_clarabel_diagnostics.jsonl", p0_diagnostics)
    _write_jsonl(output / "reference_diagnostics.jsonl", reference_diagnostics)
    _write_jsonl(output / "osqp_stage_a_diagnostics.jsonl", osqp_diagnostics)
    _write_jsonl(output / "b1_soft_diagnostics.jsonl", soft_diagnostics)

    osqp_failure_count = sum(
        not row["osqp_stage_a_physical_pass"] for row in eq_rows
    )
    osqp_classification = (
        "OSQP_STAGE_A_NUMERICAL_DIAGNOSTIC_FAILURE"
        if osqp_failure_count
        else "OSQP_STAGE_A_DIAGNOSTIC_COMPLETE"
    )
    one_step = (
        _one_step_diagnostics(model, config, snapshots, full_results)
        if full_gate_pass
        else []
    )
    _write_json(
        output / "one_step_mujoco_diagnostics.json",
        {
            "executed": full_gate_pass,
            "case_count": len(one_step),
            "is_e1": False,
            "cases": one_step,
        },
    )
    diagnostics = {
        "p0": p0_diagnostics,
        "reference": reference_diagnostics,
        "soft": soft_diagnostics,
        "osqp": osqp_diagnostics,
    }
    _figures(output, eq_rows, soft_rows, diagnostics)

    summary = {
        "lineage": ["STEP02_FAIL", "STEP02R_FAIL", "STEP02C"],
        "status": "PASS" if full_gate_pass else "FAIL",
        "stage_disposition": (
            "STEP02C_PASS_GO_TO_E1" if full_gate_pass else "STEP02C_FAIL_REVISE"
        ),
        "generated_at": generated_at,
        "config_sha256": config_hash,
        "config_hash_unchanged_through_panel": config_unchanged,
        "scientific_freeze_checks": scientific_freeze,
        "regression_gate_pass": regression_gate_pass,
        "regression_pass_count": sum(row["regression_pass"] for row in regression_rows),
        "hybrid_classification": hybrid_classification,
        "full_panel_executed_once": True,
        "full_panel_case_count": len(eq_rows),
        "gate_pass_counts": gate_counts,
        "equivalence_statistics": _stratified_stats(eq_rows),
        "osqp_stage_a_diagnostic_failure_count": osqp_failure_count,
        "osqp_stage_a_classification": osqp_classification,
        "accepted_solver_settings": accepted_settings,
        "numerical_certificate_not_formal_proof": True,
        "one_step_diagnostic_case_count": len(one_step),
        "next_stage_allowed": "E1_ONLY" if full_gate_pass else False,
    }
    _write_json(output / "eq_summary.json", summary)
    dependency_manifest = {
        "lineage": ["STEP02_FAIL", "STEP02R_FAIL", "STEP02C"],
        "python": subprocess.check_output(
            ["python", "--version"], text=True, encoding="utf-8"
        ).strip(),
        "versions": {
            name: _version(name)
            for name in (
                "mujoco",
                "numpy",
                "scipy",
                "osqp",
                "clarabel",
                "cffi",
                "pycparser",
                "PyYAML",
                "matplotlib",
            )
        },
        "cvxpy_installed": _version("cvxpy") is not None,
        "new_dependencies_installed_in_step02c": [],
    }
    _write_json(output / "dependency_manifest.json", dependency_manifest)
    lineage = {
        "stage": "STEP02C",
        "lineage": ["STEP02_FAIL", "STEP02R_FAIL", "STEP02C"],
        "preserved_commits": {
            "step02_implementation": "5b29626",
            "step02_artifacts": "ad640b9",
            "step02r_implementation": "b1304cb",
            "step02r_result": "937d193",
        },
        "step02r_disposition": "BACKEND_NUMERICAL_LIMITATION_NOT_MODEL_FAILURE",
        "step02r_reclassified_as_pass": False,
        "config_sha256": config_hash,
        "e1_started": False,
    }
    _write_json(output / "lineage.json", lineage)
    result = {
        "stage": "STEP02C_SOLVER_AGNOSTIC_EQUIVALENCE_CLOSURE",
        "status": "PASS" if full_gate_pass else "FAIL",
        "stage_disposition": summary["stage_disposition"],
        "generated_at": generated_at,
        "git_head_at_execution": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], text=True, encoding="utf-8"
        ).strip(),
        "config_sha256": config_hash,
        "regression_gate_pass": regression_gate_pass,
        "full_panel_executed": True,
        "full_panel_case_count": len(eq_rows),
        "all_primary_gates_pass": full_gate_pass,
        "recoverability_evidence": False,
        "e1_started": False,
        "next_stage_allowed": "E1_ONLY" if full_gate_pass else False,
    }
    _write_json(output / "STEP02C_RESULT.json", result)

    conclusion = (
        "Under the frozen zero-velocity four-foot fixed-support convex model, the "
        "instantaneous task projection and an independently assembled lexicographic "
        "soft-task WBC produced numerically consistent task-space and secondary "
        "solutions across the frozen DEV panel."
    )
    backend_conclusion = (
        "The previous STEP-02R failure was localized to the OSQP Stage-B numerical "
        "backend rather than the frozen physical feasibility model."
    )
    report = f"""# CAVR-WBC STEP-02C Solver-Agnostic Equivalence Closure

## Material Passport

- Origin Skill: experiment-agent
- Origin Mode: run + validate
- Origin Date: {generated_at}
- Verification Status: {'VERIFIED' if full_gate_pass else 'FAILED GATE'}
- Version Label: step02c_frozen_panel_v1

## Frozen scope and lineage

Lineage: `STEP02_FAIL -> STEP02R_FAIL -> STEP02C`. STEP-02R remains
`FAIL / REVISE` and is classified for this stage as
`BACKEND_NUMERICAL_LIMITATION_NOT_MODEL_FAILURE`. All STEP-02 and STEP-02R
artifact directories and commits were preserved.

The robot, MuJoCo model/version, five snapshots, seven health conditions,
seven task demands, task definition/scaling/weights, `lambda_tau`, contact and
friction model, force and torque bounds, fault semantics, exact external
`1e-8` task-fix gate, and all physical/equivalence thresholds match STEP-02 v1.
Config SHA256: `{config_hash}`.

## Backend and validation

The new P0 production path independently assembles the direct Clarabel QP and
does not call the independent lexicographic reference assembly or solve
methods. Both use the frozen dimensionless variable scales and are validated
in original units. A uniform 20% internal numerical feasibility guard is used
inside the production fixed-task band to make the unchanged external `1e-8`
certificate robust; the returned witness is never clipped or projected.

Clarabel KKT residuals, duality gaps, iterations, and solve times are recorded
as numerical certificates, not formal proofs. OSQP Stage-A is retained only as
a diagnostic; OSQP Stage-B was not run in the full panel.

## Gates

- Tests: {args.verified_test_count}/62 passed (52 retained + 10 STEP-02C).
- Frozen regressions: {sum(row['regression_pass'] for row in regression_rows)}/4 passed.
- Hybrid diagnostic: `{hybrid_classification}`.
- Full panel: {len(eq_rows)}/245 cases executed once.
- P0 Stage-A physical: {gate_counts['p0_stage_a_physical_pass']}/245.
- P0 Stage-B physical: {gate_counts['p0_stage_b_physical_pass']}/245.
- P0 Stage-B exact fixed band: {gate_counts['p0_stage_b_fixed_band_pass']}/245.
- Independent Stage-A physical: {gate_counts['reference_stage_a_physical_pass']}/245.
- Independent Stage-B physical: {gate_counts['reference_stage_b_physical_pass']}/245.
- Independent Stage-B exact fixed band: {gate_counts['reference_stage_b_fixed_band_pass']}/245.
- B1-soft physical: {gate_counts['b1_soft_physical_pass']}/245.
- P0/reference equivalence: {gate_counts['equivalence_pass']}/245.
- Scaled OSQP Stage-A diagnostic failures: {osqp_failure_count}/245 (`{osqp_classification}`).
- Optional one-step MuJoCo diagnostics: {len(one_step)}/3; these are implementation checks, not E1.

## Interpretation

{conclusion if full_gate_pass else 'The strict STEP-02C closure gate did not pass.'}

{backend_conclusion if full_gate_pass else 'E1 remains forbidden.'}

B1-soft/P0 differences are reported as effects of weighted regularization;
neither method is called better. No claim of novelty, superiority,
recoverability proof, or formal proof is made.

NEXT_STAGE_ALLOWED = {'E1_ONLY' if full_gate_pass else 'FALSE'}
"""
    (output / "STEP02C_REPORT.md").write_text(report, encoding="utf-8")
    print(json.dumps(_json_safe(result), indent=2, ensure_ascii=False))
    return 0 if full_gate_pass else 2


if __name__ == "__main__":
    raise SystemExit(main())
