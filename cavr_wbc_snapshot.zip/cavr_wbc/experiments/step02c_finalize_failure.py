"""Finalize STEP-02C failure artifacts without executing any solver."""

from __future__ import annotations

import csv
import hashlib
import importlib.metadata
import json
from pathlib import Path
import subprocess
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


ROOT = Path("artifacts/step02c_b1_p0_equivalence")
CONFIG = Path("configs/dev/step02c_b1_p0_equivalence.yaml")


def _write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def _write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def _write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def _version(name: str) -> str | None:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return None


def _stats(values: list[float]) -> dict[str, float]:
    ordered = sorted(values)
    p95_index = min(len(ordered) - 1, int(0.95 * len(ordered)))
    middle = len(ordered) // 2
    median = (
        ordered[middle]
        if len(ordered) % 2
        else 0.5 * (ordered[middle - 1] + ordered[middle])
    )
    return {"max": max(ordered), "p95": ordered[p95_index], "median": median}


def _placeholder(path: Path, title: str, text: str) -> None:
    fig, ax = plt.subplots(figsize=(6.2, 4.2))
    ax.axis("off")
    ax.text(0.5, 0.55, title, ha="center", va="center", fontsize=12)
    ax.text(0.5, 0.38, text, ha="center", va="center", wrap=True)
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)


def main() -> int:
    regression = json.loads((ROOT / "regression_results.json").read_text(encoding="utf-8"))
    hybrid = json.loads((ROOT / "hybrid_osqp_a_clarabel_b.json").read_text(encoding="utf-8"))
    if regression["regression_gate_pass"]:
        raise RuntimeError("failure finalizer cannot process a passing regression gate")

    config_text = CONFIG.read_text(encoding="utf-8")
    config_hash = hashlib.sha256(CONFIG.read_bytes()).hexdigest()
    (ROOT / "config.yaml").write_text(config_text, encoding="utf-8")
    (ROOT / "config_sha256.txt").write_text(config_hash + "\n", encoding="utf-8")

    p0_rows: list[dict[str, Any]] = []
    reference_rows: list[dict[str, Any]] = []
    soft_rows: list[dict[str, Any]] = []
    eq_rows: list[dict[str, Any]] = []
    for case in regression["cases"]:
        identity = {
            key: case[key]
            for key in (
                "regression_id",
                "case_id",
                "snapshot_id",
                "health_id",
                "demand_id",
                "task_class",
            )
        }
        for method, check_key in (
            ("P0_CLARABEL_PRODUCTION_STAGE_A", "p0_stage_a"),
            ("P0_CLARABEL_PRODUCTION_STAGE_B", "p0_stage_b"),
        ):
            p0_rows.append(
                {
                    **identity,
                    "scope": "regression_only",
                    "method": method,
                    "status": case["statuses"]["p0_a" if method.endswith("A") else "p0_b"],
                    "physical_pass": case["checks"][check_key],
                    "fixed_task_error": (
                        None if method.endswith("A") else case["p0_stage_b_fixed_task_error"]
                    ),
                    "kkt_detail_available": False,
                    "detail_note": "full-panel serialization was not reached",
                }
            )
        for method, check_key in (
            ("B1_LEX_REFERENCE_INDEPENDENT_STAGE_A", "reference_stage_a"),
            ("B1_LEX_REFERENCE_INDEPENDENT_STAGE_B", "reference_stage_b"),
        ):
            reference_rows.append(
                {
                    **identity,
                    "scope": "regression_only",
                    "method": method,
                    "status": case["statuses"]["ref_a" if method.endswith("A") else "ref_b"],
                    "physical_pass": case["checks"][check_key],
                    "fixed_task_error": (
                        None if method.endswith("A") else case["reference_stage_b_fixed_task_error"]
                    ),
                    "kkt_detail_available": False,
                    "detail_note": "full-panel serialization was not reached",
                }
            )
        soft_rows.append(
            {
                **identity,
                "scope": "regression_only",
                "method": "B1_SOFT_CLARABEL_PRODUCTION",
                "status": case["statuses"]["soft"],
                "physical_pass": case["checks"]["b1_soft"],
                "detail_note": "full-panel comparison withheld because regression gate failed",
            }
        )
        eq_rows.append(
            {
                **identity,
                "scope": "regression_only",
                **case["metrics"],
                "p0_stage_b_fixed_task_error": case["p0_stage_b_fixed_task_error"],
                "reference_stage_b_fixed_task_error": case[
                    "reference_stage_b_fixed_task_error"
                ],
                "equivalence_pass": case["checks"]["equivalence"],
                "regression_pass": case["regression_pass"],
            }
        )
    _write_jsonl(ROOT / "p0_clarabel_diagnostics.jsonl", p0_rows)
    _write_jsonl(ROOT / "reference_diagnostics.jsonl", reference_rows)
    _write_jsonl(
        ROOT / "osqp_stage_a_diagnostics.jsonl",
        [case["osqp_stage_a"] for case in hybrid["cases"]],
    )
    _write_jsonl(ROOT / "b1_soft_diagnostics.jsonl", soft_rows)
    _write_csv(ROOT / "eq_cases.csv", eq_rows)
    _write_csv(
        ROOT / "b1_soft_vs_p0.csv",
        [
            {
                **{key: row[key] for key in ("regression_id", "case_id", "snapshot_id", "health_id", "demand_id", "task_class")},
                "scope": "regression_only",
                "b1_soft_physical_pass": row["physical_pass"],
                "comparison_status": "WITHHELD_FULL_PANEL_NOT_AUTHORIZED",
            }
            for row in soft_rows
        ],
    )

    metrics = tuple(regression["cases"][0]["metrics"])
    summary = {
        "status": "FAIL",
        "stage_disposition": "STEP02C_FAIL_REVISE",
        "classification": "PRODUCTION_FIXED_BAND_GUARD_EQUIVALENCE_FAILURE",
        "config_archival_sha256": config_hash,
        "config_frozen_for_full_panel": False,
        "regression_gate_pass": False,
        "regression_pass_count": regression["regression_pass_count"],
        "regression_case_count": 4,
        "hybrid_classification": hybrid["classification"],
        "hybrid_pass_count": hybrid["pass_count"],
        "full_panel_authorized": False,
        "full_panel_executed": False,
        "full_panel_case_count": 0,
        "one_step_diagnostics_executed": False,
        "regression_equivalence_statistics": {
            metric: _stats([float(case["metrics"][metric]) for case in regression["cases"]])
            for metric in metrics
        },
        "regression_gate_pass_counts": {
            check: sum(bool(case["checks"][check]) for case in regression["cases"])
            for check in regression["cases"][0]["checks"]
        },
        "failure_details": {
            "A_previous_stage2_primal_infeasible": {
                "failed_metric": "stage_b_torque_regularizer_abs_difference",
                "observed": regression["cases"][0]["metrics"][
                    "stage_b_torque_regularizer_abs_difference"
                ],
                "gate": 1e-6,
            },
            "B_previous_worst_normal_upper": {
                "failed_metric": "stage_b_task_objective_abs_difference",
                "observed": regression["cases"][1]["metrics"][
                    "stage_b_task_objective_abs_difference"
                ],
                "gate": 1e-7,
            },
            "C_damaged_actuator_boundary": {
                "failed_metric": "stage_b_task_objective_abs_difference",
                "observed": regression["cases"][2]["metrics"][
                    "stage_b_task_objective_abs_difference"
                ],
                "gate": 1e-7,
            },
        },
        "next_stage_allowed": False,
    }
    _write_json(ROOT / "eq_summary.json", summary)
    _write_json(
        ROOT / "dependency_manifest.json",
        {
            "python": subprocess.check_output(
                ["python", "--version"], text=True, encoding="utf-8"
            ).strip(),
            "versions": {
                name: _version(name)
                for name in (
                    "mujoco",
                    "numpy",
                    "scipy",
                    "osqp",
                    "clarabel",
                    "cffi",
                    "pycparser",
                    "PyYAML",
                    "matplotlib",
                )
            },
            "cvxpy_installed": _version("cvxpy") is not None,
            "new_dependencies_installed_in_step02c": [],
        },
    )

    plt.rcParams.update({"figure.dpi": 150, "font.size": 9})
    labels = [case["regression_id"][0] for case in regression["cases"]]
    fig, ax = plt.subplots(figsize=(6.2, 4.2))
    ax.scatter(labels, [case["metrics"]["stage_b_normalized_task_output_inf_difference"] for case in regression["cases"]])
    ax.axhline(1e-6, color="red", linestyle="--", label="gate")
    ax.set_yscale("log")
    ax.set_ylabel("normalized final-task infinity difference")
    ax.set_title("P0 vs independent reference — regression gate")
    ax.legend()
    fig.tight_layout()
    fig.savefig(ROOT / "p0_vs_independent_reference_task.png")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(6.2, 4.2))
    width = 0.36
    x = list(range(4))
    ax.bar([value - width / 2 for value in x], [case["metrics"]["stage_a_task_objective_abs_difference"] for case in regression["cases"]], width, label="Stage A")
    ax.bar([value + width / 2 for value in x], [case["metrics"]["stage_b_task_objective_abs_difference"] for case in regression["cases"]], width, label="Stage B")
    ax.axhline(1e-7, color="red", linestyle="--", label="gate")
    ax.set_yscale("symlog", linthresh=1e-18)
    ax.set_xticks(x, labels)
    ax.set_ylabel("absolute difference")
    ax.set_title("Task-objective difference — regression gate")
    ax.legend()
    fig.tight_layout()
    fig.savefig(ROOT / "task_objective_difference.png")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(6.2, 4.2))
    ax.bar(labels, [case["metrics"]["stage_b_torque_regularizer_abs_difference"] for case in regression["cases"]])
    ax.axhline(1e-6, color="red", linestyle="--", label="gate")
    ax.set_yscale("log")
    ax.set_ylabel("absolute difference")
    ax.set_title("Torque-regularizer difference — regression gate")
    ax.legend()
    fig.tight_layout()
    fig.savefig(ROOT / "torque_regularizer_difference.png")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(6.8, 4.2))
    classes = sorted({case["task_class"] for case in regression["cases"]})
    for task_class in classes:
        selected = [case for case in regression["cases"] if case["task_class"] == task_class]
        ax.scatter([task_class] * len(selected), [case["metrics"]["stage_b_normalized_task_output_inf_difference"] for case in selected], label=task_class)
    ax.axhline(1e-6, color="red", linestyle="--", label="gate")
    ax.set_yscale("log")
    ax.tick_params(axis="x", rotation=15)
    ax.set_ylabel("normalized final-task infinity difference")
    ax.set_title("Equivalence error by task class — regression only")
    fig.tight_layout()
    fig.savefig(ROOT / "equivalence_error_by_task_class.png")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(6.2, 4.2))
    for item in hybrid["cases"]:
        validation = item["clarabel_stage_b"]["validation"]
        ax.scatter(item["regression_id"][0], max(validation["dynamics_infinity_norm"], validation["contact_infinity_norm"], validation["hard_inequality_violation"]), color="tab:blue")
    ax.axhline(1e-7, color="red", linestyle="--", label="hard gate")
    ax.axhline(1e-6, color="orange", linestyle="--", label="equality gate")
    ax.set_yscale("log")
    ax.set_ylabel("maximum original-unit residual")
    ax.set_title("Hybrid Clarabel-B physical residuals")
    ax.legend()
    fig.tight_layout()
    fig.savefig(ROOT / "physical_residuals.png")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(6.2, 4.2))
    ax.bar(labels, [max(case["osqp_stage_a"]["validation"]["dynamics_infinity_norm"], case["osqp_stage_a"]["validation"]["contact_infinity_norm"], case["osqp_stage_a"]["validation"]["hard_inequality_violation"], 1e-18) for case in hybrid["cases"]])
    ax.set_yscale("log")
    ax.set_ylabel("maximum original-unit residual")
    ax.set_title("OSQP Stage-A cross-check — regression only")
    fig.tight_layout()
    fig.savefig(ROOT / "osqp_stage_a_crosscheck.png")
    plt.close(fig)
    _placeholder(
        ROOT / "b1soft_vs_p0_task_difference.png",
        "B1-soft vs P0 task difference",
        "Full-panel comparison withheld because the regression gate failed.",
    )

    result = {
        "stage": "STEP02C_SOLVER_AGNOSTIC_EQUIVALENCE_CLOSURE",
        "status": "FAIL",
        "stage_disposition": "STEP02C_FAIL_REVISE",
        "classification": summary["classification"],
        "generated_at": regression["generated_at"],
        "git_head_at_execution": "9f5f4e13ba574040461f291539bf48ece484a7ed",
        "config_archival_sha256": config_hash,
        "config_frozen_for_full_panel": False,
        "regression_gate_pass": False,
        "full_panel_executed": False,
        "full_panel_case_count": 0,
        "recoverability_evidence": False,
        "e1_started": False,
        "next_stage_allowed": False,
    }
    _write_json(ROOT / "STEP02C_RESULT.json", result)
    report = f"""# CAVR-WBC STEP-02C Solver-Agnostic Equivalence Closure

## Material Passport

- Origin Skill: experiment-agent
- Origin Mode: run + validate
- Origin Date: {regression['generated_at']}
- Verification Status: VERIFIED regression-gate failure
- Version Label: step02c_regression_gate_v1

## Frozen scope and lineage

Lineage: `STEP02_FAIL -> STEP02R_FAIL -> STEP02C`. STEP-02R remains
`FAIL / REVISE`; its STEP-02C disposition is
`BACKEND_NUMERICAL_LIMITATION_NOT_MODEL_FAILURE`. The STEP-02 and STEP-02R
artifact directories and their frozen commits were not changed.

All scientific keys match STEP-02 v1. The exact configuration used by this
failed regression attempt is archived with SHA256 `{config_hash}`. It was not
promoted to the frozen full-panel configuration because the regression gate
failed.

## Regression outcome

- Retained and new tests: 62/62 passed.
- P0 Clarabel A/B physical and fixed-band checks: 4/4 passed.
- Independent reference A/B physical and fixed-band checks: 4/4 passed.
- B1-soft physical checks: 4/4 passed.
- Hybrid OSQP-A to Clarabel-B checks: 4/4 passed.
- Primary P0/reference equivalence: 1/4 passed.

Cases A, B, and C failed only the frozen equivalence comparison. Case A had a
Stage-B torque-regularizer difference of
`{regression['cases'][0]['metrics']['stage_b_torque_regularizer_abs_difference']}`
against the `1e-6` gate. Cases B and C had Stage-B task-objective differences
of `{regression['cases'][1]['metrics']['stage_b_task_objective_abs_difference']}`
and `{regression['cases'][2]['metrics']['stage_b_task_objective_abs_difference']}`
against the `1e-7` gate. All returned primary witnesses remained physically
valid and inside the literal external `1e-8` task-fix band.

The uniform internal fixed-band feasibility guard made boundary certificates
robust but changed the secondary boundary solution enough to violate the
frozen cross-formulation equivalence gates. The failure is therefore
classified `PRODUCTION_FIXED_BAND_GUARD_EQUIVALENCE_FAILURE`.

## Stop decision

The 245-case panel was not authorized or executed. The optional one-step
MuJoCo diagnostic was not executed. E1 was not started. This run does not
support the permitted STEP-02C pass conclusions and provides no
recoverability evidence.

NEXT_STAGE_ALLOWED = FALSE
"""
    (ROOT / "STEP02C_REPORT.md").write_text(report, encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
