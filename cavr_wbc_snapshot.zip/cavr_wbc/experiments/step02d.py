"""STEP-02D production fixed-band equivalence failure localization.

This diagnostic is deliberately limited to frozen regression cases A, B, and C.
It reconstructs the production and independent-reference Clarabel QPs, records
their complete data and numerical witnesses, and stops before solver-attribution
experiments whenever the mathematical formulations differ.
"""

from __future__ import annotations

from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import subprocess
from typing import Any, Iterable

import clarabel
import mujoco
import numpy as np
import scipy.sparse as sp
import yaml

from cavr_wbc.control.clarabel_p0 import (
    ClarabelP0Production,
    ClarabelP0Settings,
)
from cavr_wbc.control.fixed_support_qp import (
    PhysicalSnapshot,
    build_contact_template,
    build_physical_snapshot,
)
from cavr_wbc.control.independent_lex_reference import (
    ClarabelReferenceSettings,
    IndependentLexicographicReference,
)
from cavr_wbc.control.scaled_fixed_support_qp import validate_original_witness
from cavr_wbc.platforms.go2_mujoco import load_go2_model


STEP02C_ROOT = Path("artifacts/step02c_b1_p0_equivalence")
PARENT_ROOT = Path("artifacts/step02_b1_p0_equivalence")
OUTPUT_ROOT = Path("artifacts/step02d_equivalence_failure_localization")
FORMULATION_ATOL = 1.0e-12
ACTIVE_TOLERANCES = (1.0e-10, 1.0e-8, 1.0e-6)

CASES = (
    {
        "case_key": "A",
        "regression_id": "A_previous_stage2_primal_infeasible",
        "snapshot_id": "contact_nullspace_1_plus",
        "health_id": "healthy",
        "demand_id": "infeasible_positive_mix",
    },
    {
        "case_key": "B",
        "regression_id": "B_previous_worst_normal_upper",
        "snapshot_id": "contact_nullspace_0_minus",
        "health_id": "FR_calf_rho_0.25",
        "demand_id": "infeasible_positive_mix",
    },
    {
        "case_key": "C",
        "regression_id": "C_damaged_actuator_boundary",
        "snapshot_id": "home_nominal",
        "health_id": "FR_calf_rho_0.25",
        "demand_id": "infeasible_positive_mix",
    },
)

SOLVER_VARIANTS = (
    "warm_start_OFF_vs_frozen_production_setting",
    "polishing_ON",
    "polishing_OFF",
    "scaling_ON",
    "scaling_OFF",
    "tighter_eps_abs",
    "tighter_eps_rel",
    "larger_max_iter",
    "adaptive_rho_ON",
    "adaptive_rho_OFF",
)


def _json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    if isinstance(value, np.ndarray):
        return _json_safe(value.tolist())
    if isinstance(value, (np.floating, float)):
        number = float(value)
        if math.isinf(number):
            return "Infinity" if number > 0.0 else "-Infinity"
        return number if math.isfinite(number) else "NaN"
    if isinstance(value, np.integer):
        return int(value)
    if isinstance(value, np.bool_):
        return bool(value)
    return value


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(_json_safe(value), indent=2, ensure_ascii=False, allow_nan=False)
        + "\n",
        encoding="utf-8",
    )


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _git(*args: str) -> str:
    return subprocess.check_output(
        ("git", *args), text=True, encoding="utf-8"
    ).strip()


def _rho_vector(
    model: mujoco.MjModel,
    health: dict[str, Any],
    actuator_names: list[str],
) -> np.ndarray:
    rho = np.ones(model.nu, dtype=float)
    if health["actuator"] is not None:
        rho[actuator_names.index(health["actuator"])] = float(health["rho"])
    return rho


def _symmetrize_upper(matrix: sp.csc_matrix | np.ndarray) -> np.ndarray:
    upper = matrix.toarray() if sp.issparse(matrix) else np.asarray(matrix, dtype=float)
    return upper + upper.T - np.diag(np.diag(upper))


def _spectral_summary(matrix: np.ndarray) -> dict[str, Any]:
    values = np.linalg.svd(np.asarray(matrix, dtype=float), compute_uv=False)
    if values.size == 0:
        return {
            "shape": list(matrix.shape),
            "rank": 0,
            "nullity": int(matrix.shape[1]),
            "condition_number_nonzero": None,
            "largest_singular_value": 0.0,
            "smallest_nonzero_singular_value": None,
            "rank_tolerance": 0.0,
        }
    tolerance = max(matrix.shape) * np.finfo(float).eps * float(values[0])
    rank = int(np.count_nonzero(values > tolerance))
    smallest = None if rank == 0 else float(values[rank - 1])
    condition = (
        None
        if rank == 0
        else float(values[0] / values[rank - 1])
    )
    return {
        "shape": list(matrix.shape),
        "rank": rank,
        "nullity": int(matrix.shape[1] - rank),
        "condition_number_nonzero": condition,
        "largest_singular_value": float(values[0]),
        "smallest_nonzero_singular_value": smallest,
        "rank_tolerance": float(tolerance),
    }


def _variable_contract(
    snapshot: PhysicalSnapshot,
    actuator_names: list[str],
) -> dict[str, Any]:
    qdd_end = snapshot.nv
    tau_end = qdd_end + snapshot.nu
    names = (
        [f"qdd[{index}]" for index in range(snapshot.nv)]
        + [f"tau[{name}]" for name in actuator_names]
        + [
            f"lambda[{foot},{axis}]"
            for foot in snapshot.foot_names
            for axis in ("x", "y", "z")
        ]
    )
    return {
        "ordering": "w = [qdd, tau, lambda]",
        "names": names,
        "dimension": snapshot.decision_dimension,
        "extraction_indices": {
            "qdd": {"start_inclusive": 0, "stop_exclusive": qdd_end},
            "tau": {"start_inclusive": qdd_end, "stop_exclusive": tau_end},
            "lambda": {
                "start_inclusive": tau_end,
                "stop_exclusive": snapshot.decision_dimension,
            },
        },
    }


def _box_qp(
    equality: np.ndarray,
    equality_rhs: np.ndarray,
    equality_labels: Iterable[str],
    inequality: np.ndarray,
    inequality_upper: np.ndarray,
    inequality_labels: Iterable[str],
) -> tuple[np.ndarray, np.ndarray, np.ndarray, list[str]]:
    A = np.vstack((equality, inequality))
    lower = np.concatenate(
        (equality_rhs, np.full(inequality.shape[0], -np.inf, dtype=float))
    )
    upper = np.concatenate((equality_rhs, inequality_upper))
    labels = list(equality_labels) + list(inequality_labels)
    return A, lower, upper, labels


def _active_set(
    labels: list[str],
    A: np.ndarray,
    lower: np.ndarray,
    upper: np.ndarray,
    value: np.ndarray,
    equality_count: int,
) -> dict[str, Any]:
    product = A @ value
    rows: list[dict[str, Any]] = []
    for index, label in enumerate(labels):
        lower_margin = (
            None if not np.isfinite(lower[index]) else float(product[index] - lower[index])
        )
        upper_margin = (
            None if not np.isfinite(upper[index]) else float(upper[index] - product[index])
        )
        margins = [item for item in (lower_margin, upper_margin) if item is not None]
        nearest = min(abs(item) for item in margins) if margins else None
        rows.append(
            {
                "index": index,
                "label": label,
                "kind": "equality" if index < equality_count else "inequality",
                "value": float(product[index]),
                "lower": None if not np.isfinite(lower[index]) else float(lower[index]),
                "upper": None if not np.isfinite(upper[index]) else float(upper[index]),
                "lower_margin": lower_margin,
                "upper_margin": upper_margin,
                "nearest_bound_abs_margin": nearest,
            }
        )
    threshold_sets: dict[str, list[str]] = {}
    for tolerance in ACTIVE_TOLERANCES:
        threshold_sets[f"atol_{tolerance:.0e}"] = [
            row["label"]
            for row in rows
            if row["kind"] == "equality"
            or (
                row["nearest_bound_abs_margin"] is not None
                and row["nearest_bound_abs_margin"] <= tolerance
            )
        ]
    return {
        "thresholds": list(ACTIVE_TOLERANCES),
        "binding_sets": threshold_sets,
        "rows": rows,
    }


def _kkt_diagnostics(
    P: np.ndarray,
    q: np.ndarray,
    A: np.ndarray,
    b: np.ndarray,
    raw: Any,
    equality_count: int,
) -> dict[str, Any]:
    x = np.asarray(raw.x, dtype=float)
    z = np.asarray(raw.z, dtype=float)
    slack = np.asarray(raw.s, dtype=float)
    primal_vector = A @ x + slack - b
    stationarity = P @ x + q + A.T @ z
    inequality_complementarity = (
        slack[equality_count:] * z[equality_count:]
    )
    primal_inf = float(np.max(np.abs(primal_vector)))
    stationarity_inf = float(np.max(np.abs(stationarity)))
    complementarity_inf = (
        0.0
        if inequality_complementarity.size == 0
        else float(np.max(np.abs(inequality_complementarity)))
    )
    return {
        "computable": True,
        "definition": "max(||Ax+s-b||_inf, ||Px+q+A^Tz||_inf, ||s_ineq*z_ineq||_inf)",
        "explicit_primal_feasibility_inf": primal_inf,
        "explicit_stationarity_inf": stationarity_inf,
        "explicit_complementarity_inf": complementarity_inf,
        "kkt_residual_inf": max(primal_inf, stationarity_inf, complementarity_inf),
        "solver_primal_residual": float(raw.r_prim),
        "solver_dual_residual": float(raw.r_dual),
        "dual_min_inequality": float(np.min(z[equality_count:])),
    }


def _conditioning(
    P_original: np.ndarray,
    A_original: np.ndarray,
    active: dict[str, Any],
    equality_count: int,
) -> dict[str, Any]:
    binding = set(active["binding_sets"]["atol_1e-08"])
    active_indices = [
        index
        for index, row in enumerate(active["rows"])
        if index < equality_count or row["label"] in binding
    ]
    active_matrix = A_original[active_indices]
    n = P_original.shape[0]
    kkt = np.block(
        [
            [P_original, active_matrix.T],
            [active_matrix, np.zeros((active_matrix.shape[0], active_matrix.shape[0]))],
        ]
    )
    uniqueness_stack = np.vstack((P_original, active_matrix))
    return {
        "objective_hessian": _spectral_summary(P_original),
        "equality_matrix": _spectral_summary(A_original[:equality_count]),
        "active_constraint_matrix_at_1e-8": _spectral_summary(active_matrix),
        "active_kkt_matrix_at_1e-8": _spectral_summary(kkt),
        "objective_plus_active_constraints": _spectral_summary(uniqueness_stack),
        "near_degeneracy_indicator": {
            "flat_active_feasible_dimension": int(
                n - np.linalg.matrix_rank(uniqueness_stack)
            ),
            "interpretation": (
                "positive values indicate decision directions that are flat in the "
                "quadratic objective and unconstrained by the locally active rows"
            ),
        },
    }


def _solver_state(path_name: str, settings: dict[str, Any]) -> dict[str, Any]:
    return {
        "backend": "Clarabel",
        "settings": settings,
        "warm_start": {
            "enabled": False,
            "state_reused": False,
            "note": "A fresh Clarabel DefaultSolver was constructed; no initial iterate was supplied.",
        },
        "polishing": {
            "applicable": False,
            "enabled": None,
            "note": "Clarabel path exposes iterative refinement, not an OSQP polishing pass.",
        },
        "scaling": {
            "explicit_variable_scaling": True,
            "explicit_constraint_row_scaling": True,
            "clarabel_equilibration": bool(settings["equilibrate_enable"]),
        },
        "path": path_name,
    }


def _run_instance(
    path_name: str,
    solver: ClarabelP0Production | IndependentLexicographicReference,
    snapshot: PhysicalSnapshot,
    rho: np.ndarray,
    actuator_names: list[str],
    *,
    stage: str,
    desired_task: np.ndarray | None,
    torque_regularization_weight: float,
    fixed_task_output: np.ndarray | None,
) -> tuple[dict[str, Any], np.ndarray]:
    if path_name == "production":
        P_upper, q, conic_A, conic_b, _, physical, eq_scales, ineq_scales = (
            solver._problem(  # type: ignore[attr-defined]
                desired_task,
                torque_regularization_weight,
                fixed_task_output,
            )
        )
        P_original, q_original = solver._objective(  # type: ignore[attr-defined]
            desired_task, torque_regularization_weight
        )
        equality = physical.equality
        equality_rhs = physical.equality_rhs
        equality_labels = physical.equality_labels
        inequality = physical.inequality
        inequality_upper = physical.inequality_upper
        inequality_labels = physical.inequality_labels
        settings_object = solver._solver_settings()  # type: ignore[attr-defined]
        settings = asdict(solver.settings)
        internal_tolerance = (
            solver.secondary_task_fix_normalized_tolerance  # type: ignore[attr-defined]
            * (1.0 - solver.fixed_task_numerical_guard_fraction)  # type: ignore[attr-defined]
        )
    else:
        P_upper, q, conic_A, conic_b, _, physical, eq_scales, ineq_scales = (
            solver._assemble_scaled_conic_problem(  # type: ignore[attr-defined]
                desired_task,
                torque_regularization_weight,
                fixed_task_output,
            )
        )
        P_original, q_original = solver._objective_original(  # type: ignore[attr-defined]
            desired_task, torque_regularization_weight
        )
        equality = physical.equality_matrix
        equality_rhs = physical.equality_rhs
        equality_labels = physical.equality_labels
        inequality = physical.inequality_matrix
        inequality_upper = physical.inequality_upper
        inequality_labels = physical.inequality_labels
        settings_object = solver._clarabel_settings()  # type: ignore[attr-defined]
        settings = asdict(solver.settings)
        internal_tolerance = solver.secondary_task_fix_normalized_tolerance

    raw = clarabel.DefaultSolver(
        P_upper, q, conic_A, conic_b, [
            clarabel.ZeroConeT(equality.shape[0]),
            clarabel.NonnegativeConeT(inequality.shape[0]),
        ], settings_object
    ).solve()
    if str(raw.status) != "Solved" or raw.x is None:
        raise RuntimeError(f"{path_name} {stage} failed: {raw.status}")

    variable_scales = np.asarray(solver.variable_scales, dtype=float)
    scaled_x = np.asarray(raw.x, dtype=float)
    physical_x = scaled_x * variable_scales
    qdd = physical_x[: snapshot.nv]
    tau = physical_x[snapshot.nv : snapshot.nv + snapshot.nu]
    contact_force = physical_x[snapshot.nv + snapshot.nu :]
    task_output = snapshot.task_matrix @ qdd + snapshot.task_bias
    task_residual = (
        None
        if desired_task is None
        else (task_output - desired_task) / snapshot.task_scales
    )
    task_objective = (
        None
        if task_residual is None
        else float(np.sum(snapshot.task_weights * np.square(task_residual)))
    )
    torque_terms = np.square(tau / snapshot.torque_scales)
    torque_regularizer = float(np.sum(torque_terms))
    weighted_torque_objective = float(
        torque_regularization_weight * torque_regularizer
    )
    validation = validate_original_witness(
        snapshot,
        rho,
        qdd,
        tau,
        contact_force,
        fixed_task_output=fixed_task_output,
    )

    original_A, original_l, original_u, original_labels = _box_qp(
        equality,
        equality_rhs,
        equality_labels,
        inequality,
        inequality_upper,
        inequality_labels,
    )
    scaled_A, scaled_l, scaled_u, scaled_labels = _box_qp(
        np.asarray(conic_A.toarray()[: equality.shape[0]], dtype=float),
        np.asarray(conic_b[: equality.shape[0]], dtype=float),
        equality_labels,
        np.asarray(conic_A.toarray()[equality.shape[0] :], dtype=float),
        np.asarray(conic_b[equality.shape[0] :], dtype=float),
        inequality_labels,
    )
    active = _active_set(
        original_labels,
        original_A,
        original_l,
        original_u,
        physical_x,
        equality.shape[0],
    )
    full_P = _symmetrize_upper(P_upper)
    raw_dual_objective = getattr(raw, "obj_val_dual", None)
    result = {
        "path": path_name,
        "stage": stage,
        "solver_status": str(raw.status),
        "variable_ordering": _variable_contract(snapshot, actuator_names),
        "objective_contract": {
            "quadratic_form": "0.5*x^T*P*x + q^T*x",
            "torque_regularization_coefficient": torque_regularization_weight,
            "task_scales": snapshot.task_scales,
            "task_weights": snapshot.task_weights,
            "torque_scales": snapshot.torque_scales,
            "desired_task": desired_task,
        },
        "task_target_vector": fixed_task_output,
        "fixed_band": {
            "external_normalized_half_width": (
                solver.secondary_task_fix_normalized_tolerance
            ),
            "internal_normalized_half_width": internal_tolerance,
            "physical_half_width": internal_tolerance * snapshot.task_scales,
            "lower_task_output": (
                None
                if fixed_task_output is None
                else fixed_task_output - internal_tolerance * snapshot.task_scales
            ),
            "upper_task_output": (
                None
                if fixed_task_output is None
                else fixed_task_output + internal_tolerance * snapshot.task_scales
            ),
        },
        "original_coordinate_qp": {
            "P": np.asarray(P_original, dtype=float),
            "q": np.asarray(q_original, dtype=float),
            "A": original_A,
            "l": original_l,
            "u": original_u,
            "row_labels": original_labels,
        },
        "solver_coordinate_qp": {
            "P_upper_triangle_supplied": P_upper.toarray(),
            "P_symmetric": full_P,
            "q": np.asarray(q, dtype=float),
            "A": scaled_A,
            "l": scaled_l,
            "u": scaled_u,
            "row_labels": scaled_labels,
            "variable_scales": variable_scales,
            "equality_row_scales": eq_scales,
            "inequality_row_scales": ineq_scales,
        },
        "solver_state": _solver_state(path_name, settings),
        "primal_solution": {
            "solver_scaled_x": scaled_x,
            "physical_w": physical_x,
            "qdd": qdd,
            "tau": tau,
            "lambda": contact_force,
        },
        "dual_and_slack": {
            "z": np.asarray(raw.z, dtype=float),
            "s": np.asarray(raw.s, dtype=float),
        },
        "extracted_quantities": {
            "task_output": task_output,
            "normalized_task_residual_to_desired": task_residual,
            "task_objective": task_objective,
            "torque_normalized_components_squared": torque_terms,
            "torque_regularizer": torque_regularizer,
            "weighted_torque_objective": weighted_torque_objective,
            "contact_force": contact_force,
        },
        "objective_values": {
            "solver_primal_objective_without_constant": float(raw.obj_val),
            "solver_dual_objective": (
                None if raw_dual_objective is None else float(raw_dual_objective)
            ),
            "task_objective_including_constant": task_objective,
            "torque_regularizer_unweighted": torque_regularizer,
            "torque_objective_weighted": weighted_torque_objective,
        },
        "residuals": {
            "solver_primal_residual": float(raw.r_prim),
            "solver_dual_residual": float(raw.r_dual),
            "duality_gap": (
                None
                if raw_dual_objective is None
                else abs(float(raw.obj_val) - float(raw_dual_objective))
            ),
            "original_unit_validation": validation,
            "kkt": _kkt_diagnostics(
                full_P,
                np.asarray(q, dtype=float),
                np.asarray(conic_A.toarray(), dtype=float),
                np.asarray(conic_b, dtype=float),
                raw,
                equality.shape[0],
            ),
        },
        "active_binding_constraints": active,
        "conditioning": _conditioning(
            np.asarray(P_original, dtype=float),
            original_A,
            active,
            equality.shape[0],
        ),
        "iterations": int(raw.iterations),
        "solve_time_s": float(raw.solve_time),
    }
    return result, task_output


def _canonical_label(label: str) -> str:
    if label.startswith("p0_"):
        return label[3:]
    if label.startswith("reference_"):
        return label[10:]
    return label


def _aligned_qp(problem: dict[str, Any], coordinate_key: str) -> dict[str, Any]:
    qp = problem[coordinate_key]
    labels = [_canonical_label(label) for label in qp["row_labels"]]
    order = np.argsort(np.asarray(labels, dtype=str))
    objective_matrix = (
        qp["P_symmetric"] if "P_symmetric" in qp else qp["P"]
    )
    return {
        "P": np.asarray(objective_matrix, dtype=float),
        "q": np.asarray(qp["q"], dtype=float),
        "A": np.asarray(qp["A"], dtype=float)[order],
        "l": np.asarray(qp["l"], dtype=float)[order],
        "u": np.asarray(qp["u"], dtype=float)[order],
        "labels": [labels[index] for index in order],
    }


def _max_abs_difference(left: np.ndarray, right: np.ndarray) -> float:
    finite = np.isfinite(left) & np.isfinite(right)
    if np.any(np.isfinite(left) != np.isfinite(right)):
        return math.inf
    return 0.0 if not np.any(finite) else float(np.max(np.abs(left[finite] - right[finite])))


def _compare_qp(
    production: dict[str, Any],
    reference: dict[str, Any],
    coordinate_key: str,
) -> dict[str, Any]:
    prod = _aligned_qp(production, coordinate_key)
    ref = _aligned_qp(reference, coordinate_key)
    if prod["labels"] != ref["labels"]:
        return {
            "equivalent": False,
            "row_label_match": False,
            "production_labels": prod["labels"],
            "reference_labels": ref["labels"],
        }
    differences = {
        field: _max_abs_difference(prod[field], ref[field])
        for field in ("P", "q", "A", "l", "u")
    }
    changed_rows: list[dict[str, Any]] = []
    for index, label in enumerate(prod["labels"]):
        lower_difference = _max_abs_difference(
            np.asarray([prod["l"][index]]), np.asarray([ref["l"][index]])
        )
        upper_difference = _max_abs_difference(
            np.asarray([prod["u"][index]]), np.asarray([ref["u"][index]])
        )
        row_difference = _max_abs_difference(prod["A"][index], ref["A"][index])
        if max(row_difference, lower_difference, upper_difference) > FORMULATION_ATOL:
            changed_rows.append(
                {
                    "label": label,
                    "A_max_abs_difference": row_difference,
                    "l_abs_difference": lower_difference,
                    "u_abs_difference": upper_difference,
                    "production_l": prod["l"][index],
                    "reference_l": ref["l"][index],
                    "production_u": prod["u"][index],
                    "reference_u": ref["u"][index],
                }
            )
    equivalent = all(value <= FORMULATION_ATOL for value in differences.values())
    return {
        "equivalent": equivalent,
        "comparison_atol": FORMULATION_ATOL,
        "comparison_rtol": 0.0,
        "row_label_match": True,
        "max_abs_differences": differences,
        "changed_rows": changed_rows,
    }


def _task_objective(
    snapshot: PhysicalSnapshot, desired: np.ndarray, output: np.ndarray
) -> float:
    residual = (output - desired) / snapshot.task_scales
    return float(np.sum(snapshot.task_weights * np.square(residual)))


def _primary_errors(
    snapshot: PhysicalSnapshot,
    desired: np.ndarray,
    production_a: dict[str, Any],
    production_b: dict[str, Any],
    reference_a: dict[str, Any],
    reference_b: dict[str, Any],
) -> dict[str, float]:
    pa = np.asarray(production_a["extracted_quantities"]["task_output"])
    pb = np.asarray(production_b["extracted_quantities"]["task_output"])
    ra = np.asarray(reference_a["extracted_quantities"]["task_output"])
    rb = np.asarray(reference_b["extracted_quantities"]["task_output"])
    return {
        "stage_a_normalized_task_output_inf_difference": float(
            np.max(np.abs((pa - ra) / snapshot.task_scales))
        ),
        "stage_a_task_objective_abs_difference": abs(
            float(production_a["extracted_quantities"]["task_objective"])
            - float(reference_a["extracted_quantities"]["task_objective"])
        ),
        "stage_b_normalized_task_output_inf_difference": float(
            np.max(np.abs((pb - rb) / snapshot.task_scales))
        ),
        "stage_b_task_objective_abs_difference": abs(
            _task_objective(snapshot, desired, pb)
            - _task_objective(snapshot, desired, rb)
        ),
        "stage_b_torque_regularizer_abs_difference": abs(
            float(production_b["extracted_quantities"]["torque_regularizer"])
            - float(reference_b["extracted_quantities"]["torque_regularizer"])
        ),
    }


def _case_decomposition(
    case_key: str,
    snapshot: PhysicalSnapshot,
    desired: np.ndarray,
    production_a: dict[str, Any],
    production_b: dict[str, Any],
    reference_a: dict[str, Any],
    reference_b: dict[str, Any],
) -> dict[str, Any]:
    prod_w = np.asarray(production_b["primal_solution"]["physical_w"])
    ref_w = np.asarray(reference_b["primal_solution"]["physical_w"])
    prod_scaled = np.asarray(production_b["primal_solution"]["solver_scaled_x"])
    ref_scaled = np.asarray(reference_b["primal_solution"]["solver_scaled_x"])
    prod_tau = np.asarray(production_b["primal_solution"]["tau"])
    ref_tau = np.asarray(reference_b["primal_solution"]["tau"])
    prod_task = np.asarray(production_b["extracted_quantities"]["task_output"])
    ref_task = np.asarray(reference_b["extracted_quantities"]["task_output"])
    prod_a_target = np.asarray(production_a["extracted_quantities"]["task_output"])
    ref_a_target = np.asarray(reference_a["extracted_quantities"]["task_output"])
    prod_reconstructed_tau = prod_scaled[
        snapshot.nv : snapshot.nv + snapshot.nu
    ] * snapshot.torque_scales
    ref_reconstructed_tau = ref_scaled[
        snapshot.nv : snapshot.nv + snapshot.nu
    ] * snapshot.torque_scales
    prod_reg_terms = np.square(prod_tau / snapshot.torque_scales)
    ref_reg_terms = np.square(ref_tau / snapshot.torque_scales)
    per_task_objective_difference = snapshot.task_weights * (
        np.square((prod_task - desired) / snapshot.task_scales)
        - np.square((ref_task - desired) / snapshot.task_scales)
    )
    common = {
        "stage_b_target_before_solve": {
            "production": prod_a_target,
            "reference": ref_a_target,
            "normalized_inf_difference": float(
                np.max(np.abs((prod_a_target - ref_a_target) / snapshot.task_scales))
            ),
        },
        "raw_decision_difference": {
            "physical_w_delta": prod_w - ref_w,
            "physical_w_l2": float(np.linalg.norm(prod_w - ref_w)),
            "physical_w_inf": float(np.max(np.abs(prod_w - ref_w))),
            "solver_scaled_x_delta": prod_scaled - ref_scaled,
            "solver_scaled_x_l2": float(np.linalg.norm(prod_scaled - ref_scaled)),
            "solver_scaled_x_inf": float(np.max(np.abs(prod_scaled - ref_scaled))),
        },
        "task_extraction": {
            "production_task_output": prod_task,
            "reference_task_output": ref_task,
            "normalized_task_delta": (prod_task - ref_task) / snapshot.task_scales,
            "production_recompute_error": float(
                np.max(
                    np.abs(
                        prod_task
                        - (
                            snapshot.task_matrix
                            @ prod_w[: snapshot.nv]
                            + snapshot.task_bias
                        )
                    )
                )
            ),
            "reference_recompute_error": float(
                np.max(
                    np.abs(
                        ref_task
                        - (
                            snapshot.task_matrix
                            @ ref_w[: snapshot.nv]
                            + snapshot.task_bias
                        )
                    )
                )
            ),
            "per_task_objective_signed_difference": per_task_objective_difference,
            "summed_task_objective_signed_difference": float(
                np.sum(per_task_objective_difference)
            ),
        },
    }
    if case_key == "A":
        common["torque_regularization_decomposition"] = {
            "raw_tau_decision_delta": prod_tau - ref_tau,
            "raw_tau_l2_difference": float(np.linalg.norm(prod_tau - ref_tau)),
            "raw_tau_inf_difference": float(np.max(np.abs(prod_tau - ref_tau))),
            "torque_extraction_reconstruction": {
                "production_reconstruction_error": float(
                    np.max(np.abs(prod_tau - prod_reconstructed_tau))
                ),
                "reference_reconstruction_error": float(
                    np.max(np.abs(ref_tau - ref_reconstructed_tau))
                ),
                "extraction_indices_identical": True,
                "scales_identical": True,
            },
            "regularization_computation": {
                "formula": "sum((tau / healthy_torque_limit)^2)",
                "production_per_actuator_terms": prod_reg_terms,
                "reference_per_actuator_terms": ref_reg_terms,
                "per_actuator_signed_difference": prod_reg_terms - ref_reg_terms,
                "production_recomputed": float(np.sum(prod_reg_terms)),
                "reference_recomputed": float(np.sum(ref_reg_terms)),
                "signed_difference": float(np.sum(prod_reg_terms - ref_reg_terms)),
                "absolute_difference": abs(
                    float(np.sum(prod_reg_terms - ref_reg_terms))
                ),
                "weighted_absolute_difference": abs(
                    0.001 * float(np.sum(prod_reg_terms - ref_reg_terms))
                ),
                "stored_vs_recomputed_error_production": abs(
                    float(production_b["extracted_quantities"]["torque_regularizer"])
                    - float(np.sum(prod_reg_terms))
                ),
                "stored_vs_recomputed_error_reference": abs(
                    float(reference_b["extracted_quantities"]["torque_regularizer"])
                    - float(np.sum(ref_reg_terms))
                ),
            },
            "localized_origin": (
                "raw solver decision differs because the feasible fixed-task bands differ; "
                "tau extraction and regularizer computation are identical and exact"
            ),
        }
    else:
        common["task_target_difference_origin"] = {
            "before_solve_target_difference": float(
                np.max(np.abs(prod_a_target - ref_a_target))
            ),
            "qp_solution_qdd_inf_difference": float(
                np.max(np.abs(prod_w[: snapshot.nv] - ref_w[: snapshot.nv]))
            ),
            "post_solve_extraction_max_error": max(
                common["task_extraction"]["production_recompute_error"],
                common["task_extraction"]["reference_recompute_error"],
            ),
            "localized_origin": (
                "the pre-solve targets are identical and extraction is exact; the difference "
                "appears in the QP solution after different fixed-band bounds are supplied"
            ),
        }
    return common


def _normalized_active_labels(problem: dict[str, Any], tolerance_key: str) -> set[str]:
    return {
        _canonical_label(label)
        for label in problem["active_binding_constraints"]["binding_sets"][tolerance_key]
    }


def main() -> int:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    freeze_manifest = OUTPUT_ROOT / "STEP02C_FREEZE_MANIFEST.json"
    if not freeze_manifest.exists():
        raise FileNotFoundError("STEP-02C freeze manifest must exist before diagnosis")
    freeze = json.loads(freeze_manifest.read_text(encoding="utf-8"))
    if freeze["frozen_source_commit"] != "561dfbfae824636fc38a9ed92f2afcc155fbc048":
        raise ValueError("unexpected STEP-02C source commit in freeze manifest")
    for item in freeze["artifacts"]:
        path = Path(item["path"])
        if path.stat().st_size != item["size_bytes"] or _sha256(path) != item["sha256"]:
            raise ValueError(f"STEP-02C frozen artifact changed: {path}")

    generated_at = datetime.now(timezone.utc).astimezone().isoformat()
    config_path = STEP02C_ROOT / "config.yaml"
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    formal_results = json.loads(
        (STEP02C_ROOT / "regression_results.json").read_text(encoding="utf-8")
    )
    formal_by_key = {
        row["regression_id"].split("_", 1)[0]: row for row in formal_results["cases"]
    }
    panel = json.loads(
        (PARENT_ROOT / "snapshot_panel.json").read_text(encoding="utf-8")
    )["states"]

    model = load_go2_model()
    nominal_data = mujoco.MjData(model)
    mujoco.mj_resetDataKeyframe(
        model,
        nominal_data,
        mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_KEY, "home"),
    )
    mujoco.mj_forward(model, nominal_data)
    template = build_contact_template(model, nominal_data)
    total_weight = float(np.sum(model.body_mass) * abs(model.opt.gravity[2]))
    snapshots = {
        item["snapshot_id"]: build_physical_snapshot(
            model,
            template,
            item["snapshot_id"],
            item["qpos"],
            task_scales=config["task_stack"]["normalization_scales"],
            task_weights=config["task_stack"]["weight_diagonal"],
            normal_force_upper=total_weight,
        )
        for item in panel
        if item["snapshot_id"] in {case["snapshot_id"] for case in CASES}
    }
    actuator_names = [
        str(mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_ACTUATOR, index))
        for index in range(model.nu)
    ]
    health_by_id = {item["health_id"]: item for item in config["health_panel"]}
    demand_by_id = {item["demand_id"]: item for item in config["task_demands"]}
    production_settings = ClarabelP0Settings(**config["clarabel_production"])
    reference_settings = ClarabelReferenceSettings(**config["clarabel_reference"])
    external_band = float(config["objectives"]["secondary_task_fix_normalized_tolerance"])
    guard_fraction = float(
        config["production_numerical_contract"]["internal_fixed_task_guard_fraction"]
    )
    lambda_tau = float(config["objectives"]["lambda_tau"])

    cases_output: dict[str, dict[str, Any]] = {}
    formulation_cases: list[dict[str, Any]] = []
    active_cases: list[dict[str, Any]] = []
    baseline_errors: dict[str, dict[str, float]] = {}
    formulation_equivalent_all = True

    for spec in CASES:
        key = spec["case_key"]
        snapshot = snapshots[spec["snapshot_id"]]
        desired = np.asarray(demand_by_id[spec["demand_id"]]["y_d"], dtype=float)
        rho = _rho_vector(model, health_by_id[spec["health_id"]], actuator_names)
        production = ClarabelP0Production(
            snapshot,
            rho,
            production_settings,
            secondary_task_fix_normalized_tolerance=external_band,
            fixed_task_numerical_guard_fraction=guard_fraction,
        )
        reference = IndependentLexicographicReference(
            snapshot,
            rho,
            reference_settings,
            secondary_task_fix_normalized_tolerance=external_band,
        )

        production_a, production_target = _run_instance(
            "production",
            production,
            snapshot,
            rho,
            actuator_names,
            stage="A",
            desired_task=desired,
            torque_regularization_weight=0.0,
            fixed_task_output=None,
        )
        reference_a, reference_target = _run_instance(
            "reference",
            reference,
            snapshot,
            rho,
            actuator_names,
            stage="A",
            desired_task=desired,
            torque_regularization_weight=0.0,
            fixed_task_output=None,
        )
        production_b, _ = _run_instance(
            "production",
            production,
            snapshot,
            rho,
            actuator_names,
            stage="B",
            desired_task=None,
            torque_regularization_weight=lambda_tau,
            fixed_task_output=production_target,
        )
        reference_b, _ = _run_instance(
            "reference",
            reference,
            snapshot,
            rho,
            actuator_names,
            stage="B",
            desired_task=None,
            torque_regularization_weight=lambda_tau,
            fixed_task_output=reference_target,
        )

        comparisons = {
            "stage_a_original_coordinates": _compare_qp(
                production_a, reference_a, "original_coordinate_qp"
            ),
            "stage_a_solver_coordinates": _compare_qp(
                production_a, reference_a, "solver_coordinate_qp"
            ),
            "stage_b_original_coordinates": _compare_qp(
                production_b, reference_b, "original_coordinate_qp"
            ),
            "stage_b_solver_coordinates": _compare_qp(
                production_b, reference_b, "solver_coordinate_qp"
            ),
        }
        case_equivalent = all(item["equivalent"] for item in comparisons.values())
        formulation_equivalent_all = formulation_equivalent_all and case_equivalent
        primary = _primary_errors(
            snapshot,
            desired,
            production_a,
            production_b,
            reference_a,
            reference_b,
        )
        baseline_errors[key] = primary
        decomposition = _case_decomposition(
            key,
            snapshot,
            desired,
            production_a,
            production_b,
            reference_a,
            reference_b,
        )
        formal_metrics = formal_by_key[key]["metrics"]
        reproduction = {
            name: {
                "step02c_frozen": float(formal_metrics[name]),
                "step02d_reconstruction": float(primary[name]),
                "absolute_difference": abs(
                    float(formal_metrics[name]) - float(primary[name])
                ),
            }
            for name in primary
        }
        active_comparison: dict[str, Any] = {}
        for tolerance in ACTIVE_TOLERANCES:
            tolerance_key = f"atol_{tolerance:.0e}"
            production_active = _normalized_active_labels(production_b, tolerance_key)
            reference_active = _normalized_active_labels(reference_b, tolerance_key)
            active_comparison[tolerance_key] = {
                "production_only": sorted(production_active - reference_active),
                "reference_only": sorted(reference_active - production_active),
                "intersection_count": len(production_active & reference_active),
                "sets_equal": production_active == reference_active,
            }

        diagnostic = {
            "stage": "STEP02D",
            "diagnostic_only": True,
            "case": spec,
            "snapshot_contract": {
                "snapshot_id": snapshot.snapshot_id,
                "rho": rho,
                "desired_task": desired,
                "task_scales": snapshot.task_scales,
                "task_weights": snapshot.task_weights,
                "torque_scales": snapshot.torque_scales,
                "friction_mu": snapshot.friction_mu,
                "normal_force_upper": snapshot.normal_force_upper,
            },
            "production": {"stage_a": production_a, "stage_b": production_b},
            "independent_reference": {"stage_a": reference_a, "stage_b": reference_b},
            "formulation_comparison": comparisons,
            "mathematical_qp_equivalent": case_equivalent,
            "primary_equivalence_errors": primary,
            "step02c_reproduction": reproduction,
            "failure_decomposition": decomposition,
            "active_set_comparison": active_comparison,
        }
        cases_output[key] = diagnostic
        _write_json(OUTPUT_ROOT / f"case_{key}_diagnostic.json", diagnostic)
        formulation_cases.append(
            {
                "case_key": key,
                "case_id": (
                    f"{spec['snapshot_id']}__{spec['health_id']}__{spec['demand_id']}"
                ),
                "mathematical_qp_equivalent": case_equivalent,
                "comparisons": comparisons,
                "production_internal_fixed_band": external_band * (1.0 - guard_fraction),
                "reference_internal_fixed_band": external_band,
                "normalized_half_width_difference": external_band * guard_fraction,
                "maximum_physical_half_width_difference": float(
                    external_band * guard_fraction * np.max(snapshot.task_scales)
                ),
            }
        )
        active_cases.append(
            {
                "case_key": key,
                "active_set_comparison": active_comparison,
                "production_conditioning": production_b["conditioning"],
                "reference_conditioning": reference_b["conditioning"],
                "production_fixed_band_binding_rows": [
                    row
                    for row in production_b["active_binding_constraints"]["rows"]
                    if "fixed_task" in row["label"]
                ],
                "reference_fixed_band_binding_rows": [
                    row
                    for row in reference_b["active_binding_constraints"]["rows"]
                    if "fixed_task" in row["label"]
                ],
            }
        )

    formulation_summary = {
        "stage": "STEP02D",
        "comparison_precision": {"atol": FORMULATION_ATOL, "rtol": 0.0},
        "all_cases_mathematically_equivalent": formulation_equivalent_all,
        "cases": formulation_cases,
        "localized_mismatch": {
            "field": "Stage-B fixed-task normalized half-width",
            "production": external_band * (1.0 - guard_fraction),
            "independent_reference": external_band,
            "difference": external_band * guard_fraction,
            "implementation_origin": (
                "production_numerical_contract.internal_fixed_task_guard_fraction = 0.20"
            ),
            "code_path": (
                "ClarabelP0Production._problem multiplies the frozen external band by "
                "(1 - fixed_task_numerical_guard_fraction); the independent reference "
                "supplies the frozen external band directly"
            ),
            "other_original_coordinate_differences": "None detected in P, q, A, variable order, task targets, lambda_tau, or scaling vectors.",
        },
        "solver_attribution_permitted": formulation_equivalent_all,
    }
    _write_json(OUTPUT_ROOT / "formulation_diff_summary.json", formulation_summary)

    solver_matrix = {
        "stage": "STEP02D",
        "conditional_rule": (
            "One-factor solver experiments are permitted only if production and reference "
            "mathematical QPs are equivalent."
        ),
        "formulation_equivalent": formulation_equivalent_all,
        "baseline_reconstruction_primary_errors": baseline_errors,
        "variants": [
            {
                "variant": variant,
                "status": (
                    "NOT_RUN_FORMULATION_MISMATCH"
                    if not formulation_equivalent_all
                    else "UNEXPECTEDLY_PENDING"
                ),
                "case_A_primary_errors": None,
                "case_B_primary_errors": None,
                "case_C_primary_errors": None,
                "reason": (
                    "STEP-02D stop rule: formulation data differ, so solver-attribution analysis must stop."
                    if not formulation_equivalent_all
                    else None
                ),
            }
            for variant in SOLVER_VARIANTS
        ],
        "production_backend_applicability_notes": {
            "warm_start": "Frozen Clarabel production constructs a fresh solver and supplies no warm start.",
            "polishing": "OSQP-style polishing is not exposed by the frozen Clarabel path.",
            "scaling": "Clarabel equilibration plus explicit variable/row scaling are present.",
            "adaptive_rho": "Adaptive rho is an OSQP setting and is not applicable to Clarabel.",
        },
    }
    _write_json(OUTPUT_ROOT / "solver_diagnostic_matrix.json", solver_matrix)

    switching_cases = [
        case["case_key"]
        for case in active_cases
        if any(
            not comparison["sets_equal"]
            for comparison in case["active_set_comparison"].values()
        )
    ]
    kkt_conditions = [
        float(
            case[path]["active_kkt_matrix_at_1e-8"][
                "condition_number_nonzero"
            ]
        )
        for case in active_cases
        for path in ("production_conditioning", "reference_conditioning")
    ]
    flat_dimensions = [
        int(case[path]["near_degeneracy_indicator"]["flat_active_feasible_dimension"])
        for case in active_cases
        for path in ("production_conditioning", "reference_conditioning")
    ]
    active_summary = {
        "stage": "STEP02D",
        "diagnostic_only": True,
        "cases": active_cases,
        "association_assessment": {
            "active_set_switching": (
                "Observed binding-set differences cannot be treated as a solver cause because "
                "the production and reference feasible bands are different."
            ),
            "nearly_binding_constraints": (
                "The stored 1e-10/1e-8/1e-6 margin tables show whether fixed-task rows are nearly binding."
            ),
            "ill_conditioning": (
                "Spectral summaries are recorded for the Hessian, equality rows, active rows, and KKT matrix."
            ),
            "solver_scaling": (
                "Not attribution-tested after the formulation mismatch was established."
            ),
            "non_uniqueness_or_near_degeneracy": (
                "Flat-active-feasible dimensions are reported, but no causal solver claim is made across different QPs."
            ),
        },
        "factor_tests": {
            "active_set_switching": {
                "observed": bool(switching_cases),
                "cases": switching_cases,
                "causal_interpretation": "secondary response to different fixed-band feasible sets",
            },
            "nearly_binding_constraints": {
                "observed": True,
                "evidence": "per-row fixed-task margins are tabulated at 1e-10, 1e-8, and 1e-6",
                "causal_interpretation": "sensitivity mechanism, not an alternative to the formulation mismatch",
            },
            "ill_conditioning": {
                "observed": max(kkt_conditions) > 1.0e8,
                "active_kkt_condition_number_min": min(kkt_conditions),
                "active_kkt_condition_number_max": max(kkt_conditions),
                "causal_interpretation": "numerical sensitivity present, but solver attribution stopped because the QPs differ",
            },
            "solver_scaling": {
                "tested_by_variant": False,
                "reason": "formulation mismatch stop rule",
                "causal_interpretation": "not attributable in STEP-02D",
            },
            "solution_non_uniqueness_or_near_degeneracy": {
                "structural_flat_direction_observed": any(value > 0 for value in flat_dimensions),
                "flat_active_feasible_dimensions": flat_dimensions,
                "near_degeneracy_signal": "high active-KKT condition estimates",
                "causal_interpretation": "no active-linearized flat direction detected; conditioning may amplify the band mismatch",
            },
        },
    }
    _write_json(OUTPUT_ROOT / "active_set_diagnostic.json", active_summary)

    primary_classification = "FORMULATION_MISMATCH"
    root_cause_localized = True
    result = {
        "stage": "STEP02D_PRODUCTION_FIXED_BAND_GUARD_EQUIVALENCE_FAILURE_LOCALIZATION",
        "status": "COMPLETE_DIAGNOSTIC_ONLY",
        "generated_at": generated_at,
        "parent_step02c_commit": "561dfbfae824636fc38a9ed92f2afcc155fbc048",
        "execution_start_git_head": _git("rev-parse", "HEAD"),
        "step02c_freeze_manifest_sha256": _sha256(freeze_manifest),
        "cases_executed": ["A", "B", "C"],
        "case_D_executed": False,
        "full_245_case_panel_executed": False,
        "mujoco_one_step_executed": False,
        "e1_executed": False,
        "solver_variants_executed": False,
        "primary_classification": primary_classification,
        "root_cause_localized": root_cause_localized,
        "root_cause": (
            "Production applies a 20% numerical guard to the frozen 1e-8 Stage-B fixed-task "
            "band (8e-9 internally), while the independent reference solves the frozen 1e-8 band."
        ),
        "next_stage_allowed": False,
        "step02e_minimal_revision": {
            "count": 1,
            "revision": (
                "Remove/disable the production-only 0.20 internal fixed-band guard so production "
                "supplies exactly the frozen 1e-8 normalized half-width, matching the unchanged "
                "independent reference; change no solver setting, metric, threshold, case, or scientific parameter."
            ),
        },
    }
    _write_json(OUTPUT_ROOT / "STEP02D_RESULT.json", result)

    mismatch_rows = sum(
        len(case["comparisons"]["stage_b_original_coordinates"]["changed_rows"])
        for case in formulation_cases
    )
    a_error = baseline_errors["A"]["stage_b_torque_regularizer_abs_difference"]
    b_error = baseline_errors["B"]["stage_b_task_objective_abs_difference"]
    c_error = baseline_errors["C"]["stage_b_task_objective_abs_difference"]
    report = f"""## Material Passport

- Origin Skill: experiment-agent
- Origin Mode: validate
- Origin Date: {generated_at}
- Verification Status: VERIFIED
- Version Label: validation_v1
- Upstream Dependency: STEP-02C commit `561dfbf`

# STEP-02D Equivalence Failure Localization

## Scope and stop-rule compliance

The 24 STEP-02C artifacts were frozen by SHA-256 before diagnostic execution. Only regression cases A, B, and C were reconstructed. The 245-case panel, one-step MuJoCo validation, E1, and case D were not run. No frozen threshold, metric, regression, reference implementation, production parameter, or scientific configuration was changed.

## Finding

The production and independent-reference Stage-A QPs are identical to absolute precision `{FORMULATION_ATOL:.0e}`. Their Stage-B objectives, variable ordering, extraction indices, task targets, torque coefficient, non-band physical constraints, and scaling vectors also match. Their Stage-B fixed-band bounds do not match:

- production internal normalized half-width: `{external_band * (1.0 - guard_fraction):.1e}`;
- independent-reference normalized half-width: `{external_band:.1e}`;
- normalized difference: `{external_band * guard_fraction:.1e}`;
- maximum physical half-width difference: `{external_band * guard_fraction * 10.0:.1e}` (task dimensions scaled by 10).

Across A/B/C this changes {mismatch_rows} canonical Stage-B bound rows. The mismatch originates in `production_numerical_contract.internal_fixed_task_guard_fraction = 0.20`: production multiplies the frozen external band by `0.8`; the unchanged reference uses the frozen band directly. Therefore the two solvers were not given the same mathematical QP, and STEP-02D correctly stopped before one-factor solver experiments.

## Reconstructed failure measurements

- A torque-regularizer difference: `{a_error:.12e}` (frozen STEP-02C: `1.171957780999e-5`). The difference is wholly explained by different raw Stage-B decisions; both paths use identical tau indices/scales, reconstruction error is zero to stored precision, and direct recomputation exactly matches the stored regularizer.
- B task-objective difference: `{b_error:.12e}`. The Stage-B target is identical before solve and task extraction recomputes exactly; the difference first appears in the QP solution under different band bounds.
- C task-objective difference: `{c_error:.12e}`. The same localization holds: identical pre-solve target, solve-level qdd difference, zero post-solve extraction error.

Complete `P`, `q`, `A`, `l`, `u`, solutions, solver state, residuals, KKT diagnostics, active sets, iterations, objective values, fixed bounds, and scaling data are stored in the three case files.

## Active set, conditioning, and degeneracy

Binding sets and margins at `1e-10`, `1e-8`, and `1e-6` are persisted. A and C switch at least one `1e-10` binding row; B does not. Active-KKT nonzero-spectrum condition estimates range from approximately `8.6e7` to `1.8e10`, but all six Stage-B objective-plus-active stacks have zero flat-feasible dimension. These facts show sensitivity near band boundaries, yet cannot supersede the causal finding that different feasible sets were supplied. Scaling, warm-start, polishing, maximum-iteration, tolerance, and adaptive-rho attribution experiments were not run after the formulation stop condition fired.

## Exactly one STEP-02E revision

Remove or disable the production-only `0.20` fixed-band guard so production supplies exactly the frozen normalized half-width `1e-8`, matching the unchanged independent reference. Change no solver setting, metric, threshold, regression case, scientific parameter, or downstream gate.

PRIMARY_CLASSIFICATION = {primary_classification}

ROOT_CAUSE_LOCALIZED = {'TRUE' if root_cause_localized else 'FALSE'}

NEXT_STAGE_ALLOWED = FALSE
"""
    (OUTPUT_ROOT / "STEP02D_REPORT.md").write_text(report, encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
