"""Deterministic, solver-free audit of the STEP-02D exact task band.

The audit calls the production and reference *runtime assembly routes*.  In
particular, it does not compare only their stand-alone constraint builders,
which would miss the production numerical guard applied by ``_problem``.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

import numpy as np

from cavr_wbc.control.clarabel_p0 import ClarabelP0Production, ClarabelP0Settings
from cavr_wbc.control.fixed_support_qp import PhysicalSnapshot
from cavr_wbc.control.independent_lex_reference import (
    ClarabelReferenceSettings,
    IndependentLexicographicReference,
)


ASSEMBLY_EPS_MULTIPLIER = 16.0
FROZEN_FIXED_TASK_TOLERANCE = 1e-8


def _compare(left: Any, right: Any) -> dict[str, Any]:
    """Compare float64 arrays at assembly round-off, never solver tolerance."""
    a = np.asarray(left, dtype=float)
    b = np.asarray(right, dtype=float)
    if a.shape != b.shape:
        return {
            "pass": False,
            "exact": False,
            "machine_allclose": False,
            "left_shape": list(a.shape),
            "right_shape": list(b.shape),
            "max_absolute_difference": None,
            "max_difference_in_epsilon_units": None,
        }
    finite = bool(np.isfinite(a).all() and np.isfinite(b).all())
    difference = np.abs(a - b)
    reference_scale = np.maximum(1.0, np.maximum(np.abs(a), np.abs(b)))
    epsilon_units = difference / (np.finfo(np.float64).eps * reference_scale)
    maximum_units = float(np.max(epsilon_units, initial=0.0))
    machine_allclose = finite and maximum_units <= ASSEMBLY_EPS_MULTIPLIER
    return {
        "pass": machine_allclose,
        "exact": finite and bool(np.array_equal(a, b)),
        "machine_allclose": machine_allclose,
        "shape": list(a.shape),
        "max_absolute_difference": float(np.max(difference, initial=0.0)),
        "max_difference_in_epsilon_units": maximum_units,
    }


def _canonical_rows(audit: dict[str, Any], kind: str) -> dict[str, Any]:
    labels = audit[f"original_{kind}_labels"]
    normalized = [label.removeprefix("p0_").removeprefix("reference_") for label in labels]
    if len(set(normalized)) != len(normalized):
        raise ValueError(f"duplicate canonical {kind} label")
    order = np.asarray(sorted(range(len(normalized)), key=normalized.__getitem__))
    matrix = np.asarray(audit[f"original_{kind}_matrix"], dtype=float)
    rhs_key = "rhs" if kind == "equality" else "upper"
    rhs = np.asarray(audit[f"original_{kind}_{rhs_key}"], dtype=float)
    return {
        "labels": [normalized[index] for index in order],
        "matrix": matrix[order],
        "rhs": rhs[order],
        "row_scaling": np.asarray(audit[f"{kind}_row_scaling"])[order],
        "order": order,
    }


def audit_pair(
    snapshot: PhysicalSnapshot,
    rho: Any,
    config: dict[str, Any],
    target: Any,
) -> dict[str, Any]:
    """Audit one physical pair and task target without constructing a solver."""
    tolerance = float(config["objectives"]["secondary_task_fix_normalized_tolerance"])
    contract = config["production_numerical_contract"]
    guard = float(contract["internal_fixed_task_guard_fraction"])
    lambda_tau = float(config["objectives"]["lambda_tau"])
    fixed = np.asarray(target, dtype=float)
    production = ClarabelP0Production(
        snapshot,
        rho,
        ClarabelP0Settings(**config["clarabel_production"]),
        secondary_task_fix_normalized_tolerance=tolerance,
        fixed_task_numerical_guard_fraction=guard,
    )
    reference = IndependentLexicographicReference(
        snapshot,
        rho,
        ClarabelReferenceSettings(**config["clarabel_reference"]),
        secondary_task_fix_normalized_tolerance=tolerance,
    )
    p0 = production.audit_problem(
        torque_regularization_weight=lambda_tau, fixed_task_output=fixed
    )
    ref = reference.audit_problem(
        torque_regularization_weight=lambda_tau, fixed_task_output=fixed
    )
    external = float(p0["external_fixed_task_tolerance"])
    internal = float(p0["internal_fixed_task_tolerance"])
    reference_tolerance = reference.secondary_task_fix_normalized_tolerance
    tolerances = {
        "production_external_task_tolerance": external,
        "production_internal_task_tolerance": internal,
        "reference_task_tolerance": reference_tolerance,
        "configured_external_task_tolerance": float(
            contract["external_fixed_task_normalized_tolerance"]
        ),
        "production_guard_fraction": guard,
        "pass": bool(
            external == internal == reference_tolerance
            == float(contract["external_fixed_task_normalized_tolerance"])
            == FROZEN_FIXED_TASK_TOLERANCE
            and guard == 0.0
        ),
    }
    checks: dict[str, dict[str, Any]] = {}
    canonical: dict[str, tuple[dict[str, Any], dict[str, Any]]] = {}
    label_checks: dict[str, bool] = {}
    for kind in ("equality", "inequality"):
        left, right = _canonical_rows(p0, kind), _canonical_rows(ref, kind)
        canonical[kind] = left, right
        label_checks[kind] = left["labels"] == right["labels"]
        checks[f"original_{kind}_matrix"] = _compare(left["matrix"], right["matrix"])
        checks[f"original_{kind}_rhs"] = _compare(left["rhs"], right["rhs"])
        checks[f"{kind}_row_scaling"] = _compare(left["row_scaling"], right["row_scaling"])

    groups = {
        "dynamics": ("equality", ("dynamics[",)),
        "contact": ("equality", ("contact_acceleration[",)),
        "torque": ("inequality", ("torque_upper[", "torque_lower[")),
        "friction": ("inequality", ("friction[",)),
        "normal_force": ("inequality", ("normal_upper[", "normal_lower[")),
        "fixed_task_upper": ("inequality", ("fixed_task_upper[",)),
        "fixed_task_lower": ("inequality", ("fixed_task_lower[",)),
    }
    group_checks: dict[str, Any] = {}
    for group, (kind, prefixes) in groups.items():
        left, right = canonical[kind]
        left_indices = [i for i, label in enumerate(left["labels"]) if label.startswith(prefixes)]
        right_indices = [i for i, label in enumerate(right["labels"]) if label.startswith(prefixes)]
        matching_labels = (
            [left["labels"][i] for i in left_indices]
            == [right["labels"][i] for i in right_indices]
        )
        matrix_check = _compare(left["matrix"][left_indices], right["matrix"][right_indices])
        rhs_check = _compare(left["rhs"][left_indices], right["rhs"][right_indices])
        group_checks[group] = {
            "row_count": len(left_indices),
            "canonical_labels": [left["labels"][i] for i in left_indices],
            "labels_identical": matching_labels,
            "matrix": matrix_check,
            "rhs": rhs_check,
            "pass": bool(matching_labels and left_indices and matrix_check["pass"] and rhs_check["pass"]),
        }

    # The conic equality and inequality blocks retain their cone types while
    # each block is reordered by its canonical physical label.
    reordered = []
    for audit in (p0, ref):
        eq = _canonical_rows(audit, "equality")
        ineq = _canonical_rows(audit, "inequality")
        order = np.concatenate((eq["order"], len(eq["labels"]) + ineq["order"]))
        reordered.append((np.asarray(audit["scaled_conic_A"])[order], np.asarray(audit["scaled_conic_b"])[order]))
    checks["scaled_conic_A"] = _compare(reordered[0][0], reordered[1][0])
    checks["scaled_conic_b"] = _compare(reordered[0][1], reordered[1][1])
    checks["variable_scales"] = _compare(p0["variable_scales"], ref["variable_scales"])

    objective_checks: dict[str, Any] = {}
    for stage, desired, weight, fixed_output in (
        ("stage_a", fixed, 0.0, None),
        ("stage_b", None, lambda_tau, fixed),
        ("b1_soft", fixed, lambda_tau, None),
    ):
        original_p0 = production._objective(desired, weight)
        original_ref = reference._objective_original(desired, weight)
        p0_objective = production.audit_problem(
            desired_task=desired, torque_regularization_weight=weight,
            fixed_task_output=fixed_output,
        )
        ref_objective = reference.audit_problem(
            desired_task=desired, torque_regularization_weight=weight,
            fixed_task_output=fixed_output,
        )
        values = {
            "original_P": _compare(original_p0[0], original_ref[0]),
            "original_q": _compare(original_p0[1], original_ref[1]),
            "transformed_P": _compare(p0_objective["scaled_P"], ref_objective["scaled_P"]),
            "transformed_q": _compare(p0_objective["scaled_q"], ref_objective["scaled_q"]),
        }
        objective_checks[stage] = {"pass": all(item["pass"] for item in values.values()), **values}

    passed = bool(
        tolerances["pass"] and all(label_checks.values())
        and all(check["pass"] for check in checks.values())
        and all(check["pass"] for check in group_checks.values())
        and all(check["pass"] for check in objective_checks.values())
    )
    return {
        "pass": passed,
        "all_pass": passed,
        "solver_executed": False,
        "assembly_route": "production.audit_problem->_problem; reference.audit_problem->_assemble_scaled_conic_problem",
        "precision_rule": "abs(a-b) <= 16 * float64_epsilon * max(1, abs(a), abs(b)) elementwise",
        "task_target": fixed.tolist(),
        "tolerances": tolerances,
        "canonical_labels_identical": label_checks,
        "physical_groups": group_checks,
        "matrix_checks": checks,
        "objective_checks": objective_checks,
    }


def audit_panel(
    snapshots: Mapping[str, PhysicalSnapshot],
    rhos: Mapping[str, Any],
    config: dict[str, Any],
) -> dict[str, Any]:
    """Audit all physical pairs with deterministic zero/nonzero task targets."""
    records = []
    for snapshot_id in sorted(snapshots):
        snapshot = snapshots[snapshot_id]
        targets = {
            "zero": np.zeros(snapshot.task_dimension),
            "deterministic_nonzero": snapshot.task_scales * np.linspace(-0.7, 0.8, snapshot.task_dimension),
        }
        for health_id in sorted(rhos):
            for target_id, target in targets.items():
                records.append({
                    "snapshot_id": snapshot_id,
                    "health_id": health_id,
                    "target_id": target_id,
                    **audit_pair(snapshot, rhos[health_id], config, target),
                })
    passed = bool(records) and all(record["pass"] for record in records)
    return {
        "stage": "STEP02D",
        "pass": passed,
        "all_pass": passed,
        "solver_executed": False,
        "snapshot_count": len(snapshots),
        "health_count": len(rhos),
        "physical_pair_count": len(snapshots) * len(rhos),
        "target_count_per_pair": 2,
        "assembly_audit_count": len(records),
        "passing_audit_count": sum(record["pass"] for record in records),
        "records": records,
    }
