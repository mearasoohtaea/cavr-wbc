"""STEP-02D exact-band audit, one-shot regressions, and gated DEV panel.

Only the new configuration changes the production guard to zero. Frozen
production, reference, OSQP and prior-stage sources/artifacts are never edited.
"""

from __future__ import annotations

import argparse
from copy import deepcopy
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import io
import json
from pathlib import Path
import subprocess
import sys
import unittest
from unittest.mock import patch

import clarabel
import mujoco
import numpy as np
import yaml

from cavr_wbc.control.clarabel_p0 import ClarabelP0Production, ClarabelP0Settings
from cavr_wbc.control.fixed_support_qp import build_contact_template, build_physical_snapshot
from cavr_wbc.control.independent_lex_reference import (
    ClarabelReferenceSettings, IndependentLexicographicReference,
)
from cavr_wbc.control.scaled_fixed_support_qp import (
    ScaledFixedSupportPhysicalQp, Step02rSolverSettings, physical_validation_pass,
    validate_original_witness, variable_scales,
)
from cavr_wbc.experiments.step02c import (
    REGRESSION_CASES, METRIC_FIELDS, _comparison_metrics, _equivalence_pass,
    _fixed_band_pass, _json_safe, _result_record, _stats, _write_csv, _write_json,
)
from cavr_wbc.experiments.step02d_exact_audit import audit_pair, audit_panel
from cavr_wbc.experiments.step02d_exact_figures import render_figures
from cavr_wbc.platforms.go2_mujoco import load_go2_model, extract_actuator_joint_map


OUTPUT = Path("artifacts/step02d_exact_band_equivalence")
CONFIG = Path("configs/dev/step02d_exact_band_equivalence.yaml")
BASELINE = Path("artifacts/step02c_b1_p0_equivalence/config.yaml")
LINEAGE = ["STEP02_FAIL", "STEP02R_FAIL", "STEP02C_FAIL", "STEP02D"]
GATES = (
    "p0_stage_a_physical_pass", "p0_stage_b_physical_pass",
    "p0_stage_b_fixed_band_pass", "reference_stage_a_physical_pass",
    "reference_stage_b_physical_pass", "reference_stage_b_fixed_band_pass",
    "b1_soft_physical_pass", "equivalence_pass",
)
METRIC_GATES = dict(zip(METRIC_FIELDS, (1e-6, 1e-7, 1e-6, 1e-7, 1e-6)))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_context(config):
    model = load_go2_model()
    data = mujoco.MjData(model)
    mujoco.mj_resetDataKeyframe(model, data, mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_KEY, "home"))
    mujoco.mj_forward(model, data)
    template = build_contact_template(model, data)
    panel = json.loads(Path("artifacts/step02_b1_p0_equivalence/snapshot_panel.json").read_text(encoding="utf-8"))["states"]
    snapshots = {
        item["snapshot_id"]: build_physical_snapshot(
            model, template, item["snapshot_id"], item["qpos"],
            task_scales=config["task_stack"]["normalization_scales"],
            task_weights=config["task_stack"]["weight_diagonal"],
            normal_force_upper=float(np.sum(model.body_mass) * abs(model.opt.gravity[2])),
        ) for item in panel
    }
    indices = {x.actuator_name: x.actuator_index for x in extract_actuator_joint_map(model)}
    rhos = {}
    for health in config["health_panel"]:
        rho = np.ones(model.nu)
        if health["actuator"] is not None:
            rho[indices[health["actuator"]]] = health["rho"]
        rhos[health["health_id"]] = rho
    assert len(snapshots) == 5 and len(rhos) == 7 and len(config["task_demands"]) == 7
    return model, snapshots, rhos


def frozen_checks(config):
    previous = yaml.safe_load(BASELINE.read_text(encoding="utf-8"))
    expected = deepcopy(previous)
    expected["production_numerical_contract"]["internal_fixed_task_guard_fraction"] = 0.0
    metadata = ("experiment", "parent_run", "lineage", "disposition")
    checks = {key: config.get(key) == value for key, value in expected.items() if key not in metadata}
    checks["no_added_numerical_fields"] = set(config) == set(expected)
    checks["guard_exactly_zero"] = config["production_numerical_contract"]["internal_fixed_task_guard_fraction"] == 0.0
    checks["literal_frozen_band"] = config["objectives"]["secondary_task_fix_normalized_tolerance"] == 1e-8
    checks["mujoco_version"] = importlib.metadata.version("mujoco") == config["platform"]["simulator_version"]
    return checks


def history_inventory():
    roots = [
        Path("artifacts/step02_b1_p0_equivalence"),
        Path("artifacts/step02r_b1_p0_equivalence"),
        Path("artifacts/step02c_b1_p0_equivalence"),
        Path("artifacts/step02d_equivalence_failure_localization"),
        Path("artifacts/step02e_fixed_band_repair"),
        Path("third_party/unitree_mujoco_snapshot"),
    ]
    paths = [p for root in roots for p in root.rglob("*") if p.is_file()]
    paths += list(Path("cavr_wbc/control").glob("*.py"))
    return {p.as_posix(): sha(p) for p in sorted(paths)}


def append_record(output, filename, record):
    with (output / filename).open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(_json_safe(record), ensure_ascii=False, allow_nan=False) + "\n")
        stream.flush()


def solve_captured(call, snapshot, rho, target=None):
    """Observe the real frozen solver call; do not modify arguments or re-solve."""
    captured = []
    original = clarabel.DefaultSolver

    def factory(P, q, A, b, cones, settings):
        solver = original(P, q, A, b, cones, settings)
        captured.append((solver, P, q, A, b, settings))
        return solver

    with patch.object(clarabel, "DefaultSolver", side_effect=factory):
        result = call()
    if not captured:
        return result, {"available": False, "constructor_failed": True}
    if len(captured) != 1:
        raise RuntimeError("a path attempted more than one solver construction")
    try:
        return result, raw_diagnostics(captured[0], result, snapshot, rho, target)
    except Exception as exc:
        return result, {"available": False, "diagnostic_error": f"{type(exc).__name__}: {exc}",
            "solver_status": result.status, "returned_result_preserved": True}


def raw_diagnostics(captured, result, snapshot, rho, target):
    solver, upper_p, q, A, b, settings = captured
    raw = solver.get_solution()
    P = upper_p + upper_p.T - __import__("scipy").sparse.diags(upper_p.diagonal())
    x, s, z = (np.asarray(getattr(raw, key), dtype=float) for key in ("x", "s", "z"))
    if x.shape != (snapshot.decision_dimension,) or s.shape != b.shape or z.shape != b.shape:
        raise ValueError("raw solver vectors unavailable or have wrong dimensions")
    if not all(np.isfinite(v).all() for v in (x,s,z)):
        raise ValueError("raw solver vectors nonfinite")
    eq_count = snapshot.nv + snapshot.nlambda
    info = solver.get_info()
    gap = abs(float(raw.obj_val) - float(raw.obj_val_dual))
    physical = x * variable_scales(snapshot)
    candidate = validate_original_witness(snapshot, rho, physical[:snapshot.nv],
        physical[snapshot.nv:snapshot.nv+snapshot.nu], physical[snapshot.nv+snapshot.nu:], fixed_task_output=target)
    return {
        "available": True, "status": str(raw.status), "x_scaled": x,
        "slack": s, "dual": z, "primal_objective": float(raw.obj_val),
        "dual_objective": float(raw.obj_val_dual), "duality_gap": gap,
        "iterations": int(raw.iterations), "solve_time_s": float(raw.solve_time),
        "primal_residual": float(raw.r_prim), "dual_residual": float(raw.r_dual),
        "kkt_primal_infinity": float(np.max(np.abs(A @ x + s - b))),
        "kkt_stationarity_infinity": float(np.max(np.abs(P @ x + q + A.T @ z))),
        "complementarity_infinity": float(np.max(np.abs(s[eq_count:] * z[eq_count:]))),
        "cone_slack_violation": float(max(0., -np.min(s[eq_count:]))),
        "cone_dual_violation": float(max(0., -np.min(z[eq_count:]))),
        "gap_abs_from_info": float(info.gap_abs), "gap_rel_from_info": float(info.gap_rel),
        "settings_repr": str(settings), "candidate_original_witness": physical,
        "candidate_validation": candidate,
        "candidate_is_accepted": bool(result.success),
    }


def solve_case(spec, phase, index, config, snapshots, rhos, output):
    snapshot = snapshots[spec["snapshot_id"]]
    rho = rhos[spec["health_id"]]
    demand = next(x for x in config["task_demands"] if x["demand_id"] == spec["demand_id"])
    desired = np.asarray(demand["y_d"], dtype=float)
    case = {**spec, "phase": phase, "case_index": index,
        "case_id": "__".join(spec[k] for k in ("snapshot_id", "health_id", "demand_id")),
        "task_class": demand["class"]}
    tolerance = config["objectives"]["secondary_task_fix_normalized_tolerance"]
    lam = config["objectives"]["lambda_tau"]
    thresholds = config["validation"]
    prod = ClarabelP0Production(snapshot, rho, ClarabelP0Settings(**config["clarabel_production"]),
        secondary_task_fix_normalized_tolerance=tolerance, fixed_task_numerical_guard_fraction=0.0)
    ref = IndependentLexicographicReference(snapshot, rho, ClarabelReferenceSettings(**config["clarabel_reference"]),
        secondary_task_fix_normalized_tolerance=tolerance)
    osqp = ScaledFixedSupportPhysicalQp(snapshot, rho, Step02rSolverSettings(**config["osqp_stage_a_diagnostic"]),
        secondary_task_fix_normalized_tolerance=tolerance)
    results, raw, records = {}, {}, {}
    routes = {"p0_a":"p0", "p0_b":"p0", "ref_a":"reference", "ref_b":"reference", "soft":"soft", "osqp_a":"osqp"}
    files = {"p0":"p0_clarabel_diagnostics.jsonl", "reference":"reference_diagnostics.jsonl", "soft":"b1_soft_diagnostics.jsonl", "osqp":"osqp_stage_a_diagnostics.jsonl"}

    def run(name, call, target=None):
        results[name], raw[name] = solve_captured(call, snapshot, rho, target)
        records[name] = {**_result_record(case, results[name]), "path":name, "raw_solver": raw[name]}
        append_record(output, files[routes[name]], records[name])

    run("p0_a", lambda: prod.solve_stage_a(desired))
    if results["p0_a"].success:
        target = results["p0_a"].task_output.copy()
        run("p0_b", lambda: prod.solve_stage_b(target, lam), target)
    else:
        results["p0_b"] = None
        records["p0_b"] = {**_result_record(case, None), "path":"p0_b"}
        append_record(output, files["p0"], records["p0_b"])
    run("ref_a", lambda: ref.solve_stage_a(desired))
    if results["ref_a"].success:
        target = results["ref_a"].task_output.copy()
        run("ref_b", lambda: ref.solve_stage_b(target, lam), target)
    else:
        results["ref_b"] = None
        records["ref_b"] = {**_result_record(case, None), "path":"ref_b"}
        append_record(output, files["reference"], records["ref_b"])
    run("soft", lambda: prod.solve_b1_soft(desired, lam))
    results["osqp_a"] = osqp.solve_p0_stage1(desired)
    records["osqp_a"] = {**_result_record(case, results["osqp_a"]), "path":"osqp_a"}
    append_record(output, files["osqp"], records["osqp_a"])

    p0a,p0b,ra,rb,soft,oa = (results[x] for x in ("p0_a","p0_b","ref_a","ref_b","soft","osqp_a"))
    metrics = _comparison_metrics(snapshot, desired, p0a,p0b,ra,rb)
    row = {**case, **metrics,
        "p0_stage_a_physical_pass": physical_validation_pass(p0a, thresholds),
        "p0_stage_b_physical_pass": physical_validation_pass(p0b, thresholds),
        "p0_stage_b_fixed_band_pass": _fixed_band_pass(p0b,tolerance),
        "reference_stage_a_physical_pass": physical_validation_pass(ra,thresholds),
        "reference_stage_b_physical_pass": physical_validation_pass(rb,thresholds),
        "reference_stage_b_fixed_band_pass": _fixed_band_pass(rb,tolerance),
        "b1_soft_physical_pass": physical_validation_pass(soft,thresholds),
        "equivalence_pass": _equivalence_pass(metrics,thresholds),
        "osqp_stage_a_physical_pass": physical_validation_pass(oa,thresholds),
    }
    for prefix,result in (("p0",p0b),("reference",rb)):
        row[prefix+"_stage_b_fixed_task_error"] = None if result is None else result.validation.get("fixed_task_normalized_infinity_error")
        row[prefix+"_stage_b_task_norm"] = None if result is None or result.task_output is None else float(np.linalg.norm(result.task_output))
    for name,result in (("p0",p0a),("reference",ra)):
        valid = oa.success and result.success
        row["osqp_to_"+name+"_stage_a_normalized_task_output_inf_difference"] = (
            float(np.max(np.abs((oa.task_output-result.task_output)/snapshot.task_scales))) if valid else None)
        row["osqp_to_"+name+"_stage_a_task_objective_abs_difference"] = abs(oa.task_objective-result.task_objective) if valid else None
    row["case_pass"] = all(row[g] for g in GATES)
    row["osqp_diagnostic_classification"] = "OSQP_STAGE_A_DIAGNOSTIC_COMPLETE" if row["osqp_stage_a_physical_pass"] else "OSQP_STAGE_A_NUMERICAL_DIAGNOSTIC_FAILURE"
    bundle = {"case":case,"results":results,"raw":raw,"records":records,
        "snapshot":snapshot,"rho":rho,"desired":desired,"production":prod,"reference":ref}
    if phase == "regression":
        hybrid = None
        hybrid_raw = None
        if oa.success:
            hybrid,hybrid_raw = solve_captured(lambda:prod.solve_stage_b(oa.task_output,lam),snapshot,rho,oa.task_output)
        hybrid_record = {**case,"diagnostic_only":True,
            "osqp_stage_a_physical_pass":row["osqp_stage_a_physical_pass"],
            "clarabel_stage_b_physical_pass":physical_validation_pass(hybrid,thresholds),
            "fixed_band_pass":_fixed_band_pass(hybrid,tolerance),
            "osqp_stage_a":records["osqp_a"],
            "clarabel_stage_b":{**_result_record(case,hybrid),"raw_solver":hybrid_raw}}
        hybrid_record["hybrid_pass"] = all(hybrid_record[k] for k in ("osqp_stage_a_physical_pass","clarabel_stage_b_physical_pass","fixed_band_pass"))
        bundle["hybrid"] = hybrid_record
    return row, bundle


def optimal_set_diagnostic(bundle, config):
    """Postprocess existing witnesses only; no optimization calls."""
    try:
        return _optimal_set_diagnostic(bundle, config)
    except Exception as exc:
        return {"case_id":bundle["case"]["case_id"],"classification":"OPTIMAL_SET_DIAGNOSTIC_UNAVAILABLE",
            "error":f"{type(exc).__name__}: {exc}","solves_retried":0}


def _optimal_set_diagnostic(bundle, config):
    s=bundle["snapshot"]; p=bundle["results"]["p0_b"]; r=bundle["results"]["ref_b"]
    if p is None or r is None or not p.success or not r.success:
        return {"case_id":bundle["case"]["case_id"],"classification":"SOLVER_NONCONVERGENCE",
            "p0":bundle["raw"].get("p0_b"),"reference":bundle["raw"].get("ref_b")}
    a=bundle["results"]["p0_a"]; b=bundle["results"]["ref_a"]
    wp=np.concatenate((p.qdd,p.tau,p.contact_force)); wr=np.concatenate((r.qdd,r.tau,r.contact_force))
    target_same=bool(np.array_equal(a.task_output,b.task_output))
    lam=config["objectives"]["lambda_tau"]
    same_problem_audit=audit_pair(s,bundle["rho"],config,a.task_output)
    observations={}
    for name,solver,target,w in (("production",bundle["production"],a.task_output,wp),("reference",bundle["reference"],b.task_output,wr)):
        audit=solver.audit_problem(fixed_task_output=target,torque_regularization_weight=lam)
        E=np.array(audit["original_equality_matrix"]); G=np.array(audit["original_inequality_matrix"])
        upper=np.array(audit["original_inequality_upper"]); margin=upper-G@w
        active={str(t):[label for label,v in zip(audit["original_inequality_labels"],margin) if abs(v)<=t] for t in (1e-10,1e-8,1e-6)}
        active_rows=G[np.abs(margin)<=1e-8]
        D=np.asarray(audit["variable_scales"])
        tau_map=np.zeros((s.nu,s.decision_dimension));tau_map[:,s.nv:s.nv+s.nu]=np.diag(1/s.torque_scales)
        constrained=np.vstack((E,active_rows,tau_map))*D
        rank=int(np.linalg.matrix_rank(constrained))
        spectrum=np.linalg.svd(constrained,compute_uv=False)
        observations[name]={"active_constraints":active,"inequality_margins":margin,
            "zero_curvature_active_tangent_nullity":s.decision_dimension-rank,
            "active_objective_stack_singular_values":spectrum,
            "solver":bundle["raw"]["p0_b" if name=="production" else "ref_b"]}
    distances={"w_l2":float(np.linalg.norm(wp-wr)),"qdd_l2":float(np.linalg.norm(p.qdd-r.qdd)),
        "tau_l2":float(np.linalg.norm(p.tau-r.tau)),"contact_force_l2":float(np.linalg.norm(p.contact_force-r.contact_force)),
        "task_output_l2":float(np.linalg.norm(p.task_output-r.task_output)),
        "normalized_task_output_inf":float(np.max(np.abs((p.task_output-r.task_output)/s.task_scales)))}
    samples=[]
    for t in (0.,.25,.5,.75,1.):
        w=(1-t)*wp+t*wr
        val=validate_original_witness(s,bundle["rho"],w[:s.nv],w[s.nv:s.nv+s.nu],w[s.nv+s.nu:],fixed_task_output=a.task_output)
        samples.append({"mixture_fraction":t,"torque_regularizer":float(np.sum((w[s.nv:s.nv+s.nu]/s.torque_scales)**2)),"validation_against_production_target":val})
    delta=abs(p.torque_regularizer-r.torque_regularizer)
    distinct=distances["w_l2"]>1e-10
    rp=bundle["raw"]["p0_b"]; rr=bundle["raw"]["ref_b"]
    duals=[item.get("dual_objective") for item in (rp,rr)]
    common_lower=max(duals) if all(v is not None and np.isfinite(v) for v in duals) else None
    suboptimality=[lam*x.torque_regularizer-common_lower for x in (p,r)] if common_lower is not None else None
    max_uncertainty=sum(item.get("duality_gap",float("inf")) for item in (rp,rr))
    physically_valid=all(physical_validation_pass(x,config["validation"]) and _fixed_band_pass(x,1e-8) for x in (p,r))
    objective_certified=suboptimality is not None and all(-max_uncertainty<=v<=lam*1e-6+max_uncertainty for v in suboptimality)
    supported=bool(target_same and distinct and physically_valid and same_problem_audit.get("pass") and objective_certified and delta<=1e-6)
    return {"case_id":bundle["case"]["case_id"],"same_stage_a_target_exactly":target_same,
        "same_target_assembly_pass":same_problem_audit.get("pass",same_problem_audit.get("all_pass")),
        "distances":distances,"observations":observations,"secondary_objective_abs_difference":delta,
        "both_physical_and_fixed_band_valid":physically_valid,
        "common_dual_lower_bound_numerical":common_lower,"suboptimality_estimates":suboptimality,
        "combined_duality_gap_uncertainty":max_uncertainty,"objective_certified_within_frozen_gate":objective_certified,
        "segment_witnesses_without_resolve":samples,
        "midpoint_strict_convexity_identity_drop":float(lam*.25*np.sum(((p.tau-r.tau)/s.torque_scales)**2)),
        "classification":"NONUNIQUE_OR_NUMERIC_OPTIMAL_SET_SENSITIVITY" if supported else "NO_DISTINCT_OPTIMAL_WITNESSES_ESTABLISHED",
        "interpretation":"Positive torque weight makes the optimum unique in tau; qdd/contact may be nonunique. Rank diagnostics alone do not prove nonuniqueness."}


def metric_stats(rows):
    def summarize(selected):
        return {field:{"available_count":sum(row.get(field) is not None and np.isfinite(row[field]) for row in selected),
            **_stats([row[field] for row in selected if row.get(field) is not None and np.isfinite(row[field])])} for field in METRIC_FIELDS}
    output={"overall":summarize(rows)}
    for key in ("snapshot_id","health_id","task_class"):
        output[key]={value:summarize([row for row in rows if row[key]==value]) for value in sorted({row[key] for row in rows})}
    return output


def soft_comparison(bundle):
    p=bundle["results"]["p0_b"]; soft=bundle["results"]["soft"]; s=bundle["snapshot"]
    row={**bundle["case"]}
    fields=("normalized_task_output_difference_l2","p0_desired_task_error_l2","b1soft_desired_task_error_l2",
        "p0_normalized_torque_norm","b1soft_normalized_torque_norm","p0_contact_force_norm_n","b1soft_contact_force_norm_n",
        "p0_active_torque_constraints","b1soft_active_torque_constraints","p0_active_friction_constraints","b1soft_active_friction_constraints")
    row.update({k:None for k in fields})
    if p is None or not p.success or not soft.success:
        return row
    row.update({"normalized_task_output_difference_l2":float(np.linalg.norm((p.task_output-soft.task_output)/s.task_scales)),
        "p0_desired_task_error_l2":float(np.linalg.norm((p.task_output-bundle["desired"])/s.task_scales)),
        "b1soft_desired_task_error_l2":float(np.linalg.norm((soft.task_output-bundle["desired"])/s.task_scales))})
    for name,result in (("p0",p),("b1soft",soft)):
        for dest,src in (("normalized_torque_norm","torque_normalized_l2"),("contact_force_norm_n","contact_force_l2_n"),("active_torque_constraints","active_torque_constraints"),("active_friction_constraints","active_friction_constraints")):
            row[name+"_"+dest]=result.validation[src]
    return row


def run_record_tests(output):
    # This suite reads this run's saved witnesses and performs zero new solves.
    suite=unittest.defaultTestLoader.discover("tests",pattern="test_step02d_exact_regressions.py")
    stream=io.StringIO()
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    (output/"exact_regression_tests.txt").write_text(stream.getvalue(),encoding="utf-8")
    report={"tests_run":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),
        "skipped":len(result.skipped),"pass":result.wasSuccessful() and result.testsRun>=4 and not result.skipped,
        "solves_executed_by_tests":0}
    _write_json(output/"exact_regression_tests.json",report)
    return report


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--phase",choices=("preflight","execute"),required=True)
    parser.add_argument("--legacy-test-report",type=Path)
    args=parser.parse_args()
    output=OUTPUT; output.mkdir(parents=True,exist_ok=True)
    config=yaml.safe_load(CONFIG.read_text(encoding="utf-8"))
    checks=frozen_checks(config)
    if not all(checks.values()):
        raise RuntimeError(f"Unauthorized configuration difference: {checks}")
    model,snapshots,rhos=load_context(config)
    if args.phase=="preflight":
        if (output/"execution_lock.json").exists():
            raise RuntimeError("Existing run cannot be overwritten")
        audit=audit_panel(snapshots,rhos,config)
        _write_json(output/"exact_band_assembly_audit.json",audit)
        _write_json(output/"lineage.json",{"lineage":LINEAGE,"stage":"STEP02D_EXACT_BAND_SYMMETRY_CLOSURE",
            "step02c_classification":"PRODUCTION_FIXED_BAND_GUARD_EQUIVALENCE_FAILURE",
            "step02c_remains_failed":True,"prior_localization_preserved":"bfcd95a",
            "only_numerical_contract_change":{"internal_fixed_task_guard_fraction":{"before":.20,"after":0.0}},
            "scientific_freeze_checks":checks})
        _write_json(output/"history_freeze_manifest.json",{"git_head":subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(),
            "files":history_inventory()})
        print(json.dumps({"assembly_pass":audit.get("pass",audit.get("all_pass")),"scientific_freeze":all(checks.values())}))
        return 0 if audit.get("pass",audit.get("all_pass")) else 2
    audit=json.loads((output/"exact_band_assembly_audit.json").read_text(encoding="utf-8"))
    if not audit.get("pass",audit.get("all_pass")):
        raise RuntimeError("Pre-solve audit did not pass; no solves authorized")
    if args.legacy_test_report is None:
        raise RuntimeError("Frozen legacy test evidence required")
    tests=json.loads(args.legacy_test_report.read_text(encoding="utf-8"))
    if not tests["pass"] or tests["tests_run"]<62:
        raise RuntimeError("Legacy test gate failed")
    with (output/"execution_lock.json").open("x",encoding="utf-8") as lock:
        json.dump({"started_at":datetime.now(timezone.utc).isoformat(),"no_retry":True,"config_sha256_at_regression_start":sha(CONFIG)},lock,indent=2)
    _write_json(output/"implementation_manifest.json",{
        "git_head":subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(),
        "files":{p.as_posix():sha(p) for p in [
            Path("cavr_wbc/experiments/step02d_exact_band.py"),Path("cavr_wbc/experiments/step02d_exact_audit.py"),
            Path("cavr_wbc/experiments/step02d_exact_figures.py"),Path("tests/test_step02d_exact_assembly.py"),
            Path("tests/test_step02d_exact_regressions.py"),CONFIG]},
        "baseline_config_source":BASELINE.as_posix(),"baseline_config_sha256":sha(BASELINE)})
    start_hash=sha(CONFIG)
    (output/"config.yaml").write_bytes(CONFIG.read_bytes())
    (output/"config_sha256.txt").write_text(start_hash+"\n",encoding="utf-8")
    original_inventory=json.loads((output/"history_freeze_manifest.json").read_text(encoding="utf-8"))["files"]
    if original_inventory!=history_inventory():
        raise RuntimeError("Frozen history changed before solve")
    rows=[];bundles=[]
    for i,spec in enumerate(REGRESSION_CASES,1):
        row,bundle=solve_case(spec,"regression",i,config,snapshots,rhos,output)
        rows.append(row);bundles.append(bundle)
        append_record(output,"regression_cases_journal.jsonl",row)
        print(f"Regression {i}/4: {'PASS' if row['case_pass'] else 'FAIL'}",flush=True)
    regression_pass=all(row["case_pass"] for row in rows)
    regression={"cases":rows,"pass_count":sum(row["case_pass"] for row in rows),"regression_gate_pass":regression_pass,
        "metric_thresholds":METRIC_GATES,"config_sha256":start_hash,"physical_and_equivalence_required":True}
    _write_json(output/"regression_results.json",regression)
    hybrid_cases=[b["hybrid"] for b in bundles]
    hybrid={"diagnostic_only":True,"cases":hybrid_cases,"pass_count":sum(c["hybrid_pass"] for c in hybrid_cases)}
    hybrid["classification"]="OSQP_STAGE_A_TARGETS_CERTIFIED_FEASIBLE_ON_REGRESSIONS" if hybrid["pass_count"]==4 else "HYBRID_EXACT_BAND_DIAGNOSTIC_FAILURE"
    _write_json(output/"hybrid_osqp_a_clarabel_b.json",hybrid)
    record_tests=run_record_tests(output)
    regression_pass=regression_pass and record_tests["pass"]
    regression["regression_gate_pass"]=regression_pass
    regression["record_test_pass"]=record_tests["pass"]
    _write_json(output/"regression_results.json",regression)
    regression_opt=[optimal_set_diagnostic(b,config) for b in bundles]
    _write_json(output/"regression_optimal_set_diagnostics.json",regression_opt)
    full_rows=[];full_bundles=[]
    if regression_pass:
        if sha(CONFIG)!=start_hash:
            raise RuntimeError("Config changed after regression")
        _write_json(output/"full_panel_authorization.json",{"regression_gate_pass":True,"config_sha256":start_hash,
            "case_count":245,"full_panel_attempt":1,"frozen_at":datetime.now(timezone.utc).isoformat()})
        with (output/"full_panel_execution_lock.json").open("x",encoding="utf-8") as lock:
            json.dump({"attempt":1,"no_retry":True,"case_count":245},lock)
        print("Regression 4/4 PASS; beginning single frozen 245-case panel",flush=True)
        for sid in snapshots:
            for hid in rhos:
                for demand in config["task_demands"]:
                    spec={"snapshot_id":sid,"health_id":hid,"demand_id":demand["demand_id"]}
                    row,bundle=solve_case(spec,"full_panel",len(full_rows)+1,config,snapshots,rhos,output)
                    full_rows.append(row);full_bundles.append(bundle)
                    append_record(output,"full_panel_cases_journal.jsonl",row)
                    if len(full_rows)%35==0:
                        print(f"Panel {len(full_rows)}/245; primary pass {sum(r['case_pass'] for r in full_rows)}",flush=True)
    selected=full_rows if full_rows else rows
    selected_bundles=full_bundles if full_rows else bundles
    gate_counts={gate:sum(row[gate] for row in selected) for gate in GATES}
    inventory_same=original_inventory==history_inventory()
    _write_json(output/"history_preservation_check.json",{"all_unchanged":inventory_same,"files_checked":len(original_inventory),
        "changed":[p for p,h in original_inventory.items() if not Path(p).is_file() or sha(p)!=h]})
    passed=bool(regression_pass and len(full_rows)==245 and all(v==245 for v in gate_counts.values()) and inventory_same and sha(CONFIG)==start_hash)
    classification="EXACT_BAND_EQUIVALENCE_CLOSED" if passed else ("FULL_PANEL_FROZEN_GATE_FAILURE" if full_rows else "REGRESSION_FROZEN_GATE_FAILURE")
    failures=[row for row in selected if not row["case_pass"]]
    _write_json(output/"failed_case_diagnostics.json",{
        "scope":"full_panel" if full_rows else "regression","failed_cases":failures,
        "optimal_set_diagnostics":[optimal_set_diagnostic(b,config) for row,b in zip(selected,selected_bundles) if not row["case_pass"]]})
    _write_csv(output/"eq_cases.csv",selected)
    soft_allowed=all(row["b1_soft_physical_pass"] and row["p0_stage_b_physical_pass"] for row in selected)
    soft_rows=[soft_comparison(b) for b in selected_bundles] if soft_allowed else []
    _write_csv(output/"b1_soft_vs_p0.csv",soft_rows or [{"status":"WITHHELD_B1_SOFT_PHYSICAL_GATE_FAILURE"}])
    diagnostics={key:[] for key in ("p0","reference","soft","osqp")}
    for bundle in selected_bundles:
        for name,record in bundle["records"].items():
            key="p0" if name.startswith("p0") else "reference" if name.startswith("ref") else "soft" if name=="soft" else "osqp"
            diagnostics[key].append(record)
    render_figures(output,selected,diagnostics,soft_rows,soft_allowed)
    _write_json(output/"dependency_manifest.json",{"python":sys.version,"versions":{name:importlib.metadata.version(name) for name in ("mujoco","numpy","scipy","osqp","clarabel","PyYAML","matplotlib")},"new_installs":[]})
    summary={"stage":"STEP02D_EXACT_BAND_SYMMETRY_CLOSURE","status":"PASS" if passed else "FAIL / REVISE",
        "classification":classification,"lineage":LINEAGE,"config_sha256":start_hash,"config_frozen_for_full_panel":bool(full_rows),
        "scientific_freeze_checks":checks,"history_unchanged":inventory_same,"assembly_pass":True,
        "regression_pass_count":regression["pass_count"],"regression_gate_pass":regression_pass,
        "full_panel_case_count":len(full_rows),"full_panel_attempts":1 if full_rows else 0,
        "gate_pass_counts":gate_counts,"equivalence_statistics":metric_stats(selected),
        "hybrid_pass_count":hybrid["pass_count"],"hybrid_classification":hybrid["classification"],
        "failed_case_count":len(failures),"osqp_stage_a_diagnostic_failures":[r["case_id"] for r in selected if not r["osqp_stage_a_physical_pass"]],
        "b1_soft_analysis_authorized":soft_allowed,"legacy_tests":tests,"exact_regression_tests":record_tests,
        "e1_started":False,"one_step_simulation_executed":False,"next_stage_allowed":"E1_ONLY" if passed else False}
    _write_json(output/"eq_summary.json",summary)
    _write_json(output/"STEP02D_RESULT.json",summary)
    failure_lines="\n".join(f"- `{r['case_id']}`: "+", ".join(g for g in GATES if not r[g]) for r in failures)
    report=f"""## Material Passport

- Origin Skill: experiment-agent
- Origin Mode: run
- Origin Date: {datetime.now(timezone.utc).isoformat()}
- Verification Status: EXECUTED; original-unit witnesses recomputed
- Version Label: step02d_exact_band_v1

# STEP-02D Exact-Band Symmetry Closure

Result: **{summary['status']}**. Classification: `{classification}`.

Lineage: `STEP02_FAIL -> STEP02R_FAIL -> STEP02C_FAIL -> STEP02D`.
Prior result files remain archived. STEP-02C compared different task slabs
(8e-9 versus 1e-8); it is not evidence against mathematical equivalence.

The only numerical change from the archived STEP-02C configuration is production
guard fraction 0.20 -> 0.0. Production external/internal and reference bands are
all exactly 1e-8. Solver settings, objectives, physical limits and task requests
are unchanged. The original separate solver implementations were used directly.
Assembly audit passed before all regression solving. Config SHA256: `{start_hash}`.

Regression gate: {regression['pass_count']}/4. Full-panel cases: {len(full_rows)}/245;
attempts: {summary['full_panel_attempts']}. Hybrid diagnostic: {hybrid['pass_count']}/4,
`{hybrid['classification']}`. The hybrid is diagnostic and does not replace the
primary production/reference gate. Legacy tests: {tests['tests_run']}, passing;
four explicit five-metric regression tests: {record_tests['tests_run']},
passing={record_tests['pass']}. Test replay used recorded witnesses with no solves.

Gate counts for the {'full panel' if full_rows else 'regressions'}:
{json.dumps(gate_counts,indent=2)}

All original and transformed numerical witnesses, status, primal/dual objectives,
gap, KKT residuals, iterations and runtime are persisted immediately per solve.
Witness distances, active constraints and segment tests are postprocessed from
the same solves. No retry, tolerance tuning, new guard, or witness repair occurred.
The secondary objective is strictly convex in torque, while acceleration/contact
coordinates may have flat directions. Rank or residual diagnostics alone do not
establish distinct optimal witnesses or a formal proof.

{('Under the frozen zero-velocity four-foot fixed-support convex model, the instantaneous task projection and an independently assembled lexicographic soft-task WBC produced numerically consistent task-space and secondary solutions across the frozen DEV panel.' if passed else 'The required all-case certificate was not obtained; E1 remains forbidden.')}

B1-soft physical checks authorize descriptive task/torque/contact comparisons:
{soft_allowed}. These comparisons do not establish superiority or recoverability.
Prior history SHA256 preservation: {inventory_same} across {len(original_inventory)} files.
The existing localization directory and concurrent, untracked STEP-02E inventory
were preserved; no STEP-02E experiment was created or executed by this stage.

## Failed cases

{failure_lines or 'None.'}

NEXT_STAGE_ALLOWED = {'E1_ONLY' if passed else 'FALSE'}
"""
    (output/"STEP02D_REPORT.md").write_text(report,encoding="utf-8")
    print(json.dumps({k:summary[k] for k in ("status","classification","regression_pass_count","full_panel_case_count","gate_pass_counts","next_stage_allowed")},indent=2),flush=True)
    return 0 if passed else 2


if __name__=="__main__":
    raise SystemExit(main())
