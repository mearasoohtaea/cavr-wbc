"""Failure-safe visual diagnostics for the frozen STEP-02D audit.

The renderer never solves a problem.  If full-panel rows exist they define the
plot scope; otherwise the figures explicitly describe the regression phase.
Missing or non-finite observations are counted rather than plotted as zeros.
"""

from __future__ import annotations

import math
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


_FLOOR = 1.0e-18
_COLORS = ("#2864A5", "#D38120", "#28865C", "#8B67A9")


def _number(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return result if math.isfinite(result) else None


def _scoped(records: list[dict], phase: str | None) -> list[dict]:
    if phase is None:
        return list(records)
    return [record for record in records if record.get("phase") == phase]


def _empty(ax: Any, message: str = "Insufficient data") -> None:
    ax.text(0.5, 0.5, message, ha="center", va="center", transform=ax.transAxes)
    ax.set_xticks([])
    ax.set_yticks([])


def _save(fig: Any, output: Path, name: str, note: str = "") -> None:
    if note:
        fig.text(0.015, 0.018, note, fontsize=8, color="#555555", va="bottom")
    fig.tight_layout(rect=(0, 0.075 if note else 0, 1, 1))
    fig.savefig(output / name, dpi=160, facecolor="white")
    plt.close(fig)


def _series_plot(
    output: Path,
    name: str,
    rows: list[dict],
    fields: tuple[tuple[str, str], ...],
    gate: float,
    title: str,
    ylabel: str,
    scope: str,
    diagnostic: bool = False,
) -> None:
    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    counts = []
    plotted = False
    for color, (field, label) in zip(_COLORS, fields):
        values = [_number(row.get(field)) for row in rows]
        valid = sum(value is not None for value in values)
        counts.append(f"{label}: {valid}/{len(rows)} available")
        if valid:
            plotted = True
            ax.plot(
                np.arange(1, len(rows) + 1),
                [np.nan if value is None else max(value, _FLOOR) for value in values],
                color=color,
                marker="o" if len(rows) <= 10 else None,
                markersize=4,
                linewidth=1.1,
                label=label,
            )
    if plotted:
        ax.axhline(
            gate, color="#B33434", linestyle="--", linewidth=1,
            label="comparison scale (diagnostic only)" if diagnostic else "frozen gate",
        )
        ax.set_yscale("log")
        ax.set_xlabel(f"Case order within {scope.lower()}")
        ax.set_ylabel(ylabel)
        ax.grid(axis="y", alpha=0.18)
        ax.legend(fontsize=8)
    else:
        _empty(ax)
    ax.set_title(f"{title}\n{scope}")
    _save(fig, output, name, "; ".join(counts) + ". Values below 1e-18 shown at 1e-18.")


def render_figures(
    output: Path,
    rows: list[dict],
    diagnostics: dict[str, list[dict]],
    soft_rows: list[dict],
    soft_analysis_allowed: bool,
) -> None:
    """Write seven PNG diagnostics without weakening any scientific gate."""
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    phases = {row.get("phase") for row in rows}
    phase = "full_panel" if "full_panel" in phases else (
        "regression" if "regression" in phases else None
    )
    selected = _scoped(rows, phase)
    scope = (
        f"Full panel ({len(selected)} cases)" if phase == "full_panel" else
        f"Frozen regressions ({len(selected)} cases)" if phase == "regression" else
        f"Available records ({len(selected)} cases; phase unspecified)"
    )
    with plt.rc_context({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False}):
        fig, ax = plt.subplots(figsize=(6.1, 5.2))
        pairs = [
            (_number(row.get("p0_stage_b_task_norm")),
             _number(row.get("reference_stage_b_task_norm")))
            for row in selected
        ]
        pairs = [(x, y) for x, y in pairs if x is not None and y is not None]
        if pairs:
            x, y = np.asarray(pairs).T
            ax.scatter(x, y, s=24, color=_COLORS[0], alpha=0.7)
            low, high = float(min(x.min(), y.min())), float(max(x.max(), y.max()))
            pad = max((high - low) * 0.04, abs(high) * 0.01, 1.0e-12)
            ax.plot([low - pad, high + pad], [low - pad, high + pad], "--", color="#666666", linewidth=1)
            ax.set_xlabel("P0 final task-vector norm (unscaled)")
            ax.set_ylabel("Reference final task-vector norm (unscaled)")
        else:
            _empty(ax)
        ax.set_title(f"P0 and independent reference: task-norm check\n{scope}")
        _save(fig, output, "p0_vs_independent_reference_task.png",
              f"Paired data: {len(pairs)}/{len(selected)}. Norm agreement alone is not the equivalence gate.")

        _series_plot(output, "task_objective_difference.png", selected, (
            ("stage_a_task_objective_abs_difference", "Stage A"),
            ("stage_b_task_objective_abs_difference", "Stage B"),
        ), 1.0e-7, "Task-objective equivalence", "Absolute task-objective difference", scope)
        _series_plot(output, "torque_regularizer_difference.png", selected, (
            ("stage_b_torque_regularizer_abs_difference", "Stage B"),
        ), 1.0e-6, "Secondary-objective equivalence", "Absolute torque-regularizer difference", scope)

        fig, ax = plt.subplots(figsize=(7.6, 4.8))
        classes = sorted({str(row.get("task_class", "unspecified")) for row in selected})
        all_groups = []
        for task_class in classes:
            group = [
                value for row in selected
                if str(row.get("task_class", "unspecified")) == task_class
                if (value := _number(row.get("stage_b_normalized_task_output_inf_difference"))) is not None
            ]
            all_groups.append(group)
        positions = [index + 1 for index, group in enumerate(all_groups) if group]
        if positions:
            ax.boxplot(
                [[max(value, _FLOOR) for value in group] for group in all_groups if group],
                positions=positions, widths=0.5, showfliers=True,
            )
            ax.axhline(1.0e-6, color="#B33434", linestyle="--", linewidth=1, label="frozen gate")
            ax.set_xticks(np.arange(1, len(classes) + 1))
            ax.set_xticklabels([
                f"{task_class.replace('_', ' ')}\n(n={len(group)})"
                for task_class, group in zip(classes, all_groups)
            ], rotation=15, ha="right")
            ax.set_yscale("log")
            ax.set_ylabel("Normalized final-task infinity difference")
            ax.legend(fontsize=8)
        else:
            _empty(ax)
        ax.set_title(f"Final-task equivalence by task class\n{scope}")
        _save(fig, output, "equivalence_error_by_task_class.png",
              "Only finite observations shown; n denotes available cases. Values below 1e-18 shown at 1e-18.")

        fig, axes = plt.subplots(2, 2, figsize=(9.0, 6.8))
        physical_fields = (
            ("dynamics_infinity_norm", "Dynamics", 1.0e-6),
            ("contact_infinity_norm", "Contact", 1.0e-6),
            ("hard_inequality_violation", "Hard inequalities", 1.0e-7),
            ("health_adapter_identity_error", "Health identity", 1.0e-9),
        )
        names = ("p0", "reference", "soft", "osqp")
        for ax, (field, title, gate) in zip(axes.flat, physical_fields):
            groups = []
            totals = []
            for name in names:
                records = _scoped(diagnostics.get(name, []), phase)
                totals.append(len(records))
                group = []
                for record in records:
                    validation = record.get("validation") or {}
                    if not isinstance(validation, dict) or validation.get("available") is False:
                        continue
                    value = _number(validation.get(field))
                    if value is not None:
                        group.append(max(value / gate, _FLOOR))
                groups.append(group)
            positions = [index + 1 for index, group in enumerate(groups) if group]
            if positions:
                ax.boxplot([group for group in groups if group], positions=positions,
                           widths=0.5, showfliers=True)
                ax.axhline(1.0, color="#B33434", linestyle="--", linewidth=1)
                ax.set_yscale("log")
                ax.set_xticks(range(1, 5))
                ax.set_xticklabels([
                    f"{name}\n{len(group)}/{total}" for name, group, total in zip(names, groups, totals)
                ], fontsize=8)
                ax.set_ylabel("Residual / frozen gate")
            else:
                _empty(ax)
            ax.set_title(f"{title} (gate = {gate:.0e})")
        fig.suptitle(f"Physical residuals: dimensionless gate ratios\n{scope}", fontsize=11)
        _save(fig, output, "physical_residuals.png",
              "Red line: gate ratio 1. Labels: available/recorded solves. P0/reference include A and B; OSQP is diagnostic.")

        _series_plot(output, "osqp_stage_a_crosscheck.png", selected, (
            ("osqp_to_p0_stage_a_normalized_task_output_inf_difference", "OSQP A vs P0 A"),
            ("osqp_to_reference_stage_a_normalized_task_output_inf_difference", "OSQP A vs reference A"),
        ), 1.0e-6, "Scaled OSQP Stage-A cross-check (diagnostic)",
            "Normalized task-output infinity difference", scope, diagnostic=True)

        fig, ax = plt.subplots(figsize=(6.8, 5.2))
        allowed_rows = _scoped(soft_rows, phase)
        triples = []
        if soft_analysis_allowed:
            for row in allowed_rows:
                triple = tuple(_number(row.get(field)) for field in (
                    "p0_desired_task_error_l2", "b1soft_desired_task_error_l2",
                    "normalized_task_output_difference_l2",
                ))
                if all(value is not None for value in triple):
                    triples.append(triple)
        if not soft_analysis_allowed:
            _empty(ax, "Interpretation withheld\nRequired physical-validity gates have not all passed.")
        elif triples:
            x, y, differences = np.asarray(triples).T
            scatter = ax.scatter(x, y, c=differences, s=26, alpha=0.75, cmap="viridis")
            colorbar = fig.colorbar(scatter, ax=ax, pad=0.03)
            colorbar.set_label("Normalized P0 / B1-soft task distance L2")
            low, high = float(min(x.min(), y.min())), float(max(x.max(), y.max()))
            pad = max((high - low) * 0.04, abs(high) * 0.01, 1.0e-12)
            ax.plot([low - pad, high + pad], [low - pad, high + pad], "--", color="#666666", linewidth=1)
            ax.set_xlabel("P0 normalized desired-task error L2")
            ax.set_ylabel("B1-soft normalized desired-task error L2")
        else:
            _empty(ax)
        ax.set_title(f"B1-soft and P0 task differences\n{scope}")
        note = (
            f"Paired data: {len(triples)}/{len(allowed_rows)}. Differences reflect objective definitions; no superiority claim."
            if soft_analysis_allowed else "No B1-soft/P0 comparison is interpreted in this figure."
        )
        _save(fig, output, "b1soft_vs_p0_task_difference.png", note)
