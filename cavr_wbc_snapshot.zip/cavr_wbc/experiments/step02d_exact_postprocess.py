"""Correct STEP-02D reporting from saved witnesses, with no new QP solves.

Original run outputs are retained under exclusive ``initial_execution_*``
backups. Frozen configuration, implementation, journals, and solver records
remain byte-for-byte unchanged. Scientific gate decisions are never changed.
"""

from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from unittest.mock import patch

import numpy as np
import yaml

from cavr_wbc.control.scaled_fixed_support_qp import validate_original_witness
from cavr_wbc.experiments.step02d_exact_band import load_context, metric_stats
from cavr_wbc.experiments.step02d_exact_figures import render_figures
from cavr_wbc.experiments.step02c import _write_csv, _write_json


OUTPUT = Path("artifacts/step02d_exact_band_equivalence")
DIAGNOSTIC_FILES = {
    "p0": "p0_clarabel_diagnostics.jsonl",
    "reference": "reference_diagnostics.jsonl",
    "soft": "b1_soft_diagnostics.jsonl",
    "osqp": "osqp_stage_a_diagnostics.jsonl",
}
FIGURES = (
    "p0_vs_independent_reference_task.png", "task_objective_difference.png",
    "torque_regularizer_difference.png", "equivalence_error_by_task_class.png",
    "physical_residuals.png", "osqp_stage_a_crosscheck.png",
    "b1soft_vs_p0_task_difference.png",
)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(name: str):
    return json.loads((OUTPUT / name).read_text(encoding="utf-8"))


def physical_pass(record, validation):
    return bool(
        record["success"] and validation.get("available")
        and validation["dynamics_infinity_norm"] <= 1e-6
        and validation["contact_infinity_norm"] <= 1e-6
        and validation["hard_inequality_violation"] <= 1e-7
        and validation["health_adapter_identity_error"] <= 1e-9
    )


def main():
    with patch("clarabel.DefaultSolver", side_effect=AssertionError("No new solve authorized")) as clarabel_guard, patch("osqp.OSQP", side_effect=AssertionError("No new solve authorized")) as osqp_guard:
        result = _postprocess()
        clarabel_guard.assert_not_called()
        osqp_guard.assert_not_called()
    print(json.dumps(result, indent=2))


def _postprocess():
    config = yaml.safe_load((OUTPUT / "config.yaml").read_text(encoding="utf-8"))
    _, snapshots, rhos = load_context(config)
    initial_summary = read_json("eq_summary.json")
    initial_result = read_json("STEP02D_RESULT.json")
    assert initial_summary == initial_result
    assert initial_summary["classification"] == "FULL_PANEL_FROZEN_GATE_FAILURE"
    assert initial_summary["next_stage_allowed"] is False
    rows = [json.loads(line) for line in (OUTPUT / "full_panel_cases_journal.jsonl").read_text(encoding="utf-8").splitlines()]
    diagnostics = {
        key: [json.loads(line) for line in (OUTPUT / filename).read_text(encoding="utf-8").splitlines()]
        for key, filename in DIAGNOSTIC_FILES.items()
    }
    full = [record for group in diagnostics.values() for record in group if record["phase"] == "full_panel"]
    records = {(record["case_id"], record["path"]): record for record in full}
    assert len(rows) == len({row["case_id"] for row in rows}) == 245
    assert len(full) == len(records) == 245 * 6
    paths = Counter(record["path"] for record in full)
    assert paths == Counter({key: 245 for key in ("p0_a", "p0_b", "ref_a", "ref_b", "soft", "osqp_a")})
    for row in rows:
        for path in paths:
            assert (row["case_id"], path) in records
    history = read_json("history_freeze_manifest.json")["files"]
    implementation = read_json("implementation_manifest.json")["files"]
    for path, expected in {**history, **implementation}.items():
        assert digest(Path(path)) == expected, path
    preserved_inputs = {
        path.name: digest(path) for path in OUTPUT.iterdir()
        if path.suffix == ".jsonl" or path.name in (
            "config.yaml", "config_sha256.txt", "implementation_manifest.json",
            "history_freeze_manifest.json", "regression_results.json",
            "hybrid_osqp_a_clarabel_b.json", "failed_case_diagnostics.json",
        )
    }
    assert digest(OUTPUT / "config.yaml") == initial_summary["config_sha256"]

    gate_counts = {gate: sum(row[gate] for row in rows) for gate in initial_summary["gate_pass_counts"]}
    assert gate_counts == initial_summary["gate_pass_counts"]
    demands = {item["demand_id"]: np.asarray(item["y_d"], dtype=float) for item in config["task_demands"]}
    validation_checks = 0
    validation_max_difference = 0.0
    restored_stage_a_count = 0
    soft_rows = []
    failure_cases = {"almost_solved": [], "solved_fixed_band_failure": []}
    raw_pair_counts = Counter()
    raw_pair_max_difference = {key: 0.0 for key in ("x_scaled", "slack", "dual")}
    for row in rows:
        sid, hid, case_id = row["snapshot_id"], row["health_id"], row["case_id"]
        snapshot, rho, desired = snapshots[sid], rhos[hid], demands[row["demand_id"]]
        case = {path: records[case_id, path] for path in paths}
        recomputed = {}
        for path, record in case.items():
            if not record["success"]:
                assert record["status"] == "AlmostSolved" and path in ("p0_b", "ref_b")
                continue
            target = None
            if path in ("p0_b", "ref_b"):
                target = np.asarray(case["p0_a" if path == "p0_b" else "ref_a"]["task_output"])
            qdd, tau, force = (np.asarray(record[name]) for name in ("qdd", "tau", "contact_force"))
            validation = validate_original_witness(snapshot, rho, qdd, tau, force, fixed_task_output=target)
            recomputed[path] = validation
            assert np.array_equal(snapshot.task_matrix @ qdd + snapshot.task_bias, record["task_output"])
            assert float(np.sum((tau / snapshot.torque_scales) ** 2)) == record["torque_regularizer"]
            for key, value in validation.items():
                stored = record["validation"][key]
                if value is None:
                    assert stored is None
                else:
                    difference = float(np.max(np.abs(np.asarray(value, dtype=float) - np.asarray(stored, dtype=float)), initial=0.0))
                    validation_max_difference = max(validation_max_difference, difference)
                    assert difference <= 1e-12, (case_id, path, key, difference)
            validation_checks += 1

        for path, gate in (("p0_a", "p0_stage_a_physical_pass"), ("p0_b", "p0_stage_b_physical_pass"), ("ref_a", "reference_stage_a_physical_pass"), ("ref_b", "reference_stage_b_physical_pass"), ("soft", "b1_soft_physical_pass"), ("osqp_a", "osqp_stage_a_physical_pass")):
            passed = physical_pass(case[path], recomputed.get(path, {}))
            assert passed == row[gate], (case_id, gate)
        for path, gate in (("p0_b", "p0_stage_b_fixed_band_pass"), ("ref_b", "reference_stage_b_fixed_band_pass")):
            passed = bool(case[path]["success"] and recomputed[path]["fixed_task_normalized_infinity_error"] <= 1e-8)
            assert passed == row[gate], (case_id, gate)

        p0a, refa = case["p0_a"], case["ref_a"]
        assert p0a["success"] and refa["success"]
        metric_a = {
            "stage_a_normalized_task_output_inf_difference": float(np.max(np.abs((np.asarray(p0a["task_output"]) - np.asarray(refa["task_output"])) / snapshot.task_scales))),
            "stage_a_task_objective_abs_difference": abs(p0a["task_objective"] - refa["task_objective"]),
        }
        if row["stage_a_normalized_task_output_inf_difference"] is None:
            restored_stage_a_count += 1
        for field, value in metric_a.items():
            assert row[field] is None or row[field] == value
            row[field] = value
        # Do not promote incomplete Stage-B comparisons into equivalence passes.
        metrics = [row[field] for field in (
            "stage_a_normalized_task_output_inf_difference", "stage_a_task_objective_abs_difference",
            "stage_b_normalized_task_output_inf_difference", "stage_b_task_objective_abs_difference",
            "stage_b_torque_regularizer_abs_difference",
        )]
        equivalence = all(value is not None and value <= gate for value, gate in zip(metrics, (1e-6, 1e-7, 1e-6, 1e-7, 1e-6)))
        assert equivalence == row["equivalence_pass"]
        assert row["case_pass"] == all(row[gate] for gate in gate_counts)

        for left_name, right_name in (("p0_a", "ref_a"), ("p0_b", "ref_b")):
            left, right = case[left_name]["raw_solver"], case[right_name]["raw_solver"]
            assert left["status"] == right["status"]
            for key in raw_pair_max_difference:
                a, b = np.asarray(left[key]), np.asarray(right[key])
                assert a.shape == b.shape and np.array_equal(a, b), (case_id, key)
                raw_pair_counts[key] += 1
                raw_pair_max_difference[key] = max(raw_pair_max_difference[key], float(np.max(np.abs(a - b), initial=0.0)))

        p0b, soft = case["p0_b"], case["soft"]
        valid_baseline = bool(row["p0_stage_b_physical_pass"] and row["p0_stage_b_fixed_band_pass"] and p0b["success"])
        assert row["b1_soft_physical_pass"]
        reason = "ACCEPTED_PHYSICAL_AND_EXACT_BAND" if valid_baseline else (
            "P0_STAGE_B_NOT_ACCEPTED_ALMOST_SOLVED" if not p0b["success"] else "P0_STAGE_B_FIXED_BAND_EXCEEDED"
        )
        soft_row = {key: row[key] for key in ("snapshot_id", "health_id", "demand_id", "phase", "case_index", "case_id", "task_class")}
        soft_row.update({
            "b1soft_physical_pass": True,
            "p0_valid_baseline": valid_baseline,
            "paired_comparison_available": valid_baseline,
            "baseline_status_reason": reason,
            "normalized_task_output_difference_l2": None,
            "p0_desired_task_error_l2": None,
            "b1soft_desired_task_error_l2": float(np.linalg.norm((np.asarray(soft["task_output"]) - desired) / snapshot.task_scales)),
            "p0_task_objective": None,
            "b1soft_task_objective": soft["task_objective"],
            "p0_normalized_torque_norm": None,
            "b1soft_normalized_torque_norm": recomputed["soft"]["torque_normalized_l2"],
            "p0_contact_force_norm_n": None,
            "b1soft_contact_force_norm_n": recomputed["soft"]["contact_force_l2_n"],
        })
        for name in ("active_torque_constraints", "active_friction_constraints", "active_normal_lower_constraints", "active_normal_upper_constraints"):
            soft_row["p0_" + name] = None
            soft_row["b1soft_" + name] = recomputed["soft"][name]
        if valid_baseline:
            p0_output = np.asarray(p0b["task_output"])
            residual = (p0_output - desired) / snapshot.task_scales
            soft_row.update({
                "normalized_task_output_difference_l2": float(np.linalg.norm((p0_output - np.asarray(soft["task_output"])) / snapshot.task_scales)),
                "p0_desired_task_error_l2": float(np.linalg.norm(residual)),
                "p0_task_objective": float(np.sum(snapshot.task_weights * residual ** 2)),
                "p0_normalized_torque_norm": recomputed["p0_b"]["torque_normalized_l2"],
                "p0_contact_force_norm_n": recomputed["p0_b"]["contact_force_l2_n"],
            })
            for name in ("active_torque_constraints", "active_friction_constraints", "active_normal_lower_constraints", "active_normal_upper_constraints"):
                soft_row["p0_" + name] = recomputed["p0_b"][name]
        soft_rows.append(soft_row)
        if p0b["status"] == "AlmostSolved":
            raw = p0b["raw_solver"]
            failure_cases["almost_solved"].append({
                "case_id": case_id, "status": p0b["status"],
                "primal_residual": raw["primal_residual"], "dual_residual": raw["dual_residual"],
                "duality_gap": raw["duality_gap"],
                "candidate_fixed_task_error": raw["candidate_validation"]["fixed_task_normalized_infinity_error"],
                "candidate_witness_is_accepted": False,
            })
        elif not valid_baseline:
            error = recomputed["p0_b"]["fixed_task_normalized_infinity_error"]
            failure_cases["solved_fixed_band_failure"].append({
                "case_id": case_id, "status": "Solved", "physical_pass": True,
                "fixed_task_error": error, "excess_over_1e_8": error - 1e-8,
                "error_to_band_ratio": error / 1e-8,
            })

    pair_valid_count = sum(row["p0_valid_baseline"] for row in soft_rows)
    assert pair_valid_count == 221 and restored_stage_a_count == 13
    assert len(failure_cases["almost_solved"]) == 13
    assert len(failure_cases["solved_fixed_band_failure"]) == 11
    assert {gate: sum(row[gate] for row in rows) for gate in gate_counts} == gate_counts
    errors = [row["fixed_task_error"] for row in failure_cases["solved_fixed_band_failure"]]
    mechanism = "CLARABEL_STAGE_B_CONVERGENCE_AND_EXACT_BAND_CERTIFICATE_FAILURE"
    audit = {
        "stage": "STEP02D", "reporting_only_correction": True, "new_solver_calls": 0,
        "corrected_at": datetime.now(timezone.utc).isoformat(),
        "classification": "FULL_PANEL_FROZEN_GATE_FAILURE",
        "failure_mechanism_classification": mechanism,
        "status": "FAIL / REVISE", "next_stage_allowed": False,
        "full_panel_case_count": 245, "path_counts": dict(paths),
        "duplicate_record_count": len(full) - len(records),
        "saved_accepted_witnesses_revalidated": validation_checks,
        "validation_max_absolute_difference": validation_max_difference,
        "historical_manifest_files_unchanged": len(history),
        "implementation_manifest_files_unchanged": len(implementation),
        "gate_counts_unchanged": gate_counts,
        "complete_case_pass_count": sum(row["case_pass"] for row in rows),
        "stage_a_metric_rows_restored": restored_stage_a_count,
        "stage_a_metric_available_count": 245,
        "b1soft_physical_count": 245, "b1soft_p0_pair_valid_count": pair_valid_count,
        "paired_raw_exact_count": dict(raw_pair_counts),
        "paired_raw_max_absolute_difference": raw_pair_max_difference,
        "distinct_optimal_witness_evidence": False,
        "optimal_set_classification": "NO_DISTINCT_OPTIMAL_WITNESSES_ESTABLISHED",
        "optimal_set_interpretation": "Production/reference raw x, slack and dual arrays are identical in all 490 paired A/B solves, including unaccepted candidates. These records do not support distinct valid optimal witnesses; rank/flatness alone would not establish that explanation.",
        "almost_solved_stage_b_count_per_formulation": 13,
        "solved_but_exact_band_failed_count_per_formulation": 11,
        "solved_band_failure_error_min": min(errors),
        "solved_band_failure_error_max": max(errors),
        "solved_band_failure_excess_min": min(errors) - 1e-8,
        "solved_band_failure_excess_max": max(errors) - 1e-8,
        "failure_cases": failure_cases,
        "preserved_execution_input_sha256": preserved_inputs,
        "postprocessor_sha256": digest(Path(__file__)),
    }
    summary = dict(initial_summary)
    summary.update({
        "equivalence_statistics": metric_stats(rows),
        "failure_mechanism_classification": mechanism,
        "b1_soft_analysis_authorized": True,
        "b1_soft_analysis_scope": "Descriptive saved-witness statistics for all245 physically valid B1-soft cases; paired comparisons restricted to221 accepted, physical, exact-band-valid P0 baselines. No superiority inference.",
        "b1_soft_valid_count": 245,
        "b1_soft_p0_pair_valid_count": pair_valid_count,
        "b1_soft_p0_pair_unavailable_count": 24,
        "reporting_only_postprocessing": {"solver_calls": 0, "gate_decisions_changed": False, "restored_stage_a_metric_rows": restored_stage_a_count, "audit": "postrun_certification_audit.json"},
    })
    assert summary["gate_pass_counts"] == initial_summary["gate_pass_counts"]
    assert summary["next_stage_allowed"] is False
    report = (OUTPUT / "STEP02D_REPORT.md").read_text(encoding="utf-8")
    report = report.replace(
        "B1-soft physical checks authorize descriptive task/torque/contact comparisons:\nFalse. These comparisons do not establish superiority or recoverability.",
        "B1-soft physical validity is 245/245, authorizing descriptive saved-witness task, torque and contact statistics. Paired P0/B1-soft comparisons are available only for the 221 P0 baselines that satisfy solver success, physical validity and the exact fixed-task band; the other 24 paired rows remain blank with explicit reasons. These comparisons do not establish superiority or recoverability.",
    )
    report = report.rstrip().removesuffix("NEXT_STAGE_ALLOWED = FALSE").rstrip()
    report += f"""\n\n## Reporting-only postrun certification\n\nThe saved execution was postprocessed without any new solver call. Initial reports, tables and figures are preserved as `initial_execution_*`; journals, solver records, configuration, frozen implementations and all historical artifacts remain unchanged. Gate counts, FAIL / REVISE and E1 prohibition are unchanged.\n\nThe 24 failed cases comprise 13 Stage-B `AlmostSolved` returns per formulation, rejected by the frozen success requirement, and 11 `Solved`/physically valid Stage-B returns per formulation whose exact-band errors exceed 1e-8. For the latter group, fixed-task errors range from {min(errors):.17g} to {max(errors):.17g}; excesses range from {min(errors)-1e-8:.17g} to {max(errors)-1e-8:.17g}. The mechanism is `{mechanism}`.\n\nProduction and reference raw x, slack and dual arrays match exactly in all 490 paired Stage-A/Stage-B solves. The saved evidence does not establish distinct optimal witnesses or support a nonunique-optimal-set classification. Failed raw candidates remain unaccepted.\n\nAll 245 Stage-A witnesses were already valid; their two equivalence metrics are now reported for 245/245 cases (both maxima zero). The initial report omitted those metrics for the 13 cases without accepted Stage-B results. Stage-B metrics remain available for 232/245 cases and the exact-band certificate passes for 221/245. B1-soft statistics cover 245 physical witnesses; paired comparisons use only the 221 fully valid P0 baselines.\n\nNEXT_STAGE_ALLOWED = FALSE\n"""

    changed_names = ("eq_summary.json", "STEP02D_RESULT.json", "eq_cases.csv", "b1_soft_vs_p0.csv", "STEP02D_REPORT.md", *FIGURES)
    for name in changed_names:
        if (OUTPUT / ("initial_execution_" + name)).exists():
            raise FileExistsError("Reporting correction already started: " + name)
    for name in changed_names:
        with (OUTPUT / ("initial_execution_" + name)).open("xb") as backup:
            backup.write((OUTPUT / name).read_bytes())
    _write_csv(OUTPUT / "eq_cases.csv", rows)
    _write_csv(OUTPUT / "b1_soft_vs_p0.csv", soft_rows)
    _write_json(OUTPUT / "eq_summary.json", summary)
    _write_json(OUTPUT / "STEP02D_RESULT.json", summary)
    (OUTPUT / "STEP02D_REPORT.md").write_text(report, encoding="utf-8")
    render_figures(OUTPUT, rows, diagnostics, soft_rows, True)
    for name, expected in preserved_inputs.items():
        assert digest(OUTPUT / name) == expected, name
    for path, expected in {**history, **implementation}.items():
        assert digest(Path(path)) == expected, path
    audit["corrected_output_sha256"] = {name: digest(OUTPUT / name) for name in changed_names}
    audit["initial_execution_backup_sha256"] = {name: digest(OUTPUT / ("initial_execution_" + name)) for name in changed_names}
    _write_json(OUTPUT / "postrun_certification_audit.json", audit)
    return {"reporting_only": True, "new_solves": 0, "history_unchanged": True,
        "stage_a_available": 245, "b1soft_rows": 245, "valid_p0_pairs": pair_valid_count,
        "almost_solved": 13, "solved_band_failure": 11,
        "fixed_band_error_range": [min(errors), max(errors)], "next_stage_allowed": False}


if __name__ == "__main__":
    main()
