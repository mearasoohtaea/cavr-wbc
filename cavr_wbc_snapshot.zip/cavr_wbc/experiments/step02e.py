"""STEP-02E minimal fixed-band repair and four-case equivalence re-run.

This runner is intentionally limited to the four frozen STEP-02C regression
cases.  It first verifies the pre-revision STEP-02D freeze and the single
authorized configuration change, then reconstructs and compares the complete
production/reference Stage-A and Stage-B QPs.  The original STEP-02C gate is
evaluated only after the formulation-identity precheck succeeds.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import difflib
import hashlib
import json
import math
from pathlib import Path
import subprocess
from typing import Any

import mujoco
import numpy as np
import yaml

from cavr_wbc.control.clarabel_p0 import (
    ClarabelP0Production,
    ClarabelP0Settings,
)
from cavr_wbc.control.fixed_support_qp import (
    build_contact_template,
    build_physical_snapshot,
)
from cavr_wbc.control.independent_lex_reference import (
    ClarabelReferenceSettings,
    IndependentLexicographicReference,
)
from cavr_wbc.control.scaled_fixed_support_qp import (
    Step02rSolverSettings,
    physical_validation_pass,
)
from cavr_wbc.experiments import step02c as frozen_gate
from cavr_wbc.experiments import step02d as localization
from cavr_wbc.platforms.go2_mujoco import (
    extract_actuator_joint_map,
    load_go2_model,
)


CONFIG_PATH = Path("configs/dev/step02c_b1_p0_equivalence.yaml")
STEP02C_ROOT = Path("artifacts/step02c_b1_p0_equivalence")
STEP02D_ROOT = Path("artifacts/step02d_equivalence_failure_localization")
PARENT_ROOT = Path("artifacts/step02_b1_p0_equivalence")
DEFAULT_OUTPUT = Path("artifacts/step02e_fixed_band_repair")
FREEZE_MANIFEST_NAME = "STEP02D_FREEZE_MANIFEST.json"
FORMULATION_ATOL = 1.0e-12
FORMULATION_RTOL = 0.0
REQUIRED_TEST_COUNT = 62
OLD_GUARD_FRACTION = 0.20
REVISED_GUARD_FRACTION = 0.0
EXPECTED_EXTERNAL_BAND = 1.0e-8

CLASS_PASS = "STEP02E-FIXED-BAND-REPAIR-PASS"
CLASS_IDENTITY_FAIL = "STEP02E-FORMULATION-IDENTITY-FAIL"
CLASS_EQUIVALENCE_FAIL = "STEP02E-EQUIVALENCE-FAIL"
CLASS_INFRASTRUCTURE_FAIL = "STEP02E-INFRASTRUCTURE-FAIL"


def _json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    if isinstance(value, np.ndarray):
        return _json_safe(value.tolist())
    if isinstance(value, (np.floating, float)):
        number = float(value)
        if math.isinf(number):
            return "Infinity" if number > 0.0 else "-Infinity"
        return number if math.isfinite(number) else "NaN"
    if isinstance(value, np.integer):
        return int(value)
    if isinstance(value, np.bool_):
        return bool(value)
    return value


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(_json_safe(value), indent=2, ensure_ascii=False, allow_nan=False)
        + "\n",
        encoding="utf-8",
    )


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _git(*args: str) -> str:
    return subprocess.check_output(
        ("git", *args), text=True, encoding="utf-8"
    ).strip()


def _load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _verify_inventory(
    manifest: dict[str, Any], expected_root: Path
) -> list[dict[str, Any]]:
    listed = manifest.get("artifacts")
    if not isinstance(listed, list) or manifest.get("artifact_count") != len(listed):
        raise ValueError(f"invalid artifact inventory for {expected_root}")
    expected_resolved = expected_root.resolve()
    seen: set[Path] = set()
    verified: list[dict[str, Any]] = []
    for item in listed:
        path = Path(item["path"])
        resolved = path.resolve()
        try:
            resolved.relative_to(expected_resolved)
        except ValueError as exc:
            raise ValueError(f"freeze path escapes {expected_root}: {path}") from exc
        if resolved in seen:
            raise ValueError(f"duplicate freeze entry: {path}")
        seen.add(resolved)
        if not path.is_file():
            raise FileNotFoundError(f"frozen artifact missing: {path}")
        size = path.stat().st_size
        digest = _sha256(path)
        if size != int(item["size_bytes"]) or digest != item["sha256"]:
            raise ValueError(f"frozen artifact changed: {path}")
        verified.append({"path": path.as_posix(), "size_bytes": size, "sha256": digest})
    current = {path.resolve() for path in expected_root.iterdir() if path.is_file()}
    if current != seen:
        missing = sorted(str(path) for path in seen - current)
        unlisted = sorted(str(path) for path in current - seen)
        raise ValueError(
            f"freeze inventory no longer exact for {expected_root}: "
            f"missing={missing}, unlisted={unlisted}"
        )
    return verified


def _verify_freeze(output: Path) -> dict[str, Any]:
    manifest_path = output / FREEZE_MANIFEST_NAME
    if not manifest_path.is_file():
        raise FileNotFoundError(f"required pre-revision freeze missing: {manifest_path}")
    manifest = _load_json(manifest_path)
    if manifest.get("source_directory") != STEP02D_ROOT.as_posix():
        raise ValueError("STEP-02D freeze source directory mismatch")
    if manifest.get("source_tree_was_clean") is not True:
        raise ValueError("STEP-02D freeze does not certify a clean pre-revision tree")
    frozen_head = str(manifest.get("frozen_git_head", ""))
    current_head = _git("rev-parse", "HEAD")
    if not frozen_head or current_head != frozen_head:
        raise ValueError(
            f"execution HEAD {current_head} differs from frozen STEP-02D HEAD {frozen_head}"
        )
    step02d_artifacts = _verify_inventory(manifest, STEP02D_ROOT)

    nested_path = STEP02D_ROOT / "STEP02C_FREEZE_MANIFEST.json"
    nested = _load_json(nested_path)
    if nested.get("source_directory") != STEP02C_ROOT.as_posix():
        raise ValueError("nested STEP-02C freeze source directory mismatch")
    step02c_artifacts = _verify_inventory(nested, STEP02C_ROOT)
    return {
        "verified": True,
        "manifest_path": manifest_path.as_posix(),
        "manifest_sha256": _sha256(manifest_path),
        "frozen_git_head": frozen_head,
        "clean_tree_certified_before_revision": True,
        "step02d_artifact_count": len(step02d_artifacts),
        "step02c_artifact_count": len(step02c_artifacts),
        "step02d_artifacts": step02d_artifacts,
        "nested_step02c_manifest_sha256": _sha256(nested_path),
    }


def _flatten(value: Any, prefix: tuple[str, ...] = ()) -> dict[tuple[str, ...], Any]:
    if isinstance(value, dict):
        result: dict[tuple[str, ...], Any] = {}
        for key, item in value.items():
            result.update(_flatten(item, prefix + (str(key),)))
        return result
    if isinstance(value, list):
        result = {}
        for index, item in enumerate(value):
            result.update(_flatten(item, prefix + (str(index),)))
        return result
    return {prefix: value}


def _revision_audit(output: Path, frozen_head: str) -> tuple[dict[str, Any], dict[str, Any]]:
    old_text = _git("show", f"{frozen_head}:{CONFIG_PATH.as_posix()}") + "\n"
    new_text = CONFIG_PATH.read_text(encoding="utf-8")
    old_config = yaml.safe_load(old_text)
    new_config = yaml.safe_load(new_text)
    old_flat = _flatten(old_config)
    new_flat = _flatten(new_config)
    all_keys = set(old_flat) | set(new_flat)
    differences = [
        {
            "path": ".".join(key),
            "old": old_flat.get(key, "<MISSING>"),
            "new": new_flat.get(key, "<MISSING>"),
        }
        for key in sorted(all_keys)
        if old_flat.get(key, object()) != new_flat.get(key, object())
    ]
    expected_path = (
        "production_numerical_contract",
        "internal_fixed_task_guard_fraction",
    )
    exact_single_revision = bool(
        len(differences) == 1
        and differences[0]["path"] == ".".join(expected_path)
        and float(differences[0]["old"]) == OLD_GUARD_FRACTION
        and float(differences[0]["new"]) == REVISED_GUARD_FRACTION
    )
    external = float(
        new_config["production_numerical_contract"]
        ["external_fixed_task_normalized_tolerance"]
    )
    objective_band = float(
        new_config["objectives"]["secondary_task_fix_normalized_tolerance"]
    )
    if not exact_single_revision:
        raise ValueError(f"revision is not the one authorized config leaf: {differences}")
    if external != EXPECTED_EXTERNAL_BAND or objective_band != EXPECTED_EXTERNAL_BAND:
        raise ValueError("frozen external fixed-task band changed")

    status_lines = _git("status", "--short").splitlines()
    task_source_config_paths = {
        CONFIG_PATH.as_posix(),
        Path("cavr_wbc/experiments/step02e.py").as_posix(),
    }
    source_config_changes = sorted(
        line[3:]
        for line in status_lines
        if len(line) > 3 and line[3:].replace("\\", "/") in task_source_config_paths
    )
    unrelated_workspace_changes = sorted(
        line
        for line in status_lines
        if len(line) > 3
        and not line[3:].replace("\\", "/").startswith(
            DEFAULT_OUTPUT.as_posix() + "/"
        )
        and line[3:].replace("\\", "/") not in task_source_config_paths
    )
    diff = "".join(
        difflib.unified_diff(
            old_text.splitlines(keepends=True),
            new_text.splitlines(keepends=True),
            fromfile=f"a/{CONFIG_PATH.as_posix()}",
            tofile=f"b/{CONFIG_PATH.as_posix()}",
            n=3,
        )
    )
    revision_text = (
        "STEP-02E authorized revision audit\n"
        f"Frozen git HEAD: {frozen_head}\n"
        "Semantic configuration changes: 1\n"
        "Changed leaf: production_numerical_contract.internal_fixed_task_guard_fraction\n"
        f"Old value: {OLD_GUARD_FRACTION}\n"
        f"New value: {REVISED_GUARD_FRACTION}\n"
        "Production/reference implementation changes: none required by the repair.\n"
        "Reference implementation changes: none.\n\n"
        + diff
    )
    (output / "revision_diff.txt").write_text(revision_text, encoding="utf-8")
    return new_config, {
        "exactly_one_authorized_semantic_change": exact_single_revision,
        "differences": differences,
        "old_guard_fraction": OLD_GUARD_FRACTION,
        "new_guard_fraction": REVISED_GUARD_FRACTION,
        "external_band": external,
        "old_internal_production_band": external * (1.0 - OLD_GUARD_FRACTION),
        "revised_internal_production_band": external,
        "independent_reference_band": external,
        "changed_source_config_files_at_execution": source_config_changes,
        "preexisting_or_concurrent_unrelated_workspace_changes": (
            unrelated_workspace_changes
        ),
        "git_status_at_execution": status_lines,
    }


def _max_abs_difference(left: Any, right: Any) -> float:
    if left is None or right is None:
        return 0.0 if left is None and right is None else math.inf
    return localization._max_abs_difference(  # noqa: SLF001 - audit reuse is deliberate
        np.asarray(left, dtype=float), np.asarray(right, dtype=float)
    )


def _aligned_row_scales(problem: dict[str, Any]) -> tuple[list[str], np.ndarray]:
    qp = problem["solver_coordinate_qp"]
    labels = [localization._canonical_label(label) for label in qp["row_labels"]]
    scales = np.concatenate(
        (
            np.asarray(qp["equality_row_scales"], dtype=float),
            np.asarray(qp["inequality_row_scales"], dtype=float),
        )
    )
    order = np.argsort(np.asarray(labels, dtype=str))
    return [labels[index] for index in order], scales[order]


def _contract_comparison(
    production: dict[str, Any], reference: dict[str, Any]
) -> dict[str, Any]:
    production_labels, production_row_scales = _aligned_row_scales(production)
    reference_labels, reference_row_scales = _aligned_row_scales(reference)
    prod_objective = production["objective_contract"]
    ref_objective = reference["objective_contract"]
    variable_order_match = (
        production["variable_ordering"]["ordering"]
        == reference["variable_ordering"]["ordering"]
        and production["variable_ordering"]["names"]
        == reference["variable_ordering"]["names"]
        and production["variable_ordering"]["dimension"]
        == reference["variable_ordering"]["dimension"]
    )
    extraction_indices_match = (
        production["variable_ordering"]["extraction_indices"]
        == reference["variable_ordering"]["extraction_indices"]
    )
    differences = {
        "desired_task": _max_abs_difference(
            prod_objective["desired_task"], ref_objective["desired_task"]
        ),
        "fixed_task_target": _max_abs_difference(
            production["task_target_vector"], reference["task_target_vector"]
        ),
        "torque_regularization_coefficient": abs(
            float(prod_objective["torque_regularization_coefficient"])
            - float(ref_objective["torque_regularization_coefficient"])
        ),
        "variable_scales": _max_abs_difference(
            production["solver_coordinate_qp"]["variable_scales"],
            reference["solver_coordinate_qp"]["variable_scales"],
        ),
        "row_scales": (
            _max_abs_difference(production_row_scales, reference_row_scales)
            if production_labels == reference_labels
            else math.inf
        ),
        "task_scales": _max_abs_difference(
            prod_objective["task_scales"], ref_objective["task_scales"]
        ),
        "task_weights": _max_abs_difference(
            prod_objective["task_weights"], ref_objective["task_weights"]
        ),
        "torque_scales": _max_abs_difference(
            prod_objective["torque_scales"], ref_objective["torque_scales"]
        ),
        "fixed_band_internal_half_width": abs(
            float(production["fixed_band"]["internal_normalized_half_width"])
            - float(reference["fixed_band"]["internal_normalized_half_width"])
        ),
        "fixed_band_physical_half_width": _max_abs_difference(
            production["fixed_band"]["physical_half_width"],
            reference["fixed_band"]["physical_half_width"],
        ),
    }
    equivalent = bool(
        variable_order_match
        and extraction_indices_match
        and production_labels == reference_labels
        and all(value <= FORMULATION_ATOL for value in differences.values())
    )
    return {
        "equivalent": equivalent,
        "variable_ordering_match": variable_order_match,
        "extraction_indices_match": extraction_indices_match,
        "scaling_row_labels_match": production_labels == reference_labels,
        "max_abs_differences": differences,
    }


def _case_key(spec: dict[str, Any]) -> str:
    return str(spec["regression_id"]).split("_", 1)[0]


def _build_context(config: dict[str, Any]) -> dict[str, Any]:
    panel = _load_json(PARENT_ROOT / "snapshot_panel.json")["states"]
    wanted = {spec["snapshot_id"] for spec in frozen_gate.REGRESSION_CASES}
    model = load_go2_model()
    nominal_data = mujoco.MjData(model)
    mujoco.mj_resetDataKeyframe(
        model,
        nominal_data,
        mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_KEY, "home"),
    )
    mujoco.mj_forward(model, nominal_data)
    template = build_contact_template(model, nominal_data)
    total_weight = float(np.sum(model.body_mass) * abs(model.opt.gravity[2]))
    snapshots = {
        item["snapshot_id"]: build_physical_snapshot(
            model,
            template,
            item["snapshot_id"],
            item["qpos"],
            task_scales=config["task_stack"]["normalization_scales"],
            task_weights=config["task_stack"]["weight_diagonal"],
            normal_force_upper=total_weight,
        )
        for item in panel
        if item["snapshot_id"] in wanted
    }
    if set(snapshots) != wanted:
        raise ValueError(f"frozen regression snapshots missing: {wanted - set(snapshots)}")
    actuator_names = [
        str(mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_ACTUATOR, index))
        for index in range(model.nu)
    ]
    actuator_index = {
        item.actuator_name: item.actuator_index
        for item in extract_actuator_joint_map(model)
    }
    return {
        "model": model,
        "snapshots": snapshots,
        "actuator_names": actuator_names,
        "actuator_index": actuator_index,
        "health_by_id": {item["health_id"]: item for item in config["health_panel"]},
        "demand_by_id": {item["demand_id"]: item for item in config["task_demands"]},
    }


def _formulation_identity(
    config: dict[str, Any], context: dict[str, Any]
) -> dict[str, Any]:
    model = context["model"]
    production_settings = ClarabelP0Settings(**config["clarabel_production"])
    reference_settings = ClarabelReferenceSettings(**config["clarabel_reference"])
    tolerance = float(config["objectives"]["secondary_task_fix_normalized_tolerance"])
    guard = float(
        config["production_numerical_contract"]["internal_fixed_task_guard_fraction"]
    )
    lambda_tau = float(config["objectives"]["lambda_tau"])
    cases: list[dict[str, Any]] = []
    aggregate: dict[str, float] = {}

    for spec in frozen_gate.REGRESSION_CASES:
        key = _case_key(spec)
        snapshot = context["snapshots"][spec["snapshot_id"]]
        health = context["health_by_id"][spec["health_id"]]
        desired = np.asarray(
            context["demand_by_id"][spec["demand_id"]]["y_d"], dtype=float
        )
        rho = localization._rho_vector(  # noqa: SLF001 - shared frozen reconstruction
            model, health, context["actuator_names"]
        )
        production = ClarabelP0Production(
            snapshot,
            rho,
            production_settings,
            secondary_task_fix_normalized_tolerance=tolerance,
            fixed_task_numerical_guard_fraction=guard,
        )
        reference = IndependentLexicographicReference(
            snapshot,
            rho,
            reference_settings,
            secondary_task_fix_normalized_tolerance=tolerance,
        )
        production_a, production_target = localization._run_instance(  # noqa: SLF001
            "production",
            production,
            snapshot,
            rho,
            context["actuator_names"],
            stage="A",
            desired_task=desired,
            torque_regularization_weight=0.0,
            fixed_task_output=None,
        )
        reference_a, reference_target = localization._run_instance(  # noqa: SLF001
            "reference",
            reference,
            snapshot,
            rho,
            context["actuator_names"],
            stage="A",
            desired_task=desired,
            torque_regularization_weight=0.0,
            fixed_task_output=None,
        )
        production_b, _ = localization._run_instance(  # noqa: SLF001
            "production",
            production,
            snapshot,
            rho,
            context["actuator_names"],
            stage="B",
            desired_task=None,
            torque_regularization_weight=lambda_tau,
            fixed_task_output=production_target,
        )
        reference_b, _ = localization._run_instance(  # noqa: SLF001
            "reference",
            reference,
            snapshot,
            rho,
            context["actuator_names"],
            stage="B",
            desired_task=None,
            torque_regularization_weight=lambda_tau,
            fixed_task_output=reference_target,
        )

        stages: dict[str, Any] = {}
        for stage, prod_problem, ref_problem in (
            ("stage_a", production_a, reference_a),
            ("stage_b", production_b, reference_b),
        ):
            original = localization._compare_qp(  # noqa: SLF001
                prod_problem, ref_problem, "original_coordinate_qp"
            )
            solver = localization._compare_qp(  # noqa: SLF001
                prod_problem, ref_problem, "solver_coordinate_qp"
            )
            contracts = _contract_comparison(prod_problem, ref_problem)
            stage_pass = bool(
                original["equivalent"] and solver["equivalent"] and contracts["equivalent"]
            )
            stages[stage] = {
                "identity_pass": stage_pass,
                "original_coordinate_qp": original,
                "solver_coordinate_qp": solver,
                "contracts": contracts,
            }
            for coordinate, comparison in (
                ("original", original),
                ("solver", solver),
            ):
                for field, value in comparison.get("max_abs_differences", {}).items():
                    name = f"{stage}.{coordinate}.{field}"
                    aggregate[name] = max(aggregate.get(name, 0.0), float(value))
            for field, value in contracts["max_abs_differences"].items():
                name = f"{stage}.contract.{field}"
                aggregate[name] = max(aggregate.get(name, 0.0), float(value))
        cases.append(
            {
                "case_key": key,
                "regression_id": spec["regression_id"],
                "case_id": (
                    f"{spec['snapshot_id']}__{spec['health_id']}__{spec['demand_id']}"
                ),
                "identity_pass": all(item["identity_pass"] for item in stages.values()),
                "stages": stages,
            }
        )

    return {
        "stage": "STEP02E_FORMULATION_IDENTITY_PRECHECK",
        "comparison_precision": {"atol": FORMULATION_ATOL, "rtol": FORMULATION_RTOL},
        "cases_reconstructed": [case["case_key"] for case in cases],
        "all_cases_identity_pass": all(case["identity_pass"] for case in cases),
        "cases": cases,
        "global_max_abs_differences": aggregate,
        "maximum_over_all_numeric_fields": max(aggregate.values(), default=0.0),
        "gate_evaluated_during_precheck": False,
    }


def _metric_thresholds(thresholds: dict[str, float]) -> dict[str, float]:
    return {
        "stage_a_normalized_task_output_inf_difference": float(
            thresholds["normalized_task_equivalence"]
        ),
        "stage_a_task_objective_abs_difference": float(
            thresholds["task_objective_difference"]
        ),
        "stage_b_normalized_task_output_inf_difference": float(
            thresholds["normalized_task_equivalence"]
        ),
        "stage_b_task_objective_abs_difference": float(
            thresholds["task_objective_difference"]
        ),
        "stage_b_torque_regularizer_abs_difference": float(
            thresholds["torque_regularizer_difference"]
        ),
    }


def _frozen_step02c_rows() -> dict[str, dict[str, Any]]:
    frozen = _load_json(STEP02C_ROOT / "regression_results.json")
    rows = {_case_key(row): row for row in frozen["cases"]}
    expected = {_case_key(spec) for spec in frozen_gate.REGRESSION_CASES}
    if set(rows) != expected:
        raise ValueError("STEP-02C frozen regression case identity changed")
    return rows


def _not_run_comparison(
    frozen_rows: dict[str, dict[str, Any]], reason: str
) -> list[dict[str, Any]]:
    return [
        {
            "case_key": key,
            "step02c_metrics": row["metrics"],
            "step02c_equivalence_pass": bool(row["checks"]["equivalence"]),
            "step02e_metrics": None,
            "step02e_equivalence_pass": None,
            "absolute_metric_changes": None,
            "status": reason,
        }
        for key, row in sorted(frozen_rows.items())
    ]


def _run_gate(
    config: dict[str, Any],
    context: dict[str, Any],
    verified_test_count: int,
    required_test_failures: list[str],
    frozen_rows: dict[str, dict[str, Any]],
) -> tuple[dict[str, Any], dict[str, Any]]:
    model = context["model"]
    thresholds = config["validation"]
    metric_thresholds = _metric_thresholds(thresholds)
    tolerance = float(config["objectives"]["secondary_task_fix_normalized_tolerance"])
    lambda_tau = float(config["objectives"]["lambda_tau"])
    guard = float(
        config["production_numerical_contract"]["internal_fixed_task_guard_fraction"]
    )
    production_settings = ClarabelP0Settings(**config["clarabel_production"])
    reference_settings = ClarabelReferenceSettings(**config["clarabel_reference"])
    osqp_settings = Step02rSolverSettings(**config["osqp_stage_a_diagnostic"])
    rows: list[dict[str, Any]] = []
    comparisons: list[dict[str, Any]] = []

    for spec in frozen_gate.REGRESSION_CASES:
        key = _case_key(spec)
        snapshot = context["snapshots"][spec["snapshot_id"]]
        health = context["health_by_id"][spec["health_id"]]
        demand = context["demand_by_id"][spec["demand_id"]]
        desired = np.asarray(demand["y_d"], dtype=float)
        rho = frozen_gate._rho_vector(  # noqa: SLF001 - exact frozen helper
            model, health, context["actuator_index"]
        )
        case = {
            **spec,
            "case_key": key,
            "task_class": demand["class"],
            "case_id": (
                f"{spec['snapshot_id']}__{spec['health_id']}__{spec['demand_id']}"
            ),
        }
        bundle = frozen_gate._solve_case(  # noqa: SLF001 - exact frozen gate
            snapshot=snapshot,
            rho=rho,
            desired=desired,
            tolerance=tolerance,
            lambda_tau=lambda_tau,
            thresholds=thresholds,
            production_settings=production_settings,
            reference_settings=reference_settings,
            osqp_settings=osqp_settings,
            guard_fraction=guard,
        )
        p0_a = bundle["p0_a"]
        p0_b = bundle["p0_b"]
        ref_a = bundle["ref_a"]
        ref_b = bundle["ref_b"]
        soft = bundle["soft"]
        metrics = frozen_gate._comparison_metrics(  # noqa: SLF001
            snapshot, desired, p0_a, p0_b, ref_a, ref_b
        )
        checks = {
            "p0_stage_a": physical_validation_pass(p0_a, thresholds),
            "p0_stage_b": physical_validation_pass(p0_b, thresholds),
            "p0_stage_b_fixed_band": frozen_gate._fixed_band_pass(  # noqa: SLF001
                p0_b, tolerance
            ),
            "reference_stage_a": physical_validation_pass(ref_a, thresholds),
            "reference_stage_b": physical_validation_pass(ref_b, thresholds),
            "reference_stage_b_fixed_band": frozen_gate._fixed_band_pass(  # noqa: SLF001
                ref_b, tolerance
            ),
            "b1_soft": physical_validation_pass(soft, thresholds),
            "equivalence": frozen_gate._equivalence_pass(  # noqa: SLF001
                metrics, thresholds
            ),
        }
        per_metric = {
            field: {
                "value": metrics[field],
                "frozen_threshold": metric_thresholds[field],
                "pass": bool(
                    metrics[field] is not None
                    and float(metrics[field]) <= metric_thresholds[field]
                ),
            }
            for field in frozen_gate.METRIC_FIELDS
        }
        frozen_metrics = frozen_rows[key]["metrics"]
        changes = {
            field: (
                None
                if metrics[field] is None or frozen_metrics[field] is None
                else abs(float(metrics[field]) - float(frozen_metrics[field]))
            )
            for field in frozen_gate.METRIC_FIELDS
        }
        rows.append(
            {
                **case,
                "checks": checks,
                "metrics": metrics,
                "metrics_with_frozen_thresholds": per_metric,
                "statuses": {
                    name: None if bundle[name] is None else bundle[name].status
                    for name in ("p0_a", "p0_b", "ref_a", "ref_b", "soft", "osqp_a")
                },
                "production_stage_b_fixed_task_error": (
                    None
                    if p0_b is None
                    else p0_b.validation.get("fixed_task_normalized_infinity_error")
                ),
                "reference_stage_b_fixed_task_error": (
                    None
                    if ref_b is None
                    else ref_b.validation.get("fixed_task_normalized_infinity_error")
                ),
                "production_errors": {
                    "stage_a_validation": None if p0_a is None else p0_a.validation,
                    "stage_b_validation": None if p0_b is None else p0_b.validation,
                },
                "independent_reference_errors": {
                    "stage_a_validation": None if ref_a is None else ref_a.validation,
                    "stage_b_validation": None if ref_b is None else ref_b.validation,
                },
                "regression_pass": all(checks.values()),
            }
        )
        comparisons.append(
            {
                "case_key": key,
                "step02c_metrics": frozen_metrics,
                "step02c_equivalence_pass": bool(
                    frozen_rows[key]["checks"]["equivalence"]
                ),
                "step02e_metrics": metrics,
                "step02e_equivalence_pass": bool(checks["equivalence"]),
                "absolute_metric_changes": changes,
                "status": "EXECUTED",
            }
        )

    check_names = tuple(rows[0]["checks"])
    check_counts = {
        check: sum(bool(row["checks"][check]) for row in rows)
        for check in check_names
    }
    main_gate_pass_count = check_counts["equivalence"]
    required_tests_pass = bool(
        verified_test_count >= REQUIRED_TEST_COUNT
        and not required_test_failures
    )
    all_case_checks_pass = all(row["regression_pass"] for row in rows)
    regression_results = {
        "stage": "STEP02E_EXACT_STEP02C_REGRESSION_GATE_RERUN",
        "executed": True,
        "case_count": len(rows),
        "verified_test_count": verified_test_count,
        "required_test_count": REQUIRED_TEST_COUNT,
        "required_test_failure_count": len(required_test_failures),
        "required_test_failures": required_test_failures,
        "required_tests_pass": required_tests_pass,
        "check_pass_counts": check_counts,
        "all_case_checks_pass": all_case_checks_pass,
        "main_gate_pass_count": main_gate_pass_count,
        "cases": rows,
    }
    return regression_results, {
        "step02c_vs_step02e": comparisons,
        "metric_thresholds": metric_thresholds,
        "main_gate_pass_count": main_gate_pass_count,
        "required_tests_pass": required_tests_pass,
        "all_case_checks_pass": all_case_checks_pass,
    }


def _artifact_hashes(output: Path) -> dict[str, Any]:
    names = (
        "STEP02D_FREEZE_MANIFEST.json",
        "revision_diff.txt",
        "formulation_identity.json",
        "regression_results.json",
        "eq_summary.json",
        "STEP02E_RESULT.json",
        "STEP02E_REPORT.md",
    )
    rows = [
        {
            "path": (output / name).as_posix(),
            "size_bytes": (output / name).stat().st_size,
            "sha256": _sha256(output / name),
        }
        for name in names
        if (output / name).is_file()
    ]
    manifest = {
        "stage": "STEP02E",
        "note": "Self-hash is omitted to avoid recursive content.",
        "artifact_count": len(rows),
        "artifacts": rows,
    }
    _write_json(output / "artifact_hashes.json", manifest)
    return manifest


def _report(
    *,
    generated_at: str,
    classification: str,
    identity: dict[str, Any],
    regression: dict[str, Any],
    summary: dict[str, Any],
    revision: dict[str, Any],
    main_count: int,
    next_stage_allowed: bool,
    error: str | None = None,
) -> str:
    def metric(value: Any) -> str:
        return "None" if value is None else f"{float(value):.12e}"

    lines = [
        "## Material Passport",
        "",
        "- Origin Skill: experiment-agent",
        "- Origin Mode: run + validate",
        f"- Origin Date: {generated_at}",
        f"- Verification Status: {'VERIFIED' if classification == CLASS_PASS else 'FAILED GATE'}",
        "- Version Label: step02e_fixed_band_repair_v1",
        "- Upstream Dependency: STEP-02D",
        "",
        "# STEP-02E Minimal Fixed-Band Formulation Repair",
        "",
        "## Scope",
        "",
        "Only the production internal guard fraction was revised from `0.20` to `0.0`. "
        "The external band, reference path, solver settings, thresholds, metrics, and four "
        "frozen regression cases were unchanged. The 245-case panel, one-step MuJoCo "
        "validation, and E1 were not run.",
        "",
        "## Frozen bands",
        "",
        f"- Old internal production band: `{revision.get('old_internal_production_band', 8e-9):.1e}`",
        f"- Revised internal production band: `{revision.get('revised_internal_production_band', 1e-8):.1e}`",
        f"- Independent-reference band: `{revision.get('independent_reference_band', 1e-8):.1e}`",
        "",
        "## Formulation identity",
        "",
        f"Identity precheck passed: `{identity.get('all_cases_identity_pass', False)}` at "
        f"`atol={FORMULATION_ATOL:.0e}, rtol=0`. Maximum numeric difference over all "
        f"compared fields: `{identity.get('maximum_over_all_numeric_fields')}`.",
        "",
    ]
    if regression.get("executed"):
        lines.extend(
            [
                "## Exact STEP-02C gate re-run",
                "",
                "| Case | Norm task A | Task objective A | Norm task B | Task objective B | Torque regularizer B | Pass |",
                "|---|---:|---:|---:|---:|---:|:---:|",
            ]
        )
        for row in regression["cases"]:
            metrics = row["metrics"]
            lines.append(
                "| {case} | {a_norm} | {a_obj} | {b_norm} | "
                "{b_obj} | {b_tau} | {passed} |".format(
                    case=row["case_key"],
                    a_norm=metric(metrics["stage_a_normalized_task_output_inf_difference"]),
                    a_obj=metric(metrics["stage_a_task_objective_abs_difference"]),
                    b_norm=metric(metrics["stage_b_normalized_task_output_inf_difference"]),
                    b_obj=metric(metrics["stage_b_task_objective_abs_difference"]),
                    b_tau=metric(metrics["stage_b_torque_regularizer_abs_difference"]),
                    passed="PASS" if row["checks"]["equivalence"] else "FAIL",
                )
            )
        lines.extend(
            [
                "",
                "### Frozen equivalence thresholds",
                "",
                f"- Stage-A/B normalized task-output difference: "
                f"`{summary['metric_thresholds']['stage_a_normalized_task_output_inf_difference']:.1e}`",
                f"- Stage-A/B task-objective difference: "
                f"`{summary['metric_thresholds']['stage_a_task_objective_abs_difference']:.1e}`",
                f"- Stage-B torque-regularizer difference: "
                f"`{summary['metric_thresholds']['stage_b_torque_regularizer_abs_difference']:.1e}`",
                "",
                "### STEP-02C versus STEP-02E",
                "",
                "| Case | Norm task A | Task objective A | Norm task B | Task objective B | Torque regularizer B |",
                "|---|---:|---:|---:|---:|---:|",
            ]
        )
        for comparison in summary["step02c_vs_step02e"]:
            old = comparison["step02c_metrics"]
            new = comparison["step02e_metrics"]
            lines.append(
                "| {case} | {a_norm} | {a_obj} | {b_norm} | {b_obj} | {b_tau} |".format(
                    case=comparison["case_key"],
                    a_norm=(
                        f"{metric(old['stage_a_normalized_task_output_inf_difference'])} → "
                        f"{metric(new['stage_a_normalized_task_output_inf_difference'])}"
                    ),
                    a_obj=(
                        f"{metric(old['stage_a_task_objective_abs_difference'])} → "
                        f"{metric(new['stage_a_task_objective_abs_difference'])}"
                    ),
                    b_norm=(
                        f"{metric(old['stage_b_normalized_task_output_inf_difference'])} → "
                        f"{metric(new['stage_b_normalized_task_output_inf_difference'])}"
                    ),
                    b_obj=(
                        f"{metric(old['stage_b_task_objective_abs_difference'])} → "
                        f"{metric(new['stage_b_task_objective_abs_difference'])}"
                    ),
                    b_tau=(
                        f"{metric(old['stage_b_torque_regularizer_abs_difference'])} → "
                        f"{metric(new['stage_b_torque_regularizer_abs_difference'])}"
                    ),
                )
            )
        lines.extend(
            [
                "",
                f"Verified tests: `{regression['verified_test_count']}` "
                f"(required: `{regression['required_test_count']}`).",
                f"Required-test failures: `{regression.get('required_test_failure_count', 0)}`.",
                "",
            ]
        )
        for failure in regression.get("required_test_failures", []):
            lines.append(f"- `{failure}`")
        lines.extend(
            [
                "" if regression.get("required_test_failures") else "",
                "The complete per-case STEP-02C/STEP-02E comparison, frozen thresholds, "
                "physical checks, and fixed-band checks are persisted in "
                "`regression_results.json` and `eq_summary.json`.",
                "",
            ]
        )
    else:
        lines.extend(
            [
                "## Exact STEP-02C gate re-run",
                "",
                f"Not run: `{regression.get('not_run_reason', 'precheck failure')}`.",
                "",
            ]
        )
    if error is not None:
        lines.extend(["## Infrastructure error", "", f"`{error}`", ""])
    lines.extend(
        [
            "## Downstream authorization",
            "",
            "No downstream experiment was launched. A `TRUE` authorization below permits "
            "only a separately reviewed launch of the next gate.",
            "",
            f"FINAL_CLASSIFICATION = {classification}",
            "",
            f"MAIN_GATE_PASS_COUNT = {main_count}/4",
            "",
            f"NEXT_STAGE_ALLOWED = {'TRUE' if next_stage_allowed else 'FALSE'}",
            "",
        ]
    )
    return "\n".join(lines)


def _write_outcome(
    *,
    output: Path,
    generated_at: str,
    freeze: dict[str, Any],
    revision: dict[str, Any],
    identity: dict[str, Any],
    regression: dict[str, Any],
    gate: dict[str, Any],
    classification: str,
    main_count: int,
    next_stage_allowed: bool,
    error: str | None = None,
) -> None:
    comparison = gate.get("step02c_vs_step02e", [])
    summary = {
        "stage": "STEP02E_MINIMAL_FIXED_BAND_FORMULATION_REPAIR",
        "generated_at": generated_at,
        "classification": classification,
        "bands": {
            "old_internal_production": revision.get("old_internal_production_band", 8e-9),
            "revised_internal_production": revision.get(
                "revised_internal_production_band", 1e-8
            ),
            "independent_reference": revision.get("independent_reference_band", 1e-8),
            "external_fixed_task_tolerance_unchanged": True,
        },
        "formulation_identity_pass": bool(identity.get("all_cases_identity_pass", False)),
        "formulation_max_differences": identity.get("global_max_abs_differences", {}),
        "metric_thresholds": gate.get("metric_thresholds", {}),
        "step02c_vs_step02e": comparison,
        "main_gate_executed": bool(regression.get("executed", False)),
        "main_gate_pass_count": main_count,
        "main_gate_denominator": 4,
        "next_stage_allowed": next_stage_allowed,
        "full_245_case_panel_executed": False,
        "mujoco_one_step_executed": False,
        "e1_executed": False,
        "error": error,
    }
    _write_json(output / "formulation_identity.json", identity)
    _write_json(output / "regression_results.json", regression)
    _write_json(output / "eq_summary.json", summary)
    result = {
        "stage": "STEP02E_MINIMAL_FIXED_BAND_FORMULATION_REPAIR_AND_EXACT_EQUIVALENCE_GATE_RERUN",
        "generated_at": generated_at,
        "final_classification": classification,
        "freeze_verified": bool(freeze.get("verified", False)),
        "freeze_manifest_sha256": freeze.get("manifest_sha256"),
        "execution_git_head": freeze.get("frozen_git_head"),
        "revision": revision,
        "formulation_identity_pass": bool(identity.get("all_cases_identity_pass", False)),
        "required_tests_pass": bool(gate.get("required_tests_pass", False)),
        "main_gate_executed": bool(regression.get("executed", False)),
        "main_gate_pass_count": main_count,
        "main_gate_denominator": 4,
        "next_stage_allowed": next_stage_allowed,
        "downstream": {
            "full_245_case_panel_executed": False,
            "mujoco_one_step_executed": False,
            "e1_executed": False,
        },
        "commit_hash": None,
        "commit_note": "STEP-02E commit is created after artifact generation; report it externally.",
        "artifact_hash_manifest": (output / "artifact_hashes.json").as_posix(),
        "error": error,
    }
    _write_json(output / "STEP02E_RESULT.json", result)
    (output / "STEP02E_REPORT.md").write_text(
        _report(
            generated_at=generated_at,
            classification=classification,
            identity=identity,
            regression=regression,
            summary=summary,
            revision=revision,
            main_count=main_count,
            next_stage_allowed=next_stage_allowed,
            error=error,
        ),
        encoding="utf-8",
    )
    _artifact_hashes(output)


def _infrastructure_failure(output: Path, generated_at: str, error: Exception) -> int:
    message = f"{type(error).__name__}: {error}"
    freeze: dict[str, Any] = {"verified": False}
    revision: dict[str, Any] = {}
    identity = {
        "stage": "STEP02E_FORMULATION_IDENTITY_PRECHECK",
        "comparison_precision": {"atol": FORMULATION_ATOL, "rtol": FORMULATION_RTOL},
        "all_cases_identity_pass": False,
        "cases": [],
        "global_max_abs_differences": {},
        "maximum_over_all_numeric_fields": None,
        "gate_evaluated_during_precheck": False,
        "infrastructure_error": message,
    }
    regression = {
        "stage": "STEP02E_EXACT_STEP02C_REGRESSION_GATE_RERUN",
        "executed": False,
        "not_run_reason": "INFRASTRUCTURE_FAILURE",
        "verified_test_count": None,
        "required_test_count": REQUIRED_TEST_COUNT,
        "main_gate_pass_count": 0,
        "cases": [],
    }
    gate = {
        "main_gate_pass_count": 0,
        "required_tests_pass": False,
        "step02c_vs_step02e": [],
    }
    if not (output / "revision_diff.txt").exists():
        (output / "revision_diff.txt").write_text(
            f"NOT GENERATED: {message}\n", encoding="utf-8"
        )
    _write_outcome(
        output=output,
        generated_at=generated_at,
        freeze=freeze,
        revision=revision,
        identity=identity,
        regression=regression,
        gate=gate,
        classification=CLASS_INFRASTRUCTURE_FAIL,
        main_count=0,
        next_stage_allowed=False,
        error=message,
    )
    print(json.dumps({"final_classification": CLASS_INFRASTRUCTURE_FAIL, "error": message}, indent=2))
    return 4


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=str(CONFIG_PATH))
    parser.add_argument("--output", default=str(DEFAULT_OUTPUT))
    parser.add_argument("--verified-test-count", type=int, default=0)
    parser.add_argument(
        "--required-test-failure",
        action="append",
        default=[],
        help="Exact required-test failure record; repeat for multiple failures.",
    )
    args = parser.parse_args()
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    generated_at = datetime.now(timezone.utc).astimezone().isoformat()
    if Path(args.config) != CONFIG_PATH:
        return _infrastructure_failure(
            output,
            generated_at,
            ValueError(f"STEP-02E requires the frozen config path {CONFIG_PATH}"),
        )

    try:
        freeze = _verify_freeze(output)
        config, revision = _revision_audit(output, freeze["frozen_git_head"])
        context = _build_context(config)
        frozen_rows = _frozen_step02c_rows()
        identity = _formulation_identity(config, context)
        _write_json(output / "formulation_identity.json", identity)

        if not identity["all_cases_identity_pass"]:
            regression = {
                "stage": "STEP02E_EXACT_STEP02C_REGRESSION_GATE_RERUN",
                "executed": False,
                "not_run_reason": "FORMULATION_IDENTITY_PRECHECK_FAILED",
                "verified_test_count": args.verified_test_count,
                "required_test_count": REQUIRED_TEST_COUNT,
                "required_test_failure_count": len(args.required_test_failure),
                "required_test_failures": args.required_test_failure,
                "main_gate_pass_count": 0,
                "cases": [],
            }
            gate = {
                "main_gate_pass_count": 0,
                "required_tests_pass": bool(
                    args.verified_test_count >= REQUIRED_TEST_COUNT
                    and not args.required_test_failure
                ),
                "metric_thresholds": _metric_thresholds(config["validation"]),
                "step02c_vs_step02e": _not_run_comparison(
                    frozen_rows, "NOT_RUN_FORMULATION_IDENTITY_FAIL"
                ),
            }
            classification = CLASS_IDENTITY_FAIL
            main_count = 0
            next_stage_allowed = False
            return_code = 2
        else:
            regression, gate = _run_gate(
                config,
                context,
                args.verified_test_count,
                args.required_test_failure,
                frozen_rows,
            )
            main_count = int(gate["main_gate_pass_count"])
            all_gate_conditions = bool(
                gate["all_case_checks_pass"]
                and gate["required_tests_pass"]
                and main_count == 4
            )
            if all_gate_conditions:
                classification = CLASS_PASS
                next_stage_allowed = True
                return_code = 0
            elif args.required_test_failure:
                classification = CLASS_EQUIVALENCE_FAIL
                next_stage_allowed = False
                return_code = 3
            elif not gate["required_tests_pass"]:
                classification = CLASS_INFRASTRUCTURE_FAIL
                next_stage_allowed = False
                return_code = 4
            else:
                classification = CLASS_EQUIVALENCE_FAIL
                next_stage_allowed = False
                return_code = 3

        preservation = _verify_freeze(output)
        revision["frozen_artifacts_reverified_after_gate"] = True
        revision["post_gate_freeze_manifest_sha256"] = preservation["manifest_sha256"]
        _write_outcome(
            output=output,
            generated_at=generated_at,
            freeze=freeze,
            revision=revision,
            identity=identity,
            regression=regression,
            gate=gate,
            classification=classification,
            main_count=main_count,
            next_stage_allowed=next_stage_allowed,
        )
        print(
            json.dumps(
                {
                    "final_classification": classification,
                    "main_gate_pass_count": f"{main_count}/4",
                    "next_stage_allowed": next_stage_allowed,
                },
                indent=2,
            )
        )
        return return_code
    except Exception as error:  # noqa: BLE001 - failures must become a frozen classification
        return _infrastructure_failure(output, generated_at, error)


if __name__ == "__main__":
    raise SystemExit(main())
