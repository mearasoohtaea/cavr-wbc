"""One-candidate, fail-closed STEP-02F Stage-B certification experiment.

Only ``execute`` can construct an optimizer. All Stage-A/soft/OSQP evidence
comes from STEP-02D full_panel records. No old experiment is rerun.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import unittest
from unittest.mock import patch

import clarabel
import numpy as np
import scipy.sparse as sp
import yaml

from cavr_wbc.control.clarabel_p0 import ClarabelP0Production, ClarabelP0Settings
from cavr_wbc.control.independent_lex_reference import IndependentLexicographicReference, ClarabelReferenceSettings
from cavr_wbc.control.scaled_fixed_support_qp import validate_original_witness
from cavr_wbc.experiments.step02c import REGRESSION_CASES, METRIC_FIELDS, _equivalence_pass, _json_safe, _write_json, _write_csv
from cavr_wbc.experiments.step02d_exact_band import load_context

BASELINE = "208536b21d1c07ed5cf8d9b1b60f334197ac43c3"
OLD = Path("artifacts/step02d_exact_band_equivalence")
OUT = Path("artifacts/step02f_coordinate_equivalence")
PATHS = ("production", "reference")
METRIC_GATES = dict(zip(METRIC_FIELDS, (1e-6, 1e-7, 1e-6, 1e-7, 1e-6)))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def lines(path):
    if not Path(path).exists():
        return []
    return [json.loads(line) for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]


def write(name, data):
    _write_json(OUT / name, data)


def append(name, data):
    with (OUT / name).open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(_json_safe(data), ensure_ascii=False, allow_nan=False) + "\n")
        stream.flush()
        os.fsync(stream.fileno())


def exclusive(name, data):
    with (OUT / name).open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(_json_safe(data), stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def git(*args):
    return subprocess.check_output(["git", "-c", "core.quotepath=false", *args], text=True, encoding="utf-8").strip()


def raw_physical_pass(validation, thresholds):
    return bool(validation.get("available") and
        validation["dynamics_infinity_norm"] <= thresholds["dynamics_infinity_norm"] and
        validation["contact_infinity_norm"] <= thresholds["contact_infinity_norm"] and
        validation["hard_inequality_violation"] <= thresholds["hard_inequality_violation"] and
        validation["health_adapter_identity_error"] <= thresholds["health_adapter_identity"])


def objective(snapshot, desired, task):
    return float(np.sum(snapshot.task_weights * np.square((np.asarray(task) - desired) / snapshot.task_scales)))


def context():
    config = yaml.safe_load((OUT / "config.yaml").read_text(encoding="utf-8"))
    _, snapshots, rhos = load_context(config)
    cases = lines(OLD / "full_panel_cases_journal.jsonl")
    assert len(cases) == len({c["case_id"] for c in cases}) == 245
    assert all(c["phase"] == "full_panel" for c in cases)
    evidence = {}
    for filename, expected_paths in (
        ("p0_clarabel_diagnostics.jsonl", ("p0_a", "p0_b")),
        ("reference_diagnostics.jsonl", ("ref_a", "ref_b")),
        ("b1_soft_diagnostics.jsonl", ("soft",)),
        ("osqp_stage_a_diagnostics.jsonl", ("osqp_a",)),
    ):
        for route in expected_paths:
            selected = [r for r in lines(OLD / filename) if r["phase"] == "full_panel" and r["path"] == route]
            assert len(selected) == len({r["case_id"] for r in selected}) == 245
            evidence[route] = {r["case_id"]: r for r in selected}
    assert all(set(v) == {c["case_id"] for c in cases} for v in evidence.values())
    return config, snapshots, rhos, cases, evidence


def settings_for(path, snapshot, rho, config):
    tolerance = config["objectives"]["secondary_task_fix_normalized_tolerance"]
    if path == "production":
        return ClarabelP0Production(snapshot, rho, ClarabelP0Settings(**config["clarabel_production"]),
            secondary_task_fix_normalized_tolerance=tolerance, fixed_task_numerical_guard_fraction=0.0)._solver_settings()
    return IndependentLexicographicReference(snapshot, rho, ClarabelReferenceSettings(**config["clarabel_reference"]),
        secondary_task_fix_normalized_tolerance=tolerance)._clarabel_settings()


def settings_dict(settings):
    return {key: _json_safe(getattr(settings, key)) for key in dir(settings)
            if not key.startswith("_") and not callable(getattr(settings, key))}


def cached_certificates(config, snapshots, rhos, cases, evidence):
    records = []
    for case in cases:
        cid = case["case_id"]
        s, rho = snapshots[case["snapshot_id"]], rhos[case["health_id"]]
        desired = np.asarray(next(d["y_d"] for d in config["task_demands"] if d["demand_id"] == case["demand_id"]))
        checks = {}
        for route in ("p0_a", "ref_a", "soft", "osqp_a"):
            saved = evidence[route][cid]
            witness = [np.asarray(saved[k], dtype=float) for k in ("qdd", "tau", "contact_force")]
            validation = validate_original_witness(s, rho, *witness)
            task = s.task_matrix @ witness[0] + s.task_bias
            status = saved["success"] and saved["status"] == ("solved" if route == "osqp_a" else "Solved")
            # OSQP is diagnostic only; its frozen successful statuses are kept separately.
            if route == "osqp_a":
                status = bool(saved["success"])
            checks[route] = {
                "source_phase": "full_panel", "status": saved["status"], "status_accepted": bool(status),
                "raw_candidate_physical_pass": raw_physical_pass(validation, config["validation"]),
                "validation": validation, "task_output_matches_saved": bool(np.array_equal(task, saved["task_output"])),
                "task_objective_recomputed": objective(s, desired, task),
                "task_objective_saved": saved["task_objective"], "new_solves": 0,
            }
        a, r = evidence["p0_a"][cid], evidence["ref_a"][cid]
        metrics = {
            METRIC_FIELDS[0]: float(np.max(np.abs((np.asarray(a["task_output"]) - r["task_output"]) / s.task_scales))),
            METRIC_FIELDS[1]: abs(objective(s, desired, a["task_output"]) - objective(s, desired, r["task_output"])),
        }
        passed = all(checks[k]["status_accepted"] and checks[k]["raw_candidate_physical_pass"] and
                     checks[k]["task_output_matches_saved"] for k in ("p0_a", "ref_a", "soft"))
        passed = passed and all(metrics[k] <= METRIC_GATES[k] for k in metrics)
        records.append({"case_id": cid, "paths": checks, "stage_a_metrics": metrics, "pass": bool(passed)})
    return records


def prepare():
    from cavr_wbc.experiments.step02f_representation_audit import error_budget_spec
    if (OUT / "source_freeze_manifest.json").exists():
        raise RuntimeError("Preparation already frozen; no replacement allowed")
    assert git("rev-parse", "HEAD") == BASELINE
    assert git("branch", "--show-current").startswith("codex/")
    assert not git("diff", BASELINE, "--name-only"), "Frozen tracked baseline modified"
    protocol = read(OUT / "protocol/source_protocol_manifest.json")
    for record in protocol["protocols"]:
        assert sha(record["source_path"]) == record["sha256"]
        assert sha(OUT / "protocol" / Path(record["source_path"]).name) == record["sha256"]
    (OUT / "config.yaml").write_bytes((OLD / "config.yaml").read_bytes())
    config, snapshots, rhos, cases, evidence = context()
    config_hash = sha(OUT / "config.yaml")
    assert config_hash == read(OLD / "STEP02D_RESULT.json")["config_sha256"]
    (OUT / "config_sha256.txt").write_text(config_hash + "\n", encoding="utf-8")
    assert config["production_numerical_contract"]["internal_fixed_task_guard_fraction"] == 0.0
    assert config["objectives"]["secondary_task_fix_normalized_tolerance"] == 1e-8
    dependencies = read(OLD / "dependency_manifest.json")
    current = {key: importlib.metadata.version(key) for key in dependencies["versions"]}
    assert current == dependencies["versions"], (current, dependencies["versions"])
    assert sys.version == dependencies["python"]
    write("dependency_manifest.json", {"python": sys.version, "versions": current, "new_installs": [], "baseline_equal": True})
    ordinary = {"__".join(r[k] for k in ("snapshot_id", "health_id", "demand_id")): r["regression_id"] for r in REGRESSION_CASES}
    manifest = [{k: c[k] for k in ("case_id", "snapshot_id", "health_id", "demand_id", "task_class")} for c in cases]
    for item in manifest:
        item["original_four_regression_id"] = ordinary.get(item["case_id"])
        item["regression_member"] = item["demand_id"] == "infeasible_positive_mix" or item["case_id"] in ordinary
    regression = [c for c in manifest if c["regression_member"]]
    assert len(regression) == 36 and sum(c["demand_id"] == "infeasible_positive_mix" for c in regression) == 35
    assert set(ordinary) <= {c["case_id"] for c in regression}
    write("case_manifest.json", {"count": 245, "cases": manifest, "order": "STEP02D full_panel journal order"})
    write("regression_case_ids.json", {"count": 36, "cases": regression, "original_four_not_solved_separately": True,
        "stop_policy": "Stop after the first fully evaluated failed regression case; all remaining predeclared cases are NOT RUN, never dropped."})
    spec = {"stage": "STEP02F", "equation": "w=a+diag(R)*z", "source_coordinates": "original physical w, never already-scaled solver coefficients",
        "task_coordinates": "eight distinct exact +1 qdd selectors; task bias must be exactly zero",
        "task_a": "cached full_panel Stage-A target minus frozen bias", "task_R": "float64(1e-8 * task_scale)",
        "other_a": 0.0, "other_R": "original frozen D", "bounds": "transform actual float64 old h; never force +/-1",
        "row_rule": config["constraint_row_scaling"], "success_status": "Solved", "new_solver_paths": list(PATHS),
        "max_regression_solves": 72, "max_full_panel_solves": 490, "max_total_solves": 562,
        "retry": False, "clipping_projection": False, "e1_authorized": False}
    write("affine_transform_spec.json", spec)
    write("representation_error_budget.json", error_budget_spec())
    first = cases[0]
    settings_record = {}
    for path, route in (("production", "p0_b"), ("reference", "ref_b")):
        settings = settings_for(path, snapshots[first["snapshot_id"]], rhos[first["health_id"]], config)
        archived = {v["raw_solver"]["settings_repr"] for v in evidence[route].values()}
        assert archived == {str(settings)}, "Full/default solver settings differ from saved STEP02D"
        settings_record[path] = {"all_actual_fields_including_defaults": settings_dict(settings), "repr": str(settings), "matches_all_245_archived": True}
    write("solver_settings.json", settings_record)
    with patch("clarabel.DefaultSolver", side_effect=AssertionError("No solver in preparation")), patch("osqp.OSQP", side_effect=AssertionError("No OSQP in STEP02F")):
        certificates = cached_certificates(config, snapshots, rhos, cases, evidence)
    write("cached_evidence_audit.json", {"count": 245, "pass": all(r["pass"] for r in certificates), "records": certificates, "new_solves": 0})
    assert all(r["pass"] for r in certificates), "Cached frozen evidence gate failed"
    write("test_plan.json", {"pre_solve": "python -m cavr_wbc.experiments.step02f --phase test", "post_solve": "python -m cavr_wbc.experiments.step02f --phase replay",
        "full_representation_audit": "python -m cavr_wbc.experiments.step02f --phase audit", "execution": "python -u -m cavr_wbc.experiments.step02f --phase execute",
        "all_tests_solver_constructors_forbidden": True, "old_tests_not_rerun": True,
        "monitoring": {"process_alive": True, "progress_after_each_case": True, "hard_timeout_seconds": 1800, "advisory_stall_seconds": 90}})
    tracked = git("ls-tree", "-r", "--name-only", BASELINE).splitlines()
    frozen_files = [OUT / name for name in ("config.yaml", "case_manifest.json", "regression_case_ids.json", "affine_transform_spec.json", "representation_error_budget.json", "solver_settings.json", "dependency_manifest.json", "test_plan.json", "cached_evidence_audit.json")]
    source_files = [p for root in (Path("cavr_wbc"), Path("tests")) for p in root.rglob("*step02f*.py")]
    frozen_files += source_files + list((OUT / "protocol").glob("*"))
    write("source_freeze_manifest.json", {"baseline_commit": BASELINE, "worktree": str(Path.cwd()), "branch": git("branch", "--show-current"),
        "frozen_at_utc": datetime.now(timezone.utc).isoformat(), "config_sha256": config_hash,
        "baseline_checkout_file_sha256": {p: sha(p) for p in tracked},
        "step02f_frozen_file_sha256": {p.as_posix(): sha(p) for p in sorted(frozen_files)},
        "protocol_sources": protocol, "prior_history_must_remain_unchanged": True, "new_solves_so_far": 0})
    write("lineage.json", {"baseline": BASELINE, "prior_step02d_status": "FAIL / REVISE", "prior_step02e_preserved": True,
        "stage": "STEP02F_COORDINATE_EQUIVALENT_CERTIFICATION_AUDIT", "parent": "STEP02D_FAIL", "e1_authorized": False})
    print("PREPARED: exact frozen config; 245 full_panel cache cases; 36 unique regressions; zero new solves", flush=True)


def verify_freeze():
    freeze = read(OUT / "source_freeze_manifest.json")
    mismatches = []
    for group in ("baseline_checkout_file_sha256", "step02f_frozen_file_sha256"):
        mismatches += [p for p, expected in freeze[group].items() if not Path(p).exists() or sha(p) != expected]
    assert not mismatches, f"Frozen source/config/input changed: {mismatches}"
    assert sha(OUT / "config.yaml") == freeze["config_sha256"]
    assert all(importlib.metadata.version(k) == v for k, v in read(OUT / "dependency_manifest.json")["versions"].items())
    return freeze


def save_problem(case_index, path, problem):
    destination = OUT / "represented_problems" / f"{case_index:03d}_{path}.npz"
    destination.parent.mkdir(exist_ok=True)
    arrays = {k: np.asarray(v) for k, v in problem.items() if isinstance(v, (np.ndarray, float, int, np.floating))}
    arrays["equality_labels"] = np.asarray(problem["equality_labels"], dtype=str)
    arrays["inequality_labels"] = np.asarray(problem["inequality_labels"], dtype=str)
    np.savez_compressed(destination, **arrays)
    return {"file": destination.as_posix(), "sha256": sha(destination)}


def audit():
    from cavr_wbc.control.step02f_production import build_problem as prod
    from cavr_wbc.control.step02f_reference import build_problem as ref
    from cavr_wbc.experiments.step02f_representation_audit import audit_problem
    verify_freeze()
    assert read(OUT / "pre_solve_tests.json")["pass"]
    exclusive("representation_audit_lock.json", {"attempt": 1, "solver_calls": 0})
    config, snapshots, rhos, cases, evidence = context()
    records, problem_index = [], {}
    with patch("clarabel.DefaultSolver", side_effect=AssertionError("No solver before representation closes")), patch("osqp.OSQP", side_effect=AssertionError("No OSQP in STEP02F")):
        for index, case in enumerate(cases, 1):
            cid = case["case_id"]
            s, rho = snapshots[case["snapshot_id"]], rhos[case["health_id"]]
            problems, audits = {}, {}
            problem_index[cid] = {}
            for path, build, route in (("production", prod, "p0_a"), ("reference", ref, "ref_a")):
                target = np.asarray(evidence[route][cid]["task_output"], dtype=float)
                problem = build(s, rho, target, config)
                problems[path] = problem
                problem_index[cid][path] = save_problem(index, path, problem)
                audits[path] = audit_problem(problem, s, target)
            # This additional comparison never substitutes one path's constructor.
            compared = ("original_P", "original_q", "original_E", "original_f", "original_G", "original_h", "D", "a", "R", "P", "q", "E", "f", "G", "h", "A", "b")
            same = {key: bool(np.array_equal(problems["production"][key], problems["reference"][key])) for key in compared}
            record = {"case_id": cid, "paths": audits, "independent_paths_exact_array_comparison": same,
                "pass": bool(all(a["pass"] for a in audits.values()) and all(same.values())), "solver_calls": 0}
            records.append(record)
            append("representation_cases.jsonl", record)
            if index % 10 == 0 or index == 245:
                print(f"REPRESENTATION {index}/245 | pass={sum(r['pass'] for r in records)} | solves=0", flush=True)
    write("represented_problem_index.json", problem_index)
    passed = all(r["pass"] for r in records)
    write("represented_qp_equivalence_audit.json", {"case_count": 245, "path_audits": 490, "pass_count": sum(r["pass"] for r in records), "pass": passed,
        "case_evidence": "representation_cases.jsonl", "saved_original_and_transformed_matrices": "represented_problem_index.json",
        "solver_calls": 0, "failure_cases": [r["case_id"] for r in records if not r["pass"]]})
    write("representation_freeze.json", {"files": {p.as_posix(): sha(p) for p in (OUT / "represented_problems").glob("*.npz")},
        "index_sha256": sha(OUT / "represented_problem_index.json"), "audit_sha256": sha(OUT / "represented_qp_equivalence_audit.json"),
        "case_evidence_sha256": sha(OUT / "representation_cases.jsonl")})
    if not passed:
        finish("FAIL / REVISE", "REPRESENTATION_EQUIVALENCE_AUDIT_NOT_CLOSED")
    print(f"REPRESENTATION AUDIT {'PASS' if passed else 'FAIL'}; solver calls=0", flush=True)


def verify_representation():
    verify_freeze()
    audit = read(OUT / "represented_qp_equivalence_audit.json")
    assert audit["pass"] and audit["case_count"] == 245 and audit["path_audits"] == 490
    freeze = read(OUT / "representation_freeze.json")
    assert all(sha(p) == expected for p, expected in freeze["files"].items())
    for field, filename in (("index_sha256", "represented_problem_index.json"), ("audit_sha256", "represented_qp_equivalence_audit.json"), ("case_evidence_sha256", "representation_cases.jsonl")):
        assert sha(OUT / filename) == freeze[field]


def solve_one(case, phase, path, config, snapshot, rho, cached, problem_record):
    cid = case["case_id"]
    attempts = lines(OUT / "solve_attempt_ledger.jsonl")
    assert not any(r["phase"] == phase and r["case_id"] == cid and r["path"] == path for r in attempts)
    assert len(attempts) < 562
    assert sum(r["phase"] == phase for r in attempts) < (72 if phase == "regression" else 490)
    assert sha(problem_record["file"]) == problem_record["sha256"]
    with np.load(problem_record["file"], allow_pickle=False) as loaded:
        problem = {k: loaded[k] for k in loaded.files}
    settings = settings_for(path, snapshot, rho, config)
    frozen_settings = read(OUT / "solver_settings.json")[path]
    assert settings_dict(settings) == frozen_settings["all_actual_fields_including_defaults"]
    assert str(settings) == frozen_settings["repr"]
    ordinal = len(attempts) + 1
    identity = {"solve_ordinal": ordinal, "phase": phase, "case_id": cid, "path": path}
    append("solve_attempt_ledger.jsonl", {**identity, "event": "attempt_reserved_before_solver_construction", "utc": datetime.now(timezone.utc).isoformat()})
    target = np.asarray(cached["task_output"], dtype=float)
    raw_record = {**identity, "solver_constructed": False, "solve_called": False, "status": "NOT_RUN", "status_accepted": False}
    certificate = {**identity, "status_accepted": False, "raw_candidate_available": False, "raw_candidate_physical_pass": False, "raw_candidate_fixed_band_pass": False,
        "validation": {"available": False}, "task_output": None, "torque_regularizer": None, "frozen_accepted_witness": False}
    try:
        P, q, A, b = (problem[k] for k in ("P", "q", "A", "b"))
        neq = problem["E"].shape[0]
        cones = [clarabel.ZeroConeT(neq), clarabel.NonnegativeConeT(problem["G"].shape[0])]
        solver = clarabel.DefaultSolver(sp.triu(sp.csc_matrix(P), format="csc"), q, sp.csc_matrix(A), b, cones, settings)
        raw_record["solver_constructed"] = True
        raw_record["actual_settings_before_solve"] = settings_dict(solver.get_settings())
        assert raw_record["actual_settings_before_solve"] == frozen_settings["all_actual_fields_including_defaults"]
        raw_record["solve_called"] = True
        append("solver_call_ledger.jsonl", {**identity, "event": "solve_called_once"})
        raw = solver.solve()
        info = solver.get_info()
        x, slack, dual = (np.asarray(getattr(raw, key), dtype=float) for key in ("x", "s", "z"))
        finite = x.shape == (snapshot.decision_dimension,) and bool(np.isfinite(x).all())
        accepted = str(raw.status) == "Solved" and finite
        raw_record.update({"status": str(raw.status), "status_accepted": accepted, "z_coordinate": x, "slack": slack, "dual": dual,
            "iterations": int(raw.iterations), "solve_time_s": float(raw.solve_time), "primal_objective_without_constant": float(raw.obj_val),
            "dual_objective_without_constant": float(raw.obj_val_dual), "objective_constant": float(problem["objective_constant"]),
            "duality_gap": abs(float(raw.obj_val) - float(raw.obj_val_dual)), "solver_primal_residual": float(raw.r_prim), "solver_dual_residual": float(raw.r_dual),
            "gap_abs": float(info.gap_abs), "gap_rel": float(info.gap_rel), "actual_settings": settings_dict(solver.get_settings()),
            "kkt_primal_infinity": float(np.max(np.abs(A @ x + slack - b))),
            "kkt_stationarity_infinity": float(np.max(np.abs(P @ x + q + A.T @ dual))),
            "complementarity_infinity": float(np.max(np.abs(slack[neq:] * dual[neq:]))),
            "primal_cone_violation": float(max(0.0, -np.min(slack[neq:]))), "dual_cone_violation": float(max(0.0, -np.min(dual[neq:]))),
        })
        assert raw_record["actual_settings"] == frozen_settings["all_actual_fields_including_defaults"]
        certificate["status_accepted"] = accepted
        if finite:
            physical = problem["a"] + problem["R"] * x
            qdd = physical[:snapshot.nv]
            tau = physical[snapshot.nv:snapshot.nv+snapshot.nu]
            force = physical[snapshot.nv+snapshot.nu:]
            validation = validate_original_witness(snapshot, rho, qdd, tau, force, fixed_task_output=target)
            physics = raw_physical_pass(validation, config["validation"])
            band = validation["fixed_task_normalized_infinity_error"] <= 1e-8
            certificate.update({"raw_candidate_available": True, "raw_candidate_physical_pass": physics, "raw_candidate_fixed_band_pass": band,
                "validation": validation, "original_witness": physical, "cached_stage_a_target": target, "task_output": snapshot.task_matrix @ qdd + snapshot.task_bias,
                "torque_regularizer": float(np.sum(np.square(tau / snapshot.torque_scales))),
                "original_equality_residual": problem["original_E"] @ physical - problem["original_f"],
                "original_inequality_violation_by_row": np.maximum(problem["original_G"] @ physical - problem["original_h"], 0.0),
                "physical_primal_objective": float(0.5 * physical @ problem["original_P"] @ physical + problem["original_q"] @ physical),
                "inverse_mapping": "a + R*z once, no clipping/projection", "frozen_accepted_witness": bool(accepted and physics and band)})
    except Exception as exc:
        raw_record["exception"] = f"{type(exc).__name__}: {exc}"
        raw_record["status_accepted"] = False
        certificate["status_accepted"] = False
        certificate["frozen_accepted_witness"] = False
    append("raw_solver_diagnostics.jsonl", raw_record)
    append("original_unit_certificates.jsonl", certificate)
    return certificate


def evaluate_case(case, phase, config, snapshots, rhos, evidence, problem_index, cached_index):
    s, rho = snapshots[case["snapshot_id"]], rhos[case["health_id"]]
    cid = case["case_id"]
    cert = {}
    for path, route in (("production", "p0_a"), ("reference", "ref_a")):
        cert[path] = solve_one(case, phase, path, config, s, rho, evidence[route][cid], problem_index[cid][path])
    desired = np.asarray(next(d["y_d"] for d in config["task_demands"] if d["demand_id"] == case["demand_id"]))
    metrics = {**cached_index[cid]["stage_a_metrics"], **{name: None for name in METRIC_FIELDS[2:]}}
    raw_metrics = {name: None for name in METRIC_FIELDS[2:]}
    p, r = cert["production"], cert["reference"]
    if p["raw_candidate_available"] and r["raw_candidate_available"]:
        raw_metrics = {
            METRIC_FIELDS[2]: float(np.max(np.abs((np.asarray(p["task_output"]) - r["task_output"]) / s.task_scales))),
            METRIC_FIELDS[3]: abs(objective(s, desired, p["task_output"]) - objective(s, desired, r["task_output"])),
            METRIC_FIELDS[4]: abs(p["torque_regularizer"] - r["torque_regularizer"]),
        }
        if p["status_accepted"] and r["status_accepted"]:
            metrics.update(raw_metrics)
    eq = _equivalence_pass(metrics, config["validation"])
    row = {**case, "phase": phase, "all_frozen_gate_metrics": metrics, "diagnostic_raw_stage_b_comparison": raw_metrics,
        "metric_pass": {key: value is not None and value <= METRIC_GATES[key] for key, value in metrics.items()},
        "metric_sources": {key: "STEP02D full_panel cached Stage-A" if key in METRIC_FIELDS[:2] else "STEP02F new Stage-B" for key in METRIC_FIELDS},
        "cached_stage_a_b1soft_pass": cached_index[cid]["pass"], "equivalence_pass": eq,
        "paths": {path: {k: cert[path][k] for k in ("status_accepted", "raw_candidate_available", "raw_candidate_physical_pass", "raw_candidate_fixed_band_pass", "frozen_accepted_witness")} for path in PATHS},
        "final_case_pass": bool(eq and cached_index[cid]["pass"] and all(c["frozen_accepted_witness"] for c in cert.values())),
        "old_step02d_case_pass": next(c["case_pass"] for c in lines(OLD / "full_panel_cases_journal.jsonl") if c["case_id"] == cid)}
    append(f"{phase}_cases.jsonl", row)
    return row


def execute():
    verify_representation()
    assert read(OUT / "pre_solve_tests.json")["pass"]
    exclusive("execution_lock.json", {"attempt": 1, "config_sha256": sha(OUT / "config.yaml"), "started_utc": datetime.now(timezone.utc).isoformat()})
    config, snapshots, rhos, _, evidence = context()
    regressions = read(OUT / "regression_case_ids.json")["cases"]
    problem_index = read(OUT / "represented_problem_index.json")
    cached_index = {r["case_id"]: r for r in read(OUT / "cached_evidence_audit.json")["records"]}
    start = time.monotonic()
    for index, case in enumerate(regressions, 1):
        if time.monotonic() - start > 1800:
            finish("FAIL / REVISE", "HARD_TIMEOUT_BEFORE_NEXT_CASE")
            return
        row = evaluate_case(case, "regression", config, snapshots, rhos, evidence, problem_index, cached_index)
        print(f"REGRESSION {index}/36 | {case['case_id']} | pass={row['final_case_pass']} | calls={len(lines(OUT/'solver_call_ledger.jsonl'))}", flush=True)
        if not row["final_case_pass"]:
            finish("FAIL / REVISE", "REGRESSION_FROZEN_GATE_FAILURE")
            return
    verify_representation()
    exclusive("full_panel_execution_lock.json", {"status": "STARTED", "attempt": 1, "config_sha256": sha(OUT / "config.yaml"), "authorized_by": "36/36 regression gate"})
    for index, case in enumerate(read(OUT / "case_manifest.json")["cases"], 1):
        if time.monotonic() - start > 1800:
            finish("FAIL / REVISE", "HARD_TIMEOUT_BEFORE_NEXT_CASE")
            return
        row = evaluate_case(case, "full_panel", config, snapshots, rhos, evidence, problem_index, cached_index)
        print(f"FULL PANEL {index}/245 | pass={row['final_case_pass']} | calls={len(lines(OUT/'solver_call_ledger.jsonl'))}", flush=True)
    rows = lines(OUT / "full_panel_cases.jsonl")
    passed = len(rows) == 245 and all(r["final_case_pass"] for r in rows)
    finish("PASS" if passed else "FAIL / REVISE", "FROZEN_DEV_STAGE_B_IMPLEMENTATION_PASS" if passed else "FULL_PANEL_FROZEN_GATE_FAILURE")


def run_tests(replay=False):
    verify_freeze()
    pattern = "test_step02f_replay.py" if replay else "test_step02f_representation.py"
    stream = io.StringIO()
    with patch("clarabel.DefaultSolver", side_effect=AssertionError("Tests cannot construct an optimizer")), patch("osqp.OSQP", side_effect=AssertionError("Tests cannot construct OSQP")):
        suite = unittest.defaultTestLoader.discover("tests", pattern=pattern)
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    name = "saved_evidence_replay_tests" if replay else "pre_solve_tests"
    (OUT / f"{name}.txt").write_text(stream.getvalue(), encoding="utf-8")
    write(f"{name}.json", {"command": f"python -m cavr_wbc.experiments.step02f --phase {'replay' if replay else 'test'}",
        "tests_run": result.testsRun, "failures": len(result.failures), "errors": len(result.errors), "skipped": len(result.skipped),
        "pass": result.wasSuccessful() and result.testsRun > 0 and not result.skipped, "solver_calls": 0,
        "solver_constructors_mocked_forbidden": True, "old_experiments_rerun": False})
    print(stream.getvalue(), flush=True)
    if not result.wasSuccessful() or result.testsRun == 0 or result.skipped:
        raise RuntimeError("No-solve test gate failed")


def scope_results(phase, manifest):
    rows = lines(OUT / f"{phase}_cases.jsonl")
    byid = {r["case_id"]: r for r in rows}
    return {"planned_cases": len(manifest), "executed_cases": len(rows), "passing_cases": sum(r["final_case_pass"] for r in rows),
        "status": "NOT RUN" if not rows else "COMPLETE" if len(rows) == len(manifest) else "STOPPED",
        "cases": [byid.get(c["case_id"], {**c, "phase": phase, "execution_status": "NOT RUN", "final_case_pass": None}) for c in manifest]}


def finish(status, classification):
    frozen = verify_freeze()
    regression = scope_results("regression", read(OUT / "regression_case_ids.json")["cases"])
    panel = scope_results("full_panel", read(OUT / "case_manifest.json")["cases"])
    write("regression_results.json", regression)
    write("full_panel_results.json", panel)
    if not (OUT / "full_panel_execution_lock.json").exists():
        exclusive("full_panel_execution_lock.json", {"status": "NOT RUN", "attempts": 0, "reason": classification})
    diagnostics = lines(OUT / "raw_solver_diagnostics.jsonl")
    attempts = lines(OUT / "solve_attempt_ledger.jsonl")
    calls = lines(OUT / "solver_call_ledger.jsonl")
    certs = lines(OUT / "original_unit_certificates.jsonl")
    table = []
    for phase, scope in (("regression", regression), ("full_panel", panel)):
        for case in scope["cases"]:
            for path in PATHS:
                cert = next((c for c in certs if c["phase"] == phase and c["case_id"] == case["case_id"] and c["path"] == path), None)
                raw = next((c for c in diagnostics if c["phase"] == phase and c["case_id"] == case["case_id"] and c["path"] == path), None)
                execution = "NOT RUN" if raw is None else "RUN" if raw["solve_called"] else "ATTEMPTED_NO_SOLVE"
                table.append({"phase": phase, "case_id": case["case_id"], "path": path, "execution": execution,
                    "solver_status": raw["status"] if raw else "NOT RUN", **{k: cert[k] if cert else None for k in ("status_accepted", "raw_candidate_physical_pass", "raw_candidate_fixed_band_pass")},
                    **{k: case.get("all_frozen_gate_metrics", {}).get(k) for k in METRIC_FIELDS},
                    "final_case_pass": case["final_case_pass"]})
    _write_csv(OUT / "status_physics_band_ledger.csv", table)
    audit = read(OUT / "represented_qp_equivalence_audit.json") if (OUT / "represented_qp_equivalence_audit.json").exists() else {"status": "NOT RUN"}
    result = {"stage": "STEP02F", "status": status, "classification": classification, "baseline_commit": BASELINE,
        "worktree": str(Path.cwd()), "branch": frozen["branch"], "config_sha256": frozen["config_sha256"],
        "representation_audit": audit, "regression": {k: v for k, v in regression.items() if k != "cases"},
        "full_panel": {k: v for k, v in panel.items() if k != "cases"},
        "actual_solver_calls": len(calls), "reserved_attempts": len(attempts), "solver_constructions": sum(r["solver_constructed"] for r in diagnostics),
        "calls_by_phase": dict(Counter(r["phase"] for r in calls)), "statuses_by_path": {p: dict(Counter(r["status"] for r in diagnostics if r["path"] == p)) for p in PATHS},
        "stage_a_new_solves": 0, "b1_soft_new_solves": 0, "osqp_new_solves": 0, "cached_evidence_audit_pass": read(OUT / "cached_evidence_audit.json")["pass"],
        "prior_history_and_frozen_sources_unchanged": True, "tests": {name: read(OUT / f"{name}.json") if (OUT / f"{name}.json").exists() else "NOT RUN" for name in ("pre_solve_tests", "saved_evidence_replay_tests")},
        "e1_authorized": False, "e1_executed": False, "old_experiments_rerun": False,
        "result_commit": "See delivery Git commit; self-referential commit hashes are intentionally not embedded."}
    write("STEP02F_RESULT.json", result)
    report = ["## Material Passport", "", "- Origin Skill: experiment-agent", "- Origin Mode: run", "- Origin Date: 2026-09-18, Asia/Seoul",
        "- Verification Status: ANALYZED (gated numerical implementation audit; not a re-run of all prior experiments)", "- Version Label: step02f_coordinate_equivalence_v1", "",
        "# STEP-02F — Coordinate-Equivalent Certification Audit", "", f"**{status}** — `{classification}`", "",
        f"Baseline: `{BASELINE}`. Branch: `{frozen['branch']}`.", f"Worktree: `{Path.cwd()}`.",
        f"Frozen configuration SHA256: `{frozen['config_sha256']}` (byte-identical STEP-02D scientific/solver configuration).", "",
        "## Scope and gate outcomes", "", f"- Representation audit: {audit.get('pass_count', 0)}/245 cases; {audit.get('path_audits', 0)} independently assembled path audits; optimizer calls 0.",
        f"- Regression: {regression['status']}; executed {regression['executed_cases']}/36, passed {regression['passing_cases']}. Original four are members, not extra solves.",
        f"- Full panel: {panel['status']}; executed {panel['executed_cases']}/245, passed {panel['passing_cases']}.",
        f"- Actual new Stage-B solver calls: {len(calls)}; reserved attempts {len(attempts)}; maximum 562. No retries.",
        "- Stage-A, B1-soft and OSQP Stage-A: cached STEP-02D full_panel evidence only; new solves 0. All 245 cached primary/soft physical certificates rechecked.",
        "- State acceptance, diagnostic raw-candidate physics, literal fixed band, five equivalence metrics and final case decision are separate in the ledger.", "",
        "## Representation evidence", "", "Production and reference retain separate original physical assemblies and independent affine construction. The only candidate is w=a+diag(R)z, with the eight selector scales 1e-8 times task scale. Existing physical variable scales are used once for non-task coordinates; original row normalization is recomputed on transformed rows. Actual rounded old bounds are transformed, never replaced by +/-1. Equality RHS remainders and all objective terms/constants are retained.", "",
        "`representation_error_budget.json` fixes input/operation roundoff budgets before audit/optimization. `representation_cases.jsonl` records each row/target check; `represented_problems/*.npz` preserve original/transformed arrays, scales and inverse map. These assembly budgets do not relax any original-unit witness gate.", "",
        "## Failed case evidence", ""]
    for case in regression["cases"] + panel["cases"]:
        if case["final_case_pass"] is False:
            report.append(f"- {case['phase']} / `{case['case_id']}`: paths={case['paths']}; equivalence={case['equivalence_pass']}.")
    report += ["", "Rejected raw candidates remain diagnostics only, including AlmostSolved; no clipping, projection, guard, tolerance changes or fallback representation is permitted. Solver residuals/gaps/KKT and original physical residuals are stored separately. Finite DEV numerical agreement is not a deployment probability, superiority or recoverability result. STEP-02D remains FAIL.", "",
        "## Tests and provenance", "", "The test plan, command/results and complete logs are saved. All new tests forbid optimizer construction. Old solving tests were NOT RUN. Frozen baseline files and all protocol/configuration/implementation hashes are rechecked before execution and report. The original workspace and its uncommitted audit/handoff directories are not modified.", "",
        "Result commit and final Git status are supplied in the delivery message and handoff metadata. No automatic E1 or alternative strategy follows this stage.", "", "E1_AUTHORIZED = FALSE", ""]
    (OUT / "STEP02F_REPORT.md").write_text("\n".join(report), encoding="utf-8")
    print(f"FINAL {status}: {classification}; actual solves={len(calls)}; E1_AUTHORIZED = FALSE", flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", required=True, choices=("prepare", "test", "audit", "execute", "replay", "report"))
    args = parser.parse_args()
    if args.phase == "prepare":
        prepare()
    elif args.phase == "test":
        run_tests()
    elif args.phase == "audit":
        audit()
    elif args.phase == "execute":
        execute()
    elif args.phase == "replay":
        run_tests(True)
    else:
        old = read(OUT / "STEP02F_RESULT.json")
        finish(old["status"], old["classification"])


if __name__ == "__main__":
    main()
