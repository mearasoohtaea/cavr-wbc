"""Summarize completed STEP-02F representation evidence; no optimizer imports.

Only saved JSON/JSONL is read. This report neither recomputes optimization nor
changes an assembly error budget or original-unit candidate acceptance gate.
"""

from __future__ import annotations

import argparse
from collections import Counter
from fractions import Fraction
import hashlib
import json
from pathlib import Path
from typing import Any


DEFAULT_ROOT = Path("artifacts/step02f_coordinate_equivalence")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _read(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def _new_stats() -> dict[str, Any]:
    return {
        "checks": 0, "passes": 0, "coefficients": 0,
        "max_absolute_error": 0.0, "max_predeclared_bound": 0.0,
        "max_error_to_bound_ratio": 0.0,
        "max_absolute_error_location": None, "max_bound_location": None,
        "max_ratio_location": None,
    }


def _update(stats: dict[str, Any], check: dict[str, Any], location: dict) -> None:
    stats["checks"] += 1
    stats["passes"] += int(check.get("pass", False))
    stats["coefficients"] += int(check.get("coefficient_count", 0))
    for source, location_key in (
        ("max_absolute_error", "max_absolute_error_location"),
        ("max_predeclared_bound", "max_bound_location"),
        ("max_error_to_bound_ratio", "max_ratio_location"),
    ):
        value = float(check.get(source, 0.0))
        if stats[location_key] is None or value > stats[source]:
            stats[source] = value
            stats[location_key] = dict(location)
            if source == "max_error_to_bound_ratio":
                stats[location_key]["coefficient_index"] = check.get("worst_index")
                stats[location_key]["predeclared_bound_exact"] = check.get("worst_predeclared_bound")


def _ratio(error: Fraction, bound: Fraction) -> float:
    if not bound:
        if error:
            raise ValueError("Saved evidence has nonzero error with zero bound")
        return 0.0
    return float(error / bound)


def _identity_check(record: dict[str, Any]) -> dict[str, Any]:
    if "per_row_absolute_error" in record:
        errors = record["per_row_absolute_error"]
        bounds = record["per_row_predeclared_bound"]
        if len(errors) != len(bounds):
            raise ValueError("Saved identity error/bound dimensions differ")
        ratios = [_ratio(Fraction.from_float(float(e)), Fraction.from_float(float(b)))
                  for e, b in zip(errors, bounds)]
        worst = max(range(len(ratios)), key=ratios.__getitem__) if ratios else None
        return {
            "pass": record["pass"], "coefficient_count": len(errors),
            "max_absolute_error": max(errors, default=0.0),
            "max_predeclared_bound": max(bounds, default=0.0),
            "max_error_to_bound_ratio": max(ratios, default=0.0),
            "worst_index": [worst] if worst is not None else None,
            "ratio_source": "saved float64 summaries of exact-rational identity errors/bounds",
        }
    error, bound = Fraction(record["absolute_error_exact"]), Fraction(record["predeclared_bound_exact"])
    return {
        "pass": record["pass"], "coefficient_count": 1,
        "max_absolute_error": float(error), "max_predeclared_bound": float(bound),
        "max_error_to_bound_ratio": _ratio(error, bound),
        "worst_index": [], "worst_predeclared_bound": str(bound),
    }


def summarize(root: Path) -> dict[str, Any]:
    """Require completed, hash-frozen evidence, then stream all case records."""
    root = root.resolve()
    evidence_path = root / "representation_cases.jsonl"
    audit_path = root / "represented_qp_equivalence_audit.json"
    budget_path = root / "representation_error_budget.json"
    freeze_path = root / "representation_freeze.json"
    audit, budget, freeze = _read(audit_path), _read(budget_path), _read(freeze_path)
    if audit.get("case_count") != 245 or audit.get("path_audits") != 490:
        raise ValueError("Completed 245-case / 490-path representation audit required")
    input_hashes = {path.name: _sha256(path) for path in (evidence_path, audit_path, budget_path, freeze_path)}
    if freeze["case_evidence_sha256"] != input_hashes[evidence_path.name]:
        raise ValueError("Completed representation evidence hash mismatch")
    if freeze["audit_sha256"] != input_hashes[audit_path.name]:
        raise ValueError("Completed representation audit hash mismatch")

    families: dict[str, dict] = {}
    maps = {key: _new_stats() for key in ("forward", "inverse_round_trip")}
    identities = {key: _new_stats() for key in ("E", "G", "objective")}
    cases: set[str] = set()
    path_counts: Counter = Counter()
    pass_counts: Counter = Counter()
    exact_comparison_counts: Counter = Counter()
    layer_counts: Counter = Counter()
    side_stats = _new_stats()
    normalized_distances: list[float] = []
    z_distances: list[float] = []
    inverse_preservation_error = 0.0
    inverse_preservation_location = None
    coefficients = 0
    equality_nonzero_min = None
    equality_nonzero_max = 0
    reported_solver_calls = 0
    failed_cases = []
    with evidence_path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            case = json.loads(line)
            case_id = case["case_id"]
            if case_id in cases:
                raise ValueError(f"Duplicate case in saved evidence: {case_id}")
            cases.add(case_id)
            reported_solver_calls += int(case.get("solver_calls", 0))
            pass_counts["case_pass"] += int(case["pass"])
            if not case["pass"]:
                failed_cases.append(case_id)
            for family, passed in case["independent_paths_exact_array_comparison"].items():
                exact_comparison_counts[family] += int(passed)
            if set(case["paths"]) != {"production", "reference"}:
                raise ValueError(f"Saved evidence lacks two paths: {case_id}")
            for path, record in case["paths"].items():
                path_counts[path] += 1
                pass_counts[path] += int(record["pass"])
                location = {"case_id": case_id, "path": path, "jsonl_line": line_number}
                reported_solver_calls += int(record.get("solver_calls", 0))
                coefficients += int(record.get("coefficient_count_checked", 0))
                count = int(record.get("shifted_equality_rhs_nonzero_count", 0))
                equality_nonzero_min = count if equality_nonzero_min is None else min(equality_nonzero_min, count)
                equality_nonzero_max = max(equality_nonzero_max, count)
                for family, check in record.get("coefficient_checks", {}).items():
                    _update(families.setdefault(family, _new_stats()), check, location)
                for vector in record.get("deterministic_vector_checks", []):
                    vector_location = {**location, "vector_id": vector["vector_id"]}
                    for key in maps:
                        _update(maps[key], vector[key], vector_location)
                    for key in identities:
                        _update(identities[key], _identity_check(vector["identities"][key]), vector_location)
                layers = record.get("task_contract_encoding_layers", [])
                if len(layers) != 8:
                    raise ValueError(f"Expected eight saved task layers: {case_id}/{path}")
                layer_counts["task_coordinate_records"] += len(layers)
                for layer in layers:
                    for side, bound in layer["sides"].items():
                        where = {**location, "task_index": layer["task_index"], "side": side}
                        layer_counts["task_side_records"] += 1
                        layer_counts["old_encoding_within_predeclared_bound"] += int(bound["old_encoding_within_bound"])
                        expected = bool(bound["expected_old_contract_encoding_roundoff"])
                        literal_outside = not bound["inverse_endpoint_within_literal_contract"]
                        binary_outside = not bound["inverse_endpoint_within_binary64_gate_exact_evaluation"]
                        layer_counts["expected_old_contract_encoding_roundoff"] += int(expected)
                        layer_counts["inverse_endpoint_outside_literal_contract"] += int(literal_outside)
                        layer_counts["inverse_endpoint_outside_binary64_gate_exact_evaluation"] += int(binary_outside)
                        layer_counts["outside_literal_with_expected_bounded_old_roundoff"] += int(literal_outside and expected)
                        layer_counts["outside_binary64_with_expected_bounded_old_roundoff"] += int(binary_outside and expected)
                        old_error = Fraction(bound["old_encoding_error_exact"])
                        old_budget = Fraction.from_float(float(bound["old_encoding_predeclared_bound"]))
                        _update(side_stats, {
                            "pass": bound["old_encoding_within_bound"], "coefficient_count": 1,
                            "max_absolute_error": float(old_error), "max_predeclared_bound": float(old_budget),
                            "max_error_to_bound_ratio": _ratio(old_error, old_budget),
                        }, where)
                        old_endpoint = Fraction(bound["old_encoded_rhs_exact"]) * (1 if side == "upper" else -1)
                        new_endpoint = Fraction(bound["inverse_endpoint_exact"])
                        preservation_error = abs(new_endpoint - old_endpoint)
                        layer_counts["new_inverse_endpoint_exactly_preserves_old_encoded_endpoint"] += int(preservation_error == 0)
                        if inverse_preservation_location is None or float(preservation_error) > inverse_preservation_error:
                            inverse_preservation_error = float(preservation_error)
                            inverse_preservation_location = where
                        normalized_distances.append(float(Fraction(bound["inverse_normalized_distance_exact"])))
                        z_distances.append(abs(float(Fraction(bound["new_z_endpoint_exact"]))))

    if len(cases) != 245 or dict(path_counts) != {"production": 245, "reference": 245}:
        raise ValueError("Incomplete streamed representation evidence")
    if reported_solver_calls != 0:
        raise ValueError("Representation evidence unexpectedly reports optimizer calls")
    # Detect concurrent changes: only a stable completed archive is summarized.
    if _sha256(evidence_path) != input_hashes[evidence_path.name]:
        raise ValueError("Representation evidence changed during summary")
    return {
        "stage": "STEP02F_REPRESENTATION_AUDIT_SAVED_DATA_SUMMARY",
        "case_count": len(cases), "path_audit_count": sum(path_counts.values()),
        "path_counts": dict(path_counts), "pass_counts": dict(pass_counts),
        "audit_pass": bool(audit["pass"]), "failed_cases": failed_cases,
        "coefficient_count_checked": coefficients,
        "coefficient_family_summary": families,
        "deterministic_maps": maps, "deterministic_identities": identities,
        "independent_exact_array_comparison_pass_counts": dict(exact_comparison_counts),
        "shifted_equality_rhs_nonzero_count_range": [equality_nonzero_min, equality_nonzero_max],
        "task_four_layer_summary": {
            "contract_normalized_band_exact": "1/100000000",
            "binary64_gate_exact": str(Fraction.from_float(1e-8)),
            "counts": dict(layer_counts), "old_encoding_errors": side_stats,
            "new_absolute_z_endpoint_range": [min(z_distances), max(z_distances)],
            "inverse_normalized_endpoint_distance_range": [min(normalized_distances), max(normalized_distances)],
            "new_inverse_vs_old_encoded_endpoint_max_absolute_difference": inverse_preservation_error,
            "new_inverse_vs_old_encoded_endpoint_worst_location": inverse_preservation_location,
            "interpretation": "Bounded old float64 endpoint rounding is not a genuine represented-QP contradiction. It never excuses a candidate failing the unchanged literal original-unit band gate.",
        },
        "predeclared_error_budget": budget,
        "assembly_budget_is_not_validation_relaxation": True,
        "summary_solver_imports": 0, "summary_solver_calls": 0,
        "reported_representation_solver_calls": reported_solver_calls,
        "scope": "Saved-data aggregation only; does not change stage result or authorize optimization/E1.",
        "input_sha256": input_hashes,
        "report_script": str(Path(__file__).resolve()),
        "report_script_sha256": _sha256(Path(__file__)),
        "ratio_notes": "Coefficient ratios are recorded exact-rational checks. E/G identity and old-bound ratios use saved float summaries; raw exact rational evidence remains authoritative. Max-error, max-bound and max-ratio columns may refer to different entries.",
        "E1_AUTHORIZED": False,
    }


def _table(stats: dict[str, dict]) -> list[str]:
    lines = ["| Family | Passed checks | Maximum absolute error | Maximum bound | Maximum error/bound |",
             "|---|---:|---:|---:|---:|"]
    for key, row in stats.items():
        lines.append(f"| {key} | {row['passes']}/{row['checks']} | {row['max_absolute_error']:.8e} | {row['max_predeclared_bound']:.8e} | {row['max_error_to_bound_ratio']:.8f} |")
    return lines


def _markdown(summary: dict) -> str:
    layers = summary["task_four_layer_summary"]
    counts = layers["counts"]
    lines = [
        "# STEP-02F representation audit: saved-data summary", "",
        f"Representation audit {'PASS' if summary['audit_pass'] else 'FAIL'}: {summary['pass_counts']['case_pass']}/245 cases; "
        f"{summary['pass_counts']['production'] + summary['pass_counts']['reference']}/490 independent path audits. "
        f"{summary['coefficient_count_checked']:,} encoded coefficients checked. This report imports/calls no optimizer and performs no experiment.", "",
        "## Coefficient-level error budgets", "",
        "All bounds were declared before solving from binary64 unit roundoff and operation counts. "
        "These assembly budgets do not relax the original physical or fixed-task acceptance gates. "
        "Columns report independent maxima; their maxima need not share a coefficient. Locations are preserved in the JSON summary.", "",
        *_table(summary["coefficient_family_summary"]), "",
        "## Deterministic coordinate and identity checks", "",
        *_table({**summary["deterministic_maps"], **{f'identity_{key}': value for key, value in summary["deterministic_identities"].items()}}), "",
        f"Nonzero shifted equality RHS entries per represented problem: {summary['shifted_equality_rhs_nonzero_count_range']}. No equality remainder is replaced by zero.", "",
        "## Eight-task contract and represented endpoints", "",
        f"The four layers comprise the exact normalized contract 1/100000000, old float64 encoded task bounds, transformed encoded bounds, and inverse-mapped original-unit endpoints. "
        f"The archive contains {counts['task_coordinate_records']} task-coordinate records and {counts['task_side_records']} side bounds across the 490 paths.", "",
        f"- Old encoding within its predeclared bound: {counts['old_encoding_within_predeclared_bound']}/{counts['task_side_records']}.",
        f"- Inverse endpoints exactly preserving the old encoded endpoint: {counts['new_inverse_endpoint_exactly_preserves_old_encoded_endpoint']}/{counts['task_side_records']}; maximum difference {layers['new_inverse_vs_old_encoded_endpoint_max_absolute_difference']:.8e}.",
        f"- Absolute transformed z endpoint range: {layers['new_absolute_z_endpoint_range']}. Actual rounded bounds are retained rather than forced to +/-1.",
        f"- Inverse normalized endpoint distance range: {layers['inverse_normalized_endpoint_distance_range']}.",
        f"- Endpoints outside the exact decimal contract: {counts['inverse_endpoint_outside_literal_contract']}; accompanied by expected bounded old rounding: {counts['outside_literal_with_expected_bounded_old_roundoff']}.",
        f"- Endpoints outside exact evaluation against the binary64 1e-8 gate: {counts['inverse_endpoint_outside_binary64_gate_exact_evaluation']}; accompanied by expected bounded old rounding: {counts['outside_binary64_with_expected_bounded_old_roundoff']}.", "",
        "Bounded endpoint encoding roundoff is reported separately from a genuine represented-QP contradiction. "
        "It does not accept any candidate outside the unchanged literal original-unit fixed-band gate, including candidates located at an encoded endpoint. "
        "This report makes no solver-convergence, stage-PASS, superiority or recoverability claim.", "",
        "## Provenance", "",
        f"Reporting script SHA256: `{summary['report_script_sha256']}`.", "",
        *[f"- `{name}`: `{digest}`" for name, digest in summary["input_sha256"].items()], "",
        summary["ratio_notes"], "", "E1_AUTHORIZED = FALSE", "",
    ]
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=DEFAULT_ROOT)
    args = parser.parse_args()
    summary = summarize(args.root)
    output = args.root.resolve()
    (output / "representation_error_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")
    (output / "REPRESENTATION_AUDIT_SUMMARY.md").write_text(_markdown(summary), encoding="utf-8")
    print(json.dumps({"case_count": summary["case_count"], "path_audit_count": summary["path_audit_count"],
                      "audit_pass": summary["audit_pass"], "solver_calls": 0}))


if __name__ == "__main__":
    main()
