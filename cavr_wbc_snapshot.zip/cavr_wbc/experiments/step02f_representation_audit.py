"""Exact-rational, solver-free audit of STEP-02F floating-point representation.

Error budgets use only binary64 unit roundoff and operation counts. Exact
Fraction references preserve every frozen input bit and need no fitted
tolerance or arbitrary Decimal truncation allowance.
"""

from __future__ import annotations

from fractions import Fraction
from functools import lru_cache
import hashlib

import numpy as np

U = Fraction(1, 2**53)
ZERO = Fraction(0)
HALF = Fraction(1, 2)


def gamma(k):
    return k * U / (1 - k * U)


def error_budget_spec() -> dict:
    return {
        "reference_arithmetic": "exact rational Fraction.from_float; no decimal truncation",
        "unit_roundoff": "2^-53",
        "gamma_k": "k*u/(1-k*u)",
        "predeclared_before_solves": True,
        "coefficient_product": "gamma(1)*abs(exact product)",
        "hessian_two_products": "gamma(2)*abs(R_i*P_ij*R_j)",
        "shifted_rhs": "gamma(2*n+1)*(abs(rhs_i)+sum_j abs(A_ij*a_j))",
        "task_selector_shifted_rhs": "gamma(1)*abs(old_h_i-sign*target_i); multiplication by +/-1 and summing exact zeros are exact, leaving one subtraction",
        "linear_objective": "gamma(2*n+2)*abs(R_i)*(abs(q_i)+sum_j abs(P_ij*a_j))",
        "objective_constant": "gamma(4*n*n+4*n+3)*(0.5*sum_ij abs(a_i*P_ij*a_j)+sum_i abs(q_i*a_i))",
        "row_scale": "gamma(1)*abs(1/max(abs(actual rounded row),abs(actual rounded rhs)))",
        "final_row_products": "gamma(1)*abs(actual row scale*actual rounded coefficient or rhs)",
        "original_task_bound": "gamma(3)*(abs(target_i)+abs(decimal(1e-8)*task_scale_i)); includes binary literal conversion, product and addition",
        "inverse_map": "gamma(2)*(abs(a_i)+abs(R_i*z_i))",
        "round_trip": "forward_bound/abs(R_i)+gamma(2)*(abs(w_float_i)+abs(a_i))/abs(R_i)",
        "deterministic_identities": "sum of predeclared coefficient absolute-error bounds weighted by exact test-vector magnitudes",
        "arithmetic_assumptions": "finite binary64 normal values or exact zeros; unsupported subnormal/overflow stops audit",
        "normal_underflow_policy": "stop if nonzero inputs/outputs or nonzero exact transformed coefficients are below binary64 minimum normal",
        "literal_original_unit_fixed_band_gate": 1e-8,
        "assembly_budgets_do_not_modify_candidate_gate": True,
        "expected_contract_encoding_roundoff_is_not_a_feasible_set_repair": True,
    }


@lru_cache(maxsize=131072)
def F(value):
    return Fraction.from_float(float(value))


def _array(value):
    a = np.asarray(value, dtype=float)
    return np.array([F(v) for v in a.flat], dtype=object).reshape(a.shape)


def _dot(a, b):
    return sum((x * y for x, y in zip(a, b) if x and y), ZERO)


def _scale_columns(matrix, diagonal):
    return np.array([[x * r if x else ZERO for x, r in zip(row, diagonal)] for row in matrix], dtype=object)


def _check(actual, expected, budget):
    observed = _array(actual)
    expected, budget = np.asarray(expected, dtype=object), np.asarray(budget, dtype=object)
    if observed.shape != expected.shape or observed.shape != budget.shape:
        return {"pass": False, "reason": "SHAPE_MISMATCH", "actual_shape": list(observed.shape), "expected_shape": list(expected.shape)}
    worst = None
    maximum_error = ZERO
    maximum_budget = ZERO
    maximum_ratio = ZERO
    failures = []
    expectation_hash = hashlib.sha256()
    normal = F(np.finfo(float).tiny)
    unsupported = []
    for index in np.ndindex(observed.shape):
        value, want, limit = observed[index], expected[index], budget[index]
        error = abs(value - want)
        expectation_hash.update((str(want) + "\n").encode("ascii"))
        if want and abs(want) < normal:
            unsupported.append(list(index))
        ratio = error / limit if limit else (ZERO if not error else Fraction(10**100))
        if worst is None or ratio > maximum_ratio:
            maximum_ratio, worst = ratio, index
        maximum_error, maximum_budget = max(maximum_error, error), max(maximum_budget, limit)
        if error > limit:
            failures.append({"index": list(index), "exact_expected": str(want), "actual_exact": str(value), "absolute_error": str(error), "predeclared_bound": str(limit)})
    return {
        "pass": not failures and not unsupported,
        "shape": list(observed.shape), "coefficient_count": int(observed.size),
        "max_absolute_error": float(maximum_error), "max_predeclared_bound": float(maximum_budget),
        "max_error_to_bound_ratio": float(maximum_ratio),
        "worst_index": list(worst) if worst is not None else None,
        "worst_exact_expected": str(expected[worst]) if worst is not None else None,
        "worst_observed_exact": str(observed[worst]) if worst is not None else None,
        "worst_predeclared_bound": str(budget[worst]) if worst is not None else None,
        "exact_expected_rational_sha256": expectation_hash.hexdigest(),
        "failures": failures, "unsupported_subnormal_expected_indices": unsupported,
    }


def audit_problem(problem, snapshot, target) -> dict:
    """Check every actual encoded coefficient, scale, bound and affine map."""
    try:
        return _audit_problem(problem, snapshot, target)
    except (ValueError, ArithmeticError, KeyError, IndexError) as exc:
        return {"pass": False, "classification": "REPRESENTED_QP_CONTRACT_MISMATCH", "reason": str(exc), "solver_calls": 0}


def _audit_problem(p, snapshot, target):
    keys = ("original_P", "original_q", "original_E", "original_f", "original_G", "original_h", "D", "a", "R", "P", "q", "E", "f", "G", "h", "A", "b", "equality_row_scales", "inequality_row_scales", "legacy_A", "legacy_b", "legacy_P", "legacy_q", "legacy_equality_row_scales", "legacy_inequality_row_scales", "objective_constant")
    for key in keys:
        values = np.asarray(p[key], dtype=float)
        if not np.isfinite(values).all() or np.any((values != 0) & (np.abs(values) < np.finfo(float).tiny)):
            raise ValueError("nonfinite/subnormal unsupported input/output: " + key)
    n = snapshot.decision_dimension
    selectors = np.argmax(snapshot.task_matrix, axis=1)
    expected_selector = np.zeros_like(snapshot.task_matrix)
    if snapshot.task_dimension != 8 or len(set(selectors)) != 8:
        raise ValueError("task dimension/selector uniqueness")
    expected_selector[np.arange(8), selectors] = 1
    if not np.array_equal(snapshot.task_matrix, expected_selector) or np.any(snapshot.task_bias):
        raise ValueError("task is not eight distinct unit selectors with zero bias")
    target = np.asarray(target, dtype=float)
    if target.shape != (8,) or not np.isfinite(target).all():
        raise ValueError("target shape/finite")
    a_expected = np.zeros(n)
    a_expected[selectors] = target
    d_expected = np.concatenate((np.ones(3), np.full(3, 2.0), np.full(snapshot.nv - 6, 10.0), snapshot.torque_scales, np.full(snapshot.nlambda, snapshot.normal_force_upper[0])))
    if not np.array_equal(p["D"], d_expected):
        raise ValueError("legacy variable scales differ from frozen physical scales")
    r_expected = np.asarray(p["D"]).copy()
    r_expected[selectors] = 1e-8 * snapshot.task_scales
    if not np.array_equal(p["a"], a_expected) or not np.array_equal(p["R"], r_expected) or np.any(np.asarray(p["R"]) <= 0):
        raise ValueError("affine origin or scale differs from sole authorized rule")
    if len(p["equality_labels"]) != snapshot.nv + snapshot.nlambda or len(p["inequality_labels"]) != 2 * snapshot.nu + 6 * len(snapshot.foot_names) + 16:
        raise ValueError("constraint rows removed or added")
    Q, c = _array(p["original_P"]), _array(p["original_q"])
    E, f, G, h, a, R, D = (_array(p[key]) for key in ("original_E", "original_f", "original_G", "original_h", "a", "R", "D"))
    original_tau_only = np.zeros((n, n))
    tau_indices = np.arange(snapshot.nv, snapshot.nv + snapshot.nu)
    original_tau_only[tau_indices, tau_indices] = np.asarray(p["original_P"])[tau_indices, tau_indices]
    if not np.array_equal(p["original_P"], original_tau_only) or np.any(np.asarray(p["original_q"])):
        raise ValueError("frozen Stage-B objective must have only positive torque diagonal and zero linear term")
    if np.any(np.diag(original_tau_only)[tau_indices] <= 0):
        raise ValueError("frozen positive torque regularizer missing")
    expected, bounds, checks = {}, {}, {}
    expected["P"] = np.array([[R[i] * Q[i, j] * R[j] for j in range(n)] for i in range(n)], dtype=object)
    bounds["P"] = gamma(2) * np.abs(expected["P"])
    expected["q"] = np.array([R[i] * (_dot(Q[i], a) + c[i]) for i in range(n)], dtype=object)
    bounds["q"] = np.array([gamma(2 * n + 2) * abs(R[i]) * (abs(c[i]) + _dot(np.abs(Q[i]), np.abs(a))) for i in range(n)], dtype=object)
    expected["objective_constant"] = np.asarray(HALF * sum((a[i] * Q[i, j] * a[j] for i in range(n) for j in range(n) if a[i] and Q[i, j] and a[j]), ZERO) + _dot(c, a), dtype=object)
    bounds["objective_constant"] = np.asarray(gamma(4 * n * n + 4 * n + 3) * (HALF * sum((abs(a[i] * Q[i, j] * a[j]) for i in range(n) for j in range(n) if a[i] and Q[i, j] and a[j]), ZERO) + _dot(np.abs(c), np.abs(a))), dtype=object)
    for matrix_name, rhs_name, matrix, rhs in (("E", "f", E, f), ("G", "h", G, h)):
        expected[matrix_name] = _scale_columns(matrix, R)
        bounds[matrix_name] = gamma(1) * np.abs(expected[matrix_name])
        expected[rhs_name] = np.array([rhs[i] - _dot(row, a) for i, row in enumerate(matrix)], dtype=object)
        bounds[rhs_name] = np.array([gamma(2 * n + 1) * (abs(rhs[i]) + _dot(np.abs(row), np.abs(a))) for i, row in enumerate(matrix)], dtype=object)
    canonical = [str(label).removeprefix("p0_").removeprefix("reference_") for label in p["inequality_labels"]]
    for k, selected in enumerate(selectors):
        for side, sign in (("upper", 1), ("lower", -1)):
            row = canonical.index(f"fixed_task_{side}[{k}]")
            selector_row = np.zeros(n)
            selector_row[selected] = sign
            if not np.array_equal(p["original_G"][row], selector_row):
                raise ValueError("task row coefficient mismatch")
            bounds["h"][row] = gamma(1) * abs(expected["h"][row])
    for name in expected:
        checks[name] = _check(p[name], expected[name], bounds[name])

    # Re-evaluate the unchanged row rule from actual rounded new arrays.
    for prefix, matrix_name, rhs_name in (("equality", "E", "f"), ("inequality", "G", "h")):
        actual_matrix, actual_rhs = _array(p[matrix_name]), _array(p[rhs_name])
        characteristic = [max(max(abs(v) for v in row), abs(actual_rhs[i])) for i, row in enumerate(actual_matrix)]
        scale_expected = np.array([1 / value if value else Fraction(1) for value in characteristic], dtype=object)
        name = prefix + "_row_scales"
        checks[name] = _check(p[name], scale_expected, gamma(1) * np.abs(scale_expected))
    row_scales = np.concatenate((_array(p["equality_row_scales"]), _array(p["inequality_row_scales"])))
    matrix = np.vstack((_array(p["E"]), _array(p["G"])))
    rhs = np.concatenate((_array(p["f"]), _array(p["h"])))
    final_A, final_b = row_scales[:, None] * matrix, row_scales * rhs
    checks["final_A"] = _check(p["A"], final_A, gamma(1) * np.abs(final_A))
    checks["final_b"] = _check(p["b"], final_b, gamma(1) * np.abs(final_b))

    # Legacy arrays establish that the physical transform was not applied to
    # already D-scaled coefficients. Their scale rule is audited independently.
    legacy_scales = []
    for prefix, matrix_name, rhs_name, matrix, rhs in (("equality", "original_E", "original_f", E, f), ("inequality", "original_G", "original_h", G, h)):
        rounded_matrix = np.asarray(p[matrix_name]) * np.asarray(p["D"])[None, :]
        rational_matrix = _array(rounded_matrix)
        characteristic = [max(max(abs(v) for v in row), abs(rhs[i])) for i, row in enumerate(rational_matrix)]
        want = np.array([1 / value if value else Fraction(1) for value in characteristic], dtype=object)
        key = "legacy_" + prefix + "_row_scales"
        checks[key] = _check(p[key], want, gamma(1) * np.abs(want))
        legacy_scales.extend(_array(p[key]))
    legacy_scales = np.asarray(legacy_scales, dtype=object)
    legacy_A = legacy_scales[:, None] * _scale_columns(np.vstack((E, G)), D)
    legacy_b = legacy_scales * np.concatenate((f, h))
    legacy_P = D[:, None] * Q * D[None, :]
    legacy_q = D * c
    for name, want, count in (("legacy_A", legacy_A, 2), ("legacy_b", legacy_b, 1), ("legacy_P", legacy_P, 2), ("legacy_q", legacy_q, 1)):
        checks[name] = _check(p[name], want, gamma(count) * np.abs(want))

    task_layers = []
    for k, selected in enumerate(selectors):
        upper = canonical.index(f"fixed_task_upper[{k}]")
        lower = canonical.index(f"fixed_task_lower[{k}]")
        band = Fraction(1, 10**8) * F(snapshot.task_scales[k])
        center = F(target[k])
        layer = {"task_index": k, "selector_index": int(selected), "contract_literal_normalized_band": "1/100000000", "binary64_normalized_band_exact": str(F(1e-8)), "task_scale_exact": str(F(snapshot.task_scales[k])), "target_exact": str(center), "sides": {}}
        for side, row, sign in (("upper", upper, 1), ("lower", lower, -1)):
            expected_row = np.zeros(n)
            expected_row[selected] = sign
            if not np.array_equal(p["original_G"][row], expected_row):
                raise ValueError("task row coefficient mismatch")
            contract_rhs = sign * center + band
            old_error = abs(h[row] - contract_rhs)
            old_budget = gamma(3) * (abs(center) + band)
            rhs_new, coeff_new = F(p["h"][row]), F(p["G"][row, selected])
            endpoint_z = rhs_new / coeff_new
            inverse_endpoint = center + R[selected] * endpoint_z
            normalized_endpoint = abs(inverse_endpoint - center) / F(snapshot.task_scales[k])
            layer["sides"][side] = {
                "contract_rhs_exact": str(contract_rhs), "old_encoded_rhs_exact": str(h[row]),
                "old_encoding_error_exact": str(old_error), "old_encoding_error": float(old_error),
                "old_encoding_predeclared_bound": float(old_budget), "old_encoding_within_bound": old_error <= old_budget,
                "new_encoded_rhs_exact": str(rhs_new), "new_encoded_selector_coefficient_exact": str(coeff_new),
                "new_z_endpoint_exact": str(endpoint_z), "new_z_endpoint": float(endpoint_z),
                "inverse_endpoint_exact": str(inverse_endpoint), "inverse_normalized_distance_exact": str(normalized_endpoint),
                "inverse_endpoint_within_literal_contract": normalized_endpoint <= Fraction(1, 10**8),
                "inverse_endpoint_within_binary64_gate_exact_evaluation": normalized_endpoint <= F(1e-8),
                "expected_old_contract_encoding_roundoff": old_error != 0 and old_error <= old_budget,
            }
            if old_error > old_budget or h[row] - sign * center <= 0:
                raise ValueError("unresolved original contract/encoded task slab contradiction")
        task_layers.append(layer)

    deterministic = []
    for name, z_float in (("zero", np.zeros(n)), ("linear", np.linspace(-0.75, 0.75, n)), ("alternating", np.where(np.arange(n) % 2 == 0, 0.5, -0.5))):
        z = _array(z_float)
        w_exact = a + R * z
        w_float = np.asarray(p["a"]) + np.asarray(p["R"]) * z_float
        forward_bound = gamma(2) * (np.abs(a) + np.abs(R * z))
        forward = _check(w_float, w_exact, forward_bound)
        back = (w_float - np.asarray(p["a"])) / np.asarray(p["R"])
        back_bound = forward_bound / np.abs(R) + gamma(2) * (np.abs(_array(w_float)) + np.abs(a)) / np.abs(R)
        inverse = _check(back, z, back_bound)
        identities = {}
        for matrix_name, rhs_name, original_matrix, original_rhs in (("E", "f", E, f), ("G", "h", G, h)):
            old_value = np.array([_dot(row, w_exact) - original_rhs[i] for i, row in enumerate(original_matrix)], dtype=object)
            new_value = np.array([_dot(row, z) - _array(p[rhs_name])[i] for i, row in enumerate(_array(p[matrix_name]))], dtype=object)
            identity_budget = np.array([_dot(row, np.abs(z)) + bounds[rhs_name][i] for i, row in enumerate(bounds[matrix_name])], dtype=object)
            # The values are exact rationals here; compare without float casting.
            errors = np.abs(new_value - old_value)
            identities[matrix_name] = {"pass": bool(np.all(errors <= identity_budget)), "max_absolute_error": float(max(errors)), "per_row_absolute_error": [float(v) for v in errors], "per_row_predeclared_bound": [float(v) for v in identity_budget]}
        old_objective = HALF * sum((w_exact[i] * Q[i, j] * w_exact[j] for i in range(n) for j in range(n) if w_exact[i] and Q[i, j] and w_exact[j]), ZERO) + _dot(c, w_exact)
        Pnew, qnew = _array(p["P"]), _array(p["q"])
        new_objective = HALF * sum((z[i] * Pnew[i, j] * z[j] for i in range(n) for j in range(n) if z[i] and Pnew[i, j] and z[j]), ZERO) + _dot(qnew, z) + F(p["objective_constant"])
        objective_bound = HALF * sum((abs(z[i] * z[j]) * bounds["P"][i, j] for i in range(n) for j in range(n) if z[i] and z[j] and bounds["P"][i, j]), ZERO) + _dot(bounds["q"], np.abs(z)) + bounds["objective_constant"].item()
        identities["objective"] = {"pass": abs(old_objective - new_objective) <= objective_bound, "absolute_error_exact": str(abs(old_objective - new_objective)), "predeclared_bound_exact": str(objective_bound), "old_exact": str(old_objective), "new_exact": str(new_objective)}
        deterministic.append({"vector_id": name, "z": z_float.tolist(), "forward": forward, "inverse_round_trip": inverse, "identities": identities, "pass": forward["pass"] and inverse["pass"] and all(value["pass"] for value in identities.values())})
    passed = all(value["pass"] for value in checks.values()) and all(value["pass"] for value in deterministic)
    return {
        "pass": bool(passed), "classification": "REPRESENTED_QP_EQUIVALENCE_WITHIN_PREDECLARED_ROUNDOFF" if passed else "REPRESENTED_QP_CONTRACT_MISMATCH",
        "solver_calls": 0, "coefficient_checks": checks,
        "coefficient_count_checked": sum(check.get("coefficient_count", 0) for check in checks.values()),
        "task_contract_encoding_layers": task_layers,
        "deterministic_vector_checks": deterministic,
        "shifted_equality_rhs_nonzero_count": int(np.count_nonzero(p["f"])),
        "objective_constant": float(p["objective_constant"]),
        "original_unit_band_gate_unchanged": 1e-8,
        "contract_encoding_interpretation": "Expected bounded old float64 endpoint rounding is reported separately; it does not excuse any candidate's literal original-unit gate failure.",
    }


def audit_pair(production, reference, snapshot, targets) -> dict:
    if isinstance(targets, dict):
        target_p, target_r = targets["production"], targets["reference"]
    elif np.asarray(targets).shape == (2, 8):
        target_p, target_r = targets
    else:
        target_p = target_r = targets
    left, right = audit_problem(production, snapshot, target_p), audit_problem(reference, snapshot, target_r)
    same = {}
    for name in ("original_P", "original_q", "D", "a", "R"):
        same[name] = bool(np.array_equal(production[name], reference[name]))
    for kind, matrix, rhs in (("equality", "original_E", "original_f"), ("inequality", "original_G", "original_h")):
        arrays = []
        for problem in (production, reference):
            labels = [str(label).removeprefix("p0_").removeprefix("reference_") for label in problem[kind + "_labels"]]
            order = sorted(range(len(labels)), key=labels.__getitem__)
            arrays.append(([labels[i] for i in order], np.asarray(problem[matrix])[order], np.asarray(problem[rhs])[order]))
        same[kind + "_labels"] = arrays[0][0] == arrays[1][0]
        same[matrix] = bool(np.array_equal(arrays[0][1], arrays[1][1]))
        same[rhs] = bool(np.array_equal(arrays[0][2], arrays[1][2]))
    passed = left["pass"] and right["pass"] and all(same.values())
    return {"pass": bool(passed), "classification": "PAIR_REPRESENTATION_AUDIT_PASS" if passed else "REPRESENTED_QP_CONTRACT_MISMATCH", "original_encoded_problem_exact_equality": same, "production": left, "reference": right, "solver_calls": 0}
