"""Frozen STEP-02G CLI: saved-data audit only; never assemble/solve a new QP."""
from __future__ import annotations

import argparse
import ast
from collections import Counter
import csv
from datetime import datetime, timezone
from fractions import Fraction
import importlib.metadata
import io
import json
from pathlib import Path
import platform
import subprocess
import sys
import time
import traceback
import unittest

import numpy as np
import yaml

from cavr_wbc.evaluation.step02g_no_solve import optimizer_guard
from cavr_wbc.evaluation.step02g_saved_certificates import (
    InputIntegrityError, append_jsonl, checked_path, decode_exact, join_records,
    load_problem, read_json, read_jsonl, serialize_exact, sha256, verify_hash, write_json,
)

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "artifacts/step02g_saved_certificate_audit"
F = ROOT / "artifacts/step02f_coordinate_equivalence"
BASE = "0aa98d533de944b0644f13f4ef84c331f9decce1"
CONFIG_SHA = "fd14b1fe8a4a6ba689d73ca94e128095c1d8726ecac6438eadd1bc1587c96a6b"
VERSION = "STEP02G_EXACT_BOX_LAGRANGIAN_V1"
C_MAIN = Path("C:/Users/ZhuanZ（无密码）/OneDrive - 고려대학교/文档/ChatGPT/保密实验")
C_F = C_MAIN.parent / "cavr_step02f_coordinate_equivalence_20260918"
PROTOCOL_SOURCE = C_MAIN / "artifacts/step02f_scientific_audit_20260918"
PROTOCOL_HASHES = {
    "NEXT_CODEX_INSTRUCTIONS_STEP02G.md": "c4e8640cdff2d9731da84804d3f8b7b8ebda5d4c2d10d334eec9d3449c7032e6",
    "STEP02F_SCIENTIFIC_AUDIT.md": "4f98fd2cdf691e8e5af0f3e8e29c19e171b5e4af909d5c71c21139dd735adeb2",
}


def utc():
    return datetime.now(timezone.utc).isoformat()


def git(root, *args):
    return subprocess.check_output(["git", "-c", "core.quotepath=false", "-C", str(root), *args]).decode("utf-8").strip()


def require(condition, message):
    if not condition:
        raise InputIntegrityError(message)


def implementation_files():
    files = list((ROOT / "cavr_wbc/evaluation").glob("*.py"))
    files += list((ROOT / "tests").glob("test_step02g_*.py"))
    files += [Path(__file__), OUT / "STEP02G_PROTOCOL.md", OUT / ".gitattributes",
              ROOT / "cavr_wbc/evaluation/.gitattributes", ROOT / "cavr_wbc/experiments/.gitattributes",
              ROOT / "tests/.gitattributes"]
    return sorted(files)


def static_check(files):
    findings = []
    checked = []
    for path in files:
        if path.suffix != ".py":
            continue
        tree = ast.parse(path.read_text(encoding="utf-8"))
        checked.append(str(path.relative_to(ROOT)).replace("\\", "/"))
        for node in ast.walk(tree):
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                names = [alias.name for alias in node.names] if isinstance(node, ast.Import) else [node.module or ""]
                if any(name == "cavr_wbc.experiments.step02f" or name.startswith("scipy.optimize") for name in names):
                    findings.append({"file": str(path), "line": node.lineno, "issue": "forbidden runner/optimization import"})
            if isinstance(node, ast.Call):
                name = node.func.attr if isinstance(node.func, ast.Attribute) else node.func.id if isinstance(node.func, ast.Name) else ""
                if name in ("solve", "setup", "DefaultSolver", "OSQP", "OSQPSolver", "minimize", "linprog") or name.startswith("solve_"):
                    findings.append({"file": str(path), "line": node.lineno, "issue": "optimizer-like call", "name": name})
    require(not findings, f"Static optimizer boundary findings: {findings}")
    return {"method": "AST imports and direct call-name review plus separately inspected runtime guard routes", "files": checked,
            "findings": findings, "limitation": "Static name scan is not a general proof against dynamic dispatch; runtime native/export/wrapper/profile guards also required."}


def source_inventory():
    require(git(C_F, "rev-parse", "HEAD") == BASE, "C source HEAD mismatch")
    require(git(C_F, "status", "--porcelain=v1") == "", "C source F worktree dirty")
    require(git(ROOT, "rev-parse", "HEAD") == BASE, "G freeze must precede result commit")
    require(git(ROOT, "cat-file", "-t", BASE) == "commit", "Source object is not a commit")
    tree = {}
    for line in git(ROOT, "ls-tree", "-r", BASE).splitlines():
        metadata, name = line.split("\t", 1)
        tree[name] = metadata.split()[2]
    baseline_files = list(tree)
    inventory = {}
    checkout_differences = []
    for name in baseline_files:
        local = checked_path(ROOT, name)
        source = checked_path(C_F, name)
        digest = sha256(source)
        local_digest = sha256(local)
        if local_digest != digest:
            # The sole observed non-input difference is Git's CRLF checkout of
            # the root attribute file, which has no byte-preservation rule for
            # itself. Do not rewrite either file or relax evidence hashing.
            require(name == ".gitattributes", f"Source input bytes differ: {name}")
            blob = subprocess.check_output(["git", "-C", str(ROOT), "show", f"{BASE}:{name}"])
            require(source.read_bytes() == blob and local.read_bytes() == blob.replace(b"\n", b"\r\n"), "Root attributes differ beyond exact Git LF-to-CRLF checkout")
            checkout_differences.append({"file": name, "source_sha256": digest, "local_sha256": local_digest,
                "classification": "NON_RESEARCH_CHECKOUT_LF_TO_CRLF_ONLY", "source_equals_git_blob": True,
                "both_files_left_untouched": True, "not_in_frozen_scientific_input_manifests": True})
        inventory[name] = {"sha256": local_digest, "source_worktree_sha256": digest, "size_bytes": local.stat().st_size,
                           "git_blob": tree[name]}
    source_freeze = read_json(F / "source_freeze_manifest.json")
    counts = {}
    for group in ("baseline_checkout_file_sha256", "step02f_frozen_file_sha256"):
        for name, digest in source_freeze[group].items():
            verify_hash(checked_path(ROOT, name), digest)
        counts[group] = len(source_freeze[group])
    index = read_json(F / "represented_problem_index.json")
    require(len(index) == 245, "Expected 245 represented case IDs")
    represented = {}
    for case_id, paths in index.items():
        require(set(paths) == {"production", "reference"}, "Two independent paths required")
        for path, entry in paths.items():
            name = entry["file"]
            require(name not in represented, "NPZ file reused by distinct case/path")
            verify_hash(checked_path(ROOT, name), entry["sha256"])
            represented[name] = {"case_id": case_id, "path": path, "sha256": entry["sha256"]}
    representation = read_json(F / "representation_freeze.json")
    for name, digest in representation["files"].items():
        verify_hash(checked_path(ROOT, name), digest)
    for key, name in (("index_sha256", "represented_problem_index.json"), ("audit_sha256", "represented_qp_equivalence_audit.json"), ("case_evidence_sha256", "representation_cases.jsonl")):
        verify_hash(F / name, representation[key])
    verify_hash(F / "config.yaml", CONFIG_SHA)
    protocols = []
    for name, digest in PROTOCOL_HASHES.items():
        source, copy = PROTOCOL_SOURCE / name, OUT / "protocol" / name
        verify_hash(source, digest)
        verify_hash(copy, digest)
        protocols.append({"source_path": str(source), "copy_path": str(copy), "source_sha256": digest, "copy_sha256": digest, "byte_equal": True})
    main_untracked = git(C_MAIN, "ls-files", "--others", "--exclude-standard").splitlines()
    return {"algorithm_version": VERSION, "frozen_at_utc": utc(), "source_commit": BASE,
            "worktree": str(ROOT), "branch": git(ROOT, "branch", "--show-current"), "source_worktree": str(C_F),
            "source_git_status_before": git(C_F, "status", "--porcelain=v1"),
            "original_workspace_head_before": git(C_MAIN, "rev-parse", "HEAD"),
            "original_workspace_git_status_before": git(C_MAIN, "status", "--porcelain=v1"),
            "original_untracked_file_sha256": {name: sha256(C_MAIN / name) for name in main_untracked},
            "source_tracked_file_count": len(inventory), "source_tracked_files": inventory,
            "checkout_only_nonresearch_differences": checkout_differences,
            "frozen_manifest_checks": counts, "represented_problem_count": len(represented),
            "represented_problems": represented, "protocol_sources": protocols, "config_sha256": CONFIG_SHA,
            "input_interpretation": "NPZ finite float64; JSON numbers restored by Python json as binary64 then Fraction.from_float; integer metadata stays integer.",
            "hash_interpretation": "SHA256 of raw file bytes, not normalized text; box semantic rational hashes are separately labelled inside proofs."}


def verify_freeze():
    implementation = read_json(OUT / "AUDIT_IMPLEMENTATION_MANIFEST.json")
    for name, digest in implementation["files"].items():
        verify_hash(checked_path(ROOT, name), digest)
    verify_hash(OUT / "SOURCE_MANIFEST.json", implementation["source_manifest_sha256"])
    sources = read_json(OUT / "SOURCE_MANIFEST.json")
    for name, entry in sources["source_tracked_files"].items():
        verify_hash(checked_path(ROOT, name), entry["sha256"])
        verify_hash(checked_path(C_F, name), entry["source_worktree_sha256"])
    for item in sources["protocol_sources"]:
        verify_hash(item["source_path"], item["source_sha256"])
        verify_hash(item["copy_path"], item["copy_sha256"])
    require(git(C_F, "status", "--porcelain=v1") == sources["source_git_status_before"], "F source status changed")
    require(git(C_F, "rev-parse", "HEAD") == BASE, "F source commit changed")
    require(git(C_MAIN, "rev-parse", "HEAD") == sources["original_workspace_head_before"], "Original HEAD changed")
    require(git(C_MAIN, "status", "--porcelain=v1") == sources["original_workspace_git_status_before"], "Original status changed")
    for name, digest in sources["original_untracked_file_sha256"].items():
        verify_hash(C_MAIN / name, digest)
    return {"checked_at_utc": utc(), "source_files_checked": len(sources["source_tracked_files"]),
            "source_and_original_unchanged": True, "implementation_unchanged": True,
            "config_sha256": sha256(F / "config.yaml"), "source_manifest_sha256": sha256(OUT / "SOURCE_MANIFEST.json")}


def inputs():
    raw = read_jsonl(F / "raw_solver_diagnostics.jsonl")
    cert = read_jsonl(F / "original_unit_certificates.jsonl")
    joined = join_records(raw, cert, read_jsonl(F / "solver_call_ledger.jsonl"), read_jsonl(F / "solve_attempt_ledger.jsonl"))
    pairs = {}
    for row, certificate, call, attempt in joined:
        require(row["phase"] == "regression" and row["path"] in ("production", "reference"), "Unexpected saved solve phase/path")
        require(row["solver_constructed"] and row["solve_called"] and call["event"] == "solve_called_once" and attempt["event"] == "attempt_reserved_before_solver_construction", "Historical call evidence mismatch")
        for key, length in (("z_coordinate", 42), ("slack", 94), ("dual", 94)):
            array = np.asarray(row[key], dtype=np.float64)
            require(array.shape == (length,) and np.isfinite(array).all(), f"Bad saved {key}")
        witness = np.asarray(certificate["original_witness"], dtype=np.float64)
        require(witness.shape == (42,) and np.isfinite(witness).all(), "Bad saved physical witness")
        require(certificate["status_accepted"] == row["status_accepted"] == (row["status"] == "Solved"), "Status acceptance mismatch")
        pairs.setdefault(row["case_id"], {})[row["path"]] = (row, certificate)
    require(len(pairs) == 10 and all(set(pair) == {"production", "reference"} for pair in pairs.values()), "Expected10 paired saved cases")
    require(Counter(row["status"] for row in raw) == {"Solved": 18, "AlmostSolved": 2}, "Frozen status counts changed")
    for pair in pairs.values():
        require(pair["production"][0]["z_coordinate"] == pair["reference"][0]["z_coordinate"] and pair["production"][1]["original_witness"] == pair["reference"][1]["original_witness"], "Historical raw pair identity mismatch")
    regression, full, result = (read_json(F / name) for name in ("regression_results.json", "full_panel_results.json", "STEP02F_RESULT.json"))
    require(regression["executed_cases"] == 10 and regression["passing_cases"] == 9 and len(regression["cases"]) == 36, "F regression history mismatch")
    require(sum(row.get("execution_status") == "NOT RUN" for row in regression["cases"]) == 26, "F remaining regressions changed")
    require(full["executed_cases"] == 0 and full["status"] == "NOT RUN" and len(full["cases"]) == 245 and all(row.get("execution_status") == "NOT RUN" for row in full["cases"]), "F full-panel NOT RUN mismatch")
    require(result["status"] == "FAIL / REVISE" and result["actual_solver_calls"] == 20, "F result/history mismatch")
    config = yaml.safe_load((F / "config.yaml").read_text(encoding="utf-8"))
    mapping = read_json(ROOT / "artifacts/step01b_platform_freeze/actuator_joint_map.json")["entries"]
    require([entry["actuator_index"] for entry in mapping] == list(range(12)), "Actuator map order mismatch")
    config["_audited_actuator_names"] = [entry["actuator_name"] for entry in mapping]
    stage_a = {}
    for route, name, savedpath in (("production", "p0_clarabel_diagnostics.jsonl", "p0_a"), ("reference", "reference_diagnostics.jsonl", "ref_a")):
        selected = [row for row in read_jsonl(ROOT / "artifacts/step02d_exact_band_equivalence" / name) if row["phase"] == "full_panel" and row["path"] == savedpath]
        require(len(selected) == 245 and len({row["case_id"] for row in selected}) == 245, "Stage-A full_panel cache coverage mismatch")
        stage_a[route] = {row["case_id"]: row for row in selected}
    index = read_json(F / "represented_problem_index.json")
    for raw, cert, _, _ in joined:
        require(raw["case_id"] in index, "Missing represented problem for saved candidate")
        a = stage_a[raw["path"]][raw["case_id"]]
        require(a["task_output"] == cert["cached_stage_a_target"], "Stage-A target not from the frozen full_panel cache")
    return joined, index, config, stage_a


def freeze():
    require(not (OUT / "AUDIT_IMPLEMENTATION_MANIFEST.json").exists(), "Implementation freeze already exists; no silent replacement")
    sources = source_inventory()
    inputs()  # Identity/schema/cache linkage only; no candidate/bound/endpoint arithmetic.
    files = implementation_files()
    static = static_check(files)
    write_json(OUT / "SOURCE_MANIFEST.json", sources)
    write_json(OUT / "AUDIT_IMPLEMENTATION_MANIFEST.json", {
        "algorithm_version": VERSION, "frozen_at_utc": utc(), "bulk_analysis_started": False,
        "analysis_type": "method-specified post-hoc saved-evidence audit; not preregistered or blinded",
        "source_commit": BASE, "source_manifest_sha256": sha256(OUT / "SOURCE_MANIFEST.json"),
        "files": {str(path.relative_to(ROOT)).replace("\\", "/"): sha256(path) for path in files},
        "dependencies": {"python": sys.version, "platform": platform.platform(), "exact_arithmetic": "Python stdlib fractions.Fraction + integer arithmetic",
                         **{name: importlib.metadata.version(name) for name in ("numpy", "PyYAML", "clarabel", "osqp", "scipy", "mujoco")}},
        "static_check": static, "optimizer_modules_imported_only_for_boundary_guard": True,
        "method_changes": [], "authorized_optimization_calls": 0,
    })
    return {"status": "FROZEN", "source_files": sources["source_tracked_file_count"], "represented_problems": sources["represented_problem_count"]}


def tests():
    stream = io.StringIO()
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"), pattern="test_step02g_*.py", top_level_dir=str(ROOT / "tests"))
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    # Test report is task output, not historical evidence.
    (OUT / "no_solve_tests.txt").write_text(stream.getvalue(), encoding="utf-8", newline="\n")
    summary = {"tests_run": result.testsRun, "failures": len(result.failures), "errors": len(result.errors),
               "skipped": len(result.skipped), "successful": result.wasSuccessful(), "scope": "new synthetic no-optimization tests only", "saved_candidates_replayed": 0}
    write_json(OUT / "no_solve_tests.json", summary)
    require(result.wasSuccessful(), "New no-solve tests failed")
    return summary


def audit():
    from cavr_wbc.evaluation.step02g_candidates import audit_candidate
    from cavr_wbc.evaluation.step02g_endpoints import audit_endpoints
    before = verify_freeze()
    joined, index, config, stage_a = inputs()
    for name in ("candidate_audit.jsonl", "exact_bound_certificates.jsonl", "final_encoded_task_endpoints.jsonl"):
        require(not (OUT / name).exists(), f"Audit output already exists: {name}; no silent rerun")
    (OUT / "exact_evidence").mkdir(exist_ok=False)
    candidates = []
    for raw, cert, _, _ in joined:
        entry = index[raw["case_id"]][raw["path"]]
        problem = load_problem(checked_path(ROOT, entry["file"]))
        row = audit_candidate(problem, raw, cert, config, stage_a[raw["path"]][raw["case_id"]])
        require(row["validation_replay_matches_saved_gates"], "Frozen numeric/status gate replay disagrees with saved evidence")
        exact = row.pop("exact_evidence")
        exact_name = f"exact_evidence/{raw['solve_ordinal']:02d}_{raw['path']}.json"
        write_json(OUT / exact_name, exact)
        row["exact_evidence_file"] = exact_name
        row["exact_evidence_sha256"] = sha256(OUT / exact_name)
        row["represented_problem"] = entry
        append_jsonl(OUT / "candidate_audit.jsonl", row)
        append_jsonl(OUT / "exact_bound_certificates.jsonl", {"solve_ordinal": raw["solve_ordinal"], "case_id": raw["case_id"], "path": raw["path"], "exact_evidence_file": exact_name, "exact_evidence_sha256": row["exact_evidence_sha256"], "input_npz": entry, "summary": row})
        candidates.append(row)
        print(f"candidate {len(candidates)}/20 audited", flush=True)
    # Human-readable CSV retains JSONL as authoritative lossless evidence.
    scalar_keys = sorted({key for row in candidates for key, value in row.items() if not isinstance(value, (dict, list, tuple))})
    with (OUT / "candidate_audit.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=scalar_keys)
        writer.writeheader()
        for row in candidates:
            writer.writerow({key: str(row.get(key)) if isinstance(row.get(key), Fraction) else row.get(key) for key in scalar_keys})
    endpoint_count = 0
    maxima = {}
    band_counts = {layer: Counter() for layer in ("original", "pre_row_scaled", "final_encoded")}
    for number, (case_id, paths) in enumerate(index.items(), 1):
        for path in ("production", "reference"):
            entry = paths[path]
            rows = audit_endpoints(load_problem(checked_path(ROOT, entry["file"])), config["task_stack"]["normalization_scales"])
            require(len(rows) == 16, "Incomplete endpoint coverage")
            for row in rows:
                row.update(case_id=case_id, path=path, input_npz=entry)
                append_jsonl(OUT / "final_encoded_task_endpoints.jsonl", row)
                endpoint_count += 1
                for metric in ("signed_pre_minus_original_endpoint", "signed_final_minus_original_endpoint", "signed_final_minus_pre_endpoint"):
                    if metric not in maxima or abs(row[metric]) > maxima[metric]["maximum_absolute_error"]:
                        maxima[metric] = {"maximum_absolute_error": abs(row[metric]), "signed_error": row[metric], "case_id": case_id, "path": path, "task_index": row["task_index"], "side": row["side"]}
                for layer, position in row["band_positions"].items():
                    for literal in ("binary64", "decimal_rational"):
                        band_counts[layer][literal + "_within"] += int(position[f"within_{literal}_literal_band"] if literal == "binary64" else position["within_decimal_rational_band"])
        if number % 25 == 0 or number == 245:
            print(f"represented cases {number}/245; endpoints {endpoint_count}/7840", flush=True)
    require(endpoint_count == 7840, "Incomplete all-NPZ endpoint audit")
    endpoint_summary = {"status": "AUDIT_COMPLETED", "case_count": 245, "path_count": 490, "endpoint_count": endpoint_count,
                        "maxima": maxima, "literal_band_endpoint_counts": {key: dict(value) for key, value in band_counts.items()},
                        "new_acceptance_threshold": None, "does_not_explain_solver_exit_cause": True,
                        "old_representation_budget_reference": "artifacts/step02f_coordinate_equivalence/representation_error_budget.json"}
    write_json(OUT / "final_encoded_task_endpoint_summary.json", endpoint_summary)
    after = verify_freeze()
    write_json(OUT / "source_integrity_after_audit.json", {"before": before, "after": after})
    return {"status": "AUDIT_COMPLETED", "saved_candidates_audited": len(candidates), "saved_representations_audited": 490,
            "endpoints_audited": endpoint_count, "candidate_diagnostic_analyses": 20}


def replay():
    from cavr_wbc.evaluation.step02g_candidates import audit_candidate
    verify_freeze()
    saved = read_jsonl(OUT / "candidate_audit.jsonl")
    joined, index, config, stage_a = inputs()
    require(len(saved) == 20, "Incomplete saved G summaries")
    count = 0
    for recorded, (raw, cert, _, _) in zip(saved, joined):
        entry = index[raw["case_id"]][raw["path"]]
        replayed = audit_candidate(load_problem(checked_path(ROOT, entry["file"])), raw, cert, config, stage_a[raw["path"]][raw["case_id"]])
        exact = replayed.pop("exact_evidence")
        verify_hash(OUT / recorded["exact_evidence_file"], recorded["exact_evidence_sha256"])
        require(serialize_exact(exact) == read_json(OUT / recorded["exact_evidence_file"]), f"Exact evidence replay mismatch at {raw['solve_ordinal']}")
        expected = {key: value for key, value in recorded.items() if key not in ("exact_evidence_file", "exact_evidence_sha256", "represented_problem")}
        require(serialize_exact(replayed) == expected, f"Candidate replay mismatch at {raw['solve_ordinal']}")
        count += 1
        print(f"saved candidate replay {count}/20", flush=True)
    report = {"status": "PASS", "saved_candidates_replayed": count, "exact_evidence_and_summary_identical": True,
              "new_optimization_calls": 0, "old_experiments_rerun": False, "source_integrity": verify_freeze()}
    write_json(OUT / "saved_evidence_replay.json", report)
    return report


def summarize():
    """Render already computed evidence; never substitute a new audit algorithm."""
    integrity = verify_freeze()
    candidates = decode_exact(read_jsonl(OUT / "candidate_audit.jsonl"))
    endpoints = decode_exact(read_json(OUT / "final_encoded_task_endpoint_summary.json"))
    tests_report = read_json(OUT / "no_solve_tests.json")
    replay_report = read_json(OUT / "saved_evidence_replay.json")
    require(len(candidates) == 20 and endpoints["path_count"] == 490 and endpoints["endpoint_count"] == 7840, "Summary coverage incomplete")
    require(tests_report["successful"] and replay_report["saved_candidates_replayed"] == 20, "Required tests/replay incomplete")
    certificate_summary = {
        "lower_bound_status_counts": dict(Counter(row["lower_bound_status"] for row in candidates)),
        "box_status_counts": dict(Counter(row["box_proof_status"] for row in candidates)),
        "exact_feasible_candidates": sum(row["exact_original_qp_feasible"] for row in candidates),
        "strict_primal_upper_bounds": sum(row["strict_primal_upper_bound"] is not None for row in candidates),
        "strict_optimality_gaps": sum(row["strict_optimality_gap"] is not None for row in candidates),
        "numeric_physical_pass": sum(row["frozen_numeric_physical_pass"] for row in candidates),
        "numeric_literal_band_pass": sum(row["frozen_literal_band_pass"] for row in candidates),
        "exact_binary64_literal_band_pass": sum(row["exact_literal_band_binary64_pass"] for row in candidates),
        "exact_decimal_literal_band_pass": sum(row["exact_literal_band_decimal_pass"] for row in candidates),
        "frozen_status_accepted": sum(row["frozen_status_accepted"] for row in candidates),
        "signed_candidate_difference_negative_count": sum(row["candidate_objective_minus_lower_bound"] is not None and row["candidate_objective_minus_lower_bound"] < 0 for row in candidates),
        "groups": {},
    }
    for status in ("Solved", "AlmostSolved"):
        selected = [row for row in candidates if row["original_status"] == status]
        certificate_summary["groups"][status] = {
            "records": len(selected), "cases": len({row["case_id"] for row in selected}),
            "stationarity_maximum_range": [min(row["original_stationarity_absolute_maximum"] for row in selected), max(row["original_stationarity_absolute_maximum"] for row in selected)],
            "lower_bounds_certified": sum(row["lower_bound_status"] == "CERTIFIED" for row in selected),
            "exact_feasible": sum(row["exact_original_qp_feasible"] for row in selected),
            "signed_candidate_difference_range": [min(row["candidate_objective_minus_lower_bound"] for row in selected if row["candidate_objective_minus_lower_bound"] is not None), max(row["candidate_objective_minus_lower_bound"] for row in selected if row["candidate_objective_minus_lower_bound"] is not None)] if any(row["candidate_objective_minus_lower_bound"] is not None for row in selected) else None,
        }
    evidence_metrics = []
    for row in candidates:
        exact = decode_exact(read_json(OUT / row["exact_evidence_file"]))
        evidence_metrics.append({"solve_ordinal": row["solve_ordinal"],
            "nonzero_equality_rows": len(exact["exact_violated_equality_rows"]),
            "violated_inequality_rows": len(exact["exact_violated_inequality_rows"]),
            "maximum_exact_equality_residual": max(map(abs, exact["original_equality_residual"])),
            "maximum_exact_inequality_residual": max(exact["original_inequality_residual"]),
            "negative_mu_count": len(exact["negative_mu"]),
            "inverse_mapping_rounding_maximum": exact["inverse_mapping_rounding_maximum"],
            "original_stationarity_groups": exact["stationarity_by_variable_group"],
            "exact_objective_unit_conversion_proved": exact["objective_evidence"]["exact_objective_unit_conversion_proved"],
            "numeric_validation_fields_not_bit_identical": [key for key, item in exact["saved_validation_comparison"].items() if not item["equal"]],
            "encoded_stationarity_maximum": exact["encoded_stationarity_maximum"],
            "encoding_term_maximum": max(map(abs, exact["stationarity_encoding_term"])),
            "inverse_rounding_term_maximum": max(map(abs, exact["stationarity_inverse_rounding_term"])),
        })
    certificate_summary["per_candidate_details"] = evidence_metrics
    write_json(OUT / "CERTIFICATE_SUMMARY.json", certificate_summary)
    result = {
        "stage": "STEP02G", "status": "AUDIT_COMPLETED", "verification_level": "ANALYZED",
        "algorithm_version": VERSION, "source_commit": BASE, "worktree": str(ROOT),
        "branch": git(ROOT, "branch", "--show-current"), "config_sha256": CONFIG_SHA,
        "implementation_manifest_sha256": sha256(OUT / "AUDIT_IMPLEMENTATION_MANIFEST.json"),
        "source_manifest_sha256": sha256(OUT / "SOURCE_MANIFEST.json"),
        "saved_candidates_audited": 20, "saved_cases": 10, "saved_representations_audited": 490,
        "saved_representation_cases": 245, "task_endpoints_audited": 7840,
        "certificate_summary": certificate_summary, "endpoint_summary": endpoints,
        "tests": tests_report, "saved_evidence_replay": replay_report,
        "diagnostic_analysis_passes": {"candidate_primary": 20, "candidate_replay": 20, "endpoint_primary_paths": 490, "endpoint_primary_rows": 7840},
        "new_optimizer_constructions": 0, "new_optimization_solve_calls": 0,
        "new_or_repaired_candidates": 0, "old_experiments_rerun": False,
        "step02f_result_unchanged": "FAIL / REVISE", "step02d_result_unchanged": "FAIL / REVISE; strict221/245",
        "remaining_step02f_regressions": "NOT RUN", "step02f_full_panel": "NOT RUN",
        "stage_a_b1_soft_osqp_stage_a": "FROZEN SAVED EVIDENCE ONLY; NOT RERUN",
        "next_solve_authorized": False, "e1_authorized": False, "e1_executed": False,
        "posthoc_not_preregistered": True, "new_optimality_acceptance_threshold": None,
        "source_integrity": integrity,
        "result_commit": "See delivery commit; no self-referential commit hash embedded in its own contents.",
    }
    write_json(OUT / "STEP02G_RESULT.json", result)
    def display(value):
        return "null" if value is None else f"{float(value):.12g}"
    lines = [
        "# STEP-02G — 保存候选原 QP 证书审计", "",
        "## Material Passport", "",
        "- Origin Skill / Mode: experiment-agent / validate", "- Verification Status: ANALYZED",
        f"- Algorithm: {VERSION}", "- 已公开保存证据的指定方法事后诊断；不是盲测、预注册新实验或独立实验复现。", "",
        "## 结论与范围", "",
        f"AUDIT_COMPLETED：20/20 条保存候选（10 案例 × 2 路径）、490/490 份保存矩阵、7,840/7,840 个任务端点。严格下界状态：{certificate_summary['lower_bound_status_counts']}。",
        f"精确原 QP 可行候选 {certificate_summary['exact_feasible_candidates']}/20；严格 primal upper bound {certificate_summary['strict_primal_upper_bounds']}/20；严格 optimality gap {certificate_summary['strict_optimality_gaps']}/20。审计覆盖完成不等于实验 PASS。",
        "STEP-02F 保持 FAIL / REVISE。原回归仅10/36，前9通过、第10双方AlmostSolved拒收；历史20次求解、无重试；原四案例仅C/D通过，A/B未执行。剩余26回归及245全面板 NOT RUN；STEP-02D的221/245与FAIL也不改写。",
        f"旧数值物理门 {certificate_summary['numeric_physical_pass']}/20、旧literal band {certificate_summary['numeric_literal_band_pass']}/20，状态接受 {certificate_summary['frozen_status_accepted']}/20。精确binary64 literal合同 {certificate_summary['exact_binary64_literal_band_pass']}/20，精确十进制合同 {certificate_summary['exact_decimal_literal_band_pass']}/20；这些是不同判据。", "",
        "## 原目标证书与状态分离", "",
        "下表为加权Stage-B原目标单位，小数仅供阅读；完整分子/分母和经方向核对的binary64外包界见逐路径证据。f(w)−L是有符号候选诊断，不在精确可行性缺失时称为gap。不引入新最优性阈值。",
        "", "|ordinal|路径|保存状态|精确可行|严格L|候选f(w)|有符号f(w)−L|原stationarity最大值|", "|---|---|---|---|---|---|---|---|",
    ]
    for row in candidates:
        lines.append(f"|{row['solve_ordinal']}|{row['path']}|{row['original_status']}|{row['exact_original_qp_feasible']}|{display(row['strict_lower_bound'])}|{display(row['candidate_objective'])}|{display(row['candidate_objective_minus_lower_bound'])}|{display(row['original_stationarity_absolute_maximum'])}|")
    lines += ["", "完整case_id、站位分量索引、最小mu、盒证明状态、所有不可认证原因见candidate_audit.csv/jsonl。两路径不是独立科研样本；20个原始候选对应10个原始解相同的路径对，不支持不同最优解归因。", "",
        "## 证明和单位", "",
        "所有输入按保存binary64的精确有理数解释。原P/q/E/d/G/h分别取各自NPZ，不用生产替代参考；原目标常数从冻结Stage-B desired_task=None装配核实为0，而非把仿射常数直接当原常数。所有保存P系数原样使用。",
        "有限盒仅来自原约束：torque上下界、normal上下界、成对L1 friction行非负组合、经精确有理消元并验证的质量矩阵逆、按符号区间映射、实际fixed-task selector上下界交。每个最终盒面附原E行线性组合和原G行非负组合；下界例程独立重新检查84个盒面，不信任一个CERTIFIED标签。",
        "对保存对偶只做nu=s_eq*dual_eq与mu=s_ineq*dual_ineq；不再次乘D或R，不修补负mu。对角PSD的原P给出固定乘子盒上解析下确界：L=c−nuᵀd−muᵀh+Σ min_[ell_i,u_i](P_ii*t²/2+k_i*t)。任一原可行w在盒中且mu>=0，故L<=Lagrangian(w)<=f(w)，所以L<=f*。这本身不证明原QP非空，也不要求候选stationarity为0。",
        "主对象始终为保存original_witness；精确a+Rz仅为辅助舍入诊断。原stationarity、最终编码r_z及r_z−R*r_original精确分解为编码舍入项和逆映射舍入项；不能把不同单位solver residual/gap直接当原QP证书。",
        f"严格目标单位换算被证明的候选数：{sum(item['exact_objective_unit_conversion_proved'] for item in evidence_metrics)}/20。实际保存P系数与理想lambda/scale²的精确比例逐项核对；未证明共同精确比例时，除以0.001仅是标明舍入的诊断。Stage-A task objective与未加权torque regularizer分栏保存。", "",
        "## 最终编码端点", "",
        "全部490 NPZ各16条任务行均验证标签、selector、上下方向和最终A/b行顺序。三层端点并列保存：原G/h、行归一化前G/h、最终A/b并回映物理坐标。相对于binary64与十进制literal band的位置分别列出，不改变历史接受门。",
    ]
    for name, item in endpoints["maxima"].items():
        lines.append(f"- {name}：最大绝对差≈{display(item['maximum_absolute_error'])}；{item['case_id']} / {item['path']} / task{item['task_index']} / {item['side']}。")
    lines += ["", "这是有限精度表示误差审计，不宣称两个可行域完全相同；端点差异不自动解释AlmostSolved的因果机制。旧表示预算仅作来源对照，无新增/放宽阈值。", "",
        "## 无求解边界、测试与复现", "",
        f"最终合成无求解测试{tests_report['tests_run']}项通过；独立受保护进程完整回放20条保存候选，其摘要及完整精确证据逐项一致。分析计数20+回放20，与0个优化器构造、0次优化求解严格分开。490矩阵端点分析不是全面板求解。",
        "实际Clarabel/OSQP公共导出、native类构造/solve、已加载别名、19条冻结封装入口以及缓存Python/native调用有fail-fast拦截；静态AST检查与实际patch/blocked-attempt记录共同支持零求解。并非仅手写为0的字段，也不声称是对任意新加载原生代码的通用沙箱。",
        "首次冻结前集成测试发现嵌套防护重复安装导致7个测试setup错误；没有优化器调用。原失败记录保留pre_freeze_development，修正为同线程嵌套共享外层保护后重测。该修正发生在方法/代码hash冻结与保存证据批量计算之前，未改变数学方法、门槛或选择案例。",
        "首次freeze检查还记录根.gitattributes的来源LF与新checkout CRLF字节差异。只读核对全部771个基线文件后，确认唯一差异是这个非科研输入文件的逐字节LF→CRLF映射且来源等于Git blob；其余770文件字节相同，250项冻结输入和490项NPZ哈希不放宽。两份attributes都未改写；source manifest分别记录来源/checkout原字节hash。初次拦截日志保留，批量审计在成功冻结后才开始。",
        "测试/执行命令：", "", "```text",
        "python -X utf8 -m cavr_wbc.experiments.step02g --phase test",
        "python -X utf8 -m cavr_wbc.experiments.step02g --phase freeze",
        "python -X utf8 -m cavr_wbc.experiments.step02g --phase audit",
        "python -X utf8 -m cavr_wbc.experiments.step02g --phase replay",
        "python -X utf8 -m cavr_wbc.experiments.step02g --phase summarize", "```", "",
        "实际顺序、耗时、UTC时间、退出码、异常与每次边界覆盖在command_log.jsonl；依赖版本、代码/测试/协议SHA在AUDIT_IMPLEMENTATION_MANIFEST.json；所有源原字节SHA与Git blob在SOURCE_MANIFEST.json。未安装新后端、未联网、未运行F runner或旧全套求解测试。冻结后实现若变更必须另行版本记录；本交付变更记录以manifest为准。", "",
        "## 方法学风险扫描（experiment-agent validate）", "",
        "|风险|本次处理|", "|---|---|",
        "|Simpson's paradox|按状态/路径逐条列证据，不用总体通过率代替分组事实。|",
        "|Ecological fallacy|10个案例的矩阵证据不外推机器人群体或部署性能。|",
        "|Berkson's paradox|保存的10个回归来自F停止序列，非随机样本；无状态相关性推断。|",
        "|Collider bias|不在已执行/已接受条件下推断状态因果；包含2个拒收候选。|",
        "|Base-rate neglect|总范围36/245与已执行10、未执行26/245分别保留。|",
        "|Regression to the mean|无重试、无新求解，不能把诊断当性能改善。|",
        "|Survivorship bias|全部20候选、全部490表示纳入；不只报有证书项。|",
        "|Look-elsewhere effect|只用协议指定一种下界算法，不择优展示算法。|",
        "|Garden of forking paths|预先冻结已公开数据上的事后方法；不变更阈值/候选/目标。|",
        "|Correlation != causation|不把端点误差或stationarity归因为AlmostSolved根因。|",
        "|Reverse causality|保存状态不是误差形成方向的证据，不作反向因果叙述。|", "",
        "这是确定性精确证据核查，无p值、置信区间或统计功效推断；不用两路径扩大样本量。", "",
        "## 后续问题与停止", "",
        "若候选不满足精确等式，当前直接缺口是缺少可用的原QP严格可行候选，故无法由这些候选给出严格上界/gap；有下界并不能补上该缺口。下界是否足以支持下一阶段结论需另有明确目标与授权，当前没有新增最优性阈值。仅将这些证据交回科研审计，未执行任何候选/乘子修复或下一种方法。", "",
        f"工作树：{ROOT}；分支：{git(ROOT, 'branch', '--show-current')}；源提交：{BASE}。只新增evaluation审计模块、step02g入口、对应新测试、局部attributes和G工件；原控制器/solver/validator、模型、配置和历史实验文件不变。最终新增文件/状态见GIT_DELIVERY.json和交付commit；不push。", "",
        "STEP02F_RESULT_UNCHANGED = FAIL / REVISE", "SAVED_CANDIDATES_AUDITED = 20/20", "SAVED_REPRESENTATIONS_AUDITED = 490/490",
        "NEW_OPTIMIZER_CONSTRUCTIONS = 0", "NEW_OPTIMIZATION_SOLVE_CALLS = 0", "REMAINING_STEP02F_REGRESSIONS = NOT RUN",
        "STEP02F_FULL_PANEL = NOT RUN", "NEXT_SOLVE_AUTHORIZED = FALSE", "E1_AUTHORIZED = FALSE", "",
    ]
    (OUT / "STEP02G_REPORT.md").write_text("\n".join(lines), encoding="utf-8", newline="\n")
    (OUT / "EXECUTION_HANDOFF.md").write_text(
        "# STEP02G handoff\n\nANALYZED / AUDIT_COMPLETED; saved-evidence audit only. Read STEP02G_REPORT.md, STEP02G_RESULT.json, CERTIFICATE_SUMMARY.json, then candidate_audit.jsonl and linked exact evidence. All source and implementation hashes are frozen; artifact_hashes.json covers delivery bytes.\n\n"
        f"Worktree: {ROOT}\nBranch: {git(ROOT, 'branch', '--show-current')}\nBase: {BASE}\nResult commit: see delivery commit (self-reference omitted).\n\n"
        "20 candidates /10 paired cases;490 representations /245 cases;7840 endpoints. New scientific candidates:0. New optimizer constructions/solves:0. Exactlowerbound certificates do not imply primalfeasibility or experimental PASS. The two AlmostSolved statuses remain rejected.\n\n"
        "STEP02F_RESULT_UNCHANGED = FAIL / REVISE\nREMAINING_STEP02F_REGRESSIONS = NOT RUN\nSTEP02F_FULL_PANEL = NOT RUN\nNEXT_SOLVE_AUTHORIZED = FALSE\nE1_AUTHORIZED = FALSE\n",
        encoding="utf-8", newline="\n")
    return {"status": "AUDIT_COMPLETED", "certificate_summary": {key: value for key, value in certificate_summary.items() if key not in ("groups", "per_candidate_details")}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--phase", choices=("freeze", "test", "audit", "replay", "summarize"), required=True)
    args = parser.parse_args()
    start, began = time.perf_counter(), utc()
    log, outcome, exit_code, error = {}, {}, 0, None
    try:
        with optimizer_guard() as log:
            require(log["guard_installed"] and not log["patch_failures"], "Optimizer guard incomplete")
            outcome = {"freeze": freeze, "test": tests, "audit": audit, "replay": replay, "summarize": summarize}[args.phase]()
            require(not log["blocked_attempts"], "A prohibited optimizer entry was attempted")
    except BaseException as exc:
        exit_code = 1
        error = {"type": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()}
        print(error["traceback"], file=sys.stderr)
    duration = time.perf_counter() - start
    record = {"phase": args.phase, "command": f"python -X utf8 -m cavr_wbc.experiments.step02g --phase {args.phase}",
              "cwd": str(ROOT), "started_utc": began, "ended_utc": utc(), "elapsed_seconds": duration,
              "exit_code": exit_code, "outcome": outcome, "error": error, "optimizer_guard": log}
    append_jsonl(OUT / "command_log.jsonl", record)
    history = read_jsonl(OUT / "command_log.jsonl")
    write_json(OUT / "optimizer_call_audit.json", {
        "actual_optimizer_constructions": sum(row["optimizer_guard"].get("actual_constructions", 0) for row in history),
        "actual_optimization_solve_calls": sum(row["optimizer_guard"].get("actual_solve_calls", 0) for row in history),
        "blocked_optimizer_attempts": [item for row in history for item in row["optimizer_guard"].get("blocked_attempts", [])],
        "command_count": len(history), "command_log_sha256": sha256(OUT / "command_log.jsonl"),
        "all_command_guards_installed": all(row["optimizer_guard"].get("guard_installed", False) for row in history),
        "per_command_runtime_guard": [{"phase": row["phase"], "started_utc": row["started_utc"], "guard": row["optimizer_guard"]} for row in history],
        "static_check": static_check(implementation_files()),
        "boundary_scope": "Inspected installed backends and frozen wrapper routes; no F runner or new optimization code is executed.",
    })
    print(json.dumps({"phase": args.phase, "elapsed_seconds": duration, "exit_code": exit_code, "outcome": outcome}, ensure_ascii=False))
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
