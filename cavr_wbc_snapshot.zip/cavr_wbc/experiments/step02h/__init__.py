"""Bounded STEP02H exact primal certificate recovery; no original QP solves."""
