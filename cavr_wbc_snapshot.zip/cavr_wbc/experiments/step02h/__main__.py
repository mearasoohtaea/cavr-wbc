"""Bounded, persistent and single-pass H execution; replay never invokes an LP."""
from __future__ import annotations
import argparse
from fractions import Fraction
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback
import unittest

from cavr_wbc.evaluation.step02h_inputs import (
    ROOT, OUT, GF, VERSION, compact, exact_hash, write_compact, rational_decode,
    read_json, sha256, verify_hash, load_case, source_manifest, environment_lock,
    verify_sources, require, utc,
)
from cavr_wbc.evaluation.step02h_runtime import Ledger, auxiliary_optimizer_guard
from cavr_wbc.evaluation.step02h_verify import verify_g_evidence, verify_witness, binary64_export

LEDGER = OUT / 'recovery_call_ledger.jsonl'
WORKER_LIMIT = 300
BATCH_LIMIT = 3600


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    write_compact(path, value)


def read(path):
    return rational_decode(read_json(path))


def append(path, value):
    with Path(path).open('a', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(compact(value), ensure_ascii=False, separators=(',', ':'), allow_nan=False) + '\n')
        stream.flush()
        os.fsync(stream.fileno())


def exclusive(path, value):
    with Path(path).open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(compact(value), ensure_ascii=False, allow_nan=False) + '\n')
        stream.flush()
        os.fsync(stream.fileno())


def code_files():
    names = sorted(list((ROOT/'cavr_wbc/evaluation').glob('step02h_*.py')) +
                   list((ROOT/'cavr_wbc/experiments/step02h').glob('*.py')) +
                   list((ROOT/'tests/step02h').glob('*.py')))
    names += [OUT/'STEP02H_PROTOCOL.md', *sorted((OUT/'protocol').glob('*.md'))]
    return {str(path.relative_to(ROOT)).replace('\\', '/'): sha256(path) for path in names}


def check_code(manifest):
    for name, digest in manifest['files'].items():
        verify_hash(ROOT/name, digest)
    require(code_files() == manifest['files'], 'Frozen implementation file set/hash changed')


def check_environment():
    import sympy.solvers.simplex as simplex
    lock=read_json(OUT/'ENVIRONMENT_LOCK.json')
    require(Path(sys.prefix).resolve()==(ROOT/'.venv-step02h').resolve(), 'Wrong runtime prefix')
    verify_hash(simplex.__file__,lock['simplex_source_sha256'])
    require(environment_lock()==lock,'Dependency environment changed')


def guard_clean(log):
    old = log['original_guard']
    require(log['guard_installed'] and not log['blocked_attempts'] and not old['blocked_attempts'], 'Optimizer boundary violation')
    require(log['actual_original_stage_a_b_calls'] == 0 and log['actual_original_optimizer_constructions'] == 0, 'Original optimization forbidden')


def prepare():
    require(not (OUT/'SOURCE_MANIFEST.json').exists(), 'Preparation already exists; do not overwrite')
    save(OUT/'SOURCE_MANIFEST.json', source_manifest())
    save(OUT/'ENVIRONMENT_LOCK.json', environment_lock())
    cases, verifications = [], []
    with auxiliary_optimizer_guard() as boundary:
        for ordinal in range(1, 21):
            case, ge, _, _ = load_case(ordinal)
            verified = verify_g_evidence(case, ge)
            require(verified['verified'], f'G proof rejected ordinal{ordinal}: {verified}')
            path = OUT/f'auxiliary_lp_inputs/saved_{ordinal:02d}/original_input.json'
            save(path, case)
            cases.append({'solve_ordinal': ordinal, 'case_id': case['case_id'], 'path': case['path'],
                          'original_status': case['original_status'], 'input_file': str(path.relative_to(ROOT)).replace('\\','/'),
                          'input_file_sha256': sha256(path), 'exact_input_hash': exact_hash(case)})
            verifications.append({'solve_ordinal': ordinal, **verified})
            print(f'PREPARE ordinal={ordinal} G_EVIDENCE_VERIFIED', flush=True)
        guard_clean(boundary.log)
    save(OUT/'CASE_MANIFEST.json', {'order': list(range(1,21)), 'cases': cases, 'method': VERSION})
    save(OUT/'g_evidence_precheck.json', {'records': verifications, 'guard': boundary.log, 'optimization_calls': 0})


def pure_tests():
    require(not (OUT/'RUN_STARTED.json').exists(), 'No implementation test execution after real run begins')
    stamp = utc().replace(':', '').replace('.', '')
    testlog = io.StringIO()
    with auxiliary_optimizer_guard() as boundary:
        suite = unittest.defaultTestLoader.discover(str(ROOT/'tests/step02h'), pattern='test_*.py')
        result = unittest.TextTestRunner(stream=testlog, verbosity=2).run(suite)
        guard_clean(boundary.log)
        require(not boundary.log['allowed_calls'], 'Pure tests dispatched an LP')
    from cavr_wbc.evaluation.step02h_guard_tests import run_guard_selftests
    negative_guards=run_guard_selftests()
    text = testlog.getvalue()
    path = OUT/f'test_history/pure_{stamp}.txt'
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding='utf-8', newline='\n')
    report = {'utc': utc(), 'command': 'python -X utf8 -m cavr_wbc.experiments.step02h pure-tests',
              'tests_run': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
              'passed': result.wasSuccessful(), 'test_log': str(path.relative_to(ROOT)).replace('\\','/'),
              'test_log_sha256': sha256(path), 'implementation': code_files(),
              'optimization_calls': 0, 'guard': boundary.log, 'deliberate_negative_guard_tests':negative_guards,
              'scope': 'Only new H tests; all positive LP fixtures are separate and budgeted'}
    save(path.with_suffix('.json'), report)
    save(OUT/'pure_tests_latest.json', report)
    print(text, flush=True)
    require(result.wasSuccessful(), 'Preparation pure tests failed')


def sympy_exact(value):
    import sympy
    if value is None:
        return None
    if isinstance(value, Fraction):
        return sympy.Rational(value.numerator, value.denominator)
    if type(value) is int:
        return sympy.Integer(value)
    if isinstance(value, (tuple,list)):
        return [sympy_exact(item) for item in value]
    raise ValueError('Unexpected scalar at exact LP input boundary')


def worker(request_path):
    request = read(request_path)
    token, case_path = request['token'], ROOT/request['case_file']
    ledger = Ledger(LEDGER)
    destination = ROOT/request['directory']
    result = {'token': token, 'started_utc': utc(), 'status': 'ERROR', 'w_certificate': None, 't': None}
    started = time.perf_counter()
    boundary = None
    try:
        check_code(request['implementation'])
        check_environment()
        verify_hash(case_path, request['case_file_sha256'])
        case = read(case_path)
        require(exact_hash(case) == token['input_hash'], 'Reservation/input mismatch')
        ledger.note(token, 'WORKER_START', worker_pid=os.getpid())
        with auxiliary_optimizer_guard() as boundary:
            from cavr_wbc.evaluation.step02h_recovery import build_recovery_lp, backmap
            import sympy
            ledger.note(token, 'ELIMINATION_START')
            algebra_start = time.perf_counter()
            lp = build_recovery_lp(case, expected_rank=request['expected_rank'])
            ledger.note(token, 'ELIMINATION_FINISH', elapsed_seconds=time.perf_counter()-algebra_start,
                        dimensions=lp['dimensions'], verification=lp['elimination']['verification'])
            save(destination/'complete_lp.json', lp)
            lp_hash = sha256(destination/'complete_lp.json')
            ledger.note(token, 'LP_INPUT_SAVED', file=str((destination/'complete_lp.json').relative_to(ROOT)), sha256=lp_hash)
            c, A, b = (sympy_exact(lp[key]) for key in ('c','A','b'))
            bounds = [tuple(sympy_exact(pair)) for pair in lp['bounds']]
            objective, solution = boundary.linprog(ledger, token, c, A=A, b=b, bounds=bounds)
            result['backend_returned'] = True
            exact_return = lambda v: type(v) is int or isinstance(v,sympy.Rational)
            require(exact_return(objective) and all(exact_return(v) for v in solution), 'Returned nonexact backend scalar')
            # Frozen backend uses native integer0 for some nonbasic coordinates.
            # Accept exact integers directly, never coerce Float or approximate.
            returned_fraction = lambda v: Fraction(v) if type(v) is int else Fraction(int(v.p),int(v.q))
            solution = [returned_fraction(v) for v in solution]
            objective = returned_fraction(objective)
            require(len(solution)==len(lp['c']) and objective==solution[-1], 'Backend result shape/objective mismatch')
            w = backmap(lp, solution[:-1], solution[-1])
            result.update(status='BACKEND_RETURNED', w_certificate=w, t=solution[-1], z=solution[:-1],
                          auxiliary_objective=objective, lp_sha256=lp_hash, dimensions=lp['dimensions'])
            guard_clean(boundary.log)
    except BaseException as exc:
        name = type(exc).__name__
        result.update(exception_type=name, exception_message=str(exc), traceback=traceback.format_exc())
        result['status'] = ('SOLVER_REPORTED_INFEASIBLE / INCONCLUSIVE' if name == 'InfeasibleLPError' else
                            'RETURNED_WITNESS_INVALID' if result.get('backend_returned') and name == 'ValueError' else 'ERROR')
        # The first backend terminal receipt is immutable; this only fills a pre-entry failure.
        ledger.finish(token, result['status'], exception_type=name, exception_message=str(exc))
    finally:
        result['elapsed_seconds'] = time.perf_counter()-started
        result['finished_utc'] = utc()
        if boundary is not None:
            result['guard'] = boundary.log
        save(destination/'worker_result.json', result)
    print(json.dumps({'status': result['status'], 'elapsed_seconds': result['elapsed_seconds']}), flush=True)


def supervise(category, identity, case, path, implementation, expected_rank, remaining=BATCH_LIMIT):
    require(remaining>0,'No worker dispatch after resource budget is exhausted')
    ledger = Ledger(LEDGER)
    directory = path.parent
    token = ledger.reserve(category, identity, exact_hash(case))
    request = {'token': token, 'case_file': str(path.relative_to(ROOT)), 'case_file_sha256': sha256(path),
               'directory': str(directory.relative_to(ROOT)), 'implementation': implementation, 'expected_rank': expected_rank}
    save(directory/'worker_request.json', request)
    command = [sys.executable,'-X','utf8','-m','cavr_wbc.experiments.step02h','worker','--request',str(directory/'worker_request.json')]
    env = dict(os.environ)
    env.update(TMP=str(ROOT/'.step02h-local'),TEMP=str(ROOT/'.step02h-local'),PYTHONPYCACHEPREFIX=str(ROOT/'.step02h-local/pycache'))
    started = time.perf_counter()
    limit = min(WORKER_LIMIT, remaining)
    with (directory/'worker.log').open('x', encoding='utf-8') as stream:
        process = subprocess.Popen(command,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT,
                                   creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        try:
            exclusive(directory/'process.json', {'pid':process.pid,'utc':utc(),'command':command,'limit_seconds':limit,'token':token})
            while True:
                elapsed = time.perf_counter()-started
                if elapsed >= limit:
                    print(f'TIMEOUT termination scheduled: {category} {identity}, pid={process.pid}, elapsed={elapsed:.3f}',flush=True)
                    process.kill()
                    process.wait(timeout=10)
                    ledger.finish(token,'TIMEOUT / INCONCLUSIVE',elapsed_seconds=elapsed,
                                  actual_backend_entry_or_outcome_may_be_unknown=True,retry_allowed=False)
                    result = {'status':'TIMEOUT / INCONCLUSIVE','token':token,'elapsed_seconds':elapsed,'w_certificate':None,'t':None,
                              'reason':'Fixed worker/batch resource limit; no retry; does not prove original infeasibility'}
                    save(directory/'supervisor_timeout.json',result)
                    return result
                try:
                    process.wait(timeout=min(30,limit-elapsed))
                    break
                except subprocess.TimeoutExpired:
                    print(f'PROGRESS {category} {identity}: alive pid={process.pid}, {time.perf_counter()-started:.1f}s',flush=True)
        except BaseException:
            # Do not leave an unsupervised optimizer alive beyond its fixed limit.
            # This is scoped emergency worker cleanup, not a retry or early-stop heuristic.
            if process.poll() is None:
                print(f'SUPERVISION_LOST terminating owned worker pid={process.pid}; outcome remains consumed',flush=True)
                process.kill()
                process.wait(timeout=10)
            ledger.finish(token,'ATTEMPT_OUTCOME_UNKNOWN',reason='Supervisor failed; owned process terminated; no retry')
            raise
        if not (directory/'worker_result.json').exists():
            result={'status':'ERROR','token':token,'elapsed_seconds':time.perf_counter()-started,'w_certificate':None,'t':None,
                    'reason':'Worker exited without result; consumed reservation, no retry','exit_code':process.returncode}
            ledger.finish(token,'ATTEMPT_OUTCOME_UNKNOWN',exit_code=process.returncode)
            save(directory/'supervisor_error.json',result)
            return result
    result=read(directory/'worker_result.json')
    require(result['token']==token and process.returncode==0,'Worker result token/exit mismatch')
    result['supervisor_elapsed_seconds']=time.perf_counter()-started
    result['exit_code']=process.returncode
    return result


def fixture_checks(case, result, fixture):
    if fixture['expected_status'] == 'SOLVER_REPORTED_INFEASIBLE':
        return {'passed':result['status']=='SOLVER_REPORTED_INFEASIBLE / INCONCLUSIVE',
                'original_infeasibility_claim':False,'expected_auxiliary_intersection_exception':True}
    if result['status']!='BACKEND_RETURNED':
        return {'passed':False,'reason':result['status']}
    w,t=result['w_certificate'],result['t']
    dot=lambda a,b:sum((x*y for x,y in zip(a,b)),Fraction(0))
    gates={'equalities':all(dot(row,w)==rhs for row,rhs in zip(case['E'],case['d'])),
           'inequalities':all(dot(row,w)<=rhs for row,rhs in zip(case['G'],case['h'])),
           'box':all(lo<=v<=hi for lo,v,hi in zip(case['ell'],w,case['u'])),
           'distance':t>=0 and all(abs(v-s)<=t*d for v,s,d in zip(w,case['w_saved'],case['D'])),
           'literal':all(abs(dot(row,w)+bias-target)<=case['epsilon']*scale for row,bias,target,scale in zip(case['task_matrix'],case['task_bias'],case['target'],case['task_scales'])),
           'hand_known_distance':t==fixture['expected_t']}
    if fixture.get('expected_w') is not None:gates['hand_known_point']=w==fixture['expected_w']
    return {'passed':all(gates.values()),'gates':gates}


def fixtures():
    require(not (OUT/'RUN_STARTED.json').exists(), 'No new fixture calls after real batch starts')
    from cavr_wbc.evaluation.step02h_fixtures import fixtures as definitions
    plan=definitions()
    require(len(plan)==4,'Frozen synthetic plan expects exactly four calls')
    exclusive(OUT/'SYNTHETIC_PLAN.json',{'utc':utc(),'files':code_files(),'fixtures':plan,'maximum_calls':4})
    implementation={'files':code_files()}
    results=[]
    for fixture in plan:
        identity=fixture['identity']; case=fixture['case']
        path=OUT/f'auxiliary_lp_inputs/fixture_{identity}/original_input.json'
        save(path,case)
        result=supervise('synthetic_fixture',identity,case,path,implementation,fixture.get('expected_rank',len(case['E'])))
        check=fixture_checks(case,result,fixture)
        results.append({'identity':identity,'worker_status':result['status'],'verification':check})
        save(OUT/'synthetic_tests.json',{'results':results,'passed':all(row['verification']['passed'] for row in results),'complete':len(results)==4})
        print(f'SYNTHETIC {identity}: {result["status"]}, test_pass={check["passed"]}',flush=True)
        if not check['passed']:
            raise ValueError('Preparation synthetic test failed; no real calls authorized by test gate')


def freeze():
    require(not (OUT/'IMPLEMENTATION_MANIFEST.json').exists(),'Frozen implementation already exists')
    verify_sources()
    check_environment()
    tests=read_json(OUT/'pure_tests_latest.json'); synthetic=read_json(OUT/'synthetic_tests.json')
    require(tests['passed'] and tests['implementation']==code_files(),'Pure tests not current/passing')
    require(synthetic['complete'] and synthetic['passed'],'Synthetic tests not complete/passing')
    plan=read_json(OUT/'SYNTHETIC_PLAN.json')
    require(plan['files']==code_files(),'Synthetic-tested code changed before freeze')
    require(Ledger(LEDGER).snapshot()['categories']['saved_record']['reserved']==0,'Real calls already reserved')
    files=['SOURCE_MANIFEST.json','CASE_MANIFEST.json','ENVIRONMENT_LOCK.json','g_evidence_precheck.json','pure_tests_latest.json','synthetic_tests.json','SYNTHETIC_PLAN.json']
    manifest={'utc':utc(),'version':VERSION,'files':code_files(),'pre_run_artifact_hashes':{name:sha256(OUT/name) for name in files},
              'saved_case_order':list(range(1,21)),'budgets':{'saved_record':20,'synthetic_fixture':16},
              'worker_limit_seconds':WORKER_LIMIT,'real_batch_limit_seconds':BATCH_LIMIT,'ledger_before_real':Ledger(LEDGER).snapshot(),
              'post_hoc_not_preregistered':True,'E1_AUTHORIZED':False}
    exclusive(OUT/'IMPLEMENTATION_MANIFEST.json',manifest)
    print('IMPLEMENTATION_FROZEN '+sha256(OUT/'IMPLEMENTATION_MANIFEST.json'),flush=True)


def exported_numeric(case, problem, cfg, export):
    if export.get('w_binary64') is None:return export
    import numpy as np
    from cavr_wbc.evaluation.step02g_candidates import _reconstruct_validator_snapshot
    from cavr_wbc.control.scaled_fixed_support_qp import validate_original_witness
    snapshot,rho,_,_,_=_reconstruct_validator_snapshot(problem,cfg,case['case_id'].split('__')[1])
    w=np.asarray(export['w_binary64'],dtype=float)
    value=validate_original_witness(snapshot,rho,w[:18],w[18:30],w[30:],fixed_task_output=np.asarray([float(v) for v in case['target']]))
    limits={'dynamics_infinity_norm':cfg['validation']['dynamics_infinity_norm'],
            'contact_infinity_norm':cfg['validation']['contact_infinity_norm'],
            'hard_inequality_violation':cfg['validation']['hard_inequality_violation'],
            'health_adapter_identity_error':cfg['validation']['health_adapter_identity'],
            'fixed_task_normalized_infinity_error':cfg['objectives']['secondary_task_fix_normalized_tolerance']}
    gates={key:value[key]<=threshold for key,threshold in limits.items()}
    return {**export,'frozen_numeric_validator_not_run_here':False,'frozen_numeric_validation':value,'thresholds':limits,'numeric_gates':gates,
            'numeric_physical_pass':all(v for k,v in gates.items() if k!='fixed_task_normalized_infinity_error'),
            'numeric_band_pass':gates['fixed_task_normalized_infinity_error'],
            'status':'BINARY64_EXPORT_ACCEPTABLE' if all(gates.values()) and export['literal_binary64_band_pass'] else 'BINARY64_EXPORT_NOT_ACCEPTABLE',
            'new_solver_status':None,'f_status_unchanged':case['original_status']}


def run():
    manifest=read_json(OUT/'IMPLEMENTATION_MANIFEST.json');check_code(manifest)
    for name,digest in manifest['pre_run_artifact_hashes'].items():verify_hash(OUT/name,digest)
    verify_sources()
    check_environment()
    exclusive(OUT/'RUN_STARTED.json',{'utc':utc(),'implementation_sha256':sha256(OUT/'IMPLEMENTATION_MANIFEST.json'),'restart_or_retry_allowed':False})
    start=time.perf_counter();stop_reason=None
    cases=read_json(OUT/'CASE_MANIFEST.json')['cases']
    for item in cases:
        ordinal=item['solve_ordinal']
        row={**item,'recovery_status':'NOT RUN','U':None,'certified_gap_bound':None,'exact_feasible':False,'literal_pass':None,'export_status':'NOT RUN'}
        if stop_reason is None and time.perf_counter()-start>=BATCH_LIMIT:stop_reason='RESOURCE_LIMIT'
        if stop_reason is not None:
            row.update(recovery_status='NOT RUN_RESOURCE_LIMIT' if stop_reason=='RESOURCE_LIMIT' else 'NOT RUN',reason=stop_reason)
            append(OUT/'record_outcomes.jsonl',row);continue
        try:
            check_code(manifest);verify_hash(ROOT/item['input_file'],item['input_file_sha256'])
            case,ge,problem,cfg=load_case(ordinal)
            require(exact_hash(case)==item['exact_input_hash'],'Input changed since freeze')
            with auxiliary_optimizer_guard() as boundary:
                g=verify_g_evidence(case,ge);require(g['verified'],'G proof recheck failed')
                guard_clean(boundary.log)
            remaining=BATCH_LIMIT-(time.perf_counter()-start)
            if remaining<=0:
                stop_reason='RESOURCE_LIMIT'
                row.update(recovery_status='NOT RUN_RESOURCE_LIMIT',reason=stop_reason)
                append(OUT/'record_outcomes.jsonl',row)
                continue
            result=supervise('saved_record',ordinal,case,ROOT/item['input_file'],manifest,30,remaining)
            row.update(recovery_status=result['status'],L=case['L'],original_g_upper_bound=None,original_g_gap=None,
                       saved_candidate_objective_minus_L=case['saved_candidate_objective_minus_L'],elapsed_seconds=result['elapsed_seconds'])
            if result.get('guard') is not None:guard_clean(result['guard'])
            if result['status']=='BACKEND_RETURNED':
                witness={'solve_ordinal':ordinal,'case_id':case['case_id'],'path':case['path'],'w_certificate':result['w_certificate'],'t':result['t'],
                         'input_hash':item['exact_input_hash'],'original_witness_unchanged':True,'one_exact_backmap':True}
                witness_path=OUT/f'recovered_rational_witnesses/{ordinal:02d}.json';save(witness_path,witness)
                with auxiliary_optimizer_guard() as boundary:
                    verification=verify_witness(case,g,witness['w_certificate'],witness['t'])
                    append(OUT/'independent_verification.jsonl',{'solve_ordinal':ordinal,'input_hash':item['exact_input_hash'],'witness_sha256':sha256(witness_path),**verification})
                    row.update(recovery_status=verification['status'],U=verification['U'],certified_gap_bound=verification['certified_gap_bound'],
                               exact_feasible=verification.get('exact_equalities_pass',False) and verification.get('exact_original_inequalities_pass',False),
                               literal_pass=verification.get('literal_binary64_band_pass'),distance=verification.get('verified_scaled_linf_distance'),
                               t=witness['t'],verification_failures=verification['failures'])
                    export=exported_numeric(case,problem,cfg,binary64_export(case,witness['w_certificate']))
                    append(OUT/'binary64_export_checks.jsonl',{'solve_ordinal':ordinal,**export})
                    row['export_status']=export['status'];guard_clean(boundary.log)
                if not verification['certified']:stop_reason=verification['status']
            elif result['status'] not in ('SOLVER_REPORTED_INFEASIBLE / INCONCLUSIVE','TIMEOUT / INCONCLUSIVE'):
                stop_reason=result['status'];row['reason']=result.get('exception_message',result.get('reason'))
            append(OUT/'record_outcomes.jsonl',row)
            print(f'REAL ordinal={ordinal} status={row["recovery_status"]} total_elapsed={time.perf_counter()-start:.1f}s',flush=True)
        except BaseException as exc:
            stop_reason='IMPLEMENTATION_OR_INTEGRITY_ERROR'
            row.update(recovery_status='ERROR',reason=str(exc),traceback=traceback.format_exc())
            append(OUT/'record_outcomes.jsonl',row)
            print(f'STOP ordinal={ordinal}: {exc}',flush=True)
    save(OUT/'RUN_FINISHED.json',{'utc':utc(),'elapsed_seconds':time.perf_counter()-start,'stop_reason':stop_reason,'ledger':Ledger(LEDGER).snapshot()})


def replay():
    from cavr_wbc.evaluation.step02g_saved_certificates import read_jsonl
    manifest=read_json(OUT/'IMPLEMENTATION_MANIFEST.json');check_code(manifest)
    before=Ledger(LEDGER).snapshot();results=[]
    outcomes=read_jsonl(OUT/'record_outcomes.jsonl')
    require([row['solve_ordinal'] for row in outcomes]==list(range(1,21)), 'Replay requires complete fixed20 outcome rows')
    records=read_jsonl(OUT/'independent_verification.jsonl') if (OUT/'independent_verification.jsonl').exists() else []
    verified_ordinals=[row['solve_ordinal'] for row in records]
    witness_ordinals=sorted(int(path.stem) for path in (OUT/'recovered_rational_witnesses').glob('*.json'))
    require(sorted(verified_ordinals)==witness_ordinals and len(set(verified_ordinals))==len(records), 'Replay witness/verification coverage differs')
    require(all(row['solve_ordinal'] in verified_ordinals for row in outcomes if row['recovery_status']=='CERTIFIED_PRIMAL_WITNESS'), 'Certified outcome missing replay evidence')
    with auxiliary_optimizer_guard() as boundary:
        for record in records:
            ordinal=record['solve_ordinal'];case,ge,_,_=load_case(ordinal)
            path=OUT/f'recovered_rational_witnesses/{ordinal:02d}.json';verify_hash(path,record['witness_sha256'])
            witness=read(path)
            require(exact_hash(case)==record['input_hash']==witness['input_hash'],'Replay input identity')
            g=verify_g_evidence(case,ge);verification=verify_witness(case,g,witness['w_certificate'],witness['t'])
            saved=rational_decode(record)
            require(all(verification[key]==saved[key] for key in verification),'Replay differs')
            results.append({'solve_ordinal':ordinal,'status':verification['status'],'exact_replay_match':True})
        guard_clean(boundary.log)
    after=Ledger(LEDGER).snapshot();require(before==after,'Replay changed ledger')
    save(OUT/'verification_replay.json',{'utc':utc(),'records':results,'optimization_calls':0,'ledger_unchanged':True,'guard':boundary.log,'sources':verify_sources()})
    print(f'REPLAY saved_witnesses={len(results)} new_LP_calls=0',flush=True)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('phase',choices=['prepare','pure-tests','fixtures','freeze','run','replay','worker'])
    parser.add_argument('--request')
    args=parser.parse_args()
    entry={'phase':args.phase,'argv':sys.argv,'utc':utc(),'pid':os.getpid(),'files':code_files()}
    append(OUT/'command_log.jsonl',{'event':'START',**entry})
    try:
        if args.phase=='worker':worker(args.request)
        else:{'prepare':prepare,'pure-tests':pure_tests,'fixtures':fixtures,'freeze':freeze,'run':run,'replay':replay}[args.phase]()
    except BaseException as exc:
        append(OUT/'command_log.jsonl',{'event':'ERROR','phase':args.phase,'utc':utc(),'pid':os.getpid(),'exception':repr(exc)})
        raise
    else:
        append(OUT/'command_log.jsonl',{'event':'END','phase':args.phase,'utc':utc(),'pid':os.getpid()})


if __name__=='__main__':main()
