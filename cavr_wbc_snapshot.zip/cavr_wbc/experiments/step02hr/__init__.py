"""STEP02HR isolated execution entry; historical H entry is never executed."""
