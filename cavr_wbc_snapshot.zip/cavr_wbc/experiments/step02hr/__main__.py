"""Single-pass HR experiment; bounded workers and evidence-only replay."""
from __future__ import annotations
import argparse
from fractions import Fraction
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback
import unittest

from cavr_wbc.evaluation.step02hr_inputs import (
    ROOT, OUT, HF, VERSION, compact, exact_hash, write_compact, rational_decode,
    read_json, read_jsonl, sha256, verify_hash, load_case, fixtures as definitions,
    source_manifest, environment_lock, verify_sources, check_environment, require, utc,
)
from cavr_wbc.evaluation.step02hr_runtime import Ledger, auxiliary_optimizer_guard
from cavr_wbc.evaluation.step02hr_standard_form import adapt_standard_form, inverse_map
from cavr_wbc.evaluation.step02hr_standard_verify import verify_standard_form, verify_bound_proof
from cavr_wbc.evaluation.step02h_verify import verify_g_evidence, verify_witness, binary64_export

LEDGER=OUT/'recovery_call_ledger.jsonl'
WORKER_LIMIT=300
BATCH_LIMIT=3600


def save(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    write_compact(path,value)


def read(path):return rational_decode(read_json(path))


def append(path,value):
    with Path(path).open('a',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(compact(value),ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n')
        stream.flush();os.fsync(stream.fileno())


def exclusive(path,value):
    with Path(path).open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(compact(value),ensure_ascii=False,allow_nan=False)+'\n')
        stream.flush();os.fsync(stream.fileno())


def code_files():
    names=sorted(list((ROOT/'cavr_wbc/evaluation').glob('step02hr_*.py'))+
                 list((ROOT/'cavr_wbc/experiments/step02hr').glob('*.py'))+
                 list((ROOT/'tests/step02hr').glob('*.py')))
    names += [OUT/'STEP02HR_PROTOCOL.md',*sorted((OUT/'protocol').glob('*.md'))]
    return {str(path.relative_to(ROOT)).replace('\\','/'):sha256(path) for path in names}


def check_code(manifest):
    for name,digest in manifest['files'].items():verify_hash(ROOT/name,digest)
    require(code_files()==manifest['files'],'Frozen implementation file set/hash changed')


def guard_clean(log):
    old=log['original_guard']
    require(log['guard_installed'] and not log['blocked_attempts'] and not old['blocked_attempts'],'Optimizer boundary violation')
    require(log['actual_original_stage_a_b_calls']==0 and log['actual_original_optimizer_constructions']==0,'Original optimization forbidden')


def representation(case,destination,rank):
    from cavr_wbc.evaluation.step02h_recovery import build_recovery_lp
    old=build_recovery_lp(case,expected_rank=rank)
    standard=adapt_standard_form(old)
    proof=verify_standard_form(old,standard,case)
    save(destination/'complete_lp.json',old)
    save(destination/'standard_form.json',standard)
    save(destination/'equivalence_proof.json',proof)
    require(proof['verified'],'Independent standard proof rejected: '+str(proof))
    return old,standard,proof


def prepare():
    require(not (OUT/'SOURCE_MANIFEST.json').exists(),'Preparation exists; never overwrite')
    save(OUT/'SOURCE_MANIFEST.json',source_manifest())
    save(OUT/'ENVIRONMENT_LOCK.json',environment_lock())
    ledger=Ledger(LEDGER)
    save(OUT/'PRIOR_CALL_ACCOUNTING.json',{'prior_H_ledger_sha256':sha256(HF/'recovery_call_ledger.jsonl'),
         'prior_H_result_sha256':sha256(HF/'STEP02H_RESULT.json'),'prior_H_synthetic_calls':2,
         'prior_H_saved_record_calls':0,'maximum_new_synthetic':4,'maximum_new_saved_record':20,
         'maximum_new_total':24,'maximum_cumulative_synthetic_if_all_four_run':'6/16',
         'maximum_is_not_observed_count':True,'initial_HR_ledger_snapshot':ledger.snapshot()})
    cases=[]; verifications=[]; representations=[]
    with auxiliary_optimizer_guard() as boundary:
        for ordinal in range(1,21):
            case,ge,_,_=load_case(ordinal)
            verified=verify_g_evidence(case,ge)
            require(verified['verified'],f'G proof rejected ordinal{ordinal}: {verified}')
            path=OUT/f'standard_form_inputs/saved_{ordinal:02d}/original_input.json'
            save(path,case)
            old,std,proof=representation(case,path.parent,30)
            cases.append({'solve_ordinal':ordinal,'case_id':case['case_id'],'path':case['path'],
                          'original_status':case['original_status'],'input_file':str(path.relative_to(ROOT)).replace('\\','/'),
                          'input_file_sha256':sha256(path),'exact_input_hash':exact_hash(case),
                          'old_lp_hash':proof['old_lp_hash'],'standard_hash':proof['standard_hash'],
                          'standard_payload_hash':proof['standard_payload_hash'],'proof_sha256':proof['proof_sha256']})
            verifications.append({'solve_ordinal':ordinal,**verified})
            representations.append({'solve_ordinal':ordinal,'case_id':case['case_id'],'path':case['path'],
                                    'dimensions':proof['dimensions'],'proof_sha256':proof['proof_sha256'],'verified':True})
            print(f'PREPARE ordinal={ordinal} G_EVIDENCE_VERIFIED STANDARD_FORM_VERIFIED',flush=True)
        for fixture in definitions():
            path=OUT/f"standard_form_inputs/fixture_{fixture['identity']}/original_input.json"
            save(path,fixture['case'])
            representation(fixture['case'],path.parent,1)
        guard_clean(boundary.log);require(not boundary.log['allowed_calls'],'Preparation dispatched LP')
    save(OUT/'CASE_MANIFEST.json',{'order':list(range(1,21)),'cases':cases,'method':VERSION})
    save(OUT/'g_evidence_precheck.json',{'records':verifications,'guard':boundary.log,'optimization_calls':0})
    save(OUT/'representation_audit.json',{'records':representations,'saved_records_verified':20,'fixture_representations_verified':4,
         'guard':boundary.log,'optimization_calls':0,'error_budget':'Exact Fraction identities; algebraic error zero. Binary64 export checked separately without repair.'})


def pure_tests():
    require(not (OUT/'SYNTHETIC_PLAN.json').exists(),'No implementation testing/refinement after first solve freeze')
    stamp=utc().replace(':','').replace('.','');testlog=io.StringIO()
    with auxiliary_optimizer_guard() as boundary:
        suite=unittest.defaultTestLoader.discover(str(ROOT/'tests/step02hr'),pattern='test_*.py')
        result=unittest.TextTestRunner(stream=testlog,verbosity=2).run(suite)
        guard_clean(boundary.log);require(not boundary.log['allowed_calls'],'Pure tests dispatched LP')
    from cavr_wbc.evaluation.step02hr_runtime import run_guard_selftests
    negative_guards=run_guard_selftests()
    output=testlog.getvalue();path=OUT/f'test_history/pure_{stamp}.txt'
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(output,encoding='utf-8',newline='\n')
    report={'utc':utc(),'command':'python -B -X utf8 -m cavr_wbc.experiments.step02hr pure-tests',
            'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'passed':result.wasSuccessful(),
            'test_log':str(path.relative_to(ROOT)).replace('\\','/'),'test_log_sha256':sha256(path),
            'implementation':code_files(),'optimization_calls':0,'guard':boundary.log,'deliberate_negative_guard_tests':negative_guards,
            'scope':'New HR pure tests only; positive fixtures separate and budgeted'}
    save(path.with_suffix('.json'),report);save(OUT/'pure_tests.json',report)
    (OUT/'tests.txt').write_text(output,encoding='utf-8',newline='\n')
    print(output,flush=True);require(result.wasSuccessful(),'Preparation pure tests failed')


def sympy_exact(value):
    import sympy
    if isinstance(value,Fraction):return sympy.Rational(value.numerator,value.denominator)
    if type(value) is int:return sympy.Integer(value)
    if isinstance(value,(tuple,list)):return [sympy_exact(item) for item in value]
    raise ValueError('Nonexact scalar at backend input boundary')


def worker(request_path):
    request=read(request_path);token=request['token'];case_path=ROOT/request['case_file']
    ledger=Ledger(LEDGER);destination=ROOT/request['directory']
    result={'token':token,'started_utc':utc(),'status':'ERROR','w_certificate':None,'t':None}
    started=time.perf_counter();boundary=None
    try:
        check_code(request['implementation']);check_environment();verify_hash(case_path,request['case_file_sha256'])
        case=read(case_path);require(exact_hash(case)==token['input_hash'],'Reservation/input mismatch')
        ledger.note(token,'WORKER_START',worker_pid=os.getpid())
        with auxiliary_optimizer_guard() as boundary:
            import sympy
            from cavr_wbc.evaluation.step02h_recovery import build_recovery_lp
            ledger.note(token,'ELIMINATION_START');algebra_start=time.perf_counter()
            old=build_recovery_lp(case,expected_rank=request['expected_rank'])
            standard=adapt_standard_form(old);proof=verify_standard_form(old,standard,case)
            require(proof['verified'],'Worker representation proof failed')
            for name,value in [('complete_lp.json',old),('standard_form.json',standard),('equivalence_proof.json',proof)]:
                require(exact_hash(read(destination/name))==exact_hash(value),'Worker rebuilt representation changed: '+name)
            ledger.note(token,'ELIMINATION_FINISH',elapsed_seconds=time.perf_counter()-algebra_start,dimensions=standard['dimensions'],proof_sha256=proof['proof_sha256'])
            ledger.note(token,'LP_INPUT_SAVED',old_lp_hash=proof['old_lp_hash'],standard_hash=proof['standard_hash'],proof_sha256=proof['proof_sha256'])
            c,A,b=(sympy_exact(standard[key]) for key in ('c','A','b'))
            objective,solution=boundary.linprog(ledger,token,c,A=A,b=b,old_lp=old,standard_form=standard,proof=proof,physical_input=case)
            result['backend_returned']=True
            exact=lambda v:type(v) is int or isinstance(v,sympy.Rational)
            require(exact(objective) and all(exact(v) for v in solution),'Returned nonexact scalar')
            fraction=lambda v:Fraction(v) if type(v) is int else Fraction(int(v.p),int(v.q))
            solution=[fraction(v) for v in solution];objective=fraction(objective)
            result.update(raw_standard_solution=solution,auxiliary_objective=objective)
            require(len(solution)==len(c) and objective==solution[-1],'Backend shape/objective mismatch')
            result['standard_domain_pass']=all(v>=0 for v in solution)
            result['standard_rows_pass']=all(sum((a*v for a,v in zip(row,solution)),Fraction(0))<=rhs for row,rhs in zip(standard['A'],standard['b']))
            # Keep even an invalid exact point for the independent original-space
            # checker. A constructor flag never substitutes for that check.
            w=inverse_map(standard,solution[:-1],solution[-1])
            result.update(status='BACKEND_RETURNED',w_certificate=w,t=solution[-1],v=solution[:-1],
                          old_lp_hash=proof['old_lp_hash'],standard_hash=proof['standard_hash'],proof_sha256=proof['proof_sha256'],
                          dimensions=standard['dimensions'],exact_inverse_map_calls=1)
            guard_clean(boundary.log)
    except BaseException as exc:
        name=type(exc).__name__;result.update(exception_type=name,exception_message=str(exc),traceback=traceback.format_exc())
        result['status']=('SOLVER_REPORTED_INFEASIBLE / INCONCLUSIVE' if name=='InfeasibleLPError' else
                          'RETURNED_WITNESS_INVALID' if result.get('backend_returned') and name=='ValueError' else 'ERROR')
        ledger.finish(token,result['status'],exception_type=name,exception_message=str(exc))
    finally:
        result.update(elapsed_seconds=time.perf_counter()-started,finished_utc=utc())
        if boundary is not None:result['guard']=boundary.log
        save(destination/'worker_result.json',result)
    print(json.dumps({'status':result['status'],'elapsed_seconds':result['elapsed_seconds']}),flush=True)


def supervise(category,identity,case,path,implementation,expected_rank,remaining=BATCH_LIMIT):
    require(remaining>0,'No dispatch after resource budget');ledger=Ledger(LEDGER);directory=path.parent
    token=ledger.reserve(category,identity,exact_hash(case),case_id=case['case_id'],path=case['path'])
    request={'token':token,'case_file':str(path.relative_to(ROOT)),'case_file_sha256':sha256(path),
             'directory':str(directory.relative_to(ROOT)),'implementation':implementation,'expected_rank':expected_rank}
    save(directory/'worker_request.json',request)
    command=[sys.executable,'-B','-X','utf8','-m','cavr_wbc.experiments.step02hr','worker','--request',str(directory/'worker_request.json')]
    env=dict(os.environ);env.update(TMP=str(ROOT/'.step02hr-local'),TEMP=str(ROOT/'.step02hr-local'),PYTHONDONTWRITEBYTECODE='1')
    started=time.perf_counter();limit=min(WORKER_LIMIT,remaining);process=None
    with (directory/'worker.log').open('x',encoding='utf-8') as stream:
        try:
            process=subprocess.Popen(command,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT,
                                     creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            exclusive(directory/'process.json',{'pid':process.pid,'utc':utc(),'command':command,'limit_seconds':limit,'token':token})
            while True:
                elapsed=time.perf_counter()-started
                if elapsed>=limit:
                    print(f'TIMEOUT terminating owned worker {identity} pid={process.pid} elapsed={elapsed:.3f}',flush=True)
                    process.kill();process.wait(timeout=10)
                    ledger.finish(token,'TIMEOUT / INCONCLUSIVE',elapsed_seconds=elapsed,actual_backend_entry_or_outcome_may_be_unknown=True,retry_allowed=False)
                    result={'status':'TIMEOUT / INCONCLUSIVE','token':token,'elapsed_seconds':elapsed,'w_certificate':None,'t':None,
                            'reason':'Fixed worker/batch limit; no retry; not original infeasibility proof'}
                    save(directory/'supervisor_timeout.json',result);return result
                try:process.wait(timeout=min(30,limit-elapsed));break
                except subprocess.TimeoutExpired:print(f'PROGRESS {category} {identity}: alive pid={process.pid} {time.perf_counter()-started:.1f}s',flush=True)
        except BaseException:
            if process is not None and process.poll() is None:
                print(f'SUPERVISION_LOST terminating owned worker pid={process.pid}',flush=True)
                process.kill();process.wait(timeout=10)
            ledger.finish(token,'ATTEMPT_OUTCOME_UNKNOWN',reason='Supervisor failed; owned worker terminated; no retry')
            raise
        if not (directory/'worker_result.json').exists():
            result={'status':'ERROR','token':token,'elapsed_seconds':time.perf_counter()-started,'w_certificate':None,'t':None,
                    'reason':'Worker exited without result; consumed reservation','exit_code':process.returncode}
            ledger.finish(token,'ATTEMPT_OUTCOME_UNKNOWN',exit_code=process.returncode)
            save(directory/'supervisor_error.json',result);return result
    result=read(directory/'worker_result.json')
    require(result['token']==token and process.returncode==0,'Worker token/exit mismatch')
    result.update(supervisor_elapsed_seconds=time.perf_counter()-started,exit_code=process.returncode)
    return result


def fixture_checks(case,result,fixture):
    dot=lambda a,b:sum((x*y for x,y in zip(a,b)),Fraction(0))
    if fixture['expected_status']=='SOLVER_REPORTED_INFEASIBLE':
        w=fixture['original_feasible_witness']
        original=all(dot(r,w)==rhs for r,rhs in zip(case['E'],case['d'])) and all(dot(r,w)<=rhs for r,rhs in zip(case['G'],case['h']))
        contradiction=case['ell'][0]==1 and case['target']==[0] and case['epsilon']<1 and case['task_matrix']==[[1,0]]
        return {'passed':result['status']=='SOLVER_REPORTED_INFEASIBLE / INCONCLUSIVE' and original and contradiction,
                'hand_contradiction_checked':contradiction,'original_feasible_witness_checked':original,
                'original_infeasibility_claim':False,'hand_proof':fixture['hand_proof']}
    if result['status']!='BACKEND_RETURNED':return {'passed':False,'reason':result['status']}
    w,t=result['w_certificate'],result['t']
    gates={'equalities':all(dot(r,w)==rhs for r,rhs in zip(case['E'],case['d'])),
           'inequalities':all(dot(r,w)<=rhs for r,rhs in zip(case['G'],case['h'])),
           'box':all(lo<=v<=hi for lo,v,hi in zip(case['ell'],w,case['u'])),
           'distance':t>=0 and all(abs(v-s)<=t*d for v,s,d in zip(w,case['w_saved'],case['D'])),
           'literal':all(abs(dot(r,w)+bias-target)<=case['epsilon']*scale for r,bias,target,scale in zip(case['task_matrix'],case['task_bias'],case['target'],case['task_scales'])),
           'hand_known_distance':t==fixture['expected_t'],'hand_known_point':w==fixture['expected_w'],
           'standard_domain':result['standard_domain_pass'],'standard_rows':result['standard_rows_pass']}
    if fixture['prior_identity']=='h_fixture_02_negative_bounds':gates['known_standard_coordinates']=result['v']==[Fraction(3,2)]
    return {'passed':all(gates.values()),'gates':gates,'hand_proof':fixture['hand_proof'],'original_space_fraction_check':True}


def frozen_pre_inputs():
    names=['SOURCE_MANIFEST.json','CASE_MANIFEST.json','ENVIRONMENT_LOCK.json','PRIOR_CALL_ACCOUNTING.json',
           'g_evidence_precheck.json','representation_audit.json','pure_tests.json']
    files={name:sha256(OUT/name) for name in names}
    files.update({str(path.relative_to(OUT)).replace('\\','/'):sha256(path) for path in sorted((OUT/'standard_form_inputs').rglob('*.json'))})
    return files


def fixtures():
    require(not (OUT/'RUN_STARTED.json').exists(),'No fixture after real run')
    verify_sources();check_environment()
    tests=read_json(OUT/'pure_tests.json');require(tests['passed'] and tests['implementation']==code_files(),'Pure tests not current/passing')
    require(read_json(OUT/'CASE_MANIFEST.json')['order']==list(range(1,21)),'Case order changed')
    require(read_json(OUT/'representation_audit.json')['saved_records_verified']==20,'Representation gate incomplete')
    plan=definitions();require(len(plan)==4,'Four fixed fixtures only')
    manifest={'utc':utc(),'version':VERSION,'files':code_files(),'fixtures':plan,'maximum_new_calls':4,
              'prior_H_synthetic_calls':2,'maximum_new_saved_record_calls':20,'maximum_new_total':24,
              'worker_limit_seconds':WORKER_LIMIT,'real_batch_limit_seconds':BATCH_LIMIT,
              'pre_synthetic_artifact_hashes':frozen_pre_inputs(),'post_hoc_not_preregistered':True}
    exclusive(OUT/'SYNTHETIC_PLAN.json',manifest)
    results=[]
    for fixture in plan:
        identity=fixture['identity'];case=fixture['case'];check_code(manifest);check_environment()
        for name,digest in manifest['pre_synthetic_artifact_hashes'].items():verify_hash(OUT/name,digest)
        path=OUT/f'standard_form_inputs/fixture_{identity}/original_input.json'
        result=supervise('synthetic_fixture',identity,case,path,manifest,1)
        check=fixture_checks(case,result,fixture)
        if result.get('guard') is not None:
            try:guard_clean(result['guard'])
            except ValueError as exc:check.update(passed=False,guard_error=str(exc))
        results.append({'identity':identity,'prior_identity':fixture['prior_identity'],'input_hash':fixture['original_input_hash'],
                        'worker_status':result['status'],'verification':check})
        save(OUT/'synthetic_tests.json',{'results':results,'passed':all(row['verification']['passed'] for row in results),
             'complete':len(results)==4,'not_run':[f['identity'] for f in plan[len(results):]],'optimization_calls_from_persistent_ledger':True})
        print(f'SYNTHETIC {identity}: {result["status"]}, test_pass={check["passed"]}',flush=True)
        if not check['passed']:
            save(OUT/'PREPARATION_STOP.json',{'status':'PREPARATION_FAILED','utc':utc(),'failed_identity':identity,
                 'reason':check,'remaining_fixtures':'NOT RUN','real_records':'NOT RUN','further_solve_authorized':False})
            raise ValueError('Preparation synthetic gate failed; strict certificate branch stopped')


def freeze():
    require(not (OUT/'IMPLEMENTATION_MANIFEST.json').exists(),'Freeze exists; cannot overwrite')
    verify_sources();check_environment();tests=read_json(OUT/'pure_tests.json');synthetic=read_json(OUT/'synthetic_tests.json')
    plan=read_json(OUT/'SYNTHETIC_PLAN.json');check_code(plan)
    require(tests['passed'] and tests['implementation']==code_files(),'Pure tests stale')
    require(synthetic['complete'] and synthetic['passed'],'Four fixture gate not passed')
    for name,digest in plan['pre_synthetic_artifact_hashes'].items():verify_hash(OUT/name,digest)
    snapshot=Ledger(LEDGER).snapshot();require(snapshot['categories']['saved_record']['reserved']==0,'Real calls already reserved')
    files={name:sha256(OUT/name) for name in ['SYNTHETIC_PLAN.json','synthetic_tests.json',*plan['pre_synthetic_artifact_hashes']]}
    manifest={'utc':utc(),'version':VERSION,'files':code_files(),'pre_run_artifact_hashes':files,
              'saved_case_order':list(range(1,21)),'budgets':{'saved_record':20,'synthetic_fixture':4,'total':24},
              'worker_limit_seconds':WORKER_LIMIT,'real_batch_limit_seconds':BATCH_LIMIT,'ledger_before_real':snapshot,
              'real_run_authorized':True,'post_hoc_not_preregistered':True,'E1_AUTHORIZED':False}
    exclusive(OUT/'IMPLEMENTATION_MANIFEST.json',manifest)
    print('IMPLEMENTATION_FROZEN '+sha256(OUT/'IMPLEMENTATION_MANIFEST.json'),flush=True)


def exported_numeric(case,problem,cfg,export):
    if export.get('w_binary64') is None:return export
    import numpy as np
    from cavr_wbc.evaluation.step02g_candidates import _reconstruct_validator_snapshot
    from cavr_wbc.control.scaled_fixed_support_qp import validate_original_witness
    snapshot,rho,_,_,_=_reconstruct_validator_snapshot(problem,cfg,case['case_id'].split('__')[1])
    w=np.asarray(export['w_binary64'],dtype=float)
    value=validate_original_witness(snapshot,rho,w[:18],w[18:30],w[30:],fixed_task_output=np.asarray([float(v) for v in case['target']]))
    limits={'dynamics_infinity_norm':cfg['validation']['dynamics_infinity_norm'],
            'contact_infinity_norm':cfg['validation']['contact_infinity_norm'],
            'hard_inequality_violation':cfg['validation']['hard_inequality_violation'],
            'health_adapter_identity_error':cfg['validation']['health_adapter_identity'],
            'fixed_task_normalized_infinity_error':cfg['objectives']['secondary_task_fix_normalized_tolerance']}
    gates={key:value[key]<=threshold for key,threshold in limits.items()}
    return {**export,'frozen_numeric_validator_not_run_here':False,'frozen_numeric_validation':value,'thresholds':limits,'numeric_gates':gates,
            'numeric_physical_pass':all(v for k,v in gates.items() if k!='fixed_task_normalized_infinity_error'),
            'numeric_band_pass':gates['fixed_task_normalized_infinity_error'],
            'status':'BINARY64_EXPORT_ACCEPTABLE' if all(gates.values()) and export['literal_binary64_band_pass'] else 'BINARY64_EXPORT_NOT_ACCEPTABLE',
            'new_solver_status':None,'f_status_unchanged':case['original_status']}


def run():
    manifest=read_json(OUT/'IMPLEMENTATION_MANIFEST.json');check_code(manifest)
    require(manifest.get('real_run_authorized') is True,'Real gate closed')
    for name,digest in manifest['pre_run_artifact_hashes'].items():verify_hash(OUT/name,digest)
    verify_sources();check_environment()
    exclusive(OUT/'RUN_STARTED.json',{'utc':utc(),'implementation_sha256':sha256(OUT/'IMPLEMENTATION_MANIFEST.json'),'restart_or_retry_allowed':False})
    start=time.perf_counter();stop_reason=None
    for item in read_json(OUT/'CASE_MANIFEST.json')['cases']:
        ordinal=item['solve_ordinal']
        row={**item,'recovery_status':'NOT RUN','U':None,'certified_gap_bound':None,'exact_feasible':None,'literal_pass':None,'export_status':'NOT RUN'}
        if stop_reason is None and time.perf_counter()-start>=BATCH_LIMIT:stop_reason='RESOURCE_LIMIT'
        if stop_reason is not None:
            row.update(recovery_status='NOT RUN_RESOURCE_LIMIT' if stop_reason=='RESOURCE_LIMIT' else 'NOT RUN',reason=stop_reason)
            append(OUT/'record_outcomes.jsonl',row);continue
        try:
            check_code(manifest);check_environment();verify_hash(ROOT/item['input_file'],item['input_file_sha256'])
            case,ge,problem,cfg=load_case(ordinal);require(exact_hash(case)==item['exact_input_hash'],'Input changed')
            with auxiliary_optimizer_guard() as boundary:
                g=verify_g_evidence(case,ge);require(g['verified'],'G proof recheck failed');guard_clean(boundary.log)
            remaining=BATCH_LIMIT-(time.perf_counter()-start)
            if remaining<=0:
                stop_reason='RESOURCE_LIMIT';row.update(recovery_status='NOT RUN_RESOURCE_LIMIT',reason=stop_reason)
                append(OUT/'record_outcomes.jsonl',row);continue
            result=supervise('saved_record',ordinal,case,ROOT/item['input_file'],manifest,30,remaining)
            row.update(recovery_status=result['status'],L=case['L'],original_g_upper_bound=None,original_g_gap=None,
                       saved_candidate_objective_minus_L=case['saved_candidate_objective_minus_L'],elapsed_seconds=result['elapsed_seconds'])
            if result.get('guard') is not None:guard_clean(result['guard'])
            if result['status']=='BACKEND_RETURNED':
                witness={'solve_ordinal':ordinal,'case_id':case['case_id'],'path':case['path'],'w_certificate':result['w_certificate'],'t':result['t'],
                         'input_hash':item['exact_input_hash'],'original_witness_unchanged':True,'one_exact_backmap':True}
                witness_path=OUT/f'recovered_rational_witnesses/{ordinal:02d}.json';save(witness_path,witness)
                with auxiliary_optimizer_guard() as boundary:
                    verification=verify_witness(case,g,witness['w_certificate'],witness['t'])
                    require(not verification['certified'] or (result['standard_domain_pass'] and result['standard_rows_pass']),
                            'Independent original-space and standard-form checks disagree')
                    append(OUT/'independent_verification.jsonl',{'solve_ordinal':ordinal,'input_hash':item['exact_input_hash'],'witness_sha256':sha256(witness_path),**verification})
                    row.update(recovery_status=verification['status'],U=verification['U'],certified_gap_bound=verification['certified_gap_bound'],
                               exact_feasible=verification.get('exact_equalities_pass',False) and verification.get('exact_original_inequalities_pass',False),
                               literal_pass=verification.get('literal_binary64_band_pass'),distance=verification.get('verified_scaled_linf_distance'),
                               t=witness['t'],verification_failures=verification['failures'])
                    export=exported_numeric(case,problem,cfg,binary64_export(case,witness['w_certificate']))
                    append(OUT/'binary64_export_checks.jsonl',{'solve_ordinal':ordinal,**export});row['export_status']=export['status'];guard_clean(boundary.log)
                if not verification['certified']:stop_reason=verification['status']
            elif result['status'] not in ('SOLVER_REPORTED_INFEASIBLE / INCONCLUSIVE','TIMEOUT / INCONCLUSIVE'):
                stop_reason=result['status'];row['reason']=result.get('exception_message',result.get('reason'))
            append(OUT/'record_outcomes.jsonl',row)
            print(f'REAL ordinal={ordinal} status={row["recovery_status"]} elapsed={time.perf_counter()-start:.1f}s',flush=True)
        except BaseException as exc:
            stop_reason='IMPLEMENTATION_OR_INTEGRITY_ERROR';row.update(recovery_status='ERROR',reason=str(exc),traceback=traceback.format_exc())
            append(OUT/'record_outcomes.jsonl',row);print(f'STOP ordinal={ordinal}: {exc}',flush=True)
    save(OUT/'RUN_FINISHED.json',{'utc':utc(),'elapsed_seconds':time.perf_counter()-start,'stop_reason':stop_reason,'ledger':Ledger(LEDGER).snapshot()})


def replay():
    manifest=read_json(OUT/('IMPLEMENTATION_MANIFEST.json' if (OUT/'IMPLEMENTATION_MANIFEST.json').exists() else 'SYNTHETIC_PLAN.json'))
    check_code(manifest);before=Ledger(LEDGER).snapshot();results=[];proofs=[]
    records=read_jsonl(OUT/'independent_verification.jsonl') if (OUT/'independent_verification.jsonl').exists() else []
    witness_ordinals=sorted(int(path.stem) for path in (OUT/'recovered_rational_witnesses').glob('*.json'))
    require(sorted(row['solve_ordinal'] for row in records)==witness_ordinals and len(witness_ordinals)==len(records),'Witness/verification coverage')
    if (OUT/'RUN_STARTED.json').exists():
        outcomes=read_jsonl(OUT/'record_outcomes.jsonl')
        require([row['solve_ordinal'] for row in outcomes]==list(range(1,21)),'Fixed20 outcome coverage')
        require(all(row['solve_ordinal'] in witness_ordinals for row in outcomes if row['recovery_status']=='CERTIFIED_PRIMAL_WITNESS'),'Certified outcome missing witness')
    else:require(not records and not witness_ordinals,'Cannot introduce recovered witness when real gate closed')
    with auxiliary_optimizer_guard() as boundary:
        for path in sorted((OUT/'standard_form_inputs').glob('*/equivalence_proof.json')):
            old=read(path.parent/'complete_lp.json');std=read(path.parent/'standard_form.json');case=read(path.parent/'original_input.json')
            proof=read(path);require(verify_bound_proof(proof,old,std,case),'Saved coefficient proof replay mismatch')
            proofs.append({'input':str(path.parent.relative_to(OUT)),'proof_sha256':proof['proof_sha256'],'verified':True})
        for record in records:
            ordinal=record['solve_ordinal'];case,ge,_,_=load_case(ordinal)
            path=OUT/f'recovered_rational_witnesses/{ordinal:02d}.json';verify_hash(path,record['witness_sha256']);witness=read(path)
            require(exact_hash(case)==record['input_hash']==witness['input_hash'],'Replay input mismatch')
            g=verify_g_evidence(case,ge);verification=verify_witness(case,g,witness['w_certificate'],witness['t']);saved=rational_decode(record)
            require(all(verification[key]==saved[key] for key in verification),'Original-space replay differs')
            results.append({'solve_ordinal':ordinal,'status':verification['status'],'exact_replay_match':True})
        guard_clean(boundary.log);require(not boundary.log['allowed_calls'],'Replay dispatched LP')
    require(before==Ledger(LEDGER).snapshot(),'Replay changed ledger')
    save(OUT/'verification_replay.json',{'utc':utc(),'records':results,'standard_proofs':proofs,'optimization_calls':0,'ledger_unchanged':True,
                                       'guard':boundary.log,'sources':verify_sources()})
    print(f'REPLAY witnesses={len(results)} representation_proofs={len(proofs)} new_LP_calls=0',flush=True)


def main():
    (ROOT/'.step02hr-local').mkdir(exist_ok=True)
    parser=argparse.ArgumentParser();parser.add_argument('phase',choices=['prepare','pure-tests','fixtures','freeze','run','replay','worker','deliver'])
    parser.add_argument('--request');args=parser.parse_args()
    append(OUT/'command_log.jsonl',{'event':'START','phase':args.phase,'argv':sys.argv,'utc':utc(),'pid':os.getpid(),'files':code_files()})
    try:
        if args.phase=='worker':worker(args.request)
        elif args.phase=='deliver':
            from cavr_wbc.experiments.step02hr.delivery import main as deliver
            deliver()
        else:{'prepare':prepare,'pure-tests':pure_tests,'fixtures':fixtures,'freeze':freeze,'run':run,'replay':replay}[args.phase]()
    except BaseException as exc:
        append(OUT/'command_log.jsonl',{'event':'ERROR','phase':args.phase,'utc':utc(),'pid':os.getpid(),'exception':repr(exc)});raise
    else:
        append(OUT/'command_log.jsonl',{'event':'END','phase':args.phase,'utc':utc(),'pid':os.getpid()})
        if args.phase=='deliver':
            # Finalize after this command's END receipt, so the log hash is not
            # stale at delivery. Only the self manifest and Git metadata exempt.
            excluded={'artifact_hashes.json','GIT_DELIVERY.json'}
            files={str(path.relative_to(ROOT)).replace('\\','/'):sha256(path)
                   for path in sorted(OUT.rglob('*')) if path.is_file() and path.name not in excluded}
            save(OUT/'artifact_hashes.json',{'files':files,'file_count':len(files),'excluded_basename':sorted(excluded),
                 'exclusion_reason':'Self-referential manifest and post-commit Git delivery metadata','generated_utc':utc()})


if __name__=='__main__':main()
