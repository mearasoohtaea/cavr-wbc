"""Reporting-only HR delivery from persisted evidence; never runs an optimizer.

No historical runner/delivery entry is imported.  Existing ledgers are read,
not initialized, reserved, or dispatched.  All generated paths stay in HR OUT.
"""

from collections import Counter
import csv
from decimal import Context, Decimal, ROUND_CEILING, ROUND_FLOOR
from fractions import Fraction
import json
from pathlib import Path

from cavr_wbc.evaluation.step02hr_inputs import (
    ROOT, OUT, GF, HF, BASE, VERSION, CONFIG_SHA, compact, rational_decode,
    read_json, write_compact, sha256, utc, git, verify_sources,
)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path, default=None):
    return rational_decode(read_json(path)) if Path(path).exists() else default


def lines(path):
    if not Path(path).exists():
        return []
    with Path(path).open(encoding="utf-8") as stream:
        return [rational_decode(json.loads(line)) for line in stream if line.strip()]


def save(name, value):
    path = OUT / name
    require(path.resolve().is_relative_to(OUT.resolve()), "Delivery path escapes HR output")
    path.parent.mkdir(parents=True, exist_ok=True)
    write_compact(path, value)


def write_text(name, value):
    path = OUT / name
    require(path.resolve().is_relative_to(OUT.resolve()), "Delivery text path escapes HR output")
    path.write_text(value, encoding="utf-8", newline="\n")


def indexed(records, name):
    result = {}
    for record in records:
        ordinal = record["solve_ordinal"]
        require(type(ordinal) is int and 1 <= ordinal <= 20 and ordinal not in result,
                "Duplicate/out-of-range ordinal in " + name)
        result[ordinal] = record
    return result


def decimal_bounds(value, precision=18):
    if value is None:
        return None
    require(isinstance(value, Fraction), "Reporting values must retain exact Fraction encoding")
    lo = Context(prec=precision, rounding=ROUND_FLOOR).divide(Decimal(value.numerator), Decimal(value.denominator))
    hi = Context(prec=precision, rounding=ROUND_CEILING).divide(Decimal(value.numerator), Decimal(value.denominator))
    require(Fraction(lo) <= value <= Fraction(hi), "Outward display direction check failed")
    return {"lower_decimal": str(lo), "upper_decimal": str(hi),
            "significant_digits": precision, "outward_directions_checked": True}


def display(value):
    if value is None:
        return "null"
    bounds = decimal_bounds(value)
    return bounds["lower_decimal"] if bounds["lower_decimal"] == bounds["upper_decimal"] else \
        f"[{bounds['lower_decimal']}, {bounds['upper_decimal']}]"


def read_ledger():
    # Constructor creates GENESIS for missing paths, so never instantiate it
    # when reporting a preparation failure before HR ledger initialization.
    from cavr_wbc.evaluation.step02hr_runtime import Ledger, prior_call_accounting
    path = OUT / "recovery_call_ledger.jsonl"
    if path.exists():
        ledger = Ledger(path)
        return ledger.snapshot(), ledger.events()
    prior = prior_call_accounting()
    return {"prior": prior, "categories": {name: {"limit": limit, "reserved": 0,
                "linprog_started": 0, "finished": 0, "confirmed_calls": 0, "unknown_call_upper_bound": 0}
            for name, limit in (("saved_record", 20), ("synthetic_fixture", 4))},
            "attempts": [], "total_reserved": 0, "total_linprog_started": 0,
            "new_calls_lower_bound": 0, "new_calls_upper_bound": 0,
            "h_plus_hr_calls_lower_bound": 2, "h_plus_hr_calls_upper_bound": 2,
            "h_plus_hr_synthetic_calls_lower_bound": 2, "h_plus_hr_synthetic_calls_upper_bound": 2,
            "ledger_sha256": None, "ledger_not_created_by_reporting": True}, []


def call_accounting(snapshot, events):
    """Independently distinguish reservations, dispatch intentions and receipts."""
    prior = snapshot["prior"]
    require(prior["historical_synthetic_confirmed_calls"] == 2
            and prior["historical_saved_record_confirmed_calls"] == 0
            and prior["historical_unknown_calls"] == 0, "Historical H call accounting changed")
    categories, attempts = {}, []
    for category in ("saved_record", "synthetic_fixture"):
        reserved = [row for row in events if row["event"] == "RESERVED" and row["token"]["category"] == category]
        confirmed = unknown = dispatches = pending = 0
        for event in reserved:
            token = event["token"]
            related = [row for row in events if row.get("token") is not None
                       and row["token"]["reservation_id"] == token["reservation_id"]]
            require(all(row["token"] == token for row in related), "Immutable reservation association changed")
            starts = [row for row in related if row["event"] == "LINPROG_STARTED"]
            terminals = [row for row in related if row["event"] == "FINISHED"]
            require(len(starts) <= 1 and len(terminals) <= 1, "Repeated attempt or terminal in ledger")
            metadata = terminals[0]["metadata"] if terminals else {}
            receipt = metadata.get("receipt")
            entries = receipt.get("top_level_entries") if receipt else None
            require(entries in (None, 0, 1), "Unsupported backend top-level entry count")
            if receipt:
                require(all(receipt.get(key) == token[key] for key in token), "Receipt does not bind full HR token")
                require(bool(starts), "Backend receipt without durable dispatch intention")
            is_unknown = bool(starts) and receipt is None
            confirmed += int(entries == 1)
            unknown += int(is_unknown)
            dispatches += bool(starts)
            pending += int(not starts and not terminals)
            attempts.append({"token": token, "dispatch_intent_recorded": bool(starts),
                             "terminal_status": metadata.get("status", "ATTEMPT_OUTCOME_UNKNOWN"),
                             "confirmed_top_level_entries": entries, "actual_backend_entry_unknown": is_unknown,
                             "outcome_unknown": not terminals or metadata.get("status") == "ATTEMPT_OUTCOME_UNKNOWN" or is_unknown,
                             "receipt": receipt, "reservation_consumed": True, "retry_allowed": False})
        saved = snapshot["categories"][category]
        require((len(reserved), dispatches, confirmed, unknown) ==
                (saved["reserved"], saved["linprog_started"], saved["confirmed_calls"], saved["unknown_call_upper_bound"]),
                "Independent receipt aggregation differs from HR ledger snapshot")
        categories[category] = {"budget": saved["limit"], "reservations_consumed": len(reserved),
            "durable_dispatch_intents": dispatches, "confirmed_backend_entries": confirmed,
            "dispatches_without_terminal_receipt": unknown, "pending_reservations_before_dispatch": pending,
            "actual_call_count": confirmed if not unknown else None,
            "actual_call_count_lower_bound": confirmed, "actual_call_count_upper_bound": confirmed + unknown}
    lo = sum(row["actual_call_count_lower_bound"] for row in categories.values())
    hi = sum(row["actual_call_count_upper_bound"] for row in categories.values())
    slo, shi = (categories["synthetic_fixture"][key] for key in ("actual_call_count_lower_bound", "actual_call_count_upper_bound"))
    require((lo, hi, lo + 2, hi + 2, slo + 2, shi + 2) ==
            tuple(snapshot[key] for key in ("new_calls_lower_bound", "new_calls_upper_bound", "h_plus_hr_calls_lower_bound",
                "h_plus_hr_calls_upper_bound", "h_plus_hr_synthetic_calls_lower_bound", "h_plus_hr_synthetic_calls_upper_bound")),
            "Cumulative historical/new call accounting differs")
    require(categories["saved_record"]["reservations_consumed"] <= 20
            and categories["synthetic_fixture"]["reservations_consumed"] <= 4, "HR budget exceeded")
    return {"prior_H": prior, "categories": categories, "attempts": attempts,
        "total_actual_call_count": lo if lo == hi else None,
        "total_actual_call_count_lower_bound": lo, "total_actual_call_count_upper_bound": hi,
        "h_plus_hr_actual_call_count": lo + 2 if lo == hi else None,
        "h_plus_hr_actual_call_count_lower_bound": lo + 2, "h_plus_hr_actual_call_count_upper_bound": hi + 2,
        "h_plus_hr_synthetic_actual_call_count": slo + 2 if slo == shi else None,
        "h_plus_hr_synthetic_actual_call_count_lower_bound": slo + 2, "h_plus_hr_synthetic_actual_call_count_upper_bound": shi + 2,
        "total_reservations_consumed": snapshot["total_reserved"], "ledger_sha256": snapshot["ledger_sha256"],
        "ledger_hash_chain_validated": snapshot["ledger_sha256"] is not None,
        "reporting_new_optimization_calls": 0,
        "interpretation": "A reservation consumes budget but is not a call; missing terminal receipts after dispatch retain an actual-call interval. Historical H's two calls remain included. No retry is authorized."}


def build_rows(g_records, outcomes, verifications, exports, counts, case_records=None, preparation_failed=False):
    g_rows = indexed(g_records, "historical G")
    require(set(g_rows) == set(range(1, 21)), "Historical fixed scope must contain exactly 20 ordinals")
    outcome_rows, verification_rows, export_rows = (indexed(rows, label) for rows, label in
        ((outcomes, "HR outcomes"), (verifications, "HR verification"), (exports, "HR export")))
    cases = indexed(case_records or [], "case manifest")
    if cases:
        require(set(cases) == set(g_rows), "Case manifest coverage differs from fixed 20")
    attempts = {row["token"]["identity"]: row for row in counts["attempts"] if row["token"]["category"] == "saved_record"}
    if preparation_failed:
        require(not attempts and not verification_rows and not export_rows, "Preparation failure cannot contain real recovery/certificates")
    rows = []
    for ordinal in range(1, 21):
        g = g_rows[ordinal]
        require(g["strict_primal_upper_bound"] is None and g["strict_optimality_gap"] is None, "Original G null history changed")
        outcome, verification, export, attempt = (mapping.get(ordinal) for mapping in
            (outcome_rows, verification_rows, export_rows, attempts))
        for item in (outcome, cases.get(ordinal)):
            if item:
                require(item["case_id"] == g["case_id"] and item["path"] == g["path"], "Ordinal/case/path delivery association mismatch")
        if attempt:
            require(attempt["token"]["case_id"] == g["case_id"] and attempt["token"]["path"] == g["path"], "Attempt belongs to another physical record")
        if verification and cases:
            require(verification["input_hash"] == cases[ordinal]["exact_input_hash"], "Verification input hash belongs to another case")
        status = outcome["recovery_status"] if outcome else "ATTEMPT_OUTCOME_UNKNOWN" if attempt else "NOT RUN"
        if preparation_failed:
            require(status == "NOT RUN", "Preparation failure contains attempted saved record")
        certified = bool(verification and verification.get("certified") and verification.get("status") == "CERTIFIED_PRIMAL_WITNESS")
        L = g["strict_lower_bound"]
        require(isinstance(L, Fraction), "Historical lower bound is not exact")
        if certified:
            U, gap = verification["U"], verification["certified_gap_bound"]
            require(isinstance(U, Fraction) and isinstance(gap, Fraction) and U >= L and gap == U - L,
                    "CERTIFICATE_INCONSISTENCY: exact original objective interval invalid")
            require(verification["L"] == L and status == "CERTIFIED_PRIMAL_WITNESS", "Saved lower bound or certificate status differs")
            require(verification.get("exact_equalities_pass") and verification.get("exact_original_inequalities_pass")
                    and verification.get("literal_binary64_band_pass") and verification.get("gates")
                    and all(verification["gates"].values()), "Claimed certificate has a failed independent exact gate")
        else:
            U = gap = None
            require(status != "CERTIFIED_PRIMAL_WITNESS", "Certified outcome lacks independent verification")
            require(not verification or (verification.get("U") is None and verification.get("certified_gap_bound") is None),
                    "Uncertified record claims a new strict upper bound/gap")
        if outcome:
            require(outcome.get("U") == U and outcome.get("certified_gap_bound") == gap, "Outcome/verification upper bound or gap disagreement")
        distance = verification.get("verified_scaled_linf_distance") if verification else None
        row = {"solve_ordinal": ordinal, "case_id": g["case_id"], "path": g["path"],
            "original_f_status": g["original_status"],
            "original_f_numeric_physical_pass": g.get("frozen_numeric_physical_pass"),
            "original_f_literal_band_pass": g.get("frozen_literal_band_pass"),
            "original_f_status_accepted": g.get("frozen_status_accepted"),
            "original_g_exact_qp_feasible": g.get("exact_original_qp_feasible"),
            "original_g_L": L, "original_g_L_is_historical": True, "new_lower_bound_computed": False,
            "original_g_primal_upper_bound": None, "original_g_optimality_gap": None,
            "original_saved_candidate_objective": g["candidate_objective"],
            "original_saved_candidate_objective_minus_L_diagnostic": g["candidate_objective_minus_lower_bound"],
            "recovery_status": status, "rational_witness_certified": certified,
            "exact_original_qp_feasible": bool(verification.get("exact_equalities_pass") and verification.get("exact_original_inequalities_pass")) if verification else None,
            "literal_binary64_pass": verification.get("literal_binary64_band_pass") if verification else None,
            "decimal_band_report_only_pass": verification.get("decimal_band_report_only_pass") if verification else None,
            "returned_t": verification.get("returned_t") if verification else None,
            "verified_scaled_linf_distance": distance, "distance_optimality_proved": False,
            "U": U, "certified_gap_bound": gap, "certified_interval": [L, U] if certified else None,
            "binary64_export_status": export.get("status") if export else "NOT RUN",
            "binary64_numeric_physical_pass": export.get("numeric_physical_pass") if export else None,
            "binary64_numeric_band_pass": export.get("numeric_band_pass") if export else None,
            "binary64_exact_literal_pass": export.get("literal_binary64_band_pass") if export else None,
            "elapsed_seconds": outcome.get("elapsed_seconds") if outcome else None,
            "reasons": list(verification.get("failures", [])) if verification else [],
            "call_accounting": attempt, "objective_units": "actual weighted original Stage-B QP; no division by lambda_tau",
            "outward_decimal_display": {"historical_G_L": decimal_bounds(L), "U": decimal_bounds(U),
                "gap": decimal_bounds(gap), "distance": decimal_bounds(distance)}}
        if outcome and outcome.get("reason"):
            row["reasons"].append(outcome["reason"])
        if not certified and not row["reasons"]:
            row["reasons"] = ["PREPARATION_FAILED: saved-record recovery not run" if preparation_failed else status + ": no independently certified rational witness"]
        rows.append(row)
    return rows


def guard_receipts():
    records, blocked, missing, counter_inconsistencies, original_calls, constructions = [], [], [], [], 0, 0
    for path in sorted(OUT.rglob("worker_result.json")):
        record = read(path)
        guard = record.get("guard")
        if guard is None:
            missing.append(str(path.relative_to(ROOT)))
            continue
        old = guard.get("original_guard", {})
        nested_calls = old.get("actual_solve_calls")
        nested_constructions = old.get("actual_constructions")
        for outer_key, nested_value in (("actual_original_stage_a_b_calls", nested_calls),
                                         ("actual_original_optimizer_constructions", nested_constructions)):
            if nested_value is None:
                missing.append(str(path.relative_to(ROOT)) + ": original guard counter missing: " + outer_key)
            elif guard.get(outer_key) != nested_value:
                counter_inconsistencies.append({"file": str(path.relative_to(ROOT)), "counter": outer_key,
                    "HR_outer_counter": guard.get(outer_key), "original_guard_actual_counter": nested_value})
        original_calls += nested_calls if nested_calls is not None else guard.get("actual_original_stage_a_b_calls", 0)
        constructions += nested_constructions if nested_constructions is not None else guard.get("actual_original_optimizer_constructions", 0)
        blocked.extend(guard.get("blocked_attempts", []))
        blocked.extend(old.get("blocked_attempts", []))
        records.append({"file": str(path.relative_to(ROOT)), "sha256": sha256(path),
                        "worker_status": record.get("status"), "guard": guard})
    for path in sorted(OUT.rglob("worker_request.json")):
        if not (path.parent / "worker_result.json").exists():
            missing.append(str(path.relative_to(ROOT)))
    return {"worker_guard_receipts": records, "missing_worker_receipts": missing,
        "guard_receipts_complete_for_requested_workers": not missing,
        "original_stage_a_b_solve_calls_confirmed_in_receipts": original_calls,
        "original_optimizer_constructions_confirmed_in_receipts": constructions,
        "original_guard_counter_inconsistencies": counter_inconsistencies,
        "blocked_prohibited_worker_attempts": blocked,
        "scope": "Persisted receipts only; missing receipts are not represented as complete zero-call evidence. Reporting itself creates no optimizer."}


def freeze_provenance():
    for name in ("IMPLEMENTATION_MANIFEST.json", "PRE_SYNTHETIC_MANIFEST.json", "SYNTHETIC_PLAN.json"):
        path = OUT / name
        if path.exists():
            manifest = read(path)
            for filename, digest in manifest.get("files", {}).items():
                require(sha256(ROOT / filename) == digest, "Frozen HR implementation changed: " + filename)
            return {"file": name, "sha256": sha256(path), "files_checked": len(manifest.get("files", {})),
                    "real_batch_freeze_present": name == "IMPLEMENTATION_MANIFEST.json" and manifest.get("real_run_authorized") is not False}
    return {"file": None, "sha256": None, "files_checked": 0, "real_batch_freeze_present": False}


def count_text(exact, lo, hi):
    return str(exact) if exact is not None else f"UNKNOWN [{lo},{hi}]"


def synthetic_summary(synthetic, plan, stop):
    definitions = plan.get("fixtures", [])
    if not definitions:
        definitions = [{"identity": VERSION + "." + name, "prior_identity": name} for name in (
            "h_fixture_01_half_distance", "h_fixture_02_negative_bounds",
            "h_fixture_03_thin_band_active_normal", "h_fixture_04_literal_intersection_infeasible")]
    require(len(definitions) == 4 and len({row["identity"] for row in definitions}) == 4,
            "Synthetic reporting plan must retain exactly four fixed identities")
    observed = {}
    for row in (synthetic or {}).get("results", []):
        require(row["identity"] not in observed, "Duplicate synthetic result identity")
        observed[row["identity"]] = row
    require(set(observed).issubset({row["identity"] for row in definitions}), "Unknown synthetic identity in results")
    result = []
    for index, definition in enumerate(definitions, 1):
        item = observed.get(definition["identity"])
        check = item.get("verification", {}) if item else {}
        result.append({"order": index, "identity": definition["identity"],
            "prior_identity": definition.get("prior_identity", definition["identity"].removeprefix(VERSION + ".")),
            "worker_status": item.get("worker_status") if item else "NOT RUN",
            "verification_passed": check.get("passed") if item else None,
            "verification": check if item else None,
            "reason": stop.get("reason") if stop.get("failed_identity") == definition["identity"]
                      else check.get("reason", check.get("guard_error")) if item else "NOT RUN"})
    return result


def methodology_scan():
    return [
        ("Simpson 悖论", "逐路径、原状态和 ordinal 保留；不以总通过率替代分组事实。"),
        ("生态谬误", "单个保存问题的证书不外推机器人总体或部署性能。"),
        ("Berkson 选择偏差", "固定已见 F 停止序列全部 20 条；不是随机样本，不估计总体相关。"),
        ("Collider bias", "无控制变量回归或因果估计，不据选择后的恢复结果解释状态。"),
        ("基率忽略", "保留 20 条分母及 4 个 fixture，另列剩余回归/全面板未运行。"),
        ("回归均值", "不把恢复点变化称统计改善；没有按失败重测择优。"),
        ("幸存者偏差", "失败、超时、NOT RUN、无效点和浮点导出失败均保留。"),
        ("Look-elsewhere effect", "仅冻结的四个 fixture 与单一适配方法，不追加案例追求通过。"),
        ("Garden of forking paths", "承认已看过 H 结果的协议修订；冻结后禁止改法重试，不称预注册。"),
        ("相关不等于因果", "不从恢复距离或证书成立推断 AlmostSolved 根因。"),
        ("反向因果", "无因果模型或方向性统计结论；此项不适用于精确代数证明。"),
    ]


def footer(result):
    counts = result["call_accounting"]
    category = lambda name: count_text(*(counts["categories"][name][key] for key in
        ("actual_call_count", "actual_call_count_lower_bound", "actual_call_count_upper_bound")))
    total = count_text(*(counts[key] for key in ("total_actual_call_count", "total_actual_call_count_lower_bound", "total_actual_call_count_upper_bound")))
    combined = count_text(*(counts[key] for key in ("h_plus_hr_actual_call_count", "h_plus_hr_actual_call_count_lower_bound", "h_plus_hr_actual_call_count_upper_bound")))
    combined_synthetic = count_text(*(counts[key] for key in ("h_plus_hr_synthetic_actual_call_count", "h_plus_hr_synthetic_actual_call_count_lower_bound", "h_plus_hr_synthetic_actual_call_count_upper_bound")))
    return ["STEP02H_RESULT_UNCHANGED = PREPARATION_FAILED", "STEP02F_RESULT_UNCHANGED = FAIL / REVISE",
        "STEP02G_RESULT_UNCHANGED = AUDIT_COMPLETED", f"NEW_HR_SYNTHETIC_LP_CALLS = {category('synthetic_fixture')}/4",
        f"NEW_HR_SAVED_RECORD_LP_CALLS = {category('saved_record')}/20", f"NEW_HR_OPTIMIZATION_CALLS = {total}",
        f"H_PLUS_HR_SYNTHETIC_LP_CALLS = {combined_synthetic}/16", f"H_PLUS_HR_OPTIMIZATION_CALLS = {combined}",
        f"NEW_CERTIFICATE_WITNESSES = {result['new_certificate_witnesses']}/20",
        f"ORIGINAL_STAGE_A_B_SOLVE_CALLS = {result['original_stage_a_b_solve_calls']}",
        "REMAINING_STEP02F_REGRESSIONS = NOT RUN", "STEP02F_FULL_PANEL = NOT RUN",
        "FURTHER_SOLVE_AUTHORIZED = FALSE", "E1_AUTHORIZED = FALSE"]


def write_report(result, rows):
    text = ["## Material Passport", "", "- Origin Skill: experiment-agent / academic-research-suite",
        "- Origin Mode: validate / bounded execution reporting", f"- Origin Date: {result['generated_utc']}",
        "- Verification Status: ANALYZED", f"- Version Label: {VERSION}", "",
        "# STEP-02H-R 非负标准形适配与精确证书", "",
        "验证等级：ANALYZED。依据已知 H 负 bounds 接口失败进行的限额协议修订；不是盲测、预注册研究或原实验重跑。", "",
        f"状态：{result['status']}。固定 20 条均在表内；新独立有理证书 {result['new_certificate_witnesses']}/20。",
        "H 的 PREPARATION_FAILED、F 的 FAIL / REVISE、G 的 AUDIT_COMPLETED 及原候选 null 上界/gap 全部保持。", "",
        "## 四个固定合成案例", "",
        f"准备停止身份：{result['preparation_failed_identity']}；原始原因：{json.dumps(compact(result['preparation_stop_reason']), ensure_ascii=False)}。", "",
        "|顺序|H-R 执行身份|后端状态|独立检查|停止/未运行原因|", "|---|---|---|---|---|"]
    for item in result["synthetic_fixture_summary"]:
        reason = json.dumps(compact(item["reason"]), ensure_ascii=False).replace("|", "\\|")
        check = "NOT RUN" if item["verification_passed"] is None else "PASS" if item["verification_passed"] else "FAIL"
        text.append(f"|{item['order']}|{item['identity']}|{item['worker_status']}|{check}|{reason}|")
    text += ["",
        "## 固定范围结果", "",
        "L 为历史 G 下界，NOT RUN 行中的 L 不是 H-R 新输出。U、U−L 仅属于经独立验证的新有理见证。所有目标量保留实际加权 Stage-B 单位，不除以 lambda_tau。下表是方向核验的十进制外包显示，完整分数见 JSONL/CSV。", "",
        "|序号|路径|原 F 状态|H-R 状态|历史 G L|新 U|新 U−L|核验距离|binary64 导出|",
        "|---|---|---|---|---|---|---|---|---|"]
    for row in rows:
        text.append(f"|{row['solve_ordinal']}|{row['path']}|{row['original_f_status']}|{row['recovery_status']}|{display(row['original_g_L'])}|{display(row['U'])}|{display(row['certified_gap_bound'])}|{display(row['verified_scaled_linf_distance'])}|{row['binary64_export_status']}|")
    text += ["", "## 方法、调用与界限", "",
        "唯一接口变更为 z=l+v、v>=0、t 不平移。249 条旧行全保留，真实输入追加 12 条上界成为 261×13；微型输入为 16×2。独立 Fraction 证明逐行残差、目标、双向界与 w=p+Nl+Nv 回映等价。SymPy 1.14.0 linprog 仅接收 c/A/b，不传 bounds 或 A_eq/b_eq；禁止 _handle_bounds、第二后端、guard/半径/阈值调节和失败重试。",
        "原 H 两次合成调用继续计入历史额度。本轮最多 4 次合成和 20 次保存记录调用；预留、dispatch intent 与实际入口回执分列。缺回执的已派发调用报告上下界，不能写成确定零次；未知身份仍消耗预算且不可重试。",
        f"纯测试通过：{result['tests']['pure_passed']}；合成计划完成：{result['tests']['synthetic_complete']}，通过：{result['tests']['synthetic_passed']}；只读证书回放条数：{result['tests']['replay_records']}。",
        f"停止原因：{result['run_stop_reason']}。单 worker 上限 300 秒，真实批量上限 3600 秒；真实批量耗时：{result['real_batch_elapsed_seconds']} 秒。",
        "只在原 E/G、literal binary64 band、G 证明盒、D 距离与 G 下界证据全部核验后产生 U。U<L 为证书不一致并停机，不裁剪 gap。后端 t 仅报告，不声称独立证明最近点或原 QP 最优解。后端 infeasible 无独立 Farkas 证据时只是 INCONCLUSIVE，literal 交集失败不能推出原 QP 不可行。",
        f"有理证书有效但 binary64 导出不被接受的 ordinal：{result['rational_float_export_divergence_ordinals']}。导出只直接舍入一次，不修复；导出失败不否定有理上界，导出通过也不补发 Clarabel Solved/F PASS 或实时控制验证。",
        "本支线只补充数学可行性和原目标上界证据；生产 solver 状态、性能及独立实现等价性仍未解决。固定 20 条不是随机样本，证书计数不作总体统计或因果推断；两路径共用辅助工具不构成独立优化实现证据。",
        "准备门失败立即停止；结束或停止后不追加恢复方案、后端或实验。剩余 26 回归、245 全面板、Stage-A/B1-soft/E1 均未运行，不设置新区间阈值解锁它们。", "",
        "## 方法学检查：11/11 checked", "",
        "本轮是确定性精确代数审计；没有 p 值、抽样置信区间、统计功效或总体效果推断。显示外包区间是数值舍入包络，不是统计置信区间。", "",
        "|风险|本轮检查与适用边界|", "|---|---|"]
    text += [f"|{name}|{detail}|" for name, detail in methodology_scan()]
    text += ["",
        f"工作树：{ROOT}", f"分支：{result['branch']}", f"源 H 提交：{BASE}",
        "结果提交由最终交付及 GIT_DELIVERY.json 记录；不在自引用报告中嵌入结果提交。未推送。",
        "optimizer_call_audit.json 明确记录缺失回执与防护覆盖限制，不宣称通用原生代码沙箱。", ""] + footer(result) + [""]
    write_text("STEP02HR_REPORT.md", "\n".join(text))
    write_text("EXECUTION_HANDOFF.md", "\n".join(["# STEP02HR execution handoff", "",
        f"Status: {result['status']}; verification level: ANALYZED.",
        "Read STEP02HR_REPORT.md, STEP02HR_RESULT.json, the fixed-20 primal_dual_intervals.jsonl/recovery_summary.csv, exact independent verification, and optimizer_call_audit.json.",
        "All strict new bounds belong to new witnesses. Historical H/F/G records are unchanged. No consumed identity may be retried.",
        "Reporting performs zero optimization. Artifact hashes exclude their own manifest and post-commit GIT_DELIVERY.json explicitly.",
        f"Worktree: {ROOT}", f"Branch: {result['branch']}", f"Source H commit: {BASE}", ""] + footer(result) + [""]))


def deliver():
    """Generate HR reports only after a bounded run or preparation has stopped."""
    require(OUT.exists(), "HR output directory does not exist")
    require(not (OUT / "RUN_STARTED.json").exists() or (OUT / "RUN_FINISHED.json").exists(), "Real run is still active; cannot deliver")
    before = verify_sources()
    provenance = freeze_provenance()
    snapshot, events = read_ledger()
    counts = call_accounting(snapshot, events)
    guards = guard_receipts()
    synthetic = read(OUT / "synthetic_tests.json")
    preparation_stop = read(OUT / "PREPARATION_STOP.json", {})
    synthetic_rows = synthetic_summary(synthetic, read(OUT / "SYNTHETIC_PLAN.json", {}), preparation_stop)
    preparation_failed = synthetic is not None and (not synthetic.get("complete") or not synthetic.get("passed")
        or any(not row.get("verification", {}).get("passed") for row in synthetic.get("results", [])))
    case_manifest = read(OUT / "CASE_MANIFEST.json", read(HF / "CASE_MANIFEST.json", {}))
    rows = build_rows(lines(GF / "candidate_audit.jsonl"), lines(OUT / "record_outcomes.jsonl"),
        lines(OUT / "independent_verification.jsonl"), lines(OUT / "binary64_export_checks.jsonl"), counts,
        case_manifest.get("cases", []), preparation_failed)
    if preparation_failed and not (OUT / "IMPLEMENTATION_MANIFEST.json").exists() and provenance["file"]:
        frozen_source = read(OUT / provenance["file"])
        save("IMPLEMENTATION_MANIFEST.json", {"utc": utc(), "version": VERSION,
            "status": "PREPARATION_FAILED", "real_run_authorized": False,
            "terminal_reporting_snapshot_only": True, "real_batch_freeze": "NOT RUN",
            "files": frozen_source.get("files", {}), "source_freeze": provenance,
            "reason": "Preserve pre-synthetic frozen implementation for reporting/replay; not permission to start saved-record LPs"})
        provenance = freeze_provenance()
    started = (OUT / "RUN_STARTED.json").exists()
    finished = read(OUT / "RUN_FINISHED.json", {})
    critical = (any(row["recovery_status"] in ("CERTIFICATE_INCONSISTENCY", "RETURNED_WITNESS_INVALID", "ERROR") for row in rows)
        or bool(guards["original_guard_counter_inconsistencies"] or guards["blocked_prohibited_worker_attempts"])
        or guards["original_stage_a_b_solve_calls_confirmed_in_receipts"] > 0
        or guards["original_optimizer_constructions_confirmed_in_receipts"] > 0)
    certified = [row for row in rows if row["rational_witness_certified"]]
    if not started:
        status = "PREPARATION_FAILED" if preparation_failed else "PREPARATION_INCOMPLETE"
    else:
        require(not preparation_failed, "Real run occurred after failed preparation")
        status = "STOPPED_FOR_AUDIT" if critical else "COMPLETED_WITH_CERTIFICATES" if certified else "COMPLETED_WITHOUT_CERTIFICATE"
    pure = read(OUT / "pure_tests_latest.json", read(OUT / "pure_tests.json", {}))
    replay = read(OUT / "verification_replay.json", {"status": "NOT RUN", "records": [], "optimization_calls": 0})
    tests = {"pure_tests": pure, "synthetic_fixture_tests": synthetic, "verification_replay": replay,
             "new_synthetic_call_accounting": counts["categories"]["synthetic_fixture"], "reporting_lp_calls": 0}
    result = {"stage": "STEP02HR", "status": status, "verification_level": "ANALYZED", "algorithm_version": VERSION,
        "generated_utc": utc(), "source_H_commit": BASE, "source_G_commit": "7abc4d489a9266684e5672414415394e111ddd23",
        "source_F_commit": "0aa98d533de944b0644f13f4ef84c331f9decce1", "config_sha256": CONFIG_SHA,
        "worktree": str(ROOT), "branch": git(ROOT, "branch", "--show-current"),
        "fixed_saved_record_scope": 20, "fixed_record_rows_delivered": len(rows),
        "recovery_status_counts": dict(Counter(row["recovery_status"] for row in rows)), "new_certificate_witnesses": len(certified),
        "binary64_export_status_counts": dict(Counter(row["binary64_export_status"] for row in rows)),
        "rational_float_export_divergence_ordinals": [row["solve_ordinal"] for row in certified if row["binary64_export_status"] == "BINARY64_EXPORT_NOT_ACCEPTABLE"],
        "call_accounting": counts, "original_stage_a_b_solve_calls": guards["original_stage_a_b_solve_calls_confirmed_in_receipts"],
        "original_call_receipt_coverage_complete": guards["guard_receipts_complete_for_requested_workers"],
        "tests": {"pure_passed": pure.get("passed", False), "pure_tests_run": pure.get("tests_run", 0),
                  "synthetic_complete": bool(synthetic and synthetic.get("complete")), "synthetic_passed": bool(synthetic and synthetic.get("passed")),
                  "replay_records": len(replay.get("records", [])), "replay_optimization_calls": replay.get("optimization_calls")},
        "run_stop_reason": preparation_stop.get("reason", "PREPARATION_FAILED: frozen synthetic gate not completed/passed") if preparation_failed else finished.get("stop_reason"),
        "preparation_stop": preparation_stop,
        "preparation_failed_identity": preparation_stop.get("failed_identity", next((row["identity"] for row in synthetic_rows if row["verification_passed"] is False), None)),
        "preparation_stop_reason": preparation_stop.get("reason"), "synthetic_fixture_summary": synthetic_rows,
        "real_batch_status": "FINISHED" if started else "NOT RUN", "real_batch_elapsed_seconds": finished.get("elapsed_seconds"),
        "freeze_provenance": provenance, "source_integrity": before,
        "step02h_result_unchanged": "PREPARATION_FAILED", "step02f_result_unchanged": "FAIL / REVISE",
        "step02g_result_unchanged": "AUDIT_COMPLETED", "original_G_upper_bounds_and_gaps_unchanged_null": True,
        "remaining_step02f_regressions": "NOT RUN", "step02f_full_panel": "NOT RUN",
        "distance_optimality_independently_proved": False, "objective_unit_division_performed": False,
        "new_absolute_gap_acceptance_threshold": None, "post_hoc_known_data_diagnostic": True,
        "further_solve_authorized": False, "e1_authorized": False, "reporting_new_optimization_calls": 0,
        "methodology_fallacy_scan": {"coverage": "11/11 checked", "items": [{"name": name, "finding": detail} for name, detail in methodology_scan()],
            "statistical_inference_performed": False},
        "material_passport": {"origin_skill": "experiment-agent / academic-research-suite", "origin_mode": "validate / bounded execution reporting",
            "verification_status": "ANALYZED", "version_label": VERSION}}
    save("optimizer_call_audit.json", {**counts, **guards, "reporting_generated_utc": utc()})
    save("tests.json", tests)
    text = json.dumps(compact(tests), ensure_ascii=False, indent=2)
    if pure.get("test_log"):
        log_path = ROOT / pure["test_log"]
        require(sha256(log_path) == pure["test_log_sha256"], "Pure test log hash changed")
        text += "\n\n" + log_path.read_text(encoding="utf-8")
    write_text("tests.txt", text + "\n")
    write_text("primal_dual_intervals.jsonl", "".join(json.dumps(compact(row), ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n" for row in rows))
    excluded = {"call_accounting", "outward_decimal_display", "certified_interval"}
    fields = [key for key in rows[0] if key not in excluded]
    with (OUT / "recovery_summary.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: str(row[key]) if isinstance(row[key], Fraction) else json.dumps(row[key], ensure_ascii=False)
                if isinstance(row[key], list) else row[key] for key in fields})
    for name in ("independent_verification.jsonl", "binary64_export_checks.jsonl"):
        if not (OUT / name).exists():
            write_text(name, "")
    if not (OUT / "verification_replay.json").exists():
        save("verification_replay.json", replay)
    save("STEP02HR_RESULT.json", result)
    write_report(result, rows)
    after = verify_sources()
    require(read_ledger() == (snapshot, events), "Reporting altered HR ledger")
    save("SOURCE_VERIFICATION.json", {"before": before, "after": after, "ledger_unchanged": True, "reporting_lp_calls": 0})
    exclusions = {"artifact_hashes.json", "GIT_DELIVERY.json"}
    hashes = {str(path.relative_to(ROOT)).replace("\\", "/"): sha256(path) for path in sorted(OUT.rglob("*"))
              if path.is_file() and path.name not in exclusions}
    save("artifact_hashes.json", {"files": hashes, "file_count": len(hashes), "excluded_basename": sorted(exclusions),
        "exclusion_reason": "Self-referential hash manifest and post-commit Git delivery metadata", "generated_utc": utc()})
    return {"status": status, "fixed_rows": 20, "new_certificate_witnesses": len(certified),
            "call_accounting": counts, "reporting_optimization_calls": 0, "source_integrity_after": after}


def main():
    return deliver()


if __name__ == "__main__":
    print(json.dumps(compact(main()), ensure_ascii=False))
