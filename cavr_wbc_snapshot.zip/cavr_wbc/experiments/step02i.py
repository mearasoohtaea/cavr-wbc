"""One fixed BigFloat panel. No optimizer is constructed in Python.

Each Julia child is a single-use worker. Ordinary numerical failures continue;
input, implementation and accounting errors stop the affected panel.
"""
from __future__ import annotations
import argparse
from collections import Counter
from datetime import datetime, timezone
from decimal import Decimal, localcontext
import hashlib
import io
import json
import math
import os
from pathlib import Path
import struct
import subprocess
import sys
import time
import traceback
import unittest
import csv

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'artifacts/step02i_bigfloat_full_panel'
LOCAL=ROOT/'.step02i-local'
BASE='8def274247ec8ee68d78496e0237ca10d74173a8'
SOURCE=ROOT.parent/'cavr_step02hr_nonnegative_adapter_20260918'
VERSION='STEP02I_BIGFLOAT256_V1'
PATHS=('production','reference')
PREP_DEADLINE=datetime.fromisoformat('2026-09-18T11:58:24.480691+00:00').timestamp()


def utc():return datetime.now(timezone.utc).isoformat()
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def lines(path):return [json.loads(line) for line in Path(path).read_text(encoding='utf-8').splitlines() if line] if Path(path).exists() else []
def require(condition,message):
    if not condition:raise ValueError(message)


def save(path,value,exclusive=False):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x' if exclusive else 'w',encoding='utf-8',newline='\n') as stream:
        json.dump(value,stream,ensure_ascii=False,allow_nan=False,separators=(',',':'));stream.write('\n')
        stream.flush();os.fsync(stream.fileno())


def append(path,value):
    with Path(path).open('a',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(value,ensure_ascii=False,allow_nan=False,separators=(',',':'))+'\n');stream.flush();os.fsync(stream.fileno())


def git(*args):return subprocess.check_output(['git','-c','core.quotepath=false','-C',str(ROOT),*args],encoding='utf-8').strip()


def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()


class Ledger:
    """One durable single-writer ledger; a reservation is never recycled."""
    def __init__(self,path=OUT/'solve_ledger.jsonl'):self.path=Path(path)
    def events(self):
        rows=lines(self.path);previous='0'*64;identities=set();pending={}
        if self.path.exists():require(self.path.read_bytes().endswith(b'\n'),'Truncated ledger')
        for number,row in enumerate(rows,1):
            value={k:v for k,v in row.items() if k!='hash'}
            require(row['sequence']==number and row['previous_hash']==previous and row['hash']==digest(value),'Ledger chain mismatch')
            previous=row['hash'];key=tuple(row['identity'])
            if row['event']=='RESERVED':
                require(key not in identities,'Duplicate identity reservation');identities.add(key);pending[key]=row
            else:require(key in pending,'Receipt without reservation')
            if row['event']=='FINISHED':del pending[key]
        return rows
    def _append(self,event,identity,**metadata):
        rows=self.events();row={'sequence':len(rows)+1,'previous_hash':rows[-1]['hash'] if rows else '0'*64,
            'event':event,'identity':list(identity),'utc':utc(),'metadata':metadata}
        row['hash']=digest(row);append(self.path,row);return row
    def reserve(self,category,case_id,path,input_hash):
        require(category in ('smoke','stage_b'),'Invalid category')
        key=(category,case_id,path);rows=self.events();reserved=[r for r in rows if r['event']=='RESERVED']
        require(not any(tuple(r['identity'])==key for r in reserved),'Identity already consumed; no retry')
        limit=2 if category=='smoke' else 490
        require(sum(r['identity'][0]==category for r in reserved)<limit,'Call budget exhausted')
        return self._append('RESERVED',key,input_sha256=input_hash)
    def finish(self,identity,**metadata):return self._append('FINISHED',identity,**metadata)
    def accounting(self):
        rows=self.events();out={}
        for category,limit in [('smoke',2),('stage_b',490)]:
            starts=[r for r in rows if r['event']=='RESERVED' and r['identity'][0]==category]
            finished={tuple(r['identity']):r for r in rows if r['event']=='FINISHED' and r['identity'][0]==category}
            confirmed=unknown=0
            for start in starts:
                end=finished.get(tuple(start['identity']))
                if end is None:unknown+=1
                else:
                    confirmed+=end['metadata']['confirmed_solve_calls'];unknown+=end['metadata']['unknown_call_upper_bound']
            out[category]={'budget':limit,'reserved':len(starts),'confirmed_calls':confirmed,'unknown_call_upper_bound':unknown,
                           'actual_calls':confirmed if unknown==0 else None,'calls_lower_bound':confirmed,'calls_upper_bound':confirmed+unknown}
        return out


def source_check(manifest):
    for name,value in manifest['files'].items():
        require(sha(ROOT/name)==value,'Frozen source/input changed: '+name)
        require(sha(SOURCE/name)==value,'Original source/input changed: '+name)
    require(subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],encoding='utf-8').strip()==BASE,'Source HEAD changed')
    require(subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain=v1'],encoding='utf-8').strip()=='','Source H-R worktree changed')


def code_files():
    paths=[Path(__file__),ROOT/'cavr_wbc/evaluation/step02i_inputs.py',ROOT/'tests/test_step02i_inputs.py',ROOT/'tests/test_step02i_runner.py']
    paths += sorted((ROOT/'julia/step02i').glob('*'))
    paths += [OUT/'config.yaml',OUT/'STEP02I_PROTOCOL.md',*sorted((OUT/'protocol').glob('*'))]
    return {p.relative_to(ROOT).as_posix():sha(p) for p in paths if p.is_file()}


def check_frozen(manifest):
    require(code_files()==manifest['files'],'Implementation/configuration changed after freeze')
    for name,value in manifest.get('artifacts',{}).items():require(sha(OUT/name)==value,'Pre-run artifact changed: '+name)


def prep_time():require(time.time()<PREP_DEADLINE,'PREPARATION_INCOMPLETE: two-hour limit reached')


def environment():
    lock=read(OUT/'ENVIRONMENT_LOCK.json')
    # Runtime paths and no-solve loading flags are explicit in the environment
    # contract, not discovered or changed after seeing numerical results.
    return lock


def julia_command(request,output,receipt):
    lock=environment()
    return [lock['julia_executable'],*lock['worker_julia_flags'],
            str(ROOT/'julia/step02i/worker.jl'),str(request),str(output),str(receipt)]


def worker_env():
    lock=environment();env=dict(os.environ)
    env.update({str(k):str(v) for k,v in lock['worker_environment'].items()})
    env.update(TEMP=str(LOCAL),TMP=str(LOCAL),PYTHONDONTWRITEBYTECODE='1')
    return env


def supervise(category,transport,manifest,remaining):
    require(remaining>0,'Resource limit before reservation');check_frozen(manifest)
    ident=transport['identity'];cid,path=ident['case_id'],ident['path'];ordinal=ident['solve_ordinal']
    name=f'smoke_{ordinal:02d}' if category=='smoke' else f'{ordinal:03d}_{path}'
    directory=OUT/'workers'/name;directory.mkdir(parents=True,exist_ok=False)
    input_file=directory/'input.json';save(input_file,transport,exclusive=True)
    ledger=Ledger();reservation=ledger.reserve(category,cid,path,sha(input_file));identity=reservation['identity']
    request=directory/'request.json'
    save(request,{'input_file':str(input_file),'input_sha256':sha(input_file),'reservation_id':reservation['hash'],'identity':ident},exclusive=True)
    output=OUT/'high_precision_outputs'/f'{name}.json';output.parent.mkdir(exist_ok=True)
    receipt=directory/'entry_receipt.json';command=julia_command(request,output,receipt)
    started=time.monotonic();limit=min(120,remaining);process=None;timed_out=False
    try:
        with (directory/'worker.log').open('x',encoding='utf-8') as log:
            process=subprocess.Popen(command,cwd=ROOT,env=worker_env(),stdout=log,stderr=subprocess.STDOUT,
                                     creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            save(directory/'process.json',{'pid':process.pid,'utc':utc(),'command':command,'limit_seconds':limit},exclusive=True)
            while process.poll() is None:
                elapsed=time.monotonic()-started
                if elapsed>=limit:
                    print(f'TIMEOUT terminating owned STEP02I worker pid={process.pid} {cid}/{path}',flush=True)
                    process.kill();process.wait(timeout=10);timed_out=True;break
                try:process.wait(timeout=min(30,limit-elapsed))
                except subprocess.TimeoutExpired:print(f'WORKER {ordinal} {path} elapsed={time.monotonic()-started:.1f}s',flush=True)
        value=read(output) if output.exists() else None
        entry=read(receipt) if receipt.exists() else None
        if timed_out:
            status='TIMEOUT';kind='numerical_failure'
        elif process.returncode!=0 or value is None:
            status='WORKER_ERROR';kind='infrastructure_error'
        else:status=value['status'];kind='infrastructure_error' if value.get('infrastructure_error') else 'result'
        if value is not None:
            require(value['identity']==ident and value['input_sha256']==sha(input_file),'Output identity/input mismatch')
        if entry is not None:
            require(entry['identity']==ident and entry['reservation_id']==reservation['hash'],'Receipt identity mismatch')
        confirmed=int(entry is not None and entry.get('solve_calls_confirmed')==1)
        unknown=int(not confirmed and (entry is None or entry.get('solve_dispatch_intent',False)))
        ledger.finish(identity,status=status,kind=kind,elapsed_seconds=time.monotonic()-started,
                      confirmed_solve_calls=confirmed,unknown_call_upper_bound=unknown,
                      request_sha256=sha(request),output_sha256=sha(output) if output.exists() else None,
                      receipt_sha256=sha(receipt) if receipt.exists() else None,retry_allowed=False)
        return {'status':status,'kind':kind,'output':value,'elapsed_seconds':time.monotonic()-started,
                'input_sha256':sha(input_file),'output_file':output.relative_to(ROOT).as_posix() if output.exists() else None,
                'confirmed_solve_calls':confirmed,'unknown_call_upper_bound':unknown}
    except BaseException:
        if process is not None and process.poll() is None:
            process.kill();process.wait(timeout=10)
        ledger.finish(identity,status='SUPERVISION_ERROR',kind='infrastructure_error',elapsed_seconds=time.monotonic()-started,
                      confirmed_solve_calls=0,unknown_call_upper_bound=1,retry_allowed=False)
        raise


def bits(value):return struct.pack('>d',float(value)).hex()
def encode(value):return [encode(v) for v in value] if isinstance(value,list) else bits(value)
def decode(values):return [struct.unpack('>d',bytes.fromhex(v))[0] for v in values]


def smoke_plan():
    # Both original finite-binary inputs and expectations freeze before either
    # solver call. Second optimum is on the negative thin-band lower endpoint.
    plan=[]
    for ordinal,name,P,q,E,f,G,h,D,target in [
        (1,'interior_optimum',[[2,0],[0,2]],[-2,-4],[[0,1]],[2],[[1,0],[-1,0],[0,1],[0,-1],[1,0],[-1,0]],[10,10,10,10,1+1e-8,-1+1e-8],[2,4],1),
        (2,'negative_active_thin_band',[[2,0],[0,2]],[4,1],[[0,1]],[-0.5],[[1,0],[-1,0],[0,1],[0,-1],[1,0],[-1,0]],[-1,3,1,1,-1.5+1e-8,1.5+1e-8],[2,1],-1.5)]:
        transport={'identity':{'case_id':name,'path':'smoke','case_ordinal':ordinal,'solve_ordinal':ordinal},'schema':'STEP02I_BINARY64_BITS_V1',
                   **{k:encode(v) for k,v in dict(P=P,q=q,E=E,f=f,G=G,h=h,D=D,task_matrix=[[1,0]],task_bias=[0],target=[target],task_scales=[1],epsilon=1e-8,c_original=0).items()},
                   'task_upper_rows':[4],'task_lower_rows':[5],'canonical_equality_labels':['smoke_y'],
                   'canonical_inequality_labels':['upper_x','lower_x','upper_y','lower_y','fixed_task_upper[0]','fixed_task_lower[0]'],
                   'is_smoke':True}
        plan.append({'transport':transport,'expectation':{'x':str(target),'y':'2' if ordinal==1 else '-0.5',
            'x_endpoint':'center' if ordinal==1 else 'center_minus_exact_binary64_epsilon','max_coordinate_error':'1e-17',
            'accepted_status':'Solved','all_outputs_finite':True,'high_precision_original_constraints_and_band':True}})
    return plan


def check_smoke(result,plan):
    output=result['output']
    if not output or result['kind']=='infrastructure_error':return {'passed':False,'reason':result['status']}
    with localcontext() as ctx:
        ctx.prec=100
        expected=[Decimal(plan['expectation']['x']),Decimal(plan['expectation']['y'])]
        if plan['expectation']['x_endpoint']!='center':expected[0]-=Decimal.from_float(1e-8)
        w=[Decimal(v) for v in output['w']]
        error=max(abs(a-b) for a,b in zip(w,expected))
        hp=output.get('hp_checks',{}).get('high_precision_numerically_feasible',False)
        passed=len(w)==2 and result['status']=='Solved' and output['all_outputs_finite'] and hp and error<=Decimal('1e-17')
        return {'passed':bool(passed),'maximum_coordinate_error':str(error),'expected':list(map(str,expected)),
                'status':result['status'],'high_precision_feasible':output.get('hp_checks',{}).get('high_precision_numerically_feasible')}


def prepare():
    prep_time()
    from cavr_wbc.evaluation.step02i_inputs import load_all,load_case_path
    require(not (OUT/'SOURCE_MANIFEST.json').exists(),'Preparation already saved; do not overwrite')
    context=load_all();source=context['source_manifest'];source_check(source)
    save(OUT/'SOURCE_MANIFEST.json',source,exclusive=True)
    identities=[]
    for case in context['cases']:
        for path in PATHS:
            transport,_,_,_=load_case_path(case['case_id'],path,context)
            input_path=OUT/'inputs'/f"{transport['identity']['solve_ordinal']:03d}_{path}.json"
            save(input_path,transport,exclusive=True)
            identities.append({'case_id':case['case_id'],'path':path,'solve_ordinal':transport['identity']['solve_ordinal'],
                'input_file':input_path.relative_to(ROOT).as_posix(),'input_sha256':sha(input_path)})
    require(len(identities)==490,'Fixed identity count')
    save(OUT/'case_manifest.json',{'cases':context['cases'],'paths':identities,'order':'F manifest then production/reference'},exclusive=True)
    save(OUT/'smoke_plan.json',{'smoke_cases':smoke_plan(),'maximum_calls':2},exclusive=True)
    prep_time();print('PREPARED 245 cases / 490 distinct path inputs, no solves',flush=True)


def pure_tests():
    prep_time();require(not (OUT/'PRE_SMOKE_FREEZE.json').exists(),'Testing/refinement closed after smoke freeze')
    suite=unittest.TestSuite()
    for name in ('test_step02i_inputs.py','test_step02i_runner.py'):
        suite.addTests(unittest.defaultTestLoader.discover(str(ROOT/'tests'),pattern=name))
    log=io.StringIO();result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
    (OUT/'tests.txt').write_text(log.getvalue(),encoding='utf-8',newline='\n')
    save(OUT/'pure_tests.json',{'utc':utc(),'tests_run':result.testsRun,'passed':result.wasSuccessful(),
        'failures':len(result.failures),'errors':len(result.errors),'optimization_calls':0,'files':code_files()})
    print(log.getvalue(),flush=True);require(result.wasSuccessful(),'Pure interface tests failed');prep_time()


def smoke():
    prep_time();require(not (OUT/'PRE_SMOKE_FREEZE.json').exists(),'Smoke stage already frozen/attempted')
    tests=read(OUT/'pure_tests.json');require(tests['passed'] and tests['files']==code_files(),'Pure tests stale')
    source_check(read(OUT/'SOURCE_MANIFEST.json'))
    artifacts={name:sha(OUT/name) for name in ('config.yaml','SOURCE_MANIFEST.json','ENVIRONMENT_LOCK.json','case_manifest.json','smoke_plan.json','pure_tests.json')}
    manifest={'utc':utc(),'files':code_files(),'artifacts':artifacts,'version':VERSION}
    save(OUT/'PRE_SMOKE_FREEZE.json',manifest,exclusive=True);results=[]
    for item in read(OUT/'smoke_plan.json')['smoke_cases']:
        prep_time();result=supervise('smoke',item['transport'],manifest,PREP_DEADLINE-time.time());check=check_smoke(result,item)
        results.append({'case_id':item['transport']['identity']['case_id'],'result':result,'verification':check})
        save(OUT/'smoke_tests.json',{'results':results,'complete':len(results)==2,'passed':all(r['verification']['passed'] for r in results)})
        print('SMOKE '+item['transport']['identity']['case_id']+' '+str(check),flush=True)
        require(check['passed'],'PREPARATION_FAILED: smoke expected outcome failed; no further solves')


def freeze():
    prep_time();manifest=read(OUT/'PRE_SMOKE_FREEZE.json');check_frozen(manifest)
    smoke_result=read(OUT/'smoke_tests.json');require(smoke_result['complete'] and smoke_result['passed'],'Smoke gate closed')
    source_check(read(OUT/'SOURCE_MANIFEST.json'))
    manifest={**manifest,'utc':utc(),'artifacts':{**manifest['artifacts'],'smoke_tests.json':sha(OUT/'smoke_tests.json')},
              'budgets':{'real_paths':490,'smoke':2,'panel_seconds':14400,'worker_seconds':120,'solver_seconds':60},
              'real_panel_authorized':True}
    save(OUT/'IMPLEMENTATION_MANIFEST.json',manifest,exclusive=True);print('FROZEN '+sha(OUT/'IMPLEMENTATION_MANIFEST.json'),flush=True)


def execute():
    from cavr_wbc.evaluation.step02i_inputs import load_all,load_case_path,validate_export,combine_case
    manifest=read(OUT/'IMPLEMENTATION_MANIFEST.json');check_frozen(manifest);source_check(read(OUT/'SOURCE_MANIFEST.json'))
    require(manifest['real_panel_authorized'],'Panel gate closed')
    save(OUT/'RUN_STARTED.json',{'utc':utc(),'first_real_reservation_clock_pending':True,'retry_allowed':False},exclusive=True)
    context=load_all();index={(row['case_id'],row['path']):row for row in read(OUT/'case_manifest.json')['paths']}
    start=None;stop=None;case_rows=[]
    for case in context['cases']:
        pair={}
        for path in PATHS:
            item=index[case['case_id'],path]
            row={**item,'status':'NOT RUN','kind':'not_run','completed':False,'high_precision_feasible':None,
                 'float64_export_accepted':None,'raw_candidate_physical_pass':None,'raw_candidate_fixed_band_pass':None}
            if start is not None and time.monotonic()-start>=14400:stop='RESOURCE_LIMIT'
            if stop is not None:
                row.update(status='NOT RUN_RESOURCE_LIMIT' if stop=='RESOURCE_LIMIT' else 'NOT RUN',reason=stop)
            else:
                try:
                    check_frozen(manifest);require(sha(ROOT/item['input_file'])==item['input_sha256'],'Input file changed')
                    transport,problem,cached,info=load_case_path(case['case_id'],path,context)
                    require(digest(transport)==digest(read(ROOT/item['input_file'])),'Reconstructed input mismatch')
                    if start is None:
                        start=time.monotonic();save(OUT/'PANEL_CLOCK.json',{'utc':utc(),'deadline_unix':time.time()+14400,'limit_seconds':14400},exclusive=True)
                    result=supervise('stage_b',transport,manifest,14400-(time.monotonic()-start))
                    output=result.pop('output');row.update(result,completed=result['kind']!='infrastructure_error')
                    if result['kind']=='infrastructure_error':stop='IMPLEMENTATION_OR_INFRASTRUCTURE_ERROR'
                    if output is not None and not output.get('infrastructure_error',False):
                        require(output['identity']==transport['identity'],'Worker output identity mismatch')
                        row['high_precision_feasible']=output['hp_checks']['high_precision_numerically_feasible']
                        row['high_precision_checks']=output.get('hp_checks')
                        if output.get('float64_w_bits') is not None:
                            require(output['float64_export_roundings']==1,'Export rounding contract changed')
                            w=decode(output['float64_w_bits'])
                            validated=validate_export(problem,cached,info,w,result['status'],all_output_finite=output['all_outputs_finite'])
                            row.update(validated)
                            save(OUT/'float64_outputs'/f"{item['solve_ordinal']:03d}_{path}.json",{'case_id':case['case_id'],'path':path,
                                 'float64_bits':output['float64_w_bits'],'w':[v if math.isfinite(v) else str(v) for v in w],
                                 'rounding_count':1,'validation':validated},exclusive=True)
                except BaseException as exc:
                    stop='IMPLEMENTATION_OR_INFRASTRUCTURE_ERROR';row.update(status='IMPLEMENTATION_ERROR',kind='infrastructure_error',completed=False,
                        reason=str(exc),traceback=traceback.format_exc())
            pair[path]=row;append(OUT/'path_results.jsonl',row)
        case_result=combine_case(case['case_id'],pair['production'],pair['reference'],context)
        case_rows.append(case_result);append(OUT/'case_results.jsonl',case_result)
        complete=sum(bool(c['completed']) for c in case_rows);passed=sum(bool(c['final_case_pass']) for c in case_rows)
        elapsed=time.monotonic()-start if start is not None else 0
        failures=Counter(f for c in case_rows for f in c['failure_categories'])
        print(f'PANEL cases={len(case_rows)}/245 completed={complete} strict_pass={passed} elapsed={elapsed:.1f}s eta={elapsed/max(1,len(case_rows))*(245-len(case_rows)):.1f}s failures={dict(failures)}',flush=True)
    save(OUT/'RUN_FINISHED.json',{'utc':utc(),'stop_reason':stop,'elapsed_seconds':time.monotonic()-start if start else 0,'call_accounting':Ledger().accounting()},exclusive=True)


def table(path,rows):
    fields=list(dict.fromkeys(k for row in rows for k in row))
    with Path(path).open('w',encoding='utf-8',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=fields,lineterminator='\n');writer.writeheader()
        for row in rows:writer.writerow({k:json.dumps(v,ensure_ascii=False,separators=(',',':')) if isinstance(v,(dict,list)) else v for k,v in row.items()})


def deliver():
    from cavr_wbc.evaluation.step02i_inputs import load_all,combine_case
    context=load_all();saved=lines(OUT/'path_results.jsonl');observed={(r['case_id'],r['path']):r for r in saved}
    require(len(observed)==len(saved),'Duplicate result identities')
    paths=[];cases=[]
    for case in context['cases']:
        pair={}
        for path in PATHS:
            row=observed.get((case['case_id'],path),{'case_id':case['case_id'],'path':path,'status':'NOT RUN','kind':'not_run',
                'completed':False,'high_precision_feasible':None,'float64_export_accepted':None,'reason':'Preparation not completed'})
            pair[path]=row;paths.append(row)
        cases.append(combine_case(case['case_id'],pair['production'],pair['reference'],context))
    for row in paths:
        if (row['case_id'],row['path']) not in observed:append(OUT/'path_results.jsonl',row)
    require(len(paths)==490 and len(cases)==245,'Final coverage mismatch')
    table(OUT/'case_results.csv',cases)
    failures=Counter(f for row in cases for f in row['failure_categories'])
    table(OUT/'failure_breakdown.csv',[{'category':k,'case_count':v,'categories_may_overlap':True} for k,v in sorted(failures.items())])
    accounting=Ledger().accounting();finished=read(OUT/'RUN_FINISHED.json') if (OUT/'RUN_FINISHED.json').exists() else {}
    complete=sum(bool(r['completed']) for r in cases);passed=sum(bool(r['final_case_pass']) for r in cases)
    smoke_result=read(OUT/'smoke_tests.json') if (OUT/'smoke_tests.json').exists() else {}
    prep=read(OUT/'PREPARATION_STOP.json') if (OUT/'PREPARATION_STOP.json').exists() else {}
    status='PASS' if passed==245 else 'FAIL / REVISE' if complete==245 else prep.get('status','INCOMPLETE')
    subset=lambda selected:{'total':len(selected),'completed':sum(bool(r['completed']) for r in selected),'strict_pass':sum(bool(r['final_case_pass']) for r in selected)}
    regression=set(context['regression_case_ids']);d_failed=set(context['D_failure_case_ids'])
    result={'stage':'STEP02I','status':status,'verification_level':'ANALYZED','cases_completed':complete,'strict_case_pass':passed,
        'fixed_case_rows':245,'fixed_path_rows':490,'failure_categories':dict(failures),'unique_completed_failed_cases':sum(r['completed'] and not r['final_case_pass'] for r in cases),
        'regression36':subset([r for r in cases if r['case_id'] in regression]),'D_old_failed24':subset([r for r in cases if r['case_id'] in d_failed]),
        'original_four':subset([r for r,c in zip(cases,context['cases']) if c.get('original_four_regression_id')]),
        'call_accounting':accounting,'elapsed_panel_seconds':finished.get('elapsed_seconds',0),'stop_reason':finished.get('stop_reason',prep.get('reason')),
        'smoke_passed':smoke_result.get('complete',False) and smoke_result.get('passed',False),'source_HR_head':BASE,
        'post_hoc_new_numerical_implementation':True,'old_rounded_QP_elementwise_identical':False,'scientific_band_unchanged':True,
        'new_stage_a_or_b1_soft_solves':0,'historical_results_unchanged':True,'exact_certificate_branch':'CLOSED',
        'e1_authorized':False,'e2_quadruped_authorized':False,'further_automatic_solver_search':False}
    source_check(read(OUT/'SOURCE_MANIFEST.json'));save(OUT/'STEP02I_RESULT.json',result)
    summary=f'''## Material Passport

- Origin Skill: experiment-agent / academic-research-suite
- Verification Status: ANALYZED
- Scope: one fixed numerical panel, not an exact certificate or a closed-loop experiment

# STEP02I 数值面板

结果：{status}。完成 {complete}/245；严格通过 {passed}/245；已完成但失败的唯一案例数 {result['unique_completed_failed_cases']}。

失败分类（可重叠）：{json.dumps(dict(failures),ensure_ascii=False)}。
36 回归子集：{result['regression36']}；原四例：{result['original_four']}；D 的24个旧失败：{result['D_old_failed24']}。全部从本轮面板提取，未额外求解。

真实调用：{accounting['stage_b']}；合成 smoke：{accounting['smoke']}。
真实面板耗时：{result['elapsed_panel_seconds']:.3f}s；停止原因：{result['stop_reason']}。

## 实现与判定

冻结双路径独立输入共享 Julia1.10.10 / Clarabel.jl0.11.1 / BigFloat256 / QDLDL 后端。原 binary64 非任务系数与 D 精确提升，仅16条任务 RHS 在高精度中按 target-bias±epsilon*scale 重建。新端点与旧舍入 h 的差值保存在高精度输出，不宣称两个 QP 逐元素相同。科学 band 与外部门未改变，无 inward guard。

高精度数值可行、唯一最近舍入 Float64 导出、原 validator、缓存 Stage-A 及五项等价指标分列。仅 Solved 可接受；高精度通过不覆盖导出失败，未投影、修复或重试。Stage-A/B1-soft 未重跑。高精度数值不是严格最优性证书。

## 研究交接

{'全面板通过，只结束本轮数值修复；下一协议面向 E1 独立物理验证与 E2-B 配对设计。' if passed==245 else '完整失败分布用于研究范围/工程契约的明确取舍，不自动换精度、后端或坐标。' if complete==245 else '本轮未完成，保留已运行与 NOT RUN；基础设施或时限不足不等同研究假设失败。'}
本轮没有机器人执行数据，不能证明实际制动力、闭环安全、终端可达或实时性。并行 E2-A 的解析结果独立报告，不覆盖 N 失败。E1 和四足 E2-B 均不授权。

11/11 方法学风险已检查：逐路径保留防止聚合掩盖；不作生态或筛选样本外推；无碰撞变量回归；分母245不变；无失败重测；所有失败/未运行保留；无多方案择优；承认已见历史结果；不从数值状态推因果或逆因果。确定性开发面板无 p 值、功效或总体置信结论。

完整数值、一次导出与指标见 high_precision_outputs/、float64_outputs/、path_results.jsonl、case_results.csv。配置/环境/源哈希与调用账本随附。H/F/H-R 历史失败/null 状态不变。

EXACT_CERTIFICATE_BRANCH = CLOSED
E1_AUTHORIZED = FALSE
E2_QUADRUPED_AUTHORIZED = FALSE
FURTHER_AUTOMATIC_SOLVER_SEARCH = FALSE
'''
    (OUT/'STEP02I_REPORT.md').write_text(summary,encoding='utf-8',newline='\n')
    (OUT/'EXECUTION_HANDOFF.md').write_text(f'# STEP02I handoff\n\n{status}: {complete}/245 complete, {passed}/245 strict pass.\nRead STEP02I_REPORT.md, STEP02I_RESULT.json and case_results.csv. No retry/solver search/E1/quadruped execution authorized.\n',encoding='utf-8',newline='\n')
    print(json.dumps({k:result[k] for k in ('status','cases_completed','strict_case_pass','failure_categories','call_accounting')},ensure_ascii=False),flush=True)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('phase',choices=['prepare','pure-tests','smoke','freeze','execute','deliver']);args=parser.parse_args()
    OUT.mkdir(exist_ok=True,parents=True);LOCAL.mkdir(exist_ok=True)
    append(OUT/'commands.jsonl',{'event':'START','phase':args.phase,'utc':utc(),'argv':sys.argv})
    try:{'prepare':prepare,'pure-tests':pure_tests,'smoke':smoke,'freeze':freeze,'execute':execute,'deliver':deliver}[args.phase]()
    except BaseException as exc:
        append(OUT/'commands.jsonl',{'event':'ERROR','phase':args.phase,'utc':utc(),'error':repr(exc)})
        if args.phase in ('prepare','smoke','freeze') and not (OUT/'RUN_STARTED.json').exists():
            save(OUT/'PREPARATION_STOP.json',{'status':'PREPARATION_INCOMPLETE' if time.time()>=PREP_DEADLINE else 'PREPARATION_FAILED',
                'utc':utc(),'phase':args.phase,'reason':str(exc),'optimization_retry_authorized':False})
        raise
    else:append(OUT/'commands.jsonl',{'event':'END','phase':args.phase,'utc':utc()})


if __name__=='__main__':main()
