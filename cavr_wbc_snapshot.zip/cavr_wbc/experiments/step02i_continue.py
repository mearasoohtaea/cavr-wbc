"""Thin finite continuation: reuse STEP02I execution and scientific validation.

Only paths/time budgets, old evidence linkage and smoke objective acceptance
change. This entry never calls the old prepare/smoke/deliver entry points.
"""
from __future__ import annotations
import argparse
from collections import Counter
from datetime import datetime
import io
import json
from pathlib import Path
import subprocess
import sys
import time
import unittest

from cavr_wbc.experiments import step02i as base
from cavr_wbc.evaluation import step02i_inputs as inputs

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'artifacts/step02i_smoke_contract_continuation'
OLD=ROOT/'artifacts/step02i_bigfloat_full_panel'
SOURCE=ROOT.parent/'cavr_step02i_bigfloat_full_panel_20260918'
HEAD='829663733236bbb14477d35da9deb278babddea7'
DEADLINE=datetime.fromisoformat('2026-09-18T13:23:08+00:00').timestamp()
LegacyLedger=base.Ledger
legacy_supervise=base.supervise
read,save,sha,require=base.read,base.save,base.sha,base.require


class ContinuationLedger(LegacyLedger):
    def __init__(self,path=None):super().__init__(OUT/'solve_ledger.jsonl' if path is None else path)
    def reserve(self,category,case_id,path,input_hash):
        old=LegacyLedger(OLD/'solve_ledger.jsonl').events()
        require(not any(r['event']=='RESERVED' and r['identity']==[category,case_id,path] for r in old),'Identity already called in original I')
        if category=='smoke':
            require((case_id,path)==('negative_active_thin_band','smoke'),'Only second smoke may be called')
            require(not any(r['event']=='RESERVED' and r['identity'][0]=='smoke' for r in self.events()),'One new smoke budget exhausted')
        else:
            require(category=='stage_b','Unknown continuation stage')
            allowed={(r['case_id'],r['path']) for r in read(OUT/'case_manifest.json')['paths']}
            require((case_id,path) in allowed,'Real identity outside frozen panel')
        return super().reserve(category,case_id,path,input_hash)
    def accounting(self):
        result=super().accounting();result['smoke']['budget']=1
        return result


def code_files():
    files=[Path(__file__),ROOT/'cavr_wbc/evaluation/step02i_smoke_v2.py',
        ROOT/'tests/test_step02i_smoke_v2.py',ROOT/'tests/test_step02i_continue.py',
        ROOT/'cavr_wbc/experiments/step02i.py',ROOT/'cavr_wbc/evaluation/step02i_inputs.py']
    files+=sorted((ROOT/'julia/step02i').glob('*'))
    files+=[OUT/'config.yaml',OUT/'PROTOCOL_AMENDMENT.md',OUT/'NEXT_CODEX_INSTRUCTIONS_STEP02I_CONTINUATION.md']
    return {p.relative_to(ROOT).as_posix():sha(p) for p in files if p.is_file()}


def supervise(category,transport,manifest,remaining):
    result=legacy_supervise(category,transport,manifest,remaining)
    output=result.get('output')
    if output is not None and not output.get('infrastructure_error'):
        require(output['settings']==read(OUT/'ENVIRONMENT_LOCK.json')['complete_actual_settings'],'Expanded solver settings drift')
    return result


# Dynamic binding affects globals used inside original functions. The original
# module source and real numerical runner remain byte-identical to source I.
base.OUT=OUT
base.PREP_DEADLINE=DEADLINE
base.Ledger=ContinuationLedger
base.code_files=code_files
base.supervise=supervise


def history_check(manifest):
    require(subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip()==HEAD,'Original I HEAD changed')
    require(subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain=v1'],text=True).strip()=='','Original I worktree changed')
    for name,value in manifest['original_files'].items():
        require(sha(SOURCE/name)==value and sha(ROOT/name)==value,'Old evidence changed: '+name)
    require(read(OLD/'STEP02I_RESULT.json')['status']=='PREPARATION_FAILED','Old failure must remain unchanged')
    require(read(ROOT/'artifacts/e2_analytic/E2_ANALYTIC_RESULT.json')['status']=='PASS','M result changed')


def prepare():
    base.prep_time();require(not (OUT/'ORIGIN_MANIFEST.json').exists(),'Continuation already prepared')
    expected={'smoke_plan.json':'533f2f1201988bf6fefb5219fd62c746082bc380616abc10cef0bc5048bf91fd',
        'smoke_tests.json':'762d5015c719bf4cf83ad76cda11faa2a98f4a7aef0bd9b4b72eda0196939b03',
        'config.yaml':'412e92a4920f6004f890ef17a013ef1fcbb094dbecafa6e97b262a87d82f4e98'}
    for name,value in expected.items():require(sha(OLD/name)==value,'Protocol source hash mismatch: '+name)
    require(sha(OUT/'config.yaml')==expected['config.yaml'],'New numerical config must be byte-identical')
    names=['smoke_plan.json','smoke_tests.json','config.yaml','STEP02I_RESULT.json','solve_ledger.jsonl',
        'case_manifest.json','ENVIRONMENT_LOCK.json','SOURCE_MANIFEST.json','workers/smoke_01/input.json',
        'workers/smoke_01/entry_receipt.json','high_precision_outputs/smoke_01.json']
    files={str((OLD/name).relative_to(ROOT)).replace('\\','/'):sha(OLD/name) for name in names}
    m=ROOT/'artifacts/e2_analytic'
    for name in ['E2_ANALYTIC_RESULT.json',*read(m/'E2_ANALYTIC_RESULT.json')['output_sha256']]:
        files[(m/name).relative_to(ROOT).as_posix()]=sha(m/name)
    for name in ('cavr_wbc/experiments/step02i.py','cavr_wbc/evaluation/step02i_inputs.py'):
        files[name]=sha(ROOT/name)
    origin={'source_worktree':str(SOURCE),'source_commit':HEAD,'original_files':files,
        'old_result':'PREPARATION_FAILED','old_actual_optimization_calls':1,'M_result_unchanged':'PASS'}
    history_check(origin)
    account=LegacyLedger(OLD/'solve_ledger.jsonl').accounting()
    require(account['smoke']['actual_calls']==1 and account['stage_b']['reserved']==0,'Original call accounting differs')
    context=inputs.load_all();base.source_check(context['source_manifest'])
    save(OUT/'SOURCE_MANIFEST.json',context['source_manifest'],exclusive=True)
    save(OUT/'ORIGIN_MANIFEST.json',origin,exclusive=True)
    manifest=read(OLD/'case_manifest.json')
    require(len(manifest['paths'])==490,'Fixed path count changed')
    for item in manifest['paths']:require(sha(ROOT/item['input_file'])==item['input_sha256'],'Inherited input changed')
    save(OUT/'case_manifest.json',manifest,exclusive=True)
    plan=read(OLD/'smoke_plan.json')
    save(OUT/'smoke_plan_v2.json',{'amendment':'POST_HOC_SMOKE_OBJECTIVE_CHECK','original_plan_sha256':expected['smoke_plan.json'],
        'first_transport':plan['smoke_cases'][0]['transport'],'second_transport':plan['smoke_cases'][1]['transport'],
        'atol':'1e-20','rtol':'1e-20','decimal_precision_minimum':100,'coordinate_error_gate':False,
        'first_formula':'(u-1)^2+(v-2)^2; f_star=-5; eta=5e-20',
        'second_formula':'(1-2*e)*du+du^2+dv^2; f_star=-4-e+e^2; eta=max(atol,rtol*max(1,abs(f_star)))',
        'new_smoke_limit':1,'no_matrix_changes':True},exclusive=True)
    base.prep_time();print('PREPARED: inherited490 inputs checked; old smoke1 consumed, zero new solves',flush=True)


def pure_tests():
    base.prep_time();require(not (OUT/'PRE_SMOKE_FREEZE.json').exists(),'No code refinement after new smoke freeze')
    suite=unittest.TestSuite()
    for name in ('test_step02i_smoke_v2.py','test_step02i_continue.py'):
        suite.addTests(unittest.defaultTestLoader.discover(str(ROOT/'tests'),pattern=name))
    stream=io.StringIO();result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    (OUT/'tests.txt').write_text(stream.getvalue(),encoding='utf-8',newline='\n')
    save(OUT/'pure_tests.json',{'utc':base.utc(),'passed':result.wasSuccessful(),'tests_run':result.testsRun,
        'failures':len(result.failures),'errors':len(result.errors),'new_optimizer_calls':0,'files':code_files()})
    print(stream.getvalue(),flush=True);require(result.wasSuccessful(),'Pure continuation tests failed');base.prep_time()


def reassess():
    from cavr_wbc.evaluation.step02i_smoke_v2 import assess
    base.prep_time();require(not (OUT/'smoke_reassessment.json').exists(),'Reassessment already saved')
    origin=read(OUT/'ORIGIN_MANIFEST.json');history_check(origin)
    transport=read(OLD/'workers/smoke_01/input.json');output=read(OLD/'high_precision_outputs/smoke_01.json')
    record={'status':'REUSED_OUTPUT_REASSESSED','new_solve_calls':0,'old_solve_calls':1,
        'input_file':str(OLD/'workers/smoke_01/input.json'),'input_sha256':sha(OLD/'workers/smoke_01/input.json'),
        'output_file':str(OLD/'high_precision_outputs/smoke_01.json'),'output_sha256':sha(OLD/'high_precision_outputs/smoke_01.json'),
        'receipt_file':str(OLD/'workers/smoke_01/entry_receipt.json'),'receipt_sha256':sha(OLD/'workers/smoke_01/entry_receipt.json'),
        'assessment':assess(transport,output)}
    save(OUT/'smoke_reassessment.json',{'first':record,'second':{'status':'NOT RUN','new_solve_calls':0},'both_passed':False},exclusive=True)
    print('REUSED_OUTPUT_REASSESSED '+json.dumps(record['assessment']),flush=True)
    require(record['assessment']['passed'],'Saved first smoke fails amended contract')


def second_smoke():
    from cavr_wbc.evaluation.step02i_smoke_v2 import assess
    base.prep_time();require(not (OUT/'PRE_SMOKE_FREEZE.json').exists(),'Second smoke already frozen/attempted')
    tests=read(OUT/'pure_tests.json');require(tests['passed'] and tests['files']==code_files(),'Current pure tests stale')
    history_check(read(OUT/'ORIGIN_MANIFEST.json'));records=read(OUT/'smoke_reassessment.json')
    require(records['first']['assessment']['passed'],'First reassessment gate closed')
    artifacts={name:sha(OUT/name) for name in ('config.yaml','SOURCE_MANIFEST.json','ORIGIN_MANIFEST.json','ENVIRONMENT_LOCK.json',
        'case_manifest.json','smoke_plan_v2.json','pure_tests.json','PREPARATION_CLOCK.json')}
    manifest={'utc':base.utc(),'files':code_files(),'artifacts':artifacts,'version':'STEP02I_SMOKE_CONTRACT_V2'}
    save(OUT/'PRE_SMOKE_FREEZE.json',manifest,exclusive=True)
    transport=read(OUT/'smoke_plan_v2.json')['second_transport']
    result=supervise('smoke',transport,manifest,DEADLINE-time.time())
    assessment=assess(transport,result['output']) if result.get('output') is not None and result['kind']!='infrastructure_error' else {'passed':False,'reason':result['status']}
    records['second']={'status':result['status'],'new_solve_calls':result['confirmed_solve_calls'],'execution':result,'assessment':assessment}
    records['both_passed']=bool(records['first']['assessment']['passed'] and assessment['passed'])
    save(OUT/'smoke_reassessment.json',records)
    print('SECOND_SMOKE '+json.dumps(assessment),flush=True)
    require(records['both_passed'],'Second smoke failed amended contract; no retry or new adjustment')


def freeze():
    base.prep_time();manifest=read(OUT/'PRE_SMOKE_FREEZE.json');base.check_frozen(manifest)
    require(read(OUT/'smoke_reassessment.json')['both_passed'],'Smoke gate closed')
    history_check(read(OUT/'ORIGIN_MANIFEST.json'));base.source_check(read(OUT/'SOURCE_MANIFEST.json'))
    save(OUT/'IMPLEMENTATION_MANIFEST.json',{**manifest,'utc':base.utc(),
        'artifacts':{**manifest['artifacts'],'smoke_reassessment.json':sha(OUT/'smoke_reassessment.json')},
        'real_panel_authorized':True,'budgets':{'new_smoke':1,'new_real':490,'cumulative':492,'panel_seconds':14400}},exclusive=True)
    print('FROZEN real panel authorized; '+sha(OUT/'IMPLEMENTATION_MANIFEST.json'),flush=True)


def execute():
    history_check(read(OUT/'ORIGIN_MANIFEST.json'))
    base.execute()


def deliver():
    context=inputs.load_all();observed=base.lines(OUT/'path_results.jsonl');index={(r['case_id'],r['path']):r for r in observed}
    require(len(index)==len(observed),'Duplicate real path output')
    cases=[]
    stop=read(OUT/'PREPARATION_STOP.json') if (OUT/'PREPARATION_STOP.json').exists() else {}
    finished=read(OUT/'RUN_FINISHED.json') if (OUT/'RUN_FINISHED.json').exists() else {}
    for case in context['cases']:
        pair={}
        for path in base.PATHS:
            key=(case['case_id'],path)
            pair[path]=index.get(key,{'case_id':key[0],'path':path,'status':'NOT RUN','kind':'not_run',
                'completed':False,'high_precision_feasible':None,'float64_export_accepted':None,'reason':stop.get('reason','Not dispatched')})
            if key not in index:base.append(OUT/'path_results.jsonl',pair[path])
        cases.append(inputs.combine_case(case['case_id'],pair['production'],pair['reference'],context))
    base.table(OUT/'case_results.csv',cases)
    failures=Counter(f for row in cases for f in row['failure_categories'])
    base.table(OUT/'failure_breakdown.csv',[{'category':k,'case_count':v,'may_overlap':True} for k,v in sorted(failures.items())] or [{'category':'NONE','case_count':0,'may_overlap':True}])
    complete=sum(r['completed'] for r in cases);passed=sum(r['final_case_pass'] for r in cases);account=ContinuationLedger().accounting()
    status='PASS' if passed==245 else 'FAIL / REVISE' if complete==245 else stop.get('status','INCOMPLETE')
    subset=lambda selected:{'count':len(selected),'completed':sum(r['completed'] for r in selected),'strict_pass':sum(r['final_case_pass'] for r in selected)}
    cumulative_lower=1+sum(r['calls_lower_bound'] for r in account.values());cumulative_upper=1+sum(r['calls_upper_bound'] for r in account.values())
    result={'status':status,'old_step02i_result':'PREPARATION_FAILED','protocol_amendment':'POST_HOC_SMOKE_OBJECTIVE_CHECK',
        'cases_completed':complete,'strict_pass':passed,'case_count':245,'path_count':490,'failure_categories':dict(failures),
        'completed_unique_failed_cases':sum(r['completed'] and not r['final_case_pass'] for r in cases),
        'first_smoke_reused_new_solves':0,'new_call_accounting':account,
        'cumulative_calls':cumulative_lower if cumulative_lower==cumulative_upper else None,
        'cumulative_call_lower_bound':cumulative_lower,'cumulative_call_upper_bound':cumulative_upper,
        'elapsed_panel_seconds':finished.get('elapsed_seconds',0),'stop_reason':finished.get('stop_reason',stop.get('reason')),
        'regression36':subset([r for r in cases if r['regression_member']]),
        'D_old_failed24':subset([r for r in cases if r['old_step02d_failure_member']]),
        'original_four':subset([r for r in cases if r.get('original_four_regression_id')]),
        'new_stage_a_or_b1_soft_solves':0,'e2_analytic_result_unchanged':'PASS','E2_analytic_new_exports':0,
        'exact_certificate_branch':'CLOSED','historical_results_unchanged':True,'e1_authorized':False,
        'e2_quadruped_authorized':False,'further_automatic_solver_search':False,'verification_level':'ANALYZED'}
    history_check(read(OUT/'ORIGIN_MANIFEST.json'));base.source_check(read(OUT/'SOURCE_MANIFEST.json'))
    save(OUT/'STEP02I_CONTINUATION_RESULT.json',result)
    report=f'''# STEP02I continuation — {status}

真实覆盖{complete}/245，严格通过{passed}/245；已完成且失败唯一案例{result['completed_unique_failed_cases']}。分类可重叠：{dict(failures)}。
调用：本轮{account}；两次I累计{cumulative_lower}–{cumulative_upper}/492。首smoke仅重评，新增0。面板耗时{result['elapsed_panel_seconds']:.3f}s；停止原因{result['stop_reason']}。
36回归{result['regression36']}；原四例{result['original_four']}；D旧24失败{result['D_old_failed24']}。均从同一固定面板提取，无额外求解。

这是后验开发协议修订，取消任意坐标smoke硬门，按已知解析目标与原tol_gap_abs/rel检查；坐标误差只报告。原PREPARATION_FAILED和passed=false未改，首例重评不是独立新样本。公式和引用见PROTOCOL_AMENDMENT.md，两个smoke原数值与目标/约束重评见smoke_reassessment.json。

真实D坐标、16条高精度任务RHS重建、物理/故障/任务/目标、完整solver设置和外部门均未改变。原binary64非任务系数精确提升；新的任务端点与旧舍入QP不逐元素相同，无inward guard。两路径读取此前独立输入，共用后端；不是两个独立新solver。
高精度可行、一次最近Float64导出、Solved状态、原物理/band门与五项等价指标分列。高精度不能覆盖Float64失败，不接受AlmostSolved。Stage-A来自D full_panel缓存，B1-soft无新求解。未执行身份保持NOT RUN；没有重试、修点、逐例调参或删除压力例。

{'面板严格通过，结束数值准备。下一轮需独立E1物理验证与E2-B有限配对执行协议；本轮不执行。' if passed==245 else '面板仍有失败，结束自动数值修复；据完整分布由研究方明确工程验收契约与物理执行影响，不追加相似门控或solver搜索。' if complete==245 else '面板未完整执行；具体停止原因与NOT RUN已保留。准备/基础设施/时间限制不能写成研究假设失败。'}
E2-A的PASS、解析图和四足设计仅引用既有artifacts/e2_analytic，不重跑。理论、强预测B3基线与四足闭环验证仍是后续研究要求；数值通过不替代这些证据。

Material Passport: experiment-agent / academic-research-suite；ANALYZED。技能用于有界监控、调用归属、分开判定及交接，不作独立复现宣称。11/11方法风险检查：固定分母与条件分列，无总体/机器人外推，无选择样本/碰撞变量推因果，不忽略基率，不重测极值或只保留幸存者，无多方案择优，明确后验修订，不推因果或逆因果。确定性DEV不做p值或功效推断。

EXACT_CERTIFICATE_BRANCH = CLOSED
HISTORICAL_RESULTS_UNCHANGED = TRUE
E1_AUTHORIZED = FALSE
E2_QUADRUPED_AUTHORIZED = FALSE
FURTHER_AUTOMATIC_SOLVER_SEARCH = FALSE
'''
    (OUT/'STEP02I_CONTINUATION_REPORT.md').write_text(report,encoding='utf-8',newline='\n')
    print(json.dumps(result),flush=True)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('phase',choices=['prepare','pure-tests','reassess','second-smoke','freeze','execute','deliver']);args=parser.parse_args()
    OUT.mkdir(parents=True,exist_ok=True);base.LOCAL.mkdir(exist_ok=True)
    base.append(OUT/'commands.jsonl',{'event':'START','phase':args.phase,'utc':base.utc(),'argv':sys.argv})
    try:{'prepare':prepare,'pure-tests':pure_tests,'reassess':reassess,'second-smoke':second_smoke,'freeze':freeze,'execute':execute,'deliver':deliver}[args.phase]()
    except BaseException as exc:
        base.append(OUT/'commands.jsonl',{'event':'ERROR','phase':args.phase,'utc':base.utc(),'error':repr(exc)})
        if args.phase not in ('execute','deliver') and not (OUT/'RUN_STARTED.json').exists():
            save(OUT/'PREPARATION_STOP.json',{'status':'PREPARATION_INCOMPLETE' if time.time()>=DEADLINE else 'PREPARATION_FAILED','reason':str(exc),'utc':base.utc(),'phase':args.phase})
        raise
    else:base.append(OUT/'commands.jsonl',{'event':'END','phase':args.phase,'utc':base.utc()})


if __name__=='__main__':main()
