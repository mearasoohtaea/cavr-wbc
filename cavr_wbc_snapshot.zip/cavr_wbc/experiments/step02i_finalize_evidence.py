"""One-shot, no-solve delivery after the frozen PID-only guard failed.

This supplementary file is NOT a runner or a change to frozen numerical code.
It verifies process creation identities, appends only the missing UNKNOWN
observation (never a FINISHED ledger event), and uses the frozen saved-output
delivery function. The only subprocess is a read-only Windows process query.
"""
from __future__ import annotations

from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess


def classify_pid(record, process):
    if process is None:
        return 'PID_ABSENT'
    created = process.get('creation_utc')
    if not created:
        return 'UNRESOLVED_BLOCK'
    # The recorded utc is AFTER Popen returned. A process created later cannot
    # be that worker. Use a two-second margin, fail closed otherwise.
    delta = (datetime.fromisoformat(created.replace('Z', '+00:00')) -
             datetime.fromisoformat(record['utc'].replace('Z', '+00:00'))).total_seconds()
    return 'REUSED_PID_ORIGINAL_EXITED' if delta > 2 else 'POSSIBLY_ORIGINAL_BLOCK'


def process_audit(records):
    ids = sorted({r['pid'] for r in records} | {29352, 17956, 10632, 19548})
    script = "$ErrorActionPreference='Stop'; [Console]::OutputEncoding=[Text.Encoding]::UTF8\n"
    script += '$taskIds=@(' + ','.join(map(str, ids)) + ')\n'
    script += """$items=@(Get-CimInstance Win32_Process | Where-Object {
 $taskIds -contains $_.ProcessId -or $_.Name -match '^(python|julia)(\\.exe)?$'
} | ForEach-Object { [pscustomobject]@{
 pid=$_.ProcessId; parent_pid=$_.ParentProcessId; name=$_.Name;
 creation_utc=$_.CreationDate.ToUniversalTime().ToString('o'); command=$_.CommandLine
}})
[pscustomobject]@{observed_utc=[DateTime]::UtcNow.ToString('o');processes=$items} | ConvertTo-Json -Depth 5
"""
    snapshot = json.loads(subprocess.check_output(
        ['powershell.exe', '-NoProfile', '-NonInteractive', '-Command', script],
        encoding='utf-8-sig', creationflags=subprocess.CREATE_NO_WINDOW))
    by_pid = {p['pid']: p for p in snapshot['processes']}
    results = [{**r, 'classification': classify_pid(r, by_pid.get(r['pid'])),
                'current_process': by_pid.get(r['pid'])} for r in records]
    remaining = [p for p in snapshot['processes']
                 if p['name'].lower() in ('python.exe', 'julia.exe')
                 and p['pid'] not in (os.getpid(), os.getppid())]
    return {**snapshot, 'worker_and_supervisor_records': results,
            'other_python_or_julia': remaining,
            'safe': not remaining and all(r['classification'] in
                ('PID_ABSENT', 'REUSED_PID_ORIGINAL_EXITED') for r in results)}


def finalize():
    from cavr_wbc.experiments import step02i_resume as r
    from cavr_wbc.experiments import step02i_reboot as reboot
    from cavr_wbc.experiments.step02i_resume_delivery import deliver

    evidence = r.OUT / 'final_delivery'
    evidence.mkdir(exist_ok=True)
    r.require(not (r.OUT/'STEP02I_RESUME_RESULT.json').exists(), 'Already delivered; no overwrite')
    with r.singleton():
        r.save(evidence/'FINALIZE_STARTED.json', {'utc': r.base.utc(), 'pid': os.getpid(),
               'source_sha256': r.sha(Path(__file__)), 'optimizer_calls': 0}, exclusive=True)
        commands = r.base.lines(r.OUT/'commands.jsonl')
        failures = [c for c in commands if c.get('phase') == 'summarize' and c.get('event') == 'ERROR']
        starts = [c for c in commands if c.get('phase') == 'summarize' and c.get('event') == 'START']
        r.require(len(starts) == len(failures) == 1 and 'Recorded worker PID still active' in failures[0]['error'],
                  'Only the documented one-shot PID guard failure permits this finalizer')
        r.save(evidence/'ORIGINAL_SUMMARIZE_FAILURE.json', {'start': starts[0], 'error': failures[0],
               'exception_phase': 'PID guard before reconciliation or delivery', 'optimizer_calls': 0}, exclusive=True)
        records = [{**r.read(p), 'record_file': str(p.relative_to(r.ROOT))}
                   for p in sorted((r.OUT/'workers').glob('*/process.json'))]
        for name in ('RUN_STARTED.json', 'reboot_20260919/RUN_STARTED.json'):
            record = r.read(r.OUT/name)
            records.append({'pid': record['pid'], 'utc': record['started_utc'], 'record_file': name})
        processes = process_audit(records)
        r.save(evidence/'PROCESS_IDENTITY_AUDIT.json', processes, exclusive=True)
        r.require(processes['safe'], 'Matching or unresolved process: no delivery permitted')
        frozen = r.read(reboot.FREEZE)
        manifest, events = reboot.verify_restart(frozen, enforce_deadline=False)
        runtime = r.read(r.OUT/'ENVIRONMENT_LOCK.json')['reused_frozen_files']
        runtime_audit = {p: {'expected': h, 'actual': r.sha(Path(p))} for p, h in runtime.items()}
        r.require(all(v['expected'] == v['actual'] for v in runtime_audit.values()), 'Frozen runtime changed')
        stop = r.read(r.OUT/'RUN_FINISHED.json')
        r.require(stop == r.read(reboot.EXTRA/'RUN_FINISHED.json') and stop['exit_code'] == 0
                  and stop['stop_reason'] is None and stop['frozen_check_error'] is None,
                  'Unexpected end state; preserve evidence and stop')
        rows = r.base.lines(r.OUT/'attempt_results.jsonl')
        reservations = [e for e in events if e['event'] == 'RESERVED']
        finished = {tuple(e['identity']) for e in events if e['event'] == 'FINISHED'}
        pending = [e for e in reservations if tuple(e['identity']) not in finished]
        r.require(len(reservations) == 468 and len(finished) == len(rows) == 467,
                  'Unexpected final accounting')
        r.require(len({(p['case_id'], p['path'], p['attempt']) for p in rows}) == 467, 'Duplicate return')
        r.require([e['metadata']['solve_ordinal'] for e in pending] == [118], 'Unexpected pending identity')
        event = pending[0]
        item = next(p for p in manifest['remaining_paths'] if p['solve_ordinal'] == 118)
        r.require(tuple(event['identity']) == (item['case_id'], 'reference', 1), 'Pending identity mismatch')
        r.require(not (r.OUT/'high_precision_outputs/118_reference.json').exists()
                  and not (r.OUT/'workers/118_reference/entry_receipt.json').exists(),
                  'Late evidence requires separate review')
        ledger_hash = r.sha(r.OUT/'solve_ledger.jsonl')
        r.save(evidence/'PRE_DELIVERY_AUDIT.json', {
            'utc': r.base.utc(), 'resume_manifest_sha256': r.sha(r.OUT/'RESUME_MANIFEST.json'),
            'restart_manifest_sha256': r.sha(reboot.FREEZE), 'clock_sha256': r.sha(r.OUT/'PANEL_CLOCK.json'),
            'original_and_restart_frozen_checks': 'PASS', 'runtime_files': runtime_audit,
            'append_only_prefix_checks': 'PASS', 'worker_record_count': len(records)-2,
            'ledger_sha256': ledger_hash, 'accounting': r.ledger().accounting(),
            'pending_identity': event['identity'], 'optimizer_calls': 0}, exclusive=True)
        # Exact original reconciliation semantics; no new reservation, no finish,
        # no receipt, no output, and no attempt2 for ordinal 118.
        r.base.append(r.OUT/'attempt_results.jsonl', {
            **item, 'status': 'INTERRUPTED_UNKNOWN_CALL', 'kind': 'infrastructure_error',
            'completed': False, 'valid_output': False, 'confirmed_solve_calls': 0,
            'unknown_call_upper_bound': 1, 'run_id': manifest['run_id'],
            'source': 'POST_RUN_RECONCILIATION',
            'reason': 'Reserved attempt ended before path publication. No retry.'})
        result = deliver(r.OUT, r.OLD, manifest, r.ledger().accounting(), stop)
        r.require(result['status'] == 'INCOMPLETE' and result['strict_pass'] == 117
                  and result['valid_output_pair_coverage'] == 244, 'Unexpected aggregate')
        # Supplement metadata, not frozen numerical decisions. Preserve the
        # generated versions in this new directory before adding disclosures.
        r.save(evidence/'GENERATED_RESULT_BEFORE_METADATA_SUPPLEMENT.json', result, exclusive=True)
        original_report = (r.OUT/'STEP02I_RESUME_REPORT.md').read_text(encoding='utf-8')
        (evidence/'GENERATED_REPORT_BEFORE_METADATA_SUPPLEMENT.md').write_text(original_report, encoding='utf-8')
        result.update(
            returned_new_path_records=467, unknown_new_attempt_records=1,
            completed_strict_failures=127, incomplete_cases=1,
            post_reboot_supervisor_finished_normally=True,
            new_unknown_identity={'solve_ordinal': 118, 'case_id': item['case_id'], 'path': 'reference', 'attempt': 1},
            missing_numerical_pair_reason='First resume segment interrupted; no ordinal118 output; no retry authorized',
            post_reboot_user_context='User reported accidental computer reboot and explicitly requested one supervisor restart',
            observed_os_boot_utc='2026-09-19T08:42:38.500000Z',
            original_resume_segment_exact_exit_time='UNKNOWN',
            final_delivery_optimizer_calls=0,
            final_delivery_method='Identity-aware PID reconciliation and unchanged frozen saved-output deliver',
            final_delivery_evidence_directory=str(evidence))
        result['post_hoc_amendments'].append('EXPLICIT_USER_AUTHORIZED_POST_REBOOT_SUPERVISOR_ONLY_NO_NEW_RETRY_OR_CLOCK')
        r.save(r.OUT/'STEP02I_RESUME_RESULT.json', result)
        r.require(r.sha(r.OUT/'solve_ledger.jsonl') == ledger_hash, 'Delivery must not change solve ledger')
        reboot.verify_restart(frozen, enforce_deadline=False)
        r.save(evidence/'FINALIZE_FINISHED.json', {'utc': r.base.utc(), 'status': result['status'],
               'optimizer_calls': 0, 'ledger_unchanged': True, 'all_frozen_checks': 'PASS',
               'result_sha256': r.sha(r.OUT/'STEP02I_RESUME_RESULT.json')}, exclusive=True)
        print(json.dumps({k: result[k] for k in ('status', 'attempted_paths', 'attempted_pair_coverage',
              'valid_output_pair_coverage', 'strict_pass', 'stage_b_cumulative_call_interval', 'i_cumulative_call_interval')}))


if __name__ == '__main__':
    finalize()
