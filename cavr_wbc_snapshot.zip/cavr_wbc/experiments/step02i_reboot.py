"""Explicit user-authorized post-reboot supervisor, with no new retry or clock.

The original frozen resume implementation remains byte-for-byte unchanged.
This wrapper excludes ALL previous reservations, including unknown calls.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import traceback

from cavr_wbc.experiments import step02i_resume as r

EXTRA = r.OUT / 'reboot_20260919'
SOURCE = Path(__file__).resolve()
TEST = r.ROOT / 'tests/test_step02i_reboot_restart.py'
AUTHORIZATION = EXTRA / 'USER_AUTHORIZATION.md'
FREEZE = EXTRA / 'RESTART_MANIFEST.json'


def select_remaining(manifest, events):
    """Exclude consumed reservations, not just successful/finished paths."""
    consumed = {tuple(e['identity']) for e in events if e['event'] == 'RESERVED'}
    return [item for item in manifest['remaining_paths']
            if (item['case_id'], item['path'], item['attempt']) not in consumed]


def snapshot():
    script = """$ErrorActionPreference='Stop'
$osInfo=Get-CimInstance Win32_OperatingSystem
$items=@(Get-CimInstance Win32_Process | Where-Object { $_.Name -match 'python|julia' } | ForEach-Object {
 [pscustomobject]@{pid=$_.ProcessId;parent_pid=$_.ParentProcessId;creation_utc=$_.CreationDate.ToUniversalTime().ToString('o');command=$_.CommandLine;name=$_.Name}
})
[pscustomobject]@{observed_utc=[DateTime]::UtcNow.ToString('o');boot_utc=$osInfo.LastBootUpTime.ToUniversalTime().ToString('o');processes=$items} | ConvertTo-Json -Depth 4
"""
    value = json.loads(subprocess.check_output(
        ['powershell.exe', '-NoProfile', '-NonInteractive', '-Command', script],
        encoding='utf-8', creationflags=subprocess.CREATE_NO_WINDOW))
    owned = []
    for proc in value['processes']:
        if proc['pid'] in (os.getpid(), os.getppid()):
            continue
        command = (proc.get('command') or '').replace('\\', '/').lower()
        worker = str(r.ROOT).replace('\\', '/').lower()+'/julia/step02i/worker.jl'
        if (worker in command or 'cavr_wbc.experiments.step02i_resume run' in command
                or 'cavr_wbc.experiments.step02i_reboot supervisor' in command):
            owned.append(proc)
    r.require(not owned, 'Another matching supervisor or worker is active: '+repr(owned))
    return value


def verify_restart(frozen, *, exact_prefix=False, enforce_deadline=True):
    if (EXTRA/'LAUNCH_INTENT.json').exists():
        r.require(r.sha(FREEZE) == r.read(EXTRA/'LAUNCH_INTENT.json')['restart_manifest_sha256'], 'Restart manifest changed')
    manifest = r.read(r.OUT/'RESUME_MANIFEST.json')
    r.check_frozen(manifest)
    r.require(r.sha(r.OUT/'RESUME_MANIFEST.json') == frozen['resume_manifest_sha256'], 'Resume manifest changed')
    r.require(r.sha(r.OUT/'PANEL_CLOCK.json') == frozen['panel_clock_sha256'], 'Original clock changed')
    r.require(manifest['run_id'] == frozen['run_id'], 'run_id changed')
    for name, expected in frozen['implementation_files'].items():
        r.require(r.sha(r.ROOT/name) == expected, 'Restart implementation changed: '+name)
    for name, expected in frozen['preserved_files'].items():
        r.require(r.sha(r.OUT/name) == expected, 'Pre-reboot evidence changed: '+name)
    for name, prefix in frozen['append_only_prefixes'].items():
        raw = (r.OUT/name).read_bytes()
        r.require(len(raw) >= prefix['bytes'] and
                  hashlib.sha256(raw[:prefix['bytes']]).hexdigest() == prefix['sha256'],
                  'Pre-reboot append-only prefix changed: '+name)
        if exact_prefix:
            r.require(len(raw) == prefix['bytes'], 'Evidence advanced before authorized restart: '+name)
    # Constructor keeps the original FULL 468-identity plan and existing clock.
    events = r.ledger().events()
    r.ledger().clock()
    if enforce_deadline:
        r.require(r.remaining_seconds() > 0, 'RESOURCE_LIMIT: original deadline already reached')
    return manifest, events


def freeze_restart():
    EXTRA.mkdir(exist_ok=True)
    r.require(AUTHORIZATION.exists() and not FREEZE.exists(), 'Missing authorization or restart already frozen')
    with r.singleton():
        current = snapshot()
        r.require(not (r.OUT/'STEP02I_RESUME_RESULT.json').exists(), 'Already finally delivered')
        r.require(not (r.OUT/'RUN_FINISHED.json').exists(), 'Original run already finished')
        manifest = r.read(r.OUT/'RESUME_MANIFEST.json')
        r.check_frozen(manifest)
        env = r.read(r.OUT/'ENVIRONMENT_LOCK.json')
        r.require(all(r.sha(Path(p)) == h for p, h in env['reused_frozen_files'].items()), 'Frozen runtime changed')
        events = r.ledger().events()
        accounting = r.ledger().accounting()['stage_b']
        r.require(accounting['reserved'] == 96 and accounting['finished'] == 95
                  and accounting['confirmed_calls'] == 95 and accounting['pending'] == 1,
                  'Unexpected pre-reboot accounting')
        finished = {tuple(e['identity']) for e in events if e['event'] == 'FINISHED'}
        pending = [e for e in events if e['event'] == 'RESERVED' and tuple(e['identity']) not in finished]
        r.require([e['metadata']['solve_ordinal'] for e in pending] == [118], 'Unexpected pending identity')
        r.require(not (r.OUT/'high_precision_outputs/118_reference.json').exists()
                  and not (r.OUT/'workers/118_reference/entry_receipt.json').exists(),
                  'Late pending output/receipt requires read-only reconciliation first')
        rows = r.base.lines(r.OUT/'attempt_results.jsonl')
        r.require(len(rows) == 95 and all(row.get('completed') for row in rows), 'Prior returns differ')
        remaining = select_remaining(manifest, events)
        r.require([item['solve_ordinal'] for item in remaining] == list(range(119, 491)), 'Remaining identity list differs')
        for item in remaining:
            name = f"{item['solve_ordinal']:03d}_{item['path']}"
            r.require(not (r.OUT/'workers'/name).exists()
                      and not (r.OUT/'high_precision_outputs'/(name+'.json')).exists(), 'Fresh identity already has artifacts')
        r.save(EXTRA/'PRE_RESTART_PROCESS_SNAPSHOT.json', current, exclusive=True)
        excluded = {'solve_ledger.jsonl', 'attempt_results.jsonl', 'PROGRESS.json', 'commands.jsonl', 'supervisor.lock'}
        preserved = {p.relative_to(r.OUT).as_posix(): r.sha(p) for p in r.OUT.rglob('*')
                     if p.is_file() and EXTRA not in p.parents and p.relative_to(r.OUT).as_posix() not in excluded}
        prefixes = {name: {'bytes': (r.OUT/name).stat().st_size, 'sha256': r.sha(r.OUT/name)}
                    for name in ('solve_ledger.jsonl', 'attempt_results.jsonl', 'commands.jsonl')}
        value = {'frozen_utc': r.base.utc(), 'run_id': manifest['run_id'],
                 'segment': 'EXPLICIT_USER_AUTHORIZED_POST_REBOOT',
                 'resume_manifest_sha256': r.sha(r.OUT/'RESUME_MANIFEST.json'),
                 'panel_clock_sha256': r.sha(r.OUT/'PANEL_CLOCK.json'),
                 'panel_clock': r.ledger().clock(), 'before_accounting': accounting,
                 'pending_preserved': pending, 'remaining_paths': remaining,
                 'max_additional_reservations': 372, 'new_retries_authorized': 0,
                 'preserved_files': preserved, 'append_only_prefixes': prefixes,
                 'implementation_files': {p.relative_to(r.ROOT).as_posix(): r.sha(p)
                    for p in (SOURCE, TEST, AUTHORIZATION, EXTRA/'tests.txt', EXTRA/'PURE_TEST_RESULT.json', EXTRA/'PRE_RESTART_PROCESS_SNAPSHOT.json')}}
        r.save(FREEZE, value, exclusive=True)
        verify_restart(value, exact_prefix=True)
        print(json.dumps({'frozen': True, 'additional_reservations': 372,
                          'deadline_unix': value['panel_clock']['deadline_unix'], 'optimizer_calls': 0}))


def launch_authorized():
    frozen = r.read(FREEZE)
    with r.singleton():
        verify_restart(frozen, exact_prefix=True)
        snapshot()
        r.require(not (EXTRA/'LAUNCH_INTENT.json').exists() and not (EXTRA/'LAUNCH.json').exists()
                  and not (EXTRA/'RUN_STARTED.json').exists(), 'Restart authorization already consumed')
        command = [str(r.PYTHON), '-B', '-X', 'utf8', '-u', '-m', 'cavr_wbc.experiments.step02i_reboot', 'supervisor']
        r.save(EXTRA/'LAUNCH_INTENT.json', {'authorized_utc': r.base.utc(), 'command': command,
               'run_id': frozen['run_id'], 'restart_manifest_sha256': r.sha(FREEZE)}, exclusive=True)
    # Release the singleton before the child takes it; exclusive intent prevents
    # a second launcher while avoiding a parent/child lock-acquisition race.
    environment = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', TEMP=str(r.base.LOCAL), TMP=str(r.base.LOCAL))
    with (EXTRA/'supervisor.stdout.log').open('xb') as stdout, (EXTRA/'supervisor.stderr.log').open('xb') as stderr:
        process = subprocess.Popen(command, cwd=r.ROOT, env=environment, stdin=subprocess.DEVNULL,
                                   stdout=stdout, stderr=stderr, close_fds=True,
                                   creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_BREAKAWAY_FROM_JOB)
    r.save(EXTRA/'LAUNCH.json', {'launcher_utc': r.base.utc(), 'pid': process.pid,
           'command': command, 'run_id': frozen['run_id'], 'restart_manifest_sha256': r.sha(FREEZE)}, exclusive=True)
    print(json.dumps(r.read(EXTRA/'LAUNCH.json')))


def supervisor():
    frozen = r.read(FREEZE)
    with r.singleton():
        r.require((EXTRA/'LAUNCH_INTENT.json').exists(), 'No exclusive explicit restart launch authorization')
        r.require(not (EXTRA/'RUN_STARTED.json').exists(), 'Explicit reboot restart already started; never restart automatically')
        manifest, events = verify_restart(frozen, exact_prefix=True)
        r.require(select_remaining(manifest, events) == frozen['remaining_paths'], 'Restart subset drift')
        process_state = snapshot()
        r.save(EXTRA/'RUN_STARTED.json', {'run_id': manifest['run_id'], 'pid': os.getpid(), 'parent_pid': os.getppid(),
               'started_utc': r.base.utc(), 'actual_command': [sys.executable, *sys.orig_argv[1:]],
               'process_snapshot': process_state, 'restart_manifest_sha256': r.sha(FREEZE),
               'deadline_unix': frozen['panel_clock']['deadline_unix'], 'restart_allowed': False}, exclusive=True)
        attempts = r.base.lines(r.OUT/'attempt_results.jsonl')
        stop, exit_code = None, 0
        try:
            context = r.inputs.load_all()
            for item in frozen['remaining_paths']:
                if r.remaining_seconds() <= 0:
                    stop = 'RESOURCE_LIMIT'; break
                verify_restart(frozen)
                transport, _, _, _ = r.inputs.load_case_path(item['case_id'], item['path'], context)
                r.require(r.base.digest(transport) == r.base.digest(r.read(r.ROOT/item['input_file'])), 'Scientific input reconstruction mismatch')
                result = r.supervised_attempt(item, transport, manifest)
                output = result.pop('output')
                row = {**item, **result, 'completed': result['kind'] != 'infrastructure_error',
                       'valid_output': False, 'run_id': manifest['run_id'], 'source': 'USER_AUTHORIZED_POST_REBOOT'}
                if output is not None and not output.get('infrastructure_error', False):
                    row['complete_return_utc'] = output.get('finished_utc')
                    row.update(r.path_from_output(item, output, r.ROOT/result['output_file'],
                                                  status=result['status'], kind=result['kind'], context=context))
                    if output.get('float64_w_bits') is not None:
                        name = f"{item['solve_ordinal']:03d}_{item['path']}"
                        r.save(r.OUT/'float64_outputs'/(name+'.json'), {'case_id': item['case_id'], 'path': item['path'],
                               'attempt': item['attempt'], 'float64_bits': output['float64_w_bits'],
                               'w': [v if math.isfinite(v) else str(v) for v in r.base.decode(output['float64_w_bits'])],
                               'rounding_count': 1, 'validation': {k: v for k, v in row.items() if k not in item}}, exclusive=True)
                r.base.append(r.OUT/'attempt_results.jsonl', row)
                attempts.append(row)
                r.progress(context, attempts)
                if result['kind'] == 'infrastructure_error':
                    stop, exit_code = 'IMPLEMENTATION_OR_INFRASTRUCTURE_ERROR', 2
                    break
        except BaseException as exc:
            stop = 'RESOURCE_LIMIT' if 'RESOURCE_LIMIT' in str(exc) else 'IMPLEMENTATION_OR_INFRASTRUCTURE_ERROR'
            exit_code = 0 if stop == 'RESOURCE_LIMIT' else 2
            r.save(EXTRA/'INTERRUPTION.json', {'run_id': manifest['run_id'], 'observed_utc': r.base.utc(),
                   'kind': stop, 'error': repr(exc), 'traceback': traceback.format_exc(), 'exit_code': exit_code}, exclusive=True)
            traceback.print_exc()
        finally:
            check_error = None
            try:
                # Full evidence verification remains mandatory after the deadline.
                verify_restart(frozen, enforce_deadline=False)
            except BaseException as exc:
                check_error, stop, exit_code = repr(exc), 'FROZEN_EVIDENCE_CHANGED', 2
            record = {'run_id': manifest['run_id'], 'finished_utc': r.base.utc(), 'pid': os.getpid(),
                      'exit_code': exit_code, 'stop_reason': stop, 'frozen_check_error': check_error,
                      'new_call_accounting': r.ledger().accounting(), 'panel_clock': r.read(r.OUT/'PANEL_CLOCK.json'),
                      'restart_allowed': False, 'segment': 'EXPLICIT_USER_AUTHORIZED_POST_REBOOT',
                      'original_segment_ended_without_finish_marker': True,
                      'pending_118_preserved': True, 'restart_manifest_sha256': r.sha(FREEZE)}
            r.save(EXTRA/'RUN_FINISHED.json', record, exclusive=True)
            # This marks the authorized run's final segment, not a fabricated original exit.
            r.save(r.OUT/'RUN_FINISHED.json', record, exclusive=True)
        return exit_code


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('phase', choices=['freeze_restart', 'launch_authorized', 'supervisor'])
    args = parser.parse_args()
    EXTRA.mkdir(exist_ok=True)
    r.base.append(EXTRA/'commands.jsonl', {'event': 'START', 'phase': args.phase, 'utc': r.base.utc(), 'argv': sys.argv})
    value = {'freeze_restart': freeze_restart, 'launch_authorized': launch_authorized, 'supervisor': supervisor}[args.phase]()
    r.base.append(EXTRA/'commands.jsonl', {'event': 'END', 'phase': args.phase, 'utc': r.base.utc(), 'exit_code': value or 0})
    return value or 0


if __name__ == '__main__':
    raise SystemExit(main())
