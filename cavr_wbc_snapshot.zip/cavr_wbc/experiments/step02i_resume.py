"""One explicitly authorized resume; no change to scientific assembly or solver.

All historical artifacts are read-only. The sole retry is ordinal 23 attempt 2.
This entry never calls either previous execute/deliver/smoke entry point.
"""
from __future__ import annotations

import argparse
from collections import Counter
from contextlib import contextmanager
from datetime import datetime, timezone
import io
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback
import unittest
import uuid

from cavr_wbc.experiments import step02i as base
from cavr_wbc.evaluation import step02i_inputs as inputs
from cavr_wbc.experiments.step02i_resume_ledger import ResumeLedger

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'artifacts/step02i_resume_20260919'
OLD = ROOT / 'artifacts/step02i_smoke_contract_continuation'
BASE_COMMIT = '8968e8e5c682a40050e850581e366f3261eb4616'
PROTOCOL_SOURCE = Path('E:/CAVR-WBC/experiment_handoff_20260919/NEXT_CODEX_INSTRUCTIONS_STEP02I_RESUME.md')
PYTHON = Path('E:/CAVR-WBC/cavr_step02h_exact_primal_certificate_20260918/.venv-step02h/Scripts/python.exe')
read, save, sha, require = base.read, base.save, base.sha, base.require
LegacyLedger = base.Ledger


def write_jsonl(path, rows):
    with Path(path).open('x', encoding='utf-8', newline='\n') as stream:
        for row in rows:
            stream.write(json.dumps(row, ensure_ascii=False, allow_nan=False, separators=(',', ':'))+'\n')
        stream.flush(); os.fsync(stream.fileno())


def code_files():
    paths = [ROOT/'cavr_wbc/experiments'/name for name in
             ('step02i_resume.py', 'step02i_resume_ledger.py', 'step02i_resume_delivery.py', 'step02i.py')]
    paths += [ROOT/'cavr_wbc/evaluation/step02i_inputs.py']
    paths += sorted((ROOT/'tests').glob('test_step02i_resume*.py'))
    paths += sorted((ROOT/'julia/step02i').glob('*'))
    paths += [OUT/'RESUME_PROTOCOL.md', OUT/'PREPARATION_CLOCK.json', OUT/'config.yaml', OUT/'ENVIRONMENT_LOCK.json']
    return {p.relative_to(ROOT).as_posix(): sha(p) for p in paths if p.is_file()}


def check_frozen(manifest):
    require(code_files() == manifest['files'], 'Resume implementation/config changed after freeze')
    for name, value in manifest['historical_files'].items():
        if name.endswith('step02i_smoke_contract_continuation/workers/023_production/entry_receipt.json') and (OUT/'LATE_ORIGINAL_RETURN.json').exists():
            require(sha(ROOT/name) == read(OUT/'LATE_ORIGINAL_RETURN.json')['receipt_sha256'], 'Late original receipt changed after acceptance')
            continue
        require(sha(ROOT/name) == value, 'Historical input/evidence changed: '+name)
    for name, value in manifest.get('artifacts', {}).items():
        require(sha(OUT/name) == value, 'Resume manifest artifact changed: '+name)


def ledger():
    manifest = read(OUT/'RESUME_MANIFEST.json')
    class BoundLedger(ResumeLedger):
        def finish(self, identity, **metadata):
            item = self.allowed[tuple(identity)]
            name = str(item['solve_ordinal']).zfill(3)+'_'+item['path']
            if (OUT/'workers'/name/'GLOBAL_TIMEOUT.json').exists():
                metadata.update(status='TIMEOUT_RESOURCE_LIMIT', kind='numerical_failure')
            return super().finish(identity, **metadata)
    return BoundLedger(OUT/'solve_ledger.jsonl', manifest['remaining_paths'],
                        manifest['old_unknown_reservation_hash'], OUT/'PANEL_CLOCK.json', manifest['run_id'])


base.OUT = OUT
base.Ledger = ledger
base.check_frozen = check_frozen


def preparation_time():
    clock = read(OUT/'PREPARATION_CLOCK.json')
    require(time.time() < datetime.fromisoformat(clock['deadline_utc']).timestamp(), 'Resume preparation limit reached')


def path_from_output(item, output, output_file, *, status=None, kind='result', context=None):
    transport, problem, cached, info = inputs.load_case_path(item['case_id'], item['path'], context)
    require(base.digest(transport) == base.digest(read(ROOT/item['input_file'])), 'Scientific input reconstruction mismatch')
    require(output['identity'] == transport['identity'] and output['input_sha256'] == item['input_sha256'], 'Returned identity/input mismatch')
    require(output['settings'] == read(OUT/'ENVIRONMENT_LOCK.json')['complete_actual_settings'], 'Expanded solver settings drift')
    row = {**item, 'status': status or output['status'], 'kind': kind,
           'completed': kind != 'infrastructure_error', 'output_file': str(Path(output_file).relative_to(ROOT)).replace('\\', '/'),
           'output_sha256': sha(output_file), 'high_precision_feasible': output['hp_checks']['high_precision_numerically_feasible'],
           'high_precision_checks': output['hp_checks'], 'valid_output': False}
    if output.get('float64_w_bits') is not None:
        require(output['float64_export_roundings'] == 1, 'Float64 export rounding count changed')
        w = base.decode(output['float64_w_bits'])
        row.update(inputs.validate_export(problem, cached, info, w, row['status'], all_output_finite=output['all_outputs_finite']))
        row['valid_output'] = bool(output['all_outputs_finite'] and row.get('raw_candidate_available'))
    return row


def late_old_return(context=None):
    output_path = OLD/'high_precision_outputs/023_production.json'
    if not output_path.exists():
        return None
    item = read(OLD/'case_manifest.json')['paths'][22]
    receipt_path = OLD/'workers/023_production/entry_receipt.json'
    receipt = read(receipt_path)
    old_events = LegacyLedger(OLD/'solve_ledger.jsonl').events()
    reservation = next(r for r in old_events if r['event'] == 'RESERVED' and r['identity'] == ['stage_b', item['case_id'], item['path']])
    require(receipt['reservation_id'] == reservation['hash'] and receipt['solve_calls_confirmed'] == 1, 'Late original receipt invalid')
    row = path_from_output(item, read(output_path), output_path, context=context)
    # A legitimate returned failure cancels retry too; never condition reuse on PASS.
    row.update(attempt=1, source='LATE_ORIGINAL_RETURN', late_historical_return=True, receipt_sha256=sha(receipt_path),
               complete_return_utc=read(output_path).get('finished_utc'), valid_return_utc=receipt.get('solve_finished_utc'))
    return row


def prepare():
    preparation_time()
    require(base.git('rev-parse', 'HEAD') == BASE_COMMIT, 'Wrong resume baseline')
    require(not (OUT/'RESUME_MANIFEST.json').exists(), 'Resume already frozen; never overwrite')
    require(read(OLD/'STEP02I_CONTINUATION_RESULT.json')['status'] == 'INCOMPLETE', 'Old result changed')
    events = LegacyLedger(OLD/'solve_ledger.jsonl').events()
    require(len(events) == 47, 'Old 47-event ledger changed')
    old_rows = base.lines(OLD/'path_results.jsonl')
    completed = [r for r in old_rows if r.get('completed')]
    require(len(completed) == 22 and sum(not r['raw_candidate_fixed_band_pass'] for r in completed) == 10, 'Old returned scope changed')
    original = read(OLD/'case_manifest.json')
    require(len(original['paths']) == 490, 'Scientific identities changed')
    unknown = next(r for r in events if r['event'] == 'RESERVED' and r['identity'] == ['stage_b', original['paths'][22]['case_id'], 'production'])
    require(not any(r['event'] == 'FINISHED' and r['identity'] == unknown['identity'] for r in events), 'Old UNKNOWN already finished')
    # Preserve configuration bytes; no installation, inspection solver or smoke.
    (OUT/'config.yaml').write_bytes((OLD/'config.yaml').read_bytes())
    env = read(OLD/'ENVIRONMENT_LOCK.json')
    env.update(stage='STEP02I_INTERRUPTION_RESUME_V1', worker_sha256=sha(ROOT/'julia/step02i/worker.jl'),
               worker_change='Only OUT artifact-directory constant; solver and assembly byte-identical otherwise',
               resume_source_lock_sha256=sha(OLD/'ENVIRONMENT_LOCK.json'))
    save(OUT/'ENVIRONMENT_LOCK.json', env, exclusive=True)
    require(all(sha(Path(p)) == value for p, value in env['reused_frozen_files'].items()), 'Frozen runtime/dependency changed')
    old_worker = subprocess.check_output(['git', 'show', BASE_COMMIT+':julia/step02i/worker.jl'])
    require((ROOT/'julia/step02i/worker.jl').read_bytes() == old_worker.replace(b'step02i_smoke_contract_continuation', b'step02i_resume_20260919'), 'Worker numerical source changed')
    recovered = late_old_return()
    if recovered:
        save(OUT/'LATE_ORIGINAL_RETURN.json', recovered, exclusive=True)
        write_jsonl(OUT/'late_old_attempts.jsonl', [recovered])
    remaining = [{**r, 'attempt': 2 if r['solve_ordinal'] == 23 else 1,
                  'old_reservation_hash': unknown['hash'] if r['solve_ordinal'] == 23 else None}
                 for r in original['paths'][22:] if not (recovered and r['solve_ordinal'] == 23)]
    require(len(remaining) == (467 if recovered else 468), 'Wrong remaining identity count')
    for item in original['paths']:
        require(sha(ROOT/item['input_file']) == item['input_sha256'], 'Frozen input hash differs')
    historical = {p.relative_to(ROOT).as_posix(): sha(p) for p in OLD.rglob('*') if p.is_file()}
    historical.update({r['input_file']: r['input_sha256'] for r in original['paths']})
    historical.update(read(OLD/'SOURCE_MANIFEST.json')['files'])
    for name, value in read(OLD/'ORIGIN_MANIFEST.json')['original_files'].items():
        require(sha(ROOT/name) == value, 'Original I/E2 history changed')
        historical[name] = value
    write_jsonl(OUT/'historical_attempts.jsonl', [{**r, 'attempt': 1, 'source': 'HISTORICAL_READ_ONLY'} for r in old_rows[:23]])
    save(OUT/'remaining_manifest.json', {'paths': remaining, 'scientific_paths': original['paths']}, exclusive=True)
    tests = unittest.TestSuite()
    for pattern in ('test_step02i_resume_ledger.py', 'test_step02i_resume_delivery.py', 'test_step02i_resume.py'):
        tests.addTests(unittest.defaultTestLoader.discover(str(ROOT/'tests'), pattern=pattern))
    stream = io.StringIO(); outcome = unittest.TextTestRunner(stream=stream, verbosity=2).run(tests)
    (OUT/'tests.txt').write_text(stream.getvalue(), encoding='utf-8', newline='\n')
    save(OUT/'pure_tests.json', {'passed': outcome.wasSuccessful(), 'tests_run': outcome.testsRun,
                              'errors': len(outcome.errors), 'failures': len(outcome.failures), 'new_optimizer_calls': 0}, exclusive=True)
    print(stream.getvalue(), flush=True)
    require(outcome.wasSuccessful(), 'No-solve resume tests failed')
    preparation_time()
    manifest = {'run_id': str(uuid.uuid4()), 'frozen_utc': base.utc(), 'base_commit': BASE_COMMIT,
                'old_unknown_reservation_hash': unknown['hash'], 'old_ledger_sha256': sha(OLD/'solve_ledger.jsonl'),
                'historical_files': historical, 'files': code_files(), 'remaining_paths': remaining,
                'scientific_paths': original['paths'], 'max_new_attempts': len(remaining),
                'old_unknown_preserved': True, 'late_original_return_recovered': recovered is not None,
                'time_limit_seconds': 28800, 'per_worker_seconds': 120, 'per_solver_seconds': 60,
                'old_panel_clock': read(OLD/'PANEL_CLOCK.json'), 'new_stage_b_upper_limit': 491,
                'cumulative_i_upper_limit': 493,
                'artifacts': {p: sha(OUT/p) for p in ('remaining_manifest.json', 'historical_attempts.jsonl', 'pure_tests.json')}}
    if recovered:
        for name in ('LATE_ORIGINAL_RETURN.json', 'late_old_attempts.jsonl'):
            manifest['artifacts'][name] = sha(OUT/name)
    save(OUT/'RESUME_MANIFEST.json', manifest, exclusive=True)
    print('RESUME_FROZEN run_id='+manifest['run_id']+' new_attempts='+str(len(remaining)), flush=True)


@contextmanager
def singleton():
    import msvcrt
    lock = (OUT/'supervisor.lock').open('a+b')
    try:
        if lock.seek(0, os.SEEK_END) == 0:
            lock.write(b'1'); lock.flush()
        lock.seek(0)
        msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        yield
    finally:
        lock.close()


def remaining_seconds():
    return max(0.0, read(OUT/'PANEL_CLOCK.json')['deadline_unix']-time.time()) if (OUT/'PANEL_CLOCK.json').exists() else 28800.0


def supervised_attempt(item, transport, manifest):
    """Reuse the original supervisor, adding only a durable worker exit receipt."""
    original_popen = subprocess.Popen
    name = str(item['solve_ordinal']).zfill(3)+'_'+item['path']
    exit_path = OUT/'workers'/name/'exit.json'

    class ExitRecordedProcess(original_popen):
        def __init__(self, *args, **kwargs):
            require(remaining_seconds() > 0, 'RESOURCE_LIMIT before actual worker launch')
            super().__init__(*args, **kwargs)

        def _record(self, code):
            if code is not None and not exit_path.exists():
                save(exit_path, {'pid': self.pid, 'exit_code': code, 'observed_utc': base.utc(),
                                'attempt': item['attempt'], 'run_id': manifest['run_id']}, exclusive=True)
            return code

        def poll(self):
            return self._record(super().poll())

        def wait(self, timeout=None):
            left = remaining_seconds()
            if left <= 0 and super().poll() is None:
                print('GLOBAL DEADLINE: terminate current authorized worker pid='+str(self.pid), flush=True)
                save(OUT/'workers'/name/'GLOBAL_TIMEOUT.json', {'utc': base.utc(), 'pid': self.pid,
                     'reason': 'RESOURCE_LIMIT', 'deadline_unix': read(OUT/'PANEL_CLOCK.json')['deadline_unix']}, exclusive=not (OUT/'workers'/name/'GLOBAL_TIMEOUT.json').exists())
                super().kill()
                return self._record(super().wait(timeout=10))
            timeout = min(timeout, left) if timeout is not None else left
            return self._record(super().wait(timeout=max(0.001, timeout)))

    subprocess.Popen = ExitRecordedProcess
    try:
        result = base.supervise('stage_b', transport, manifest, remaining_seconds())
        if (OUT/'workers'/name/'GLOBAL_TIMEOUT.json').exists():
            result.update(status='TIMEOUT_RESOURCE_LIMIT', kind='numerical_failure')
        return result
    finally:
        subprocess.Popen = original_popen


def progress(context, attempts):
    selected = {(r['case_id'], r['path']): r for r in base.lines(OLD/'path_results.jsonl') if r.get('completed')}
    if (OUT/'LATE_ORIGINAL_RETURN.json').exists():
        r = read(OUT/'LATE_ORIGINAL_RETURN.json'); selected[r['case_id'], r['path']] = r
    selected.update({(r['case_id'], r['path']): r for r in attempts})
    paired = []
    for case in context['cases']:
        if all((case['case_id'], path) in selected for path in base.PATHS):
            paired.append(inputs.combine_case(case['case_id'], selected[case['case_id'], 'production'], selected[case['case_id'], 'reference'], context))
    record = {'utc': base.utc(), 'attempt_rows': len(attempts), 'completed_cases': sum(r['completed'] for r in paired),
              'strict_pass': sum(r['final_case_pass'] for r in paired),
              'failure_categories': dict(Counter(f for r in paired for f in r['failure_categories'])), 'accounting': ledger().accounting()}
    # Atomic replace avoids monitoring partial JSON while no scientific record is overwritten.
    temporary = OUT/'PROGRESS.tmp.json'; save(temporary, record); os.replace(temporary, OUT/'PROGRESS.json')
    print('PROGRESS '+json.dumps(record), flush=True)


def run():
    manifest = read(OUT/'RESUME_MANIFEST.json')
    with singleton():
        require(not (OUT/'RUN_STARTED.json').exists(), 'Resume attempt already started; automatic restart forbidden')
        check_frozen(manifest)
        save(OUT/'RUN_STARTED.json', {'run_id': manifest['run_id'], 'pid': os.getpid(), 'parent_pid': os.getppid(),
             'started_utc': base.utc(), 'actual_command': [sys.executable, *sys.orig_argv[1:]],
             'deadline_source': 'PANEL_CLOCK.json first new reservation; never reset', 'restart_allowed': False}, exclusive=True)
        stop = None; exit_code = 0; attempts = []
        try:
            context = inputs.load_all()
            for item in manifest['remaining_paths']:
                if item['solve_ordinal'] == 23:
                    if not (OUT/'LATE_ORIGINAL_RETURN.json').exists() and (OLD/'high_precision_outputs/023_production.json').exists():
                        recovered = late_old_return(context)
                        save(OUT/'LATE_ORIGINAL_RETURN.json', recovered, exclusive=True)
                        write_jsonl(OUT/'late_old_attempts.jsonl', [recovered])
                    if (OUT/'LATE_ORIGINAL_RETURN.json').exists():
                        save(OUT/'RETRY_CANCELLED.json', {'utc': base.utc(), 'reason': 'FIRST_COMPLETE_OLD_RETURN',
                             'effective_new_attempt_limit': 467, 'old_unknown_history_preserved': True}, exclusive=True)
                        continue
                if remaining_seconds() <= 0:
                    stop = 'RESOURCE_LIMIT'; break
                check_frozen(manifest)
                transport, _, _, _ = inputs.load_case_path(item['case_id'], item['path'], context)
                require(base.digest(transport) == base.digest(read(ROOT/item['input_file'])), 'Rebuilt scientific input mismatch')
                result = supervised_attempt(item, transport, manifest)
                output = result.pop('output')
                row = {**item, **result, 'completed': result['kind'] != 'infrastructure_error',
                       'valid_output': False, 'run_id': manifest['run_id'], 'source': 'NEW_RESUME_ATTEMPT'}
                if output is not None and not output.get('infrastructure_error', False):
                    row['complete_return_utc'] = output.get('finished_utc')
                    row.update(path_from_output(item, output, ROOT/result['output_file'], status=result['status'], kind=result['kind'], context=context))
                    if output.get('float64_w_bits') is not None:
                        name = str(item['solve_ordinal']).zfill(3)+'_'+item['path']
                        save(OUT/'float64_outputs'/(name+'.json'), {'case_id': item['case_id'], 'path': item['path'],
                             'attempt': item['attempt'], 'float64_bits': output['float64_w_bits'],
                             'w': [v if math.isfinite(v) else str(v) for v in base.decode(output['float64_w_bits'])],
                             'rounding_count': 1, 'validation': {k: v for k, v in row.items() if k not in item}}, exclusive=True)
                base.append(OUT/'attempt_results.jsonl', row); attempts.append(row)
                progress(context, attempts)
                if result['kind'] == 'infrastructure_error':
                    stop = 'IMPLEMENTATION_OR_INFRASTRUCTURE_ERROR'; exit_code = 2; break
        except BaseException as exc:
            stop = 'RESOURCE_LIMIT' if 'RESOURCE_LIMIT' in str(exc) else 'IMPLEMENTATION_OR_INFRASTRUCTURE_ERROR'
            exit_code = 0 if stop == 'RESOURCE_LIMIT' else 2
            save(OUT/'INTERRUPTION.json', {'run_id': manifest['run_id'], 'observed_utc': base.utc(), 'kind': stop,
                 'error': repr(exc), 'traceback': traceback.format_exc(), 'root_cause': 'See captured exception; no automatic restart',
                 'exit_code': exit_code}, exclusive=True)
            traceback.print_exc()
        finally:
            check_error = None
            try: check_frozen(manifest)
            except BaseException as exc: check_error = repr(exc); stop = 'FROZEN_EVIDENCE_CHANGED'; exit_code = 2
            save(OUT/'RUN_FINISHED.json', {'run_id': manifest['run_id'], 'finished_utc': base.utc(), 'pid': os.getpid(),
                 'exit_code': exit_code, 'stop_reason': stop, 'frozen_check_error': check_error,
                 'new_call_accounting': ledger().accounting(), 'panel_clock': read(OUT/'PANEL_CLOCK.json') if (OUT/'PANEL_CLOCK.json').exists() else None,
                 'restart_allowed': False}, exclusive=True)
        return exit_code


def launch():
    preparation_time(); manifest = read(OUT/'RESUME_MANIFEST.json')
    # The sole authorized late-return exception: never retry a returned failure.
    if not (OUT/'LATE_ORIGINAL_RETURN.json').exists() and (OLD/'high_precision_outputs/023_production.json').exists():
        recovered = late_old_return()
        save(OUT/'LATE_ORIGINAL_RETURN.json', recovered, exclusive=True)
        write_jsonl(OUT/'late_old_attempts.jsonl', [recovered])
    check_frozen(manifest)
    require(not (OUT/'LAUNCH.json').exists() and not (OUT/'RUN_STARTED.json').exists(), 'Single authorized launch already consumed')
    command = [str(PYTHON), '-B', '-X', 'utf8', '-u', '-m', 'cavr_wbc.experiments.step02i_resume', 'run']
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', TEMP=str(base.LOCAL), TMP=str(base.LOCAL))
    # Explicitly detach from the console and break away from a tool-session job.
    # If Windows refuses breakaway, fail before any experiment; do not silently degrade.
    with (OUT/'supervisor.stdout.log').open('xb') as stdout, (OUT/'supervisor.stderr.log').open('xb') as stderr:
        process = subprocess.Popen(command, cwd=ROOT, env=env, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                                   close_fds=True, creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_BREAKAWAY_FROM_JOB)
    save(OUT/'LAUNCH.json', {'run_id': manifest['run_id'], 'launcher_utc': base.utc(), 'pid': process.pid,
         'command': command, 'creationflags': ['DETACHED_PROCESS', 'CREATE_BREAKAWAY_FROM_JOB'],
         'stdout': str(OUT/'supervisor.stdout.log'), 'stderr': str(OUT/'supervisor.stderr.log')}, exclusive=True)
    print(json.dumps(read(OUT/'LAUNCH.json')), flush=True)


def summarize():
    from cavr_wbc.experiments.step02i_resume_delivery import deliver
    require(not (OUT/'STEP02I_RESUME_RESULT.json').exists(), 'Final summary already delivered; do not overwrite')
    with singleton():
        require((OUT/'RUN_STARTED.json').exists(), 'No resume run started')
        # Releasing the supervisor lock does not imply an orphan child has ended.
        import ctypes
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.OpenProcess.restype = ctypes.c_void_p
        kernel.OpenProcess.argtypes = [ctypes.c_uint32, ctypes.c_int, ctypes.c_uint32]
        kernel.GetExitCodeProcess.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint32)]
        kernel.CloseHandle.argtypes = [ctypes.c_void_p]
        for path in (OUT/'workers').glob('*/process.json'):
            pid = read(path)['pid']; handle = kernel.OpenProcess(0x1000, 0, pid)
            if handle:
                try:
                    exit_code = ctypes.c_uint32()
                    require(kernel.GetExitCodeProcess(handle, ctypes.byref(exit_code)), 'Cannot confirm worker exit')
                    require(exit_code.value != 259, 'Recorded worker PID still active; confirm identity and wait, never relaunch')
                finally:
                    kernel.CloseHandle(handle)
        manifest = read(OUT/'RESUME_MANIFEST.json'); check_frozen(manifest)
        if not (OUT/'RUN_FINISHED.json').exists():
            if not (OUT/'INTERRUPTION.json').exists():
                save(OUT/'INTERRUPTION.json', {'run_id': manifest['run_id'], 'observed_utc': base.utc(),
                     'kind': 'SUPERVISOR_DISAPPEARED', 'root_cause': 'UNKNOWN', 'exit_code': None,
                     'note': 'Single-instance OS lock released without a RUN_FINISHED record; no restart or new solve.'}, exclusive=True)
        stop_info = read(OUT/'RUN_FINISHED.json') if (OUT/'RUN_FINISHED.json').exists() else read(OUT/'INTERRUPTION.json')
        # A supervisor may vanish after reservation but before appending its path.
        observed = {(r['case_id'], r['path'], r['attempt']) for r in base.lines(OUT/'attempt_results.jsonl')}
        events = ledger().events()
        finished = {tuple(e['identity']): e for e in events if e['event'] == 'FINISHED'}
        for event in events:
            key = tuple(event['identity'])
            if event['event'] == 'RESERVED' and key not in observed:
                item = next(r for r in manifest['remaining_paths'] if (r['case_id'], r['path'], r['attempt']) == key)
                name = str(item['solve_ordinal']).zfill(3)+'_'+item['path']
                output_file = OUT/'high_precision_outputs'/(name+'.json')
                receipt_file = OUT/'workers'/name/'entry_receipt.json'
                counts = finished.get(key, {}).get('metadata', {'confirmed_solve_calls': 0, 'unknown_call_upper_bound': 1})
                row = {**item, 'status': 'INTERRUPTED_UNKNOWN_CALL', 'kind': 'infrastructure_error',
                       'completed': False, 'valid_output': False, 'confirmed_solve_calls': counts['confirmed_solve_calls'],
                       'unknown_call_upper_bound': counts['unknown_call_upper_bound'], 'run_id': manifest['run_id'],
                       'source': 'POST_RUN_RECONCILIATION', 'reason': 'Reserved attempt ended before path publication. No retry.'}
                if output_file.exists() and receipt_file.exists():
                    output, receipt = read(output_file), read(receipt_file)
                    require(receipt['reservation_id'] == event['hash'], 'Recovery receipt link mismatch')
                    if not output.get('infrastructure_error', False):
                        row.update(path_from_output(item, output, output_file))
                        row['complete_return_utc'] = output.get('finished_utc')
                        if key not in finished and receipt.get('solve_calls_confirmed') == 1:
                            ledger().finish(key, status=row['status'], kind='result', confirmed_solve_calls=1,
                                 unknown_call_upper_bound=0, output_sha256=sha(output_file), receipt_sha256=sha(receipt_file),
                                 recorded_by='POST_RUN_SAVED_RETURN_RECOVERY', retry_allowed=False)
                            row.update(confirmed_solve_calls=1, unknown_call_upper_bound=0)
                base.append(OUT/'attempt_results.jsonl', row)
        deliver(OUT, OLD, manifest, ledger().accounting(), stop_info)


def main():
    parser = argparse.ArgumentParser(); parser.add_argument('phase', choices=['prepare', 'launch', 'run', 'summarize']); args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    base.append(OUT/'commands.jsonl', {'event': 'START', 'phase': args.phase, 'utc': base.utc(), 'argv': sys.argv})
    try:
        value = {'prepare': prepare, 'launch': launch, 'run': run, 'summarize': summarize}[args.phase]()
    except BaseException as exc:
        base.append(OUT/'commands.jsonl', {'event': 'ERROR', 'phase': args.phase, 'utc': base.utc(), 'error': repr(exc)})
        raise
    base.append(OUT/'commands.jsonl', {'event': 'END', 'phase': args.phase, 'utc': base.utc(), 'exit_code': value or 0})
    return value or 0


if __name__ == '__main__':
    raise SystemExit(main())
