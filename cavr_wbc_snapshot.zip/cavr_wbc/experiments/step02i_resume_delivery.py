"""No-solve aggregation for the single authorized STEP02I interruption resume.

This module never imports a solver, invokes a worker, edits the historical output
directory, or revalidates by optimizing. Scientific comparisons delegate to the
unchanged STEP02I saved-output combiner.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from copy import deepcopy
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path


PATHS = ("production", "reference")
RETRY_KEY = ("home_nominal__FR_hip_rho_0.50__near_lateral_roll", "production")
ROOT = Path(__file__).resolve().parents[2]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def lines(path):
    path = Path(path)
    return [json.loads(s) for s in path.read_text(encoding="utf-8").splitlines() if s.strip()] if path.exists() else []


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def row_sha(row):
    return hashlib.sha256(json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")).hexdigest()


def identity(row):
    return row["case_id"], row["path"]


def complete_return(row):
    """A provenance-checked returned record, not a scientific success criterion."""
    return bool(row.get("kind") == "result" and row.get("completed") and row.get("output_file"))


def valid_output(row):
    """Finite available numerical output, independently of acceptance or feasibility."""
    if not (row.get("kind") == "result" and row.get("raw_candidate_available")
            and row.get("all_output_finite") and row.get("output_file")):
        return False
    vector, task = row.get("w_float64"), row.get("task_output")
    if not isinstance(vector, list) or len(vector) != 42 or not isinstance(task, list) or len(task) != 8:
        return False
    values = vector + task + [row.get("task_objective"), row.get("torque_regularizer")]
    return all(isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) for v in values)


def merge_paths(manifest, historical_attempts, new_attempts, stop_info):
    """Pure deterministic merge; no replacement of any returned historical point.

    Optional late historical return records have ``late_historical_return=True``
    and attempt 1; the UNKNOWN observation remains in attempt_history. If both
    attempts returned, caller must supply ``complete_return_utc`` for both, so
    earliest complete return is selected without consulting finite/pass/fail.
    """
    entries = manifest.get("scientific_paths", manifest.get("paths"))
    require(isinstance(entries, list), "Missing frozen scientific path manifest")
    expected = {identity(row): row for row in entries}
    require(len(expected) == len(entries), "Duplicate scientific manifest identity")
    grouped = defaultdict(list)
    historical_keys = set()
    attempt_ids = set()
    for source, rows in (("historical", historical_attempts), ("resume", new_attempts)):
        for original in rows:
            row = deepcopy(original)
            key = identity(row)
            require(key in expected, "Attempt outside frozen scientific panel")
            attempt = int(row.get("attempt", 1))
            require(attempt in (1, 2), "Unauthorized attempt ordinal")
            if row.get("input_sha256") is not None:
                require(row["input_sha256"] == expected[key]["input_sha256"], "Attempt input hash drift")
            late = bool(row.get("late_historical_return"))
            if source == "historical":
                require(attempt == 1, "Historical attempt must remain attempt 1")
                historical_keys.add(key)
            elif late:
                require(key == RETRY_KEY and attempt == 1 and complete_return(row), "Invalid late original return")
            else:
                require((key == RETRY_KEY and attempt == 2) or (key not in historical_keys and attempt == 1),
                        "Returned historical path may not be retried")
                if attempt == 2:
                    require(any(r.get("status") == "INTERRUPTED_UNKNOWN_CALL" for r in grouped[key]),
                            "Retry requires the original preserved UNKNOWN attempt")
            unique = (*key, attempt)
            if unique in attempt_ids:
                require(late and all(r["status"] == "INTERRUPTED_UNKNOWN_CALL" for r in grouped[key]),
                        "Duplicate attempt record")
            else:
                attempt_ids.add(unique)
            row.update(attempt=attempt, attempt_source=source, attempted=True,
                       valid_output_available=valid_output(row))
            grouped[key].append(row)
    result = []
    for entry in entries:
        key = identity(entry)
        candidates = grouped[key]
        returned = [row for row in candidates if complete_return(row)]
        if len(returned) > 1:
            require(key == RETRY_KEY, "Multiple numerical returns for nonretry identity")
            require(all(row.get("complete_return_utc") for row in returned),
                    "First complete return requires recorded timestamps, not quality selection")
            selected = min(returned, key=lambda row: datetime.fromisoformat(row["complete_return_utc"].replace("Z", "+00:00")))
        elif returned:
            selected = returned[0]
        elif candidates:
            # A timeout/unknown remains an attempted outcome, never a valid output.
            selected = candidates[-1]
        else:
            reason = stop_info.get("stop_reason", stop_info.get("reason", "NOT_DISPATCHED"))
            selected = {**entry, "attempt": None, "attempted": False, "kind": "not_run",
                        "status": "NOT RUN_RESOURCE_LIMIT" if "RESOURCE_LIMIT" in str(reason) else "NOT RUN",
                        "reason": reason, "completed": False, "high_precision_feasible": None,
                        "float64_export_accepted": None, "valid_output_available": False}
        row = deepcopy(selected)
        row["scientific_identity"] = list(key)
        row["selected_attempt"] = selected.get("attempt")
        row["selection_rule"] = "FIRST_COMPLETE_PROVENANCE_CHECKED_RETURN_NOT_BEST_GATE_RESULT"
        row["attempt_history"] = [{k: r.get(k) for k in ("attempt", "attempt_source", "status", "kind", "output_file",
                                                        "confirmed_solve_calls", "unknown_call_upper_bound", "complete_return_utc")}
                                  for r in candidates]
        row["old_unknown_attempt_preserved"] = any(r["status"] == "INTERRUPTED_UNKNOWN_CALL" for r in candidates)
        result.append(row)
    return result


def merge_cases(paths, context):
    from cavr_wbc.evaluation.step02i_inputs import combine_case
    index = {identity(row): row for row in paths}
    require(len(index) == len(paths), "Duplicate merged scientific identity")
    cases = []
    for case in context["cases"]:
        pair = [index[(case["case_id"], path)] for path in PATHS]
        row = combine_case(case["case_id"], *pair, context)
        row["attempted_pair_coverage"] = all(r.get("attempted", False) for r in pair)
        row["valid_output_pair_coverage"] = all(valid_output(r) for r in pair)
        row["attempt_outcome_pair_complete"] = all(r.get("completed", False) for r in pair)
        row["final_case_pass"] = bool(row["final_case_pass"] and row["valid_output_pair_coverage"])
        row["scientific_path_sources"] = {path: {k: r.get(k) for k in ("selected_attempt", "attempt_source", "output_file",
            "source_path_results_file", "source_path_results_sha256", "source_row_sha256", "output_sha256")}
            for path, r in zip(PATHS, pair)}
        cases.append(row)
    return cases


def summarize_coverage(paths, cases):
    return {"scientific_path_count": len(paths), "case_count": len(cases),
            "attempted_paths": sum(bool(r.get("attempted")) for r in paths),
            "attempted_pair_coverage": sum(r["attempted_pair_coverage"] for r in cases),
            "valid_output_paths": sum(valid_output(r) for r in paths),
            "valid_output_pair_coverage": sum(r["valid_output_pair_coverage"] for r in cases),
            "attempt_outcome_pairs_complete": sum(r["attempt_outcome_pair_complete"] for r in cases),
            "strict_pass": sum(r["final_case_pass"] for r in cases)}


def historical_attempts(old_out):
    """Reference exact prior rows/output bytes, selecting only truly reserved identities."""
    old_out = Path(old_out)
    source = old_out / "path_results.jsonl"
    index = {identity(r): r for r in lines(source)}
    ledger = lines(old_out / "solve_ledger.jsonl")
    reservations = [r for r in ledger if r["event"] == "RESERVED" and r["identity"][0] == "stage_b"]
    result = []
    for reservation in reservations:
        key = tuple(reservation["identity"][1:])
        original = index[key]
        row = deepcopy(original)
        row.update(attempt=1, source_path_results_file=str(source), source_path_results_sha256=sha(source),
                   source_row_sha256=row_sha(original), old_reservation_hash=reservation["hash"],
                   old_reservation_input_sha256=reservation["metadata"]["input_sha256"])
        if row.get("output_file"):
            output = Path(row["output_file"])
            if not output.is_absolute():
                output = ROOT / output
            row["output_sha256"] = sha(output)
        result.append(row)
    require(len(result) == 23 and sum(valid_output(r) for r in result) == 22,
            "Original partial evidence differs from 22 finite returns plus 023 UNKNOWN")
    require([identity(r) for r in result if r["status"] == "INTERRUPTED_UNKNOWN_CALL"] == [RETRY_KEY],
            "Original unknown identity changed")
    return result


def _save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8", newline="\n")


def _jsonl(path, rows):
    Path(path).write_text("".join(json.dumps(r, ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n" for r in rows), encoding="utf-8", newline="\n")


def _table(path, rows):
    fields = list(dict.fromkeys(k for row in rows for k in row))
    with Path(path).open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v, ensure_ascii=False, separators=(",", ":")) if isinstance(v, (dict, list)) else v for k, v in row.items()})


def deliver(out, old_out, manifest, accounting, stop_info, *, context=None):
    """Write only the new resume directory. Caller ensures all workers have ended."""
    out, old_out = Path(out).resolve(), Path(old_out).resolve()
    require(out != old_out and not out.is_relative_to(old_out), "Historical directory is read-only")
    require(out.is_dir(), "Resume directory has not been prepared")
    old_result = read(old_out / "STEP02I_CONTINUATION_RESULT.json")
    require(old_result["status"] == "INCOMPLETE" and old_result["strict_pass"] == 6,
            "Historical partial result changed")
    if context is None:
        from cavr_wbc.evaluation.step02i_inputs import load_all
        context = load_all()
    old_attempts = historical_attempts(old_out)
    new_attempts = lines(out / "attempt_results.jsonl")
    late_returns = lines(out / "late_old_attempts.jsonl")
    paths = merge_paths(manifest, old_attempts, late_returns + new_attempts, stop_info)
    cases = merge_cases(paths, context)
    require(len(paths) == 490 and len(cases) == 245, "Fixed scientific panel cardinality changed")
    coverage = summarize_coverage(paths, cases)
    old_cases = lines(old_out / "case_results.jsonl")
    old_failed = [r["case_id"] for r in old_cases if r.get("completed") and not r.get("final_case_pass")]
    require(len(old_failed) == 5, "Historical five failed cases not intact")
    case_index = {r["case_id"]: r for r in cases}
    require(all(not case_index[c]["final_case_pass"] for c in old_failed), "Historical failed case overwritten")
    require(coverage["strict_pass"] <= 240, "Five retained failures forbid PASS")
    account = accounting.get("stage_b", accounting)
    lower = int(account["calls_lower_bound"])
    upper = int(account["calls_upper_bound"])
    reserved = int(account["reserved"])
    new_limit = len(manifest["remaining_paths"]) if "remaining_paths" in manifest else 468
    require(new_limit in (467, 468), "Resume remaining budget must be 467 or 468")
    require(0 <= lower <= upper <= reserved <= new_limit, "Resume accounting exceeds authorized interval/budget")
    status = "FAIL / REVISE" if coverage["attempt_outcome_pairs_complete"] == 245 else "INCOMPLETE"
    categories = Counter(f for r in cases for f in r["failure_categories"])
    subset = lambda rows: {"count": len(rows), "attempted_pair_coverage": sum(r["attempted_pair_coverage"] for r in rows),
        "valid_output_pair_coverage": sum(r["valid_output_pair_coverage"] for r in rows), "strict_pass": sum(r["final_case_pass"] for r in rows)}
    result = {"stage": "STEP02I_INTERRUPTION_RESUME_V1", "status": status,
        "verification_level": "ANALYZED", "utc": datetime.now(timezone.utc).isoformat(), **coverage,
        "cases_completed": coverage["valid_output_pair_coverage"], "old_continuation_result": "INCOMPLETE",
        "original_step02i_result": "PREPARATION_FAILED", "source_commit": "8968e8e5c682a40050e850581e366f3261eb4616",
        "post_hoc_amendments": ["POST_HOC_SMOKE_OBJECTIVE_CHECK", "8_HOUR_RESOURCE_RESUME", "ONE_023_UNKNOWN_RETRY"],
        "resume_time_limit_hours": 8, "max_new_stage_b_attempts": new_limit,
        "protocol_absolute_max_new_stage_b_attempts": 468, "new_stage_b_accounting": account,
        "historical_stage_b_call_interval": [22, 23], "historical_smoke_calls": 2,
        "stage_b_cumulative_call_interval": [22 + lower, 23 + upper],
        "i_cumulative_call_interval": [24 + lower, 25 + upper],
        "stage_b_cumulative_call_upper_limit": 491, "i_cumulative_call_upper_limit": 493,
        "old_5_failed_cases_preserved": True, "old_failed_case_ids": old_failed,
        "old_unknown_attempt_preserved": True, "old_unknown_call_count_erased": False,
        "old_interruption_root_cause_at_delivery": "UNKNOWN",
        "user_reported_interruption_context": "manual Codex exit",
        "user_context_source": str(out / "USER_INTERRUPTION_CONTEXT.md"),
        "internal_process_termination_mechanism": "NOT_ESTABLISHED",
        "historical_results_unchanged": True,
        "failure_categories": dict(categories), "new_numerical_attempt_records": len(new_attempts),
        "late_original_return_records": len(late_returns), "stop_info": stop_info,
        "regression36": subset([r for r in cases if r["regression_member"]]),
        "D_old_failed24": subset([r for r in cases if r["old_step02d_failure_member"]]),
        "original_four": subset([r for r in cases if r.get("original_four_regression_id")]),
        "stage_a_b1_soft_new_calls": 0, "new_smoke_calls": 0, "e2_analytic_new_calls": 0,
        "exact_certificate_branch": "CLOSED", "e2_analytic_result_unchanged": "PASS",
        "e1_authorized": False, "e2_quadruped_authorized": False, "further_automatic_solver_search": False,
        "old_path_results_sha256": sha(old_out / "path_results.jsonl"),
        "old_ledger_sha256": sha(old_out / "solve_ledger.jsonl"),
        "old_result_sha256": sha(old_out / "STEP02I_CONTINUATION_RESULT.json"),
        "worktree": str(ROOT), "output_directory": str(out)}
    _jsonl(out / "attempt_history.jsonl", old_attempts + late_returns + new_attempts)
    _jsonl(out / "path_results.jsonl", paths)
    _jsonl(out / "case_results.jsonl", cases)
    _table(out / "case_results.csv", cases)
    _table(out / "failure_breakdown.csv", [{"category": k, "case_count": v, "may_overlap": True} for k, v in sorted(categories.items())])
    _save(out / "STEP02I_RESUME_RESULT.json", result)
    flags = """OLD_CONTINUATION_RESULT = INCOMPLETE
RESUME_TIME_LIMIT_HOURS = 8
MAX_NEW_STAGE_B_ATTEMPTS = 468
RETRY_ALLOWED_IDENTITY = ordinal_023_production_attempt2_only
STAGE_B_CUMULATIVE_CALL_UPPER_LIMIT = 491
I_CUMULATIVE_CALL_UPPER_LIMIT = 493
OLD_5_FAILED_CASES_PRESERVED = TRUE
OLD_UNKNOWN_ATTEMPT_PRESERVED = TRUE
EXACT_CERTIFICATE_BRANCH = CLOSED
E2_ANALYTIC_RESULT_UNCHANGED = PASS
E2_QUADRUPED_AUTHORIZED = FALSE
FURTHER_AUTOMATIC_SOLVER_SEARCH = FALSE
E1_AUTHORIZED = FALSE"""
    report = f"""## Material Passport

- Origin Skill: experiment-agent / academic-research-suite
- Origin Mode: run / saved-evidence aggregation
- Verification Status: ANALYZED（无新增复现求解）
- Version Label: STEP02I_INTERRUPTION_RESUME_V1

# STEP02I 最后一次有界续行 — {status}

固定 245 案例／490 科学路径：已尝试路径 {coverage['attempted_paths']}/490，完整尝试配对 {coverage['attempted_pair_coverage']}/245；有有效数值输出的配对 {coverage['valid_output_pair_coverage']}/245；严格通过 {coverage['strict_pass']}/245。尝试结局完整配对 {coverage['attempt_outcome_pairs_complete']}/245。超时或 UNKNOWN 不是有效数值输出，以上分母不混用。

新增 Stage-B 预留 {reserved}/{new_limit}（协议绝对上限468）；实际新增调用区间 [{lower}, {upper}]。含旧 UNKNOWN，Stage-B 累计区间 {result['stage_b_cumulative_call_interval']}/491，含两次历史 smoke 的 I 累计 {result['i_cumulative_call_interval']}/493。旧 UNKNOWN 仍保留为历史未知观察，不能在原账本按0或1消除；若有迟到原返回，另列补充证据且取消尚未开始重试，累计区间沿用历史观察的保守上界。停止信息：{json.dumps(stop_info, ensure_ascii=False)}。

原提交 8968e8e5c682a40050e850581e366f3261eb4616 的 partial INCOMPLETE、原始47条事件账本及 pending 均只读引用。22条已返回路径未重跑；旧5个失败永久保留，严格通过上限240/245。023 attempt1 UNKNOWN 与本轮唯一许可的 attempt2 分列于 attempt_history.jsonl；最终 path_results.jsonl 仍仅490个科学身份。合并采用首次完整来源合法返回，有限数值输出另计，绝不按门结果择优；没有返回的路径保留明确 NOT RUN 或超时/未知记录。旧交付时原因记录为UNKNOWN，之后用户说明曾手动退出Codex，详见 USER_INTERRUPTION_CONTEXT.md。这项新说明与旧观察分列保存；内部进程终止机制并未建立证据，也不因此消除原调用UNKNOWN。

本次8小时资源续行与一次基础设施 UNKNOWN 重试是已授权的后验协议修订，不是盲测，也不能声称原协议从未变更。前次 smoke 接受合同的后验修改及 PREPARATION_FAILED 历史同样保留。旧准备期间7个Julia缓存文件mtime触碰事件及其缓解记录仍在旧目录 environment/CACHE_MTIME_INCIDENT.md，不能宣称旧depot从始至终所有元数据未变。

Julia 1.10.10、Clarabel.jl 0.11.1、BigFloat256、QDLDL、完整 solver 设置与原科学输入不变。只接受 Solved；原物理检查、literal normalized band <=1e-8、五项配对等价指标和最终严格判定分别保存。高精度可行不能覆盖一次Float64导出的band失败；不接受AlmostSolved、不裁剪、不inward rounding、不修点、不逐例调参。原D坐标与16条高精度任务RHS合同保持，不把新任务端点说成与旧舍入QP逐元素相同。Stage-A只读STEP02D full_panel缓存，B1-soft与E2-A无新增求解；E2-A PASS只引用旧证据。36回归、原四例及D旧24失败均为同一面板子集，没有额外求解。

失败分类（允许重叠）：{dict(categories)}。完整覆盖而仍有失败时为FAIL / REVISE；未完成为INCOMPLETE。基础设施或资源限制不构成研究假设失败。数值结果不替代四足闭环或实际控制器执行验证；本轮结束后不进入E1/E2-B、不启动求解器搜索或证书支线。

测试为续行身份/attempt合并、预算与中断保存的无求解检查；实际命令与输出见本轮测试记录和commands.jsonl（如有）。修改文件、Git状态、提交号由本次最终交付记录补充；本报告生成器不提交、不推送。工作树：{ROOT}；输出：{out}。

方法风险检查11/11：固定因子与分母、无生态外推、无筛选样本相关推断、无碰撞变量因果推断、基率分母显式、无重测失败择优、未运行/未知不删、无多方案择优、后验修订披露、无相关性因果宣称、无逆因果宣称。确定性开发面板不提供p值、总体成功率或研究有效性的统计外推。

```text
{flags}
```
"""
    (out / "STEP02I_RESUME_REPORT.md").write_text(report, encoding="utf-8", newline="\n")
    return result
