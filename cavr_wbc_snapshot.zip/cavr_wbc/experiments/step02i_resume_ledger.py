"""Durable, no-recycling accounting for the single authorized STEP02I resume.

This module uses only the Python standard library.  Its caller owns the
single-supervisor process lock; constructing or reading a ledger never starts
a worker.  Pending reservations consume one possible call until evidence is
recorded, and historical unknown calls are never rewritten here.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import time


RETRY_CASE = 'home_nominal__FR_hip_rho_0.50__near_lateral_roll'
RETRY_IDENTITY = (RETRY_CASE, 'production', 2)
LIMIT_SECONDS = 8 * 60 * 60
MAX_NEW_ATTEMPTS = 468


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def _digest(value):
    encoded = json.dumps(value, sort_keys=True, separators=(',', ':'),
                         ensure_ascii=False, allow_nan=False).encode('utf-8')
    return hashlib.sha256(encoded).hexdigest()


def _sha(value):
    return (isinstance(value, str) and len(value) == 64
            and all(c in '0123456789abcdef' for c in value))


def _utc(timestamp=None):
    return datetime.fromtimestamp(time.time() if timestamp is None else timestamp,
                                  timezone.utc).isoformat()


def _write(path, value, mode):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open(mode, encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, allow_nan=False,
                                separators=(',', ':')) + '\n')
        stream.flush()
        os.fsync(stream.fileno())


class ResumeLedger:
    """Original ``supervise`` compatible reservation/finish interface.

    ``allowed`` contains exactly the 467 never-dispatched paths (ordinals
    24..490), optionally plus the sole permitted ordinal-23 attempt 2.
    Every item has case_id, path, attempt, solve_ordinal, input_sha256.
    Numerical transport bytes must remain unchanged; attempt belongs only to
    this call ledger and the request's reservation link.
    """

    def __init__(self, path, allowed, old_reservation_hash, clock_path, run_id):
        self.path = Path(path)
        self.clock_path = Path(clock_path)
        _require(isinstance(run_id, str) and bool(run_id.strip()), 'Missing run_id')
        self.run_id = run_id
        self.old_reservation_hash = old_reservation_hash
        self.allowed = {}
        self.scientific_index = {}
        ordinals = set()
        normalized = []
        for item in allowed:
            cid, route, attempt = item['case_id'], item['path'], item['attempt']
            ordinal = item['solve_ordinal']
            _require(isinstance(cid, str) and bool(cid), 'Invalid case_id')
            _require(route in ('production', 'reference'), 'Invalid scientific path')
            _require(type(attempt) is int and type(ordinal) is int, 'Integer identity required')
            key = (cid, route, attempt)
            scientific = (cid, route)
            _require(key not in self.allowed and scientific not in self.scientific_index,
                     'Duplicate allowed identity')
            _require(ordinal not in ordinals, 'Duplicate solve ordinal')
            _require(_sha(item['input_sha256']), 'Invalid scientific input SHA256')
            if ordinal == 23:
                _require(key == RETRY_IDENTITY, 'Only ordinal 023 production attempt 2 may retry')
                _require(_sha(old_reservation_hash), 'Retry requires original reservation hash')
                _require(item.get('old_reservation_hash', old_reservation_hash) == old_reservation_hash,
                         'Original reservation link mismatch')
                old_hash = old_reservation_hash
            else:
                _require(24 <= ordinal <= 490 and attempt == 1,
                         'Completed 22 paths cannot rerun; only 467 first attempts are allowed')
                _require(item.get('old_reservation_hash') is None, 'Unexpected retry ancestry')
                old_hash = None
            value = {'case_id': cid, 'path': route, 'attempt': attempt,
                     'solve_ordinal': ordinal, 'input_sha256': item['input_sha256'],
                     'old_reservation_hash': old_hash}
            self.allowed[key] = value
            self.scientific_index[scientific] = key
            ordinals.add(ordinal)
            normalized.append(value)
        _require(ordinals in (set(range(24, 491)), set(range(23, 491))),
                 'Resume plan must contain all 467 first attempts and optional sole retry')
        self.budget = len(self.allowed)
        _require(self.budget <= MAX_NEW_ATTEMPTS, 'Resume budget exceeds 468')
        self.plan_hash = _digest(sorted(normalized, key=lambda row: row['solve_ordinal']))

    def clock(self):
        """Read the fixed clock without creating it or resetting its deadline."""
        if not self.clock_path.exists():
            return None
        value = json.loads(self.clock_path.read_text(encoding='utf-8'))
        _require(value.get('run_id') == self.run_id, 'Clock run_id mismatch')
        _require(value.get('plan_sha256') == self.plan_hash, 'Clock plan hash mismatch')
        start, deadline = value.get('start_unix'), value.get('deadline_unix')
        _require(type(start) in (float, int) and type(deadline) in (float, int)
                 and math.isfinite(start) and math.isfinite(deadline), 'Invalid panel clock')
        _require(value.get('limit_seconds') == LIMIT_SECONDS
                 and abs((deadline - start) - LIMIT_SECONDS) <= 1e-6,
                 'Clock must preserve the fixed eight-hour interval')
        _require(datetime.fromisoformat(value['utc']).timestamp() == start,
                 'Clock UTC and numeric start disagree')
        return value

    def _clock_before_reservation(self, rows):
        clock = self.clock()
        if clock is None:
            _require(not rows, 'Existing reservations have lost their immutable clock')
            # Round to microseconds so the persisted UTC and epoch agree exactly.
            started = datetime.now(timezone.utc)
            stamp = started.timestamp()
            clock = {'utc': started.isoformat(), 'start_unix': stamp,
                     'deadline_unix': stamp + LIMIT_SECONDS, 'limit_seconds': LIMIT_SECONDS,
                     'run_id': self.run_id, 'plan_sha256': self.plan_hash,
                     'starts_at': 'FIRST_NEW_RESERVATION'}
            _write(self.clock_path, clock, 'x')
        _require(time.time() < clock['deadline_unix'], 'RESOURCE_LIMIT: fixed resume deadline reached')
        return clock

    def events(self):
        """Validate the complete chain and its frozen reservation ancestry."""
        if not self.path.exists():
            return []
        raw = self.path.read_bytes()
        _require(not raw or raw.endswith(b'\n'), 'Truncated ledger')
        rows = [json.loads(line) for line in raw.decode('utf-8').splitlines() if line]
        previous = '0' * 64
        reserved, pending = set(), set()
        clock = self.clock()
        _require(not rows or clock is not None, 'Existing reservations have lost their immutable clock')
        for sequence, row in enumerate(rows, 1):
            value = {key: item for key, item in row.items() if key != 'hash'}
            _require(row['sequence'] == sequence and row['previous_hash'] == previous
                     and row['hash'] == _digest(value), 'Ledger chain mismatch')
            previous = row['hash']
            key = tuple(row['identity'])
            _require(key in self.allowed, 'Ledger identity not in frozen resume plan')
            metadata = row['metadata']
            _require(metadata.get('run_id') == self.run_id, 'Ledger run_id mismatch')
            _require(metadata.get('plan_sha256') == self.plan_hash, 'Ledger plan hash mismatch')
            if row['event'] == 'RESERVED':
                _require(key not in reserved, 'Duplicate identity reservation; no retry')
                expected = self.allowed[key]
                _require(metadata.get('category') == 'stage_b', 'Unauthorized ledger category')
                _require(metadata.get('input_sha256') == expected['input_sha256'], 'Scientific input hash mismatch')
                _require(metadata.get('solve_ordinal') == expected['solve_ordinal'], 'Solve ordinal mismatch')
                _require(metadata.get('old_reservation_hash') == expected['old_reservation_hash'],
                         'Original reservation link mismatch')
                _require(metadata.get('deadline_unix') == clock['deadline_unix'], 'Reservation clock mismatch')
                reserved.add(key)
                pending.add(key)
            elif row['event'] == 'FINISHED':
                _require(key in pending, 'Finish without pending reservation')
                self._check_counts(metadata)
                pending.remove(key)
            else:
                raise ValueError('Unknown ledger event')
        _require(len(reserved) <= self.budget, 'Call budget exhausted')
        return rows

    @staticmethod
    def _check_counts(metadata):
        confirmed = metadata.get('confirmed_solve_calls')
        unknown = metadata.get('unknown_call_upper_bound')
        _require(type(confirmed) is int and type(unknown) is int
                 and confirmed in (0, 1) and unknown in (0, 1) and confirmed + unknown <= 1,
                 'Each reservation permits at most one actual or unknown call')

    def _append(self, event, identity, rows, **metadata):
        _require('run_id' not in metadata and 'plan_sha256' not in metadata,
                 'Caller cannot replace frozen ledger metadata')
        row = {'sequence': len(rows) + 1, 'previous_hash': rows[-1]['hash'] if rows else '0' * 64,
               'event': event, 'identity': list(identity), 'utc': _utc(),
               'metadata': {**metadata, 'run_id': self.run_id, 'plan_sha256': self.plan_hash}}
        row['hash'] = _digest(row)
        _write(self.path, row, 'a')
        return row

    def reserve(self, category, case_id, path, input_hash):
        _require(category == 'stage_b', 'Only Stage-B resume calls are authorized; no smoke')
        key = self.scientific_index.get((case_id, path))
        _require(key is not None, 'Identity not authorized: completed paths cannot rerun')
        expected = self.allowed[key]
        _require(input_hash == expected['input_sha256'], 'Scientific input hash mismatch')
        rows = self.events()
        starts = [row for row in rows if row['event'] == 'RESERVED']
        _require(not any(tuple(row['identity']) == key for row in starts),
                 'Identity already consumed; no retry')
        _require(len(starts) < self.budget, 'Call budget exhausted')
        clock = self._clock_before_reservation(rows)
        return self._append('RESERVED', key, rows, category='stage_b', input_sha256=input_hash,
                            solve_ordinal=expected['solve_ordinal'],
                            old_reservation_hash=expected['old_reservation_hash'],
                            deadline_unix=clock['deadline_unix'])

    def finish(self, identity, **metadata):
        rows = self.events()
        key = tuple(identity)
        starts = {tuple(row['identity']) for row in rows if row['event'] == 'RESERVED'}
        finishes = {tuple(row['identity']) for row in rows if row['event'] == 'FINISHED'}
        _require(key in starts and key not in finishes, 'Finish without pending reservation')
        self._check_counts(metadata)
        return self._append('FINISHED', key, rows, **metadata)

    def accounting(self):
        rows = self.events()
        starts = [row for row in rows if row['event'] == 'RESERVED']
        finishes = {tuple(row['identity']): row for row in rows if row['event'] == 'FINISHED'}
        confirmed = unknown = 0
        for start in starts:
            end = finishes.get(tuple(start['identity']))
            if end is None:
                unknown += 1
            else:
                confirmed += end['metadata']['confirmed_solve_calls']
                unknown += end['metadata']['unknown_call_upper_bound']
        return {'stage_b': {'budget': self.budget, 'reserved': len(starts),
                           'finished': len(finishes), 'pending': len(starts) - len(finishes),
                           'confirmed_calls': confirmed, 'unknown_call_upper_bound': unknown,
                           'actual_calls': confirmed if unknown == 0 else None,
                           'calls_lower_bound': confirmed, 'calls_upper_bound': confirmed + unknown}}
