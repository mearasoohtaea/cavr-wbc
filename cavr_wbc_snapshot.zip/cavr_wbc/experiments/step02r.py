"""Run the frozen STEP-02R regression gate and stop safely on failure."""

from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import math
from pathlib import Path
import subprocess
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mujoco
import numpy as np
import yaml

from cavr_wbc.control.fixed_support_qp import (
    QpSolveResult,
    build_contact_template,
    build_physical_snapshot,
)
from cavr_wbc.control.independent_lex_reference import (
    ClarabelReferenceSettings,
    IndependentLexicographicReference,
)
from cavr_wbc.control.scaled_fixed_support_qp import (
    ScaledFixedSupportPhysicalQp,
    Step02rSolverSettings,
    physical_validation_pass,
)
from cavr_wbc.platforms.go2_mujoco import (
    DEFAULT_GO2_MODEL_PATH,
    extract_actuator_joint_map,
    load_go2_model,
)


PARENT_ROOT = Path("artifacts/step02_b1_p0_equivalence")
DEFAULT_OUTPUT = Path("artifacts/step02r_b1_p0_equivalence")
REGRESSION_CASES = (
    {
        "regression_id": "A_previous_stage2_primal_infeasible",
        "snapshot_id": "contact_nullspace_1_plus",
        "health_id": "healthy",
        "demand_id": "infeasible_positive_mix",
    },
    {
        "regression_id": "B_previous_worst_normal_upper",
        "snapshot_id": "contact_nullspace_0_minus",
        "health_id": "FR_calf_rho_0.25",
        "demand_id": "infeasible_positive_mix",
    },
    {
        "regression_id": "C_damaged_actuator_boundary",
        "snapshot_id": "home_nominal",
        "health_id": "FR_calf_rho_0.25",
        "demand_id": "infeasible_positive_mix",
    },
    {
        "regression_id": "D_ordinary_feasible",
        "snapshot_id": "home_nominal",
        "health_id": "healthy",
        "demand_id": "small_zero",
    },
)


def _json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    if isinstance(value, np.ndarray):
        return _json_safe(value.tolist())
    if isinstance(value, (np.floating, float)):
        number = float(value)
        if math.isinf(number):
            return "Infinity" if number > 0 else "-Infinity"
        return number if math.isfinite(number) else "NaN"
    if isinstance(value, np.integer):
        return int(value)
    if isinstance(value, np.bool_):
        return bool(value)
    return value


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(_json_safe(value), indent=2, ensure_ascii=False, allow_nan=False)
        + "\n",
        encoding="utf-8",
    )


def _write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        raise ValueError(f"empty audit table: {path}")
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(_json_safe(rows))


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _version(name: str) -> str | None:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return None


def _result_record(case: dict[str, str], result: QpSolveResult | None) -> dict[str, Any]:
    if result is None:
        return {
            **case,
            "method": "NOT_LAUNCHED",
            "status": "PRIMARY_WITNESS_NUMERICALLY_INVALID",
            "success": False,
            "validation": {"available": False},
        }
    return {
        **case,
        "method": result.method,
        "status": result.status,
        "status_val": result.status_val,
        "success": result.success,
        "iterations": result.iterations,
        "solve_time_s": result.solve_time_s,
        "setup_time_s": result.setup_time_s,
        "primal_residual": result.primal_residual,
        "dual_residual": result.dual_residual,
        "solver_objective": result.solver_objective,
        "qdd": result.qdd,
        "tau": result.tau,
        "contact_force": result.contact_force,
        "task_output": result.task_output,
        "task_objective": result.task_objective,
        "torque_regularizer": result.torque_regularizer,
        "validation": result.validation,
    }


def _metric(
    snapshot: Any,
    desired: np.ndarray,
    p0: QpSolveResult | None,
    other: QpSolveResult | None,
) -> dict[str, float | None]:
    if (
        p0 is None
        or other is None
        or not p0.success
        or not other.success
    ):
        return {
            "normalized_task_output_inf_difference": None,
            "task_objective_abs_difference": None,
            "torque_regularizer_abs_difference": None,
        }
    p0_residual = (p0.task_output - desired) / snapshot.task_scales
    other_residual = (other.task_output - desired) / snapshot.task_scales
    return {
        "normalized_task_output_inf_difference": float(
            np.max(np.abs((p0.task_output - other.task_output) / snapshot.task_scales))
        ),
        "task_objective_abs_difference": float(
            abs(
                np.sum(snapshot.task_weights * np.square(p0_residual))
                - np.sum(snapshot.task_weights * np.square(other_residual))
            )
        ),
        "torque_regularizer_abs_difference": float(
            abs(p0.torque_regularizer - other.torque_regularizer)
        ),
    }


def _comparison_pass(metrics: dict[str, Any], thresholds: dict[str, float]) -> bool:
    return bool(
        metrics["normalized_task_output_inf_difference"] is not None
        and metrics["normalized_task_output_inf_difference"]
        <= thresholds["normalized_task_equivalence"]
        and metrics["task_objective_abs_difference"]
        <= thresholds["task_objective_difference"]
        and metrics["torque_regularizer_abs_difference"]
        <= thresholds["torque_regularizer_difference"]
    )


def _placeholder(ax: Any, text: str) -> None:
    ax.axis("off")
    ax.text(0.5, 0.5, text, ha="center", va="center", wrap=True)


def _figures(
    output: Path,
    independent_rows: list[dict[str, Any]],
    soft_rows: list[dict[str, Any]],
    osqp_diagnostics: list[dict[str, Any]],
    reference_diagnostics: list[dict[str, Any]],
) -> None:
    plt.rcParams.update({"figure.dpi": 150, "font.size": 9})
    valid = [
        row
        for row in independent_rows
        if row["normalized_task_output_inf_difference"] is not None
    ]
    fig, ax = plt.subplots(figsize=(5.4, 4.4))
    if valid:
        ax.scatter(
            [row["p0_task_scalar"] for row in valid],
            [row["reference_task_scalar"] for row in valid],
        )
        ax.set_xlabel("P0 task-output norm")
        ax.set_ylabel("independent reference task-output norm")
    else:
        _placeholder(
            ax,
            "No valid Stage-B comparison\nRegression gate stopped before full panel",
        )
    ax.set_title("STEP-02R independent task output (regression gate)")
    fig.tight_layout()
    fig.savefig(output / "independent_p0_vs_lex_task_output.png")
    plt.close(fig)

    for filename, field, title in (
        (
            "independent_task_objective_difference.png",
            "task_objective_abs_difference",
            "Independent primary-objective difference",
        ),
        (
            "independent_torque_regularizer_difference.png",
            "torque_regularizer_abs_difference",
            "Independent secondary-regularizer difference",
        ),
    ):
        fig, ax = plt.subplots(figsize=(6.0, 4.0))
        values = [row[field] for row in valid]
        if values:
            ax.bar(range(len(values)), values)
            ax.set_yscale("symlog", linthresh=1e-14)
            ax.set_ylabel(field)
        else:
            _placeholder(
                ax,
                "Unavailable because P0 Stage-B failed the regression gate",
            )
        ax.set_title(f"{title} — regression only")
        fig.tight_layout()
        fig.savefig(output / filename)
        plt.close(fig)

    all_diagnostics = osqp_diagnostics + reference_diagnostics
    fig, ax = plt.subplots(figsize=(7.0, 4.4))
    labels = []
    values = []
    for item in all_diagnostics:
        validation = item.get("validation", {})
        if validation.get("available"):
            labels.append(item["method"])
            values.append(
                max(
                    validation["dynamics_infinity_norm"],
                    validation["contact_infinity_norm"],
                    validation["hard_inequality_violation"],
                    1e-18,
                )
            )
    ax.scatter(range(len(values)), values, s=14)
    ax.axhline(1e-7, color="red", linestyle="--", label="hard inequality gate")
    ax.axhline(1e-6, color="orange", linestyle="--", label="equality gates")
    ax.set_yscale("log")
    ax.set_ylabel("maximum original-unit residual")
    ax.set_xlabel("successful regression solve index")
    ax.set_title("Physical residuals — regression gate only")
    ax.legend()
    fig.tight_layout()
    fig.savefig(output / "physical_residual_distributions.png")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7.0, 4.4))
    methods = [
        "P0_OSQP_SCALED_STAGE1",
        "P0_OSQP_SCALED_STAGE2",
        "B1_LEX_REFERENCE_INDEPENDENT_STAGE_A",
        "B1_LEX_REFERENCE_INDEPENDENT_STAGE_B",
    ]
    runtime = []
    for method in methods:
        values = [
            item["solve_time_s"] * 1000.0
            for item in all_diagnostics
            if item.get("method") == method and item.get("solve_time_s") is not None
        ]
        runtime.append(float(np.median(values)) if values else 0.0)
    ax.bar(range(len(methods)), runtime)
    ax.set_xticks(range(len(methods)), ["P0 A", "P0 B", "Ref A", "Ref B"])
    ax.set_ylabel("median solve time (ms)")
    ax.set_title("OSQP vs Clarabel runtime — regression gate only")
    fig.tight_layout()
    fig.savefig(output / "osqp_vs_reference_runtime.png")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(6.0, 4.0))
    valid_soft = [
        row for row in soft_rows if row["normalized_task_difference_l2"] is not None
    ]
    if valid_soft:
        ax.bar(
            range(len(valid_soft)),
            [row["normalized_task_difference_l2"] for row in valid_soft],
        )
        ax.set_ylabel("normalized task-output difference L2")
    else:
        _placeholder(ax, "No valid P0 Stage-B/B1-soft comparison")
    ax.set_title("B1-soft vs P0 — regression gate only")
    fig.tight_layout()
    fig.savefig(output / "b1soft_vs_p0_task_difference.png")
    plt.close(fig)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--config", default="configs/dev/step02r_b1_p0_equivalence.yaml"
    )
    parser.add_argument("--output", default=str(DEFAULT_OUTPUT))
    parser.add_argument("--verified-test-count", type=int, default=0)
    args = parser.parse_args()
    config_path = Path(args.config)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    if not (output / "STEP02_V1_FAILURE_DIAGNOSIS.json").is_file():
        raise FileNotFoundError("v1 failure diagnosis must exist before STEP-02R")

    config_text = config_path.read_text(encoding="utf-8")
    config = yaml.safe_load(config_text)
    config_hash = _sha256(config_path)
    (output / "config.yaml").write_text(config_text, encoding="utf-8")
    (output / "config_sha256.txt").write_text(config_hash + "\n", encoding="utf-8")
    generated_at = datetime.now(timezone.utc).astimezone().isoformat()

    v1_config = yaml.safe_load((PARENT_ROOT / "config.yaml").read_text(encoding="utf-8"))
    frozen_keys = (
        "platform",
        "physical_model",
        "snapshot_panel",
        "task_stack",
        "objectives",
        "validation",
        "health_panel",
        "task_demands",
    )
    scientific_freeze = {
        key: config[key] == v1_config[key] for key in frozen_keys
    }
    if not all(scientific_freeze.values()):
        raise ValueError(f"STEP-02R scientific freeze mismatch: {scientific_freeze}")

    panel = json.loads(
        (PARENT_ROOT / "snapshot_panel.json").read_text(encoding="utf-8")
    )["states"]
    model = load_go2_model()
    nominal_data = mujoco.MjData(model)
    mujoco.mj_resetDataKeyframe(
        model,
        nominal_data,
        mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_KEY, "home"),
    )
    mujoco.mj_forward(model, nominal_data)
    template = build_contact_template(model, nominal_data)
    total_weight = float(np.sum(model.body_mass) * abs(model.opt.gravity[2]))
    snapshots = {
        item["snapshot_id"]: build_physical_snapshot(
            model,
            template,
            item["snapshot_id"],
            item["qpos"],
            task_scales=config["task_stack"]["normalization_scales"],
            task_weights=config["task_stack"]["weight_diagonal"],
            normal_force_upper=total_weight,
        )
        for item in panel
    }
    health_by_id = {item["health_id"]: item for item in config["health_panel"]}
    demand_by_id = {item["demand_id"]: item for item in config["task_demands"]}
    actuator_index = {
        item.actuator_name: item.actuator_index
        for item in extract_actuator_joint_map(model)
    }
    osqp_settings = Step02rSolverSettings(**config["osqp"])
    reference_settings = ClarabelReferenceSettings(
        **config["clarabel_reference"]
    )
    tolerance = config["objectives"]["secondary_task_fix_normalized_tolerance"]
    lambda_tau = config["objectives"]["lambda_tau"]
    thresholds = config["validation"]

    osqp_diagnostics: list[dict[str, Any]] = []
    reference_diagnostics: list[dict[str, Any]] = []
    regression_results: list[dict[str, Any]] = []
    independent_rows: list[dict[str, Any]] = []
    internal_rows: list[dict[str, Any]] = []
    soft_rows: list[dict[str, Any]] = []
    representative_audit: dict[str, Any] | None = None
    accepted_osqp_settings = None
    accepted_reference_settings = None

    print("STEP-02R frozen regression gate: 4 cases; full panel remains gated")
    for case_spec in REGRESSION_CASES:
        snapshot = snapshots[case_spec["snapshot_id"]]
        health = health_by_id[case_spec["health_id"]]
        demand = demand_by_id[case_spec["demand_id"]]
        desired = np.asarray(demand["y_d"], dtype=float)
        rho = np.ones(model.nu)
        if health["actuator"] is not None:
            rho[actuator_index[health["actuator"]]] = float(health["rho"])
        case = {
            **case_spec,
            "case_id": (
                f"{case_spec['snapshot_id']}__{case_spec['health_id']}__"
                f"{case_spec['demand_id']}"
            ),
        }
        production = ScaledFixedSupportPhysicalQp(
            snapshot,
            rho,
            osqp_settings,
            secondary_task_fix_normalized_tolerance=tolerance,
        )
        p0_a = production.solve_p0_stage1(desired)
        p0_a_valid = physical_validation_pass(p0_a, thresholds)
        p0_b = (
            production.solve_p0_stage2(
                p0_a.task_output, lambda_tau, warm_start=p0_a
            )
            if p0_a.success and p0_a_valid
            else None
        )
        internal_a = production.solve_internal_lex_stage_a(desired)
        internal_a_valid = physical_validation_pass(internal_a, thresholds)
        internal_b = (
            production.solve_internal_lex_stage_b(
                internal_a.task_output, lambda_tau, warm_start=internal_a
            )
            if internal_a.success and internal_a_valid
            else None
        )
        soft = production.solve_b1_soft(desired, lambda_tau)
        accepted_osqp_settings = production.accepted_osqp_settings

        reference = IndependentLexicographicReference(
            snapshot,
            rho,
            reference_settings,
            secondary_task_fix_normalized_tolerance=tolerance,
        )
        ref_a = reference.solve_stage_a(desired)
        ref_a_valid = physical_validation_pass(ref_a, thresholds)
        ref_b = (
            reference.solve_stage_b(ref_a.task_output, lambda_tau)
            if ref_a.success and ref_a_valid
            else None
        )
        accepted_reference_settings = reference.accepted_settings

        for result in (p0_a, p0_b, internal_a, internal_b, soft):
            osqp_diagnostics.append(_result_record(case, result))
        for result in (ref_a, ref_b):
            reference_diagnostics.append(_result_record(case, result))

        p0_b_valid = physical_validation_pass(p0_b, thresholds)
        internal_b_valid = physical_validation_pass(internal_b, thresholds)
        ref_b_valid = physical_validation_pass(ref_b, thresholds)
        soft_valid = physical_validation_pass(soft, thresholds)
        fixed_task_checks = {
            "p0_stage_b": (
                p0_b is not None
                and p0_b.success
                and p0_b.validation["fixed_task_normalized_infinity_error"]
                <= tolerance
            ),
            "reference_stage_b": (
                ref_b is not None
                and ref_b.success
                and ref_b.validation["fixed_task_normalized_infinity_error"]
                <= tolerance
            ),
        }
        independent_metrics = _metric(snapshot, desired, p0_b, ref_b)
        internal_metrics = _metric(snapshot, desired, p0_b, internal_b)
        independent_pass = bool(
            p0_b_valid
            and ref_b_valid
            and fixed_task_checks["p0_stage_b"]
            and fixed_task_checks["reference_stage_b"]
            and _comparison_pass(independent_metrics, thresholds)
        )
        internal_pass = bool(
            p0_b_valid
            and internal_b_valid
            and _comparison_pass(internal_metrics, thresholds)
        )
        regression_pass = bool(
            p0_a_valid
            and p0_b_valid
            and ref_a_valid
            and ref_b_valid
            and soft_valid
            and fixed_task_checks["p0_stage_b"]
            and fixed_task_checks["reference_stage_b"]
            and independent_pass
        )
        regression_results.append(
            {
                **case,
                "p0_stage_a_status": p0_a.status,
                "p0_stage_a_physical_pass": p0_a_valid,
                "p0_stage_b_status": (
                    "PRIMARY_WITNESS_NUMERICALLY_INVALID"
                    if p0_b is None
                    else p0_b.status
                ),
                "p0_stage_b_physical_pass": p0_b_valid,
                "reference_stage_a_status": ref_a.status,
                "reference_stage_a_physical_pass": ref_a_valid,
                "reference_stage_b_status": (
                    "PRIMARY_WITNESS_NUMERICALLY_INVALID"
                    if ref_b is None
                    else ref_b.status
                ),
                "reference_stage_b_physical_pass": ref_b_valid,
                "b1_soft_status": soft.status,
                "b1_soft_physical_pass": soft_valid,
                "fixed_task_checks": fixed_task_checks,
                "independent_equivalence_metrics": independent_metrics,
                "independent_equivalence_pass": independent_pass,
                "internal_identity_pass": internal_pass,
                "regression_pass": regression_pass,
            }
        )
        independent_rows.append(
            {
                **case,
                "p0_stage_a_status": p0_a.status,
                "p0_stage_b_status": "NOT_RUN" if p0_b is None else p0_b.status,
                "reference_stage_a_status": ref_a.status,
                "reference_stage_b_status": "NOT_RUN" if ref_b is None else ref_b.status,
                **independent_metrics,
                "p0_task_scalar": (
                    None if p0_b is None or not p0_b.success else float(np.linalg.norm(p0_b.task_output))
                ),
                "reference_task_scalar": (
                    None if ref_b is None or not ref_b.success else float(np.linalg.norm(ref_b.task_output))
                ),
                "equivalence_pass": independent_pass,
                "scope": "FROZEN_REGRESSION_GATE_ONLY",
            }
        )
        internal_rows.append(
            {
                **case,
                "interpretation": "implementation identity regression",
                "p0_stage_b_status": "NOT_RUN" if p0_b is None else p0_b.status,
                "internal_stage_b_status": "NOT_RUN" if internal_b is None else internal_b.status,
                **internal_metrics,
                "identity_pass": internal_pass,
                "scope": "FROZEN_REGRESSION_GATE_ONLY",
            }
        )
        soft_difference = None
        if p0_b is not None and p0_b.success and soft.success:
            soft_difference = float(
                np.linalg.norm(
                    (p0_b.task_output - soft.task_output) / snapshot.task_scales
                )
            )
        soft_rows.append(
            {
                **case,
                "p0_stage_b_status": "NOT_RUN" if p0_b is None else p0_b.status,
                "b1_soft_status": soft.status,
                "p0_physical_pass": p0_b_valid,
                "b1_soft_physical_pass": soft_valid,
                "normalized_task_difference_l2": soft_difference,
                "scope": "FROZEN_REGRESSION_GATE_ONLY",
            }
        )

        if representative_audit is None:
            representative_audit = {
                "parent_run": "STEP02_FAIL",
                "disposition": "NUMERICAL_REVISION",
                "representative_case": case,
                "osqp_stage_b_problem": production.audit_problem(
                    torque_regularization_weight=lambda_tau,
                    fixed_task_output=p0_a.task_output,
                ),
                "clarabel_stage_b_problem": reference.audit_problem(
                    torque_regularization_weight=lambda_tau,
                    fixed_task_output=ref_a.task_output,
                ),
            }
        print(
            f"STEP-02R regression {case_spec['regression_id']}: "
            f"{'PASS' if regression_pass else 'FAIL'}"
        )

    regression_gate_pass = all(
        item["regression_pass"] for item in regression_results
    )
    full_panel_executed = False
    stop_reason = (
        None
        if regression_gate_pass
        else (
            "STEP02R_REVISE_REQUIRED: the uniformly scaled OSQP Stage-B path "
            "did not complete and satisfy the unchanged 1e-8 fixed-task band "
            "in every frozen regression."
        )
    )
    if regression_gate_pass:
        stop_reason = (
            "Regression gate passed, but this guarded runner intentionally does not "
            "auto-launch the separate full-panel command."
        )

    numerical_scaling = {
        "parent_run": "STEP02_FAIL",
        "disposition": "NUMERICAL_REVISION",
        "coordinate_equation": "w = D_variable * w_hat",
        "variable_order": ["qdd[18]", "tau[12]", "lambda_world[12]"],
        "D_variable_diagonal": ScaledFixedSupportPhysicalQp(
            snapshots["home_nominal"],
            np.ones(model.nu),
            osqp_settings,
            secondary_task_fix_normalized_tolerance=tolerance,
        ).variable_scales,
        "qdd_scales": {
            "base_translation": 1.0,
            "base_rotation": 2.0,
            "joints": 10.0,
        },
        "tau_scale_source": "frozen healthy actuator torque limits",
        "lambda_scale_n": total_weight,
        "rho_changes_variable_scale": False,
        "row_scaling_rule": config["constraint_row_scaling"],
        "invertible": True,
        "scientific_feasible_set_changed": False,
    }
    _write_json(output / "numerical_scaling.json", numerical_scaling)
    _write_json(output / "scaled_qp_audit.json", representative_audit)
    _write_json(
        output / "dependency_manifest.json",
        {
            "parent_run": "STEP02_FAIL",
            "disposition": "NUMERICAL_REVISION",
            "python": subprocess.check_output(
                ["python", "--version"], text=True, encoding="utf-8"
            ).strip(),
            "requirements_file": "requirements-step02r.txt",
            "installation_command": "python -m pip install clarabel",
            "versions": {
                name: _version(name)
                for name in (
                    "mujoco",
                    "numpy",
                    "scipy",
                    "osqp",
                    "clarabel",
                    "cffi",
                    "pycparser",
                    "PyYAML",
                    "matplotlib",
                )
            },
            "cvxpy_installed": _version("cvxpy") is not None,
            "rl_libraries_installed_by_step02r": False,
        },
    )
    _write_json(
        output / "regression_test_results.json",
        {
            "parent_run": "STEP02_FAIL",
            "disposition": "NUMERICAL_REVISION",
            "generated_at": generated_at,
            "config_sha256": config_hash,
            "verified_unit_test_count": args.verified_test_count,
            "regression_gate_pass": regression_gate_pass,
            "full_panel_authorized_by_regression_gate": regression_gate_pass,
            "full_panel_executed": full_panel_executed,
            "stop_reason": stop_reason,
            "cases": regression_results,
        },
    )
    _write_csv(output / "eq_cases_independent.csv", independent_rows)
    _write_csv(output / "internal_identity_cases.csv", internal_rows)
    _write_csv(output / "b1_soft_vs_p0.csv", soft_rows)
    for path, rows in (
        (output / "solver_diagnostics_osqp.jsonl", osqp_diagnostics),
        (output / "solver_diagnostics_reference.jsonl", reference_diagnostics),
    ):
        with path.open("w", encoding="utf-8", newline="\n") as handle:
            for row in rows:
                handle.write(
                    json.dumps(_json_safe(row), ensure_ascii=False, allow_nan=False)
                    + "\n"
                )
    _figures(
        output,
        independent_rows,
        soft_rows,
        osqp_diagnostics,
        reference_diagnostics,
    )

    osqp_stage_b_noncompletion = sum(
        item["p0_stage_b_status"] != "solved" for item in regression_results
    )
    osqp_stage_b_band_failures = sum(
        not item["fixed_task_checks"]["p0_stage_b"]
        for item in regression_results
    )
    osqp_stage_b_physical_passes = sum(
        item["p0_stage_b_physical_pass"] for item in regression_results
    )
    osqp_stage_b_fixed_errors = {
        item["case_id"]: item["validation"].get(
            "fixed_task_normalized_infinity_error"
        )
        for item in osqp_diagnostics
        if item.get("method") == "P0_OSQP_SCALED_STAGE2"
        and item.get("validation", {}).get("available")
    }
    reference_complete = all(
        item["reference_stage_a_physical_pass"]
        and item["reference_stage_b_physical_pass"]
        for item in regression_results
    )
    gates = {
        "parent_v1_preserved": True,
        "scientific_content_unchanged": all(scientific_freeze.values()),
        "all_52_unit_tests_passed": args.verified_test_count >= 52,
        "four_frozen_regressions_pass": regression_gate_pass,
        "full_245_case_panel_executed_once": full_panel_executed,
        "all_245_p0_stage_a_valid": False,
        "all_245_p0_stage_b_valid": False,
        "all_245_independent_stage_a_valid": False,
        "all_245_independent_stage_b_valid": False,
        "all_245_b1_soft_valid": False,
        "all_245_independent_equivalence_pass": False,
    }
    summary = {
        "parent_run": "STEP02_FAIL",
        "disposition": "NUMERICAL_REVISION",
        "status": "FAIL",
        "stage_disposition": "STEP02R_REVISE_REQUIRED",
        "config_sha256": config_hash,
        "scientific_freeze_checks": scientific_freeze,
        "regression_case_count": len(REGRESSION_CASES),
        "regression_pass_count": sum(
            item["regression_pass"] for item in regression_results
        ),
        "osqp_stage_b_solver_noncompletion_count": osqp_stage_b_noncompletion,
        "osqp_stage_b_fixed_task_band_failure_count": osqp_stage_b_band_failures,
        "osqp_stage_b_physical_pass_count": osqp_stage_b_physical_passes,
        "osqp_stage_b_fixed_task_errors_for_completed_witnesses": (
            osqp_stage_b_fixed_errors
        ),
        "independent_reference_completed_all_regressions": reference_complete,
        "full_panel_executed": full_panel_executed,
        "full_panel_case_count": 0,
        "classification": (
            "OSQP_NUMERICAL_IMPLEMENTATION_LIMITATION"
            if osqp_stage_b_band_failures > 0 and reference_complete
            else "REGRESSION_GATE_FAILURE"
        ),
        "stop_reason": stop_reason,
        "accepted_osqp_settings": accepted_osqp_settings,
        "accepted_clarabel_settings": accepted_reference_settings,
        "pass_gate": gates,
        "next_stage_allowed": False,
    }
    _write_json(output / "eq_summary.json", summary)
    result = {
        "parent_run": "STEP02_FAIL",
        "disposition": "NUMERICAL_REVISION",
        "status": "FAIL",
        "stage": "STEP02R_NUMERICAL_CONDITIONING_INDEPENDENT_REFERENCE",
        "stage_disposition": "STEP02R_REVISE_REQUIRED",
        "generated_at": generated_at,
        "git_head_at_execution": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], text=True, encoding="utf-8"
        ).strip(),
        "config_sha256": config_hash,
        "full_panel_executed": False,
        "classification": summary["classification"],
        "stop_reason": stop_reason,
        "next_stage_allowed": False,
        "e1_started": False,
        "recoverability_evidence": False,
    }
    _write_json(output / "STEP02R_RESULT.json", result)

    report = f"""# CAVR-WBC STEP-02R Numerical Revision Report

## Material Passport

- Origin Skill: experiment-agent
- Origin Mode: run + validate
- Origin Date: {generated_at}
- Verification Status: VERIFIED regression-gate execution
- Version Label: step02r_regression_gate_v1

## Identity and scope

- parent_run = STEP02_FAIL
- disposition = NUMERICAL_REVISION
- Frozen parent artifacts: `artifacts/step02_b1_p0_equivalence/`
- Frozen parent commits: `5b29626`, `ad640b9`
- STEP-02R config SHA256: `{config_hash}`

The robot, model, contact data, 5 snapshots, 7 health conditions, 7 task
demands, task definition/scaling, lambda_tau, torque/force bounds, fault model,
task-fix band, and every physical/equivalence threshold match STEP-02 v1.

## Failure-cause audit

`STEP02_V1_FAILURE_DIAGNOSIS.json` was generated before the solver revision.
It classifies 42 unique failed v1 cases across 102 case-stage records using
solver status and independently recomputed original-unit residuals.

## Numerical revision

The physical variable remains the 42D vector `[qdd, tau, lambda]`. OSQP uses
dimensionless coordinates with fixed qdd scales `[1, 1, 1, 2, 2, 2, 10 x12]`,
healthy torque-limit scales, and total robot weight ({total_weight} N) for all
contact-force components. Every constraint row is scaled by one positive,
deterministic max-magnitude rule. Runtime accepted settings are recorded in
`eq_summary.json` and the original-unit validator remains authoritative.

Clarabel { _version('clarabel') } is called through its direct Python API. It
assembles dynamics, contact, torque, friction, normal-force, and task-band
constraints in a separate source path; CVXPY was not installed.

## Tests and frozen regression gate

- Unit/integration tests: {args.verified_test_count}/52 passed.
- Frozen regression cases: {sum(item['regression_pass'] for item in regression_results)}/4 passed.
- Scaled OSQP Stage-B solver non-completions: {osqp_stage_b_noncompletion}/4.
- Scaled OSQP Stage-B fixed-task-band failures: {osqp_stage_b_band_failures}/4.
- Scaled OSQP Stage-B physically valid witnesses: {osqp_stage_b_physical_passes}/4.
- Completed OSQP Stage-B fixed-task errors: {osqp_stage_b_fixed_errors}.
- Independent Clarabel A/B physically valid for all regressions: {reference_complete}.
- Full 245-case panel executed: {full_panel_executed}.

The full panel was not launched because the predeclared regression gate failed.
No individual case was retried, no setting was changed per case, and the
normalized fixed-task band remains exactly 1e-8.

## Disposition

**STEP-02R = FAIL / REVISE**

Classification: `{summary['classification']}`. The independent reference
solves the frozen regression cases, while the production OSQP Stage-B path
does not robustly complete and remain inside the required band under the
unified settings. This is not interpreted as a physical-model failure or as
evidence for or against
recoverability. E1 was not started.

NEXT_STAGE_ALLOWED = FALSE
"""
    (output / "STEP02R_REPORT.md").write_text(report, encoding="utf-8")
    print(json.dumps(_json_safe(result), indent=2, ensure_ascii=False))
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
