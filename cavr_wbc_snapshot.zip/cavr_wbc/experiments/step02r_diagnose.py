"""Create the immutable STEP-02 v1 failure-cause audit for STEP-02R."""

from __future__ import annotations

from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
from typing import Any


V1_ROOT = Path("artifacts/step02_b1_p0_equivalence")
OUTPUT = Path(
    "artifacts/step02r_b1_p0_equivalence/STEP02_V1_FAILURE_DIAGNOSIS.json"
)
PRIMARY_STAGES = {"P0_STAGE1", "B1_LEX_STAGE_A"}
SECONDARY_STAGES = {"P0_STAGE2", "B1_LEX_STAGE_B"}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _increment_unique(
    mapping: dict[str, set[str]], key: str, case_id: str
) -> None:
    mapping[key].add(case_id)


def main() -> int:
    summary = json.loads((V1_ROOT / "eq_summary.json").read_text(encoding="utf-8"))
    thresholds = summary["thresholds"]
    task_panel = json.loads(
        (V1_ROOT / "task_demand_panel.json").read_text(encoding="utf-8")
    )
    task_values = {
        item["demand_id"]: item for item in task_panel["demands"]
    }
    diagnostics = [
        json.loads(line)
        for line in (V1_ROOT / "solver_diagnostics.jsonl")
        .read_text(encoding="utf-8")
        .splitlines()
    ]

    records: list[dict[str, Any]] = []
    failed_case_ids: set[str] = set()
    occurrence_counts: dict[str, Counter[str]] = {
        name: Counter()
        for name in (
            "snapshot",
            "health_condition",
            "task_demand",
            "qp_stage",
            "physical_constraint_family",
        )
    }
    unique_counts: dict[str, dict[str, set[str]]] = {
        name: defaultdict(set)
        for name in (
            "snapshot",
            "health_condition",
            "task_demand",
            "qp_stage",
            "physical_constraint_family",
        )
    }

    for item in diagnostics:
        stage = item["stage"]
        status = item["status"]
        validation = item.get("validation", {})
        families: list[dict[str, str]] = []
        if stage in PRIMARY_STAGES and not item.get("success", False):
            families.append(
                {"code": "A", "family": "primary_stage_solver_failure"}
            )
        if stage in SECONDARY_STAGES and status == "primal infeasible":
            families.append(
                {"code": "B", "family": "secondary_stage_primal_infeasible"}
            )
        if validation.get("available"):
            checks = (
                (
                    "C",
                    "dynamics_residual_failure",
                    "dynamics_infinity_norm",
                    thresholds["dynamics_infinity_norm"],
                ),
                (
                    "D",
                    "contact_residual_failure",
                    "contact_infinity_norm",
                    thresholds["contact_infinity_norm"],
                ),
                (
                    "E",
                    "torque_bound_violation",
                    "torque_violation",
                    thresholds["hard_inequality_violation"],
                ),
                (
                    "F",
                    "friction_violation",
                    "friction_violation",
                    thresholds["hard_inequality_violation"],
                ),
                (
                    "G",
                    "normal_force_lower_violation",
                    "normal_force_lower_violation",
                    thresholds["hard_inequality_violation"],
                ),
                (
                    "H",
                    "normal_force_upper_violation",
                    "normal_force_upper_violation",
                    thresholds["hard_inequality_violation"],
                ),
                (
                    "I",
                    "health_adapter_identity_failure",
                    "health_adapter_identity_error",
                    thresholds["health_adapter_identity"],
                ),
            )
            for code, family, field, threshold in checks:
                value = validation.get(field)
                if value is not None and float(value) > float(threshold):
                    families.append({"code": code, "family": family})
        if not families:
            continue

        case_id = item["case_id"]
        failed_case_ids.add(case_id)
        family_names = [entry["family"] for entry in families]
        record = {
            "case_id": case_id,
            "snapshot": item["snapshot_id"],
            "health_condition": item["health_id"],
            "task": item["demand_id"],
            "task_class": item["demand_class"],
            "task_demand_y_d": task_values[item["demand_id"]]["y_d"],
            "stage": stage,
            "failure_classification": families,
            "solver": {
                "status": status,
                "status_val": item.get("status_val"),
                "success": item.get("success", False),
                "iterations": item.get("iterations"),
                "primal_residual": item.get("primal_residual"),
                "dual_residual": item.get("dual_residual"),
            },
            "original_unit_residuals": {
                "dynamics_infinity_norm": validation.get(
                    "dynamics_infinity_norm"
                ),
                "contact_infinity_norm": validation.get(
                    "contact_infinity_norm"
                ),
                "torque_bound_violation": validation.get("torque_violation"),
                "friction_violation": validation.get("friction_violation"),
                "normal_force_lower_violation": validation.get(
                    "normal_force_lower_violation"
                ),
                "normal_force_upper_violation": validation.get(
                    "normal_force_upper_violation"
                ),
                "hard_inequality_violation": validation.get(
                    "hard_inequality_violation"
                ),
                "health_adapter_identity_error": validation.get(
                    "health_adapter_identity_error"
                ),
                "dynamics_residual_vector": validation.get(
                    "dynamics_residual"
                ),
                "contact_residual_vector": validation.get("contact_residual"),
            },
            "active_constraints": {
                "torque": validation.get("active_torque_constraints"),
                "friction": validation.get("active_friction_constraints"),
                "normal_lower": validation.get(
                    "active_normal_lower_constraints"
                ),
                "normal_upper": validation.get(
                    "active_normal_upper_constraints"
                ),
            },
        }
        records.append(record)

        dimensions = {
            "snapshot": item["snapshot_id"],
            "health_condition": item["health_id"],
            "task_demand": item["demand_id"],
            "qp_stage": stage,
        }
        for name, key in dimensions.items():
            occurrence_counts[name][key] += 1
            _increment_unique(unique_counts[name], key, case_id)
        for family in family_names:
            occurrence_counts["physical_constraint_family"][family] += 1
            _increment_unique(
                unique_counts["physical_constraint_family"], family, case_id
            )

    result = {
        "stage": "STEP-02R",
        "parent_run": "STEP02_FAIL",
        "disposition": "NUMERICAL_REVISION",
        "source_commits": {
            "implementation": "5b29626",
            "failed_run_artifacts": "ad640b9",
        },
        "source_artifacts": {
            "v1_root": V1_ROOT.as_posix(),
            "solver_diagnostics_sha256": _sha256(
                V1_ROOT / "solver_diagnostics.jsonl"
            ),
            "eq_summary_sha256": _sha256(V1_ROOT / "eq_summary.json"),
        },
        "frozen_thresholds": thresholds,
        "classification_legend": {
            "A": "primary-stage solver failure",
            "B": "secondary-stage primal infeasible",
            "C": "dynamics residual failure",
            "D": "contact residual failure",
            "E": "torque-bound violation",
            "F": "friction violation",
            "G": "normal-force lower violation",
            "H": "normal-force upper violation",
            "I": "health-adapter identity failure",
        },
        "scope": {
            "diagnostic_rows_examined": len(diagnostics),
            "total_v1_cases": summary["case_count"],
            "failed_unique_cases_across_all_v1_stages": len(failed_case_ids),
            "failed_case_stage_records": len(records),
        },
        "failure_counts": {
            "record_occurrences": {
                key: dict(value) for key, value in occurrence_counts.items()
            },
            "unique_cases": {
                dimension: {
                    key: len(case_ids) for key, case_ids in values.items()
                }
                for dimension, values in unique_counts.items()
            },
        },
        "failed_case_ids": sorted(failed_case_ids),
        "failed_case_stage_details": records,
        "interpretation_guard": (
            "Classifications use solver status plus independently recomputed "
            "original-unit residuals; solver status alone is not treated as cause."
        ),
    }
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(
        json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    print(
        json.dumps(
            {
                "output": OUTPUT.as_posix(),
                "failed_unique_cases": len(failed_case_ids),
                "failed_case_stage_records": len(records),
                "family_counts": result["failure_counts"][
                    "record_occurrences"
                ]["physical_constraint_family"],
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
