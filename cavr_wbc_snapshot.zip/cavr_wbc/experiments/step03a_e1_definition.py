"""Frozen E1 identity planning and append-only accounting.

This module deliberately contains no simulator, optimizer, or controller code.
It creates the 720-entry E1 identity manifest and records preparation/smoke
events in a tamper-evident append-only ledger.  A caller may supply an
independent evaluator callback for the bounded smoke harness; the runner never
imports an evaluator and never treats controller feasibility labels as input.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import sys
from typing import Any, Callable, Iterable, Mapping, Sequence


PROTOCOL_VERSION = "CAVR-WBC_STEP03A_E1_DEFINITION_IMPLEMENTATION_V1"
SOURCE_COMMIT = "de0b5b1ca39a3306cb4a68778324ee03354a6d5f"
JOINT_NAMES = (
    "FR_hip",
    "FR_thigh",
    "FR_calf",
    "RR_hip",
    "RR_thigh",
    "RR_calf",
    "FL_hip",
    "FL_thigh",
    "FL_calf",
    "RL_hip",
    "RL_thigh",
    "RL_calf",
)
HEALTH_LEVELS = (1.0, 0.75, 0.5, 0.25, 0.0)
STATE_CLASSES = ("healthy_balance", "near_capacity", "authored_infeasible")
TASK_DIRECTIONS = (
    "body_roll",
    "body_pitch",
    "com_height_forward_velocity_coupled",
    "attitude_lateral_velocity_coupled",
)
IDENTITY_COUNT = (
    len(JOINT_NAMES) * len(HEALTH_LEVELS) * len(STATE_CLASSES) * len(TASK_DIRECTIONS)
)
LEDGER_EVENTS = ("RESERVED", "FINISHED")
FINISH_STATUSES = {
    "PASS",
    "COMPLETED",
    "PHYSICAL_FAILURE",
    "NUMERICAL_MISMATCH",
    "SMOKE_PASS",
    "SMOKE_FAIL",
    "SMOKE_INTERFACE_ONLY",
    "NOT_RUN",
    "UNKNOWN",
    "INFEASIBLE",
    "STRUCTURAL_INVALID",
    "ERROR",
}


def _canonical(value: Any) -> str:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )


def _digest(value: Any) -> str:
    return hashlib.sha256(_canonical(value).encode("utf-8")).hexdigest()


def _sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _is_sha256(value: Any) -> bool:
    return (
        isinstance(value, str)
        and len(value) == 64
        and all(char in "0123456789abcdef" for char in value)
    )


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _health_token(value: float) -> str:
    # This representation is part of the identity key; it is never parsed as
    # a user-provided label after the manifest has been frozen.
    return format(float(value), ".12g")


def default_source_hash(source_commit: str = SOURCE_COMMIT) -> str:
    """Return a stable provenance digest for a source commit identifier."""

    if not isinstance(source_commit, str) or not source_commit:
        raise ValueError("source_commit must be a non-empty string")
    return hashlib.sha256(source_commit.encode("utf-8")).hexdigest()


def identity_seed(
    *,
    joint_name: str,
    health: float,
    state_class: str,
    task_direction: str,
    source_commit: str = SOURCE_COMMIT,
) -> int:
    """Derive a reproducible 64-bit seed without using Python's hash()."""

    payload = {
        "protocol_version": PROTOCOL_VERSION,
        "source_commit": source_commit,
        "joint_name": joint_name,
        "health": _health_token(health),
        "state_class": state_class,
        "task_direction": task_direction,
    }
    return int.from_bytes(
        hashlib.sha256(_canonical(payload).encode("utf-8")).digest()[:8],
        byteorder="big",
        signed=False,
    )


@dataclass(frozen=True)
class Identity:
    """One immutable row of the E1 scientific identity manifest."""

    ordinal: int
    identity_id: str
    joint_index: int
    joint_name: str
    health: float
    state_class: str
    task_direction: str
    seed: int
    attempt: int
    source_commit: str
    source_hash: str
    status: str = "NOT_RUN"

    def as_dict(self) -> dict[str, Any]:
        return {
            "ordinal": self.ordinal,
            "identity_id": self.identity_id,
            "joint_index": self.joint_index,
            "joint_name": self.joint_name,
            "health": self.health,
            "state_class": self.state_class,
            "task_direction": self.task_direction,
            "seed": self.seed,
            "attempt": self.attempt,
            "source_commit": self.source_commit,
            "source_hash": self.source_hash,
            "status": self.status,
        }


def build_identity_manifest(
    *, source_commit: str = SOURCE_COMMIT, source_hash: str | None = None
) -> list[dict[str, Any]]:
    """Build all 720 identities in a deterministic, documented order."""

    if not isinstance(source_commit, str) or not source_commit:
        raise ValueError("source_commit must be a non-empty string")
    source_hash = default_source_hash(source_commit) if source_hash is None else source_hash
    if not _is_sha256(source_hash):
        raise ValueError("source_hash must be a lowercase SHA256 digest")
    rows: list[dict[str, Any]] = []
    ordinal = 1
    for joint_index, joint_name in enumerate(JOINT_NAMES):
        for health in HEALTH_LEVELS:
            for state_class in STATE_CLASSES:
                for task_direction in TASK_DIRECTIONS:
                    row = Identity(
                        ordinal=ordinal,
                        identity_id=f"E1-{ordinal:04d}",
                        joint_index=joint_index,
                        joint_name=joint_name,
                        health=float(health),
                        state_class=state_class,
                        task_direction=task_direction,
                        seed=identity_seed(
                            joint_name=joint_name,
                            health=float(health),
                            state_class=state_class,
                            task_direction=task_direction,
                            source_commit=source_commit,
                        ),
                        attempt=1,
                        source_commit=source_commit,
                        source_hash=source_hash,
                    )
                    rows.append(row.as_dict())
                    ordinal += 1
    validate_manifest(rows)
    return rows


def validate_manifest(rows: Sequence[Mapping[str, Any]]) -> None:
    """Reject missing, duplicated, reordered, or altered identity rows."""

    if not isinstance(rows, Sequence) or isinstance(rows, (str, bytes)):
        raise ValueError("manifest must be a sequence of rows")
    if len(rows) != IDENTITY_COUNT:
        raise ValueError(f"manifest must contain exactly {IDENTITY_COUNT} identities")
    expected = {
        (joint_name, float(health), state_class, task_direction)
        for joint_name in JOINT_NAMES
        for health in HEALTH_LEVELS
        for state_class in STATE_CLASSES
        for task_direction in TASK_DIRECTIONS
    }
    seen: set[tuple[str, float, str, str]] = set()
    source_commit: str | None = None
    source_hash: str | None = None
    for ordinal, row in enumerate(rows, start=1):
        if not isinstance(row, Mapping):
            raise ValueError("manifest rows must be mappings")
        if row.get("ordinal") != ordinal or row.get("identity_id") != f"E1-{ordinal:04d}":
            raise ValueError("manifest ordinals or identity IDs are not contiguous")
        joint_index = row.get("joint_index")
        if type(joint_index) is not int or not 0 <= joint_index < len(JOINT_NAMES):
            raise ValueError("invalid joint_index")
        joint_name = row.get("joint_name")
        if joint_name != JOINT_NAMES[joint_index]:
            raise ValueError("joint index/name mismatch")
        health = row.get("health")
        if type(health) not in (int, float) or isinstance(health, bool):
            raise ValueError("health must be numeric")
        health = float(health)
        if not any(math.isclose(health, value, rel_tol=0.0, abs_tol=0.0) for value in HEALTH_LEVELS):
            raise ValueError("health is not a frozen health level")
        state_class = row.get("state_class")
        task_direction = row.get("task_direction")
        key = (joint_name, health, state_class, task_direction)
        if key not in expected or key in seen:
            raise ValueError("manifest identity is missing, unknown, or duplicated")
        seen.add(key)
        seed = row.get("seed")
        if type(seed) is not int or not 0 <= seed < 2**64:
            raise ValueError("seed must be an unsigned 64-bit integer")
        expected_seed = identity_seed(
            joint_name=joint_name,
            health=health,
            state_class=state_class,
            task_direction=task_direction,
            source_commit=row.get("source_commit"),
        )
        if seed != expected_seed:
            raise ValueError("identity seed does not match frozen identity fields")
        if row.get("attempt") != 1 or row.get("status") != "NOT_RUN":
            raise ValueError("preparation manifest rows must be attempt 1/NOT_RUN")
        row_source_commit = row.get("source_commit")
        row_source_hash = row.get("source_hash")
        if not isinstance(row_source_commit, str) or not row_source_commit:
            raise ValueError("source_commit is required")
        if not _is_sha256(row_source_hash):
            raise ValueError("source_hash must be a lowercase SHA256 digest")
        if row_source_hash != default_source_hash(row_source_commit):
            raise ValueError("source_hash does not match source_commit")
        if source_commit is None:
            source_commit, source_hash = row_source_commit, row_source_hash
        elif row_source_commit != source_commit or row_source_hash != source_hash:
            raise ValueError("manifest source provenance is inconsistent")
    if seen != expected:
        raise ValueError("manifest does not cover the complete Cartesian product")


def manifest_bytes(rows: Sequence[Mapping[str, Any]]) -> bytes:
    validate_manifest(rows)
    return b"".join((_canonical(dict(row)).encode("utf-8") + b"\n") for row in rows)


def manifest_hash(rows: Sequence[Mapping[str, Any]]) -> str:
    return _sha256_bytes(manifest_bytes(rows))


def write_identity_manifest(path: str | Path, rows: Sequence[Mapping[str, Any]]) -> str:
    """Write once; a second identical write is accepted, a changed write fails."""

    payload = manifest_bytes(rows)
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        if target.read_bytes() != payload:
            raise ValueError("existing identity manifest differs; refusing overwrite")
        return _sha256_bytes(payload)
    with target.open("xb") as stream:
        stream.write(payload)
        stream.flush()
        os.fsync(stream.fileno())
    return _sha256_bytes(payload)


def load_identity_manifest(path: str | Path) -> list[dict[str, Any]]:
    target = Path(path)
    raw = target.read_bytes()
    if raw and not raw.endswith(b"\n"):
        raise ValueError("identity manifest is truncated")
    rows = [json.loads(line) for line in raw.decode("utf-8").splitlines() if line]
    validate_manifest(rows)
    return rows


def identity_payload(row: Mapping[str, Any]) -> dict[str, Any]:
    """Return the public identity payload passed to an optional evaluator."""

    required = (
        "identity_id",
        "ordinal",
        "joint_index",
        "joint_name",
        "health",
        "state_class",
        "task_direction",
        "seed",
        "attempt",
        "source_hash",
    )
    missing = [key for key in required if key not in row]
    if missing:
        raise ValueError(f"identity row is missing fields: {missing}")
    payload = {key: row[key] for key in required}
    # These are intentionally the only keys available to an evaluator smoke
    # callback.  In particular no feasible/status/solver field is forwarded.
    return payload


class AppendOnlyIdentityLedger:
    """Hash-chained reservations and finishes for frozen identities."""

    def __init__(
        self,
        path: str | Path,
        manifest: Sequence[Mapping[str, Any]],
        *,
        run_id: str,
        source_hash: str,
    ) -> None:
        validate_manifest(manifest)
        if not isinstance(run_id, str) or not run_id.strip():
            raise ValueError("run_id must be a non-empty string")
        if not _is_sha256(source_hash):
            raise ValueError("source_hash must be a lowercase SHA256 digest")
        expected_sources = {row["source_hash"] for row in manifest}
        if expected_sources != {source_hash}:
            raise ValueError("ledger source_hash does not match manifest")
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.run_id = run_id
        self.source_hash = source_hash
        self.manifest_hash = manifest_hash(manifest)
        self._manifest = {row["identity_id"]: dict(row) for row in manifest}
        self.verify()

    def _read_rows(self) -> list[dict[str, Any]]:
        if not self.path.exists():
            return []
        raw = self.path.read_bytes()
        if raw and not raw.endswith(b"\n"):
            raise ValueError("ledger is truncated")
        try:
            rows = [json.loads(line) for line in raw.decode("utf-8").splitlines() if line]
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("ledger contains invalid JSON") from exc
        return rows

    @staticmethod
    def _row_hash(row: Mapping[str, Any]) -> str:
        return _digest({key: value for key, value in row.items() if key != "hash"})

    def verify(self) -> list[dict[str, Any]]:
        rows = self._read_rows()
        previous_hash = "0" * 64
        reserved: set[str] = set()
        finished: set[str] = set()
        for sequence, row in enumerate(rows, start=1):
            if row.get("sequence") != sequence:
                raise ValueError("ledger sequence mismatch")
            if row.get("previous_hash") != previous_hash:
                raise ValueError("ledger previous_hash mismatch")
            if row.get("hash") != self._row_hash(row):
                raise ValueError("ledger hash chain mismatch")
            if row.get("event") not in LEDGER_EVENTS:
                raise ValueError("unknown ledger event")
            identity_id = row.get("identity_id")
            if identity_id not in self._manifest:
                raise ValueError("ledger identity is not in the frozen manifest")
            metadata = row.get("metadata")
            if not isinstance(metadata, Mapping):
                raise ValueError("ledger metadata must be an object")
            if metadata.get("run_id") != self.run_id:
                raise ValueError("ledger run_id mismatch")
            if metadata.get("manifest_hash") != self.manifest_hash:
                raise ValueError("ledger manifest_hash mismatch")
            if metadata.get("source_hash") != self.source_hash:
                raise ValueError("ledger source_hash mismatch")
            expected_identity_hash = _digest(self._manifest[identity_id])
            if metadata.get("identity_hash") != expected_identity_hash:
                raise ValueError("ledger identity hash mismatch")
            event = row["event"]
            if event == "RESERVED":
                if identity_id in reserved:
                    raise ValueError("identity reserved more than once")
                if identity_id in finished:
                    raise ValueError("identity reserved after finish")
                reserved.add(identity_id)
            else:
                if identity_id not in reserved:
                    raise ValueError("finish without reservation")
                if identity_id in finished:
                    raise ValueError("identity finished more than once")
                status = metadata.get("status")
                if status not in FINISH_STATUSES:
                    raise ValueError("unknown finish status")
                finished.add(identity_id)
            previous_hash = row["hash"]
        return rows

    def _append(self, event: str, identity_id: str, **metadata: Any) -> dict[str, Any]:
        if event not in LEDGER_EVENTS:
            raise ValueError("unknown ledger event")
        rows = self.verify()
        identity = self._manifest.get(identity_id)
        if identity is None:
            raise ValueError("identity is not in the frozen manifest")
        base = {
            "sequence": len(rows) + 1,
            "previous_hash": rows[-1]["hash"] if rows else "0" * 64,
            "event": event,
            "identity_id": identity_id,
            "utc": _utc_now(),
            "metadata": {
                **metadata,
                "run_id": self.run_id,
                "manifest_hash": self.manifest_hash,
                "source_hash": self.source_hash,
                "identity_hash": _digest(identity),
            },
        }
        base["hash"] = self._row_hash(base)
        with self.path.open("a", encoding="utf-8", newline="\n") as stream:
            stream.write(_canonical(base) + "\n")
            stream.flush()
            os.fsync(stream.fileno())
        return base

    def reserve(self, identity_id: str) -> dict[str, Any]:
        rows = self.verify()
        if any(row["identity_id"] == identity_id for row in rows):
            raise ValueError("identity already consumed; no retry")
        return self._append("RESERVED", identity_id, attempt=1)

    def finish(
        self,
        identity_id: str,
        *,
        status: str,
        physical_steps: int = 0,
        output_hash: str | None = None,
        error: str | None = None,
    ) -> dict[str, Any]:
        if status not in FINISH_STATUSES:
            raise ValueError("unknown finish status")
        if type(physical_steps) is not int or physical_steps < 0:
            raise ValueError("physical_steps must be a non-negative integer")
        rows = self.verify()
        events = [row for row in rows if row["identity_id"] == identity_id]
        if not events or events[-1]["event"] != "RESERVED":
            raise ValueError("finish requires one pending reservation")
        if output_hash is not None and not _is_sha256(output_hash):
            raise ValueError("output_hash must be a lowercase SHA256 digest")
        if error is not None and not isinstance(error, str):
            raise ValueError("error must be a string or None")
        return self._append(
            "FINISHED",
            identity_id,
            attempt=1,
            status=status,
            physical_steps=physical_steps,
            output_hash=output_hash,
            error=error,
        )

    def accounting(self) -> dict[str, Any]:
        rows = self.verify()
        reserved = sum(row["event"] == "RESERVED" for row in rows)
        finished = sum(row["event"] == "FINISHED" for row in rows)
        return {
            "manifest_count": len(self._manifest),
            "reserved": reserved,
            "finished": finished,
            "pending": reserved - finished,
            "ledger_events": len(rows),
            "last_hash": rows[-1]["hash"] if rows else "0" * 64,
        }


EvaluatorCallback = Callable[[Mapping[str, Any], int], Mapping[str, Any]]


def run_smoke(
    output_dir: str | Path,
    *,
    identity_count: int = 3,
    physical_steps: int = 2,
    evaluator: EvaluatorCallback | None = None,
    run_id: str = "step03a-smoke",
) -> dict[str, Any]:
    """Run a bounded ledger/evaluator smoke without any solver call.

    The default path is interface-only and records ``SMOKE_INTERFACE_ONLY``;
    it does not claim that physical replay occurred.  A supplied evaluator is
    called with a public identity payload and a step budget no greater than two.
    """

    if type(identity_count) is not int or not 1 <= identity_count <= 3:
        raise ValueError("identity_count must be between 1 and 3")
    if type(physical_steps) is not int or not 0 <= physical_steps <= 2:
        raise ValueError("physical_steps must be between 0 and 2")
    root = Path(output_dir)
    root.mkdir(parents=True, exist_ok=True)
    manifest_path = root / "E1_IDENTITY_MANIFEST.jsonl"
    rows = build_identity_manifest()
    write_identity_manifest(manifest_path, rows)
    ledger_path = root / "E1_ATTEMPT_LEDGER.jsonl"
    ledger = AppendOnlyIdentityLedger(
        ledger_path,
        rows,
        run_id=run_id,
        source_hash=rows[0]["source_hash"],
    )
    results: list[dict[str, Any]] = []
    for row in rows[:identity_count]:
        identity_id = row["identity_id"]
        reservation = ledger.reserve(identity_id)
        payload = identity_payload(row)
        if evaluator is None:
            result: Mapping[str, Any] = {
                "status": "SMOKE_INTERFACE_ONLY",
                "physical_steps": 0,
                "note": "No evaluator supplied; no physical replay was run",
            }
        else:
            result = evaluator(payload, physical_steps)
            if not isinstance(result, Mapping):
                raise ValueError("evaluator callback must return a mapping")
            if "feasible" in result or "solver_status" in result:
                raise ValueError("evaluator result exposes forbidden controller labels")
        status = str(result.get("status", "SMOKE_FAIL"))
        steps = result.get("physical_steps", 0)
        output_hash = result.get("output_hash")
        error = result.get("error")
        finish = ledger.finish(
            identity_id,
            status=status,
            physical_steps=steps,
            output_hash=output_hash,
            error=error,
        )
        results.append(
            {
                "identity_id": identity_id,
                "reservation_hash": reservation["hash"],
                "finish_hash": finish["hash"],
                "status": status,
                "physical_steps": steps,
            }
        )
    return {
        "protocol_version": PROTOCOL_VERSION,
        "run_id": run_id,
        "manifest_path": str(manifest_path),
        "ledger_path": str(ledger_path),
        "manifest_hash": manifest_hash(rows),
        "identity_count": identity_count,
        "physical_steps_limit": physical_steps,
        "evaluator_supplied": evaluator is not None,
        "results": results,
        "accounting": ledger.accounting(),
        "solver_calls": 0,
        "optimizer_calls": 0,
    }


def _load_json_spec(path: Path) -> Mapping[str, Any]:
    if not path.exists():
        raise ValueError(f"missing frozen definition spec: {path}")
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, Mapping):
        raise ValueError(f"definition spec must be an object: {path}")
    return value


def _state_qvel(model: Any, state_class: str, state_spec: Mapping[str, Any]) -> Any:
    """Build qvel from the frozen scenario spec without inspecting results."""

    import numpy as np

    values = np.zeros(model.nv, dtype=float)
    scenarios = state_spec.get("state_classes", ())
    scenario = next((item for item in scenarios if item.get("id") == state_class), None)
    if scenario is None:
        raise ValueError(f"state class missing from frozen spec: {state_class}")
    qvel = scenario.get("qvel", {})
    if qvel == "zeros":
        return values
    if not isinstance(qvel, Mapping):
        raise ValueError("state qvel definition must be zeros or an object")
    # MuJoCo free-joint qvel order is linear xyz followed by angular xyz.
    if "base_forward_mps" in qvel:
        values[0] = float(qvel["base_forward_mps"])
    for index, value in qvel.get("components", {}).items():
        index = int(index)
        if index < 0 or index >= model.nv:
            raise ValueError("state qvel component is outside model.nv")
        values[index] = float(value)
    if not np.isfinite(values).all():
        raise ValueError("state qvel contains non-finite values")
    return values


def _task_callback_for_direction(direction_row: Mapping[str, Any]) -> Callable[[Any, Any], dict[str, float]]:
    """Return a public-state task callback for one frozen direction."""

    from cavr_wbc.evaluation.e1_metrics import task_components_from_data, task_direction_value

    coefficients = direction_row.get("coefficients")
    if not isinstance(coefficients, Mapping) or not coefficients:
        raise ValueError("task direction coefficients are missing")

    def callback(model: Any, data: Any) -> dict[str, float]:
        values = task_components_from_data(model, data)
        values["direction_value"] = task_direction_value(values, coefficients)
        return values

    return callback


def _frozen_direction_specs(root: Path) -> dict[str, Mapping[str, Any]]:
    spec = _load_json_spec(root / "TASK_DIRECTION_SPEC.json")
    rows = spec.get("directions")
    if not isinstance(rows, Sequence):
        raise ValueError("TASK_DIRECTION_SPEC directions must be a list")
    result = {str(row.get("id")): row for row in rows if isinstance(row, Mapping)}
    missing = set(TASK_DIRECTIONS) - set(result)
    if missing:
        raise ValueError(f"task direction spec missing: {sorted(missing)}")
    return result


def _write_csv_once(path: Path, fieldnames: Sequence[str], rows: Iterable[Mapping[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise ValueError(f"refusing to overwrite existing execution artifact: {path}")
    with path.open("x", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
        stream.flush()
        os.fsync(stream.fileno())


def run_e1(
    output_dir: str | Path,
    *,
    start_ordinal: int = 1,
    end_ordinal: int = IDENTITY_COUNT,
    run_id: str = "step03a-e1-full",
    allow_execution: bool = False,
) -> dict[str, Any]:
    """Execute a bounded or full E1 replay through the independent evaluator.

    ``allow_execution`` is an explicit guard.  Without it the function only
    validates the requested range and raises before loading MuJoCo.  The full
    720 identity panel therefore cannot start accidentally from a preparation
    command.  The caller owns the authorization decision and output directory.
    """

    if type(start_ordinal) is not int or type(end_ordinal) is not int:
        raise ValueError("ordinal bounds must be integers")
    if not 1 <= start_ordinal <= end_ordinal <= IDENTITY_COUNT:
        raise ValueError("ordinal range is outside the frozen 720 identities")
    if not allow_execution:
        raise PermissionError("E1 execution requires allow_execution=True")

    # Lazy imports keep manifest/ledger tests independent of MuJoCo and solver
    # packages.  This path only uses fresh MuJoCo integration; no optimizer or
    # controller module is imported.
    import mujoco
    import numpy as np
    from cavr_wbc.evaluation.e1_independent_dynamics import IndependentDynamicsEvaluator
    from cavr_wbc.evaluation.e1_metrics import compute_step_metrics
    from cavr_wbc.platforms.go2_mujoco import (
        extract_actuator_joint_map,
        extract_healthy_torque_limits,
        load_go2_model,
    )

    root = Path(output_dir)
    root.mkdir(parents=True, exist_ok=True)
    rows = load_identity_manifest(root / "E1_IDENTITY_MANIFEST.jsonl")
    state_spec = _load_json_spec(root / "STATE_SCENARIO_SPEC.json")
    direction_specs = _frozen_direction_specs(root)
    selected = rows[start_ordinal - 1 : end_ordinal]
    model = load_go2_model()
    data = mujoco.MjData(model)
    home_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_KEY, "home")
    if home_id < 0:
        raise ValueError("Go2 model does not contain official home keyframe")
    mujoco.mj_resetDataKeyframe(model, data, home_id)
    home_qpos = data.qpos.copy()
    limits = np.asarray(extract_healthy_torque_limits(model), dtype=float)
    if limits.shape != (model.nu,):
        raise ValueError("healthy torque limit count does not match model.nu")
    actuator_map = extract_actuator_joint_map(model)
    evaluator = IndependentDynamicsEvaluator()
    ledger = AppendOnlyIdentityLedger(
        root / "E1_ATTEMPT_LEDGER.jsonl",
        rows,
        run_id=run_id,
        source_hash=rows[0]["source_hash"],
    )
    actuator_records: list[dict[str, Any]] = []
    replay_records: list[dict[str, Any]] = []
    result_rows: list[dict[str, Any]] = []
    for row in selected:
        identity_id = row["identity_id"]
        reservation = ledger.reserve(identity_id)
        status = "COMPLETED"
        error: str | None = None
        physical_steps = 0
        try:
            qvel = _state_qvel(model, row["state_class"], state_spec)
            rho = np.ones(model.nu, dtype=float)
            rho[int(row["joint_index"])] = float(row["health"])
            raw_command = np.zeros(model.nu, dtype=float)
            sign = 1.0 if int(row["seed"]) % 2 else -1.0
            raw_command[int(row["joint_index"])] = sign * 0.5 * limits[int(row["joint_index"])]
            applied_command = np.clip(raw_command, -rho * limits, rho * limits)
            direction_callback = _task_callback_for_direction(direction_specs[row["task_direction"]])
            replay = evaluator.replay(
                home_qpos,
                qvel,
                (applied_command, applied_command),
                rho,
                step_index=int(row["ordinal"]) * 2,
                task_callback=direction_callback,
            )
            physical_steps = replay.steps_requested
            metric_rows: list[dict[str, Any]] = []
            for step_index, state in enumerate(replay.states):
                metric = compute_step_metrics(evaluator.model, state)
                metric_row = {
                    "identity_id": identity_id,
                    "ordinal": row["ordinal"],
                    "step_index": step_index,
                    "state_class": row["state_class"],
                    "task_direction": row["task_direction"],
                    "direction_value": state.task_values.get("direction_value"),
                    "task_values_json": _canonical(dict(state.task_values)),
                    "model_source_hash": state.model_source_hash,
                    "input_hash": state.input_hash,
                    **metric,
                }
                metric_rows.append(metric_row)
                replay_records.append(metric_row)
                for actuator_index in range(model.nu):
                    actuator_records.append(
                        {
                            "identity_id": identity_id,
                            "ordinal": row["ordinal"],
                            "step_index": step_index,
                            "joint_index": actuator_index,
                            "joint_name": actuator_map[actuator_index].joint_name,
                            "health": float(rho[actuator_index]),
                            "raw_command_nm": float(raw_command[actuator_index]),
                            "applied_command_nm": float(applied_command[actuator_index]),
                            "ctrl_written_nm": float(state.ctrl_written[actuator_index]),
                            "actuator_force_nm": float(state.actuator_force[actuator_index]),
                            "generalized_torque_nm": float(state.generalized_torque[actuator_index]),
                            "model_source_hash": state.model_source_hash,
                        }
                    )
            statuses = {str(item["status"]) for item in metric_rows}
            if "STRUCTURAL_INVALID" in statuses:
                status = "STRUCTURAL_INVALID"
            elif "PHYSICAL_FAILURE" in statuses:
                status = "PHYSICAL_FAILURE"
            elif "NUMERICAL_MISMATCH" in statuses:
                status = "NUMERICAL_MISMATCH"
            else:
                status = "PASS"
            output_hash = _digest({"states": [state.as_dict() for state in replay.states], "metrics": metric_rows})
            ledger.finish(identity_id, status=status, physical_steps=physical_steps, output_hash=output_hash)
            result_rows.append({**row, "result_status": status, "physical_steps": physical_steps, "output_hash": output_hash})
        except Exception as exc:  # retain the failure and continue other identities
            status = "STRUCTURAL_INVALID" if isinstance(exc, (KeyError, ValueError)) else "ERROR"
            error = f"{type(exc).__name__}: {exc}"
            ledger.finish(identity_id, status=status, physical_steps=physical_steps, error=error)
            result_rows.append({**row, "result_status": status, "physical_steps": physical_steps, "error": error})

    _write_csv_once(
        root / "E1_ACTUATOR_PATH.csv",
        (
            "identity_id", "ordinal", "step_index", "joint_index", "joint_name", "health",
            "raw_command_nm", "applied_command_nm", "ctrl_written_nm", "actuator_force_nm",
            "generalized_torque_nm", "model_source_hash",
        ),
        actuator_records,
    )
    _write_csv_once(
        root / "E1_PHYSICAL_REPLAY.csv",
        ("identity_id", "ordinal", "step_index", "state_class", "task_direction",
         "direction_value", "task_values_json", "model_source_hash", "input_hash", "status",
         "structural_ok", "physical_failure", "qacc_error_inf", "torque_violation_inf_nm",
         "minimum_friction_margin_n", "maximum_tangential_speed_m_s", "minimum_normal_force_n",
         "contact_count", "controller_feasibility_labels_consumed"),
        replay_records,
    )
    completed = len(result_rows)
    strict_pass = sum(row.get("result_status") == "PASS" for row in result_rows)
    structural_invalid = sum(
        row.get("result_status") == "STRUCTURAL_INVALID" for row in result_rows
    )
    # E1's preparation gate is structural.  Ordinary physical failures are
    # scientific observations and must not be relabeled as a blocked gate.
    if completed < IDENTITY_COUNT:
        execution_status = "INCOMPLETE"
    elif structural_invalid:
        execution_status = "BLOCKED"
    else:
        execution_status = "PASS"
    result = {
        "protocol_version": PROTOCOL_VERSION,
        "status": execution_status,
        "identities_attempted": completed,
        "identities_required": IDENTITY_COUNT,
        "identities_strict_pass": strict_pass,
        "identities_structural_invalid": structural_invalid,
        "start_ordinal": start_ordinal,
        "end_ordinal": end_ordinal,
        "physical_steps": sum(int(row.get("physical_steps", 0)) for row in result_rows),
        "solver_calls": 0,
        "optimizer_calls": 0,
        "retries": 0,
        "e2b_executed": False,
        "result_rows": result_rows,
        "ledger": ledger.accounting(),
    }
    result_path = root / "E1_RESULT.json"
    if result_path.exists():
        raise ValueError(f"refusing to overwrite existing execution artifact: {result_path}")
    result_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    report_path = root / "E1_REPORT.md"
    if report_path.exists():
        raise ValueError(f"refusing to overwrite existing execution artifact: {report_path}")
    report_path.write_text(
        "# E1 independent physical replay\n\n"
        f"- Status: **{result['status']}**\n"
        f"- Identities: {completed}/{IDENTITY_COUNT}; strict pass: {strict_pass}\n"
        f"- Structural invalid identities: {structural_invalid}\n"
        f"- Physical steps: {result['physical_steps']}\n"
        "- Solver calls: 0; optimizer calls: 0; retries: 0\n"
        "- Controller feasibility labels consumed: false\n"
        "- E2-B: NOT RUN\n\n"
        "The E1 status is a structural execution gate; ordinary physical and numerical failures are retained as observations.\n",
        encoding="utf-8",
    )
    return result


def write_ledger_schema(path: str | Path) -> None:
    schema = {
        "protocol_version": PROTOCOL_VERSION,
        "format": "JSONL",
        "append_only": True,
        "hash": "sha256(canonical_row_without_hash)",
        "chain": "previous_hash starts at 64 zeroes",
        "events": {
            "RESERVED": ["sequence", "previous_hash", "event", "identity_id", "utc", "metadata", "hash"],
            "FINISHED": ["sequence", "previous_hash", "event", "identity_id", "utc", "metadata", "hash"],
        },
        "metadata_required": [
            "run_id",
            "manifest_hash",
            "source_hash",
            "identity_hash",
            "attempt",
        ],
        "finish_metadata": ["status", "physical_steps", "output_hash", "error"],
        "no_retry": True,
    }
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = (_canonical(schema) + "\n").encode("utf-8")
    if target.exists() and target.read_bytes() != payload:
        raise ValueError("existing ledger schema differs; refusing overwrite")
    if not target.exists():
        with target.open("xb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())


def write_preparation_artifacts(output_dir: str | Path) -> dict[str, Any]:
    """Create the manifest and schema used by the preparation gate."""

    root = Path(output_dir)
    root.mkdir(parents=True, exist_ok=True)
    rows = build_identity_manifest()
    identity_path = root / "E1_IDENTITY_MANIFEST.jsonl"
    digest = write_identity_manifest(identity_path, rows)
    write_ledger_schema(root / "E1_LEDGER_SCHEMA.json")
    return {
        "protocol_version": PROTOCOL_VERSION,
        "source_commit": SOURCE_COMMIT,
        "source_hash": rows[0]["source_hash"],
        "identity_count": len(rows),
        "manifest_sha256": digest,
        "ledger_schema": str(root / "E1_LEDGER_SCHEMA.json"),
        "execution": "NOT_RUN",
        "solver_calls": 0,
        "optimizer_calls": 0,
    }


def _default_output_dir() -> Path:
    return Path("artifacts") / "step03a_e1_definition_implementation"


def main(argv: Sequence[str] | None = None) -> int:
    import argparse

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "command", choices=("prepare", "validate", "smoke", "execute"), nargs="?", default="prepare"
    )
    parser.add_argument("--output", type=Path, default=_default_output_dir())
    parser.add_argument("--identity-count", type=int, default=3)
    parser.add_argument("--physical-steps", type=int, default=2)
    parser.add_argument("--start-ordinal", type=int, default=1)
    parser.add_argument("--end-ordinal", type=int, default=IDENTITY_COUNT)
    args = parser.parse_args(argv)
    if args.command == "prepare":
        result = write_preparation_artifacts(args.output)
    elif args.command == "validate":
        rows = load_identity_manifest(args.output / "E1_IDENTITY_MANIFEST.jsonl")
        result = {"valid": True, "identity_count": len(rows), "manifest_hash": manifest_hash(rows)}
    elif args.command == "smoke":
        result = run_smoke(
            args.output,
            identity_count=args.identity_count,
            physical_steps=args.physical_steps,
        )
    else:
        result = run_e1(
            args.output,
            start_ordinal=args.start_ordinal,
            end_ordinal=args.end_ordinal,
            allow_execution=True,
        )
    print(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2))
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
