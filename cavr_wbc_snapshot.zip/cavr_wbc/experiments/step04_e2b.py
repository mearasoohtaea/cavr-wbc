"""E2-B quadruped mechanism DEV runner.

This module intentionally keeps the five controllers in one deterministic
dynamic MuJoCo experiment.  It is a mechanism-development panel (not a
formal statistical panel): every controller receives the same frozen scenario
and the independent evaluator only consumes public simulator state.
"""
from __future__ import annotations

import argparse, csv, hashlib, json, math, os, platform, shutil, sys, time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

import mujoco
import numpy as np
import yaml
try:
    # MuJoCo 3.x exposes the batched C rollout extension as a submodule.  It
    # is intentionally imported through the submodule (``mujoco.rollout`` is
    # not installed as a top-level attribute in all wheels), so the runtime
    # path is explicit and easy to audit.  Older wheels use the deterministic
    # Python fallback below.
    from mujoco.rollout import rollout as _mujoco_rollout
except Exception:  # pragma: no cover - exercised only on old MuJoCo wheels
    _mujoco_rollout = None
from cavr_wbc.control.e2b_dynamic import DynamicWBC
from cavr_wbc.control.native_p1_mujoco import native_p1_from_env
from cavr_wbc.evaluation.e2b_physical import evaluate as independent_evaluate
from cavr_wbc.platforms.go2_mujoco import FOOT_NAMES, extract_healthy_torque_limits

ROOT = Path(__file__).resolve().parents[2]
MODEL_REL = Path("third_party/unitree_mujoco_snapshot/unitree_robots/go2/scene.xml")
METHODS = ("B1", "B2", "B3", "P0", "P1")
LAYERS = ("R1", "R2", "R3")
HEALTH_LEVELS = (0.75, 0.50, 0.25, 0.0)
ACTUATOR_NAMES = ("FR_hip", "FR_thigh", "FR_calf", "FL_hip", "FL_thigh", "FL_calf", "RR_hip", "RR_thigh", "RR_calf", "RL_hip", "RL_thigh", "RL_calf")
FR_THIGH = 1
HOME = np.array([0.0, 0.9, -1.8, 0.0, 0.9, -1.8, 0.0, 0.9, -1.8, 0.0, 0.9, -1.8], float)


def canon(x: Any) -> str:
    return json.dumps(x, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha(x: Any) -> str:
    if isinstance(x, (str, bytes)):
        b = x.encode() if isinstance(x, str) else x
    else:
        b = canon(x).encode()
    return hashlib.sha256(b).hexdigest()


def euler_from_quat(q: np.ndarray) -> tuple[float, float, float]:
    w, x, y, z = map(float, q)
    roll = math.atan2(2*(w*x+y*z), 1-2*(x*x+y*y))
    s = max(-1.0, min(1.0, 2*(w*y-z*x)))
    pitch = math.asin(s)
    yaw = math.atan2(2*(w*z+x*y), 1-2*(y*y+z*z))
    return roll, pitch, yaw


def write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")


def load_model() -> mujoco.MjModel:
    return mujoco.MjModel.from_xml_path(MODEL_REL.as_posix())


def model_audit(m: mujoco.MjModel) -> dict[str, Any]:
    names = [mujoco.mj_id2name(m, mujoco.mjtObj.mjOBJ_ACTUATOR, i) for i in range(m.nu)]
    limits = m.actuator_ctrlrange.astype(float).tolist()
    return {"model_relpath": MODEL_REL.as_posix(), "model_sha256": sha(MODEL_REL.read_bytes()), "nq": int(m.nq), "nv": int(m.nv), "nu": int(m.nu), "actuator_names": names, "actuator_order": ACTUATOR_NAMES, "ctrlrange_Nm": limits, "units": "N*m", "FR_thigh_index": FR_THIGH}


@dataclass(frozen=True)
class Scenario:
    scenario_id: str
    paired: bool
    seed: int
    speed: str
    speed_mps: float
    health: float
    layer: str
    fault_onset_s: float | None
    initial_pitch: float
    initial_roll: float
    disturbance_force: tuple[float, float, float]
    contact_template: str = "four_point_go2_home"


def build_scenarios() -> list[Scenario]:
    out: list[Scenario] = []
    for speed in ("low", "medium"):
        vm = 0.20 if speed == "low" else 0.40
        for health in HEALTH_LEVELS:
            for rep in range(10):
                seed = 20260920 + (0 if speed == "low" else 1000) + int(round((0.75-health)*100)) * 10 + rep
                rng = np.random.default_rng(seed)
                if health >= 0.50 and rep < 7:
                    layer = "R1"
                elif health == 0.0:
                    layer = "R3"
                else:
                    layer = "R2"
                onset = float(rng.uniform(2.0, 6.0))
                out.append(Scenario(f"F_{speed}_h{health:.2f}_{rep:02d}", True, seed, speed, vm, health, layer, onset, float(rng.uniform(-0.03,0.03)), float(rng.uniform(-0.03,0.03)), tuple(map(float, rng.normal(0, [1.5, 1.0, 2.0])))))
    for rep in range(10):
        seed = 30260920 + rep; rng = np.random.default_rng(seed)
        out.append(Scenario(f"H_control_{rep:02d}", False, seed, "low" if rep < 5 else "medium", 0.20 if rep < 5 else 0.40, 1.0, "R1", None, float(rng.uniform(-0.03,0.03)), float(rng.uniform(-0.03,0.03)), tuple(map(float, rng.normal(0, [1.5, 1.0, 2.0])))))
    return out


class Controller:
    def __init__(self, method: str, health: float, speed_mps: float):
        self.method, self.health, self.speed_mps = method, health, speed_mps
        self.calls = 0

    def nominal(self, q: np.ndarray, v: np.ndarray, t: float) -> np.ndarray:
        self.calls += 1
        kp, kd = 38.0, 1.8
        target = HOME.copy()
        # Forward-velocity task in the same original task contract.
        target[[1, 4, 7, 10]] += 0.10 * self.speed_mps * math.sin(min(t, 2.0))
        err = target - q
        if self.method == "B2":  # frozen hierarchical task degradation
            err[[1,4,7,10]] *= (0.75 + 0.25 * max(self.health, 0.0))
            tau = 45.0 * err - 2.2 * v
        elif self.method == "B3":  # one fixed predictive reference-governor step
            pred = q + 0.02 * v
            tau = 36.0 * (target - pred) - 1.7 * v
        elif self.method == "P0" or self.method == "P1":
            tau = 40.0 * err - 1.9 * v
        else:  # B1 soft WBC
            tau = 38.0 * err - 1.8 * v
        return tau

    def command(self, q: np.ndarray, v: np.ndarray, t: float) -> np.ndarray:
        tau = self.nominal(q, v, t)
        # One and only one health cap; independent physical evaluator rechecks it.
        lo = np.array([-23.7, -23.7, -45.43] * 4)
        hi = -lo
        if t >= 0 and self.health < 1.0:
            lo[FR_THIGH] *= self.health; hi[FR_THIGH] *= self.health
        return np.clip(tau, lo, hi)


def task_metrics(d: mujoco.MjData, target_v: float) -> dict[str, float]:
    roll, pitch, _ = euler_from_quat(d.qpos[3:7]); v = np.asarray(d.qvel, float)
    return {"roll": roll, "pitch": pitch, "height": float(d.qpos[2]), "forward_velocity": float(d.qvel[0]), "task_error": float(abs(d.qvel[0]-target_v) + abs(roll) + abs(pitch) + abs(d.qpos[2]-0.27))}


def interval_backup(
    m: mujoco.MjModel,
    d: mujoco.MjData,
    sc: Scenario,
    method: str,
    sim_time: float,
    backup_index: int,
    *,
    controller: DynamicWBC | None = None,
) -> dict[str, Any]:
    """Validate one P1 submission over the complete frozen [0, Delta] interval.

    A previous implementation evaluated the same ``MjData`` 21 times.  That
    was only a repeated snapshot and could not certify a backup arriving while
    the plant was moving.  Here the submission is held fixed while one cloned
    state is propagated monotonically from the arrival state to ``Delta``.
    Every checkpoint is passed through the public-state evaluator, including
    contacts, friction, actuator output and terminal-set membership.  The
    resulting event keeps a single backup id across all points, making the
    interval evidence auditable without a 21x repeated rollout.
    """
    delta = 1.0
    samples = np.linspace(0.0, delta, 21)
    health_vec = np.ones(m.nu, dtype=float)
    health_vec[FR_THIGH] = float(sc.health)
    target = {
        "com_velocity": sc.speed_mps,
        "com_height": 0.27,
        "roll": 0.0,
        "pitch": 0.0,
    }

    # P1 uses the same deterministic P0 submission command at the beginning
    # of the interval.  It is intentionally one submission, not 21 hidden
    # controller calls; each cloned plant then receives exactly that command.
    # Reuse the episode controller when supplied.  This is important for the
    # repair path: P1 must participate in the same persistent OSQP/warm-start
    # ledger as the online command, rather than silently constructing a fresh
    # solver for every backup event.  The optional argument preserves the
    # stand-alone helper interface used by smoke/unit tests.
    ctrl = controller if controller is not None else DynamicWBC(m)
    solve_target = {
        "desired_base_accel": [0.0] * 6,
        "desired_joint_accel": [0.0] * m.nu,
        "task_weights": [1.0] * (6 + m.nu),
        **target,
    }
    # Allocate the identity before the one online submission so the solver
    # ledger rows generated for this backup can carry the same audit key as
    # arrival, interval and terminal evidence.
    bid = f"{sc.scenario_id}-{method}-backup-{backup_index:04d}"
    ledger_start = len(ctrl.solver_ledger)
    # P1's realtime submission is the P0 dynamic solve with the P1 interval
    # contract layered on top; the controller itself exposes B1/B2/B3/P0.
    out = ctrl.compute(d, "P0", health_vec, solve_target)
    for ledger_row in ctrl.solver_ledger[ledger_start:]:
        ledger_row["backup_id"] = bid
    tau = np.asarray(out["tau"], dtype=float) if out.get("success", False) and out.get("tau") is not None else np.zeros(m.nu, dtype=float)

    evaluator_cfg = {
        "task": {"roll_limit_rad": 0.55, "pitch_limit_rad": 0.55, "com_height_min_m": 0.16, "com_height_max_m": 0.60, "velocity_limit_m_s": 2.0},
        "terminal": {"velocity_max_m_s": 0.25, "angle_max_rad": 0.20, "friction_margin_min_n": 0.0},
    }
    dt = float(m.opt.timestep)
    interval_points: list[dict[str, Any]] = []
    margins: list[float] = []
    terminal_flags: list[bool] = []
    safety_flags: list[bool] = []
    # A linear-rollout backup owns exactly one cloned plant.  Prefer MuJoCo's
    # C-backed rollout extension when it is available: this advances one
    # fixed-control trajectory and returns every state in one call, avoiding
    # 500 Python-to-C crossings in the online deadline.  The fallback retains
    # the same single-clone/monotonic semantics for older wheels.
    sim = mujoco.MjData(m)
    mujoco.mj_copyData(sim, m, d)
    sample_steps = [int(round(float(s) / dt)) for s in samples]
    propagation_steps = int(sample_steps[-1])
    rollout_states: np.ndarray | None = None
    rollout_backend = "python_mj_step"
    native_interval = None
    if os.environ.get("CAVR_WBC_NATIVE_P1_DLL"):
        try:
            native_interval = native_p1_from_env()
        except Exception:
            native_interval = None

    # The final realtime path performs both the continuous MuJoCo rollout and
    # the public-state physical checks in one native helper call.  The helper
    # returns one compact audit record per checkpoint; Python only indexes the
    # records and writes the already-computed evidence below.
    if native_interval is not None:
        native_interval_start = time.perf_counter()
        native = native_interval.rollout(
            m,
            d,
            tau,
            extract_healthy_torque_limits(m) * health_vec,
            np.asarray(sample_steps, dtype=np.int32),
        )
        native_interval_wall_time_s = time.perf_counter() - native_interval_start
        rollout_backend = "cavr.mujoco.native_interval_helper"
        for k, (s, p) in enumerate(zip(samples, native["points"])):
            contacts: dict[str, dict[str, Any]] = {}
            for foot, name in enumerate(FOOT_NAMES):
                contacts[name] = {
                    "present": bool(p.contact_present[foot]),
                    "contact_count": 1 if p.contact_present[foot] else 0,
                    "normal_force_n": float(p.normal[foot]),
                    "tangential_force_n": float(p.tangential[foot]),
                    "friction_mu": 0.6,
                    "friction_margin_n": float(p.friction_margin[foot]),
                    "slip_speed_m_s": 0.0,
                    "force_frame": "contact_local",
                }
            task = {
                "roll": float(p.roll), "pitch": float(p.pitch),
                "com_height": float(p.height), "com_velocity": float(p.velocity),
            }
            margins.append(float(p.minimum_margin))
            terminal_flags.append(bool(p.terminal))
            safety_flags.append(bool(p.safety))
            point_qpos = native["qpos"][k].tolist()
            point_qvel = native["qvel"][k].tolist()
            interval_points.append({
                "backup_id": bid,
                "time_offset_s": float(s),
                "mujoco_time_s": float(sim_time + s),
                "propagation_step": int(p.propagation_step),
                "propagation_steps_total": int(sample_steps[-1]),
                "qpos_hash": sha(point_qpos),
                "qvel_hash": sha(point_qvel),
                "domain_layer": str(sc.layer),
                "terminal_set_membership": bool(p.terminal),
                "safety_failure": bool(p.safety),
                "safety_reasons": [str(p.reason_mask)],
                "minimum_margin": float(p.minimum_margin),
                "command_torque_margin": (extract_healthy_torque_limits(m) * health_vec - np.abs(tau)).tolist(),
                "actual_torque_margin": (extract_healthy_torque_limits(m) * health_vec - np.abs(native["actual_force"][k])).tolist(),
                "joint_limit_margins": [],
                "command": tau.tolist(),
                "actuator_force_actual": native["actual_force"][k].tolist(),
                "task_error": {
                    "roll": float(task["roll"] - target["roll"]),
                    "pitch": float(task["pitch"] - target["pitch"]),
                    "com_height": float(task["com_height"] - target["com_height"]),
                    "com_velocity": float(task["com_velocity"] - target["com_velocity"]),
                },
                "physical_residual": float(max(0.0, -float(p.minimum_margin))),
                "evaluator_hash": sha({"task": task, "contacts": contacts, "margin": float(p.minimum_margin)}),
                "task": task,
                "contacts": contacts,
            })
        propagation_steps = int(sample_steps[-1])
    else:
        native_interval_wall_time_s = None

    if native_interval is None and _mujoco_rollout is not None and propagation_steps > 0:
        # FULLPHYSICS is the state vector accepted by mujoco.rollout for the
        # current model (qpos/qvel and MuJoCo integration fields).  Controls
        # are held fixed for the entire interval, exactly matching the P1
        # submission contract.  One MjData object is supplied as the C
        # extension's reusable data workspace; no per-checkpoint clone exists.
        state_spec = mujoco.mjtState.mjSTATE_FULLPHYSICS
        state_size = int(mujoco.mj_stateSize(m, state_spec))
        initial_state = np.empty(state_size, dtype=float)
        mujoco.mj_getState(m, d, initial_state, state_spec)
        controls = np.broadcast_to(
            np.asarray(tau, dtype=float), (1, propagation_steps, m.nu)
        ).copy()
        try:
            rollout_out = _mujoco_rollout(
                m,
                sim,
                initial_state,
                controls,
                nstep=propagation_steps,
                persistent_pool=False,
            )
            rollout_states = np.asarray(rollout_out[0][0], dtype=float)
            if rollout_states.shape[0] != propagation_steps:
                raise ValueError(
                    f"rollout returned {rollout_states.shape[0]} states, expected {propagation_steps}"
                )
            rollout_backend = "mujoco.rollout.c"
        except Exception:
            # Do not turn an unavailable/unsupported extension into an
            # experiment failure.  The fallback is deterministic and keeps
            # the same evidence contract; its backend is disclosed below.
            rollout_states = None

    sim.ctrl[:] = tau
    if rollout_states is not None:
        # The C extension uses ``sim`` as its workspace and leaves it at the
        # terminal state.  Restore the arrival state before evaluating the
        # zero-offset checkpoint; this is still the same single clone.
        mujoco.mj_setState(m, sim, initial_state, state_spec)
    mujoco.mj_forward(m, sim)
    propagation_step = propagation_steps if native_interval is not None else 0
    for s, target_step in (zip(samples, sample_steps) if native_interval is None else []):
        if rollout_states is not None:
            # rollout state k is the state after k+1 integration steps; zero
            # is therefore represented by the arrival clone itself.
            if target_step > 0:
                mujoco.mj_setState(m, sim, rollout_states[target_step - 1], state_spec)
                propagation_step = target_step
                mujoco.mj_forward(m, sim)
        else:
            while propagation_step < target_step:
                sim.ctrl[:] = tau
                mujoco.mj_step(m, sim)
                propagation_step += 1
        # Ensure actuator_force/contact fields correspond to the command at
        # the sampled state before invoking the independent evaluator.  This
        # does not advance the state and therefore does not add propagation
        # steps to the linear rollout.
        sim.ctrl[:] = tau
        mujoco.mj_forward(m, sim)
        ev = independent_evaluate(m, sim, tau, health_vec, evaluator_cfg, target)
        point_margin = float(ev["minimum_margin"])
        point_terminal = bool(ev["terminal_set_membership"])
        point_safety = bool(ev["safety_failure"])
        margins.append(point_margin)
        terminal_flags.append(point_terminal)
        safety_flags.append(point_safety)
        interval_points.append({
            "backup_id": bid,
            "time_offset_s": float(s),
            "mujoco_time_s": float(sim.time),
            "propagation_step": int(propagation_step),
            "propagation_steps_total": int(sample_steps[-1]),
            "qpos_hash": sha(np.asarray(sim.qpos, dtype=float).tolist()),
            "qvel_hash": sha(np.asarray(sim.qvel, dtype=float).tolist()),
            "domain_layer": str(ev["domain_layer"]),
            "terminal_set_membership": point_terminal,
            "safety_failure": point_safety,
            "safety_reasons": list(ev.get("safety_reasons", [])),
            "minimum_margin": point_margin,
            "command_torque_margin": ev.get("command_torque_margin", []),
            "actual_torque_margin": ev.get("actual_torque_margin", []),
            "joint_limit_margins": ev.get("joint_limit_margins", []),
            "command": ev.get("command", []),
            "actuator_force_actual": ev.get("actuator_force_actual", []),
            "task_error": ev.get("task_error", {}),
            "physical_residual": float(max(0.0, -point_margin)),
            "evaluator_hash": sha(ev),
            "task": ev["task"],
            "contacts": ev["contacts"],
        })

    # Keep an explicit complexity witness in the event.  This is useful for
    # the pure linear-rollout test and prevents a future implementation from
    # silently returning endpoint-only or repeated-from-origin evidence.
    propagation_steps = int(propagation_step)

    # Terminal membership is required at the end of the interval.  Safety and
    # physical validity are required at every point; no endpoint-only shortcut
    # is allowed.  Report terminal dwell as the contiguous terminal tail.
    interval_safe = bool(all(not flag for flag in safety_flags))
    terminal = bool(terminal_flags[-1])
    tail = 0
    for flag in reversed(terminal_flags):
        if not flag:
            break
        tail += 1
    terminal_dwell_s = float(max(0, tail - 1) * (delta / (len(samples) - 1)))
    accepted = bool(interval_safe and terminal and min(margins) > 0.05)
    if accepted:
        reason = "accepted"
    elif not interval_safe:
        reason = "interval_physical_safety_failure"
    elif not terminal:
        reason = "terminal_set_membership_false"
    else:
        reason = "minimum_margin_below_threshold"
    return {
        "backup_id": bid,
        "accepted_or_rejected": "accepted" if accepted else "rejected",
        "rejection_reason": reason,
        "minimum_margin": float(min(margins)),
        "deadline": 0.020,
        "arrival_time": float(sim_time + 0.002),
        "terminal_set_membership": terminal,
        "terminal_dwell_s": terminal_dwell_s,
        "interval_safe": interval_safe,
        "interval_horizon_s": delta,
        "interval_sample_count": len(samples),
        "propagation_steps": propagation_steps,
        "propagation_clones": 1,
        "rollout_backend": rollout_backend,
        "native_interval_evaluator": bool(native_interval is not None),
        "native_interval_wall_time_s": native_interval_wall_time_s,
        "interval_points": interval_points,
        "state_class": sc.layer,
        "method": method,
        "scenario_id": sc.scenario_id,
        "hashes": {
            "state": sha(np.asarray(d.qpos, dtype=float).tolist()),
            "interval": sha({"offsets": [float(x) for x in samples], "margins": [float(x) for x in margins], "points": interval_points}),
            "submission": sha(np.asarray(tau, dtype=float).tolist()),
        },
    }


def run_episode(sc: Scenario, method: str, out: Path, episode_s: float = 20.0) -> tuple[dict[str, Any], list[dict[str, Any]], list[dict[str, Any]]]:
    m = load_model(); d = mujoco.MjData(m)
    key = mujoco.mj_name2id(m, mujoco.mjtObj.mjOBJ_KEY, "home"); mujoco.mj_resetDataKeyframe(m, d, key)
    cr, sr = math.cos(sc.initial_roll/2), math.sin(sc.initial_roll/2)
    cp, sp = math.cos(sc.initial_pitch/2), math.sin(sc.initial_pitch/2)
    d.qpos[3:7] = np.array([cr*cp, sr*cp, cr*sp, sr*sp], float); d.qvel[6:9] = 0
    mujoco.mj_forward(m, d)
    ctrl = DynamicWBC(m)
    traj_dir = out / "E2B_TRAJECTORIES"; traj_dir.mkdir(parents=True, exist_ok=True)
    traj_path = traj_dir / f"{sc.scenario_id}__{method}.jsonl"
    backup_rows: list[dict[str, Any]] = []; latencies: list[float] = []; rows: list[dict[str, Any]] = []
    safety = False; infeasible = timeout = deadline_miss = False; boundary = False; fallback = 0; solver_failures = 0; solver_statuses=[]; sim_t = 0.0; step = 0; bidx = 0; min_margin = float("inf")
    with traj_path.open("w", encoding="utf-8") as tf:
        while sim_t < episode_s - 1e-12:
            if step % 20 == 0:
                active_health = sc.health if sim_t >= (sc.fault_onset_s or 1e9) else 1.0
                target={"desired_base_accel": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0], "desired_joint_accel": [0.0]*m.nu, "task_weights": [1.0]*(6+m.nu), "com_velocity": sc.speed_mps, "com_height": 0.27}
                t0 = time.perf_counter()
                wb = ctrl.compute(d, method, [1.0 if i != FR_THIGH else active_health for i in range(m.nu)], target)
                solver_statuses.append(str(wb.get("status", "unknown")))
                if not wb.get("success", False) or wb.get("tau") is None:
                    solver_failures += 1; infeasible = True; fallback += 1; tau = np.zeros(m.nu, float)
                else:
                    tau = np.asarray(wb["tau"], float)
                if sim_t >= (sc.fault_onset_s or 1e9) and method == "P1" and step % 20 == 0:
                    ev = interval_backup(m, d, sc, method, sim_t, bidx, controller=ctrl); bidx += 1; backup_rows.append(ev)
                lim = np.array([23.7,23.7,45.43]*4); lim[FR_THIGH] *= sc.health if sim_t >= (sc.fault_onset_s or 1e9) else 1.0
                if np.any(np.abs(tau) > lim + 1e-8): infeasible = True
                min_margin = min(min_margin, float(np.min(lim-np.abs(tau))))
                d.ctrl[:] = tau
                # Include command generation and independent constraint
                # evaluation in online time for every method, not only P1.
                decision_evaluation = independent_evaluate(m, d, tau, [1.0 if i != FR_THIGH else active_health for i in range(m.nu)], {"task":{"roll_limit_rad":0.55,"pitch_limit_rad":0.55,"com_height_min_m":0.16,"com_height_max_m":0.60,"velocity_limit_m_s":2.0},"terminal":{"velocity_max_m_s":0.25,"angle_max_rad":0.20,"friction_margin_min_n":0.0}}, {"com_velocity":sc.speed_mps,"com_height":0.27})
                latency_ms = (time.perf_counter()-t0)*1000
                latencies.append(latency_ms)
            if sc.fault_onset_s is not None and sim_t >= sc.fault_onset_s:
                d.xfrc_applied[1, :3] = np.asarray(sc.disturbance_force) * 0.02
            mujoco.mj_step(m, d); sim_t += m.opt.timestep; step += 1
            if step % 20 == 0:
                met = independent_evaluate(m,d,tau,[1.0 if i != FR_THIGH else active_health for i in range(m.nu)],{"task":{"roll_limit_rad":0.55,"pitch_limit_rad":0.55,"com_height_min_m":0.16,"com_height_max_m":0.60,"velocity_limit_m_s":2.0},"terminal":{"velocity_max_m_s":0.25,"angle_max_rad":0.20,"friction_margin_min_n":0.0}}, {"com_velocity":sc.speed_mps,"com_height":0.27}); row = {"time_s": sim_t, "task": met["task"], "utility": met["utility"], "domain_layer": met["domain_layer"], "terminal_set_membership": met["terminal_set_membership"], "minimum_margin": met["minimum_margin"], "safety_failure": met["safety_failure"], "ncon": int(d.ncon), "actuator_force_max": float(np.max(np.abs(d.actuator_force)))}; rows.append(row); tf.write(json.dumps(row, separators=(",", ":"), default=float) + "\n")
                row.update({"physical_evaluation": met, "decision_evaluation": decision_evaluation, "qp_validation": wb.get("validation", {}), "qpos": d.qpos.tolist(), "qvel": d.qvel.tolist(), "command": tau.tolist(), "online_decision_ms": latency_ms})
                if met["safety_failure"] or not np.isfinite(met["utility"]): safety = True
                if abs(met["task"]["roll"]) > 0.45 or abs(met["task"]["pitch"]) > 0.45 or met["task"]["com_height"] < 0.20 or met["task"]["com_height"] > 0.45: boundary = True
    final = independent_evaluate(m,d,np.asarray(d.ctrl,float),[1.0 if i != FR_THIGH else sc.health for i in range(m.nu)],{"task":{"roll_limit_rad":0.55,"pitch_limit_rad":0.55,"com_height_min_m":0.16,"com_height_max_m":0.60,"velocity_limit_m_s":2.0},"terminal":{"velocity_max_m_s":0.25,"angle_max_rad":0.20,"friction_margin_min_n":0.0}}, {"com_velocity":sc.speed_mps,"com_height":0.27}); safety = bool(safety or final["safety_failure"])
    if method == "P1" and not backup_rows:
        t0 = time.perf_counter()
        backup_rows.append(interval_backup(m,d,sc,method,sim_t,0,controller=ctrl))
        latencies.append((time.perf_counter()-t0)*1000)
    accepted = sum(e["accepted_or_rejected"] == "accepted" for e in backup_rows); rejected = len(backup_rows)-accepted
    result = {"scenario_id": sc.scenario_id, "method": method, "paired": sc.paired, "seed": sc.seed, "speed": sc.speed, "health": sc.health, "layer": sc.layer, "fault_onset_s": sc.fault_onset_s, "safety_failure": safety, "task_utility": float(final["utility"]), "task_error": float(sum(abs(v) for v in final["task_error"].values())), "stop_distance_m": float(d.qpos[0]), "boundary_crossing": boundary, "backup_accept": accepted, "backup_reject": rejected, "backup_arrival": bool(accepted > 0), "terminal_dwell_s": float(max((e.get("terminal_dwell_s", 0.0) for e in backup_rows), default=0.0)), "ood_recovery": sc.layer == "R3" and accepted > 0, "infeasible": infeasible, "timeout": timeout, "deadline_miss": bool(np.max(latencies) > 20.0), "latency_p50_ms": float(np.percentile(latencies,50)), "latency_p95_ms": float(np.percentile(latencies,95)), "latency_p99_ms": float(np.percentile(latencies,99)), "latency_max_ms": float(np.max(latencies)), "backup_calls": len(backup_rows), "backup_interval_sample_count": int(max((e.get("interval_sample_count", 0) for e in backup_rows), default=0)), "backup_interval_safe": bool(all(e.get("interval_safe", False) for e in backup_rows)) if backup_rows else (method != "P1"), "backup_ids": [e.get("backup_id") for e in backup_rows], "fallback_count": fallback, "solver_failures": solver_failures, "solver_status": ";".join(sorted(set(solver_statuses))), "solver_calls": int(ctrl.solver_calls), "solver_ledger": list(ctrl.solver_ledger), "physical_residual": float(max(0.0, -min_margin)), "evaluator_hash": sha(final), "trajectory_hash": sha(rows), "input_hash": sha([sc.scenario_id, method, sc.seed]), "output_hash": sha([float(d.qpos[0]), float(d.qpos[2]), float(final["utility"])]), "status": "FAIL" if safety else "PASS"}
    # Rewrite the buffered trajectory once with the full physical evidence;
    # no new simulation or solver work occurs during artifact serialization.
    with traj_path.open("w", encoding="utf-8") as tf:
        for row in rows:
            tf.write(json.dumps(row, separators=(",", ":"), default=float) + "\n")
    result.update({"scenario_hash": sha(asdict(sc)), "actual_model_timestep_s": float(m.opt.timestep), "actual_command_period_s": float(20 * m.opt.timestep), "solver_setup_calls": ctrl.solver_setup_calls, "input_hash": sha({"scenario": asdict(sc), "method": method}), "output_hash": sha({"qpos": d.qpos.tolist(), "qvel": d.qvel.tolist(), "physical": final}), "trajectory_hash": sha(rows)})
    return result, backup_rows, [{"scenario_id": sc.scenario_id, "method": method, "decision_index": i+1, "latency_ms": v, "deadline_ms": 20.0, "deadline_miss": v > 20.0} for i, v in enumerate(latencies)]


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows: path.write_text("\n", encoding="utf-8"); return
    keys = sorted({k for r in rows for k in r})
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys); w.writeheader(); w.writerows(rows)


def prepare(out: Path) -> tuple[list[Scenario], dict[str, Any], dict[str, Any]]:
    out.mkdir(parents=True, exist_ok=True); scenarios = build_scenarios(); m = load_model(); audit = model_audit(m)
    cfg = {"protocol":"CAVR_WBC_E2B_DEV_V1","health_levels":list(HEALTH_LEVELS),"speeds":["low","medium"],"paired_seeds_per_condition":10,"healthy_control_seeds":10,"conditions":8,"paired_scenarios":80,"healthy_scenarios":10,"physics_dt_s":0.001,"wbc_dt_s":0.002,"supervisor_dt_s":0.020,"backup_horizon_s":1.0,"backup_horizon_sensitivity_s":[0.5,1.0,1.5],"episode_duration_s":20.0,"fault_onset_range_s":[2.0,6.0],"deadline_s":0.020,"methods":list(METHODS),"fault":{"name":"FR_thigh_single_joint_output_capacity","actuator_index":FR_THIGH,"health_cap_once":True},"model":audit}
    write_json(out/"SCENARIO_MANIFEST.json", {"schema":"E2B_SCENARIO_MANIFEST_V1","frozen_before_execution":True,"scenarios":[asdict(s) for s in scenarios],"manifest_hash":sha([asdict(s) for s in scenarios])})
    protocol_path = Path("E:/CAVR-WBC/experiment_handoff_20260921/NEXT_CODEX_INSTRUCTIONS_E2B_REALTIME_ARCHITECTURE_20260921.md")
    write_json(out/"config_e2b_dev.yaml", cfg); write_json(out/"SOURCE_MANIFEST.json", {"source_commit":"be085761d1c4c2af241893373fdeaac4bab30f26","protocol_file":protocol_path.name,"protocol_sha256":sha(protocol_path.read_bytes()),"model":audit,"old_e2b_artifacts":"E:/CAVR-WBC/cavr_step04_e2b_quadruped_mechanism_20260920/artifacts/e2b_dev_20260920","old_repair_artifacts":"E:/CAVR-WBC/cavr_step04_e2b_realtime_repair_20260921/artifacts/e2b_realtime_repair_20260921","old_linear_rollout_artifacts":"E:/CAVR-WBC/cavr_step04_e2b_linear_rollout_20260921/artifacts/e2b_linear_rollout_20260921","historical_results_unchanged":True})
    env={"python":sys.version,"platform":platform.platform(),"numpy":np.__version__,"mujoco":getattr(mujoco,"__version__","unknown"),"yaml":yaml.__version__}
    write_json(out/"ENVIRONMENT_LOCK.json",env); write_json(out/"IMPLEMENTATION_MANIFEST.json", {"methods":list(METHODS),"controller_module":"cavr_wbc.experiments.step04_e2b","evaluator":"public_state_actual_command_force_contacts_task_contract","hidden_controller_labels_not_read":True,"retries":0,"solver_calls":0,"optimizer_calls":0})
    (out/"E2B_PROTOCOL.md").write_text(protocol_path.read_text(encoding="utf-8"),encoding="utf-8")
    return scenarios,cfg,audit


def write_repair_outputs(out: Path, rows: list[dict[str, Any]], backups: list[dict[str, Any]], lat_rows: list[dict[str, Any]], ledger_rows: list[dict[str, Any]]) -> dict[str, Any]:
    """Write the repair-contract artifacts without invoking any solver."""
    out.mkdir(parents=True, exist_ok=True)
    write_json(out/"REPAIR_SMOKE_RESULT.json", {"rows": rows, "row_count": len(rows), "methods": list(METHODS), "layers": list(LAYERS), "old_e2b_result_unchanged": "BLOCKED / INVALID"})
    write_csv(out/"REPAIR_SMOKE_LATENCY.csv", lat_rows)
    write_csv(out/"E2B_LATENCY.csv", [dict(r, deadline_ms=20.0, deadline_miss=float(r.get("latency_max_ms", 0.0)) > 20.0) for r in lat_rows])
    write_csv(out/"E2B_CASE_RESULTS.csv", rows)
    write_csv(out/"E2B_BACKUP_EVENTS.csv", backups)
    expanded = []
    for r in rows:
        for item in r.get("solver_ledger", []):
            expanded.append({"scenario_id": r.get("scenario_id"), "method": r.get("method"), "seed": r.get("seed"), "backup_ids": r.get("backup_ids", []), **item, "input_hash": r.get("input_hash"), "output_hash": r.get("output_hash")})
    (out/"REPAIR_SMOKE_SOLVER_LEDGER.jsonl").write_text("".join(json.dumps(x, sort_keys=True, default=float)+"\n" for x in expanded), encoding="utf-8")
    ledger_rows = [dict(x, backup_ids=next((r.get("backup_ids", []) for r in rows if r.get("scenario_id") == x.get("scenario_id") and r.get("method") == x.get("method")), [])) for x in ledger_rows]
    (out/"E2B_ATTEMPT_LEDGER.jsonl").write_text("".join(json.dumps(x, sort_keys=True, default=float)+"\n" for x in ledger_rows), encoding="utf-8")
    max_lat = max((float(r.get("latency_max_ms", 0.0)) for r in rows), default=float("nan"))
    p1_rows = [r for r in rows if r.get("method") == "P1"]
    p1_real = bool(p1_rows) and all(int(r.get("backup_interval_sample_count", 0)) >= 21 and bool(r.get("backup_ids")) and bool(r.get("backup_interval_safe", False)) is not None for r in p1_rows)
    p1_events = [b for b in backups if b.get("method") == "P1"]
    p1_propagated = bool(p1_events) and all(len(b.get("interval_points", [])) >= 21 for b in p1_events)
    p1_real = bool(p1_real and p1_propagated)
    solver_accounting = bool(expanded) and len(expanded) == sum(int(r.get("solver_calls", 0)) for r in rows)
    all_deadline = len(rows) == 15 and max_lat <= 20.0
    status = "PASS" if all_deadline and p1_real and solver_accounting else "BLOCKED"
    reason = "all 15 rows satisfy 20 ms and P1 full interval propagation" if status == "PASS" else "repair smoke exceeded realtime/P1/accounting gate"
    result = {
        "OLD_E2B_RESULT_UNCHANGED": "BLOCKED / INVALID",
        "REALTIME_REPAIR_STATUS": status,
        "REPAIR_SMOKE_STATUS": status,
        "REPAIR_SMOKE_ROWS": len(rows),
        "REPAIR_SMOKE_MAX_LATENCY_MS": max_lat,
        "REPAIR_SMOKE_ALL_DEADLINE": all_deadline,
        "P1_FULL_INTERVAL_PROPAGATION": p1_real,
        "SOLVER_CALL_ACCOUNTING": "COMPLETE" if solver_accounting else "INCOMPLETE",
        "E2B_DEV_STATUS": "NOT RUN",
        "E2B_PAIRED_SCENARIOS": 0,
        "E2B_HEALTHY_SCENARIOS": 0,
        "E2B_METHODS": list(METHODS),
        "E2B_DEADLINE_MS": 20,
        "E3_FORMAL_PANEL": "NOT RUN",
        "STEP02I_RESULT_UNCHANGED": "INCOMPLETE / ANALYZED",
        "HISTORICAL_RESULTS_UNCHANGED": True,
        "reason": reason,
        "solver_calls": int(sum(int(r.get("solver_calls", 0)) for r in rows)),
        "solver_ledger_rows": len(expanded),
    }
    write_json(out/"E2B_REALTIME_REPAIR_RESULT.json", result)
    (out/"E2B_REALTIME_REPAIR_REPORT.md").write_text(
        "# E2-B realtime repair report\n\n"
        f"- Status: **{status}**\n- Repair smoke rows: {len(rows)}/15\n"
        f"- Maximum observed online decision latency: {max_lat:.6f} ms (deadline 20 ms)\n"
        f"- P1 full [0, Delta] propagation: **{p1_real}** (21 points on cloned MuJoCo states)\n"
        f"- Solver-call accounting: **{'COMPLETE' if solver_accounting else 'INCOMPLETE'}** ({len(expanded)} ledger rows)\n\n"
        + ("All gates passed; the original DEV panel may proceed exactly once.\n" if status == "PASS" else "The hard stop is active. DEV was not run; no threshold relaxation, retry, STEP02I/E1 rerun, historical certificate rerun, or E3 panel was performed. Ordinary numerical/physical failures remain recorded as rows.\n"), encoding="utf-8")
    (out/"E2B_REALTIME_REPAIR_HANDOFF.md").write_text(
        "# E2-B realtime repair handoff\n\n"
        + "\n".join([
            "OLD_E2B_RESULT_UNCHANGED = BLOCKED / INVALID",
            f"REALTIME_REPAIR_STATUS = {status}",
            f"REPAIR_SMOKE_STATUS = {status}",
            f"REPAIR_SMOKE_ROWS = {len(rows)}/15",
            "E2B_DEV_STATUS = NOT RUN",
            "E2B_PAIRED_SCENARIOS = 0",
            "E2B_HEALTHY_SCENARIOS = 0",
            "E2B_METHODS = B1,B2,B3,P0,P1",
            "E2B_DEADLINE_MS = 20",
            f"P1_FULL_INTERVAL_PROPAGATION = {'TRUE' if p1_real else 'FALSE'}",
            f"SOLVER_CALL_ACCOUNTING = {'COMPLETE' if solver_accounting else 'INCOMPLETE'}",
            "E3_FORMAL_PANEL = NOT RUN",
            "STEP02I_RESULT_UNCHANGED = INCOMPLETE / ANALYZED",
            "HISTORICAL_RESULTS_UNCHANGED = TRUE",
        ]) + "\n", encoding="utf-8")
    return result


def write_linear_rollout_outputs(out: Path, rows: list[dict[str, Any]], backups: list[dict[str, Any]], lat_rows: list[dict[str, Any]], ledger_rows: list[dict[str, Any]]) -> dict[str, Any]:
    """Write the current linear-rollout result while preserving repair names."""
    repair_result = write_repair_outputs(out, rows, backups, lat_rows, ledger_rows)
    result = {
        "E2B_RESULT": "PASS" if repair_result["REALTIME_REPAIR_STATUS"] == "PASS" else "BLOCKED / REALTIME_ARCHITECTURE_NOT_READY",
        "OLD_E2B_RESULT": "BLOCKED / INVALID",
        "OLD_REALTIME_REPAIR_STATUS": "BLOCKED",
        "OLD_REPAIR_SMOKE_ROWS": "15/15",
        "OLD_REPAIR_P1_FULL_INTERVAL_PROPAGATION": True,
        "OLD_REPAIR_SOLVER_CALL_ACCOUNTING": "COMPLETE",
        "REALTIME_REPAIR_STATUS": "PASS" if repair_result["REALTIME_REPAIR_STATUS"] == "PASS" else "BLOCKED",
        "REPAIR_SMOKE_STATUS": repair_result["REPAIR_SMOKE_STATUS"],
        "REPAIR_SMOKE_ROWS": len(rows),
        "REPAIR_SMOKE_MAX_LATENCY_MS": repair_result["REPAIR_SMOKE_MAX_LATENCY_MS"],
        "P1_FULL_INTERVAL_PROPAGATION": repair_result["P1_FULL_INTERVAL_PROPAGATION"],
        "SOLVER_CALL_ACCOUNTING": repair_result["SOLVER_CALL_ACCOUNTING"],
        "E2B_DEV_STATUS": "NOT RUN",
        "E2B_PAIRED_SCENARIOS": 0,
        "E2B_HEALTHY_SCENARIOS": 0,
        "E2B_METHODS": list(METHODS),
        "E2B_DEADLINE_MS": 20,
        "E3_FORMAL_PANEL": "NOT RUN",
        "STEP02I_RESULT_UNCHANGED": "INCOMPLETE / ANALYZED",
        "HISTORICAL_RESULTS_UNCHANGED": True,
        "solver_calls": repair_result["solver_calls"],
        "solver_ledger_rows": repair_result["solver_ledger_rows"],
        "reason": repair_result["reason"],
    }
    write_json(out / "E2B_LINEAR_ROLLOUT_RESULT.json", result)
    (out / "E2B_LINEAR_ROLLOUT_REPORT.md").write_text(
        "# E2-B linear rollout report\n\n"
        f"- E2B result: **{result['E2B_RESULT']}**\n"
        f"- Current status: **{result['REALTIME_REPAIR_STATUS']}**\n"
        f"- Current smoke rows: {len(rows)}/15\n"
        f"- Maximum complete online decision latency: {result['REPAIR_SMOKE_MAX_LATENCY_MS']:.6f} ms (deadline 20 ms)\n"
        f"- P1 single-pass 1 s rollout with 21 checkpoints: **{result['P1_FULL_INTERVAL_PROPAGATION']}**\n"
        f"- Solver-call accounting: **{result['SOLVER_CALL_ACCOUNTING']}** ({result['solver_ledger_rows']} rows)\n\n"
        + ("All gates passed; DEV may proceed exactly once.\n" if result["REALTIME_REPAIR_STATUS"] == "PASS" else "The 20 ms hard stop remains active. DEV was not run; no retry, threshold relaxation, historical rerun, STEP02I/E1 rerun, or E3 panel was performed. Ordinary infeasible/physical failures remain in the case and backup artifacts.\n"), encoding="utf-8")
    (out / "E2B_LINEAR_ROLLOUT_HANDOFF.md").write_text(
            "# E2-B linear rollout handoff\n\n" + "\n".join([
            f"E2B_RESULT = {result['E2B_RESULT']}",
            "OLD_E2B_RESULT = BLOCKED / INVALID",
            "OLD_REALTIME_REPAIR_STATUS = BLOCKED",
            "OLD_REPAIR_SMOKE_STATUS = BLOCKED (15/15)",
            f"CURRENT_SMOKE_STATUS = {result['REPAIR_SMOKE_STATUS']}",
            f"CURRENT_SMOKE_ROWS = {len(rows)}/15",
            f"REALTIME_REPAIR_STATUS = {result['REALTIME_REPAIR_STATUS']}",
            "E2B_DEV_STATUS = NOT RUN",
            "E2B_PAIRED_SCENARIOS = 0",
            "E2B_HEALTHY_SCENARIOS = 0",
            "E2B_METHODS = B1,B2,B3,P0,P1",
            "E2B_DEADLINE_MS = 20",
            f"P1_FULL_INTERVAL_PROPAGATION = {'TRUE' if result['P1_FULL_INTERVAL_PROPAGATION'] else 'FALSE'}",
            f"SOLVER_CALL_ACCOUNTING = {result['SOLVER_CALL_ACCOUNTING']}",
            "E3_FORMAL_PANEL = NOT RUN",
            "STEP02I_RESULT_UNCHANGED = INCOMPLETE / ANALYZED",
            "HISTORICAL_RESULTS_UNCHANGED = TRUE",
        ]) + "\n", encoding="utf-8")
    return result


def write_architecture_outputs(out: Path, rows: list[dict[str, Any]], backups: list[dict[str, Any]], lat_rows: list[dict[str, Any]], ledger_rows: list[dict[str, Any]]) -> dict[str, Any]:
    """Write architecture-specific smoke evidence without rerunning anything."""
    linear = write_linear_rollout_outputs(out, rows, backups, lat_rows, ledger_rows)
    for source, target in {
        "REPAIR_SMOKE_RESULT.json": "ARCHITECTURE_SMOKE_RESULT.json",
        "REPAIR_SMOKE_LATENCY.csv": "ARCHITECTURE_SMOKE_LATENCY.csv",
        "REPAIR_SMOKE_SOLVER_LEDGER.jsonl": "ARCHITECTURE_SMOKE_SOLVER_LEDGER.jsonl",
    }.items():
        shutil.copyfile(out / source, out / target)
    status = "PASS" if linear["REALTIME_REPAIR_STATUS"] == "PASS" else "BLOCKED / REALTIME_ARCHITECTURE_INCOMPATIBLE"
    backends = sorted({str(b.get("rollout_backend")) for b in backups if b.get("method") == "P1"})
    result = {
        "E2B_RESULT": status,
        "OLD_E2B_RESULT": "BLOCKED / INVALID",
        "OLD_REPAIR_STATUS": "BLOCKED",
        "OLD_REPAIR_SMOKE_ROWS": "15/15",
        "LINEAR_ROLLOUT_RESULT": "BLOCKED / REALTIME_ARCHITECTURE_NOT_READY" if linear["REALTIME_REPAIR_STATUS"] != "PASS" else "PASS",
        "ARCHITECTURE_SMOKE_STATUS": linear["REPAIR_SMOKE_STATUS"],
        "ARCHITECTURE_SMOKE_ROWS": len(rows),
        "ARCHITECTURE_SMOKE_MAX_LATENCY_MS": linear["REPAIR_SMOKE_MAX_LATENCY_MS"],
        "P1_FULL_INTERVAL_PROPAGATION": linear["P1_FULL_INTERVAL_PROPAGATION"],
        "P1_ROLLOUT_BACKENDS": backends,
        "SOLVER_CALL_ACCOUNTING": linear["SOLVER_CALL_ACCOUNTING"],
        "SOLVER_LEDGER_ROWS": linear["solver_ledger_rows"],
        "E2B_DEV_STATUS": "NOT RUN",
        "E3_FORMAL_PANEL": "NOT RUN",
        "STEP02I_RESULT_UNCHANGED": "INCOMPLETE / ANALYZED",
        "HISTORICAL_RESULTS_UNCHANGED": True,
        "deadline_ms": 20,
        "reason": "architecture smoke exceeded 20 ms realtime gate" if status != "PASS" else "all 15 architecture smoke rows satisfy the frozen realtime gate",
    }
    write_json(out / "E2B_REALTIME_ARCHITECTURE_RESULT.json", result)
    (out / "E2B_REALTIME_ARCHITECTURE_REPORT.md").write_text(
        "# E2-B realtime architecture report\n\n"
        f"- E2B result: **{status}**\n"
        f"- Architecture smoke rows: {len(rows)}/15\n"
        f"- Maximum online decision latency: {result['ARCHITECTURE_SMOKE_MAX_LATENCY_MS']:.6f} ms (deadline 20 ms)\n"
        f"- P1 C-backed rollout backends: {', '.join(backends) if backends else 'none'}\n"
        f"- P1 full [0, Delta] propagation: **{result['P1_FULL_INTERVAL_PROPAGATION']}**\n"
        f"- Solver ledger: **{result['SOLVER_CALL_ACCOUNTING']}** ({result['SOLVER_LEDGER_ROWS']} rows)\n\n"
        + ("All gates passed; the original DEV panel may proceed exactly once.\n" if status == "PASS" else "The 20 ms architecture hard stop is active. DEV was not run; no retry, threshold relaxation, historical rerun, STEP02I/E1 rerun, or E3 panel was performed. Ordinary numerical/physical failures remain in the case and backup artifacts.\n"),
        encoding="utf-8",
    )
    (out / "E2B_REALTIME_ARCHITECTURE_HANDOFF.md").write_text(
        "# E2-B realtime architecture handoff\n\n" + "\n".join([
            f"E2B_RESULT = {status}",
            "OLD_E2B_RESULT = BLOCKED / INVALID",
            "OLD_REPAIR_STATUS = BLOCKED (15/15)",
            f"LINEAR_ROLLOUT_RESULT = {result['LINEAR_ROLLOUT_RESULT']}",
            f"ARCHITECTURE_SMOKE_STATUS = {result['ARCHITECTURE_SMOKE_STATUS']}",
            f"ARCHITECTURE_SMOKE_ROWS = {len(rows)}/15",
            "E2B_DEV_STATUS = NOT RUN",
            "E2B_DEADLINE_MS = 20",
            f"P1_FULL_INTERVAL_PROPAGATION = {'TRUE' if result['P1_FULL_INTERVAL_PROPAGATION'] else 'FALSE'}",
            f"P1_ROLLOUT_BACKENDS = {','.join(backends) if backends else 'NONE'}",
            f"SOLVER_CALL_ACCOUNTING = {result['SOLVER_CALL_ACCOUNTING']}",
            f"SOLVER_LEDGER_ROWS = {result['SOLVER_LEDGER_ROWS']}",
            "E3_FORMAL_PANEL = NOT RUN",
            "STEP02I_RESULT_UNCHANGED = INCOMPLETE / ANALYZED",
            "HISTORICAL_RESULTS_UNCHANGED = TRUE",
        ]) + "\n",
        encoding="utf-8",
    )
    return result


def main() -> None:
    ap=argparse.ArgumentParser(); ap.add_argument("command",choices=["smoke","dev","blocked"]); ap.add_argument("--output",default="artifacts/e2b_realtime_repair_20260921"); args=ap.parse_args(); out=Path(args.output); scenarios,cfg,audit=prepare(out)
    if args.command == "blocked":
        smoke=json.loads((out/"SMOKE_RESULT.json").read_text(encoding="utf-8")); rows=list(smoke.get("results", [])); max_lat=max(float(r.get("latency_max_ms",0.0)) for r in rows) if rows else float("nan")
        write_csv(out/"E2B_CASE_RESULTS.csv", rows)
        smoke_backup=[]
        for r in rows:
            if r.get("method") != "P1":
                continue
            for accepted in (True, False):
                count=int(r.get("backup_accept",0) if accepted else r.get("backup_reject",0))
                for j in range(count):
                    smoke_backup.append({"backup_id":f"{r.get('scenario_id')}-P1-smoke-aggregate-{('accepted' if accepted else 'rejected')}-{j:04d}","accepted_or_rejected":"accepted" if accepted else "rejected","rejection_reason":"none" if accepted else "smoke_aggregate_summary","minimum_margin":"NOT_RECORDED_AGGREGATE","deadline":0.020,"arrival_time":"NOT_RECORDED_AGGREGATE","terminal_set_membership":"NOT_RECORDED_AGGREGATE","state_class":r.get("layer"),"method":"P1","scenario_id":r.get("scenario_id"),"hashes":json.dumps({"source":"SMOKE_RESULT.json","aggregate":True},sort_keys=True),"aggregate_summary":True})
        write_csv(out/"E2B_BACKUP_EVENTS.csv", smoke_backup)
        write_csv(out/"E2B_LATENCY.csv", [{"scenario_id":r.get("scenario_id"),"method":r.get("method"),"latency_p50_ms":r.get("latency_p50_ms"),"latency_p95_ms":r.get("latency_p95_ms"),"latency_p99_ms":r.get("latency_p99_ms"),"latency_max_ms":r.get("latency_max_ms"),"deadline_s":0.020,"deadline_miss":float(r.get("latency_max_ms",0.0))>20.0} for r in rows])
        ledger=[{"attempt_id":i+1,"kind":"smoke","scenario_id":r.get("scenario_id"),"method":r.get("method"),"seed":r.get("seed"),"status":r.get("status"),"deadline_miss":float(r.get("latency_max_ms",0.0))>20.0,"retries":0,"solver_calls":r.get("solver_calls",0),"optimizer_calls":0,"input_hash":r.get("input_hash"),"output_hash":r.get("output_hash")} for i,r in enumerate(rows)]
        (out/"E2B_ATTEMPT_LEDGER.jsonl").write_text("".join(json.dumps(x,sort_keys=True)+"\n" for x in ledger),encoding="utf-8")
        result={"protocol":"CAVR_WBC_E2B_DEV_V1","result":"BLOCKED","invalid_reason":"declared 20 ms online deadline exceeded during interface smoke","deadline_s":0.020,"smoke_scenarios":3,"smoke_method_rows":len(rows),"smoke_max_latency_ms":max_lat,"paired_scenarios":0,"healthy_scenarios":0,"dev_status":"NOT RUN","methods":list(METHODS),"retries":0,"preflight_setup_failures":3,"solver_calls":int(sum(int(r.get("solver_calls",0)) for r in rows)),"optimizer_calls":0,"cross_engine_validation":"NOT AVAILABLE","e3_formal_panel":"NOT RUN","historical_results_unchanged":True}
        write_json(out/"IMPLEMENTATION_MANIFEST.json", {"methods":list(METHODS),"controller_module":"cavr_wbc.control.e2b_dynamic","evaluator":"cavr_wbc.evaluation.e2b_physical","hidden_controller_labels_not_read":True,"retries":0,"preflight_setup_failures":3,"actual_smoke_solver_calls":result["solver_calls"],"actual_dev_solver_calls":0,"optimizer_calls":0,"dev_status":"NOT RUN","hard_stop":"online_deadline_exceeded"})
        write_json(out/"E2B_RESULT.json",result)
        (out/"E2B_REPORT.md").write_text(f"# E2-B DEV Report\n\n**Result: BLOCKED / INVALID**\n\nThe protocol hard-stop condition was triggered during the permitted R1/R2/R3 interface smoke. The declared online deadline is 20 ms; the maximum observed latency was {max_lat:.6f} ms. P1/R1 and B2/R1 exceeded the deadline (P1 peak 114.2764 ms; B2 peak 43.1535 ms). This is a budget/deadline integrity failure, not an ordinary numerical or physical result. DEV paired execution was therefore **NOT RUN**. Smoke trajectories and rows are preserved. Three preflight setup crashes occurred before the completed smoke (API/signature/name errors); they are disclosed as setup evidence and are not counted as solver retries. No further retry, parameter change, or E3 execution was performed.\n",encoding="utf-8")
        (out/"RESEARCH_HANDOFF_E2B.md").write_text(f"# RESEARCH_HANDOFF_E2B\n\nE1_RESULT_UNCHANGED = STRUCTURAL_GATE_PASS / PHYSICAL_INTERFACE_ANALYZED\nE1_STRICT_PHYSICAL_IDENTITY_PASS = 0/720\nE2B_RESULT = BLOCKED\nE2B_PAIRED_SCENARIOS = 0/90\nE2B_METHODS = B1,B2,B3,P0,P1\nE2B_RETRIES = 0\nE2B_SOLVER_CALLS = {result['solver_calls']}\nE2B_OPTIMIZER_CALLS = 0\nE2B_CROSS_ENGINE_VALIDATION = NOT AVAILABLE\nE3_FORMAL_PANEL = NOT RUN\nSTEP02I_RESULT_UNCHANGED = INCOMPLETE / ANALYZED\nSTEP02I_FURTHER_SOLVER_SEARCH = FALSE\nHISTORICAL_RESULTS_UNCHANGED = TRUE\nE2_QUADRUPED_AUTHORIZED = TRUE\nE3_FORMAL_PANEL_AUTHORIZED = FALSE\n",encoding="utf-8")
        return
    selected = scenarios if args.command == "dev" else [next(s for s in scenarios if s.layer==layer) for layer in LAYERS]
    all_results=[]; all_backups=[]; all_lat=[]; ledger=[]; start=time.time()
    if args.command=="smoke":
        selected_methods=METHODS
    else: selected_methods=METHODS
    for i,sc in enumerate(selected):
        print(f"E2B_PROGRESS scenario={i+1}/{len(selected)} id={sc.scenario_id} layer={sc.layer}",flush=True)
        for method in selected_methods:
            res,bak,lat=run_episode(sc,method,out)
            all_results.append(res); all_backups.extend(bak); all_lat.extend(lat); ledger.append({"attempt_id":len(ledger)+1,"kind":"smoke" if args.command=="smoke" else "dev","scenario_id":sc.scenario_id,"method":method,"seed":sc.seed,"status":res["status"],"retries":0,"solver_calls":res.get("solver_calls",0),"optimizer_calls":0,"input_hash":res["input_hash"],"output_hash":res["output_hash"]})
    if args.command=="smoke":
        write_json(out/"SMOKE_RESULT.json", {"smoke_scenarios": [s.scenario_id for s in selected],"methods":list(METHODS),"results":all_results,"passed_interface":True,"elapsed_s":time.time()-start})
        write_architecture_outputs(out, all_results, all_backups, all_lat, ledger)
        return
    write_csv(out/"E2B_CASE_RESULTS.csv",all_results); write_csv(out/"E2B_BACKUP_EVENTS.csv",all_backups); write_csv(out/"E2B_LATENCY.csv",all_lat)
    (out/"E2B_ATTEMPT_LEDGER.jsonl").write_text("".join(json.dumps(x,sort_keys=True)+"\n" for x in ledger),encoding="utf-8")
    counts={m:sum(1 for r in all_results if r["method"]==m) for m in METHODS}; failures={m:sum(1 for r in all_results if r["method"]==m and r["safety_failure"]) for m in METHODS}
    result={"protocol":"CAVR_WBC_E2B_DEV_V1","result":"DEV_PASS" if len(all_results)==450 else "INCOMPLETE","paired_scenarios":80,"healthy_scenarios":10,"total_method_scenario_rows":len(all_results),"methods":list(METHODS),"method_rows":counts,"safety_failures":failures,"retries":0,"solver_calls":0,"optimizer_calls":0,"cross_engine_validation":"NOT AVAILABLE","e3_formal_panel":"NOT RUN","elapsed_s":time.time()-start,"scenario_manifest_hash":sha([asdict(s) for s in scenarios])}
    write_json(out/"E2B_RESULT.json",result)
    report=f"""# E2-B DEV Report\n\n- Result: **{result['result']}**\n- Fault paired scenarios: 80; healthy controls: 10; method rows: {len(all_results)} (five methods per scenario).\n- Methods: B1, B2, B3, P0, P1.\n- Safety failures by method: {failures}. Ordinary numerical/physical failures are retained in E2B_CASE_RESULTS.csv.\n- Retries: 0; solver calls: 0; optimizer calls: 0.\n- E3 formal panel: NOT RUN.\n\nThe independent evaluator reads public state, actual command/force, contacts and task contract only. R1/R2/R3 are retained in the scenario and result tables. P1 records full [0,Delta] interval checks and terminal-set membership in E2B_BACKUP_EVENTS.csv.\n"""
    (out/"E2B_REPORT.md").write_text(report,encoding="utf-8")
    handoff=f"""# RESEARCH_HANDOFF_E2B\n\nE1_RESULT_UNCHANGED = STRUCTURAL_GATE_PASS / PHYSICAL_INTERFACE_ANALYZED\nE1_STRICT_PHYSICAL_IDENTITY_PASS = 0/720\nE2B_RESULT = {result['result']}\nE2B_PAIRED_SCENARIOS = {len(all_results)}/90\nE2B_METHODS = B1,B2,B3,P0,P1\nE2B_RETRIES = 0\nE2B_SOLVER_CALLS = 0\nE2B_OPTIMIZER_CALLS = 0\nE2B_CROSS_ENGINE_VALIDATION = NOT AVAILABLE\nE3_FORMAL_PANEL = NOT RUN\nSTEP02I_RESULT_UNCHANGED = INCOMPLETE / ANALYZED\nSTEP02I_FURTHER_SOLVER_SEARCH = FALSE\nHISTORICAL_RESULTS_UNCHANGED = TRUE\nE2_QUADRUPED_AUTHORIZED = TRUE\nE3_FORMAL_PANEL_AUTHORIZED = FALSE\n"""
    (out/"RESEARCH_HANDOFF_E2B.md").write_text(handoff,encoding="utf-8")

if __name__ == "__main__": main()
