"""Withdrawn Tier-1/Tier-2 runner: evidence-integrity stop.

The executed source and raw latest outputs are preserved byte-for-byte under
artifacts/tro_tier1_tier2_20260921/prior_unverified_20260921/.
No experiment is resumed by this module. The delivery reports document
unlogged probes/repeated runs, incomplete native-state identity, and a
misclassified natural-infeasibility path. New numerical work needs a new
explicitly approved execution plan; the fixed contract is not relaxed.
"""


def run():
    """Fail closed before imports, output writes, simulation or solver calls."""
    raise RuntimeError(
        "INTEGRATION_BLOCKED: execution is withdrawn; see "
        "artifacts/tro_tier1_tier2_20260921/TRO_TIER1_TIER2_REPORT.md. "
        "No solver or simulator has been called."
    )


if __name__ == "__main__":
    run()
