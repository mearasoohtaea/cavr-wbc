"""One-shot STEP12 component experiment; no prepare/probe/retry entry points.

The parent is a non-numerical timeout supervisor. Exactly one child owns all
three fixed cases and the append-only numerical ledger. Importing this module
does not import numerical libraries or create an experiment directory.
"""
from __future__ import annotations

import hashlib
import json
import math
import multiprocessing as mp
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parents[2]
RUN_ID = "d5dfde17-5ffe-48b4-b921-da4764f86514"
OUTPUT_ROOT = ROOT / "artifacts/step12_bounded_integration_20260922"
ACCEPTANCE = ROOT / "configs/validation/step12_v1_acceptance_v1.json"
PURE_RESULT = ROOT / "configs/validation/step12_pure_test_result_retry4.json"
PROTOCOL = Path("E:/CAVR-WBC/experiment_handoff_20260921/NEXT_CODEX_INSTRUCTIONS_STEP12_BOUNDED_INTEGRATION_20260922.md")
SOURCE_COMMIT = "6fc5d6f23f6327d5acf52d372aa2165f878aaece"
SCENARIOS = ROOT / "artifacts/e2b_dev_20260920/SCENARIO_MANIFEST.json"
MODEL_PATH = Path("third_party/unitree_mujoco_snapshot/unitree_robots/go2/scene.xml")
CASE_IDS = ("H_control_00", "F_low_h0.00_00", "F_low_h0.25_00")
LIMITS = {"case": 3, "b2_compute": 3, "solver": 5, "injection": 1,
          "stage": 6, "rollout": 3, "fixture": 3}
BACKENDS = {"solver": "osqp.python.OSQP", "p1": "PYTHON_MUJOCO_MJ_STEP"}


def sha_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump_new(path, value):
    with Path(path).open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def selected_cases():
    original = json.loads(SCENARIOS.read_text(encoding="utf-8"))["scenarios"]
    pairs = (("R1", 1.0), ("R3", 0.0), ("R2", 0.25))
    selected = [sorted((s for s in original if s["layer"] == layer and
                        s["health"] == health), key=lambda s: s["scenario_id"])[0]
                for layer, health in pairs]
    if tuple(s["scenario_id"] for s in selected) != CASE_IDS:
        raise ValueError("Frozen case selection changed")
    return selected


def _git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True).strip()


def _make_manifest():
    tests = json.loads(PURE_RESULT.read_text(encoding="utf-8"))
    if not tests["successful"] or tests["guard_violations"]:
        raise RuntimeError("Pure tests did not pass with zero guarded calls")
    for rel, expected in tests["source_sha256"].items():
        if sha_file(ROOT / rel) != expected:
            raise RuntimeError(f"Tested source changed: {rel}")
    if _git("status", "--porcelain=v1"):
        raise RuntimeError("Preparation must be committed before numerical entry")
    return {
        "schema": "STEP12_BOUNDED_INTEGRATION_V1", "run_id": RUN_ID,
        "acceptance_definition_commit": SOURCE_COMMIT,
        "preparation_commit": _git("rev-parse", "HEAD"),
        "branch": _git("branch", "--show-current"), "worktree": str(ROOT),
        "protocol": {"path": str(PROTOCOL), "sha256": sha_file(PROTOCOL)},
        "acceptance": {"path": str(ACCEPTANCE.relative_to(ROOT)),
                       "sha256": sha_file(ACCEPTANCE),
                       "document": json.loads(ACCEPTANCE.read_text(encoding="utf-8"))},
        "fixed_inputs": selected_cases(), "limits": LIMITS,
        "case_hard_wall_s": 60, "batch_hard_wall_s": 180,
        "deadline_s": 0.020, "horizon_s": 1.0, "checkpoints": 21,
        "backup_kind": "CONSTANT_TORQUE_HOLD", "backends": BACKENDS,
        "initialization": "Original home keyframe and original roll/pitch; zero initial velocity, not speed target; mj_forward only; no settling or warm-up",
        "fault_semantics": "Component capture uses scenario health immediately; retained fault_onset is metadata, no pre-fault episode is simulated",
        "model_timestep": "Use actual compiled model option unchanged; never force archived config label onto model",
        "gate_revision": "Three fixed inputs, not prescribed outcomes; natural status=3 is not required",
        "witness_scope": "Only array substitution into same assembled shared constraints/band, no exact certificate",
        "evaluation_scope": "Sampled physical evaluation, not feedback recovery/continuous safety/terminal invariance",
        "historical_cumulative_calls": "UNKNOWN_UNCHANGED",
        "numerical_entry_launches": 1, "cold_start": True,
        "solver_parameter_overrides": {}, "performance_comparison": None,
        "pure_tests": tests, "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "numerical_command": f'"{sys.executable}" -B -X utf8 -m cavr_wbc.experiments.step12_bounded_integration',
        "changed_files": _git("diff", "--name-only", SOURCE_COMMIT, "HEAD").splitlines(),
        "preparation_git_status": "clean",
        "supervisor_pid": os.getpid(), "supervisor_start_ns": time.perf_counter_ns(),
    }


def _batch_worker(output):
    """The only numerical dispatch owner. No warm-up, retry or case extension."""
    from cavr_wbc.experiments.step12_ledger import EventLedger
    out = Path(output)
    ledger = EventLedger(out / "EVENTS.jsonl", limits=LIMITS)
    ledger.note("BATCH_STARTED", {"pid": os.getpid(), "run_id": RUN_ID})
    try:
        # Freeze backend explicitly, without editing machine-wide settings.
        ignored = {key: os.environ.pop(key, None) for key in
                   ("CAVR_WBC_NATIVE_OSQP_DLL", "CAVR_WBC_NATIVE_P1_DLL")}
        ledger.note("BACKEND_FREEZE", {"backends": BACKENDS, "disabled_native_env": ignored})
        import mujoco
        import numpy as np
        import osqp
        from dataclasses import asdict
        from cavr_wbc.control.e2b_dynamic import DynamicWBC, DynamicWBCConfig
        from cavr_wbc.control.step12_validation import load_acceptance_config
        from cavr_wbc.control.step12_p1 import (
            capture_identity, compare_identities, evaluate_constant_torque_hold,
            StructuralIdentityError,
        )
        from cavr_wbc.platforms.go2_mujoco import extract_actuator_joint_map
        acceptance = load_acceptance_config(ACCEPTANCE)
        ledger.note("RUNTIME", {"python": sys.version, "numpy": np.__version__,
                               "mujoco": mujoco.__version__, "osqp": osqp.__version__,
                               "acceptance": acceptance.manifest()})
        for index, scenario in enumerate(selected_cases()):
            cid = scenario["scenario_id"]
            case_call = "case:" + cid
            ledger.begin("case", case_call, {"scenario": scenario})
            try:
                def fixture():
                    model = mujoco.MjModel.from_xml_path(MODEL_PATH.as_posix())
                    data = mujoco.MjData(model)
                    key = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_KEY, "home")
                    if key < 0:
                        raise ValueError("Frozen home keyframe missing")
                    mujoco.mj_resetDataKeyframe(model, data, key)
                    cr, sr = math.cos(scenario["initial_roll"] / 2), math.sin(scenario["initial_roll"] / 2)
                    cp, sp = math.cos(scenario["initial_pitch"] / 2), math.sin(scenario["initial_pitch"] / 2)
                    data.qpos[3:7] = [cr * cp, sr * cp, cr * sp, sr * sp]
                    data.qvel[6:9] = 0
                    ledger.record_call("forward", cid + ":fixture_forward",
                                       lambda: mujoco.mj_forward(model, data), {"propagation": False})
                    return model, data
                # Native objects must not be serialized as numerical evidence.
                holder = []
                def initialize():
                    holder.extend(fixture())
                    m, d = holder
                    return {"qpos": d.qpos.copy(), "qvel": d.qvel.copy(), "ctrl": d.ctrl.copy(),
                            "time": float(d.time), "timestep": float(m.opt.timestep),
                            "integrator": int(m.opt.integrator)}
                ledger.record_call("fixture", cid + ":fixture", initialize, {"scenario": scenario})
                model, data = holder
                stage_index = 0

                def solve_callback(phase, payload, solve):
                    nonlocal stage_index
                    if phase == "after":
                        ledger.note("STAGE_RETURNED", {"case_id": cid, "stage": payload["stage"]})
                        return None
                    stage_index += 1
                    sid = cid + ":" + payload["stage"]
                    raw_problem = {k: payload[k].toarray() if hasattr(payload[k], "toarray") else payload[k]
                                   for k in ("P", "q", "A", "l", "u")}
                    meta = {"case_id": cid, "stage": payload["stage"], "problem": raw_problem}
                    if index == 2 and payload["stage"] == "B2_stage2":
                        return ledger.record_call("injection", sid, lambda: {
                            "x": None, "status": "primal infeasible", "status_val": 3,
                            "iterations": None, "solve_time_s": None, "solve_wall_time_s": None,
                            "setup_time_s": None, "update_time_s": None,
                            "primal_residual": None, "dual_residual": None,
                            "real_optimizer_called": False, "callback_injection": True,
                        }, meta)
                    return ledger.record_call("solver", sid, solve, meta)

                workspace_start = time.perf_counter_ns()
                ctrl = DynamicWBC(model, DynamicWBCConfig(), solve_callback=solve_callback,
                                  acceptance_config=acceptance)
                ledger.note("WORKSPACE_CONSTRUCTED", {"case_id": cid,
                    "duration_ns": time.perf_counter_ns() - workspace_start,
                    "solver_calls": ctrl.solver_calls, "solver_setup_calls": ctrl.solver_setup_calls,
                    "l0_mapping": ctrl.l0_mapping})
                if ctrl.solver_calls or ctrl.solver_setup_calls:
                    raise RuntimeError("Workspace construction invoked hidden solver work")
                mapping = extract_actuator_joint_map(model)
                health = np.ones(model.nu)
                fr = [i for i, row in enumerate(mapping) if row.actuator_name == "FR_thigh"]
                if len(fr) != 1:
                    raise ValueError("FR_thigh mapping mismatch")
                health[fr[0]] = scenario["health"]
                target = {"desired_base_accel": [0.0] * 6,
                          "desired_joint_accel": [0.0] * model.nu,
                          "task_weights": [1.0] * (6 + model.nu),
                          "roll": 0.0, "pitch": 0.0, "com_height": 0.27,
                          "com_velocity": scenario["speed_mps"]}
                config = {"controller": asdict(ctrl.cfg), "acceptance": acceptance.manifest(),
                          "backends": BACKENDS, "fault": "FR_thigh", "contact_mode": "four_point_go2_home",
                          "horizon_s": 1.0, "checkpoints": 21, "deadline_s": 0.020}
                backup_id = cid + ":constant_hold:0001"
                capture_ns = time.perf_counter_ns()
                pre_state = capture_identity(model, data, np.zeros(model.nu), health, config,
                    backup_id, model_path=MODEL_PATH, target=target)
                ledger.note("STATE_CAPTURED", {"case_id": cid, "monotonic_ns": capture_ns,
                    "identity": pre_state, "command_note": "zero placeholder before B2; never dispatched"})
                b2_start = time.perf_counter_ns()
                wb = ledger.record_call("b2_compute", cid + ":compute",
                    lambda: ctrl.compute(data, "B2", health, target), {"case_id": cid, "capture_ns": capture_ns})
                returned_ns = time.perf_counter_ns()
                ledger.note("COMMAND_RETURN", {"case_id": cid, "returned_ns": returned_ns,
                    "stage1": ctrl.last_stage1_snapshot, "stage2": ctrl.last_stage2_snapshot,
                    "stage1_witness": ctrl.last_stage1_witness})
                post_state = capture_identity(model, data, np.zeros(model.nu), health, config,
                    backup_id, model_path=MODEL_PATH, target=target)
                capture_comparison = compare_identities(pre_state, post_state)
                ledger.note("CAPTURE_TO_COMMAND_STATE_CHECK", {
                    "case_id": cid, "comparison": capture_comparison, "actual_identity": post_state})
                if not capture_comparison["identity_equal"]:
                    raise StructuralIdentityError("B2 capture state changed before P1 submission")
                result = {"scenario": scenario, "backup_id": backup_id,
                    "backup_kind": "CONSTANT_TORQUE_HOLD", "b2": wb,
                    "b2_elapsed_s": (returned_ns - b2_start) / 1e9,
                    "b2_deadline_met": returned_ns - b2_start <= 20_000_000,
                    "capture_ns": capture_ns, "returned_ns": returned_ns,
                    "execution_integrity": "RECORDED", "stage_events": stage_index,
                    "v1": wb.get("v1_valid", False),
                    "input_receive_identity": "NOT_ASSESSED_NO_P1"}
                if wb.get("success") and wb.get("v1_valid") and wb.get("tau") is not None:
                    command = np.asarray(wb["tau"], dtype=float)
                    sender = capture_identity(model, data, command, health, config,
                        backup_id, model_path=MODEL_PATH, target=target)
                    ledger.note("SENDER_SUBMISSION", {"case_id": cid, "identity": sender})
                    p1_index = 0
                    def record_p1(kind, fn, metadata):
                        nonlocal p1_index
                        p1_index += 1
                        return ledger.record_call(kind, cid + f":p1:{p1_index}:{kind}", fn,
                                                  {"case_id": cid, **metadata})
                    p1 = evaluate_constant_torque_hold(model, data, command, health, config,
                        backup_id, sender_identity=sender, model_path=MODEL_PATH,
                        target=target, record_call=record_p1)
                    result["p1"] = p1
                    result["input_receive_identity"] = "VERIFIED_AT_RECEIVER"
                    result["coupled_trace"] = True
                    result["capture_to_p1_end_s"] = (p1["p1_ended_perf_counter_ns"] - capture_ns) / 1e9
                    result["end_to_end_deadline_result"] = (
                        "MET" if result["capture_to_p1_end_s"] <= 0.020 else "DEADLINE_MISS")
                else:
                    result["p1"] = {"sampled_physical_result": "NOT_RUN_NO_VALID_COMMAND",
                                    "deadline_result": "NOT_ASSESSED", "interval_points": []}
                    result["coupled_trace"] = False
                    result["end_to_end_deadline_result"] = "NOT_ASSESSED_NO_VALID_COMMAND"
                result["real_optimizer_calls"] = ctrl.real_optimizer_calls
                result["callback_injections"] = ctrl.callback_injections
                result["stage1_witness"] = ctrl.last_stage1_witness
                print(f"CASE_RECORDED {cid} V1={result['v1']} P1={result['p1']['sampled_physical_result']}", flush=True)
                ledger.end(case_call, result)
            except BaseException as exc:
                if getattr(exc, "receiver_identity", None) is not None:
                    ledger.note("RECEIVER_IDENTITY_ERROR", {"case_id": cid,
                        "receiver_identity": exc.receiver_identity,
                        "identity_comparison": exc.identity_comparison})
                ledger.error(case_call, exc)
                raise
        ledger.note("BATCH_FINISHED", {"counts": ledger.counts})
    except BaseException as exc:
        ledger.note("BATCH_STOPPED", {"error_type": type(exc).__name__, "error": str(exc),
                                     "traceback": traceback.format_exc()})
        raise
    finally:
        ledger.close()


def _read_complete_events(path):
    if not path.exists():
        return []
    lines = path.read_text(encoding="utf-8").splitlines()
    events = []
    for line in lines:
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            break  # monitoring only; final reconstruction checks integrity
    return events


def _report(output, manifest, reconstruction, exitcode, timeout_reason):
    # Final no-solve collector after the only numerical child has exited.
    calls = reconstruction["calls"]
    values = list(calls.values()) if isinstance(calls, dict) else calls
    rows = [c["terminal"]["result"] for c in values
            if c.get("kind") == "case" and c.get("state") == "END"]
    completed = (len(rows) == 3 and not timeout_reason and exitcode == 0
                 and reconstruction["complete_jsonl"]
                 and reconstruction["budget_within_protocol"]
                 and not reconstruction["unknown_call_ids"]
                 and not reconstruction.get("reconstruction_error"))
    confirmed_solver_calls = sum(c.get("kind") == "solver" and c.get("state") == "END"
        and c["terminal"]["result"].get("real_optimizer_called") is True for c in values)
    reserved_solver_calls = reconstruction["counts"].get("solver")
    completed_ids = {r["scenario"]["scenario_id"] for r in rows}
    incomplete = []
    for cid in CASE_IDS:
        if cid in completed_ids:
            continue
        call = calls.get("case:" + cid)
        incomplete.append({"case_id": cid,
            "state": "NOT_RUN" if call is None else call["state"],
            "reason": timeout_reason or reconstruction.get("reconstruction_error")
                      or "STOPPED_AFTER_STRUCTURAL_ERROR",
            "terminal_evidence": None if call is None else call["terminal"]})
    natural_primal_infeasible = any(c.get("kind") == "solver" and c.get("state") == "END"
        and c["terminal"]["result"].get("status_val") == 3 for c in values)
    result = {"run_id": RUN_ID, "execution_integrity": "COMPLETED_RECORDED" if completed else "INCOMPLETE",
              "process_exitcode": exitcode, "timeout_reason": timeout_reason,
              "counts": reconstruction["counts"], "unknown_call_ids": reconstruction["unknown_call_ids"],
              "cases": rows, "incomplete_cases": incomplete,
              "not_run_case_ids": [c["case_id"] for c in incomplete if c["state"] == "NOT_RUN"],
              "complete_jsonl": reconstruction["complete_jsonl"],
              "budget_within_protocol": reconstruction["budget_within_protocol"],
              "reconstruction_error": reconstruction.get("reconstruction_error"),
              "partial_tail_hex": reconstruction.get("partial_tail_hex"),
              "confirmed_real_solver_calls": confirmed_solver_calls,
              "reserved_solver_calls": reserved_solver_calls,
              "real_solver_call_interval": [confirmed_solver_calls, reserved_solver_calls],
              "natural_status_3_observed": natural_primal_infeasible,
              "historical_cumulative_calls": "UNKNOWN_UNCHANGED",
              "unconditional_pass": None, "coupled_trace_count": sum(bool(r["coupled_trace"]) for r in rows)}
    dump_new(output / "CASE_RESULTS.json", result)
    lines = ["# STEP12 固定输入组件结果", "", "## Material Passport", "",
             "- Origin Skill: experiment-agent", "- Origin Mode: run",
             "- Verification Status: UNVERIFIED（一次组件执行，不是复现实验或连续安全证书）",
             "- Version Label: step12_bounded_integration_v1", "", "## 结果", "",
             f"执行记录状态：{result['execution_integrity']}；进程退出码：{exitcode}；硬超时：{timeout_reason}。",
             "", "| 固定输入 | Stage1 / Stage2 原始状态 | V1 / 返回策略 | P1 物理结果 | B2 ms / 20ms | P1 ms / 20ms |",
             "|---|---|---|---|---|---|"]
    for r in rows:
        stage_calls = [c for key, c in calls.items() if key.startswith(r['scenario']['scenario_id'] + ':B2_stage')]
        stage_statuses = [str(c['terminal']['result'].get('status_val'))
            if c['state'] == 'END' else c['state'] for c in stage_calls]
        p1_ms = r['p1'].get('p1_wall_time_s')
        p1_ms = 'NOT_RUN' if p1_ms is None else f'{p1_ms * 1000:.3f}'
        lines.append(f"| {r['scenario']['scenario_id']} | {' / '.join(stage_statuses)} | {r['v1']} / {r['b2'].get('command_status')} | {r['p1']['sampled_physical_result']} | {r['b2_elapsed_s']*1000:.3f} / {'MET' if r['b2_deadline_met'] else 'MISS'} | {p1_ms} / {r['p1']['deadline_result']} |")
    lines += ["", f"调用计数：`{json.dumps(result['counts'], ensure_ascii=False)}`。",
              f"UNKNOWN 调用：`{result['unknown_call_ids']}`；完整耦合 trace：{result['coupled_trace_count']}/3。",
              f"真实求解确认/预留：{confirmed_solver_calls}/{reserved_solver_calls}，实际调用区间 {result['real_solver_call_interval']}；自然 status=3：{natural_primal_infeasible}。",
              "未完成案例及原因：`" + str(incomplete) + "`。没有补跑或扩大调用数。",
              "", "V1 拒收、迭代上限、物理 REJECT 和 deadline miss 分别保留，数据记录完整不等于物理或实时通过。",
              "本轮 CONSTANT_TORQUE_HOLD 仅评价 1 s / 21 checkpoints；不证明反馈可恢复性、连续安全或终端集不变性。",
              "冻结 Python OSQP 与 PYTHON_MUJOCO_MJ_STEP，使用实际模型时步；冷启动及记录开销计入，不与旧预热后端宣称加速。",
              "", "## 可追溯性", "", f"准备提交：`{manifest['preparation_commit']}`；验收定义提交：`{SOURCE_COMMIT}`。",
              f"纯测试：{manifest['pure_tests']['tests_run']} 项，guard 违规 {manifest['pure_tests']['guard_violations']}；命令与源码 hash 见 manifest。",
              "数值命令：`" + manifest['numerical_command'] + "`（唯一一次）。",
              "准备时 Git 状态为 clean；本轮修改文件：`" + ', '.join(manifest['changed_files']) + "`。执行后的四个工件在本 run_id 目录追加交付；最终提交号由任务收尾报告给出。",
              "逐调用 START/END/ERROR、完整 QP、primal/V1、输入接收、轨迹和时序均索引于 EVENTS.jsonl；配置与预算见 PROTOCOL_AND_MANIFEST.json。",
              "历史累计调用仍为 UNKNOWN；旧准备停止与旧失败不改写。未进入 Tier3/Tier4/DEV/E3，未重跑 STEP02I/E1 或历史证书，未访问禁区项目。",
              "", "## 下一步", "",
              "唯一建议：依据本次首个未通过的数值或接口条件，另行冻结下一步方案，不重复本组三输入。",
              "主要研究问题：**预测恢复性约束相对损伤感知软任务 WBC/HQP 和瞬时任务重构，能否减少后续不可恢复状态，同时保留更多原始任务效用？**",
              "B2 fallback、日志及局部 V1 不是该问题的答案。旧 P1 延迟不构成所有算法的下界；在线主张需要明确备份/时序语义及预算内闭环对照，离线研究须另立协议。当前仍是实现和组件证据修复阶段，并非投稿就绪。", ""]
    with (output / "REPORT.md").open("x", encoding="utf-8", newline="\n") as stream:
        stream.write("\n".join(lines))
    return result


def main():
    from cavr_wbc.experiments.step12_ledger import (
        create_run_directory, reconstruct_events, append_terminal_event,
    )
    os.chdir(ROOT)
    manifest = _make_manifest()
    output = create_run_directory(OUTPUT_ROOT, RUN_ID)
    dump_new(output / "PROTOCOL_AND_MANIFEST.json", manifest)
    process = mp.get_context("spawn").Process(target=_batch_worker, args=(str(output),))
    start = time.perf_counter_ns()
    timeout_reason = None
    try:
        process.start()
        print(f"RUN_STARTED run_id={RUN_ID} worker_pid={process.pid} case_limit=60s batch_limit=180s", flush=True)
        while process.is_alive():
            now = time.perf_counter_ns()
            events = _read_complete_events(output / "EVENTS.jsonl")
            timeout_reason = hard_timeout_reason(events, now, start)
            if timeout_reason:
                print(f"HARD_TIMEOUT {timeout_reason}; terminating only worker PID {process.pid}; no retry", flush=True)
                break
            process.join(0.1)
    except BaseException as exc:
        timeout_reason = f"SUPERVISOR_ERROR:{type(exc).__name__}:{exc}"
    finally:
        # Never leave an orphan numerical worker if monitoring itself fails.
        if process.is_alive():
            process.terminate()
            process.join(10)
            if process.is_alive():
                process.kill()
                process.join()
        elif process.pid is not None:
            process.join()
    reconstruction = final_reconstruction(output / "EVENTS.jsonl")
    if reconstruction["complete_jsonl"] and not reconstruction.get("reconstruction_error"):
        append_terminal_event(output / "EVENTS.jsonl", "SUPERVISOR_WORKER_EXIT_CONFIRMED", {
            "worker_pid": process.pid, "exitcode": process.exitcode,
            "termination_reason": timeout_reason, "no_retry": True})
        reconstruction = reconstruct_events(output / "EVENTS.jsonl")
    result = _report(output, manifest, reconstruction, process.exitcode, timeout_reason)
    print(json.dumps({"output": str(output), "execution_integrity": result["execution_integrity"],
                      "counts": result["counts"], "cases": len(result["cases"])}, ensure_ascii=False), flush=True)
    return 0 if result["execution_integrity"] == "COMPLETED_RECORDED" else 2


def hard_timeout_reason(events, now_ns, batch_start_ns):
    starts = {e.get("call_id"): e for e in events
              if e.get("event") == "START" and e.get("kind") == "case"}
    # Check both open and already-closed cases.  A worker can finish a case
    # between watchdog polls; that case must still consume the 60 s budget and
    # must not silently authorize dispatch of the next fixed input.
    for call_id, start in starts.items():
        terminals = [e for e in events
                     if e.get("event") in ("END", "ERROR")
                     and e.get("call_id") == call_id]
        end_ns = terminals[-1].get("perf_counter_ns") if terminals else now_ns
        if end_ns - start["perf_counter_ns"] >= 60_000_000_000:
            return "CASE_60S_HARD_TIMEOUT"
    # The 180 s wall is measured from the supervisor's pre-dispatch clock,
    # independent of any child event timestamps.
    if now_ns - batch_start_ns >= 180_000_000_000:
        return "BATCH_180S_HARD_TIMEOUT"
    return None


def final_reconstruction(path):
    from cavr_wbc.experiments.step12_ledger import reconstruct_events
    try:
        return reconstruct_events(path)
    except Exception as exc:
        # Invalid/missing evidence cannot establish zero numerical dispatch.
        return {"calls": {}, "counts": {}, "unknown_call_ids": ["UNRECONSTRUCTABLE_LEDGER"],
                "complete_jsonl": False, "budget_within_protocol": False,
                "reconstruction_error": f"{type(exc).__name__}: {exc}"}


if __name__ == "__main__":
    raise SystemExit(main())
