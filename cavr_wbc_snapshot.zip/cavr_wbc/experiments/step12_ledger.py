"""Append-only, write-ahead accounting for the single STEP12 numerical batch.

This module imports only the standard library and never initializes a model,
solves a problem, or propagates state.  START is flushed and fsynced before a
callable is invoked.  A START without END/ERROR consumes its budget forever and
is reconstructed as UNKNOWN; this module deliberately has no resume operation.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import fields, is_dataclass
from datetime import datetime, timezone
from enum import Enum
import json
import math
import os
from pathlib import Path
import threading
import time
import traceback
from typing import Any, Callable, TypeVar


T = TypeVar("T")
SCHEMA_VERSION = "step12_append_only_ledger_v1"
PROTOCOL_LIMITS = {
    "case": 3,
    "b2_compute": 3,
    "solver": 5,
    "injection": 1,
    "stage": 6,
    "rollout": 3,
    "fixture": 3,
}
CALL_KINDS = frozenset(PROTOCOL_LIMITS).difference({"stage"}) | {"forward"}
RESERVED_EVENTS = frozenset({"START", "END", "ERROR"})


class LedgerError(RuntimeError):
    """A ledger identity, persistence, or integrity contract was violated."""


class BudgetExceeded(LedgerError):
    """A proposed START would exceed the frozen call budget."""


class DuplicateCallError(LedgerError):
    """A call identity has already consumed its one permitted attempt."""


def json_safe(value: Any, _seen: set[int] | None = None) -> Any:
    """Preserve evidence in strict JSON, tagging NaN/Inf rather than clipping.

    Arrays/scalars exposing ``tolist``/``item`` are accepted without importing
    NumPy.  Object and byte fallbacks are explicitly tagged, never silently
    replaced by null.  Identity code must record units/dtype/shape separately;
    this serializer does not assert semantic equivalence.
    """
    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float):
        if math.isfinite(value):
            return value
        return {"__nonfinite__": "NaN" if math.isnan(value) else
                ("+Infinity" if value > 0 else "-Infinity")}
    if isinstance(value, Enum):
        return json_safe(value.value, _seen)
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, (bytes, bytearray, memoryview)):
        return {"__bytes_hex__": bytes(value).hex()}
    seen = set() if _seen is None else _seen
    identity = id(value)
    if identity in seen:
        raise ValueError("Cyclic evidence cannot be serialized")
    seen.add(identity)
    try:
        if isinstance(value, Mapping):
            if not all(isinstance(key, str) for key in value):
                return {"__mapping_items__": [
                    [json_safe(key, seen), json_safe(item, seen)]
                    for key, item in value.items()
                ]}
            return {key: json_safe(item, seen) for key, item in value.items()}
        if isinstance(value, (list, tuple)):
            return [json_safe(item, seen) for item in value]
        if isinstance(value, (set, frozenset)):
            return {"__set_items__": [json_safe(item, seen)
                                      for item in sorted(value, key=repr)]}
        if is_dataclass(value) and not isinstance(value, type):
            return {field.name: json_safe(getattr(value, field.name), seen)
                    for field in fields(value)}
        if callable(getattr(value, "toarray", None)):
            return json_safe(value.toarray(), seen)
        if callable(getattr(value, "tolist", None)):
            return json_safe(value.tolist(), seen)
        if callable(getattr(value, "item", None)):
            return json_safe(value.item(), seen)
        if hasattr(value, "__dict__"):
            return {"__object_type__": type(value).__module__ + "." +
                    type(value).__qualname__, "fields": json_safe(vars(value), seen)}
        return {"__unsupported_type__": type(value).__module__ + "." +
                type(value).__qualname__, "repr": repr(value)}
    finally:
        seen.remove(identity)


def _stamp() -> dict[str, Any]:
    return {
        "utc": datetime.now(timezone.utc).isoformat(timespec="microseconds"),
        "perf_counter_ns": time.perf_counter_ns(),
        "pid": os.getpid(),
    }


def _encoded(record: Mapping[str, Any]) -> str:
    return json.dumps(json_safe(record), ensure_ascii=True, allow_nan=False,
                      separators=(",", ":")) + "\n"


def _limits(limits: Mapping[str, int] | None) -> dict[str, int]:
    result = dict(PROTOCOL_LIMITS)
    for key, value in (limits or {}).items():
        if key not in result:
            raise ValueError(f"Unknown budget: {key}")
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ValueError(f"Budget {key} must be a nonnegative integer")
        if value > PROTOCOL_LIMITS[key]:
            raise ValueError(f"Budget {key} exceeds the frozen STEP12 maximum")
        result[key] = value
    return result


def _budget_keys(kind: str) -> tuple[str, ...]:
    return (kind, "stage") if kind in {"solver", "injection"} else (kind,)


def create_run_directory(output_root: str | Path, run_id: str) -> Path:
    """Create one exclusive run directory; an existing directory is fatal."""
    if (not isinstance(run_id, str) or not run_id or run_id in {".", ".."}
            or "/" in run_id or "\\" in run_id or ":" in run_id):
        raise ValueError("run_id must be a single directory name")
    root = Path(output_root)
    root.mkdir(parents=True, exist_ok=True)
    path = root / run_id
    path.mkdir(exist_ok=False)
    return path


def claim_launch(marker_path: str | Path, metadata: Any = None) -> Path:
    """Optional task-level exclusive marker, consumed before worker launch."""
    path = Path(marker_path)
    payload = _encoded({"schema_version": SCHEMA_VERSION,
                        "event": "NUMERICAL_ENTRY_CLAIMED", **_stamp(),
                        "metadata": metadata})
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(payload)
        stream.flush()
        os.fsync(stream.fileno())
    return path


class EventLedger:
    """A single writer with immutable identities and start-counted budgets.

    ``solver`` and ``injection`` also consume ``stage``. ``forward`` counts
    separately and is not a propagation/rollout. Limits may only be reduced.
    Case IDs should be stable and included in call metadata for monitoring.
    """

    def __init__(self, path: str | Path,
                 limits: Mapping[str, int] | None = None):
        self.path = Path(path)
        self.limits = _limits(limits)
        self._counts = {key: 0 for key in (*PROTOCOL_LIMITS, "forward")}
        self._starts: dict[str, dict[str, Any]] = {}
        self._finished: set[str] = set()
        self._lock = threading.RLock()
        self._broken = False
        self._sequence = 0
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_APPEND
        flags |= getattr(os, "O_BINARY", 0)
        fd = os.open(self.path, flags, 0o600)
        self._stream = os.fdopen(fd, "a", encoding="utf-8", newline="\n")

    @property
    def counts(self) -> dict[str, int]:
        with self._lock:
            return dict(self._counts)

    @property
    def events(self) -> list[dict[str, Any]]:
        return reconstruct_events(self.path)["events"]

    def _append(self, event: str, **fields_: Any) -> dict[str, Any]:
        if self._broken or self._stream.closed:
            raise LedgerError("Ledger is closed or persistence previously failed")
        record = json_safe({"schema_version": SCHEMA_VERSION,
                            "sequence": self._sequence + 1, "event": event,
                            **_stamp(), **fields_})
        encoded = _encoded(record)
        try:
            self._stream.write(encoded)
            self._stream.flush()
            os.fsync(self._stream.fileno())
        except BaseException:
            self._broken = True
            raise
        self._sequence += 1
        return record

    def note(self, event: str, metadata: Any = None) -> dict[str, Any]:
        """Record non-call timing/evidence; cannot forge START/END/ERROR."""
        if not isinstance(event, str) or not event or event in RESERVED_EVENTS:
            raise ValueError("note requires a non-reserved event name")
        with self._lock:
            return self._append(event, metadata=metadata, counts=self._counts)

    def begin(self, kind: str, call_id: str,
              metadata: Any = None) -> dict[str, Any]:
        with self._lock:
            if kind not in CALL_KINDS:
                raise ValueError(f"Unknown call kind: {kind}")
            if not isinstance(call_id, str) or not call_id:
                raise ValueError("call_id must be a nonempty stable string")
            if call_id in self._starts:
                raise DuplicateCallError(f"Call identity already consumed: {call_id}")
            counts = dict(self._counts)
            for key in _budget_keys(kind):
                if key in self.limits and counts[key] >= self.limits[key]:
                    raise BudgetExceeded(f"STEP12 {key} budget exhausted")
                counts[key] += 1
            record = self._append("START", kind=kind, call_id=call_id,
                                  metadata=metadata, counts=counts)
            self._starts[call_id] = record
            self._counts = counts
            return record

    def _finish(self, call_id: str, event: str, **fields_: Any) -> dict[str, Any]:
        with self._lock:
            if call_id not in self._starts or call_id in self._finished:
                raise LedgerError(f"Call is not unfinished: {call_id}")
            start = self._starts[call_id]
            record = self._append(
                event, kind=start["kind"], call_id=call_id,
                start_perf_counter_ns=start["perf_counter_ns"],
                elapsed_ns=time.perf_counter_ns() - start["perf_counter_ns"],
                metadata=start["metadata"], counts=self._counts, **fields_)
            self._finished.add(call_id)
            return record

    def end(self, call_id: str, result: Any = None) -> dict[str, Any]:
        return self._finish(call_id, "END", result=result)

    def error(self, call_id: str, exc: BaseException) -> dict[str, Any]:
        return self._finish(call_id, "ERROR", error={
            "type": type(exc).__module__ + "." + type(exc).__qualname__,
            "message": str(exc),
            "traceback": "".join(traceback.format_exception(type(exc), exc,
                                                            exc.__traceback__)),
        })

    def record_call(self, kind: str, call_id: str, fn: Callable[[], T],
                    metadata: Any = None) -> T:
        self.begin(kind, call_id, metadata)
        try:
            result = fn()
        except Exception as exc:
            self.error(call_id, exc)
            raise
        # BaseException interruption deliberately leaves the START unfinished.
        self.end(call_id, result)
        return result

    def close(self) -> None:
        with self._lock:
            self._stream.close()

    def __enter__(self) -> "EventLedger":
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()


def reconstruct_events(path: str | Path) -> dict[str, Any]:
    """Read accounting without reopening a writer or dispatching any action.

    A possibly interrupted trailing write is preserved as raw evidence and is
    not treated as a complete event. Malformed complete lines are fatal.
    """
    raw = Path(path).read_bytes()
    lines = raw.splitlines(keepends=True)
    partial_tail = b""
    if lines and not lines[-1].endswith(b"\n"):
        partial_tail = lines.pop()
    events = []
    counts = {key: 0 for key in (*PROTOCOL_LIMITS, "forward")}
    calls: dict[str, dict[str, Any]] = {}
    for line_number, line in enumerate(lines, 1):
        try:
            event = json.loads(line)
        except (ValueError, UnicodeDecodeError) as exc:
            raise LedgerError(f"Malformed complete event at line {line_number}") from exc
        if (not isinstance(event, dict) or event.get("sequence") != line_number
                or event.get("schema_version") != SCHEMA_VERSION):
            raise LedgerError(f"Invalid ledger envelope at line {line_number}")
        event_type = event.get("event")
        if event_type == "START":
            call_id, kind = event.get("call_id"), event.get("kind")
            if not isinstance(call_id, str) or not call_id or kind not in CALL_KINDS:
                raise LedgerError(f"Invalid START identity at line {line_number}")
            if call_id in calls:
                raise LedgerError(f"Duplicate START identity: {call_id}")
            for key in _budget_keys(kind):
                counts[key] += 1
            calls[call_id] = {"kind": kind, "state": "UNKNOWN", "start": event,
                              "terminal": None}
        elif event_type in {"END", "ERROR"}:
            call_id = event.get("call_id")
            call = calls.get(call_id)
            if (call is None or call["terminal"] is not None
                    or event.get("kind") != call["kind"]):
                raise LedgerError(f"Unmatched terminal event at line {line_number}")
            call["state"] = event_type
            call["terminal"] = event
        if "counts" in event and event["counts"] != counts:
            raise LedgerError(f"Counter snapshot mismatch at line {line_number}")
        events.append(event)
    return {
        "events": events, "counts": counts, "calls": calls,
        "unknown_call_ids": [key for key, value in calls.items()
                             if value["state"] == "UNKNOWN"],
        "partial_tail_hex": partial_tail.hex() or None,
        "complete_jsonl": not partial_tail,
        "budget_within_protocol": all(counts[key] <= limit
                                       for key, limit in PROTOCOL_LIMITS.items()),
    }


def append_terminal_event(path: str | Path, event: str,
                          metadata: Any = None) -> dict[str, Any]:
    """Append a supervisor observation AFTER the worker is confirmed dead.

    The caller owns process termination/join and must never call this while the
    writer lives. This does not complete UNKNOWN calls or enable a new entry.
    A partial trailing write is preserved and prohibits further JSONL appends.
    """
    if not isinstance(event, str) or not event or event in RESERVED_EVENTS:
        raise ValueError("Supervisor event must not be START, END, or ERROR")
    snapshot = reconstruct_events(path)
    if not snapshot["complete_jsonl"]:
        raise LedgerError("Partial trailing evidence must remain unmodified")
    record = json_safe({"schema_version": SCHEMA_VERSION,
                        "sequence": len(snapshot["events"]) + 1,
                        "event": event, **_stamp(), "metadata": metadata,
                        "counts": snapshot["counts"], "supervisor": True})
    flags = os.O_WRONLY | os.O_APPEND | getattr(os, "O_BINARY", 0)
    fd = os.open(Path(path), flags)
    with os.fdopen(fd, "a", encoding="utf-8", newline="\n") as stream:
        stream.write(_encoded(record))
        stream.flush()
        os.fsync(stream.fileno())
    return record
