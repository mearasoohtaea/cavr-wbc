"""Bounded STEP13 recoverability-mechanism pilot.

This module intentionally uses a deterministic fixed-support surrogate.  It is
not a MuJoCo or solver runner, and importing it never starts a numerical job.
The surrogate exists to test the mechanism and paired-accounting protocol
before a separately authorised physical panel is attempted.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping

from cavr_wbc.control.step13_recoverability import evaluate_method

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_OUT = ROOT / "artifacts" / "step13_recoverability_mechanism_pilot_20260922"
HEALTH_LEVELS = (0.25, 0.0)
LAYERS = ("R1", "R2", "R3")
METHODS = (
    "B1_FAULT_AWARE_SOFT_WBC",
    "P0_INSTANT_PROJECTION",
    "P1_RECOVERABILITY_FILTER",
)
SEEDS_PER_CELL = 10
EXPECTED_CASES = len(HEALTH_LEVELS) * len(LAYERS) * SEEDS_PER_CELL
DEADLINE_MS = 20.0


def _sha(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def _finite(x: float) -> bool:
    return isinstance(x, (int, float)) and math.isfinite(float(x))


def build_case_manifest() -> List[Dict[str, Any]]:
    """Return the frozen 2-health x 3-layer x 10-seed panel.

    The parity construction deliberately supplies at least half cases with a
    negative future braking margin while all cases remain instantaneously
    feasible.  It is deterministic and contains no case-search loop.
    """
    rows: List[Dict[str, Any]] = []
    ordinal = 0
    for layer_index, layer in enumerate(LAYERS):
        for health_index, health in enumerate(HEALTH_LEVELS):
            p_max = {"R1": 0.35, "R2": 0.30, "R3": 0.25}[layer]
            for seed_index in range(SEEDS_PER_CELL):
                seed = 1_000 * (layer_index + 1) + (25 if health > 0 else 0) + seed_index
                # The case manifest freezes the first five states in each cell
                # as constructive counterexamples.  This gives exactly 30/60
                # before any method is evaluated; labels are never outcome-
                # dependent.
                unsafe = seed_index < 5
                # Safe rows have low speed; unsafe rows have the same present
                # feasibility but insufficient distance to brake in the future.
                if unsafe:
                    v = 0.25 + 0.01 * (seed_index % 3)
                else:
                    # At zero authority a non-advancing state is the explicit
                    # a(rho)=0 branch that remains recoverable.
                    v = 0.05 + 0.01 * (seed_index % 3) if health > 0 else 0.0
                p = p_max - (0.09 if not unsafe else 0.015)
                # A fully disabled actuator has no recoverable braking authority.
                a_brake = 0.16 if health > 0 else 0.0
                health_tag = "H025" if health > 0 else "H000"
                rows.append({
                    "case_id": f"{layer}_{health_tag}_S{seed_index:02d}",
                    "ordinal": ordinal,
                    "seed": seed,
                    "health": health,
                    "layer": layer,
                    "fault": "FR_thigh",
                    "support": ["FL", "FR", "RL", "RR"],
                    "instantaneous_feasible": True,
                    "p": p,
                    "v": v,
                    "p_max": p_max,
                    "a_brake": a_brake,
                    "backup_id": f"STEP13_{layer}_{health_tag}_S{seed_index:02d}_BK",
                    "fault_onset_s": 0.50,
                    "task_target_speed": 0.20,
                    "stop_horizon_s": 1.0,
                    "constructive_future_risk": unsafe,
                })
                ordinal += 1
    if len(rows) != EXPECTED_CASES:
        raise RuntimeError(f"fixed panel cardinality changed: {len(rows)} != {EXPECTED_CASES}")
    return rows


def braking_margin(case: Mapping[str, Any]) -> float:
    """Analytic fixed-support double-integrator stopping margin in metres."""
    p, v, p_max, a = (float(case[k]) for k in ("p", "v", "p_max", "a_brake"))
    if not all(_finite(x) for x in (p, v, p_max, a)) or a < 0 or v < 0:
        raise ValueError("non-finite or invalid surrogate state")
    return float(evaluate_method("P1_RECOVERABILITY_FILTER", p=p, p_max=p_max, v=v,
                                 rho=float(case["health"]), acceleration=a).braking.h_stop)


def _simulate(case: Mapping[str, Any], method: str) -> Dict[str, Any]:
    if method not in METHODS:
        raise ValueError(f"unknown method {method}")
    started_ns = time.perf_counter_ns()
    decision = evaluate_method(method, p=float(case["p"]), p_max=float(case["p_max"]),
                               v=float(case["v"]), rho=float(case["health"]),
                               acceleration=float(case["a_brake"]),
                               instant_feasible=True, projection_feasible=True)
    margin = float(decision.braking.h_stop)
    p1_accept = bool(decision.braking.safe)
    checkpoints = [i / 20.0 for i in range(21)]
    p0, v0, a = float(case["p"]), float(case["v"]), float(case["a_brake"])
    interval_positions = [p0 + v0 * t - 0.5 * a * t * t for t in checkpoints]
    interval_boundary_margins = [float(case["p_max"]) - p for p in interval_positions]
    interval_min_margin = min(interval_boundary_margins)
    # The fixed-support independent evaluator surrogate checks the complete
    # submitted interval; it is not a claim about full MuJoCo dynamics.
    future_unsafe = interval_min_margin < 0.0 or not p1_accept
    projection_penalty = 0.015 if method == METHODS[1] else 0.0
    if method == METHODS[2] and not decision.accepted:
        accepted = False
        safety_failure = False
        stop_reason = "FILTER_REJECTED_FUTURE_MARGIN"
    else:
        accepted = True
        safety_failure = future_unsafe
        stop_reason = "TERMINAL_SET" if not safety_failure else "BOUNDARY_CROSSING"
    utility = max(0.0, 1.0 - abs(float(case["v"]) - float(case["task_target_speed"])) - projection_penalty)
    elapsed_ms = (time.perf_counter_ns() - started_ns) / 1_000_000.0
    if a > 0:
        stopping_distance = (v0 * v0) / (2.0 * a)
        recovery_time = v0 / a
    elif v0 == 0:
        stopping_distance, recovery_time = 0.0, 0.0
    else:
        stopping_distance, recovery_time = None, None
    terminal_arrival = bool(accepted and not safety_failure)
    input_hash = _sha(case)
    task_reference_hash = _sha({"task": "STEP12_ORIGINAL_TASK_REFERENCE", "version": 1})
    return {
        "case_id": case["case_id"], "ordinal": case["ordinal"], "seed": case["seed"],
        "health": case["health"], "layer": case["layer"], "method": method,
        "paired": True, "instantaneous_feasible": True,
        "future_braking_margin_m": margin if math.isfinite(margin) else None,
        "future_braking_margin_class": "SAFE" if p1_accept else "INSUFFICIENT",
        "initial_state_hash": input_hash,
        "task_reference_hash": task_reference_hash,
        "support_contacts": list(case["support"]),
        "method_arm": method,
        "backup_id": case["backup_id"],
        "interval_checkpoints": checkpoints,
        "interval_boundary_margins_m": interval_boundary_margins,
        "filter_accepted": accepted,
        "filter_rejected": not accepted,
        "safety_failure": safety_failure,
        "terminal_set_arrival": terminal_arrival,
        "terminal_status": "ARRIVED" if terminal_arrival else ("REJECTED" if not accepted else "MISSED"),
        "terminal_set_definition": "p<=p_max; v=0; fixed-support contact and actuator bounds",
        "stop_distance_m": stopping_distance,
        "recovery_time_s": recovery_time if terminal_arrival else None,
        "task_utility": utility,
        "task_error": abs(float(case["v"]) - float(case["task_target_speed"])),
        "velocity_initial_m_s": case["v"], "velocity_final_m_s": 0.0 if accepted else case["v"],
        "attitude_error_rad": None, "end_effector_error_m": None,
        "residuals": {"dynamics": None, "contact": None, "friction": None,
                       "scope": "FULL_PHYSICAL_EVALUATOR_NOT_RUN_SURROGATE_ONLY"},
        "margins": {"braking_min_m": margin if math.isfinite(margin) else None,
                    "interval_boundary_min_m": interval_min_margin,
                    "actuator_capacity": float(case["health"])},
        "friction_margin": None, "actuator_margin": float(case["health"]),
        "latency_ms": elapsed_ms,
        "deadline_miss": None,
        "deadline": {"budget_ms": DEADLINE_MS, "status": "DIAGNOSTIC_ONLY_SURROGATE"},
        "solver_status": "SURROGATE_ANALYTIC",
        "solver_calls": 0, "fallback_trigger": None,
        "backup_kind": "PREDICTED_INTERVAL_SCREENING",
        "p1_scope": "OFFLINE_PREDICTIVE_SCREENING",
        "evaluator_scope": "fixed_support_analytic_surrogate; no MuJoCo claim",
        "stop_reason": stop_reason,
        "status": "FAIL" if safety_failure else "PASS",
    }


def run_pilot(cases: Iterable[Mapping[str, Any]], output_dir: Path) -> Dict[str, Any]:
    """Run exactly the frozen panel; never expand or substitute cases."""
    rows = [dict(c) for c in cases]
    if len(rows) != EXPECTED_CASES or len({c.get("case_id") for c in rows}) != EXPECTED_CASES:
        raise RuntimeError("pilot panel cardinality/identity mismatch; refusing auto-expand")
    expected_ids = {c["case_id"] for c in rows}
    output_dir.mkdir(parents=True, exist_ok=False)
    result_rows: List[Dict[str, Any]] = []
    events: List[Dict[str, Any]] = []
    started = time.time()
    for case in rows:
        if not case.get("instantaneous_feasible", False):
            raise RuntimeError(f"structural protocol error: {case['case_id']} not instantaneously feasible")
        for method in METHODS:
            now = time.time()
            events.append({"event": "START", "case_id": case["case_id"], "method": method, "utc": now})
            row = _simulate(case, method)
            row["input_hash"] = _sha(case)
            row["output_hash"] = _sha(row)
            result_rows.append(row)
            events.append({"event": "END", "case_id": case["case_id"], "method": method, "utc": time.time(), "status": row["status"]})
    if {r["case_id"] for r in result_rows} != expected_ids or len(result_rows) != EXPECTED_CASES * len(METHODS):
        raise RuntimeError("paired accounting mismatch")
    output_dir.joinpath("STEP13_RESULTS.jsonl").write_text("".join(json.dumps(r, sort_keys=True) + "\n" for r in result_rows), encoding="utf-8")
    output_dir.joinpath("STEP13_METHOD_EVENTS.jsonl").write_text("".join(json.dumps(e, sort_keys=True) + "\n" for e in events), encoding="utf-8")
    summary = {
        "schema": "step13_pilot_result_v1", "panel_cases": EXPECTED_CASES,
        "methods": list(METHODS), "rows": len(result_rows), "paired": True,
        "health_levels": list(HEALTH_LEVELS), "layers": list(LAYERS),
        "seeds_per_cell": SEEDS_PER_CELL, "deadline_ms": DEADLINE_MS,
        "safety_failure_rate": {m: sum(r["safety_failure"] for r in result_rows if r["method"] == m) / EXPECTED_CASES for m in METHODS},
        "terminal_arrival_rate": {m: sum(r["terminal_set_arrival"] for r in result_rows if r["method"] == m) / EXPECTED_CASES for m in METHODS},
        "filter_rejection_rate": {m: sum(r["filter_rejected"] for r in result_rows if r["method"] == m) / EXPECTED_CASES for m in METHODS},
        "task_utility_mean": {m: sum(r["task_utility"] for r in result_rows if r["method"] == m) / EXPECTED_CASES for m in METHODS},
        "deadline_miss_count": sum(1 for r in result_rows if r["deadline_miss"] is True),
        "status_counts": {m: {s: sum(r["status"] == s for r in result_rows if r["method"] == m) for s in ("PASS", "FAIL")} for m in METHODS},
        "unsafe_constructed_fraction": sum(bool(c["constructive_future_risk"]) for c in rows) / EXPECTED_CASES,
        "runtime_scope": "deterministic fixed-support surrogate only; no MuJoCo or solver calls",
        "deadline_assessment": "NOT_A_REALTIME_CLAIM",
        "started_utc": started, "ended_utc": time.time(), "stop_reason": "FIXED_PANEL_COMPLETE",
    }
    summary["pilot_gate"] = pilot_gate(summary)
    output_dir.joinpath("STEP13_PILOT_RESULT.json").write_text(json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")
    report = [
        "# STEP13 recoverability mechanism pilot", "",
        "This is a deterministic fixed-support surrogate pilot; it is not a MuJoCo or feedback-recovery result.", "",
        f"- Paired cases: {summary['panel_cases']} (methods x3: {summary['rows']} rows)",
        f"- Safety-failure rates: {summary['safety_failure_rate']}",
        f"- Task-utility means: {summary['task_utility_mean']}",
        f"- Deadline misses: {summary['deadline_miss_count']}",
        f"- Pilot gate: {summary['pilot_gate']['stop_reason']}",
        "- Automatic expansion: forbidden; any larger panel requires a new authorisation.",
    ]
    output_dir.joinpath("STEP13_PILOT_REPORT.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    return summary


def pilot_gate(summary: Mapping[str, Any], utility_tolerance: float = 0.05) -> Dict[str, Any]:
    """Evaluate the frozen stop gate; never authorise automatic expansion."""
    sf = summary["safety_failure_rate"]
    utility = summary["task_utility_mean"]
    p1_reduces = float(sf["P1_RECOVERABILITY_FILTER"]) < float(sf["B1_FAULT_AWARE_SOFT_WBC"])
    utility_preserved = float(utility["P1_RECOVERABILITY_FILTER"]) + utility_tolerance >= float(utility["B1_FAULT_AWARE_SOFT_WBC"])
    return {
        "p1_reduces_safety_failure": p1_reduces,
        "p1_preserves_task_utility": utility_preserved,
        "expand_authorized": False,
        "stop_reason": "PILOT_GATE_PASS_BUT_AUTHORISATION_REQUIRED" if (p1_reduces and utility_preserved) else "PILOT_GATE_FAILED_REFRAME_REQUIRED",
    }


def write_protocol(output_dir: Path, cases: List[Mapping[str, Any]]) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    manifest = {
        "schema": "step13_protocol_manifest_v1", "step": "STEP13",
        "panel": {"health_levels": list(HEALTH_LEVELS), "layers": list(LAYERS), "seeds_per_cell": SEEDS_PER_CELL, "cases": EXPECTED_CASES},
        "methods": list(METHODS), "deadline_ms": DEADLINE_MS,
        "p1_definition": "offline predictive recoverability filter using fixed-support double-integrator braking surrogate; not feedback backup",
        "surrogate_mapping": "p,v,p_max,a_brake map sagittal support margin; full-body residuals remain explicit diagnostics",
        "terminal_set": "p <= p_max and v == 0 after finite braking horizon",
        "stop_conditions": ["negative braking margin", "boundary crossing", "solver/deadline result retained", "structural mismatch stops panel"],
        "no_auto_expand": True, "case_manifest_sha256": _sha(cases),
    }
    output_dir.joinpath("STEP13_PROTOCOL_AND_MANIFEST.json").write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")
    with output_dir.joinpath("STEP13_CASE_MANIFEST.csv").open("w", encoding="utf-8", newline="") as f:
        fields = ["case_id", "ordinal", "seed", "health", "layer", "fault", "p", "v", "p_max", "a_brake", "constructive_future_risk"]
        writer = csv.DictWriter(f, fieldnames=fields); writer.writeheader(); writer.writerows({k: c[k] for k in fields} for c in cases)
    output_dir.joinpath("STEP13_METHOD_DEFINITIONS.md").write_text("# STEP13 methods\n\n" + "\n".join(f"- **{m}**" for m in METHODS) + "\n\nP1 is an offline predictive filter surrogate, not feedback backup.\n", encoding="utf-8")
    output_dir.joinpath("STEP13_RECOVERABILITY_SPEC.md").write_text("# STEP13 recoverability specification\n\nFixed-support stopping margin: `h_stop = p_max - p - v^2/(2 a_brake)`; `a_brake=0` is handled explicitly. Negative margin is future recovery failure. No case expansion or substitution is permitted.\n", encoding="utf-8")


def main(argv: List[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--prepare", action="store_true", help="write frozen protocol and case manifest only")
    parser.add_argument("--run", action="store_true", help="run fixed deterministic surrogate pilot")
    parser.add_argument("--output", type=Path, default=DEFAULT_OUT)
    args = parser.parse_args(argv)
    if not (args.prepare or args.run):
        parser.error("explicit --prepare or --run is required; no implicit numerical execution")
    cases = build_case_manifest()
    if args.prepare:
        write_protocol(args.output, cases)
    if args.run:
        write_protocol(args.output, cases)
        run_pilot(cases, args.output / "pilot")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
