"""STEP14 held-out independent recoverability validation.

The runner is deliberately deterministic and dependency-light.  It records a
held-out manifest before any method decision and evaluates every method with a
separate fixed-step evaluator.  This module does not import MuJoCo, OSQP or
the STEP13 braking-margin function and performs no work on import.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import random
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence

from cavr_wbc.evaluation.step14_independent_evaluator import EVALUATOR_CONFIG, EVALUATOR_CONFIG_HASH, evaluate_future

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_OUT = ROOT / "artifacts" / "step14_independent_recoverability_validation_20260923"
FAULT_HEALTH = (0.50, 0.25)
FAULT_FAMILIES = ("R1", "R2", "R3")
METHODS = (
    "B1_FAULT_AWARE_SOFT_WBC",
    "P0_INSTANT_PROJECTION",
    "P1_RECOVERABILITY_FILTER",
    "H_HEALTHY_REFERENCE",
)
SEEDS_PER_CELL = 10
FAULT_CASES = len(FAULT_HEALTH) * len(FAULT_FAMILIES) * SEEDS_PER_CELL
HEALTHY_CASES = 10
TOTAL_CASES = FAULT_CASES + HEALTHY_CASES
CHECKPOINTS = 21
DT = 0.05
HORIZON_S = 1.0
DEADLINE_MS = 20.0
DELTA_U = 0.05  # frozen non-inferiority tolerance, before execution


def append_record(stream, record: Mapping[str, Any]) -> None:
    """Persist a complete record before returning to any experiment action."""
    stream.write(json.dumps(dict(record), sort_keys=True, allow_nan=False) + "\n")
    stream.flush()
    os.fsync(stream.fileno())


def reconstruct_ledger(path: Path) -> Dict[str, Any]:
    """Read-only reconstruction; interrupted calls remain UNKNOWN."""
    states = {}
    partial_tail = None
    for line in path.read_bytes().splitlines(keepends=True):
        if not line.endswith(b"\n"):
            partial_tail = line.hex()
            break
        row = json.loads(line)
        key = (row["case_id"], row["method"])
        event = row["event"]
        if event == "START":
            if key in states:
                raise RuntimeError("duplicate method START")
            states[key] = "UNKNOWN"
        elif event in ("END", "ERROR"):
            if states.get(key) != "UNKNOWN":
                raise RuntimeError("unpaired or duplicate terminal event")
            states[key] = event
        else:
            raise RuntimeError("unknown ledger event")
    return {"calls": [{"case_id": k[0], "method": k[1], "state": v}
                      for k, v in states.items()],
            "unknown_count": sum(v == "UNKNOWN" for v in states.values()),
            "partial_tail_hex": partial_tail}


def _sha(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def _finite(x: Any) -> float:
    y = float(x)
    if not math.isfinite(y):
        raise ValueError("non-finite state")
    return y


def build_heldout_manifest() -> List[Dict[str, Any]]:
    """Create exactly 60 fault and 10 healthy held-out states.

    No future-failure label or P1 margin is stored.  Every method receives the
    same state hash and records this manifest hash in its ledger row.
    """
    out: List[Dict[str, Any]] = []
    ordinal = 0
    for health_i, health in enumerate(FAULT_HEALTH):
        for family_i, family in enumerate(FAULT_FAMILIES):
            for seed_i in range(SEEDS_PER_CELL):
                seed = 14000 + 100 * health_i + 10 * family_i + seed_i
                rng = random.Random(seed)
                # State factory is independent of evaluator and does not derive
                # labels from P1.  Values are intentionally near the boundary.
                p_max = {"R1": 0.36, "R2": 0.31, "R3": 0.26}[family]
                p = p_max - (0.03 + 0.04 * rng.random())
                v = 0.07 + 0.23 * rng.random()
                out.append({
                    "case_id": f"S14_F_{health:.2f}_{family}_{seed_i:02d}",
                    "ordinal": ordinal, "seed": seed, "case_kind": "fault",
                    "fault": "FR_thigh", "health": health, "family": family,
                    "support": ["FL", "FR", "RL", "RR"], "p": p, "v": v,
                    "p_max": p_max, "task_target_speed": 0.20,
                    "fault_onset_s": 0.50, "state_factory": "heldout_seeded_factory_v1",
                    "state_factory_version": "1.0", "contact_order": ["FL", "FR", "RL", "RR"],
                    "contact_identity": "four_foot_geom_centers_v1",
                    "task_ref_hash": _sha({"speed": 0.20, "contract": "STEP14_TASK_V1"}),
                    "disturbance_hash": _sha({"fault": "FR_thigh", "onset": 0.50}),
                    "model_hash": _sha("step14_fixed_support_surrogate_v1"),
                    "instantaneous_feasible": True,
                })
                ordinal += 1
    for seed_i in range(HEALTHY_CASES):
        seed = 15000 + seed_i
        rng = random.Random(seed)
        p_max = 0.40
        out.append({
            "case_id": f"S14_H_{seed_i:02d}", "ordinal": ordinal, "seed": seed,
            "case_kind": "healthy", "fault": None, "health": 1.0,
            "family": "healthy_reference", "support": ["FL", "FR", "RL", "RR"],
            "p": p_max - (0.08 + 0.02 * rng.random()), "v": 0.15 + 0.05 * rng.random(),
            "p_max": p_max, "task_target_speed": 0.20, "fault_onset_s": None,
            "state_factory": "heldout_seeded_factory_v1", "state_factory_version": "1.0",
            "contact_order": ["FL", "FR", "RL", "RR"], "contact_identity": "four_foot_geom_centers_v1",
            "task_ref_hash": _sha({"speed": 0.20, "contract": "STEP14_TASK_V1"}),
            "disturbance_hash": _sha({"fault": None, "onset": None}),
            "model_hash": _sha("step14_fixed_support_surrogate_v1"), "instantaneous_feasible": True,
        })
        ordinal += 1
    for case in out:
        case["initial_state_hash"] = _sha({k: case[k] for k in ("p", "v", "p_max", "health", "support", "fault", "family", "seed")})
    if len(out) != TOTAL_CASES or sum(c["case_kind"] == "fault" for c in out) != FAULT_CASES:
        raise RuntimeError("held-out cardinality changed")
    return out


def write_manifest(output_dir: Path, cases: Sequence[Mapping[str, Any]]) -> str:
    output_dir.mkdir(parents=True, exist_ok=False)
    manifest_hash = _sha(list(cases))
    protocol = {
        "schema": "step14_protocol_manifest_v1", "step": "STEP14",
        "source": {"step13_result_commit": "fa4f8bf", "step12_result_commit": "c8746e9d01cc68f64f7b7cf7e44f7913c28c5f39"},
        "authorization": {"required_phrase": "AUTHORIZE_STEP14_INDEPENDENT_VALIDATION = TRUE", "received": True},
        "panel": {"fault_cases": FAULT_CASES, "healthy_cases": HEALTHY_CASES,
                   "health_levels": list(FAULT_HEALTH), "families": list(FAULT_FAMILIES),
                   "methods": list(METHODS), "seeds_per_cell": SEEDS_PER_CELL},
        "heldout": True, "manifest_sha256": manifest_hash,
        "independence": {"p1_read_set": ["current_state", "fault", "health", "task_reference", "frozen_model_parameters"],
                          "p1_forbidden_reads": ["future_state", "independent_rollout", "future_label", "evaluator_residual", "label_cache"],
                          "p1_does_not_read_future": True, "evaluator_separate_path": True,
                          "truth_leakage_check": "no future label/braking margin in manifest"},
        "evaluator": {"kind": "INDEPENDENT_SURROGATE_VALIDATION", "config_hash": EVALUATOR_CONFIG_HASH, "checkpoints": CHECKPOINTS,
                      "dt_s": DT, "horizon_s": HORIZON_S, "physical_upgrade": "not run"},
        "delta_U": {"absolute": DELTA_U, "units": "normalized task utility", "source": "pre-registered task/healthy-reference tolerance", "frozen_before_run": True}, "deadline_ms": DEADLINE_MS,
        "stop_decisions": ["GO", "HOLD", "STOP"], "auto_expand": False,
        "numeric_run": "not started",
    }
    (output_dir / "STEP14_PROTOCOL_AND_MANIFEST.json").write_text(json.dumps(protocol, indent=2, sort_keys=True), encoding="utf-8")
    fields = ["case_id", "ordinal", "seed", "case_kind", "fault", "health", "family", "p", "v", "p_max", "task_target_speed", "state_factory_version", "initial_state_hash", "contact_identity", "task_ref_hash", "disturbance_hash", "model_hash"]
    with (output_dir / "STEP14_CASE_MANIFEST.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields); writer.writeheader()
        writer.writerows({k: c.get(k) for k in fields} for c in cases)
    (output_dir / "STEP14_INDEPENDENCE_AUDIT.md").write_text(
        "# STEP14 independence audit\n\n"
        "The held-out manifest has no future label or P1 braking margin. "
        "P1 reads only current state, fault/health, task reference and frozen model parameters; future states, terminal labels and evaluator outcomes are forbidden reads. "
        "The independent evaluator is a separate module with its own fixed-step propagation and safety predicates; it records raw states, contact/friction/actuator margins, terminal predicates and first-failure checkpoints.\n\n"
        "Ledger contract: each method has START and END records; ERROR and UNKNOWN are reserved for failed or interrupted calls. P1 uses a state-dependent scaled braking action, not constant-torque hold.\n\n"
        "Exact confidence intervals are required for GO; this surrogate run reports HOLD/STOP when exact CI is unavailable.\n",
        encoding="utf-8")
    return manifest_hash


def _independent_evaluator(case: Mapping[str, Any], method: str, accepted: bool, scale: float) -> Dict[str, Any]:
    """Adapter to the independent evaluator module; no P1 criterion inside."""
    kind = "STATE_DEPENDENT_SCALED_BRAKING_ACTION" if method == "P1_RECOVERABILITY_FILTER" else "TASK_COMMAND"
    return evaluate_future(case, {"kind": kind, "scale": scale, "method": method, "accepted": accepted})


def _decision(case: Mapping[str, Any], method: str) -> Dict[str, Any]:
    if method == "H_HEALTHY_REFERENCE":
        accepted, scale, action = True, 1.0, "ACCEPT"
    else:
        # Method decision is kept separate from `_independent_evaluator`; the
        # latter never imports or calls the P1 braking-margin implementation.
        from cavr_wbc.control.step13_recoverability import evaluate_method
        d = evaluate_method(method, p=case["p"], p_max=case["p_max"], v=case["v"],
                            rho=case["health"], acceleration=max(0.0, 0.75 * case["health"]),
                            instant_feasible=True, projection_feasible=True)
        accepted, scale, action = bool(d.accepted), float(d.command_scale), d.action
    action = {"kind": "STATE_DEPENDENT_SCALED_BRAKING_ACTION" if method == "P1_RECOVERABILITY_FILTER" else "TASK_COMMAND", "scale": scale}
    ev = evaluate_future(case, action)
    utility = max(0.0, 1.0 - abs(float(case["v"]) - float(case["task_target_speed"])) - (0.015 if method == "P0_INSTANT_PROJECTION" else 0.0)) * (scale if accepted else 0.0)
    return {
        "case_id": case["case_id"], "ordinal": case["ordinal"], "seed": case["seed"],
        "case_kind": case["case_kind"], "family": case["family"], "health": case["health"],
        "method": method, "paired": True, "state_hash": _sha(case),
        "accepted": accepted, "command_scale": scale, "action": action,
        "filter_rejected": not accepted, "task_utility": utility,
        "task_error": abs(float(case["v"]) - float(case["task_target_speed"])),
        "latency_ms": {METHODS[0]: 1.0, METHODS[1]: 1.2, METHODS[2]: 1.6, METHODS[3]: 0.4}[method],
        "deadline_miss": False, "solver_status": "ANALYTIC_SURROGATE",
        "evaluator_config_hash": EVALUATOR_CONFIG_HASH,
        "independent_evaluation": ev,
        "backup_action": "STATE_DEPENDENT_SCALED_BRAKING_ACTION" if method == "P1_RECOVERABILITY_FILTER" else "TASK_COMMAND",
        "no_valid_command": not accepted,
        "v1_rejected": bool(method == "P1_RECOVERABILITY_FILTER" and not accepted),
        "status": ("V1_REJECTED" if method == "P1_RECOVERABILITY_FILTER" and not accepted else
                   ("NO_VALID_COMMAND" if not accepted else ("FAIL" if ev["safety_failure"] else "PASS"))),
    }


def _stop_decision(rows: Sequence[Mapping[str, Any]]) -> Dict[str, Any]:
    fault = [r for r in rows if r["case_kind"] == "fault"]
    rates = {m: sum(r["independent_evaluation"]["safety_failure"] and r["status"] not in {"NO_VALID_COMMAND", "V1_REJECTED"} for r in fault if r["method"] == m) / FAULT_CASES for m in METHODS}
    no_command = {m: sum(r["status"] in {"NO_VALID_COMMAND", "V1_REJECTED"} for r in fault if r["method"] == m) / FAULT_CASES for m in METHODS}
    utility = {m: sum(r["task_utility"] for r in fault if r["method"] == m) / FAULT_CASES for m in METHODS}
    p1_better = rates["P1_RECOVERABILITY_FILTER"] < rates["B1_FAULT_AWARE_SOFT_WBC"]
    utility_ok = utility["P1_RECOVERABILITY_FILTER"] + DELTA_U >= utility["B1_FAULT_AWARE_SOFT_WBC"]
    state = "HOLD" if p1_better and utility_ok else "STOP"
    return {"decision": state, "failure_rate": rates, "no_valid_command_rate": no_command, "task_utility_mean": utility,
            "delta_U": DELTA_U, "confidence_interval_method": "not_available_without_preregistered_exact_CI",
            "exact_ci_available": False,
            "expand_authorized": False,
            "reason": "independent primary endpoint and utility gate"}


def run_validation(cases: Sequence[Mapping[str, Any]], output_dir: Path, *, expected_manifest_sha256: str | None = None) -> Dict[str, Any]:
    if len(cases) != TOTAL_CASES or len({c["case_id"] for c in cases}) != TOTAL_CASES:
        raise RuntimeError("held-out panel cardinality mismatch; no auto-expansion")
    out = output_dir
    if out.exists():
        raise FileExistsError(f"refusing to overwrite existing validation output: {out}")
    manifest_hash = _sha(list(cases))
    if expected_manifest_sha256 is not None and expected_manifest_sha256 != manifest_hash:
        raise RuntimeError("held-out manifest hash mismatch")
    out.mkdir(parents=True)
    rows: List[Dict[str, Any]] = []; ledger: List[Dict[str, Any]] = []
    for case in cases:
        for method in METHODS:
            started = time.time(); ledger.append({"event": "START", "case_id": case["case_id"], "method": method, "manifest_sha256": manifest_hash, "utc": started})
            decision_start = time.perf_counter_ns()
            row = _decision(case, method)
            row["latency_ms"] = (time.perf_counter_ns() - decision_start) / 1e6
            row["deadline_miss"] = row["latency_ms"] > DEADLINE_MS
            row["manifest_sha256"] = manifest_hash
            row["output_hash"] = _sha(row); rows.append(row)
            ledger.append({"event": "END", "case_id": case["case_id"], "method": method, "status": row["status"], "evaluator": EVALUATOR_CONFIG["name"], "evaluator_config_hash": EVALUATOR_CONFIG_HASH, "utc": time.time()})
    if len(rows) != TOTAL_CASES * len(METHODS):
        raise RuntimeError("paired result count mismatch")
    (out / "STEP14_CASE_RESULTS.jsonl").write_text("".join(json.dumps(r, sort_keys=True) + "\n" for r in rows), encoding="utf-8")
    (out / "STEP14_INDEPENDENT_EVALUATOR_LEDGER.jsonl").write_text("".join(json.dumps(e, sort_keys=True) + "\n" for e in ledger), encoding="utf-8")
    decision = _stop_decision(rows)
    result = {"schema": "step14_validation_result_v1", "cases": TOTAL_CASES, "rows": len(rows), "methods": list(METHODS), "manifest_sha256": manifest_hash, "stop": decision, "runtime_scope": "independent fixed-step surrogate; no MuJoCo/solver run", "numeric_run": "complete", "p1_backup_semantics": "STATE_DEPENDENT_SCALED_BRAKING_ACTION", "deadline_ms": DEADLINE_MS}
    (out / "STEP14_REPORT.md").write_text("# STEP14 independent validation\n\n" + f"Decision: **{decision['decision']}**\n\n" + json.dumps(decision, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (out / "STEP14_RESEARCH_HANDOFF.md").write_text("# STEP14 handoff\n\nHeld-out independent evaluator completed as a bounded surrogate only. No realtime, MuJoCo, E2-B or H2 claim is authorised. Automatic expansion is forbidden.\n", encoding="utf-8")
    (out / "STEP14_RESULT.json").write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    return result


def main(argv: List[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--prepare", action="store_true")
    parser.add_argument("--run", action="store_true")
    parser.add_argument("--output", type=Path, default=DEFAULT_OUT)
    args = parser.parse_args(argv)
    if not (args.prepare or args.run):
        parser.error("explicit --prepare or --run required")
    cases = build_heldout_manifest()
    manifest_hash = None
    if args.prepare:
        manifest_hash = write_manifest(args.output, cases)
    if args.run:
        if manifest_hash is None:
            manifest_hash = write_manifest(args.output, cases)
        run_validation(cases, args.output / "run", expected_manifest_sha256=manifest_hash)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
