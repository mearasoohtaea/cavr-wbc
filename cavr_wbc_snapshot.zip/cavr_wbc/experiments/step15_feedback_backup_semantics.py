"""Bounded STEP15 feedback-backup semantic smoke.

This runner deliberately owns only the three pre-declared reduced-order cases.
It is not a recoverability panel and never loads MuJoCo or a solver.  The
policy and evaluator are separate modules: the runner records the submitted
per-tick action trajectory and the evaluator independently propagates it.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
from typing import Any, Mapping

from cavr_wbc.control.feedback_backup import FeedbackBackupPolicy, FrozenBackupConfig
from cavr_wbc.evaluation.step15_independent_evaluator import (
    EVALUATOR_CONFIG,
    EVALUATOR_CONFIG_HASH,
    evaluate_trajectory,
)


STEP15_PROTOCOL = {
    "name": "STEP15_FEEDBACK_BACKUP_SEMANTICS_GATE",
    "authorization": "AUTHORIZE_STEP15_BACKUP_SEMANTICS_IMPLEMENTATION = TRUE",
    "scope": "semantic/reduced-order implementation only",
    "formal_panel": False,
    "mujoco": False,
    "solver": False,
    "cases": ["safe_interior", "boundary_braking", "zero_capacity_boundary"],
    "case_count": 3,
    "repeat_policy": "one execution per case; no retry/tuning/expansion",
}


def _sha(value: Any) -> str:
    payload = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _finite(value: Any, name: str) -> float:
    result = float(value)
    if not math.isfinite(result):
        raise ValueError(f"{name} must be finite")
    return result


def declared_cases() -> list[dict[str, Any]]:
    """Return the exact three cases used by the bounded semantic smoke."""

    base = {
        "p_max": 1.0,
        "support": ["FL", "FR", "RL", "RR"],
        "contact": [True, True, True, True],
        "support_count": 4,
        "friction_coeff": 0.60,
        "normal_force": 117.72,
        "actuator_limit": 1.0,
        "task_reference": {"target_speed": 0.0, "target_position": 0.95},
        "model": {"mass_kg": 12.0, "lever_arm_m": 0.12, "gravity_m_s2": 9.81},
    }
    cases = [
        {
            **base,
            "case_id": "S15_safe_interior",
            "case_kind": "safe_interior",
            "p": 0.10,
            "v": 0.20,
            "health": 1.0,
        },
        {
            **base,
            "case_id": "S15_boundary_braking",
            "case_kind": "boundary_braking",
            "p": 0.82,
            "v": 0.45,
            "health": 0.75,
        },
        {
            **base,
            "case_id": "S15_zero_capacity_boundary",
            "case_kind": "zero_capacity_boundary",
            "p": 0.20,
            "v": 0.30,
            "health": 0.0,
        },
    ]
    for row in cases:
        row["initial_state_hash"] = _sha({k: row[k] for k in ("p", "v", "p_max", "health", "support")})
        row["task_reference_hash"] = _sha(row["task_reference"])
        row["model_hash"] = _sha(row["model"])
    return cases


def _advance(state: Mapping[str, Any], action: Mapping[str, Any], dt: float) -> dict[str, Any]:
    """Runner-side state snapshot for requesting the next policy action.

    This is intentionally a tiny state adapter, not the independent evaluator.
    It uses only the submitted acceleration and current state and never reads
    evaluator labels.
    """

    p = _finite(state["p"], "p")
    v = max(0.0, _finite(state["v"], "v"))
    raw_action = action.get("backup_action", action)
    accel = _finite(raw_action.get("value"), "backup_action.value")
    next_v = max(0.0, v + accel * dt)
    next_p = p + 0.5 * (v + next_v) * dt
    result = dict(state)
    result["p"] = next_p
    result["v"] = next_v
    return result


def run_smoke(output_dir: str | Path) -> dict[str, Any]:
    """Run exactly one bounded pass of the three semantic smoke cases."""

    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    config = FrozenBackupConfig()
    policy_spec = config.as_dict() if hasattr(config, "as_dict") else dict(config.__dict__)
    policy_spec["config_hash"] = getattr(config, "config_hash", _sha(policy_spec))
    policy_spec["protocol"] = STEP15_PROTOCOL
    policy_spec["evaluator_config_hash"] = EVALUATOR_CONFIG_HASH
    policy_spec["implementation_hashes"] = {
        "feedback_backup_module": hashlib.sha256(Path(__file__).resolve().parents[1].joinpath("control", "feedback_backup.py").read_bytes()).hexdigest(),
        "independent_evaluator_module": hashlib.sha256(Path(__file__).resolve().parents[1].joinpath("evaluation", "step15_independent_evaluator.py").read_bytes()).hexdigest(),
        "runner_module": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    (output / "STEP15_POLICY_SPEC.json").write_text(
        json.dumps(policy_spec, indent=2, sort_keys=True), encoding="utf-8"
    )

    cases = declared_cases()
    (output / "STEP15_CASE_MANIFEST.json").write_text(
        json.dumps({"protocol": STEP15_PROTOCOL, "cases": cases}, indent=2, sort_keys=True),
        encoding="utf-8",
    )

    trace_rows: list[dict[str, Any]] = []
    ledger_rows: list[dict[str, Any]] = []
    result_rows: list[dict[str, Any]] = []
    for ordinal, case in enumerate(cases, start=1):
        policy = FeedbackBackupPolicy()
        policy.reset(config)
        state = dict(case)
        actions: list[dict[str, Any]] = []
        ledger_rows.append({
            "case_id": case["case_id"], "event": "START", "event_index": len(ledger_rows), "ordinal": ordinal,
            "backup_id": policy.backup_id, "policy_config_hash": policy.config_hash,
            "evaluator_config_hash": EVALUATOR_CONFIG_HASH,
        })
        horizon_ticks = max(1, int(round(config.horizon_s / config.dt_s)))
        for tick in range(horizon_ticks):
            action = policy.compute(state, case["health"], case["task_reference"])
            if not isinstance(action, Mapping):
                raise TypeError("FeedbackBackupPolicy.compute must return a mapping")
            action = dict(action)
            action["tick"] = tick
            action["case_id"] = case["case_id"]
            actions.append(action)
            trace_rows.append({"case_id": case["case_id"], "tick": tick, "state": dict(state), "action": action})
            state = _advance(state, action, config.dt_s)
        evaluation = evaluate_trajectory(case, actions)
        row = {
            "case_id": case["case_id"],
            "case_kind": case["case_kind"],
            "ordinal": ordinal,
            "policy_config_hash": policy_spec["config_hash"],
            "evaluator_config_hash": EVALUATOR_CONFIG_HASH,
            "action_count": len(actions),
            "action_hash": _sha(actions),
            "evaluation": evaluation,
        }
        result_rows.append(row)
        ledger_rows.append({
            "case_id": case["case_id"],
            "event": "END",
            "event_index": len(ledger_rows),
            "ordinal": ordinal,
            "backup_id": evaluation.get("backup_id"),
            "policy_config_hash": policy.config_hash,
            "evaluator_config_hash": EVALUATOR_CONFIG_HASH,
            "action_hash": _sha(actions),
            "trajectory_hash": evaluation.get("trajectory_hash"),
            "status": evaluation.get("status"),
            "first_failure_type": (evaluation.get("first_failure") or {}).get("type"),
        })

    (output / "STEP15_POLICY_TRACES.jsonl").write_text(
        "".join(json.dumps(row, sort_keys=True) + "\n" for row in trace_rows), encoding="utf-8"
    )
    (output / "STEP15_INDEPENDENT_EVALUATOR_LEDGER.jsonl").write_text(
        "".join(json.dumps(row, sort_keys=True) + "\n" for row in ledger_rows), encoding="utf-8"
    )
    (output / "STEP15_CASE_RESULTS.jsonl").write_text(
        "".join(json.dumps(row, sort_keys=True) + "\n" for row in result_rows), encoding="utf-8"
    )

    passed = all(row["evaluation"].get("status") != "UNKNOWN" for row in result_rows)
    smoke_result = {
        "protocol": STEP15_PROTOCOL,
        "status": "BACKUP_SEMANTICS_READY_FOR_REFREEZE" if passed else "BACKUP_SEMANTICS_BLOCKED",
        "cases": len(result_rows),
        "all_ledger_known": passed,
        "formal_panel_run": False,
        "mujoco_run": False,
        "solver_calls": 0,
        "policy_config_hash": policy_spec["config_hash"],
        "evaluator_config_hash": EVALUATOR_CONFIG_HASH,
    }
    (output / "STEP15_SMOKE_RESULT.json").write_text(
        json.dumps(smoke_result, indent=2, sort_keys=True), encoding="utf-8"
    )
    report = "# STEP15 Feedback-Backup Semantics Gate\n\n"
    report += "This bounded reduced-order smoke implements a state-feedback backup policy and an independent action-trajectory evaluator. It is not recoverability, whole-body physics, stability, viability, or a 20 ms real-time claim.\n\n"
    report += f"Status: **{smoke_result['status']}**\n\n"
    report += f"Cases: {len(result_rows)} (safe interior, boundary/braking, zero-capacity boundary). Formal panel: not run. MuJoCo/solver calls: 0.\n"
    (output / "STEP15_REPORT.md").write_text(report, encoding="utf-8")
    handoff = "# STEP15 Research Handoff\n\n"
    handoff += "The implementation is semantic/reduced-order only. The three-case smoke does not support H2, closed-loop safety, stability, viability, recoverability, or real-time claims. STEP13 surrogate conclusions and STEP14 blocked status remain unchanged. A later protocol must re-freeze any full-body evaluator before a held-out panel.\n"
    (output / "STEP15_RESEARCH_HANDOFF.md").write_text(handoff, encoding="utf-8")
    return smoke_result


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--smoke", action="store_true", help="run the three-case bounded semantic smoke")
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args(argv)
    if not args.smoke:
        parser.error("only --smoke is authorized in STEP15")
    result = run_smoke(args.output)
    print(json.dumps(result, sort_keys=True))
    return 0 if result["status"] == "BACKUP_SEMANTICS_READY_FOR_REFREEZE" else 2


if __name__ == "__main__":
    raise SystemExit(main())
