"""STEP16 formal independent recoverability panel.

This runner is intentionally separate from the historical E2-B runners.  It
uses the frozen 80+10 scenario generator only for case identity, while the
P1_FEEDBACK path is a genuine current-state MuJoCo adapter and the final
predicates are recomputed from serialized simulator observations.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import platform
import sys
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any

import mujoco
import numpy as np

from cavr_wbc.control.e2b_dynamic import DynamicWBC
from cavr_wbc.control.step16_feedback_adapter import P1FeedbackAdapter
from cavr_wbc.evaluation.e2b_physical import evaluate as physical_evaluate
from cavr_wbc.evaluation.step16_independent_evaluator import evaluate_serialized_trajectory
from cavr_wbc.platforms.go2_mujoco import (
    contact_diagnostics,
    extract_healthy_torque_limits,
    joint_tau_from_qfrc,
)
from cavr_wbc.experiments.step04_e2b import (
    FR_THIGH,
    METHODS as OLD_METHODS,
    build_scenarios,
    load_model,
)

ROOT = Path(__file__).resolve().parents[2]
METHODS = ("B1", "B2", "B3", "P0", "P1_FEEDBACK")
CONTROL_DT_S = 0.020
PHYSICS_STEPS_PER_TICK = 10
EPISODE_S = 20.0
BACKUP_HORIZON_S = 1.0
BACKUP_CHECKPOINTS = 21
DEADLINE_MS = 20.0
MODEL_REL = Path("third_party/unitree_mujoco_snapshot/unitree_robots/go2/scene.xml")
FIXED_BOUNDARY_M = 1.0


def sha(value: Any) -> str:
    if isinstance(value, bytes):
        payload = value
    elif isinstance(value, str):
        payload = value.encode()
    else:
        payload = json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    return hashlib.sha256(payload).hexdigest()


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False, default=float) + "\n", encoding="utf-8")


def _euler(q: np.ndarray) -> tuple[float, float]:
    w, x, y, z = map(float, q)
    return math.atan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y)), math.asin(max(-1.0, min(1.0, 2 * (w * y - z * x))))


def _reset(m: mujoco.MjModel, d: mujoco.MjData, scenario: Any) -> None:
    key = mujoco.mj_name2id(m, mujoco.mjtObj.mjOBJ_KEY, "home")
    if key >= 0:
        mujoco.mj_resetDataKeyframe(m, d, key)
    cr, sr = math.cos(float(scenario.initial_roll) / 2), math.sin(float(scenario.initial_roll) / 2)
    cp, sp = math.cos(float(scenario.initial_pitch) / 2), math.sin(float(scenario.initial_pitch) / 2)
    d.qpos[3:7] = np.array([cr * cp, sr * cp, cr * sp, sr * sp], dtype=float)
    d.qvel[6:9] = 0.0
    d.xfrc_applied[:] = 0.0
    mujoco.mj_forward(m, d)


def _target(m: mujoco.MjModel, speed: float, action: float = 0.0) -> dict[str, Any]:
    base = [0.0] * 6
    base[0] = float(action)
    return {
        "desired_base_accel": base,
        "desired_joint_accel": [0.0] * m.nu,
        "task_weights": [1.0] * (6 + m.nu),
        "com_velocity": float(speed),
        "com_height": 0.27,
        "p_max": FIXED_BOUNDARY_M,
        "target_position": FIXED_BOUNDARY_M - 0.05,
    }


def _health(sc: Any, sim_t: float, m: mujoco.MjModel) -> tuple[np.ndarray, float]:
    active = float(sc.health) if sc.fault_onset_s is not None and sim_t >= float(sc.fault_onset_s) else 1.0
    h = np.ones(m.nu, dtype=float)
    h[FR_THIGH] = active
    return h, active


def _state_for_policy(m: mujoco.MjModel, d: mujoco.MjData, active_health: float) -> dict[str, Any]:
    contacts = contact_diagnostics(m, d)
    # The panel freezes a local one-metre forward recoverability boundary.  It
    # is derived only from the current qpos and never from future labels.
    p = float(d.qpos[0])
    return {
        "p": p,
        "v": float(d.qvel[0]),
        "p_max": p + 1.0,
        "contact": {name: bool(contacts[name]["present"]) for name in ("FL", "FR", "RL", "RR")},
        "friction_coeff": 0.5,
        "actuator_limit": float(active_health),
    }


def _physical(m: mujoco.MjModel, d: mujoco.MjData, tau: np.ndarray, h: np.ndarray, speed: float) -> dict[str, Any]:
    cfg = {
        "task": {"roll_limit_rad": 0.55, "pitch_limit_rad": 0.55, "com_height_min_m": 0.16, "com_height_max_m": 0.60, "velocity_limit_m_s": 2.0},
        "terminal": {"velocity_max_m_s": 0.25, "angle_max_rad": 0.20, "friction_margin_min_n": 0.0},
    }
    return physical_evaluate(m, d, tau, h, cfg, {"com_velocity": speed, "com_height": 0.27})


def run_episode(sc: Any, method: str, out: Path) -> tuple[dict[str, Any], list[dict[str, Any]], list[dict[str, Any]]]:
    m = load_model()
    d = mujoco.MjData(m)
    _reset(m, d, sc)
    wbc = DynamicWBC(m)
    adapter = P1FeedbackAdapter(wbc, m) if method == "P1_FEEDBACK" else None
    if adapter is not None:
        adapter.reset()
    trajectory: list[dict[str, Any]] = []
    latency_rows: list[dict[str, Any]] = []
    solver_ledger: list[dict[str, Any]] = []
    limits = extract_healthy_torque_limits(m)
    sim_t = 0.0
    control_ticks = int(round(EPISODE_S / CONTROL_DT_S))
    safety_failure = False
    infeasible = False
    deadline_miss = False
    min_margin = float("inf")
    first_backup_tick: int | None = None
    stable_backup_id = adapter.backup_id if adapter is not None else f"STEP16-{sc.scenario_id}-{method}"
    with (out / "STEP16_POLICY_TRAJECTORIES.jsonl").open("a", encoding="utf-8") as trace:
        for tick in range(control_ticks):
            hvec, active_health = _health(sc, sim_t, m)
            t0 = time.perf_counter()
            adapter_row: dict[str, Any] = {}
            if adapter is not None:
                adapter_out = adapter.compute(d, hvec, _target(m, sc.speed_mps))
                wb = adapter_out["wbc"]
                adapter_row = {
                    "backup_id": adapter_out.get("backup_id"),
                    "action": adapter_out.get("action"),
                    "ledger_row": adapter_out.get("ledger_row"),
                }
            else:
                wb = wbc.compute(d, method, hvec, _target(m, sc.speed_mps))
            elapsed_ms = (time.perf_counter() - t0) * 1000.0
            deadline = elapsed_ms > DEADLINE_MS
            deadline_miss = deadline_miss or deadline
            latency_rows.append({"scenario_id": sc.scenario_id, "method": method, "tick": tick, "latency_ms": elapsed_ms, "deadline_ms": DEADLINE_MS, "deadline_miss": deadline})
            tau = np.asarray(wb.get("tau"), dtype=float) if wb.get("success") and wb.get("tau") is not None else np.zeros(m.nu, dtype=float)
            if not np.isfinite(tau).all() or not wb.get("success"):
                infeasible = True
            d.ctrl[:] = tau
            mujoco.mj_forward(m, d)
            tau_applied = joint_tau_from_qfrc(m, d)
            contacts = contact_diagnostics(m, d)
            physical = _physical(m, d, tau, hvec, sc.speed_mps)
            physical_contacts = physical.get("contacts") if isinstance(physical, dict) else None
            serialized_contacts = physical_contacts if isinstance(physical_contacts, dict) else contacts
            roll, pitch = _euler(np.asarray(d.qpos[3:7], dtype=float))
            row = {
                "scenario_id": sc.scenario_id, "method": method, "tick": tick, "time_s": float(sim_t),
                "qpos": np.asarray(d.qpos, dtype=float).tolist(), "qvel": np.asarray(d.qvel, dtype=float).tolist(),
                "health": float(active_health), "health_vector": hvec.tolist(),
                "action": adapter_row.get("action", {"channel": "base_x_acceleration", "unit": "m/s^2", "value": 0.0}),
                "backup_id": adapter_row.get("backup_id") or stable_backup_id, "tau_cmd": tau.tolist(),
                "tau_applied": tau_applied.tolist(), "actuator_force": np.asarray(d.actuator_force, dtype=float).tolist(),
                "contacts": serialized_contacts, "physical_evaluation": physical, "friction_coeff": 0.5,
                "actuator_limits": limits.tolist(),
                "solver_status": wb.get("status"), "solver_status_class": wb.get("status_class"),
                "solver_calls": int(wb.get("solver_calls", 1)), "solver_call_index": wb.get("solver_call_index"),
                "solver_wall_ms": None if wb.get("solve_wall_time_s") is None else float(wb["solve_wall_time_s"]) * 1000.0,
                "qp_validation": wb.get("validation", {}), "roll": roll, "pitch": pitch,
                "latency_ms": elapsed_ms, "boundary_margin_m": float(FIXED_BOUNDARY_M - d.qpos[0]),
                "terminal_fields": {"height_m": float(d.qpos[2]), "forward_velocity_m_s": float(d.qvel[0]), "ncon": int(d.ncon)},
            }
            trajectory.append(row)
            trace.write(json.dumps(row, sort_keys=True, separators=(",", ":"), default=float) + "\n")
            trace.flush()
            solver_ledger.extend(dict(x, scenario_id=sc.scenario_id, method=method, tick=tick, backup_id=adapter_row.get("backup_id")) for x in wbc.solver_ledger[len(solver_ledger):])
            lim = limits * hvec
            min_margin = min(min_margin, float(np.min(lim - np.abs(tau))))
            infeasible = infeasible or bool(np.any(np.abs(tau) > lim + 1e-7))
            safety_failure = safety_failure or bool(physical.get("safety_failure", False))
            if adapter_row.get("backup_id") and first_backup_tick is None:
                first_backup_tick = tick
            if sc.fault_onset_s is not None and sim_t >= float(sc.fault_onset_s):
                d.xfrc_applied[1, :3] = np.asarray(sc.disturbance_force, dtype=float) * 0.02
            for _ in range(PHYSICS_STEPS_PER_TICK):
                mujoco.mj_step(m, d)
            sim_t += CONTROL_DT_S
    onset_tick = 0 if sc.fault_onset_s is None else int(round(float(sc.fault_onset_s) / CONTROL_DT_S))
    evaluator = evaluate_serialized_trajectory(case=asdict(sc), trajectory=trajectory, start_index=onset_tick)
    result = {
        "scenario_id": sc.scenario_id, "method": method, "paired": bool(sc.paired), "seed": int(sc.seed), "speed": sc.speed,
        "health": float(sc.health), "layer": sc.layer, "fault_onset_s": sc.fault_onset_s,
        "safety_failure": bool(safety_failure or evaluator.get("safety_failure", False)), "infeasible": bool(infeasible),
        "deadline_miss": bool(deadline_miss), "latency_p50_ms": float(np.percentile([r["latency_ms"] for r in latency_rows], 50)),
        "latency_p95_ms": float(np.percentile([r["latency_ms"] for r in latency_rows], 95)), "latency_max_ms": float(max(r["latency_ms"] for r in latency_rows)),
        "solver_calls": int(wbc.solver_calls), "solver_setup_calls": int(wbc.solver_setup_calls),
        "solver_statuses": sorted({str(r.get("solver_status")) for r in trajectory}), "solver_ledger": solver_ledger,
        "backup_id": adapter.backup_id if adapter is not None else None, "backup_tick": first_backup_tick,
        "min_torque_margin": float(min_margin), "evaluator": evaluator,
        "trajectory_hash": sha(trajectory), "scenario_hash": sha(asdict(sc)),
        "status": "FAIL" if (safety_failure or infeasible or evaluator.get("physical_status") != "PASS") else ("OFFLINE_PHYSICAL_BOUNDARY" if deadline_miss else "PASS"),
    }
    return result, trajectory, latency_rows


def adapter_preflight(out: Path) -> dict[str, Any]:
    m = load_model(); d = mujoco.MjData(m); scenarios = build_scenarios(); _reset(m, d, scenarios[0])
    h = np.ones(m.nu, dtype=float); h[FR_THIGH] = 0.75
    wbc = DynamicWBC(m); adapter = P1FeedbackAdapter(wbc, m)
    t0 = time.perf_counter(); adapter_out = adapter.compute(d, h, _target(m, scenarios[0].speed_mps)); wb = adapter_out["wbc"]; row = adapter_out; elapsed = (time.perf_counter() - t0) * 1000.0
    tau = np.asarray(wb.get("tau"), dtype=float) if wb.get("tau") is not None else np.zeros(m.nu)
    d.ctrl[:] = tau; mujoco.mj_forward(m, d)
    evidence = {"status": "PASS" if wb.get("success") and np.isfinite(joint_tau_from_qfrc(m, d)).all() and elapsed <= DEADLINE_MS else "BLOCKED_NO_PHYSICAL_BACKUP_ADAPTER", "elapsed_ms": elapsed, "solver_calls": int(wbc.solver_calls), "backup_id": adapter.backup_id, "action": row.get("action"), "tau_cmd": tau.tolist(), "tau_applied": joint_tau_from_qfrc(m, d).tolist(), "mapping": adapter.spec}
    write_json(out / "STEP16_PREFLIGHT.json", evidence)
    return evidence


def run_panel(out: Path, run_id: str) -> dict[str, Any]:
    out.mkdir(parents=True, exist_ok=True)
    scenarios = build_scenarios()
    manifest = {
        "schema": "STEP16_FORMAL_INDEPENDENT_RECOVERABILITY_PANEL_V1", "run_id": run_id, "source_commit": "fa68d9abeca1a3278ada55b2c89a6d0d5a9450a3", "methods": list(METHODS),
        "paired_scenarios": sum(bool(s.paired) for s in scenarios), "healthy_scenarios": sum(not bool(s.paired) for s in scenarios),
        "health_levels": [0.75, 0.5, 0.25, 0.0], "layers": ["R1", "R2", "R3"], "episode_s": EPISODE_S, "control_dt_s": CONTROL_DT_S,
        "physics_steps_per_tick": PHYSICS_STEPS_PER_TICK, "backup_horizon_s": BACKUP_HORIZON_S, "backup_checkpoints": BACKUP_CHECKPOINTS,
        "deadline_ms": DEADLINE_MS, "fixed_boundary_m": FIXED_BOUNDARY_M, "fr_thigh_index": FR_THIGH, "scenario_hash": sha([asdict(s) for s in scenarios]),
        "model_sha256": sha(MODEL_REL.read_bytes()), "historical_results_unchanged": True,
    }
    write_json(out / "STEP16_PROTOCOL_AND_MANIFEST.json", manifest)
    rows: list[dict[str, Any]] = []; latency: list[dict[str, Any]] = []
    for scenario in scenarios:
        for method in METHODS:
            result, _, lrows = run_episode(scenario, method, out)
            rows.append(result); latency.extend(lrows)
            write_json(out / f"case_{scenario.scenario_id}__{method}.json", result)
    with (out / "STEP16_CASE_RESULTS.csv").open("w", newline="", encoding="utf-8") as f:
        keys = sorted({k for r in rows for k in r if k != "solver_ledger" and k != "evaluator"})
        writer = csv.DictWriter(f, fieldnames=keys); writer.writeheader()
        for r in rows: writer.writerow({k: json.dumps(v, sort_keys=True, default=float) if isinstance(v, (dict, list)) else v for k, v in r.items() if k in keys})
    (out / "STEP16_LATENCY_LEDGER.jsonl").write_text("".join(json.dumps(x, sort_keys=True) + "\n" for x in latency), encoding="utf-8")
    (out / "STEP16_INDEPENDENT_EVALUATOR_LEDGER.jsonl").write_text("".join(json.dumps({"run_id": run_id, "scenario_id": r["scenario_id"], "method": r["method"], "evaluator": r["evaluator"], "physical_status": r["evaluator"].get("physical_status"), "status": r["evaluator"].get("status"), "checkpoint_count": r["evaluator"].get("checkpoint_count"), "start_checkpoint_time_s": (r["evaluator"].get("checkpoints") or [{}])[0].get("time_s"), "deadline_miss_count": r["evaluator"].get("deadline_miss_count"), "trajectory_hash": r["trajectory_hash"]}, sort_keys=True, default=float) + "\n" for r in rows), encoding="utf-8")
    (out / "STEP16_SOLVER_CALL_LEDGER.jsonl").write_text("".join(json.dumps(x, sort_keys=True, default=float) + "\n" for r in rows for x in r["solver_ledger"]), encoding="utf-8")
    status = "FORMAL_PANEL_COMPLETED"
    summary = {"status": status, "rows": len(rows), "pass": sum(r["status"] == "PASS" for r in rows), "fail": sum(r["status"] != "PASS" for r in rows), "paired": sum(r["paired"] for r in rows), "strict_deadline_pass": all(not r["deadline_miss"] for r in rows), "historical_results_unchanged": True, "h2": "NOT_ESTABLISHED"}
    write_json(out / "STEP16_RESULT.json", summary)
    write_json(out / "STEP16_CASE_RESULTS.json", rows)
    method_summary = {m: {"n": sum(r["method"] == m for r in rows), "pass": sum(r["method"] == m and r["status"] == "PASS" for r in rows), "offline_boundary": sum(r["method"] == m and r["status"] == "OFFLINE_PHYSICAL_BOUNDARY" for r in rows), "fail": sum(r["method"] == m and r["status"] == "FAIL" for r in rows)} for m in METHODS}
    report = "# STEP16 Formal Independent Recoverability Panel\n\n" + f"Status: **{status}**\n\nRun ID: `{run_id}`. Rows: {len(rows)} (80 paired × 5 methods + 10 healthy × 5 methods).\n\n" + f"Strict deadline pass: `{summary['strict_deadline_pass']}`. H2: **NOT ESTABLISHED**; this panel reports the frozen physical boundary only.\n\n" + "## Method outcomes\n\n" + json.dumps(method_summary, indent=2, sort_keys=True) + "\n\nPhysical failure, solver failure and deadline outcomes are retained per case. A 20 ms miss is reported as `OFFLINE_PHYSICAL_BOUNDARY`; it is not converted into a real-time claim.\n"
    (out / "STEP16_REPORT.md").write_text(report, encoding="utf-8")
    (out / "STEP16_RESEARCH_HANDOFF.md").write_text("# STEP16 Research Handoff\n\nSTEP16 is an independent MuJoCo recoverability panel. Historical STEP12/13/14/15/E2B/E1 results remain unchanged. A 20 ms miss is an offline physical boundary, not a real-time claim.\n", encoding="utf-8")
    write_json(out / "GIT_DELIVERY.json", {"run_id": run_id, "source_commit": "fa68d9abeca1a3278ada55b2c89a6d0d5a9450a3", "branch": "codex/step16-formal-independent-recoverability-panel-20260923", "status": status, "git_push": False})
    return summary


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--preflight", action="store_true")
    parser.add_argument("--run-panel", action="store_true")
    parser.add_argument("--run-id", default="step16-formal-20260923-repair-01")
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args(argv)
    if args.preflight == args.run_panel:
        parser.error("choose exactly one of --preflight or --run-panel")
    if args.preflight:
        result = adapter_preflight(args.output)
    else:
        result = run_panel(args.output, args.run_id)
    print(json.dumps(result, sort_keys=True, default=float))
    return 0 if result.get("status") in {"PASS", "FORMAL_PANEL_COMPLETED"} else 2


if __name__ == "__main__":
    raise SystemExit(main())
