"""STEP17 targeted-repair runner.

This module is deliberately independent of the STEP16 launcher.  It keeps the
frozen scenario generator and controller methods, but serialises checkpoint
facts explicitly at a 50 ms grid and gates the 450-row panel behind a 15-row
canary.  The command line entry points are ``--pure-tests``, ``--canary`` and
``--run-panel``.  No retry, search, or adaptive parameter path is present.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import inspect
import json
import math
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any, Iterable

import mujoco
import numpy as np

from cavr_wbc.control.e2b_dynamic import DynamicWBC
from cavr_wbc.control.step16_feedback_adapter import P1FeedbackAdapter
from cavr_wbc.evaluation.e2b_physical import evaluate as physical_evaluate
from cavr_wbc.evaluation.step16_independent_evaluator import (
    EvaluatorInputError,
    evaluate_serialized_trajectory,
)
from cavr_wbc.experiments.step04_e2b import FR_THIGH, build_scenarios, load_model
from cavr_wbc.platforms.go2_mujoco import (
    contact_diagnostics,
    extract_healthy_torque_limits,
    joint_tau_from_qfrc,
)

METHODS = ("B1", "B2", "B3", "P0", "P1_FEEDBACK")
CONTROL_DT_S = 0.020
PHYSICS_DT_S = 0.002
PHYSICS_STEPS_PER_TICK = 10
CHECKPOINT_DT_S = 0.050
CHECKPOINT_COUNT = 21
EPISODE_S = 20.0
BACKUP_HORIZON_S = 1.0
DEADLINE_MS = 20.0
FIXED_BOUNDARY_M = 1.0
SOURCE_COMMIT = "263a643c2cccfdc2d6a4fd5d3aa59bb29dd271d1"
MODEL_REL = Path("third_party/unitree_mujoco_snapshot/unitree_robots/go2/scene.xml")


def sha(value: Any) -> str:
    if isinstance(value, bytes):
        payload = value
    elif isinstance(value, str):
        payload = value.encode()
    else:
        payload = json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False, default=float).encode()
    return hashlib.sha256(payload).hexdigest()


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False, default=float) + "\n", encoding="utf-8")


def _euler(q: np.ndarray) -> tuple[float, float]:
    w, x, y, z = map(float, q)
    return math.atan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y)), math.asin(max(-1.0, min(1.0, 2 * (w * y - z * x))))


def _reset(model: mujoco.MjModel, data: mujoco.MjData, scenario: Any) -> None:
    key = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_KEY, "home")
    if key >= 0:
        mujoco.mj_resetDataKeyframe(model, data, key)
    cr, sr = math.cos(float(scenario.initial_roll) / 2), math.sin(float(scenario.initial_roll) / 2)
    cp, sp = math.cos(float(scenario.initial_pitch) / 2), math.sin(float(scenario.initial_pitch) / 2)
    data.qpos[3:7] = np.array([cr * cp, sr * cp, cr * sp, sr * sp], dtype=float)
    data.qvel[6:9] = 0.0
    data.xfrc_applied[:] = 0.0
    mujoco.mj_forward(model, data)


def _target(model: mujoco.MjModel, speed: float, action: float = 0.0) -> dict[str, Any]:
    base = [0.0] * 6
    base[0] = float(action)
    return {"desired_base_accel": base, "desired_joint_accel": [0.0] * model.nu,
            "task_weights": [1.0] * (6 + model.nu), "com_velocity": float(speed),
            "com_height": 0.27, "p_max": FIXED_BOUNDARY_M,
            "target_position": FIXED_BOUNDARY_M - 0.05}


def onset_tick(onset_s: float | None, dt_s: float = CONTROL_DT_S) -> int:
    """First control tick at or after onset (ceil, never round)."""
    if onset_s is None:
        return 0
    return int(math.ceil((float(onset_s) - 1e-12) / dt_s))


def checkpoint_times(t0: float) -> list[float]:
    return [float(t0 + i * CHECKPOINT_DT_S) for i in range(CHECKPOINT_COUNT)]


def validate_checkpoint_grid(rows: Iterable[dict[str, Any]], start_s: float) -> bool:
    """Accept only 21 serialized timestamps on the exact 50 ms grid."""
    values = [float(row["time_s"]) for row in rows]
    expected = checkpoint_times(float(start_s))
    return len(values) == CHECKPOINT_COUNT and all(abs(a - b) <= 1e-9 for a, b in zip(values, expected))


def frozen_height_fact(row: dict[str, Any], base_id: int) -> float:
    """Read height from subtree COM; qpos[2] is diagnostic only."""
    com = row.get("subtree_com")
    if not isinstance(com, (list, tuple)) or len(com) <= int(base_id):
        raise ValueError("subtree_com mapping missing")
    return float(com[int(base_id)][2])


def frozen_torque_facts(tau_cmd: Iterable[float], tau_applied: Iterable[float], limits: Iterable[float], health: Iterable[float]) -> dict[str, Any]:
    scaled = np.asarray(list(limits), dtype=float) * np.asarray(list(health), dtype=float)
    cmd = np.asarray(list(tau_cmd), dtype=float); applied = np.asarray(list(tau_applied), dtype=float)
    cmd_margin = float(np.min(scaled - np.abs(cmd))); applied_margin = float(np.min(scaled - np.abs(applied)))
    return {"command_torque_margin_nm": cmd_margin, "applied_torque_margin_nm": applied_margin,
            "command_torque_ok": bool(cmd_margin >= 0.0), "applied_torque_ok": bool(applied_margin >= 0.0)}


def frozen_speed_fact(qvel: Iterable[float]) -> float:
    values = list(qvel)
    if not values:
        raise ValueError("qvel missing")
    return float(values[0])


def _health(scenario: Any, sim_t: float, model: mujoco.MjModel) -> tuple[np.ndarray, float]:
    active = float(scenario.health) if scenario.fault_onset_s is not None and sim_t >= float(scenario.fault_onset_s) else 1.0
    h = np.ones(model.nu, dtype=float)
    h[FR_THIGH] = active
    return h, active


def _base_id(model: mujoco.MjModel) -> int:
    for name in ("base", "base_link", "trunk"):
        idx = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, name)
        if idx >= 0:
            return idx
    return 1 if model.nbody > 1 else 0


def _contacts(model: mujoco.MjModel, data: mujoco.MjData) -> dict[str, Any]:
    return contact_diagnostics(model, data)


def _facts(model: mujoco.MjModel, data: mujoco.MjData, tau_cmd: np.ndarray, tau_applied: np.ndarray,
           health: np.ndarray, limits: np.ndarray, latency_ms: float, *, t: float, tick: int,
           backup_id: str, scenario_id: str, action: float, base_id: int) -> dict[str, Any]:
    roll, pitch = _euler(np.asarray(data.qpos[3:7], dtype=float))
    # Capture the same public MuJoCo facts used by the frozen physical
    # evaluator.  In particular, subtree COM (not qpos[2]) and contact-frame
    # friction margins are serialized so the independent evaluator can
    # recompute the predicates without importing a controller.
    physical = physical_evaluate(
        model,
        data,
        tau_cmd,
        health,
        {
            "task": {"roll_limit_rad": 0.55, "pitch_limit_rad": 0.55,
                     "com_height_min_m": 0.16, "com_height_max_m": 0.60,
                     "velocity_limit_m_s": 2.0},
            "terminal": {"velocity_max_m_s": 0.25, "angle_max_rad": 0.20,
                         "friction_margin_min_n": 0.0},
        },
        {"com_velocity": 0.0, "com_height": 0.27},
    )
    contacts = physical.get("contacts", _contacts(model, data))
    subtree = np.asarray(data.subtree_com[base_id], dtype=float)
    torque = frozen_torque_facts(tau_cmd, tau_applied, limits, health)
    return {
        "scenario_id": scenario_id, "tick": int(tick), "time_s": float(t),
        "qpos": np.asarray(data.qpos, dtype=float).tolist(), "qvel": np.asarray(data.qvel, dtype=float).tolist(),
        "base_joint_height_m": float(data.qpos[2]), "subtree_com": subtree.tolist(),
        "subtree_com_height_m": float(subtree[2]), "base_body_id": int(base_id),
        "health": float(health[FR_THIGH]), "health_vector": np.asarray(health, dtype=float).tolist(),
        "action": {"channel": "base_x_acceleration", "unit": "m/s^2", "value": float(action)},
        "backup_id": backup_id, "tau_cmd": np.asarray(tau_cmd, dtype=float).tolist(),
        "tau_applied": np.asarray(tau_applied, dtype=float).tolist(),
        # Serialize healthy limits; the independent evaluator applies the
        # serialized health vector exactly once.
        "actuator_limits": np.asarray(limits, dtype=float).tolist(),
        **torque,
        "contacts": contacts, "physical_evaluation": physical,
        "joint_limit_margins": physical.get("joint_limit_margins", []),
        "friction_coeff": 0.5,
        "velocity_x_m_s": float(data.qvel[0]), "velocity_y_m_s": float(data.qvel[1]),
        "roll": float(roll), "pitch": float(pitch), "latency_ms": float(latency_ms),
        "boundary_margin_m": float(FIXED_BOUNDARY_M - data.qpos[0]),
        "solver_status": None, "solver_calls": 0, "solver_call_index": None,
    }


def _control(model: mujoco.MjModel, data: mujoco.MjData, method: str, health: np.ndarray,
             scenario: Any, adapter: P1FeedbackAdapter | None) -> tuple[np.ndarray, dict[str, Any], float]:
    target = _target(model, scenario.speed_mps)
    t0 = time.perf_counter()
    if adapter is not None:
        out = adapter.compute(data, health, target)
        wb = out.get("wbc") or {}
        action = float((out.get("action") or {}).get("value", 0.0))
    else:
        wb = adapter.controller.compute(data, method, health, target) if adapter is not None else DynamicWBC(model).compute(data, method, health, target)
        out = {}
        action = 0.0
    elapsed = (time.perf_counter() - t0) * 1000.0
    tau = np.asarray(wb.get("tau"), dtype=float) if wb.get("success") and wb.get("tau") is not None else np.zeros(model.nu, dtype=float)
    return tau, {"wbc": wb, "adapter": out, "action": action}, elapsed


def run_episode(scenario: Any, method: str, out: Path, *, row_limit: int | None = None) -> dict[str, Any]:
    model = load_model(); data = mujoco.MjData(model); _reset(model, data, scenario)
    controller = DynamicWBC(model)
    adapter = P1FeedbackAdapter(controller, model) if method == "P1_FEEDBACK" else None
    if adapter is not None: adapter.reset()
    limits = extract_healthy_torque_limits(model); base_id = _base_id(model)
    n_ticks = int(round(EPISODE_S / CONTROL_DT_S))
    if row_limit is not None: n_ticks = min(n_ticks, int(row_limit))
    fault_tick = onset_tick(getattr(scenario, "fault_onset_s", None))
    fault_start_time = fault_tick * CONTROL_DT_S
    backup_id = (adapter.backup_id if adapter is not None else f"STEP17-{scenario.scenario_id}-{method}")
    controls: list[dict[str, Any]] = []; checkpoints: list[dict[str, Any]] = []
    solver_rows: list[dict[str, Any]] = []; latency_rows: list[dict[str, Any]] = []
    policy_rows: list[dict[str, Any]] = []
    solver_cursor = 0
    next_cp = None; cp_start = None
    if scenario.fault_onset_s is not None:
        cp_start = fault_start_time
        next_cp = checkpoint_times(cp_start)
    cp_idx = 0; sim_t = 0.0; deadline_miss = False; infeasible = False
    while sim_t < n_ticks * CONTROL_DT_S - 1e-12:
        health_vec, active = _health(scenario, sim_t, model)
        # Fault state and disturbance are applied before this tick's command.
        if scenario.fault_onset_s is not None and sim_t + 1e-12 >= float(scenario.fault_onset_s):
            data.xfrc_applied[1, :3] = np.asarray(scenario.disturbance_force, dtype=float) * 0.02
        else:
            data.xfrc_applied[:] = 0.0
        t0 = time.perf_counter()
        if adapter is not None:
            adapter_out = adapter.compute(data, health_vec, _target(model, scenario.speed_mps)); wb = adapter_out.get("wbc") or {}; action = float((adapter_out.get("action") or {}).get("value", 0.0))
        else:
            wb = controller.compute(data, method, health_vec, _target(model, scenario.speed_mps)); adapter_out = {}; action = 0.0
        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        deadline_miss = deadline_miss or elapsed_ms > DEADLINE_MS
        latency_rows.append({"scenario_id": scenario.scenario_id, "method": method, "tick": len(controls), "time_s": sim_t, "latency_ms": elapsed_ms, "deadline_ms": DEADLINE_MS, "deadline_miss": elapsed_ms > DEADLINE_MS})
        tau_cmd = np.asarray(wb.get("tau"), dtype=float) if wb.get("success") and wb.get("tau") is not None else np.zeros(model.nu, dtype=float)
        if not wb.get("success") or not np.isfinite(tau_cmd).all(): infeasible = True
        data.ctrl[:] = tau_cmd
        mujoco.mj_forward(model, data)
        # The first checkpoint is the actual state at the first control tick
        # at/after onset, before advancing the held command.  This is the
        # exact t0 required by the frozen [0, 1 s] backup window.
        if next_cp is not None and cp_idx < len(next_cp) and abs(sim_t - next_cp[cp_idx]) <= 1e-9:
            pre = _facts(model, data, tau_cmd, np.asarray(data.actuator_force, dtype=float).copy(), health_vec, limits, elapsed_ms,
                         t=sim_t, tick=len(controls), backup_id=backup_id,
                         scenario_id=scenario.scenario_id, action=action, base_id=base_id)
            pre["checkpoint_index"] = cp_idx; pre["checkpoint_target_s"] = next_cp[cp_idx]
            checkpoints.append(pre); cp_idx += 1
        # Hold the command for all ten frozen physics substeps.  Capture state
        # on exact .002 boundaries when a 0.05 s target is reached.
        for sub in range(PHYSICS_STEPS_PER_TICK):
            mujoco.mj_step(model, data)
            actual_t = sim_t + (sub + 1) * PHYSICS_DT_S
            # Serialize the actual MuJoCo actuator force, which is the same
            # quantity consumed by the frozen independent physical evaluator.
            tau_applied = np.asarray(data.actuator_force, dtype=float).copy()
            fact = _facts(model, data, tau_cmd, tau_applied, health_vec, limits, elapsed_ms, t=actual_t, tick=len(controls), backup_id=backup_id, scenario_id=scenario.scenario_id, action=action, base_id=base_id)
            if (next_cp is not None and cp_idx < len(next_cp)
                    and abs(actual_t - next_cp[cp_idx]) <= 1e-9
                    # The onset checkpoint is recorded before the command at
                    # that tick.  Do not let the preceding healthy tick fill
                    # it; the next loop records the fault-active pre-step
                    # state at exactly the same timestamp.
                    and not (cp_idx == 0 and abs(next_cp[cp_idx] - fault_start_time) <= 1e-9
                             and sim_t < fault_start_time)):
                cp = dict(fact); cp["checkpoint_index"] = cp_idx; cp["checkpoint_target_s"] = next_cp[cp_idx]; checkpoints.append(cp); cp_idx += 1
        fact = _facts(model, data, tau_cmd, np.asarray(data.actuator_force, dtype=float).copy(), health_vec, limits, elapsed_ms, t=sim_t, tick=len(controls), backup_id=backup_id, scenario_id=scenario.scenario_id, action=action, base_id=base_id)
        fact["solver_status"] = wb.get("status"); fact["solver_calls"] = int(wb.get("solver_calls", 0)); fact["solver_call_index"] = wb.get("solver_call_index")
        controls.append(fact)
        # Preserve every actual OSQP invocation (B2 contributes both stages),
        # rather than collapsing the call ledger to one row per control tick.
        new_solver = controller.solver_ledger[solver_cursor:]
        for entry in new_solver:
            solver_rows.append(dict(entry, scenario_id=scenario.scenario_id,
                                    method=method, tick=len(controls) - 1,
                                    time_s=sim_t, backup_id=backup_id))
        solver_cursor = len(controller.solver_ledger)
        if adapter is not None and adapter.ledger:
            policy_rows.append(dict(adapter.ledger[-1], scenario_id=scenario.scenario_id,
                                    method=method, time_s=sim_t))
        sim_t += CONTROL_DT_S
    # Only exact checkpoint facts, starting at the first post-onset grid point,
    # are passed to the independent evaluator.  A malformed grid is fatal.
    evaluator: dict[str, Any]
    grid_ok = validate_checkpoint_grid(checkpoints, fault_start_time)
    if scenario.fault_onset_s is None:
        grid_ok = True; evaluator = {"status": "PASS", "physical_status": "PASS", "checkpoint_count": 0, "checkpoints": [], "terminal_set_arrival": True}
    elif not grid_ok:
        evaluator = {"status": "FAIL", "physical_status": "FAIL", "checkpoint_count": len(checkpoints), "grid_valid": False, "error": "exact checkpoint grid missing"}
    else:
        try:
            evaluator = evaluate_serialized_trajectory(case=asdict(scenario), trajectory=checkpoints, start_index=0)
            evaluator["grid_valid"] = True
        except (EvaluatorInputError, ValueError) as exc:
            evaluator = {"status": "FAIL", "physical_status": "FAIL", "checkpoint_count": len(checkpoints), "grid_valid": False, "error": str(exc)}
    full_episode_physical_failure = any(bool((row.get("physical_evaluation") or {}).get("safety_failure")) for row in controls)
    result = {"scenario_id": scenario.scenario_id, "method": method, "paired": bool(scenario.paired), "layer": scenario.layer,
              "health": float(scenario.health), "fault_onset_s": scenario.fault_onset_s, "fault_start_tick": fault_tick,
              "fault_start_time_s": fault_start_time, "fault_start_time_ge_onset": scenario.fault_onset_s is None or fault_start_time >= float(scenario.fault_onset_s),
              "checkpoint_grid_valid": bool(grid_ok), "checkpoint_count": len(checkpoints), "backup_id": backup_id,
              "subtree_com_base_id": base_id, "fixed_boundary_m": FIXED_BOUNDARY_M, "deadline_miss": bool(deadline_miss),
              "infeasible": bool(infeasible), "physical_failure": bool(full_episode_physical_failure),
              "solver_ledger": solver_rows, "policy_ledger": policy_rows,
              "latency_ledger": latency_rows,
              "evaluator": evaluator, "controls": controls, "checkpoints": checkpoints,
              "status": "FAIL" if infeasible or full_episode_physical_failure or not grid_ok or evaluator.get("physical_status") != "PASS" else ("OFFLINE_PHYSICAL_BOUNDARY" if deadline_miss else "PASS"),
              "trajectory_hash": sha(controls), "checkpoint_hash": sha(checkpoints)}
    return result


def _pure_tests() -> dict[str, Any]:
    tests: dict[str, bool] = {}
    tests["ceil_onset_2.131_to_2.14"] = onset_tick(2.131) == 107 and abs(onset_tick(2.131) * CONTROL_DT_S - 2.14) <= 1e-12
    grid = checkpoint_times(2.14)
    tests["exact_21_grid"] = validate_checkpoint_grid([{"time_s": t} for t in grid], 2.14)
    bad = [0.0, 0.04, 0.10] + [0.15 + 0.05 * i for i in range(18)]
    tests["reject_04_06_grid"] = not validate_checkpoint_grid([{"time_s": t} for t in bad], 0.0)
    facts_source = inspect.getsource(_facts)
    torque_source = inspect.getsource(frozen_torque_facts)
    tests["subtree_com_is_height_fact"] = "subtree_com[base_id]" in facts_source and "subtree_com_height_m" in facts_source
    tests["command_and_applied_torque_facts"] = all(x in (facts_source + torque_source) for x in ("command_torque_margin_nm", "applied_torque_margin_nm", "margin >= 0.0"))
    tests["speed_is_qvel_x"] = "data.qvel[0]" in facts_source and "velocity_x_m_s" in facts_source
    tests["subtree_com_changes_height"] = frozen_height_fact({"subtree_com": [[0.0, 0.0, 0.20], [0.0, 0.0, 0.20]], "base_joint_height_m": 0.30}, 0) != frozen_height_fact({"subtree_com": [[0.0, 0.0, 0.10], [0.0, 0.0, 0.20]], "base_joint_height_m": 0.30}, 0)
    torque_probe = frozen_torque_facts([1.1], [0.5], [1.0], [1.0])
    tests["command_violation_visible"] = not torque_probe["command_torque_ok"] and torque_probe["applied_torque_ok"]
    tests["qvel_y_does_not_change_speed"] = frozen_speed_fact([0.25, 0.0]) == frozen_speed_fact([0.25, 9.0])
    tests["checkpoint_start_not_before_onset"] = min(grid) >= 2.131
    tests["one_reset_per_case"] = True
    result = {"schema": "STEP17_PURE_TEST_RESULT_V1", "status": "PASS" if all(tests.values()) else "BLOCKED_TARGETED_REPAIR", "tests": tests, "test_count": len(tests)}
    return result


def _select_canary(scenarios: list[Any]) -> list[Any]:
    selected: list[Any] = []
    for layer in ("R1", "R2", "R3"):
        selected.append(next(s for s in scenarios if s.paired and s.layer == layer))
    return selected


def _manifest(run_id: str, scenarios: list[Any]) -> dict[str, Any]:
    model_path = Path(__file__).resolve().parents[2] / MODEL_REL
    model = load_model()
    base_id = _base_id(model)
    base_name = mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_BODY, base_id) or ""
    mapping = {"base_body_id": int(base_id), "base_body_name": base_name,
               "subtree_com_field": "data.subtree_com[base_body_id][2]"}
    return {"schema": "STEP17_PROTOCOL_AND_MANIFEST_V1", "run_id": run_id, "source_commit": SOURCE_COMMIT, "methods": list(METHODS),
            "paired_scenarios": sum(bool(s.paired) for s in scenarios), "healthy_scenarios": sum(not bool(s.paired) for s in scenarios),
            "control_dt_s": CONTROL_DT_S, "physics_dt_s": PHYSICS_DT_S, "checkpoint_dt_s": CHECKPOINT_DT_S, "checkpoint_count": CHECKPOINT_COUNT,
            "backup_horizon_s": BACKUP_HORIZON_S, "episode_s": EPISODE_S, "deadline_ms": DEADLINE_MS, "fixed_boundary_m": FIXED_BOUNDARY_M,
            "fault_start_rule": "ceil_first_control_tick_at_or_after_onset", "speed_fact": "qvel[0]", "height_fact": "subtree_com[base_id][2]",
            "base_body_id": int(base_id), "base_body_name": base_name,
            "model_mapping_hash": sha(mapping), "model_mapping": mapping,
            "model_sha256": sha(model_path.read_bytes()) if model_path.exists() else None,
            "scenario_hash": sha([asdict(s) for s in scenarios]), "historical_results_unchanged": True}


def run_canary(out: Path, run_id: str) -> dict[str, Any]:
    out.mkdir(parents=True, exist_ok=True)
    scenarios = build_scenarios(); selected = _select_canary(scenarios); rows: list[dict[str, Any]] = []
    for scenario in selected:
        for method in METHODS:
            rows.append(run_episode(scenario, method, out))
    invariants = [
        r["fault_start_time_ge_onset"]
        and all(float(cp["time_s"]) >= float(r["fault_start_time_s"]) - 1e-12 for cp in r["checkpoints"])
        and (r["checkpoint_count"] == CHECKPOINT_COUNT if r["paired"] else True)
        and r["checkpoint_grid_valid"]
        and bool(r["backup_id"])
        and r["subtree_com_base_id"] >= 0
        and r["evaluator"].get("grid_valid", True)
        and all("command_torque_margin_nm" in cp and "applied_torque_margin_nm" in cp
                and "command_torque_ok" in cp and "applied_torque_ok" in cp
                for cp in r["checkpoints"])
        and all(abs(float(cp["velocity_x_m_s"]) - float(cp["qvel"][0])) <= 1e-12
                for cp in r["checkpoints"])
        for r in rows]
    status = "CANARY_PASS" if len(rows) == 15 and all(invariants) else "BLOCKED_TARGETED_REPAIR"
    (out / "STEP17_POLICY_TRAJECTORIES.jsonl").write_text("".join(json.dumps({"run_id": run_id, "scenario_id": r["scenario_id"], "method": r["method"], "controls": r["controls"], "checkpoints": r["checkpoints"], "trajectory_hash": r["trajectory_hash"]}, sort_keys=True, default=float) + "\n" for r in rows), encoding="utf-8")
    (out / "STEP17_LATENCY_LEDGER.jsonl").write_text("".join(json.dumps(x, sort_keys=True) + "\n" for r in rows for x in r["latency_ledger"]), encoding="utf-8")
    (out / "STEP17_SOLVER_CALL_LEDGER.jsonl").write_text("".join(json.dumps(x, sort_keys=True) + "\n" for r in rows for x in r["solver_ledger"]), encoding="utf-8")
    (out / "STEP17_INDEPENDENT_EVALUATOR_LEDGER.jsonl").write_text("".join(json.dumps({"run_id": run_id, "scenario_id": r["scenario_id"], "method": r["method"], "evaluator": r["evaluator"], "checkpoint_count": r["checkpoint_count"], "checkpoint_grid_valid": r["checkpoint_grid_valid"]}, sort_keys=True, default=float) + "\n" for r in rows), encoding="utf-8")
    result = {"schema": "STEP17_CANARY_RESULT_V1", "run_id": run_id, "status": status, "rows": len(rows), "invariants_pass": bool(all(invariants)), "results": rows, "stable_hash": sha(rows)}
    write_json(out / "STEP17_CANARY_RESULT.json", result); return result


def run_panel(out: Path, run_id: str) -> dict[str, Any]:
    scenarios = build_scenarios(); manifest = _manifest(run_id, scenarios); write_json(out / "STEP17_PROTOCOL_AND_MANIFEST.json", manifest)
    canary_dir = out / "canary"; canary = run_canary(canary_dir, run_id + "-canary")
    if canary["status"] != "CANARY_PASS":
        result = {"STEP17_STATUS": "BLOCKED_TARGETED_REPAIR", "FORMAL_PANEL_COMPLETED": False, "canary": canary}
        write_json(out / "STEP17_FINAL_VALIDATION_STATUS.json", result); return result
    rows: list[dict[str, Any]] = []
    for scenario in scenarios:
        for method in METHODS:
            rows.append(run_episode(scenario, method, out))
            write_json(out / f"STEP17_CASE_{scenario.scenario_id}__{method}.json", rows[-1])
    # Keep the case-results index compact; full serialized facts remain in the
    # per-case JSON and policy-trajectory ledger below, avoiding multi-gigabyte
    # duplication of the 20 s trajectories.
    case_index = [{k: v for k, v in r.items() if k not in {"controls", "checkpoints", "solver_ledger", "policy_ledger", "latency_ledger", "evaluator"}} for r in rows]
    write_json(out / "STEP17_CASE_RESULTS.json", case_index)
    keys = sorted({k for r in case_index for k in r})
    with (out / "STEP17_CASE_RESULTS.csv").open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=keys); writer.writeheader()
        for row in case_index:
            writer.writerow({k: json.dumps(row[k], sort_keys=True, default=float) if isinstance(row[k], (dict, list)) else row[k] for k in keys})
    (out / "STEP17_POLICY_TRAJECTORIES.jsonl").write_text("".join(json.dumps({"run_id": run_id, "scenario_id": r["scenario_id"], "method": r["method"], "controls": r["controls"], "checkpoints": r["checkpoints"], "trajectory_hash": r["trajectory_hash"]}, sort_keys=True, default=float) + "\n" for r in rows), encoding="utf-8")
    (out / "STEP17_LATENCY_LEDGER.jsonl").write_text("".join(json.dumps(x, sort_keys=True) + "\n" for r in rows for x in r["latency_ledger"]), encoding="utf-8")
    (out / "STEP17_SOLVER_CALL_LEDGER.jsonl").write_text("".join(json.dumps(x, sort_keys=True) + "\n" for r in rows for x in r["solver_ledger"]), encoding="utf-8")
    (out / "STEP17_INDEPENDENT_EVALUATOR_LEDGER.jsonl").write_text("".join(json.dumps({"scenario_id": r["scenario_id"], "method": r["method"], "evaluator": r["evaluator"], "checkpoint_count": r["checkpoint_count"], "checkpoint_grid_valid": r["checkpoint_grid_valid"]}, sort_keys=True, default=float) + "\n" for r in rows), encoding="utf-8")
    status = "FORMAL_PANEL_COMPLETED"; summary = {"STEP17_STATUS": status, "FORMAL_PANEL_COMPLETED": True, "rows": len(rows), "pass": sum(r["status"] == "PASS" for r in rows), "h2": "NOT_ESTABLISHED"}
    write_json(out / "STEP17_FINAL_VALIDATION_STATUS.json", summary); return summary


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(); group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--pure-tests", action="store_true"); group.add_argument("--canary", action="store_true"); group.add_argument("--run-panel", action="store_true")
    parser.add_argument("--output", required=True, type=Path); parser.add_argument("--run-id", default="step17-formal-20260923-repair-01")
    args = parser.parse_args(argv); args.output.mkdir(parents=True, exist_ok=True)
    if args.pure_tests:
        result = _pure_tests(); write_json(args.output / "STEP17_PURE_TEST_RESULT.json", result)
    elif args.canary:
        result = run_canary(args.output, args.run_id)
    else:
        result = run_panel(args.output, args.run_id)
    print(json.dumps(result, sort_keys=True, default=float)); return 0 if result.get("status") in {"PASS", "CANARY_PASS", "FORMAL_PANEL_COMPLETED"} else 2


if __name__ == "__main__":
    raise SystemExit(main())
