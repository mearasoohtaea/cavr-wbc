"""STEP19 storage-only streaming wrapper around the frozen STEP17 episode runner.

No controller, evaluator, scenario or threshold code lives here.  This module
only shards completed case/method results and builds bounded compact indexes.
"""
from __future__ import annotations

import gc
import hashlib
import json
import os
import argparse
from dataclasses import asdict
from pathlib import Path
from typing import Any, Iterable, Callable

from cavr_wbc.experiments import step17_formal_panel as base

METHODS = base.METHODS
CHECKPOINT_COUNT = base.CHECKPOINT_COUNT
SOURCE_OBJECT = "32b7a20113f5bcccc27721ea1a13d336f5519251"


def _atomic_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".tmp-{os.getpid()}")
    with tmp.open("w", encoding="utf-8", newline="") as fh:
        fh.write(text); fh.flush(); os.fsync(fh.fileno())
    os.replace(tmp, path)


def _json(path: Path, value: Any) -> None:
    _atomic_text(path, json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False, default=float) + "\n")


def _digest(value: Any) -> str:
    return base.sha(value)


def _manifest_fingerprint(manifest: dict[str, Any]) -> str:
    frozen = {k: v for k, v in manifest.items()
              if k not in {"persistence_status", "persistence_outputs", "case_index_sha256", "frozen_manifest_hash"}}
    return _digest(frozen)


def _stream_jsonl(path: Path, rows: Iterable[Any]) -> tuple[int, str]:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".tmp-{os.getpid()}")
    h = hashlib.sha256(); count = 0
    with tmp.open("wb") as fh:
        for row in rows:
            raw = (json.dumps(row, sort_keys=True, separators=(",", ":"), default=float) + "\n").encode("utf-8")
            fh.write(raw); h.update(raw); count += 1
        fh.flush(); os.fsync(fh.fileno())
    os.replace(tmp, path)
    read_count, read_hash = _read_jsonl(path)
    if read_count != count or read_hash != h.hexdigest():
        raise RuntimeError(f"stream ledger read-back mismatch: {path}")
    return count, h.hexdigest()


def _iter_jsonl(path: Path) -> Iterable[dict[str, Any]]:
    with path.open("rb") as fh:
        for raw in fh:
            if raw.strip():
                yield json.loads(raw.decode("utf-8"))


def _read_jsonl(path: Path) -> tuple[int, str]:
    h = hashlib.sha256(); count = 0
    with path.open("rb") as fh:
        for raw in fh:
            if raw.strip():
                json.loads(raw.decode("utf-8")); h.update(raw); count += 1
    return count, h.hexdigest()


def _append_ledger(path: Path, row: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = (json.dumps(row, sort_keys=True, separators=(",", ":"), default=float) + "\n").encode("utf-8")
    with path.open("ab") as fh:
        fh.write(raw); fh.flush(); os.fsync(fh.fileno())


def _states(path: Path) -> dict[str, dict[str, Any]]:
    out: dict[str, dict[str, Any]] = {}
    if path.exists():
        with path.open("rb") as fh:
            for raw in fh:
                if raw.strip():
                    row = json.loads(raw.decode("utf-8")); out[str(row["identity"])] = row
    return out


def _case_invariants(result: dict[str, Any]) -> bool:
    if not result.get("fault_start_time_ge_onset"):
        return False
    if result.get("paired") and result.get("checkpoint_count") != CHECKPOINT_COUNT:
        return False
    if not result.get("checkpoint_grid_valid") or not result.get("backup_id"):
        return False
    evaluator = result.get("evaluator")
    if not isinstance(evaluator, dict) or "status" not in evaluator or "physical_status" not in evaluator:
        return False
    for cp in result.get("checkpoints", []):
        if float(cp.get("time_s", -1.0)) < float(result.get("fault_start_time_s", 0.0)) - 1e-12:
            return False
        if not all(k in cp for k in ("command_torque_margin_nm", "applied_torque_margin_nm", "command_torque_ok", "applied_torque_ok")):
            return False
        if abs(float(cp.get("velocity_x_m_s")) - float(cp.get("qvel")[0])) > 1e-12:
            return False
        if cp.get("backup_id") not in (None, result.get("backup_id")):
            return False
    return bool(result.get("solver_ledger")) and bool(result.get("latency_ledger"))


def _meta_from_payload(path: Path, payload: dict[str, Any]) -> dict[str, Any]:
    r = payload["result"]
    return {"identity": f"{payload['phase']}:{payload['scenario_id']}:{payload['method']}",
            "phase": payload["phase"], "scenario_id": payload["scenario_id"], "method": payload["method"],
            "paired": bool(payload["scenario"].get("paired")), "layer": payload["scenario"].get("layer"),
            "health": float(payload["scenario"].get("health", 0.0)), "status": r.get("status"),
            "fault_start_time_s": r.get("fault_start_time_s"), "fault_start_time_ge_onset": r.get("fault_start_time_ge_onset"),
            "checkpoint_count": r.get("checkpoint_count"), "checkpoint_grid_valid": r.get("checkpoint_grid_valid"),
            "backup_id": r.get("backup_id"), "deadline_miss": r.get("deadline_miss"),
            "physical_failure": r.get("physical_failure"), "infeasible": r.get("infeasible"),
            "shard": str(path), "result_hash": payload["result_hash"],
            "trajectory_hash": payload.get("trajectory_hash"), "checkpoint_hash": payload.get("checkpoint_hash"),
            "policy_rows": len(r.get("policy_ledger", [])), "solver_rows": len(r.get("solver_ledger", [])),
            "latency_rows": len(r.get("latency_ledger", [])), "policy_hash": _digest(r.get("policy_ledger", [])),
            "solver_hash": _digest(r.get("solver_ledger", [])), "latency_hash": _digest(r.get("latency_ledger", [])),
            "evaluator_hash": _digest(r.get("evaluator", {})), "evaluator_status": r.get("evaluator", {}).get("status")}


def _write_shard(path: Path, run_id: str, phase: str, scenario: Any, method: str,
                 result: dict[str, Any], manifest_hash: str, manifest_facts: dict[str, Any]) -> dict[str, Any]:
    payload = {"schema": "STEP19_CASE_SHARD_V1", "run_id": run_id, "phase": phase,
               "scenario_id": scenario.scenario_id, "method": method, "scenario": asdict(scenario),
               "manifest_hash": manifest_hash, "manifest_facts": manifest_facts,
               "result": result, "result_hash": _digest(result),
               "trajectory_hash": result.get("trajectory_hash"), "checkpoint_hash": result.get("checkpoint_hash")}
    _json(path, payload)
    with path.open("r", encoding="utf-8") as fh:
        read_back = json.load(fh)
    if read_back.get("manifest_hash") != manifest_hash or read_back.get("result_hash") != _digest(read_back.get("result")):
        raise RuntimeError(f"shard hash/config mismatch: {path}")
    return _meta_from_payload(path, read_back)


def _case_stream(out: Path, run_id: str, phase: str, scenario: Any, method: str,
                 manifest_hash: str, manifest_facts: dict[str, Any], states: dict[str, dict[str, Any]]) -> dict[str, Any]:
    identity = f"{phase}:{scenario.scenario_id}:{method}"
    root = out / "cases"
    shard = root / f"{phase}__{scenario.scenario_id}__{method}" / "STEP19_CASE_SHARD.json"
    prior = states.get(identity)
    if prior is None and shard.exists():
        raise RuntimeError(f"orphan shard without ledger state: {identity}")
    if prior:
        if prior.get("status") != "DONE" or not shard.exists():
            raise RuntimeError(f"{identity} is STARTED_UNKNOWN or missing")
        with shard.open("r", encoding="utf-8") as fh:
            payload = json.load(fh)
        if payload.get("manifest_hash") != manifest_hash or payload.get("manifest_facts") != manifest_facts or payload.get("result_hash") != _digest(payload.get("result")):
            raise RuntimeError(f"incompatible DONE shard: {identity}")
        if not _case_invariants(payload["result"]):
            raise RuntimeError(f"invalid DONE shard: {identity}")
        # DONE shards are immutable; verify and reference without rewriting.
        return _meta_from_payload(shard, payload)
    start_row = {"run_id": run_id, "identity": identity, "phase": phase,
                 "scenario_id": scenario.scenario_id, "method": method, "status": "STARTED_UNKNOWN"}
    _append_ledger(out / "STEP19_RUN_LEDGER.jsonl", start_row)
    states[identity] = start_row
    result = base.run_episode(scenario, method, out)
    if not _case_invariants(result):
        raise RuntimeError(f"scientific invariant failed: {identity}")
    meta = _write_shard(shard, run_id, phase, scenario, method, result, manifest_hash, manifest_facts)
    done_row = {"run_id": run_id, "identity": identity, "phase": phase,
                "scenario_id": scenario.scenario_id, "method": method,
                "status": "DONE", "result_hash": meta["result_hash"], "shard": meta["shard"]}
    _append_ledger(out / "STEP19_RUN_LEDGER.jsonl", done_row)
    states[identity] = done_row
    del result; gc.collect()
    return meta


def _compact_ledgers(out: Path, run_id: str, metas: Iterable[dict[str, Any]]) -> dict[str, Any]:
    specs = {
        "STEP19_POLICY_LEDGER.jsonl": ("policy_rows", "policy_hash"),
        "STEP19_SOLVER_CALL_LEDGER.jsonl": ("solver_rows", "solver_hash"),
        "STEP19_LATENCY_LEDGER.jsonl": ("latency_rows", "latency_hash"),
        "STEP19_INDEPENDENT_EVALUATOR_LEDGER.jsonl": ("evaluator_status", "evaluator_hash"),
    }
    manifest: dict[str, Any] = {}
    for filename, (rows_key, hash_key) in specs.items():
        def rows() -> Iterable[dict[str, Any]]:
            for m in metas:
                yield {"run_id": run_id, "phase": m["phase"], "scenario_id": m["scenario_id"],
                       "method": m["method"], "shard": m["shard"],
                       "rows": m[rows_key] if rows_key.endswith("_rows") else 1, "hash": m[hash_key]}
        count, digest = _stream_jsonl(out / filename, rows())
        manifest[filename] = {"rows": count, "sha256": digest, "path": str(out / filename)}
    return manifest


def _compact_ledgers_from_jsonl(out: Path, run_id: str, source: Path) -> dict[str, Any]:
    specs = {
        "STEP19_POLICY_LEDGER.jsonl": ("policy_rows", "policy_hash"),
        "STEP19_SOLVER_CALL_LEDGER.jsonl": ("solver_rows", "solver_hash"),
        "STEP19_LATENCY_LEDGER.jsonl": ("latency_rows", "latency_hash"),
        "STEP19_INDEPENDENT_EVALUATOR_LEDGER.jsonl": ("evaluator_status", "evaluator_hash"),
    }
    manifest: dict[str, Any] = {}
    for filename, (rows_key, hash_key) in specs.items():
        def rows() -> Iterable[dict[str, Any]]:
            for m in _iter_jsonl(source):
                yield {"run_id": run_id, "phase": m["phase"], "scenario_id": m["scenario_id"],
                       "method": m["method"], "shard": m["shard"],
                       "rows": m[rows_key] if rows_key.endswith("_rows") else 1, "hash": m[hash_key]}
        count, digest = _stream_jsonl(out / filename, rows())
        manifest[filename] = {"rows": count, "sha256": digest, "path": str(out / filename)}
    return manifest


def _stream_index(path: Path, metas: Iterable[dict[str, Any]]) -> tuple[int, str]:
    path.parent.mkdir(parents=True, exist_ok=True); tmp = path.with_name(path.name + f".tmp-{os.getpid()}")
    h = hashlib.sha256(); count = 0
    with tmp.open("wb") as fh:
        fh.write(b"[\n"); first = True
        for m in metas:
            if not first: fh.write(b",\n")
            first = False
            raw = json.dumps(m, sort_keys=True, separators=(",", ":"), default=float).encode("utf-8")
            fh.write(raw); h.update(raw); count += 1
        fh.write(b"\n]\n"); fh.flush(); os.fsync(fh.fileno())
    os.replace(tmp, path)
    read_count = 0; first_nonempty = None; previous_nonempty = None
    with path.open("rb") as fh:
        for line in fh:
            raw = line.strip()
            if not raw: continue
            if first_nonempty is None: first_nonempty = raw
            previous_nonempty = raw
            if raw in (b"[", b"]"): continue
            if raw.endswith(b","): raw = raw[:-1]
            json.loads(raw.decode("utf-8")); read_count += 1
    if first_nonempty != b"[" or previous_nonempty != b"]":
        raise RuntimeError(f"index framing mismatch: {path}")
    if read_count != count:
        raise RuntimeError(f"index read-back mismatch: {path}")
    return count, h.hexdigest()


def _write_reports(out: Path, status: str, completed: bool, note: str) -> None:
    _atomic_text(out / "STEP19_REPORT.md", f"# STEP19 streaming panel report\n\n```ini\nSTEP19_STATUS = {status}\nFORMAL_PANEL_COMPLETED = {str(completed).upper()}\n```\n\n{note}\n\nSTEP16, STEP17 and STEP18 outputs remain preserved and excluded. E3, parameter search and historical reruns were not performed.\n")
    _atomic_text(out / "STEP19_RESEARCH_HANDOFF.md", f"# STEP19 research handoff\n\n- Status: `{status}`.\n- Formal panel completed: `{completed}`.\n- {note}\n- STEP16/17/18 evidence preserved and excluded.\n- E3/search/history reruns: not authorized and not performed.\n")


def _verify_run_ledger(path: Path, expected_identities: int) -> dict[str, Any]:
    last: dict[str, dict[str, Any]] = {}; starts: dict[str, int] = {}; dones: dict[str, int] = {}; rows = 0
    for row in _iter_jsonl(path):
        rows += 1; ident = str(row["identity"]); last[ident] = row
        if row.get("status") == "STARTED_UNKNOWN": starts[ident] = starts.get(ident, 0) + 1
        if row.get("status") == "DONE": dones[ident] = dones.get(ident, 0) + 1
    if len(last) != expected_identities or any(v != 1 for v in starts.values()) or any(v != 1 for v in dones.values()):
        raise RuntimeError("run ledger duplicate or incomplete transitions")
    if any(row.get("status") != "DONE" for row in last.values()):
        raise RuntimeError("run ledger contains STARTED_UNKNOWN at finalization")
    return {"rows": rows, "identities": len(last), "starts": sum(starts.values()), "dones": sum(dones.values())}


def run_streaming_panel(out: Path, run_id: str) -> dict[str, Any]:
    existing = set(p.name for p in out.iterdir()) if out.exists() else set()
    if existing - {"STEP19_STORAGE_TEST_RESULT.json", "storage_test"}:
        return {"STEP19_STATUS": "BLOCKED_STREAMING_PERSISTENCE", "FORMAL_PANEL_COMPLETED": False,
                "formal_panel_started": False, "error": "output root is non-empty; refusing overwrite"}
    out.mkdir(parents=True, exist_ok=True)
    scenarios = base.build_scenarios()
    manifest = base._manifest(run_id, scenarios)
    manifest.update({"schema": "STEP19_PROTOCOL_AND_MANIFEST_V1", "source_commit": SOURCE_OBJECT,
                     "streaming_storage": True, "persistence_status": "PENDING", "persistence_outputs": {}})
    # The frozen manifest identity is immutable across the canary/panel updates;
    # persistence-status fields are deliberately excluded from this hash.
    manifest_hash = _manifest_fingerprint(manifest)
    manifest["frozen_manifest_hash"] = manifest_hash
    _json(out / "STEP19_PROTOCOL_AND_MANIFEST.json", manifest)
    manifest_facts = {"manifest_hash": manifest_hash, "source_commit": SOURCE_OBJECT,
                      "model_sha256": manifest.get("model_sha256"),
                      "model_mapping_hash": manifest.get("model_mapping_hash"),
                      "scenario_hash": manifest.get("scenario_hash"),
                      "deadline_ms": manifest.get("deadline_ms"),
                      "checkpoint_count": manifest.get("checkpoint_count"),
                      "backup_horizon_s": manifest.get("backup_horizon_s")}
    states = _states(out / "STEP19_RUN_LEDGER.jsonl")
    canary: list[dict[str, Any]] = []
    try:
        for scenario in base._select_canary(scenarios):
            for method in METHODS:
                canary.append(_case_stream(out, run_id, "canary", scenario, method, manifest_hash, manifest_facts, states))
        if len(canary) != 15:
            raise RuntimeError("canary did not produce 15 DONE shards")
        canary_ledgers = _compact_ledgers(out / "canary", run_id, canary)
        canary_summary = {"schema": "STEP19_CANARY_RESULT_V1", "run_id": run_id, "status": "CANARY_PASS",
                          "rows": 15, "rows_done": 15, "results": canary, "stable_hash": _digest(canary),
                          "persistence_status": "PASS", "ledger_manifest": canary_ledgers}
        _json(out / "canary/STEP19_CANARY_RESULT.json", canary_summary)
        manifest.update({"persistence_status": "PASS", "persistence_outputs": canary_ledgers})
        _json(out / "STEP19_PROTOCOL_AND_MANIFEST.json", manifest)
    except Exception as exc:
        result = {"STEP19_STATUS": "BLOCKED_STREAMING_PERSISTENCE", "FORMAL_PANEL_COMPLETED": False,
                  "formal_panel_started": False, "canary_rows_done": len(canary),
                  "error": f"{type(exc).__name__}: {exc}"}
        _json(out / "STEP19_FINAL_VALIDATION_STATUS.json", result)
        _write_reports(out, "BLOCKED_STREAMING_PERSISTENCE", False, f"Canary stopped without retry: {result['error']}")
        return result

    panel_source = out / "STEP19_PANEL_COMPACT.jsonl"
    panel_count = 0; panel_pass = 0
    try:
        for scenario in scenarios:
            for method in METHODS:
                meta = _case_stream(out, run_id, "panel", scenario, method, manifest_hash, manifest_facts, states)
                _append_ledger(panel_source, meta)
                panel_count += 1; panel_pass += int(meta["status"] == "PASS")
        if panel_count != 450:
            raise RuntimeError("formal panel did not produce 450 DONE shards")
        _, index_hash = _stream_index(out / "STEP19_CASE_RESULTS.json", _iter_jsonl(panel_source))
        ledgers = _compact_ledgers_from_jsonl(out, run_id, panel_source)
        ledger_summary = _verify_run_ledger(out / "STEP19_RUN_LEDGER.jsonl", 465)
        manifest.update({"persistence_status": "PASS", "persistence_outputs": ledgers, "case_index_sha256": index_hash})
        if _manifest_fingerprint(manifest) != manifest_hash:
            raise RuntimeError("frozen manifest fingerprint changed")
        _json(out / "STEP19_PROTOCOL_AND_MANIFEST.json", manifest)
        summary = {"STEP19_STATUS": "FORMAL_PANEL_COMPLETED", "FORMAL_PANEL_COMPLETED": True,
                   "rows": 450, "pass": panel_pass,
                   "h2": "NOT_ESTABLISHED", "persistence_status": "PASS", "ledger_manifest": ledgers,
                   "run_ledger": ledger_summary}
        _json(out / "STEP19_FINAL_VALIDATION_STATUS.json", summary)
        _write_reports(out, "FORMAL_PANEL_COMPLETED", True, "All 450 case shards and compact ledgers were atomically persisted and read-back verified.")
        return summary
    except Exception as exc:
        result = {"STEP19_STATUS": "BLOCKED_STREAMING_PERSISTENCE", "FORMAL_PANEL_COMPLETED": False,
                  "formal_panel_started": True, "rows_done": panel_count, "error": f"{type(exc).__name__}: {exc}"}
        _json(out / "STEP19_FINAL_VALIDATION_STATUS.json", result)
        _write_reports(out, "BLOCKED_STREAMING_PERSISTENCE", False, f"Panel stopped without retry after storage/integrity error: {result['error']}")
        return result


def main() -> int:
    parser = argparse.ArgumentParser(description="STEP19 bounded streaming panel")
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    result = run_streaming_panel(args.output, args.run_id)
    print(json.dumps(result, sort_keys=True, ensure_ascii=False))
    return 0 if result.get("STEP19_STATUS") == "FORMAL_PANEL_COMPLETED" else 2


if __name__ == "__main__":
    raise SystemExit(main())
