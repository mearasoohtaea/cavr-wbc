"""Bounded STEP20 physical episode; no persistence or experiment dispatch."""
from __future__ import annotations

from collections import Counter
from dataclasses import asdict
from time import perf_counter
import math
import traceback
import mujoco
import numpy as np

from cavr_wbc.control.step20_task_reference import TaskManager, TaskResponseWBC, reference
from cavr_wbc.experiments import step17_formal_panel as frozen
from cavr_wbc.evaluation.step16_independent_evaluator import evaluate_serialized_trajectory
from cavr_wbc.platforms.go2_mujoco import extract_healthy_torque_limits

PHYSICS_STEPS = 1100
CONTROL_TICKS = 110
CHECKPOINT_STEPS = tuple(range(100, 601, 25))


def json_safe(value):
    if isinstance(value, np.ndarray):
        return json_safe(value.tolist())
    if isinstance(value, np.generic):
        return json_safe(value.item())
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [json_safe(x) for x in value]
    if isinstance(value, float) and not math.isfinite(value):
        return {"nonfinite": repr(value)}
    return value


def channel_mapping(model) -> dict:
    free = [j for j in range(model.njnt) if model.jnt_type[j] == mujoco.mjtJoint.mjJNT_FREE]
    if len(free) != 1 or model.jnt_qposadr[free[0]] != 0 or model.jnt_dofadr[free[0]] != 0:
        raise ValueError("STEP20 requires root free joint at qpos/dof address 0")
    names = [mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_ACTUATOR, i) for i in range(model.nu)]
    if names[1] != "FR_thigh" or abs(model.opt.timestep - .002) > 1e-12:
        raise ValueError("Frozen actuator mapping/timestep mismatch")
    return {"free_joint_id": free[0], "free_joint_body_id": int(model.jnt_bodyid[free[0]]),
            "position": "world base x: qpos[0] [m]", "velocity": "world base x: qvel[0] [m/s]",
            "desired_acceleration": "desired_base_accel[0] [m/s^2]",
            "not_whole_robot_com_tracking": True, "actuator_names": names,
            "fault_actuator_indices": [1], "physics_dt_s": float(model.opt.timestep)}


def state_values(data) -> dict:
    return {"time_s": float(data.time), "qpos": data.qpos.copy().tolist(),
            "qvel": data.qvel.copy().tolist(), "act": data.act.copy().tolist(),
            "ctrl": data.ctrl.copy().tolist(), "qacc_warmstart": data.qacc_warmstart.copy().tolist(),
            "xfrc_applied": data.xfrc_applied.copy().tolist()}


def initial_state_facts(scenario) -> dict:
    model = frozen.load_model(); data = mujoco.MjData(model)
    frozen._reset(model, data, scenario)
    state = state_values(data)
    return {"state": state, "state_hash": frozen.sha(state), "mapping": channel_mapping(model),
            "healthy_torque_limits_nm": extract_healthy_torque_limits(model).tolist(),
            "integrator": int(model.opt.integrator), "nq": model.nq, "nv": model.nv, "nu": model.nu}


def health_at_tick(input_id: str, tick: int, nu: int = 12) -> np.ndarray:
    h = np.ones(nu)
    if input_id == "S20_H050_POS" and tick >= 10:
        h[1] = .5
    return h


def task_metrics(controls: list[dict], final: dict, p_init: float, d: float) -> dict:
    segments = {}
    for name, choose in (("stationary", lambda t: t < .2),
                         ("motion", lambda t: .2 <= t <= 1.2),
                         ("hold", lambda t: t > 1.2)):
        rows = [r for r in controls if choose(r["time_s"])]
        segments[name] = {"n_control_samples": len(rows),
            "position_mae_m": float(np.mean([abs(r["measured_p_m"] - r["external_reference"]["p_ref_m"]) for r in rows])) if rows else None,
            "velocity_mae_m_s": float(np.mean([abs(r["measured_v_m_s"] - r["external_reference"]["v_ref_m_s"]) for r in rows])) if rows else None}
    hold = [r["measured_v_m_s"] for r in controls if r["time_s"] > 1.2]
    # Final state is separately saved at 2.2, not an extra control decision.
    return {"segments": segments, "final_displacement_m": final["qpos"][0] - p_init,
            "final_position_error_m": final["qpos"][0] - (p_init + d),
            "final_velocity_m_s": final["qvel"][0],
            "hold_velocity_rms_m_s": float(np.sqrt(np.mean(np.square(hold)))) if hold else None}


def run_episode(scenario, input_id: str, displacement_m: float, method: str,
                expected_initial_hash: str | None = None) -> dict:
    model = frozen.load_model(); data = mujoco.MjData(model); frozen._reset(model, data, scenario)
    mapping = channel_mapping(model); initial = state_values(data); initial_hash = frozen.sha(initial)
    if expected_initial_hash is not None and initial_hash != expected_initial_hash:
        raise ValueError("Frozen shared initial-state hash differs")
    p_init = float(data.qpos[0]); controller = TaskResponseWBC(model)
    backup_id = f"STEP20-{input_id}-{method}"
    manager = TaskManager(controller, model, method, p_init, displacement_m, backup_id)
    limits = extract_healthy_torque_limits(model); base_id = frozen._base_id(model)
    controls = []; checkpoints = []; physical_rows = []; solver_rows = []; policy_rows = []; latency = []
    numerical_failure = None; implementation_error = None; actual_steps = 0
    integration_s = 0.; evaluation_s = 0.; solver_cursor = 0

    def facts(h, tau, action, ms, step, tick):
        nonlocal evaluation_s
        start = perf_counter()
        row = frozen._facts(model, data, tau, data.actuator_force.copy(), h, limits, ms,
            t=step * .002, tick=tick, backup_id=backup_id, scenario_id=input_id,
            action=action, base_id=base_id)
        row["external_reference"] = reference(p_init, displacement_m, step * .002)
        # Retain the historical physical predicates; never report the old
        # mixed-unit utility as STEP20 task performance.
        row["physical_evaluation"].pop("utility", None)
        row["task_utility_used"] = False
        row["physics_step"] = step
        evaluation_s += perf_counter() - start
        return row

    try:
        for tick in range(CONTROL_TICKS):
            step = tick * 10
            h = health_at_tick(input_id, tick, model.nu)
            data.xfrc_applied[:] = 0.
            response = manager.compute(data, h, tick)
            wb = response.pop("wbc")
            ms = response["latency_ms"]
            valid = response["valid_command"]
            tau = np.asarray(response["tau_cmd"], dtype=float)
            # No new optimizer or retry for invalid command: historical zero
            # command fallback is retained and explicitly logged.
            data.ctrl[:] = tau
            start = perf_counter(); mujoco.mj_forward(model, data); integration_s += perf_counter() - start
            for entry in controller.solver_ledger[solver_cursor:]:
                solver_rows.append(dict(entry, input_id=input_id, method=method, tick=tick,
                                        time_s=step*.002, backup_id=backup_id))
            solver_cursor = len(controller.solver_ledger)
            row = {"input_id": input_id, "method": method, "tick": tick, "time_s": step*.002,
                   **response, "health_vector": h.tolist(), "fault_mask": [1],
                   "backup_id": backup_id, "tau_cmd": tau.tolist(),
                   "tau_applied": data.actuator_force.copy().tolist(),
                   "qdd": None if wb.get("qdd") is None else np.asarray(wb["qdd"]).tolist(),
                   "solver_status": wb.get("status"), "solver_success": valid,
                   "solver_calls": int(wb.get("solver_calls", 0)), "wbc_validation": wb.get("validation"),
                   "fallback_used": bool(wb.get("fallback_used", False)),
                   "returned_command_source": wb.get("returned_command_source", "stage1" if valid else "zero_command"),
                   "stage2_status": wb.get("stage2_status"),
                   "contact_force_qp": None if wb.get("contact_force") is None else np.asarray(wb["contact_force"]).tolist()}
            pre = facts(h, tau, response["a_command_mps2"], ms, step, tick)
            row["physical_at_decision"] = pre
            controls.append(row)
            latency.append({"input_id": input_id, "method": method, "tick": tick, "time_s": step*.002,
                            "latency_ms": ms, "deadline_ms": 20., "deadline_miss": ms > 20.})
            if response["policy"] is not None:
                policy_rows.append(dict(response["policy"], tick=tick, time_s=step*.002))
            # The first window state is recorded after applying health and
            # the t=.2 decision, before any propagation under that command.
            if step == 100:
                checkpoints.append(pre)
            for sub in range(10):
                start = perf_counter()
                mujoco.mj_step(model, data)
                actual_steps += 1
                finite = np.isfinite(data.qpos).all() and np.isfinite(data.qvel).all() and np.isfinite(data.actuator_force).all()
                if finite:
                    mujoco.mj_forward(model, data)  # refresh derived facts at this actual propagated state
                integration_s += perf_counter() - start
                if not finite:
                    numerical_failure = {"type": "NONFINITE_STATE", "physics_step": actual_steps,
                                         "state": json_safe(state_values(data))}
                    break
                fact = facts(h, tau, response["a_command_mps2"], ms, actual_steps, tick)
                physical_rows.append(fact)
                if actual_steps in CHECKPOINT_STEPS and actual_steps != 100:
                    checkpoints.append(fact)
            row["post_control_state"] = json_safe(state_values(data))
            if numerical_failure:
                break
    except Exception as exc:
        implementation_error = {"type": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()}
        # Any calls made before a Python exception remain counted.
        for entry in controller.solver_ledger[solver_cursor:]:
            solver_rows.append(dict(entry, input_id=input_id, method=method, tick=len(controls)))
    final = json_safe(state_values(data))
    complete = actual_steps == PHYSICS_STEPS and len(controls) == CONTROL_TICKS and not implementation_error and not numerical_failure
    grid_valid = len(checkpoints) == 21 and all(abs(r["time_s"] - s*.002) < 1e-9 for r, s in zip(checkpoints, CHECKPOINT_STEPS))
    eval_start = perf_counter()
    if grid_valid:
        case = dict(asdict(scenario), scenario_id=input_id, health=.5 if input_id == "S20_H050_POS" else 1.,
                    fault_onset_s=.2 if input_id == "S20_H050_POS" else None)
        try:
            evaluator = evaluate_serialized_trajectory(case=case, trajectory=checkpoints, start_index=0)
        except Exception as exc:
            implementation_error = {"type":type(exc).__name__,"message":str(exc),"traceback":traceback.format_exc()}
            complete = False
            evaluator = {"status":"EVALUATOR_ERROR","physical_status":"NOT_EVALUATED","error":str(exc)}
    else:
        evaluator = {"status": "INCOMPLETE", "physical_status": "NOT_EVALUATED_INCOMPLETE_WINDOW",
                     "checkpoint_count": len(checkpoints), "terminal_set_arrival": None}
    evaluation_s += perf_counter() - eval_start
    physical_failures = Counter(reason for r in physical_rows + [c["physical_at_decision"] for c in controls]
                                for reason in r["physical_evaluation"]["safety_reasons"])
    metric = task_metrics(controls, final, p_init, displacement_m) if not numerical_failure else None
    return json_safe({"schema": "STEP20_EPISODE_V1", "input_id": input_id, "method": method,
        "status": "COMPLETED" if complete else "FAILED", "initial_state": initial,
        "initial_state_hash": initial_hash, "mapping": mapping, "p_init_m": p_init,
        "displacement_reference_m": displacement_m, "backup_id": backup_id,
        "controls": controls, "checkpoints": checkpoints, "physics_trajectory": physical_rows,
        "solver_ledger": solver_rows, "policy_ledger": policy_rows, "latency_ledger": latency,
        "final_state": final, "physics_steps": actual_steps, "control_decisions": len(controls),
        "metrics": metric, "evaluator": evaluator, "checkpoint_grid_valid": grid_valid,
        "physical_failure": bool(physical_failures), "physical_failure_reason_counts": dict(physical_failures),
        "deadline_miss_ticks": sum(x["deadline_miss"] for x in latency),
        "solver_invalid_command_ticks": sum(not x["solver_success"] for x in controls),
        "timing": {"control_total_s": sum(x["latency_ms"] for x in latency)/1000,
                   "model_integration_forward_s": integration_s, "independent_evaluation_s": evaluation_s},
        "numerical_failure": numerical_failure, "implementation_error": implementation_error})
