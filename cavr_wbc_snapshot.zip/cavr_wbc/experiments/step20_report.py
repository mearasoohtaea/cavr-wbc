"""STEP20 saved-output reporting. No model loading, integration or solving."""
from __future__ import annotations
import argparse
from collections import Counter
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path


def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''): h.update(block)
    return h.hexdigest()


def write_csv(path,rows):
    fields=list(dict.fromkeys(k for r in rows for k in r))
    with path.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)


def report(out):
    root=Path(__file__).resolve().parents[2]
    manifest=json.loads((out/'PROTOCOL_AND_MANIFEST.json').read_text(encoding='utf-8'))
    summary=json.loads((out/'EXECUTION_SUMMARY.json').read_text(encoding='utf-8'))
    history=[json.loads(x) for x in (out/'ATTEMPT_LEDGER.jsonl').read_text(encoding='utf-8').splitlines() if x]
    identities=[i['input_id']+':'+m for i in manifest['inputs'] for m in manifest['methods']]
    if len(history)!=30 or any([r['status'] for r in history if r['identity']==i]!=['START','DONE'] for i in identities):
        raise ValueError('Expected exactly one START/DONE per fixed identity')
    if any(r['run_id']!=manifest['run_id'] or r['manifest_hash']!=manifest['manifest_hash'] for r in history):
        raise ValueError('Ledger identity mismatch')
    hash_checks={str(root/p):h for p,h in {**manifest['source_sha256'],**manifest['model_files_sha256']}.items()}
    hash_checks.update({manifest['protocol']:manifest['protocol_sha256'],manifest['source_manifest']:manifest['source_manifest_sha256']})
    if any(digest(Path(p))!=h for p,h in hash_checks.items()): raise ValueError('Frozen input/source hash changed')
    immutable=['PROTOCOL_AND_MANIFEST.json','ATTEMPT_LEDGER.jsonl','CASE_RESULTS.csv','TEST_RESULTS.json']
    immutable += [p for p in summary['artifact_sha256'] if p.endswith('STEP20_CASE_SHARD.json')]
    if any(digest(out/p)!=summary['artifact_sha256'][p] for p in immutable): raise ValueError('Saved raw evidence hash changed')
    metrics=list(csv.DictReader((out/'CASE_RESULTS.csv').open(encoding='utf-8',newline='')))
    chains=[];series=[];diagnostics=[];paired={};verify=[]
    trajectory_signatures={}
    all_solver=Counter();all_fallback=Counter();realtime={}
    for m in metrics:
        input_id,method=m['input_id'],m['method']
        path=out/'cases'/f'{input_id}__{method}'/'STEP20_CASE_SHARD.json'
        if not path.exists(): continue
        payload=json.loads(path.read_text(encoding='utf-8'));r=payload['result'];controls=r['controls']
        canonical=json.dumps(r,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
        if hashlib.sha256(canonical).hexdigest()!=payload['result_hash']: raise ValueError('changed shard')
        done=next(x for x in history if x['identity']==payload['identity'] and x['status']=='DONE')
        if done['result_hash']!=payload['result_hash'] or done['solver_calls']!=len(r['solver_ledger']): raise ValueError('DONE/shard mismatch')
        if abs(r['final_state']['time_s']-2.2)>1e-9 or len(r['physics_trajectory'])!=1100: raise ValueError('Final state/trajectory length')
        if len(r['checkpoints'])!=21 or len(r['evaluator']['checkpoints'])!=21: raise ValueError('Independent checkpoint count')
        trajectory_signatures[(input_id,method)]=hashlib.sha256(json.dumps([
            {k:x[k] for k in ('qdd','tau_cmd','tau_applied','post_control_state')} for x in controls
        ],sort_keys=True,separators=(',',':')).encode()).hexdigest()
        verify.append({'identity':payload['identity'],'controls':len(controls),'physics_steps':r['physics_steps'],
                       'checkpoint_times_s':[x['time_s'] for x in r['checkpoints']],
                       'initial_hash_matches':r['initial_state_hash']==manifest['initial']['state_hash'],
                       'result_hash_matches':True,'healthy_independent_evaluation_actual_points':len(r['evaluator']['checkpoints'])})
        if len(controls)!=110 or r['physics_steps']!=1100 or not verify[-1]['initial_hash_matches']:
            raise ValueError('STEP20 fixed design output mismatch')
        if any(abs(x['time_s']-(.2+j*.05))>1e-9 for j,x in enumerate(r['checkpoints'])): raise ValueError('checkpoint grid')
        by_status=Counter(str(x.get('status')) for x in r['solver_ledger']);all_solver.update(by_status)
        fallback=Counter(str(x['returned_command_source']) for x in controls);all_fallback.update(fallback)
        realtime.setdefault(method,[]).extend(x['latency_ms'] for x in r['latency_ledger'])
        qpres={k:max(abs(x['wbc_validation'].get(k,0)) for x in controls) for k in ('dynamics_residual_inf','contact_acceleration_residual_inf')}
        post_motion=[x for x in controls if .2<=x['time_s']<=1.2]
        diagnostics.append({'input_id':input_id,'method':method,'solver_status_counts':dict(by_status),
            'returned_command_counts':dict(fallback),'qp_residual_maxima':qpres,
            'max_joint_qdd_norm_motion':max(math.sqrt(sum(v*v for v in x['qdd'][6:])) for x in post_motion),
            'min_fr_thigh_command_margin_nm':min(x['physical_at_decision']['actuator_limits'][1]*x['health_vector'][1]-abs(x['tau_cmd'][1]) for x in controls),
            'p1_modes':dict(Counter(x['mode'] for x in r['policy_ledger'])),
            'p1_acceleration_limited_ticks':sum(x['a_raw_mps2']!=x['a_backup_mps2'] for x in r['policy_ledger']),
            'timing':r['timing']})
        for x in controls:
            qpt=x['qp_tasks'][0]
            row={'input_id':input_id,'method':method,'sample_kind':'CONTROL_PRE_STATE','tick':x['tick'],'time_s':x['time_s'],
                'p_ref_m':x['external_reference']['p_ref_m'],'v_ref_m_s':x['external_reference']['v_ref_m_s'],
                'a_ref_m_s2':x['external_reference']['a_ref_m_s2'],'p_m':x['measured_p_m'],'v_m_s':x['measured_v_m_s'],
                'a_nominal_mps2':x['a_nominal_mps2'],'a_command_mps2':x['a_command_mps2'],
                'qp_stage1_target_x_mps2':qpt['desired'][0],'qp_stage1_objective_q0':qpt['linear_objective_q'][0],
                'qp_stage2_target_x_mps2':x['qp_tasks'][1]['desired'][0] if len(x['qp_tasks'])>1 else None,
                'qdd_x_mps2':x['qdd'][0],'health_fr_thigh':x['health_vector'][1],
                'tau_fr_thigh_nm':x['tau_cmd'][1],'actual_tau_fr_thigh_nm':x['tau_applied'][1],
                'tau_cmd_nm_json':json.dumps(x['tau_cmd']),'tau_applied_nm_json':json.dumps(x['tau_applied']),
                'physical_failure':x['physical_at_decision']['physical_evaluation']['safety_failure'],
                'contact_present_count':sum(z['present'] for z in x['physical_at_decision']['contacts'].values()),
                'latency_ms':x['latency_ms'],'solver_status':x['solver_status'],'command_source':x['returned_command_source'],
                'backup_id':x['backup_id'],'policy_version':x['policy_version']}
            series.append(row)
            if x['tick'] in (10,25,35,60,109): chains.append(row)
        series.append({'input_id':input_id,'method':method,'sample_kind':'FINAL_STATE_NO_NEW_ACTION',
            'time_s':2.2,'p_ref_m':r['p_init_m']+r['displacement_reference_m'],'v_ref_m_s':0.,'a_ref_m_s2':0.,
            'p_m':r['final_state']['qpos'][0],'v_m_s':r['final_state']['qvel'][0]})
        if input_id in ('S20_HEALTHY_POS','S20_HEALTHY_NEG'):
            paired[(input_id,method)]={'final_x':r['final_state']['qpos'][0],
                'tau':[x['tau_cmd'] for x in controls], 'qdd':[x['qdd'][0] for x in controls],
                'target':[x['qp_tasks'][0]['desired'][0] for x in controls]}
    response=[]
    for method in manifest['methods']:
        a,b=paired[('S20_HEALTHY_POS',method)],paired[('S20_HEALTHY_NEG',method)]
        response.append({'method':method,'healthy_pos_minus_neg_final_x_m':a['final_x']-b['final_x'],
            'max_paired_qp_target_x_difference_mps2':max(abs(x-y) for x,y in zip(a['target'],b['target'])),
            'max_paired_qdd_x_difference_mps2':max(abs(x-y) for x,y in zip(a['qdd'],b['qdd'])),
            'max_paired_tau_difference_nm':max(abs(x-y) for aa,bb in zip(a['tau'],b['tau']) for x,y in zip(aa,bb))})
    write_csv(out/'TASK_TIMESERIES.csv',series);write_csv(out/'CONTROL_CHAIN_SAMPLES.csv',chains)
    write_csv(out/'DIRECTION_RESPONSE.csv',response)
    diag={'verification':verify,'cases':diagnostics,'solver_status_counts':dict(all_solver),
          'returned_command_counts':dict(all_fallback),'paired_direction_response':response,
          'p1_equals_p0_saved_trajectory_by_input':{i['input_id']:trajectory_signatures[(i['input_id'],'P0')]==trajectory_signatures[(i['input_id'],'P1_PD_BACKUP_V2')] for i in manifest['inputs']},
          'h050_equals_healthy_pos_saved_trajectory_by_method':{m:trajectory_signatures[('S20_H050_POS',m)]==trajectory_signatures[('S20_HEALTHY_POS',m)] for m in manifest['methods']},
          'reporting_script_sha256':digest(Path(__file__)),'new_solver_calls':0,'new_physics_steps':0}
    (out/'SAVED_RESPONSE_DIAGNOSTICS.json').write_text(json.dumps(diag,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    lines=['# STEP20 任务接线与短时响应开发实验','',
        '## Material Passport','',
        '- 来源：experiment-agent / ARS；模式：固定实验执行与已保存输出描述。',
        '- 实验日期：2026-10-01；交付复核日期：'+datetime.now(timezone.utc).date().isoformat()+' UTC。',
        '- 验证：本批运行完成；无独立重复、显著性或非劣检验。',
        '- 版本：STEP20_TASK_RESPONSE_V1；研究范围：15条开发 episode，非 H2 优势验证。','',
        '## 结论','',
        '**任务参考已接入真实 QP，并改变 qdd 与力矩；机器人对方向的差分响应可测，但不足以执行 ±10 mm 平移。** '
        '正向指令仅产生约 +0.135～+0.148 mm 最终位移，负向指令仍产生约 +0.130～+0.141 mm 正向位移。'
        '因此不能把物理边界/时延通过改述为任务成功。','',
        f"固定批次15/15完成，16500 physics steps、1650控制决策、{summary['solver_calls']}次真实求解；START与DONE各15、FAILED/UNKNOWN/缺失均0。"
        '所有episode的初态hash一致。全程逐物理步及逐控制tick保存物理事实；所有healthy/退化输入都实际评价0.2～1.2秒的21个状态，没有健康占位True。','',
        '## 设计与实现','',
        f"初态来自 `{manifest['selected_source_scenario']['scenario_id']}`，seed={manifest['selected_source_scenario']['seed']}；"
        '按冻结规则在读取本批结果前选择。额外外扰关闭；只在退化输入t=0.2秒决策前把FR_thigh的health改为0.5，其余11个actuator保持1。',
        '世界基座x通道是qpos[0]/qvel[0]/desired_base_accel[0]，不是全机器人CoM。'
        '模型dt=0.002秒、控制dt=0.02秒，每条1100步/110决策，t=2.2秒保存终态但不再发动作。'
        '初始位置只记录一次；参考为0.2～1.2秒的五次曲线、之后保持。Kp=1.25 s^-2，Kd=0.75 s^-1。',
        'B1/B2/B3/P0复用原方法；仅用STEP20子类记录真实QP组装，未修改旧控制器。'
        'B3原变换仍使目标/权重与共享输入不同；P0原关节投影和B2原第二阶段预算/fallback保持。',
        '`P1_PD_BACKUP_V2` 保留旧健康限幅PD身份并加入显式局部p/v参考和acceleration feedforward，只有一层PD。'
        'rho=health_vector[FR_thigh=1]；归一化cap乘1 m/s²换算为加速度后限幅，真实N·m力矩界仍由WBC执行。'
        '当前接触/摩擦/零能力分支保持原行为，backup ID在episode内稳定。本批没有预测可恢复性过滤器。','',
        '## 位移、停止与误差','',
        '| 输入 | 方法 | 末位移 mm | 末位置误差 mm | 末速度 mm/s | 保持段速度RMS mm/s |',
        '|---|---|---:|---:|---:|---:|']
    for r in metrics:
        lines.append(f"| {r['input_id']} | {r['method']} | {float(r['final_displacement_m'])*1000:.6f} | {float(r['final_position_error_m'])*1000:.6f} | {float(r['final_velocity_m_s'])*1000:.6f} | {float(r['hold_velocity_rms_m_s'])*1000:.6f} |")
    lines+=['','静止段[0,0.2)、运动段[0.2,1.2]、保持段(1.2,2.2)的position MAE[m]/velocity MAE[m/s]均在CASE_RESULTS.csv中单列，'
            '每个指标读取当tick保存的外部参考。末态2.2秒另存，不混作第111次决策；保持段RMS采用控制前采样1.22～2.18秒。'
            '没有沿用混合单位utility，也未补设任务成功阈值。','',
            '## 从目标到动作的证据','',
            '以下使用同初态正负输入的实际记录作描述性对照，不重新求解，不把时间点当独立样本。',
            '| 方法 | 最大QP目标方向差 m/s² | 最大qdd方向差 m/s² | 最大力矩方向差 N·m | 最终位置方向差 μm |',
            '|---|---:|---:|---:|---:|']
    for r in response:
        lines.append(f"| {r['method']} | {r['max_paired_qp_target_x_difference_mps2']:.6g} | {r['max_paired_qdd_x_difference_mps2']:.6g} | {r['max_paired_tau_difference_nm']:.6g} | {r['healthy_pos_minus_neg_final_x_m']*1e6:.6g} |")
    lines+=['','这些方向差证实任务不是只改变标签；但绝对负向运动未实现，且正向位置误差仍接近9.85～9.86 mm。'
        '初态包含固定的roll/pitch偏移，两个方向共享初始化后的自然瞬态；没有另跑零输入反事实，不能把全部微小绝对位移归因于参考。',
        '当前QP同时保留四足接触加速度等式、零关节加速度目标和原等权重任务，位置/速度任务只作用于一个base加速度分量。'
        '保存的QP目标、qdd、接触残差和力矩方向差共同支持：接线已成立，但在该固定接触与目标权衡下，实际运动传递极弱。'
        '不能仅凭“接触存在”断言唯一原因；应继续检查QP qdd与实际MuJoCo响应的一致性及任务/接触耦合，而非增加样本或扩幅。','',
        '## 物理边界与实时性','',
        '15/15全程物理检查无已记录失败，15/15独立21点窗口物理检查通过。力矩命令/实际力矩、接触、摩擦、关节、姿态、subtree_com高度与固定边界沿用冻结谓词，'
        '无放宽容差。QP动力学/接触残差保留原计算定义，仅另列报告，不把求解器success当物理证据。'
        '本窗口是采样物理描述，不是连续时间安全证书。',
        'QP动力学残差最大为3.526381e−7（广义力分量含N与N·m）；接触加速度残差最大为'
        'B1/B2/P0/P1的8.084784e−6 m/s²、B3的1.450750e−5 m/s²。独立物理谓词不包含该QP接触残差；'
        '因此上述物理PASS不等于全部QP数值约束获得额外认证。冻结配置中的residual_tolerance_nm=1e−5为力矩单位，'
        '不能拿来判定m/s²残差。原OSQP绝对/相对容差均为1e−7，本批未改动，也没有事后新增残差验收门。','',
        '| 方法 | 控制决策数 | 最大端到端耗时 ms | 超20 ms决策数 |',
        '|---|---:|---:|---:|']
    for method,times in realtime.items(): lines.append(f'| {method} | {len(times)} | {max(times):.6f} | {sum(t>20 for t in times)} |')
    lines+=['','计时包含任务管理器、前馈/PD/限幅、方法变换、QP、正常fallback及实际命令选择；'
        '模型积分/forward、独立评价和文件写出另列。时延结论只覆盖本机本批所执行模块，不包含尚未实现的预测器。',
        '求解调用状态计数：`'+json.dumps(dict(all_solver),ensure_ascii=False,sort_keys=True)+'`。',
        '返回命令来源计数：`'+json.dumps(dict(all_fallback),ensure_ascii=False,sort_keys=True)+'`。'
        'B2共330次第二阶段调用全部未成功（327次达到迭代上限、3次primal infeasible），330个控制tick均返回第一阶段命令，'
        '这解释了本批B2与B1的同轨迹；不能报告为B2两阶段均成功。普通失败按冻结fallback记录，不重试、不删除。','',
        '## 直接下一步判断与范围终点','',
        '**已具备可观测任务接线基础，但尚不具备把该plant/controller作为有效平移任务执行器来检验预测方法优势的基础。** '
        '下一项工作应针对已保存的qdd、接触约束、力矩和实际加速度链路定位响应衰减；本轮到此停止，不自行更改权重或接触约束。'
        '任务执行基础建立后，再实现nominal candidate → feedback-backup prediction → 1秒/21点约束与终端检查 → nominal或backup选择，新增预测成本计入20 ms。',
        '保存的qdd、命令/实际力矩、逐控制后完整状态逐值比较显示：各输入P1与P0同轨迹，各方法健康正向与0.5健康正向同轨迹。'
        'P1加速度限幅未激活；退化FR_thigh命令力矩仍有至少11.280055 N·m余量。这不是机制无效或方法等效证据。'
        '本批无独立随机重复，无显著性/非劣性检验，不支持普遍可恢复性或H2优越性主张。','',
        '## 可复核交付','',
        '- PROTOCOL_AND_MANIFEST.json：冻结设计、初态、模型/代码hash。',
        '- CASE_RESULTS.csv：15条完整状态，分段MAE、最终误差和时延。',
        '- TASK_TIMESERIES.csv：1650条控制前采样与15条终态，单位显式。',
        '- CONTROL_CHAIN_SAMPLES.csv / DIRECTION_RESPONSE.csv：参考→QP→qdd/力矩→实际响应证据。',
        '- cases/*/STEP20_CASE_SHARD.json：完整逐步轨迹、21点独立评价、solver/action/policy/latency账本。',
        '- TEST_RESULTS.json：5项测试，0真实solver/积分调用；已有环境无pytest，采用标准库unittest。',
        '- EXECUTION_SUMMARY.json / SAVED_RESPONSE_DIAGNOSTICS.json：尝试、调用、状态、hash与Git实际状态。',
        '- EXECUTION_RECORD.json / FINAL_VERIFICATION.json：实际执行命令、测试及本批只读复核。','',
        '旧STEP19 manifest/结果未覆盖或重分类；未重跑历史面板、未进入E3/RL/硬件。','',
        '```ini','STEP20_FIXED_BATCH = COMPLETED_15_OF_15','TASK_WIRING = CONNECTED_TO_QP_AND_ACTUATION',
        'TASK_RESPONSE = INSUFFICIENT_FOR_REQUESTED_DISPLACEMENT','PHYSICAL_OBSERVED = PASS_15_OF_15',
        'CONTROL_DEADLINE_OBSERVED = PASS_1650_OF_1650','PREDICTIVE_RECOVERABILITY_FILTER = NOT_IMPLEMENTED',
        'REAL_EPISODE_ATTEMPTS = 15','REAL_SOLVER_CALLS = 1980','NUMERICAL_RETRIES = 0','STEP19_FULL_PANEL_RERUN = FALSE',
        'FORMAL_H2_SUPERIORITY_CLAIM = NOT_AUTHORIZED','E3 = NOT_AUTHORIZED','RL_OR_HARDWARE = NOT_AUTHORIZED','```','']
    delivery_path=out/'GIT_DELIVERY.json'
    if delivery_path.exists():
        delivery=json.loads(delivery_path.read_text(encoding='utf-8'))
        summary['git_status']=delivery['status'];summary['git_delivery']=delivery
        lines+=['','## Git实际交付','',
            '交付状态：`'+delivery['status']+'`。核心代码和原始数据提交：`'+delivery['core_commit']+'`。',
            '分支：`'+delivery['branch']+'`；分支引用写入结果：'+delivery['ref_update_result']+'。',
            '采用E盘隔离索引，不修改原工作树缺失索引或旧HEAD；当前工作树仍指向原STEP17分支。'
            '后续交付元数据提交只追加本报告和汇总，不修改冻结源码、manifest、ledger、case shard或CASE_RESULTS。','']
    verification={'schema':'STEP20_FINAL_SAVED_EVIDENCE_VERIFICATION_V1',
        'checked_at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS',
        'scope':'Only STEP20 saved evidence and directly frozen inputs; no historical panel traversal',
        'command':'python -B -X utf8 -m cavr_wbc.experiments.step20_report --output '+str(out),
        'attempt_status_counts':dict(Counter(x['status'] for x in history)),
        'unique_case_identities':len(identities),'verified_raw_artifacts':len(immutable),
        'frozen_input_source_model_hashes_unchanged':len(hash_checks),
        'cases':verify,'solver_calls':sum(all_solver.values()),
        'physics_steps':sum(x['physics_steps'] for x in verify),
        'control_decisions':sum(x['controls'] for x in verify),
        'new_real_episode_attempts':0,'new_solver_calls':0,'new_physics_steps':0,
        'verification_pass_is_not_task_success':True}
    (out/'FINAL_VERIFICATION.json').write_text(json.dumps(verification,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    (out/'TASK_RESPONSE_REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
    summary.update(reporting_source_sha256={str(Path(__file__)):digest(Path(__file__))},
        task_wiring='CONNECTED_TO_QP_AND_ACTUATION',task_response='INSUFFICIENT_FOR_REQUESTED_DISPLACEMENT',
        physical_observed_cases_pass=15,control_deadline_miss_ticks=0,
        development_conclusion='Task wiring established; motion response insufficient; do not expand panel.',
        solver_status_counts=dict(all_solver),returned_command_counts=dict(all_fallback))
    summary['artifact_sha256']={str(p.relative_to(out)):digest(p) for p in out.rglob('*') if p.is_file() and p.name!='EXECUTION_SUMMARY.json'}
    (out/'EXECUTION_SUMMARY.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps({'verification':verification['status'],'solver_statuses':dict(all_solver),'command_sources':dict(all_fallback),
        'p1_equals_p0':diag['p1_equals_p0_saved_trajectory_by_input'],'healthy_equals_degraded':diag['h050_equals_healthy_pos_saved_trajectory_by_method']},indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);report(p.parse_args().output)
