"""STEP20 fixed 15-episode development batch and evidence-only summary."""
from __future__ import annotations

import argparse
from collections import Counter
import csv
from dataclasses import asdict
from datetime import datetime, timezone
import gc
import hashlib
import io
import json
import os
from pathlib import Path
import sys
import time
import traceback

from cavr_wbc.control.step20_task_reference import METHODS, specification
from cavr_wbc.control.e2b_dynamic import DynamicWBCConfig
from cavr_wbc.evaluation.step16_independent_evaluator import EVALUATOR_CONFIG
from cavr_wbc.experiments import step17_formal_panel as base
from cavr_wbc.experiments import step20_episode as episode

ROOT = Path(__file__).resolve().parents[2]
SOURCE_MANIFEST = ROOT / "artifacts/step19_environment_recovery_20260930/panel/STEP19_PROTOCOL_AND_MANIFEST.json"
PROTOCOL = Path("E:/CAVR-WBC/experiment_handoff_20260921/NEXT_CODEX_INSTRUCTIONS_STEP20_TASK_RESPONSE_AND_METHOD_ALIGNMENT_20261001.md")
INPUTS = (("S20_HEALTHY_POS", .01), ("S20_HEALTHY_NEG", -.01), ("S20_H050_POS", .01))
SOURCE_FILES = ["cavr_wbc/control/step20_task_reference.py", "cavr_wbc/experiments/step20_episode.py",
    "cavr_wbc/experiments/step20_task_response.py", "tests/test_step20_task_response.py",
    "cavr_wbc/experiments/step17_formal_panel.py", "cavr_wbc/experiments/step04_e2b.py",
    "cavr_wbc/control/e2b_dynamic.py", "cavr_wbc/control/feedback_backup.py",
    "cavr_wbc/control/step16_feedback_adapter.py", "cavr_wbc/evaluation/e2b_physical.py",
    "cavr_wbc/evaluation/step16_independent_evaluator.py", "cavr_wbc/platforms/go2_mujoco.py"]


def utc():
    return datetime.now(timezone.utc).isoformat()


def file_hash(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024*1024), b""):
            h.update(block)
    return h.hexdigest()


def write_json(path, obj):
    base._atomic_write_text(Path(path), json.dumps(obj, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n")


def append(path, obj):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="") as f:
        f.write(json.dumps(obj, sort_keys=True, allow_nan=False) + "\n"); f.flush(); os.fsync(f.fileno())


def select_scenario():
    old = json.loads(SOURCE_MANIFEST.read_text(encoding="utf-8"))
    scenarios = base.build_scenarios()
    if base.sha([asdict(s) for s in scenarios]) != old["scenario_hash"]:
        raise ValueError("Frozen scenario generator does not match STEP19 manifest")
    chosen = sorted((s for s in scenarios if s.speed == "low" and s.health == .5 and s.fault_onset_s is not None), key=lambda s:s.scenario_id)[0]
    return chosen, old


def freeze(out, run_id):
    chosen, old = select_scenario()
    initial = episode.initial_state_facts(chosen)
    model_paths = [base.MODEL_REL, base.MODEL_REL.with_name("go2.xml")]
    if file_hash(ROOT / base.MODEL_REL) != old["model_sha256"]:
        raise ValueError("Frozen model identity differs")
    source = {p:file_hash(ROOT/p) for p in SOURCE_FILES}
    manifest = {"schema":"STEP20_PROTOCOL_V1", "run_id":run_id, "frozen_at_utc":utc(),
        "protocol":str(PROTOCOL), "protocol_sha256":file_hash(PROTOCOL),
        "source_manifest":str(SOURCE_MANIFEST), "source_manifest_sha256":file_hash(SOURCE_MANIFEST),
        "source_scenario_hash":old["scenario_hash"], "selected_source_scenario":asdict(chosen),
        "selection_rule":"lexicographic first low-speed health=0.5 fault scenario, before STEP20 outcomes",
        "initial":initial, "inputs":[{"input_id":i,"d_m":d,"fault_onset_s":.2 if i == "S20_H050_POS" else None,
            "health_after_onset":.5 if i == "S20_H050_POS" else 1., "mask":[1]} for i,d in INPUTS],
        "methods":list(METHODS), "max_real_episode_attempts":15, "numerical_retries":0,
        "episode_duration_s":2.2, "physics_steps":1100, "control_decisions":110,
        "physics_dt_s":.002,"control_dt_s":.02,"deadline_ms":20.,
        "checkpoint_times_s":[s*.002 for s in episode.CHECKPOINT_STEPS],
        "external_disturbance_force_n":[0.,0.,0.], "task_reference":specification(),
        "wbc_config":asdict(DynamicWBCConfig()), "independent_evaluator_config":EVALUATOR_CONFIG,
        "physical_threshold_source":"unchanged step17_formal_panel._facts and step16_independent_evaluator",
        "physical_task_limits":{"roll_limit_rad":.55,"pitch_limit_rad":.55,"com_height_min_m":.16,"com_height_max_m":.60,"velocity_limit_m_s":2.},
        "physical_terminal_limits":{"velocity_max_m_s":.25,"angle_max_rad":.20,"friction_margin_min_n":0.},
        "source_sha256":source,"model_files_sha256":{str(p):file_hash(ROOT/p) for p in model_paths},
        "python":sys.executable,"python_version":sys.version,
        "native_osqp_dll":os.environ.get("CAVR_WBC_NATIVE_OSQP_DLL"),
        "temporary_directory":os.environ.get("TEMP"), "git_status":"SOURCE_HASH_DELIVERY_PENDING_GIT_REF_CHECK",
        "no_predictive_filter_claim":True,"no_H2_superiority_claim":True,"E3_authorized":False}
    manifest["manifest_hash"] = base.sha(manifest)
    write_json(out/"PROTOCOL_AND_MANIFEST.json", manifest)
    return chosen, manifest


def execute_case(out, manifest, scenario, input_id, d, method, episode_fn=episode.run_episode):
    identity = input_id + ":" + method
    ledger = out/"ATTEMPT_LEDGER.jsonl"
    history = [json.loads(x) for x in ledger.read_text(encoding="utf-8").splitlines() if x] if ledger.exists() else []
    starts = [r for r in history if r["status"] == "START"]
    if len(starts) >= 15 or any(r["identity"] == identity for r in history):
        raise RuntimeError("Attempt already reserved or 15-attempt bound reached; refusing numerical retry")
    shard = out/"cases"/(input_id+"__"+method)/"STEP20_CASE_SHARD.json"
    if shard.exists():
        raise RuntimeError("Refusing completed/orphan shard overwrite")
    start = {"identity":identity,"status":"START","timestamp_utc":utc(),"pid":os.getpid(),
             "run_id":manifest["run_id"],"manifest_hash":manifest["manifest_hash"]}
    append(ledger, start); print(json.dumps(start),flush=True)
    try:
        result = episode_fn(scenario,input_id,d,method,manifest["initial"]["state_hash"])
    except Exception as exc:
        result = {"status":"FAILED","implementation_error":{"type":type(exc).__name__,"message":str(exc),"traceback":traceback.format_exc()},
                  "input_id":input_id,"method":method,"solver_ledger":[],"unknown_solver_count":True}
    payload = {"schema":"STEP20_CASE_SHARD_V1","run_id":manifest["run_id"],
               "manifest_hash":manifest["manifest_hash"],"identity":identity,"result":result,"result_hash":base.sha(result)}
    write_start = time.perf_counter()
    # A write retry reuses this exact memory result; never re-executes physics.
    for write_attempt in range(2):
        try:
            write_json(shard,payload)
            check = json.loads(shard.read_text(encoding="utf-8"))
            if base.sha(check["result"]) != payload["result_hash"]:
                raise RuntimeError("Shard readback mismatch")
            break
        except OSError:
            if write_attempt:
                append(ledger,{**start,"status":"UNKNOWN","timestamp_utc":utc(),"reason":"Persistence failure; no trajectory rerun"})
                raise
    done = {**start,"status":"DONE" if result["status"] == "COMPLETED" else "FAILED",
            "timestamp_utc":utc(),"shard":str(shard.relative_to(out)),"result_hash":payload["result_hash"],
            "solver_calls":len(result.get("solver_ledger",[])),"file_write_readback_s":time.perf_counter()-write_start}
    append(ledger,done); print(json.dumps(done),flush=True)
    return result


def summarize(out):
    manifest = json.loads((out/"PROTOCOL_AND_MANIFEST.json").read_text(encoding="utf-8"))
    history = [json.loads(x) for x in (out/"ATTEMPT_LEDGER.jsonl").read_text(encoding="utf-8").splitlines() if x]
    rows=[]; state_hashes=set(); solver_total=0; counts=Counter(); source_changed={}
    for p,h in manifest["source_sha256"].items():
        if file_hash(ROOT/p) != h: source_changed[p] = file_hash(ROOT/p)
    for i,d in INPUTS:
        for method in METHODS:
            matching=[r for r in history if r["identity"] == i+":"+method]
            last=matching[-1] if matching else {"status":"NOT_STARTED"}
            row={"input_id":i,"method":method,"attempt_state":last["status"],"d_ref_m":d}
            if "shard" in last:
                payload=json.loads((out/last["shard"]).read_text(encoding="utf-8")); r=payload["result"]
                if base.sha(r) != payload["result_hash"]: raise ValueError("Result hash changed")
                metrics=r.get("metrics") or {}
                state_hashes.add(r.get("initial_state_hash")); solver_total+=len(r.get("solver_ledger",[]))
                controls=r.get("controls",[])
                row.update(status=r["status"],**{k:v for k,v in metrics.items() if k != "segments"},
                    physics_steps=r.get("physics_steps"),control_decisions=r.get("control_decisions"),
                    physical_failure=r.get("physical_failure"),physical_window_status=r.get("evaluator",{}).get("physical_status"),
                    deadline_miss_ticks=r.get("deadline_miss_ticks"), solver_calls=len(r.get("solver_ledger",[])),
                    invalid_command_ticks=r.get("solver_invalid_command_ticks"),checkpoint_count=len(r.get("checkpoints",[])),
                    latency_max_ms=max((x["latency_ms"] for x in r.get("latency_ledger",[])),default=None),
                    a_nominal_max_abs_mps2=max((abs(x["a_nominal_mps2"]) for x in controls),default=None),
                    qp_target_max_abs_mps2=max((abs(x["qp_tasks"][0]["desired"][0]) for x in controls),default=None),
                    qdd_x_max_abs_mps2=max((abs(x["qdd"][0]) for x in controls if x.get("qdd") is not None),default=None),
                    physical_reasons=json.dumps(r.get("physical_failure_reason_counts",{}),sort_keys=True))
                for phase,metrics_phase in metrics.get("segments",{}).items():
                    for k,v in metrics_phase.items(): row[phase+"_"+k]=v
                counts[r["status"]]+=1
            else: counts[last["status"]]+=1
            rows.append(row)
    fields=list(dict.fromkeys(k for row in rows for k in row)); f=io.StringIO(newline="")
    writer=csv.DictWriter(f,fieldnames=fields); writer.writeheader();writer.writerows(rows)
    base._atomic_write_text(out/"CASE_RESULTS.csv",f.getvalue())
    attempts=sum(x["status"]=="START" for x in history)
    summary={"schema":"STEP20_EXECUTION_SUMMARY_V1","run_id":manifest["run_id"],"checked_at_utc":utc(),
        "real_episode_attempts":attempts,"max_real_episode_attempts":15,"solver_calls":solver_total,
        "states":dict(counts),"fixed_batch_completed":counts["COMPLETED"]==15,
        "missing_or_unknown":sum(x["attempt_state"] in ("START","UNKNOWN","NOT_STARTED") for x in rows),
        "shared_initial_state_hashes":sorted(x for x in state_hashes if x),
        "source_sha256":manifest["source_sha256"],"source_changed_since_freeze":source_changed,
        "pure_tests_solver_calls":0,"numerical_retries":0,"E3_authorized":False,
        "git_status":"SOURCE_HASH_DELIVERY_PENDING_GIT_REF_CHECK"}
    summary["artifact_sha256"]={str(p.relative_to(out)):file_hash(p) for p in out.rglob("*") if p.is_file() and p.name != "EXECUTION_SUMMARY.json" and ".tmp-" not in p.name}
    write_json(out/"EXECUTION_SUMMARY.json",summary)
    return summary


def run(out, run_id):
    out=out.resolve()
    allowed=(ROOT/"artifacts/step20_task_response_20261001").resolve()
    if out.parent != allowed: raise ValueError("Output must be one unique STEP20 run directory")
    out.mkdir(parents=True,exist_ok=True)
    if (out/"ATTEMPT_LEDGER.jsonl").exists() or (out/"PROTOCOL_AND_MANIFEST.json").exists():
        raise RuntimeError("Existing run; use --summarize for read-only result aggregation, never implicit rerun")
    scenario,manifest=freeze(out,run_id)
    for input_id,d in INPUTS:
        for method in METHODS:
            result=execute_case(out,manifest,scenario,input_id,d,method)
            if result.get("implementation_error"):
                # No silent replay. Partial evidence retained; fix infrastructure
                # before explicitly dispatching only as-yet unstarted cases.
                return summarize(out)
            del result; gc.collect()
    return summarize(out)


def main():
    p=argparse.ArgumentParser();p.add_argument("--output",type=Path,required=True);p.add_argument("--run-id")
    p.add_argument("--summarize",action="store_true");a=p.parse_args()
    result=summarize(a.output) if a.summarize else run(a.output,a.run_id or a.output.name)
    print(json.dumps(result,sort_keys=True),flush=True)
    return 0 if result["fixed_batch_completed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
