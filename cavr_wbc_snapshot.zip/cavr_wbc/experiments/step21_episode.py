"""One bounded STEP21 episode. Diagnostics run only after command selection."""
from collections import Counter
from dataclasses import asdict
from time import perf_counter
import traceback

import mujoco
import numpy as np

from cavr_wbc.control.step20_task_reference import reference, nominal_acceleration
from cavr_wbc.control.step21_contact_reference import Step21WBC
from cavr_wbc.experiments import step17_formal_panel as frozen
from cavr_wbc.experiments.step20_episode import (
    PHYSICS_STEPS, CONTROL_TICKS, CHECKPOINT_STEPS, channel_mapping,
    state_values, json_safe, task_metrics,
)
from cavr_wbc.evaluation.step16_independent_evaluator import evaluate_serialized_trajectory
from cavr_wbc.platforms.go2_mujoco import extract_healthy_torque_limits


def health_at_tick(input_id, tick, nu=12):
    h = np.ones(nu)
    if input_id == "S21_H050_POS" and tick >= 10:
        h[1] = .5
    return h


def constraint_diagnostics(model, data):
    """Actual efc row forces mapped with the actual dense/sparse J transpose."""
    types = np.asarray(data.efc_type, dtype=int).copy()
    forces = np.asarray(data.efc_force, dtype=float).copy()
    groups = {}; products = 0; total = np.zeros(model.nv)
    for kind in sorted(set(types.tolist())):
        indices = np.flatnonzero(types == kind)
        vector = np.zeros(data.nefc)
        vector[indices] = forces[indices]
        contribution = np.zeros(model.nv)
        mujoco.mj_mulJacTVec(model, data, contribution, vector)
        products += 1; total += contribution
        name = mujoco.mjtConstraint(kind).name
        groups[name] = {"type": kind, "rows": indices.tolist(),
            "row_ids": np.asarray(data.efc_id)[indices].astype(int).tolist(),
            "constraint_coordinate_forces": forces[indices].tolist(),
            "generalized_force_J_transpose_f": contribution.tolist()}
    return {"schema": "STEP21_ACTION_CONDITIONED_CONSTRAINT_GROUPS_V1",
        "time_s": float(data.time), "nefc": int(data.nefc),
        "jacobian_storage": "SPARSE" if mujoco.mj_isSparse(model) else "DENSE",
        "grouping": "actual mjtConstraint type; each contribution = mj_mulJacTVec(efc force masked by type)",
        "groups": groups, "summed_generalized_force": total.tolist(),
        "sum_minus_qfrc_constraint_inf": float(np.max(np.abs(total-data.qfrc_constraint))),
        "jacobian_transpose_products": products}


def run_episode(scenario, input_id, displacement_m, configuration, expected_initial_hash):
    model = frozen.load_model(); data = mujoco.MjData(model)
    frozen._reset(model, data, scenario)
    initial = state_values(data)
    if frozen.sha(initial) != expected_initial_hash:
        raise ValueError("STEP21 reset differs from STEP20 frozen initial state")
    channel_mapping(model)
    if np.any(data.qfrc_applied) or np.any(data.xfrc_applied):
        raise ValueError("STEP21 external generalized force/body wrench must be zero")
    controller = Step21WBC(model, configuration)
    p_init = float(data.qpos[0]); backup_id = f"STEP21-{configuration}-{input_id}"
    limits = extract_healthy_torque_limits(model); base_id = frozen._base_id(model)
    controls = []; checkpoints = []; physics = []; solver = []; latency = []
    steps = 0; solver_cursor = 0; nonfinite = None; implementation_error = None
    integration_s = 0.; evaluation_s = 0.; diagnostic_s = 0.; action_forward_s = 0.
    products = 0; diagnostic_calls = 0; action_forward_calls = 0; integration_forward_calls = 0

    def facts(h, tau, a, ms, step, tick):
        nonlocal evaluation_s
        begin = perf_counter()
        row = frozen._facts(model, data, tau, data.actuator_force.copy(), h, limits, ms,
            t=step*.002, tick=tick, backup_id=backup_id, scenario_id=input_id,
            action=a, base_id=base_id)
        row["physical_evaluation"].pop("utility", None)
        row.update(external_reference=reference(p_init, displacement_m, step*.002), physics_step=step)
        evaluation_s += perf_counter()-begin
        return row

    try:
        for tick in range(CONTROL_TICKS):
            step = tick*10; t = step*.002
            h = health_at_tick(input_id, tick, model.nu)
            data.qfrc_applied[:] = 0.; data.xfrc_applied[:] = 0.
            begin = perf_counter()
            ref = reference(p_init, displacement_m, t)
            p, v = float(data.qpos[0]), float(data.qvel[0])
            a = nominal_acceleration(ref, p, v)
            base_ref = [a, 0., 0., 0., 0., 0.]
            target = {"desired_base_accel": base_ref, "desired_joint_accel": [0.]*model.nu,
                "task_weights": [1.]*(6+model.nu), "com_velocity": ref["v_ref_m_s"],
                "com_height": .27, "p_max": 1., "target_position": ref["p_ref_m"]}
            wb = controller.compute(data, "B1", h, target)
            valid = bool(wb.get("success")) and wb.get("tau") is not None and np.isfinite(wb["tau"]).all()
            tau = np.asarray(wb["tau"], dtype=float).copy() if valid else np.zeros(model.nu)
            ms = (perf_counter()-begin)*1000
            # The only applied torque is this bounded QP total (or legacy zero fallback).
            trace = controller.last_trace
            qvel_before = data.qvel.copy()
            data.ctrl[:] = tau
            begin = perf_counter(); mujoco.mj_forward(model, data)
            action_forward_s += perf_counter()-begin; action_forward_calls += 1
            begin = perf_counter(); diagnostic = constraint_diagnostics(model, data)
            diagnostic_s += perf_counter()-begin; diagnostic_calls += 1
            products += diagnostic["jacobian_transpose_products"]
            post = {"time_s": float(data.time), "qpos": data.qpos.copy().tolist(),
                "qvel": data.qvel.copy().tolist(), "qacc_after_command_forward": data.qacc.copy().tolist(),
                "qfrc_bias": data.qfrc_bias.copy().tolist(), "qfrc_passive": data.qfrc_passive.copy().tolist(),
                "qfrc_actuator": data.qfrc_actuator.copy().tolist(),
                "qfrc_constraint": data.qfrc_constraint.copy().tolist(),
                "qfrc_applied": data.qfrc_applied.copy().tolist(), "xfrc_applied": data.xfrc_applied.copy().tolist(),
                "constraint_diagnostics": diagnostic}
            for entry in controller.solver_ledger[solver_cursor:]:
                solver.append(dict(entry, configuration=configuration, input_id=input_id, tick=tick, time_s=t))
            solver_cursor = len(controller.solver_ledger)
            pre = facts(h, tau, a, ms, step, tick)
            row = {"configuration": configuration, "input_id": input_id, "method": "B1",
                "tick": tick, "time_s": t, "external_reference": ref,
                "measured_p_m": p, "measured_v_m_s": v, "a_base_ref": base_ref,
                "assembly": trace, "qdd": None if wb.get("qdd") is None else np.asarray(wb["qdd"]).tolist(),
                "contact_lambda_qp": None if wb.get("contact_force") is None else np.asarray(wb["contact_force"]).tolist(),
                "tau_total": tau.tolist(), "tau_cmd": tau.tolist(), "tau_applied": data.actuator_force.copy().tolist(),
                "health_vector": h.tolist(), "fault_mask": [1], "latency_ms": ms,
                "solver_status": wb.get("status"), "solver_success": valid,
                "solver_status_val": wb.get("status_val"), "wbc_validation": wb.get("validation"),
                "dynamics_model_version": trace["model_version"], "post_command_forward": post,
                "physical_at_decision": pre, "command_source": "B1_QP_TOTAL" if valid else "ZERO_COMMAND_FALLBACK"}
            controls.append(row)
            latency.append({"tick": tick, "time_s": t, "latency_ms": ms,
                "deadline_ms": 20., "deadline_miss": ms>20.})
            if step == 100:
                checkpoints.append(pre)
            for sub in range(10):
                begin = perf_counter(); mujoco.mj_step(model, data); steps += 1
                finite = np.isfinite(data.qpos).all() and np.isfinite(data.qvel).all() and np.isfinite(data.actuator_force).all()
                if finite:
                    mujoco.mj_forward(model, data); integration_forward_calls += 1
                integration_s += perf_counter()-begin
                if not finite or abs(float(data.time)-steps*.002)>1e-9:
                    nonfinite = {"type": "NONFINITE_OR_SIMULATOR_RESET", "physics_step": steps,
                        "state": json_safe(state_values(data))}
                    break
                if sub == 0:
                    row["first_physics_interval"] = {"start_s": t, "end_s": steps*.002,
                        "qvel_after": data.qvel.copy().tolist(),
                        "average_acceleration_from_qvel_difference": ((data.qvel-qvel_before)/.002).tolist()}
                fact = facts(h, tau, a, ms, steps, tick); physics.append(fact)
                if steps in CHECKPOINT_STEPS and steps != 100:
                    checkpoints.append(fact)
            row["post_control_state"] = json_safe(state_values(data))
            if not nonfinite:
                row["control_interval_average_acceleration"] = {"start_s": t, "end_s": steps*.002,
                    "average_acceleration_from_qvel_difference": ((data.qvel-qvel_before)/.02).tolist()}
            if nonfinite:
                break
    except Exception as exc:
        implementation_error = {"type": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()}
        for entry in controller.solver_ledger[solver_cursor:]:
            solver.append(dict(entry, configuration=configuration, input_id=input_id, tick=len(controls)))
    final = json_safe(state_values(data))
    grid = len(checkpoints)==21 and all(abs(r["time_s"]-s*.002)<1e-9 for r,s in zip(checkpoints,CHECKPOINT_STEPS))
    begin = perf_counter()
    evaluator = {"physical_status": "NOT_EVALUATED_INCOMPLETE_WINDOW"}
    if grid:
        case = dict(asdict(scenario), scenario_id=input_id,
            health=.5 if input_id=="S21_H050_POS" else 1.,
            fault_onset_s=.2 if input_id=="S21_H050_POS" else None)
        try:
            evaluator = evaluate_serialized_trajectory(case=case, trajectory=checkpoints, start_index=0)
        except Exception as exc:
            implementation_error = {"type": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()}
    evaluation_s += perf_counter()-begin
    failures = Counter(reason for r in physics+[x["physical_at_decision"] for x in controls]
        for reason in r["physical_evaluation"]["safety_reasons"])
    complete = steps==1100 and len(controls)==110 and not nonfinite and not implementation_error
    return json_safe({"schema": "STEP21_EPISODE_V1", "input_id": input_id, "configuration": configuration,
        "status": "COMPLETED" if complete else "FAILED", "initial_state": initial,
        "initial_state_hash": frozen.sha(initial), "p_init_m": p_init, "d_ref_m": displacement_m,
        "controls": controls, "physics_trajectory": physics, "checkpoints": checkpoints,
        "solver_ledger": solver, "latency_ledger": latency, "evaluator": evaluator,
        "final_state": final, "metrics": task_metrics(controls, final, p_init, displacement_m) if not nonfinite else None,
        "physical_failure": bool(failures), "physical_failure_reason_counts": dict(failures),
        "deadline_miss_ticks": sum(x["deadline_miss"] for x in latency),
        "invalid_command_ticks": sum(not x["solver_success"] for x in controls),
        "checkpoint_grid_valid": grid, "numerical_failure": nonfinite, "implementation_error": implementation_error,
        "counts": {"physics_steps": steps, "control_decisions": len(controls), "control_qp_calls": len(solver),
            "svd_calls": controller.svd_calls, "loss_model_calls": controller.loss_model_calls,
            "contact_linearization_calls": controller.contact_linearization_calls,
            "initialization_forward_calls": 1, "action_conditioned_forward_calls": action_forward_calls,
            "integration_refresh_forward_calls": integration_forward_calls,
            "constraint_diagnostic_calls": diagnostic_calls, "constraint_J_transpose_products": products},
        "timing": {"control_total_s": sum(x["latency_ms"] for x in latency)/1000,
            "action_conditioned_forward_s": action_forward_s, "constraint_diagnostics_s": diagnostic_s,
            "integration_and_refresh_s": integration_s, "physical_and_independent_evaluation_s": evaluation_s}})
