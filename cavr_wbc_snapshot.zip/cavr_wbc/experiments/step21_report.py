"""Describe only saved STEP21 evidence; never load a model or execute a solver."""
from collections import Counter
from datetime import datetime, timezone
import csv
import hashlib
import json
import math
from pathlib import Path


def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''): h.update(block)
    return h.hexdigest()


def canonical_hash(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def rms(values):
    return math.sqrt(sum(v*v for v in values)/len(values)) if values else None


def csv_write(path,rows):
    fields=list(dict.fromkeys(k for row in rows for k in row))
    with path.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields,lineterminator='\n');w.writeheader();w.writerows(rows)


def report(out):
    root=Path(__file__).resolve().parents[2]
    manifest=json.loads((out/'PROTOCOL_AND_MANIFEST.json').read_text(encoding='utf-8'))
    history=[json.loads(x) for x in (out/'ATTEMPT_LEDGER.jsonl').read_text(encoding='utf-8').splitlines() if x]
    rows=[];series=[];total=Counter();solver_status=Counter();states=Counter();verified=[];minimums={}
    for config in manifest['configuration_order']:
        for inp in manifest['input_order']:
            input_id=inp['input_id'];identity=config+':'+input_id
            matches=[x for x in history if x['identity']==identity]
            last=matches[-1] if matches else {'status':'NOT_STARTED'}
            row={'configuration':config,'input_id':input_id,'attempt_state':last['status'],'d_ref_m':inp['d_m']}
            if 'shard' not in last:
                states[last['status']]+=1;rows.append(row);continue
            shard=out/last['shard'];payload=json.loads(shard.read_text(encoding='utf-8'));r=payload['result']
            if canonical_hash(r)!=payload['result_hash'] or payload['result_hash']!=last['result_hash']:
                raise ValueError('Saved shard/DONE hash mismatch')
            if payload['manifest_hash']!=manifest['manifest_hash']: raise ValueError('Wrong manifest identity')
            counts=r.get('counts',{});total.update(counts);states[r['status']]+=1
            controls=r.get('controls',[]);metric=r.get('metrics') or {}
            row.update(status=r['status'],**{k:v for k,v in metric.items() if k!='segments'},
                physical_failure=r.get('physical_failure'),physical_window_status=r.get('evaluator',{}).get('physical_status'),
                physical_reasons=json.dumps(r.get('physical_failure_reason_counts',{})),
                deadline_miss_ticks=r.get('deadline_miss_ticks'),invalid_command_ticks=r.get('invalid_command_ticks'),
                latency_max_ms=max((x['latency_ms'] for x in controls),default=None),**counts)
            for phase,metrics in metric.get('segments',{}).items():
                for k,v in metrics.items(): row[phase+'_'+k]=v
            closure=[];rank=[];condition=[];ref=[];qdd=[];actual_error=[];joint_error=[];loss_error=[]
            finite_difference_error=[];effective=[];legacy=[];contact_residual=[];group_residual=[];branches=Counter()
            command_margin=[];actual_margin=[]
            for x in controls:
                a=x['assembly'];post=x['post_command_forward'];contact_ref=a['contact_reference']
                if contact_ref:
                    closure.append(contact_ref['closure_residual_inf']);rank.append(contact_ref['rank'])
                    if contact_ref['condition_estimate'] is not None: condition.append(contact_ref['condition_estimate'])
                else:
                    residual=[sum(j*v for j,v in zip(jr[:6],a['a_base_ref']))+jv for jr,jv in zip(a['Jc'],a['jdotv'])]
                    closure.append(max(map(abs,residual),default=0.))
                w=x.get('wbc_validation') or {}
                if 'dynamics_residual_inf' in w: effective.append(w['dynamics_residual_inf'])
                if 'legacy_dynamics_residual_inf' in w: legacy.append(w['legacy_dynamics_residual_inf'])
                if 'contact_acceleration_residual_inf' in w: contact_residual.append(w['contact_acceleration_residual_inf'])
                group_residual.append(post['constraint_diagnostics']['sum_minus_qfrc_constraint_inf'])
                h=x['health_vector'];lim=x['physical_at_decision']['actuator_limits']
                command_margin.append(h[1]*lim[1]-abs(x['tau_cmd'][1]))
                actual_margin.append(h[1]*lim[1]-abs(x['tau_applied'][1]))
                if a['loss_prediction']: branches.update(a['loss_prediction']['branch_actuator_order'])
                if .2<=x['time_s']<=1.2 and x['qdd'] is not None:
                    ref.append(a['a_base_ref'][0]);qdd.append(x['qdd'][0])
                    actual_error.append(x['qdd'][0]-post['qacc_after_command_forward'][0])
                    joint_error.extend(x['qdd'][i]-post['qacc_after_command_forward'][i] for i in a['mapped_joint_dofs'])
                    if 'first_physics_interval' in x:
                        finite_difference_error.append(x['qdd'][0]-x['first_physics_interval']['average_acceleration_from_qvel_difference'][0])
                    actual_friction=post['constraint_diagnostics']['groups'].get('mjCNSTR_FRICTION_DOF',{}).get('generalized_force_J_transpose_f',[0.]*len(a['g_loss_pred']))
                    loss_error.extend(a['g_loss_pred'][i]-actual_friction[i] for i in a['mapped_joint_dofs'])
                series.append({'configuration':config,'input_id':input_id,'sample_kind':'CONTROL_PRE_STATE','tick':x['tick'],'time_s':x['time_s'],
                    'p_ref_m':x['external_reference']['p_ref_m'],'v_ref_m_s':x['external_reference']['v_ref_m_s'],
                    'a_ref_m_s2':x['external_reference']['a_ref_m_s2'],'p_m':x['measured_p_m'],'v_m_s':x['measured_v_m_s'],
                    'a_base_ref_x_m_s2':a['a_base_ref'][0],'qdd_x_m_s2':x['qdd'][0] if x['qdd'] is not None else None,
                    'qacc_x_after_command_forward_m_s2':post['qacc_after_command_forward'][0],
                    'first_interval_average_accel_x_m_s2':x.get('first_physics_interval',{}).get('average_acceleration_from_qvel_difference',[None])[0],
                    'control_interval_average_accel_x_m_s2':x.get('control_interval_average_acceleration',{}).get('average_acceleration_from_qvel_difference',[None])[0],
                    'health_fr_thigh':h[1],'tau_cmd_fr_thigh_nm':x['tau_cmd'][1],'tau_applied_fr_thigh_nm':x['tau_applied'][1],
                    'latency_ms':x['latency_ms'],'solver_status':x['solver_status'],'dynamics_model_version':a['model_version']})
            if r.get('final_state'):
                series.append({'configuration':config,'input_id':input_id,'sample_kind':'FINAL_STATE_NO_ACTION','time_s':2.2,
                    'p_ref_m':r['p_init_m']+r['d_ref_m'],'v_ref_m_s':0.,'p_m':r['final_state']['qpos'][0],'v_m_s':r['final_state']['qvel'][0]})
            denom=sum(v*v for v in ref)
            row.update(reference_closure_residual_max_m_s2=max(closure,default=None),
                reference_rank_min=min(rank,default=None),reference_rank_max=max(rank,default=None),
                reference_condition_max=max(condition,default=None),
                motion_qp_reference_projection_gain=sum(a*b for a,b in zip(ref,qdd))/denom if denom else None,
                motion_qp_actual_qacc_base_x_rms_error_m_s2=rms(actual_error),
                motion_qp_actual_qacc_joint_rms_error_rad_s2=rms(joint_error),
                motion_qp_first_interval_base_x_rms_error_m_s2=rms(finite_difference_error),
                motion_predicted_actual_dry_friction_rms_error_nm=rms(loss_error),
                qp_effective_dynamics_residual_inf_max=max(effective,default=None),
                qp_legacy_dynamics_residual_inf_max=max(legacy,default=None),
                qp_contact_acceleration_residual_max_m_s2=max(contact_residual,default=None),
                grouped_constraint_force_sum_error_inf_max=max(group_residual,default=None),
                min_fr_thigh_command_margin_nm=min(command_margin,default=None),min_fr_thigh_actual_margin_nm=min(actual_margin,default=None),
                dry_friction_branch_counts=json.dumps(dict(branches),sort_keys=True))
            solver_status.update(str(x.get('status')) for x in r.get('solver_ledger',[]))
            checked={'identity':identity,'result_hash_matches':True,'counts':counts,
                'initial_hash_matches':r.get('initial_state_hash')==manifest['initial']['state_hash'],
                'checkpoint_times_s':[x['time_s'] for x in r.get('checkpoints',[])],
                'checkpoint_grid_valid':r.get('checkpoint_grid_valid'),
                'post_command_forward_time_matches_predecision':all(abs(x['time_s']-x['post_command_forward']['time_s'])<=1e-9 for x in controls),
                'external_forces_zero':all(not any(x['post_command_forward']['qfrc_applied']) and not any(v for rr in x['post_command_forward']['xfrc_applied'] for v in rr) for x in controls)}
            if r['status']=='COMPLETED' and (not checked['initial_hash_matches'] or not checked['checkpoint_grid_valid']):
                raise ValueError('Completed record violates fixed initial/grid')
            verified.append(checked);rows.append(row)
    for config in manifest['configuration_order']:
        zero=next(x for x in rows if x['configuration']==config and x['input_id']=='S21_HEALTHY_ZERO').get('final_displacement_m')
        for row in (x for x in rows if x['configuration']==config):
            row['same_configuration_zero_final_displacement_m']=zero
            raw=row.get('final_displacement_m')
            row['drift_adjusted_final_displacement_m']=None if raw is None or zero is None else raw-zero
    healthy=[x for x in rows if x['configuration']=='KF_CONTACT_AND_LOSS' and x['input_id']!='S21_H050_POS']
    criteria={}
    for row in healthy:
        i=row['input_id'];complete=row.get('status')=='COMPLETED'
        criteria[i+'_physical']=complete and row.get('physical_failure') is False and row.get('physical_window_status')=='PASS'
        criteria[i+'_deadline']=complete and row.get('deadline_miss_ticks')==0
        if i=='S21_HEALTHY_ZERO':
            criteria[i+'_drift']=complete and abs(row['final_displacement_m'])<=.0005
        else:
            criteria[i+'_sign']=complete and row['final_displacement_m']*row['d_ref_m']>0
            criteria[i+'_position']=complete and abs(row['final_position_error_m'])<=.002
            criteria[i+'_final_speed']=complete and abs(row['final_velocity_m_s'])<=.001
            criteria[i+'_hold_speed_rms']=complete and row['hold_velocity_rms_m_s']<=.001
    execution_ready=len(healthy)==3 and all(criteria.values())
    csv_write(out/'CASE_RESULTS.csv',rows);csv_write(out/'TASK_TIMESERIES.csv',series)
    source_changed={p:digest(root/p) for p,h in manifest['source_sha256'].items() if digest(root/p)!=h}
    source_documents_changed={p:digest(Path(manifest['source_step20_output'])/p) for p,h in manifest['source_step20_document_sha256'].items() if digest(Path(manifest['source_step20_output'])/p)!=h}
    if source_changed or source_documents_changed: raise ValueError('Frozen source/STEP20 document changed')
    attempts=sum(x['status']=='START' for x in history)
    if attempts>12 or total['control_qp_calls']>1320 or total['physics_steps']>13200: raise ValueError('STEP21 budget exceeded')
    summary={'schema':'STEP21_EXECUTION_SUMMARY_V1','run_id':manifest['run_id'],'checked_at_utc':datetime.now(timezone.utc).isoformat(),
        'real_episode_attempts':attempts,'states':dict(states),'fixed_batch_completed':states['COMPLETED']==12,
        'counts':dict(total),'solver_status_counts':dict(solver_status),'numerical_retries':0,
        'engineering_criteria':criteria,'common_task_execution_ready':execution_ready,
        'git_status':'SOURCE_AND_ARTIFACTS_SAVED_PENDING_SCOPED_COMMIT','source_sha256':manifest['source_sha256'],
        'frozen_source_changed':source_changed,'source_step20_documents_changed':source_documents_changed,
        'saved_evidence_checks':verified,'new_report_solver_calls':0,'new_report_physics_steps':0,
        'full_panel_expansion':False,'E3_authorized':False,'RL_or_hardware_authorized':False}
    diagnostics={'cases':rows,'engineering_criteria':criteria,'metrics_definitions':manifest['response_metrics_definitions']}
    (out/'RESPONSE_DIAGNOSTICS.json').write_text(json.dumps(diagnostics,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    lines=['# STEP21 接触兼容参考与损耗模型开发对照','', '## Material Passport','',
        'experiment-agent／run；2026-10-07（Asia/Seoul）；固定12条真实模拟及保存证据描述；无独立随机重复。','',
        '## 批次结果','',f"已完整完成 {states['COMPLETED']}/12 条；实际尝试 {attempts} 条；控制QP调用 {total['control_qp_calls']}；物理积分 {total['physics_steps']}。",
        f"KF共同任务执行工程判据：{'PASS' if execution_ready else 'NOT_MET'}。判据在首次START前冻结。所有普通求解、物理、任务与时延失败保留。",'',
        '| 配置 | 输入 | raw末位移 mm | drift-adjusted mm | raw末误差 mm | 末速度 mm/s | hold RMS mm/s | 物理 | >20ms |',
        '|---|---|---:|---:|---:|---:|---:|---|---:|']
    def fmt(row,key,scale=1.):
        v=row.get(key);return 'NA' if v is None else f'{v*scale:.6f}'
    for row in rows:
        lines.append('| '+ ' | '.join([row['configuration'],row['input_id'],fmt(row,'final_displacement_m',1000),
            fmt(row,'drift_adjusted_final_displacement_m',1000),fmt(row,'final_position_error_m',1000),
            fmt(row,'final_velocity_m_s',1000),fmt(row,'hold_velocity_rms_m_s',1000),str(row.get('physical_window_status','NA')),str(row.get('deadline_miss_ticks','NA'))])+' |')
    lines+=['','ZERO仍执行同一反馈管理器，仅d=0。漂移校正按同配置健康ZERO末位移作差；工程判据使用raw值。'
        'motion/hold MAE及静止段指标、完整物理原因、时延和力矩余量在CASE_RESULTS.csv，时序表包含所有输入。','',
        '## 参考、QP与真实瞬时加速度','',
        '| 配置 | 输入 | 参考闭合残差max m/s² | QP/参考投影比例 | QP−命令后qacc RMS m/s² | QP−首步差分 RMS m/s² |',
        '|---|---|---:|---:|---:|---:|']
    for row in rows:
        lines.append('| '+' | '.join([row['configuration'],row['input_id'],fmt(row,'reference_closure_residual_max_m_s2'),
            fmt(row,'motion_qp_reference_projection_gain'),fmt(row,'motion_qp_actual_qacc_base_x_rms_error_m_s2'),
            fmt(row,'motion_qp_first_interval_base_x_rms_error_m_s2')])+' |')
    lines+=['','比例定义为运动段Σ(a_base_ref_x·qdd_x)/Σ(a_base_ref_x²)。它是本轨迹的有符号传递描述。'
        'qacc在已选tau_total后的同状态forward取得；首步和控制区间速度差分分别为0.002 s和0.02 s平均近似，三者在原始记录中分列。',
        'K/KF固定SVD cutoff=1e−10，使用实际actuator→DOF映射；秩、奇异值、condition与未闭合残差逐tick保存。原足接触硬约束、任务权重与正则不变。','',
        '## 损耗模型与实际力分组','',
        'KF使用qfrc_bias−qfrc_passive−g_loss_pred。g_loss_pred取compiled hinge frictionloss，优先按当前关节速度方向；'
        '速度deadband=1e−4 rad/s，静止附近按参考加速度方向，deadband=1e−6 rad/s²。该运动意图规则是有界近似。'
        '全部补偿进入唯一QP总命令及健康力矩界，未在解后加力矩。',
        'passive force与dry friction分别处理；干摩擦是约束力，见[MuJoCo官方计算文档](https://mujoco.readthedocs.io/en/stable/computation/index.html#friction-loss)。'
        '诊断按真实efc_type分组，通过各组J.T·force得到广义力，[官方函数定义](https://mujoco.readthedocs.io/en/stable/APIreference/APIfunctions.html#mj-muljactvec)。'
        'contact、joint friction、limit及其他实际组均保留；这些命令后的qacc/constraint事实仅用于诊断。',
        '原式与KF有效式的动力学残差分别版本化；完整数值在case table与shard。QP残差与实际物理谓词分开描述。','',
        '## 时延与工程判据','',
        '| 配置 | 最大控制时延 ms | 超deadline tick | 最小H050 FR_thigh命令余量 N·m |',
        '|---|---:|---:|---:|']
    for config in manifest['configuration_order']:
        rr=[x for x in rows if x['configuration']==config]
        hh=next(x for x in rr if x['input_id']=='S21_H050_POS')
        lines.append(f"| {config} | {max((x.get('latency_max_ms') or 0 for x in rr)):.6f} | {sum(x.get('deadline_miss_ticks') or 0 for x in rr)} | {fmt(hh,'min_fr_thigh_command_margin_nm')} |")
    lines+=['','控制计时包含共享参考、SVD/损耗、QP、fallback与命令选择；action-conditioned forward、constraint诊断、积分与独立评价的耗时另列。',
        '冻结判据逐项结果：`'+json.dumps(criteria,ensure_ascii=False,sort_keys=True)+'`。',
        '求解原始状态计数：`'+json.dumps(dict(solver_status),ensure_ascii=False,sort_keys=True)+'`。',
        '调用分类计数：`'+json.dumps(dict(total),ensure_ascii=False,sort_keys=True)+'`。','',
        '## 研究判断与交付','',
        ('KF满足本批±10 mm支撑任务工程判据，建立了可继续构建预测backup选择器的共同载体。' if execution_ready else
         'KF尚未满足共同任务执行工程判据；本批直接记录了参考→QP→命令后加速度及损耗分组，下一步应由这些链路证据定位剩余误差。'),
        '本轮以L→K→KF固定消融描述共同载体的变化；开发配置不能直接作为论文新算法。'
        '本批没有H2优越性、预测P1或论文投稿证据完备的结论；时序tick不作为独立重复，未做显著性、非劣性或等效检验。',
        '交付：PROTOCOL_AND_MANIFEST.json、12行CASE_RESULTS.csv、TASK_TIMESERIES.csv、cases/*/STEP21_CASE_SHARD.json、'
        'ATTEMPT_LEDGER.jsonl、RESPONSE_DIAGNOSTICS.json、TEST_RESULTS.json、EXECUTION_SUMMARY.json。','',
        '```ini',f"STEP21_FIXED_BATCH = {'COMPLETED_12_OF_12' if states['COMPLETED']==12 else 'INCOMPLETE'}",
        f"KF_COMMON_TASK_EXECUTION_CRITERIA = {'PASS' if execution_ready else 'NOT_MET'}",
        f'REAL_EPISODE_ATTEMPTS = {attempts}',f"CONTROL_QP_CALLS = {total['control_qp_calls']}",
        f"PHYSICS_INTEGRATION_STEPS = {total['physics_steps']}",
        'NUMERICAL_RETRIES = 0','PARAMETER_SEARCH = FALSE','HISTORICAL_RESULTS_UNCHANGED = TRUE',
        'FULL_PANEL_EXPANSION = FALSE','PREDICTIVE_P1 = NOT_IMPLEMENTED','E3 = NOT_AUTHORIZED','RL_OR_HARDWARE = NOT_AUTHORIZED','```','']
    delivery=out/'GIT_DELIVERY.json'
    if delivery.exists():
        gd=json.loads(delivery.read_text(encoding='utf-8'));summary['git_status']=gd['status'];summary['git_delivery']=gd
        lines+=['Git交付状态：`'+gd['status']+'`；核心提交：`'+gd['core_commit']+'`；分支：`'+gd['branch']+'`。',
            '使用E盘隔离索引/对象方案；原工作树HEAD未reset。']
    (out/'TASK_RESPONSE_REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
    summary['artifact_sha256']={str(p.relative_to(out)):digest(p) for p in out.rglob('*') if p.is_file() and p.name!='EXECUTION_SUMMARY.json'}
    (out/'EXECUTION_SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'completed':states['COMPLETED'],'attempts':attempts,'counts':dict(total),
        'engineering_ready':execution_ready,'criteria':criteria,'solver_statuses':dict(solver_status)},ensure_ascii=False),flush=True)
