"""STEP21 fixed 4-input by 3-configuration batch; append-only attempt ledger."""
import argparse
from collections import Counter
from dataclasses import asdict
from datetime import datetime, timezone
import gc
import hashlib
import json
import os
from pathlib import Path
import sys
from time import perf_counter
import traceback

import mujoco
import numpy as np
from cavr_wbc.control.step21_contact_reference import CONFIGURATIONS, Step21WBC
from cavr_wbc.experiments import step17_formal_panel as frozen
from cavr_wbc.experiments.step04_e2b import Scenario
from cavr_wbc.experiments.step20_episode import initial_state_facts
from cavr_wbc.experiments.step21_episode import run_episode

ROOT = Path(__file__).resolve().parents[2]
PROTOCOL = Path('E:/CAVR-WBC/experiment_handoff_20260921/NEXT_CODEX_INSTRUCTIONS_STEP21_CONTACT_CONSISTENT_RESPONSE_20261007.md')
OLD_OUT = ROOT/'artifacts/step20_task_response_20261001/step20-task-response-20261001-0519'
INPUTS = (('S21_HEALTHY_ZERO',0.),('S21_HEALTHY_POS',.01),('S21_HEALTHY_NEG',-.01),('S21_H050_POS',.01))
NEW_SOURCE = ('cavr_wbc/control/step21_contact_reference.py','cavr_wbc/experiments/step21_episode.py',
    'cavr_wbc/experiments/step21_response.py','cavr_wbc/experiments/step21_report.py',
    'tests/test_step21_contact_reference.py','tests/test_step21_response.py')
ENGINEERING_CRITERIA = {'healthy_pos_negative_correct_signed_raw_displacement':True,
    'healthy_directions_raw_final_position_error_abs_max_m':.002,
    'healthy_directions_final_velocity_abs_max_m_s':.001,
    'healthy_directions_hold_velocity_rms_max_m_s':.001,
    'healthy_zero_raw_final_displacement_abs_max_m':.0005,
    'healthy_zero_pos_neg_physical_failures_max':0,'healthy_zero_pos_neg_deadline_misses_max':0,
    'configuration':'KF_CONTACT_AND_LOSS'}


def utc():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
    return h.hexdigest()


def write_json(path, obj):
    frozen._atomic_write_text(path,json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)+'\n')


def append(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('a',encoding='utf-8',newline='') as f:
        f.write(json.dumps(obj,sort_keys=True,allow_nan=False)+'\n');f.flush();os.fsync(f.fileno())


def freeze(out, run_id):
    old=json.loads((OLD_OUT/'PROTOCOL_AND_MANIFEST.json').read_text(encoding='utf-8'))
    legacy={p:digest(ROOT/p) for p in old['source_sha256']}
    if legacy!=old['source_sha256']: raise ValueError('Directly inherited frozen source changed')
    scenario=Scenario(**old['selected_source_scenario'])
    initial=initial_state_facts(scenario)
    if initial['state_hash']!=old['initial']['state_hash']: raise ValueError('Shared STEP20 initial hash mismatch')
    model=frozen.load_model();controller=Step21WBC(model,CONFIGURATIONS[0])
    source={**legacy,**{p:digest(ROOT/p) for p in NEW_SOURCE}}
    old_artifacts={p:digest(OLD_OUT/p) for p in ('TASK_RESPONSE_REPORT.md','PROTOCOL_AND_MANIFEST.json','EXECUTION_SUMMARY.json')}
    manifest={'schema':'STEP21_PROTOCOL_V1','run_id':run_id,'frozen_at_utc':utc(),
        'client_date':'2026-10-07','client_timezone':'Asia/Seoul','protocol':str(PROTOCOL),'protocol_sha256':digest(PROTOCOL),
        'source_commit':'0f4eda7fb9d52fa4f0e4d0165898c5b2059bc986',
        'source_step20_output':str(OLD_OUT),'source_step20_document_sha256':old_artifacts,
        'interpretation_document':str(PROTOCOL.parent/'step20_response_analysis_20261007/STEP20_RESEARCH_INTERPRETATION.md'),
        'selected_source_scenario':asdict(scenario),'initial':initial,'compiled_mapping_and_losses':controller.mapping_info,
        'input_order':[{'input_id':i,'d_m':d,'fault_onset_s':.2 if i=='S21_H050_POS' else None,
            'health_after_onset':.5 if i=='S21_H050_POS' else 1.,'fault_actuator_mask':[1]} for i,d in INPUTS],
        'configuration_order':list(CONFIGURATIONS),'dispatch_order':'configuration outer, input inner; L,K,KF then ZERO,POS,NEG,H050',
        'method':'B1 single-stage only','episode_duration_s':2.2,'physics_dt_s':.002,'control_dt_s':.02,
        'physics_steps_per_case':1100,'control_decisions_per_case':110,'checkpoint_times_s':[.2+j*.05 for j in range(21)],
        'max_real_episode_attempts':12,'max_control_qp_calls':1320,'max_physics_integration_steps':13200,
        'numerical_retries':0,'wall_timeout_s':1800,'deadline_ms':20.,'engineering_criteria':ENGINEERING_CRITERIA,
        'response_metrics_definitions':{'motion_window_s':[.2,1.2],
            'drift_adjusted_final_displacement':'raw final displacement minus same-configuration HEALTHY_ZERO raw final displacement',
            'qp_reference_projection_gain':'sum(a_base_ref_x*qdd_x)/sum(a_base_ref_x^2) over saved motion control ticks',
            'qp_actual_base_accel_rms_error':'RMS(qdd_x - qacc_after_command_forward_x) at same qpos/qvel and selected command',
            'first_interval_average_accel':'(v(t+.002)-v(t))/.002; distinct from instantaneous qacc',
            'control_interval_average_accel':'(v(t+.02)-v(t))/.02; distinct from instantaneous qacc'},
        'task_reference':old['task_reference'],'wbc_config':old['wbc_config'],
        'independent_evaluator_config':old['independent_evaluator_config'],
        'physical_task_limits':old['physical_task_limits'],'physical_terminal_limits':old['physical_terminal_limits'],
        'model_files_sha256':old['model_files_sha256'],'source_sha256':source,
        'relative_svd_rank_cutoff':1e-10,'loss_velocity_deadband_rad_s':1e-4,'loss_acceleration_deadband_rad_s2':1e-6,
        'loss_prediction':'bounded per-actuated-hinge dry-friction approximation; velocity first, intention at rest',
        'external_generalized_forces':'all zero','external_body_wrenches':'all zero',
        'constraint_truth_enters_control':False,'qacc_after_command_forward_enters_control':False,
        'post_solve_torque_compensation':False,'task_weights_changed':False,
        'dynamics_versions':{'L_LEGACY':'M*qdd+qfrc_bias=B*tau_total+Jc.T*lambda',
            'K_CONTACT_REFERENCE':'same as L',
            'KF_CONTACT_AND_LOSS':'M*qdd+(qfrc_bias-qfrc_passive-g_loss_pred)=B*tau_total+Jc.T*lambda'},
        'official_dynamics_documentation':'https://mujoco.readthedocs.io/en/stable/computation/index.html#friction-loss',
        'python':sys.executable,'python_version':sys.version,'mujoco_version':mujoco.__version__,'numpy_version':np.__version__,
        'native_osqp_dll':os.environ.get('CAVR_WBC_NATIVE_OSQP_DLL'),'TEMP':os.environ.get('TEMP'),'TMP':os.environ.get('TMP'),
        'historical_results_unchanged':True,'full_panel_expansion':False,'E3_authorized':False,'RL_or_hardware_authorized':False}
    for p,h in manifest['model_files_sha256'].items():
        if digest(ROOT/p)!=h: raise ValueError('Model differs from STEP20')
    manifest['manifest_hash']=frozen.sha(manifest)
    write_json(out/'PROTOCOL_AND_MANIFEST.json',manifest)
    return scenario,manifest


def execute_case(out,manifest,scenario,input_id,d,configuration,episode_fn=run_episode):
    ledger=out/'ATTEMPT_LEDGER.jsonl';identity=configuration+':'+input_id
    history=[json.loads(x) for x in ledger.read_text(encoding='utf-8').splitlines() if x] if ledger.exists() else []
    if sum(x['status']=='START' for x in history)>=12 or any(x['identity']==identity for x in history):
        raise RuntimeError('Attempt reserved; refusing numerical retry or >12 episodes')
    shard=out/'cases'/f'{configuration}__{input_id}'/'STEP21_CASE_SHARD.json'
    if shard.exists(): raise RuntimeError('Refusing shard overwrite')
    start={'identity':identity,'status':'START','run_id':manifest['run_id'],'manifest_hash':manifest['manifest_hash'],
        'timestamp_utc':utc(),'pid':os.getpid()}
    append(ledger,start);print(json.dumps(start),flush=True)
    try:
        result=episode_fn(scenario,input_id,d,configuration,manifest['initial']['state_hash'])
    except Exception as exc:
        result={'status':'FAILED','configuration':configuration,'input_id':input_id,'solver_ledger':[],
            'counts':{},'unknown_call_count':True,'implementation_error':{'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()}}
    payload={'schema':'STEP21_CASE_SHARD_V1','identity':identity,'manifest_hash':manifest['manifest_hash'],
        'run_id':manifest['run_id'],'result':result,'result_hash':frozen.sha(result)}
    begin=perf_counter()
    for write_attempt in range(2):
        try:
            write_json(shard,payload)
            checked=json.loads(shard.read_text(encoding='utf-8'))
            if frozen.sha(checked['result'])!=payload['result_hash']: raise RuntimeError('Shard readback mismatch')
            break
        except OSError:
            if write_attempt:
                append(ledger,{**start,'status':'UNKNOWN','timestamp_utc':utc(),'reason':'Persistence failure; no trajectory recomputed'})
                raise
    done={**start,'status':'DONE' if result['status']=='COMPLETED' else 'FAILED','timestamp_utc':utc(),
        'shard':str(shard.relative_to(out)),'result_hash':payload['result_hash'],'counts':result.get('counts',{}),
        'write_and_readback_s':perf_counter()-begin}
    append(ledger,done);print(json.dumps(done),flush=True)
    return result


def run(out,run_id):
    out=out.resolve()
    allowed=(ROOT/'artifacts/step21_contact_response_20261007').resolve()
    if allowed not in out.parents: raise ValueError('Output must be unique child of STEP21 directory')
    out.mkdir(parents=True,exist_ok=True)
    if (out/'PROTOCOL_AND_MANIFEST.json').exists() or (out/'ATTEMPT_LEDGER.jsonl').exists():
        raise RuntimeError('Existing batch evidence; run cannot restart')
    begin=perf_counter();scenario,manifest=freeze(out,run_id)
    write_json(out/'RUN_STARTED.json',{'run_id':run_id,'pid':os.getpid(),'timestamp_utc':utc(),
        'command':sys.argv,'cwd':str(ROOT),'timeout_s':1800})
    counts=Counter();states=Counter();stopped=None
    try:
        for config in CONFIGURATIONS:
            for input_id,d in INPUTS:
                if perf_counter()-begin>=1800:
                    stopped='WALL_TIMEOUT';break
                result=execute_case(out,manifest,scenario,input_id,d,config)
                counts.update(result.get('counts',{}));states[result['status']]+=1
                write_json(out/'PROGRESS.json',{'updated_utc':utc(),'run_id':run_id,'last_identity':config+':'+input_id,
                    'states':dict(states),'counts':dict(counts),'max_attempts':12})
                if counts['control_qp_calls']>1320 or counts['physics_steps']>13200:
                    stopped='IMPLEMENTATION_BUDGET_ERROR'
                elif result.get('implementation_error'):
                    stopped='IMPLEMENTATION_ERROR'
                del result;gc.collect()
                if stopped: break
            if stopped: break
    except BaseException as exc:
        write_json(out/'INTERRUPTION.json',{'run_id':run_id,'timestamp_utc':utc(),
            'type':type(exc).__name__,'message':str(exc),'counts':dict(counts)})
        raise
    write_json(out/'RUN_FINISHED.json',{'run_id':run_id,'timestamp_utc':utc(),'pid':os.getpid(),
        'status':'FIXED_BATCH_DISPATCH_COMPLETED' if stopped is None else stopped,'states':dict(states),
        'counts':dict(counts),'elapsed_wall_s':perf_counter()-begin})
    from cavr_wbc.experiments.step21_report import report
    report(out)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True)
    p.add_argument('--run-id');p.add_argument('--summarize',action='store_true');args=p.parse_args()
    if args.summarize:
        from cavr_wbc.experiments.step21_report import report
        report(args.output.resolve())
    else:
        if not args.run_id: p.error('--run-id required for fixed batch')
        run(args.output,args.run_id)
