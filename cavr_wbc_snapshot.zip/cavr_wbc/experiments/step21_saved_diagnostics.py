"""Saved STEP21 force-chain interpretation and final bounded-evidence checks.

No MuJoCo/controller imports or numerical experiment dispatch. Linear solves
only decompose already-recorded acceleration errors using saved mass matrices.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import json
from pathlib import Path
import numpy as np

from cavr_wbc.experiments.step21_report import digest, canonical_hash


def analyze(out):
    root=Path(__file__).resolve().parents[2]
    m=json.loads((out/'PROTOCOL_AND_MANIFEST.json').read_text(encoding='utf-8'))
    summary=json.loads((out/'EXECUTION_SUMMARY.json').read_text(encoding='utf-8'))
    history=[json.loads(x) for x in (out/'ATTEMPT_LEDGER.jsonl').read_text().splitlines() if x]
    identities=[c+':'+i['input_id'] for c in m['configuration_order'] for i in m['input_order']]
    if len(history)!=24 or any([x['status'] for x in history if x['identity']==i]!=['START','DONE'] for i in identities):
        raise ValueError('Expected exactly 12 START/DONE identities')
    if any(x['run_id']!=m['run_id'] or x['manifest_hash']!=m['manifest_hash'] for x in history):
        raise ValueError('Ledger run/manifest mismatch')
    for p,h in m['source_sha256'].items():
        if digest(root/p)!=h: raise ValueError('Frozen numerical/reporting source changed')
    for p,h in m['model_files_sha256'].items():
        if digest(root/p)!=h: raise ValueError('Frozen model changed')
    if digest(Path(m['protocol']))!=m['protocol_sha256']: raise ValueError('Protocol changed')
    cases=[];linear_solves=0;verified=[];count=Counter()
    for event in (x for x in history if x['status']=='DONE'):
        payload=json.loads((out/event['shard']).read_text(encoding='utf-8'));r=payload['result']
        if canonical_hash(r)!=payload['result_hash'] or payload['result_hash']!=event['result_hash']: raise ValueError('Shard evidence changed')
        if r['counts']!=event['counts']: raise ValueError('Call ledger count mismatch')
        if r['counts']['control_qp_calls']!=len(r['solver_ledger']): raise ValueError('Solver ledger incomplete')
        if r['initial_state_hash']!=m['initial']['state_hash']: raise ValueError('Initial state mismatch')
        if (len(r['controls']),len(r['physics_trajectory']),len(r['checkpoints']))!=(110,1100,21): raise ValueError('Fixed lengths incomplete')
        if len(r['evaluator']['checkpoints'])!=21: raise ValueError('Independent window incomplete')
        if abs(r['final_state']['time_s']-2.2)>1e-9: raise ValueError('Final time mismatch')
        count.update(r['counts']);terms={};rows=[];max_sum_error=0.;max_eq_error=0.;max_unattributed=0.;mapped=m['compiled_mapping_and_losses']['mapped_joint_dofs']
        reference_closed=[];tau_extra=[];zeros=[]
        for x in r['controls']:
            a=x['assembly'];post=x['post_command_forward'];M=np.asarray(a['M']);J=np.asarray(a['Jc']);B=np.asarray(a['B'])
            h=np.ones(12)
            if r['input_id']=='S21_H050_POS' and x['tick']>=10: h[1]=.5
            if not np.array_equal(x['health_vector'],h): raise ValueError('Fault timing/mapping error')
            if abs(post['time_s']-x['time_s'])>1e-9: raise ValueError('Post-command time mismatch')
            if any(post['qfrc_applied']) or any(v for rr in post['xfrc_applied'] for v in rr): raise ValueError('External force nonzero')
            if not np.array_equal(x['tau_cmd'],x['tau_total']): raise ValueError('Unrecorded post-solve increment')
            if r['input_id']=='S21_HEALTHY_ZERO' and (x['external_reference']['p_ref_m']!=r['p_init_m'] or x['external_reference']['v_ref_m_s']!=0 or x['external_reference']['a_ref_m_s2']!=0): raise ValueError('ZERO reference changed')
            if x['qdd'] is None: continue
            qdd=np.asarray(x['qdd']);tau=np.asarray(x['tau_total']);lam=np.asarray(x['contact_lambda_qp'])
            qacc=np.asarray(post['qacc_after_command_forward']);fr=np.asarray(post['qfrc_constraint'])
            groups=post['constraint_diagnostics']['groups'];contact=np.zeros(len(qdd));friction=np.zeros(len(qdd));other=np.zeros(len(qdd))
            for name,group in groups.items():
                value=np.asarray(group['generalized_force_J_transpose_f'])
                if name.startswith('mjCNSTR_CONTACT'): contact+=value
                elif name=='mjCNSTR_FRICTION_DOF': friction+=value
                else: other+=value
            compensated=r['configuration']=='KF_CONTACT_AND_LOSS'
            g=np.asarray(a['g_loss_pred']) if compensated else np.zeros(len(qdd))
            passive=np.asarray(post['qfrc_passive'])-(np.asarray(a['qfrc_passive']) if compensated else 0.)
            fterms={'actuator_map_difference':np.asarray(post['qfrc_actuator'])-B@tau,
                'passive_unmodeled_or_difference':passive,
                'actual_contact_minus_QP_contact':contact-J.T@lam,
                'actual_joint_friction_minus_prediction':friction-g,'other_constraints':other}
            exact_dynamics=M@qacc+np.asarray(post['qfrc_bias'])-np.asarray(post['qfrc_passive'])-np.asarray(post['qfrc_actuator'])-fr
            max_eq_error=max(max_eq_error,float(np.max(np.abs(exact_dynamics))))
            qp_residual=M@qdd+np.asarray(a['bias_eff'])-B@tau-J.T@lam
            # Preserve the unexplained saved balance rather than assigning it
            # to any force group. This is an algebraic identity, not an extra
            # certification of the simulator's continuous-time dynamics.
            fterms['bias_before_after_difference']=np.asarray(a['bias_original'])-np.asarray(post['qfrc_bias'])
            raw_remainder=M@(qacc-qdd)-sum(fterms.values())
            max_unattributed=max(max_unattributed,float(np.max(np.abs(raw_remainder))))
            fterms['unattributed_recorded_balance_remainder']=raw_remainder
            if .2<=x['time_s']<=1.2:
                names=list(fterms);columns=np.column_stack([fterms[k] for k in names])
                accel=np.linalg.solve(M,columns);linear_solves+=1
                sum_error=accel.sum(axis=1)-(qacc-qdd)
                max_sum_error=max(max_sum_error,float(np.max(np.abs(sum_error))))
                for j,name in enumerate(names): terms.setdefault(name,[]).append(float(accel[0,j]))
                actual_joint=np.asarray(friction)[mapped];predicted_joint=np.asarray(g)[mapped]
                row={'tick':x['tick'],'time_s':x['time_s'],'reference_base_x_m_s2':a['a_base_ref'][0],
                    'qdd_base_x_m_s2':float(qdd[0]),'qacc_base_x_m_s2':float(qacc[0]),
                    'actual_minus_QP_base_x_acceleration_m_s2':float(qacc[0]-qdd[0]),
                    'base_x_acceleration_components_m_s2':{name:float(accel[0,j]) for j,name in enumerate(names)},
                    'actual_hinge_friction_nm':actual_joint.tolist(),'predicted_hinge_friction_nm':predicted_joint.tolist(),
                    'loss_branches':a['loss_prediction']['branch_actuator_order'] if a['loss_prediction'] else None}
                row['unattributed_generalized_force_remainder']=raw_remainder.tolist()
                rows.append(row)
        case={'identity':event['identity'],'configuration':r['configuration'],'input_id':r['input_id'],
            'motion_acceleration_component_rms_m_s2':{k:float(np.sqrt(np.mean(np.square(v)))) for k,v in terms.items()},
            'motion_acceleration_component_mean_m_s2':{k:float(np.mean(v)) for k,v in terms.items()},
            'acceleration_decomposition_sum_error_inf_max':max_sum_error,
            'same_state_actual_dynamics_residual_inf_max':max_eq_error,'motion_records':rows}
        case['unattributed_generalized_force_remainder_inf_max']=max_unattributed
        cases.append(case)
        verified.append({'identity':event['identity'],'controls':110,'physics_steps':1100,'solver_ledger_calls':110,
            'checkpoints':21,'initial_state_hash_matches':True,'case_hash_matches':True,
            'timing_and_health_and_external_zero_and_total_torque_checks':True})
    if count['control_qp_calls']!=1320 or count['physics_steps']!=13200: raise ValueError('Complete batch budget mismatch')
    diagnostics={'schema':'STEP21_SAVED_FORCE_CHAIN_DIAGNOSTICS_V1','cases':cases,
        'decomposition':'Algebraic M^-1 force components plus explicitly retained unattributed recorded balance remainder; not an exact model certification',
        'time_window_s':[.2,1.2],'postprocessing_linear_system_solves':linear_solves,
        'new_solver_calls':0,'new_physics_integration_steps':0,'new_episodes':0,
        'correlated_components_not_independent_causal_effects':True,'source_sha256':digest(Path(__file__))}
    (out/'CHAIN_FORCE_DIAGNOSTICS.json').write_text(json.dumps(diagnostics,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    details=['','## L→K→KF 的实际效果与未通过原因','',
        'L健康正负方向的QP传递比例分别为0.027752和0.028586；K提高到0.999569和1.000403。'
        'K/KF的12列关节Jacobian在本批逐tick满秩，最大condition约2.382，参考闭合残差不超过3.215e−16 m/s²。'
        '接触参考已修复QP层的加速度衰减，实际plant的运动传递仍需单独判断。',
        'K正负raw末位移分别+0.286901/+0.106050 mm；去除同配置ZERO漂移后为+0.090406/−0.090445 mm。'
        '相较L的±0.00250 mm差分响应有所增加，但QP−真实瞬时qacc的运动段RMS约0.03926 m/s²，基座未执行要求的±10 mm。',
        'KF正向raw位移+11.944030 mm、位置误差+1.944030 mm，单项位置判据通过；末速度4.419408 mm/s、hold RMS 4.700659 mm/s均超过1 mm/s。'
        'KF负向raw位移+6.041624 mm，位置误差+16.041624 mm；减去ZERO后仍为+1.106597 mm，方向问题仍存在。'
        'KF ZERO漂移+4.935027 mm，超过0.5 mm界。由此具体失败于ZERO漂移、负向符号/误差及两方向停止指标。',
        'KF相对K降低了正向QP−qacc RMS（0.039259→0.026826 m/s²），负向仅由0.039267降至0.038181 m/s²。'
        '其干摩擦预测与真实joint-friction约束广义力的运动段RMS误差约0.108～0.110 N·m；强制按速度或近静止意图选择满幅frictionloss，'
        '并未复制实际静摩擦可取中间约束力的状态。这是已记录的模型差异，伴随接触反作用差异，应由完整力链定位，不能据正向位移一项认定载体已完成。','',
        '| 配置 | 输入 | contact差异分量RMS m/s² | dry-friction差异分量RMS m/s² | 未归因余项RMS m/s² |',
        '|---|---|---:|---:|---:|']
    for case in cases:
        t=case['motion_acceleration_component_rms_m_s2']
        details.append(f"| {case['configuration']} | {case['input_id']} | {t.get('actual_contact_minus_QP_contact',0):.6f} | {t.get('actual_joint_friction_minus_prediction',0):.6f} | {t.get('unattributed_recorded_balance_remainder',0):.6f} |")
    details+=['','该表通过保存的M和广义力分组分解同状态(qacc−qdd)，组件存在相关与抵消，RMS不能相加成独立因果贡献。'
        '仅已记录力项的平衡存在未归因余项，原最大广义力平衡差0.013137（分量单位含N/N·m）；未据此认定真实动力学已经被精确重建。'
        '余项单列并保留，不能将全部响应差归因于dry friction或contact。完整有符号逐tick分解、实际摩擦、预测摩擦和分支在CHAIN_FORCE_DIAGNOSTICS.json。',
        'H050正向与同配置健康正向的末态/任务指标一致；KF退化FR_thigh最小命令及实际力矩余量均为11.064706 N·m。'
        '该输入未激发健康力矩界，不提供健康收益判断。物理12/12通过、全部1320个控制决策≤20 ms，最大10.329600 ms。',
        '本轮固定批次完成，任务执行工程判据NOT_MET。剩余问题集中于QP到plant的损耗/接触力匹配、记录平衡余项及漂移/停止响应；本轮在交付后结束。','']
    report_path=out/'TASK_RESPONSE_REPORT.md';text=report_path.read_text(encoding='utf-8')
    marker='\n## L→K→KF 的实际效果与未通过原因'
    text=text.split(marker)[0]
    report_path.write_text(text+'\n'.join(details),encoding='utf-8')
    verification={'schema':'STEP21_FINAL_BOUNDED_EVIDENCE_CHECK_V1','checked_at_utc':datetime.now(timezone.utc).isoformat(),
        'status':'PASS','ledger_events':24,'start_count':12,'done_count':12,'failed_or_unknown_or_missing':0,
        'cases':verified,'counts':dict(count),'frozen_sources_unchanged':True,'model_unchanged':True,
        'physics_steps':13200,'control_qp_calls':1320,'new_episodes':0,'new_control_solver_calls':0,'new_integration_steps':0,
        'scientific_task_execution_pass':False,'postprocessing_linear_system_solves':linear_solves,
        'command':'python -B -X utf8 -m cavr_wbc.experiments.step21_saved_diagnostics --output '+str(out)}
    (out/'FINAL_VERIFICATION.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    summary['postprocessing_source_sha256']={str(Path(__file__).relative_to(root)):digest(Path(__file__))}
    summary['final_verification_status']='PASS';summary['execution_exit_code']=0
    summary['freeze_static_initialization_forward_calls']=1
    summary['artifact_sha256']={str(p.relative_to(out)):digest(p) for p in out.rglob('*') if p.is_file() and p.name!='EXECUTION_SUMMARY.json'}
    (out/'EXECUTION_SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'saved_evidence_check':'PASS','new_episode_or_control_solver_or_integration_calls':0,
        'postprocessing_linear_system_solves':linear_solves,
        'max_accel_decomposition_error':max(x['acceleration_decomposition_sum_error_inf_max'] for x in cases),
        'max_actual_dynamics_residual':max(x['same_state_actual_dynamics_residual_inf_max'] for x in cases)}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True)
    analyze(p.parse_args().output.resolve())
