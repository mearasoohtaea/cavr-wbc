"""STEP22 fixed-duration full-pose episodes; diagnostics after command choice."""
from collections import Counter
from dataclasses import asdict
from time import perf_counter
import traceback
import mujoco
import numpy as np

from cavr_wbc.control.step20_task_reference import reference
from cavr_wbc.control.step22_pose_servo import Step22WBC, BasePoseServo
from cavr_wbc.experiments import step17_formal_panel as frozen
from cavr_wbc.experiments.step20_episode import (
    PHYSICS_STEPS, CONTROL_TICKS, CHECKPOINT_STEPS, channel_mapping, state_values, json_safe, task_metrics,
)
from cavr_wbc.experiments.step21_episode import constraint_diagnostics
from cavr_wbc.evaluation.step16_independent_evaluator import evaluate_serialized_trajectory
from cavr_wbc.platforms.go2_mujoco import extract_healthy_torque_limits


def health_at_tick(input_id,tick,nu=12):
    h=np.ones(nu)
    if input_id=='S22_H050_POS' and tick>=10: h[1]=.5
    return h


def final_pose_error(model,data,q_init,d):
    qref=data.qpos.copy();qref[:7]=q_init[:7];qref[0]+=d
    error=np.zeros(model.nv);mujoco.mj_differentiatePos(model,error,1.,data.qpos,qref)
    return {'q_reference':qref.tolist(),'tangent_pose_error':error[:6].tolist(),
        'position_offset_xyz_m':(data.qpos[:3]-q_init[:3]).tolist(),
        'orientation_error_norm_rad':float(np.linalg.norm(error[3:6])),
        'base_angular_velocity_rad_s':data.qvel[3:6].copy().tolist()}


def run_episode(scenario,input_id,d,configuration,expected_initial_hash):
    model=frozen.load_model();data=mujoco.MjData(model);frozen._reset(model,data,scenario)
    initial=state_values(data);channel_mapping(model)
    if frozen.sha(initial)!=expected_initial_hash: raise ValueError('STEP22 frozen initial state mismatch')
    if np.any(data.qfrc_applied) or np.any(data.xfrc_applied): raise ValueError('External force must be zero')
    q_init=data.qpos.copy();p_init=float(q_init[0]);controller=Step22WBC(model)
    servo=BasePoseServo(model,q_init,d,configuration)
    limits=extract_healthy_torque_limits(model);base_id=frozen._base_id(model)
    backup_id=f'STEP22-{configuration}-{input_id}'
    controls=[];physics=[];checkpoints=[];solver=[];latency=[];integral=[]
    steps=0;cursor=0;failure=None;implementation_error=None
    integration_s=0.;evaluation_s=0.;forward_s=0.;diagnostic_s=0.
    forward_calls=0;refresh_calls=0;diagnostic_calls=0;products=0

    def facts(h,tau,action,ms,step,tick):
        nonlocal evaluation_s
        begin=perf_counter()
        row=frozen._facts(model,data,tau,data.actuator_force.copy(),h,limits,ms,t=step*.002,tick=tick,
            backup_id=backup_id,scenario_id=input_id,action=action,base_id=base_id)
        row['physical_evaluation'].pop('utility',None)
        row.update(physics_step=step,external_reference=reference(p_init,d,step*.002))
        evaluation_s+=perf_counter()-begin
        return row

    try:
        for tick in range(CONTROL_TICKS):
            t=tick*.02;step=tick*10;h=health_at_tick(input_id,tick,model.nu)
            data.qfrc_applied[:]=0.;data.xfrc_applied[:]=0.
            response=servo.compute(controller,data,h,tick)
            wb=response.pop('wbc');response.pop('wb',None)
            tau=np.asarray(response['tau_cmd'],dtype=float);ms=response['latency_ms']
            trace=controller.last_trace;qvel_before=data.qvel.copy()
            # tau_total is the one QP command or the recorded zero fallback.
            data.ctrl[:]=tau
            begin=perf_counter();mujoco.mj_forward(model,data)
            forward_s+=perf_counter()-begin;forward_calls+=1
            begin=perf_counter();diag=constraint_diagnostics(model,data)
            mass=np.zeros((model.nv,model.nv));mujoco.mj_fullM(model,data,mass)
            diagnostic_s+=perf_counter()-begin;diagnostic_calls+=1;products+=diag['jacobian_transpose_products']
            post={'time_s':float(data.time),'qpos':data.qpos.copy().tolist(),'qvel':data.qvel.copy().tolist(),
                'qacc_after_command_forward':data.qacc.copy().tolist(),'M_after_command_forward':mass.tolist(),
                'qfrc_bias':data.qfrc_bias.copy().tolist(),'qfrc_passive':data.qfrc_passive.copy().tolist(),
                'qfrc_actuator':data.qfrc_actuator.copy().tolist(),'qfrc_constraint':data.qfrc_constraint.copy().tolist(),
                'qfrc_smooth':data.qfrc_smooth.copy().tolist(),'qacc_smooth':data.qacc_smooth.copy().tolist(),
                'qfrc_damper':data.qfrc_damper.copy().tolist(),'qfrc_spring':data.qfrc_spring.copy().tolist(),
                'qfrc_applied':data.qfrc_applied.copy().tolist(),'xfrc_applied':data.xfrc_applied.copy().tolist(),
                'constraint_diagnostics':diag}
            for entry in controller.solver_ledger[cursor:]:
                solver.append(dict(entry,configuration=configuration,input_id=input_id,tick=tick,time_s=t))
            cursor=len(controller.solver_ledger)
            pre=facts(h,tau,response['a_base_ref'][0],ms,step,tick)
            row={'configuration':configuration,'input_id':input_id,'method':'B1','tick':tick,'time_s':t,
                **response,'assembly':trace,'health_vector':h.tolist(),'fault_mask':[1],
                'tau_total':tau.tolist(),'tau_cmd':tau.tolist(),'tau_applied':data.actuator_force.copy().tolist(),
                'qdd':None if wb.get('qdd') is None else np.asarray(wb['qdd']).tolist(),
                'contact_lambda_qp':None if wb.get('contact_force') is None else np.asarray(wb['contact_force']).tolist(),
                'solver_status':wb.get('status'),'solver_status_val':wb.get('status_val'),
                'solver_success':response['valid_command'],'wbc_validation':wb.get('validation'),
                'post_command_forward':post,'physical_at_decision':pre,
                'command_source':'B1_QP_TOTAL' if response['valid_command'] else 'ZERO_COMMAND_FALLBACK'}
            controls.append(row);integral.append(dict(response['integral_record'],tick=tick,time_s=t))
            latency.append({'tick':tick,'time_s':t,'latency_ms':ms,'deadline_ms':20.,'deadline_miss':ms>20.})
            if step==100: checkpoints.append(pre)
            for sub in range(10):
                begin=perf_counter();mujoco.mj_step(model,data);steps+=1
                finite=np.isfinite(data.qpos).all() and np.isfinite(data.qvel).all() and np.isfinite(data.actuator_force).all()
                if finite:
                    mujoco.mj_forward(model,data);refresh_calls+=1
                integration_s+=perf_counter()-begin
                if not finite or abs(float(data.time)-steps*.002)>1e-9:
                    failure={'type':'NONFINITE_OR_SIMULATOR_RESET','physics_step':steps,'state':json_safe(state_values(data))}
                    break
                if sub==0:
                    row['first_physics_interval']={'start_s':t,'end_s':steps*.002,
                        'average_acceleration_from_qvel_difference':((data.qvel-qvel_before)/.002).tolist()}
                fact=facts(h,tau,response['a_base_ref'][0],ms,steps,tick);physics.append(fact)
                if steps in CHECKPOINT_STEPS and steps!=100: checkpoints.append(fact)
            row['post_control_state']=json_safe(state_values(data))
            if not failure:
                row['control_interval_average_acceleration']={'start_s':t,'end_s':steps*.002,
                    'average_acceleration_from_qvel_difference':((data.qvel-qvel_before)/.02).tolist()}
            if failure: break
    except Exception as exc:
        implementation_error={'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()}
        for entry in controller.solver_ledger[cursor:]:
            solver.append(dict(entry,configuration=configuration,input_id=input_id,tick=len(controls)))
    final=json_safe(state_values(data))
    grid=len(checkpoints)==21 and all(abs(r['time_s']-s*.002)<1e-9 for r,s in zip(checkpoints,CHECKPOINT_STEPS))
    evaluator={'physical_status':'NOT_EVALUATED_INCOMPLETE_WINDOW'}
    begin=perf_counter()
    if grid:
        case=dict(asdict(scenario),scenario_id=input_id,health=.5 if input_id=='S22_H050_POS' else 1.,
            fault_onset_s=.2 if input_id=='S22_H050_POS' else None)
        try: evaluator=evaluate_serialized_trajectory(case=case,trajectory=checkpoints,start_index=0)
        except Exception as exc:
            implementation_error={'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()}
    evaluation_s+=perf_counter()-begin
    physical_failures=Counter(reason for r in physics+[x['physical_at_decision'] for x in controls]
        for reason in r['physical_evaluation']['safety_reasons'])
    complete=steps==1100 and len(controls)==110 and not failure and not implementation_error
    pose_final=final_pose_error(model,data,q_init,d) if not failure else None
    return json_safe({'schema':'STEP22_EPISODE_V1','configuration':configuration,'input_id':input_id,
        'status':'COMPLETED' if complete else 'FAILED','initial_state':initial,'q_init':q_init.tolist(),
        'initial_state_hash':frozen.sha(initial),'p_init_m':p_init,'d_ref_m':d,
        'controls':controls,'physics_trajectory':physics,'checkpoints':checkpoints,'solver_ledger':solver,
        'latency_ledger':latency,'integral_ledger':integral,'evaluator':evaluator,'checkpoint_grid_valid':grid,
        'final_state':final,'final_pose_tracking':pose_final,
        'metrics':task_metrics(controls,final,p_init,d) if not failure else None,
        'physical_failure':bool(physical_failures),'physical_failure_reason_counts':dict(physical_failures),
        'deadline_miss_ticks':sum(x['deadline_miss'] for x in latency),
        'invalid_command_ticks':sum(not x['valid_command'] for x in controls),
        'numerical_failure':failure,'implementation_error':implementation_error,
        'counts':{'physics_steps':steps,'control_decisions':len(controls),'control_qp_calls':len(solver),
            'svd_calls':controller.svd_calls,'passive_model_calls':controller.passive_model_calls,
            'contact_linearization_calls':controller.contact_linearization_calls,
            'initialization_forward_calls':1,'action_conditioned_forward_calls':forward_calls,
            'integration_refresh_forward_calls':refresh_calls,'constraint_diagnostic_calls':diagnostic_calls,
            'constraint_J_transpose_products':products,'post_command_mass_diagnostic_calls':diagnostic_calls,
            'integral_updates':sum(x['updated'] for x in integral),'final_tangent_pose_diagnostic_calls':int(pose_final is not None)},
        'timing':{'control_total_s':sum(x['latency_ms'] for x in latency)/1000,
            'action_conditioned_forward_s':forward_s,'constraint_and_mass_diagnostics_s':diagnostic_s,
            'integration_and_refresh_s':integration_s,'physical_and_independent_evaluation_s':evaluation_s}})
