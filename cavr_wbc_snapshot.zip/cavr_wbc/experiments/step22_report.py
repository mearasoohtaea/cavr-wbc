"""Saved-output STEP22 task, pose, integrator, physics and latency reporting."""
from collections import Counter
from datetime import datetime, timezone
import json
from pathlib import Path
import numpy as np
from cavr_wbc.experiments.step21_report import digest, canonical_hash, csv_write


def engineering_result(rows,config):
    checks={};healthy=[x for x in rows if x['configuration']==config and x['input_id']!='S22_H050_POS']
    for r in healthy:
        i=r['input_id'];ok=r.get('status')=='COMPLETED'
        checks[i+'_physical']=ok and r.get('physical_failure') is False and r.get('physical_window_status')=='PASS'
        checks[i+'_deadline']=ok and r.get('deadline_miss_ticks')==0
        if i=='S22_HEALTHY_ZERO': checks[i+'_drift']=ok and abs(r['final_displacement_m'])<=.0005
        else:
            checks[i+'_raw_sign']=ok and r['final_displacement_m']*r['d_ref_m']>0
            checks[i+'_position']=ok and abs(r['final_position_error_m'])<=.002
            checks[i+'_final_speed']=ok and abs(r['final_velocity_m_s'])<=.001
            checks[i+'_hold_speed_rms']=ok and r['hold_velocity_rms_m_s']<=.001
    return {'pass':len(healthy)==3 and all(checks.values()),'checks':checks}


def report(out):
    root=Path(__file__).resolve().parents[2]
    m=json.loads((out/'PROTOCOL_AND_MANIFEST.json').read_text(encoding='utf-8'))
    history=[json.loads(x) for x in (out/'ATTEMPT_LEDGER.jsonl').read_text().splitlines() if x]
    rows=[];series=[];counts=Counter();states=Counter();statuses=Counter();verified=[]
    for config in m['configuration_order']:
        for inp in m['input_order']:
            i=inp['input_id'];identity=config+':'+i;events=[x for x in history if x['identity']==identity]
            last=events[-1] if events else {'status':'NOT_STARTED'}
            row={'configuration':config,'input_id':i,'d_ref_m':inp['d_m'],'attempt_state':last['status']}
            if 'shard' not in last:
                states[last['status']]+=1;rows.append(row);continue
            payload=json.loads((out/last['shard']).read_text(encoding='utf-8'));r=payload['result']
            if canonical_hash(r)!=payload['result_hash'] or payload['result_hash']!=last['result_hash']: raise ValueError('Shard/DONE hash changed')
            if payload['manifest_hash']!=m['manifest_hash'] or payload['run_id']!=m['run_id']: raise ValueError('Case identity mismatch')
            states[r['status']]+=1;counts.update(r.get('counts',{}));controls=r.get('controls',[])
            statuses.update(str(x.get('status')) for x in r.get('solver_ledger',[]))
            metrics=r.get('metrics') or {}
            row.update(status=r['status'],**{k:v for k,v in metrics.items() if k!='segments'},**r.get('counts',{}),
                physical_failure=r.get('physical_failure'),physical_window_status=r.get('evaluator',{}).get('physical_status'),
                physical_failure_reasons=json.dumps(r.get('physical_failure_reason_counts',{})),
                deadline_miss_ticks=r.get('deadline_miss_ticks'),invalid_command_ticks=r.get('invalid_command_ticks'),
                latency_max_ms=max((x['latency_ms'] for x in controls),default=None))
            for phase,pmetrics in metrics.get('segments',{}).items():
                for k,v in pmetrics.items(): row[phase+'_'+k]=v
                selected=[x for x in controls if (x['time_s']<.2 if phase=='stationary' else .2<=x['time_s']<=1.2 if phase=='motion' else x['time_s']>1.2)]
                if selected:
                    row[phase+'_pose_mae_xyz_m_rotation_rad_json']=json.dumps(np.mean(np.abs([x['e_pose'] for x in selected]),axis=0).tolist())
                    row[phase+'_velocity_mae_xyz_m_s_rotation_rad_s_json']=json.dumps(np.mean(np.abs([x['e_vel'] for x in selected]),axis=0).tolist())
            closure=[];rank=[];condition=[];errors_base=[];errors_joint=[];dynamics=[];legacy=[];contact=[];mass_diff=[];balance=[]
            margins=[];actual_margins=[];physical_bounds=Counter();authority_gate=Counter();actual_gate=Counter();freezes=Counter()
            for x in controls:
                a=x['assembly'];post=x['post_command_forward'];integral=x['integral_record']
                rr=a['contact_reference'];closure.append(rr['closure_residual_inf']);rank.append(rr['rank'])
                if rr['condition_estimate'] is not None: condition.append(rr['condition_estimate'])
                tau=np.asarray(x['tau_total']);applied=np.asarray(x['tau_applied']);limit=np.asarray(a['tau_lim'])
                margins.append(float(limit[1]-abs(tau[1])));actual_margins.append(float(limit[1]-abs(applied[1])))
                for j in np.flatnonzero((limit<=0)|(np.abs(tau)>=limit)): physical_bounds[int(j)]+=1
                for j in np.flatnonzero((limit<=0)|(np.abs(tau)>=.99*limit)): authority_gate[int(j)]+=1
                for j in np.flatnonzero((limit<=0)|(np.abs(applied)>=.99*limit)): actual_gate[int(j)]+=1
                freezes[str(integral.get('freeze_reason'))]+=1
                w=x.get('wbc_validation') or {}
                if 'dynamics_residual_inf' in w: dynamics.append(w['dynamics_residual_inf'])
                if 'legacy_dynamics_residual_inf' in w: legacy.append(w['legacy_dynamics_residual_inf'])
                if 'contact_acceleration_residual_inf' in w: contact.append(w['contact_acceleration_residual_inf'])
                M=np.asarray(a['M']);Mactual=np.asarray(post['M_after_command_forward'])
                mass_diff.append(float(np.max(np.abs(Mactual-M))))
                qacc=np.asarray(post['qacc_after_command_forward'])
                actual_balance=Mactual@qacc+np.asarray(post['qfrc_bias'])-np.asarray(post['qfrc_passive'])-np.asarray(post['qfrc_actuator'])-np.asarray(post['qfrc_constraint'])
                balance.append(float(np.max(np.abs(actual_balance))))
                if .2<=x['time_s']<=1.2 and x['qdd'] is not None:
                    errors_base.append((np.asarray(x['qdd'])[:6]-qacc[:6]).tolist())
                    errors_joint.extend(np.asarray(x['qdd'])[a['mapped_joint_dofs']]-qacc[a['mapped_joint_dofs']])
                series.append({'configuration':config,'input_id':i,'sample_kind':'CONTROL_PRE_STATE','tick':x['tick'],'time_s':x['time_s'],
                    'p_ref_m':x['external_reference']['p_ref_m'],'v_ref_m_s':x['external_reference']['v_ref_m_s'],
                    'a_ref_m_s2':x['external_reference']['a_ref_m_s2'],'p_m':x['measured_p_m'],'v_m_s':x['measured_v_m_s'],
                    'q_reference_json':json.dumps(x['q_reference']),'pose_error_m_rad_json':json.dumps(x['e_pose']),
                    'velocity_error_m_s_rad_s_json':json.dumps(x['e_vel']),
                    'a_base_ref_m_s2_rad_s2_json':json.dumps(x['a_base_ref']),
                    'b_used_m_s2_rad_s2_json':json.dumps(integral['b_used']),'b_after_m_s2_rad_s2_json':json.dumps(integral['b_after']),
                    'integral_updated':integral['updated'],'integral_freeze_reason':integral['freeze_reason'],
                    'qdd_base_x_m_s2':x['qdd'][0] if x['qdd'] is not None else None,'qacc_after_command_base_x_m_s2':qacc[0],
                    'health_fr_thigh':x['health_vector'][1],'tau_total_fr_thigh_nm':tau[1],'tau_applied_fr_thigh_nm':applied[1],
                    'latency_ms':x['latency_ms'],'solver_status':x['solver_status'],'command_source':x['command_source']})
            if r.get('final_pose_tracking'):
                f=r['final_pose_tracking'];ep=f['tangent_pose_error']
                row.update(final_y_offset_m=f['position_offset_xyz_m'][1],final_z_offset_m=f['position_offset_xyz_m'][2],
                    final_orientation_error_rad=f['orientation_error_norm_rad'],
                    final_base_angular_speed_rad_s=float(np.linalg.norm(f['base_angular_velocity_rad_s'])),
                    final_tangent_pose_error_json=json.dumps(ep))
                series.append({'configuration':config,'input_id':i,'sample_kind':'FINAL_STATE_NO_ACTION','time_s':2.2,
                    'p_ref_m':r['p_init_m']+r['d_ref_m'],'v_ref_m_s':0.,'p_m':r['final_state']['qpos'][0],
                    'v_m_s':r['final_state']['qvel'][0],'pose_error_m_rad_json':json.dumps(ep)})
            pose=np.asarray([x['e_pose'] for x in controls]);vv=np.asarray([x['physical_at_decision']['qvel'][:6] for x in controls])
            b=np.asarray([x['b_used'] for x in r.get('integral_ledger',[])])
            row.update(reference_closure_max_m_s2=max(closure,default=None),reference_rank_min=min(rank,default=None),
                reference_condition_max=max(condition,default=None),
                motion_qp_actual_base_acceleration_rms_error_json=json.dumps(np.sqrt(np.mean(np.square(errors_base),axis=0)).tolist()) if errors_base else None,
                motion_qp_actual_joint_acceleration_rms_error_rad_s2=float(np.sqrt(np.mean(np.square(errors_joint)))) if errors_joint else None,
                effective_dynamics_residual_inf_max=max(dynamics,default=None),legacy_dynamics_residual_inf_max=max(legacy,default=None),
                qp_contact_acceleration_residual_max_m_s2=max(contact,default=None),
                pre_post_command_mass_difference_inf_max=max(mass_diff,default=None),
                recorded_actual_force_balance_remainder_inf_max=max(balance,default=None),
                min_fr_thigh_command_margin_nm=min(margins,default=None),min_fr_thigh_applied_margin_nm=min(actual_margins,default=None),
                physical_torque_bound_counts_json=json.dumps(dict(physical_bounds),sort_keys=True),
                authority_99pct_counts_json=json.dumps(dict(authority_gate),sort_keys=True),
                applied_torque_99pct_counts_json=json.dumps(dict(actual_gate),sort_keys=True),
                integral_reason_counts_json=json.dumps(dict(freezes),sort_keys=True),
                max_abs_integral_bias_per_axis_json=json.dumps(np.max(np.abs(b),axis=0).tolist()) if len(b) else None,
                max_abs_y_offset_m=float(np.max(np.abs(pose[:,1]))) if len(pose) else None,
                max_abs_z_offset_m=float(np.max(np.abs(pose[:,2]))) if len(pose) else None,
                max_orientation_error_norm_rad=float(np.max(np.linalg.norm(pose[:,3:],axis=1))) if len(pose) else None,
                max_base_angular_speed_rad_s=float(np.max(np.linalg.norm(vv[:,3:],axis=1))) if len(vv) else None)
            checked={'identity':identity,'case_hash_matches':True,'initial_hash_matches':r.get('initial_state_hash')==m['initial']['state_hash'],
                'control_decisions':len(controls),'physics_steps':len(r.get('physics_trajectory',[])),
                'solver_ledger_calls':len(r.get('solver_ledger',[])),'independent_points':len(r.get('evaluator',{}).get('checkpoints',[])),
                'checkpoint_grid_valid':r.get('checkpoint_grid_valid')}
            if r['status']=='COMPLETED':
                if (checked['control_decisions'],checked['physics_steps'],checked['solver_ledger_calls'],checked['independent_points'])!=(110,1100,110,21): raise ValueError('Completed case sizes incorrect')
                if not checked['initial_hash_matches'] or not checked['checkpoint_grid_valid']: raise ValueError('Initial or grid mismatch')
                if abs(r['final_state']['time_s']-2.2)>1e-9: raise ValueError('Final time mismatch')
                for k,x in enumerate(controls):
                    h=np.ones(12)
                    if i=='S22_H050_POS' and k>=10: h[1]=.5
                    if not np.array_equal(x['health_vector'],h): raise ValueError('Fault timing/mask mismatch')
                    a=x['assembly'];post=x['post_command_forward']
                    if any(a['g_loss_pred']): raise ValueError('Dry friction prediction was not disabled')
                    if not np.array_equal(x['tau_cmd'],x['tau_total']): raise ValueError('Postsolve torque increment')
                    if abs(post['time_s']-x['time_s'])>1e-9: raise ValueError('Post-command timestamp mismatch')
                    if k and x['integral_record']['b_used']!=controls[k-1]['integral_record']['b_after']: raise ValueError('Integral update order mismatch')
                    if x['q_reference'][1:7]!=r['q_init'][1:7]: raise ValueError('y/z/orientation reference moved')
                    if any(post['qfrc_applied']) or any(v for rr in post['xfrc_applied'] for v in rr): raise ValueError('External force nonzero')
            verified.append(checked);rows.append(row)
    for config in m['configuration_order']:
        zero=next(r for r in rows if r['configuration']==config and r['input_id']=='S22_HEALTHY_ZERO').get('final_displacement_m')
        for r in (x for x in rows if x['configuration']==config):
            r['same_configuration_zero_displacement_m']=zero
            r['drift_adjusted_final_displacement_m']=r['final_displacement_m']-zero if zero is not None and r.get('final_displacement_m') is not None else None
    engineering={c:engineering_result(rows,c) for c in m['configuration_order']}
    ready=[c for c,v in engineering.items() if v['pass']]
    csv_write(out/'CASE_RESULTS.csv',rows);csv_write(out/'TASK_TIMESERIES.csv',series)
    changed={p:digest(root/p) for p,h in m['source_sha256'].items() if digest(root/p)!=h}
    docs_changed={p:digest(Path(m['source_step21_output'])/p) for p,h in m['source_step21_documents_sha256'].items() if digest(Path(m['source_step21_output'])/p)!=h}
    if changed or docs_changed: raise ValueError('Frozen source/old STEP21 document changed')
    attempts=sum(x['status']=='START' for x in history)
    if attempts>8 or counts['control_qp_calls']>880 or counts['physics_steps']>8800: raise ValueError('STEP22 budget exceeded')
    summary={'schema':'STEP22_EXECUTION_SUMMARY_V1','run_id':m['run_id'],'checked_at_utc':datetime.now(timezone.utc).isoformat(),
        'real_episode_attempts':attempts,'states':dict(states),'fixed_batch_completed':states['COMPLETED']==8,
        'counts':dict(counts),'solver_status_counts':dict(statuses),'engineering_criteria_by_configuration':engineering,
        'configurations_meeting_engineering_criteria':ready,'common_task_execution_ready':bool(ready),
        'source_sha256':m['source_sha256'],'frozen_source_changed':changed,'old_STEP21_documents_changed':docs_changed,
        'numerical_retries':0,'git_status':'SOURCE_AND_ARTIFACTS_SAVED_PENDING_SCOPED_COMMIT',
        'saved_evidence_checks':verified,'new_report_solver_calls':0,'new_report_physics_steps':0,
        'formal_panel_expansion':False,'E3_authorized':False,'RL_or_hardware_authorized':False}
    diagnostics={'schema':'STEP22_SAVED_DIAGNOSTICS_V1','cases':rows,'engineering':engineering,'counts':dict(counts),
        'time_points_are_not_independent_replicates':True,'actual_force_balance_remainder_retained':True}
    (out/'RESPONSE_DIAGNOSTICS.json').write_text(json.dumps(diagnostics,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    def fmt(r,k,scale=1.):
        v=r.get(k);return 'NA' if v is None else f'{v*scale:.6f}'
    lines=['# STEP22 完整基座位姿伺服与停止能力','', '## Material Passport','',
        'experiment-agent／run；2026-10-07（Asia/Seoul）；固定8条真实模拟、必要纯测试与保存数据描述；无独立随机重复。','',
        '## 结果与固定工程判据','',
        f"固定批次完成 {states['COMPLETED']}/8；实际attempt {attempts}；控制QP {counts['control_qp_calls']}；正式积分 {counts['physics_steps']}。",
        '各配置冻结工程判据：'+', '.join(c+(' = PASS' if engineering[c]['pass'] else ' = NOT_MET') for c in m['configuration_order'])+'。','',
        '| 配置 | 输入 | raw位移 mm | drift-adjusted mm | raw末误差 mm | 末速度 mm/s | hold RMS mm/s | 物理 | >20ms |',
        '|---|---|---:|---:|---:|---:|---:|---|---:|']
    for r in rows:
        lines.append('| '+' | '.join([r['configuration'],r['input_id'],fmt(r,'final_displacement_m',1000),fmt(r,'drift_adjusted_final_displacement_m',1000),
            fmt(r,'final_position_error_m',1000),fmt(r,'final_velocity_m_s',1000),fmt(r,'hold_velocity_rms_m_s',1000),
            str(r.get('physical_window_status','NA')),str(r.get('deadline_miss_ticks','NA'))])+' |')
    lines+=['','工程判据沿用STEP21：双向正确raw符号，末位置误差≤2 mm、末速度/hold RMS≤1 mm/s，ZERO漂移≤0.5 mm，三个健康输入满足旧物理与20 ms。'
        'drift-adjusted按同配置健康ZERO末位移作差；判据使用raw值。静止/运动/hold分段p/v MAE全部保留在CASE_RESULTS.csv。','',
        '## 全位姿与停止闭环','',
        'ω=8 s⁻¹：PD Kp/Kd=64/16，PID Kp/Kd/Ki=192/24/512。全部六个基座通道应用一次伺服，y/z与四元数保持reset初值。'
        '姿态误差使用[mj_differentiatePos](https://mujoco.readthedocs.io/en/stable/APIreference/APIfunctions.html#mj-differentiatepos) current→reference、dt=1构造广义切空间位移，前三项m、后三项rad。'
        '角速度通道与free-joint广义qvel一致；参考其余关节取当前位置。理想线性极点设计不等于受约束plant稳定性证明。',
        'PID当前tick使用b_k，单次QP选命令后，只有有效/有限且所有actuator均低于当前能力99%时更新b。零容量单独视为饱和；任一饱和冻结全部6维。'
        'b各轴限幅±1加速度单位。积分、冻结原因及更新前后值逐tick持久化。','',
        '| 配置 | 输入 | 末y偏移 mm | 末z偏移 mm | 末姿态误差 rad | 最大姿态误差 rad | 末角速度 rad/s |',
        '|---|---|---:|---:|---:|---:|---:|']
    for r in rows:
        lines.append('| '+' | '.join([r['configuration'],r['input_id'],fmt(r,'final_y_offset_m',1000),fmt(r,'final_z_offset_m',1000),
            fmt(r,'final_orientation_error_rad'),fmt(r,'max_orientation_error_norm_rad'),fmt(r,'final_base_angular_speed_rad_s')])+' |')
    lines+=['','这些六通道跟踪量是预设描述指标，未增设事后通过门槛。物理高度继续用subtree_com，世界基座位置不改称whole-robot CoM。','',
        '## 接触参考、动力学与实际plant','',
        '同一tick的Jc/Jdot*v和实际actuator→DOF映射用于固定SVD，cutoff=1e−10。未闭合残差、奇异值/rank/condition逐tick保存。'
        'QP动力学采用qfrc_bias−qfrc_passive，g_loss_pred=0，只有QP内部健康限幅后的tau_total，无解后补偿。'
        'joint-bound预测时长由0.002改为真实命令保持0.020 s，joint range、margin与其他QP权重/正则/solver预算均保留。',
        '命令后同状态qacc与QP qdd的6通道RMS误差、接触/摩擦按实际constraint type得到的广义力、力平衡余项均保存。'
        '瞬时qacc与0.002/0.02秒速度差分分列。真实foot condim/friction保持compiled值，QP点力与真实接触模型仍有差异，不能把力分组RMS相加作独立因果贡献。','',
        '## 实时性、健康与积分','',
        '| 配置 | 最大控制时延 ms | 超deadline tick | H050最小命令余量 N·m | H050实际余量 N·m |',
        '|---|---:|---:|---:|---:|']
    for config in m['configuration_order']:
        rr=[r for r in rows if r['configuration']==config];h=next(r for r in rr if r['input_id']=='S22_H050_POS')
        lines.append(f"| {config} | {max((r.get('latency_max_ms') or 0 for r in rr)):.6f} | {sum(r.get('deadline_miss_ticks') or 0 for r in rr)} | {fmt(h,'min_fr_thigh_command_margin_nm')} | {fmt(h,'min_fr_thigh_applied_margin_nm')} |")
    lines+=['','H050力矩物理bound计数、99% authority门计数、实际力矩门计数在结果表，逐actuator记录，不能把未激发健康边界解释为收益。'
        '端到端计时含六通道伺服、积分管理、SVD、QP及命令选择；诊断forward、物理评价、积分与写出另外计时。',
        '冻结工程判据逐项：`'+json.dumps(engineering,ensure_ascii=False,sort_keys=True)+'`。',
        '求解原始状态：`'+json.dumps(dict(statuses),sort_keys=True)+'`。',
        '调用分类：`'+json.dumps(dict(counts),sort_keys=True)+'`。','',
        '## 共同载体判断','',
        ('满足冻结任务工程判据的配置：'+', '.join(ready)+'。可据本批预定义开发对照选择共同载体。' if ready else
         'PD/PID均尚未满足冻结任务工程判据，具体失败项完整列出；当前结果用于定位位姿保持、方向或停止链路的剩余问题。'),
        '跨STEP21与STEP22有全位姿、增益、损耗及joint-bound等共同修改，跨批差异不唯一归因于增益。'
        '下一项方法工作为nominal→feedback-backup prediction→接受/切换及激发健康约束的挑战；本轮只完成这8条，未执行下一项方法。'
        '本批无显著性、非劣/等效检验，tick不作独立样本，不宣称H2成立或未来预测P1实时性已验证。','',
        '## 交付文件','',
        'PROTOCOL_AND_MANIFEST.json、CASE_RESULTS.csv、TASK_TIMESERIES.csv、cases/*/STEP22_CASE_SHARD.json、'
        'ATTEMPT_LEDGER.jsonl、RESPONSE_DIAGNOSTICS.json、TEST_RESULTS.json、EXECUTION_SUMMARY.json。','',
        '```ini',f"STEP22_FIXED_BATCH = {'COMPLETED_8_OF_8' if states['COMPLETED']==8 else 'INCOMPLETE'}"]
    lines+=[c+' = '+('PASS' if engineering[c]['pass'] else 'NOT_MET') for c in m['configuration_order']]
    lines += [f'REAL_EPISODE_ATTEMPTS = {attempts}',f"CONTROL_QP_CALLS = {counts['control_qp_calls']}",
        f"FORMAL_PHYSICS_STEPS = {counts['physics_steps']}",'JOINT_BOUND_COMMAND_HORIZON_S = 0.020',
        'FULL_AMPLITUDE_DRY_FRICTION_FEEDFORWARD = DISABLED','NUMERICAL_RETRIES = 0','PARAMETER_SEARCH = FALSE',
        'HISTORICAL_RESULTS_UNCHANGED = TRUE','FORMAL_PANEL_EXPANSION = FALSE','E3 = NOT_AUTHORIZED','RL_OR_HARDWARE = NOT_AUTHORIZED','```','']
    gd_path=out/'GIT_DELIVERY.json'
    if gd_path.exists():
        gd=json.loads(gd_path.read_text());summary['git_status']=gd['status'];summary['git_delivery']=gd
        lines+=['Git交付状态：`'+gd['status']+'`；核心提交：`'+gd['core_commit']+'`；分支：`'+gd['branch']+'`。'
            '使用E盘隔离索引，原工作树HEAD未reset。']
    (out/'TASK_RESPONSE_REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
    summary['artifact_sha256']={str(p.relative_to(out)):digest(p) for p in out.rglob('*') if p.is_file() and p.name!='EXECUTION_SUMMARY.json'}
    (out/'EXECUTION_SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'completed':states['COMPLETED'],'attempts':attempts,'counts':dict(counts),
        'engineering_pass_configurations':ready,'engineering':engineering,'solver_statuses':dict(statuses)},ensure_ascii=False),flush=True)
