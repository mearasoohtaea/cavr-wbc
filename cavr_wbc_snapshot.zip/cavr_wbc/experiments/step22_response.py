"""STEP22 fixed full-pose PD/PID batch; no retry of reserved combinations."""
import argparse
from collections import Counter
from dataclasses import asdict
import gc
import json
import os
from pathlib import Path
import sys
from time import perf_counter
import traceback
import mujoco
import numpy as np

from cavr_wbc.control.step22_pose_servo import CONFIGURATIONS, Step22WBC, specification
from cavr_wbc.experiments import step17_formal_panel as frozen
from cavr_wbc.experiments.step04_e2b import Scenario
from cavr_wbc.experiments.step20_episode import initial_state_facts
from cavr_wbc.experiments.step21_response import digest, utc, write_json, append
from cavr_wbc.experiments.step22_episode import run_episode

ROOT=Path(__file__).resolve().parents[2]
PROTOCOL=Path('E:/CAVR-WBC/experiment_handoff_20260921/NEXT_CODEX_INSTRUCTIONS_STEP22_FULL_POSE_SERVO_20261007.md')
OLD_OUT=ROOT/'artifacts/step21_contact_response_20261007/step21-contact-response-20261007-01'
INPUTS=(('S22_HEALTHY_ZERO',0.),('S22_HEALTHY_POS',.01),('S22_HEALTHY_NEG',-.01),('S22_H050_POS',.01))
NEW_SOURCE=('cavr_wbc/control/step22_pose_servo.py','cavr_wbc/experiments/step22_episode.py',
    'cavr_wbc/experiments/step22_response.py','cavr_wbc/experiments/step22_report.py',
    'tests/test_step22_pose_servo.py','tests/test_step22_response.py')
ENGINEERING_CRITERIA={'healthy_directions_correct_raw_sign':True,
    'healthy_directions_raw_final_position_error_abs_max_m':.002,
    'healthy_directions_final_velocity_abs_max_m_s':.001,
    'healthy_directions_hold_velocity_rms_max_m_s':.001,
    'healthy_zero_raw_final_displacement_abs_max_m':.0005,
    'healthy_zero_pos_neg_physical_failures_max':0,'healthy_zero_pos_neg_deadline_misses_max':0}


def freeze(out,run_id):
    old=json.loads((OLD_OUT/'PROTOCOL_AND_MANIFEST.json').read_text(encoding='utf-8'))
    legacy={p:digest(ROOT/p) for p in old['source_sha256']}
    if legacy!=old['source_sha256']: raise ValueError('Inherited directly frozen source differs')
    scenario=Scenario(**old['selected_source_scenario']);initial=initial_state_facts(scenario)
    if initial['state_hash']!=old['initial']['state_hash']: raise ValueError('Initial state differs from STEP21')
    model=frozen.load_model();controller=Step22WBC(model)
    docs={p:digest(OLD_OUT/p) for p in ('PROTOCOL_AND_MANIFEST.json','TASK_RESPONSE_REPORT.md','EXECUTION_SUMMARY.json')}
    manifest={'schema':'STEP22_PROTOCOL_V1','run_id':run_id,'frozen_at_utc':utc(),
        'client_date':'2026-10-07','client_timezone':'Asia/Seoul','protocol':str(PROTOCOL),'protocol_sha256':digest(PROTOCOL),
        'source_commit':'5ff00b3ef7cd3c317a005fe33346b04763c422e8','source_step21_output':str(OLD_OUT),
        'source_step21_documents_sha256':docs,'decision_document':str(PROTOCOL.parent/'STEP21_INTERPRETATION_AND_STEP22_DECISION_20261007.md'),
        'selected_source_scenario':asdict(scenario),'initial':initial,'q_init':initial['state']['qpos'],
        'input_order':[{'input_id':i,'d_m':d,'fault_onset_s':.2 if i=='S22_H050_POS' else None,
            'health_after_onset':.5 if i=='S22_H050_POS' else 1.,'fault_actuator_mask':[1]} for i,d in INPUTS],
        'configuration_order':list(CONFIGURATIONS),'dispatch_order':'PD then PID; ZERO,POS,NEG,H050 within each',
        'servo_design':specification(),'wbc_config':asdict(controller.cfg),
        'joint_bound_revision':{'old_wbc_dt_s':old['wbc_config']['wbc_dt'],'new_wbc_dt_s':.02,
            'reason':'actual command hold duration; unchanged joint range and margin'},
        'compiled_mapping_and_losses':controller.mapping_info,'compiled_dof_armature':model.dof_armature.tolist(),
        'compiled_foot_properties':[{'geom_id':int(g),'name':mujoco.mj_id2name(model,mujoco.mjtObj.mjOBJ_GEOM,g),
            'condim':int(model.geom_condim[g]),'friction':model.geom_friction[g].tolist()} for g in controller._foot_geom_ids],
        'pose_error_definition':'mj_differentiatePos(current,q_reference,dt=1); six generalized tangent displacement components',
        'pose_error_units':['m','m','m','rad','rad','rad'],
        'velocity_error_units':['m/s','m/s','m/s','rad/s','rad/s','rad/s'],
        'references':'fixed q_init y/z/quaternion; scalar quintic x; current joint positions in q_reference',
        'world_base_not_whole_robot_com':True,'dynamics':'M*qdd+(qfrc_bias-qfrc_passive)=B*tau_total+Jc.T*lambda',
        'g_loss_pred':'all zero; full-amplitude dry friction prediction disabled','post_solve_torque_increment':False,
        'relative_svd_rank_cutoff':1e-10,'external_generalized_force':'all zero','external_body_wrenches':'all zero',
        'episode_duration_s':2.2,'physics_dt_s':.002,'control_dt_s':.02,'physics_steps_per_case':1100,
        'control_decisions_per_case':110,'checkpoint_times_s':[.2+j*.05 for j in range(21)],
        'max_real_episode_attempts':8,'max_control_qp_calls':880,'max_formal_physics_steps':8800,
        'deadline_ms':20.,'wall_timeout_s':1800,'numerical_retries':0,'engineering_criteria':ENGINEERING_CRITERIA,
        'independent_evaluator_config':old['independent_evaluator_config'],
        'physical_task_limits':old['physical_task_limits'],'physical_terminal_limits':old['physical_terminal_limits'],
        'model_files_sha256':old['model_files_sha256'],
        'source_sha256':{**legacy,**{p:digest(ROOT/p) for p in NEW_SOURCE}},
        'response_metrics_definitions':{'segments':'stationary t<.2; motion .2<=t<=1.2; hold t>1.2 control-pre samples',
            'drift_adjusted_displacement':'raw final displacement minus same-configuration healthy ZERO raw displacement',
            'raw_criteria':'same STEP21 x/stop/physical/deadline criteria, applied independently to PD and PID',
            'six_axis_tracking':'per-axis tangent pose/velocity MAE; y/z offset, orientation error and angular velocity descriptive only',
            'instantaneous_vs_interval_accel':'post-command same-state qacc separately from .002/.02 velocity differences'},
        'python':sys.executable,'python_version':sys.version,'mujoco_version':mujoco.__version__,'numpy_version':np.__version__,
        'native_osqp_dll':os.environ.get('CAVR_WBC_NATIVE_OSQP_DLL'),'TEMP':os.environ.get('TEMP'),'TMP':os.environ.get('TMP'),
        'formal_panel_expansion':False,'E3_authorized':False,'RL_or_hardware_authorized':False}
    for p,h in manifest['model_files_sha256'].items():
        if digest(ROOT/p)!=h: raise ValueError('Frozen model changed')
    manifest['manifest_hash']=frozen.sha(manifest);write_json(out/'PROTOCOL_AND_MANIFEST.json',manifest)
    return scenario,manifest


def execute_case(out,manifest,scenario,input_id,d,configuration,episode_fn=run_episode):
    ledger=out/'ATTEMPT_LEDGER.jsonl';identity=configuration+':'+input_id
    history=[json.loads(x) for x in ledger.read_text().splitlines() if x] if ledger.exists() else []
    if sum(x['status']=='START' for x in history)>=8 or any(x['identity']==identity for x in history):
        raise RuntimeError('Reserved combination or eight-attempt bound; numerical retry refused')
    shard=out/'cases'/f'{configuration}__{input_id}'/'STEP22_CASE_SHARD.json'
    if shard.exists(): raise RuntimeError('Existing shard cannot be overwritten')
    start={'identity':identity,'status':'START','run_id':manifest['run_id'],'manifest_hash':manifest['manifest_hash'],
        'timestamp_utc':utc(),'pid':os.getpid()}
    append(ledger,start);print(json.dumps(start),flush=True)
    try: result=episode_fn(scenario,input_id,d,configuration,manifest['initial']['state_hash'])
    except Exception as exc:
        result={'status':'FAILED','configuration':configuration,'input_id':input_id,'solver_ledger':[],'counts':{},
            'unknown_call_count':True,'implementation_error':{'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()}}
    payload={'schema':'STEP22_CASE_SHARD_V1','run_id':manifest['run_id'],'manifest_hash':manifest['manifest_hash'],
        'identity':identity,'result':result,'result_hash':frozen.sha(result)}
    begin=perf_counter()
    for write_attempt in range(2):
        try:
            write_json(shard,payload);checked=json.loads(shard.read_text(encoding='utf-8'))
            if frozen.sha(checked['result'])!=payload['result_hash']: raise RuntimeError('Shard readback mismatch')
            break
        except OSError:
            if write_attempt:
                append(ledger,{**start,'status':'UNKNOWN','timestamp_utc':utc(),'reason':'Output unavailable; no numerical rerun'})
                raise
    done={**start,'status':'DONE' if result['status']=='COMPLETED' else 'FAILED','timestamp_utc':utc(),
        'shard':str(shard.relative_to(out)),'result_hash':payload['result_hash'],'counts':result.get('counts',{}),
        'write_and_readback_s':perf_counter()-begin}
    append(ledger,done);print(json.dumps(done),flush=True)
    return result


def run(out,run_id):
    out=out.resolve();allowed=(ROOT/'artifacts/step22_full_pose_response_20261007').resolve()
    if allowed not in out.parents: raise ValueError('Output must be unique STEP22 child directory')
    out.mkdir(parents=True,exist_ok=True)
    if (out/'PROTOCOL_AND_MANIFEST.json').exists() or (out/'ATTEMPT_LEDGER.jsonl').exists():
        raise RuntimeError('Existing batch cannot restart')
    begin=perf_counter();scenario,manifest=freeze(out,run_id)
    write_json(out/'RUN_STARTED.json',{'run_id':run_id,'pid':os.getpid(),'timestamp_utc':utc(),
        'command':sys.argv,'cwd':str(ROOT),'timeout_s':1800})
    counts=Counter();states=Counter();stop=None
    try:
        for config in CONFIGURATIONS:
            for input_id,d in INPUTS:
                if perf_counter()-begin>=1800: stop='WALL_TIMEOUT';break
                result=execute_case(out,manifest,scenario,input_id,d,config)
                counts.update(result.get('counts',{}));states[result['status']]+=1
                write_json(out/'PROGRESS.json',{'run_id':run_id,'updated_utc':utc(),'last_identity':config+':'+input_id,
                    'states':dict(states),'counts':dict(counts),'max_attempts':8})
                if counts['control_qp_calls']>880 or counts['physics_steps']>8800: stop='IMPLEMENTATION_BUDGET_ERROR'
                elif result.get('implementation_error'): stop='IMPLEMENTATION_ERROR'
                del result;gc.collect()
                if stop: break
            if stop: break
    except BaseException as exc:
        write_json(out/'INTERRUPTION.json',{'run_id':run_id,'timestamp_utc':utc(),
            'type':type(exc).__name__,'message':str(exc),'counts':dict(counts)})
        raise
    write_json(out/'RUN_FINISHED.json',{'run_id':run_id,'timestamp_utc':utc(),'pid':os.getpid(),
        'status':'FIXED_BATCH_DISPATCH_COMPLETED' if stop is None else stop,'counts':dict(counts),
        'states':dict(states),'elapsed_wall_s':perf_counter()-begin})
    from cavr_wbc.experiments.step22_report import report
    report(out)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--run-id')
    p.add_argument('--summarize',action='store_true');args=p.parse_args()
    if args.summarize:
        from cavr_wbc.experiments.step22_report import report
        report(args.output.resolve())
    else:
        if not args.run_id: p.error('--run-id required')
        run(args.output,args.run_id)
