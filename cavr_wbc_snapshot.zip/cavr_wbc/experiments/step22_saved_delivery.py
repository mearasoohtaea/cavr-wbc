"""Saved STEP22 delivery interpretation/validation; no simulator or controller."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import csv
import hashlib
import json
import math
from pathlib import Path


def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1048576),b''): h.update(chunk)
    return h.hexdigest()


def fonts(out):
    from pypdf import PdfReader
    records=[]
    for p in sorted((out/'figures').glob('*.pdf')):
        reader=PdfReader(p);checked=[]
        for page in reader.pages:
            for name,obj in page['/Resources']['/Font'].items():
                font=obj.get_object();nodes=[font]
                if font.get('/DescendantFonts'): nodes += [x.get_object() for x in font['/DescendantFonts']]
                desc=[n['/FontDescriptor'].get_object() for n in nodes if n.get('/FontDescriptor')]
                embedded=any(any(k in d for k in ('/FontFile','/FontFile2','/FontFile3')) for d in desc)
                if any(n.get('/Subtype')=='/Type3' for n in nodes) or not embedded:
                    raise ValueError('Unembedded or Type3 figure font')
                checked.append({'name':str(font.get('/BaseFont')),'embedded':embedded,
                    'font_types':[str(n.get('/Subtype')) for n in nodes]})
        records.append({'figure':p.name,'fonts':checked,'width_in':float(reader.pages[0].mediabox.width)/72,
            'height_in':float(reader.pages[0].mediabox.height)/72})
    if len(records)!=2: raise ValueError('Expected two figure PDFs')
    (out/'FIGURE_FONT_VERIFICATION.json').write_text(json.dumps({'status':'PASS','figures':records,
        'note':'scipilot file checker warned on Type0 parent; actual descendant FontDescriptor/FontFile2 checked directly',
        'new_solver_or_integration_calls':0},indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'font_embedding':'PASS','figure_pdfs':len(records)}))


def finalize(out):
    root=Path(__file__).resolve().parents[2]
    m=json.loads((out/'PROTOCOL_AND_MANIFEST.json').read_text(encoding='utf-8'))
    s=json.loads((out/'EXECUTION_SUMMARY.json').read_text(encoding='utf-8'))
    history=[json.loads(x) for x in (out/'ATTEMPT_LEDGER.jsonl').read_text().splitlines() if x]
    identities=[c+':'+i['input_id'] for c in m['configuration_order'] for i in m['input_order']]
    if len(history)!=16 or any([x['status'] for x in history if x['identity']==i]!=['START','DONE'] for i in identities):
        raise ValueError('Expected exactly one START/DONE for each fixed combination')
    for p,h in {**m['source_sha256'],**m['model_files_sha256']}.items():
        if digest(root/p)!=h: raise ValueError('Frozen source/model changed')
    if digest(Path(m['protocol']))!=m['protocol_sha256']: raise ValueError('Protocol changed')
    cases=[];count=Counter();statuses=Counter()
    for event in (x for x in history if x['status']=='DONE'):
        payload=json.loads((out/event['shard']).read_text(encoding='utf-8'));r=payload['result']
        canonical=json.dumps(r,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
        if hashlib.sha256(canonical).hexdigest()!=event['result_hash'] or payload['result_hash']!=event['result_hash']:
            raise ValueError('Raw case evidence changed')
        if r['initial_state_hash']!=m['initial']['state_hash'] or r['q_init']!=m['q_init']: raise ValueError('Initial identity changed')
        if (len(r['controls']),len(r['physics_trajectory']),len(r['solver_ledger']),len(r['checkpoints']),len(r['evaluator']['checkpoints']))!=(110,1100,110,21,21):
            raise ValueError('Complete case lengths mismatch')
        if r['counts']!=event['counts'] or abs(r['final_state']['time_s']-2.2)>1e-9: raise ValueError('Ledger counts or terminal time mismatch')
        if [x['physics_step'] for x in r['checkpoints']]!=list(range(100,601,25)): raise ValueError('Independent grid changed')
        gains=m['servo_design']['gains'][r['configuration']];clamps=[0]*6;freeze=Counter();updates=0;previous=[0.]*6
        for tick,x in enumerate(r['controls']):
            ir=x['integral_record'];before=ir['b_before'];after=ir['b_after'];used=ir['b_used'];e=x['e_pose'];limit=x['assembly']['tau_lim'];tau=x['tau_total']
            if used!=previous or before!=previous: raise ValueError('Integral state sequence changed')
            if x['q_reference'][1:7]!=r['q_init'][1:7] or x['q_reference'][7:]!=x['physical_at_decision']['qpos'][7:]:
                raise ValueError('Pose reference/current-joint contract changed')
            if x['assembly']['joint_bound_command_horizon_s']!=.02 or any(x['assembly']['g_loss_pred']): raise ValueError('Joint horizon/loss contract changed')
            expected_a=[ff+gains['kp_s_inv2']*ep+gains['kd_s_inv']*ev+b for ff,ep,ev,b in zip(x['a_feedforward'],e,x['e_vel'],used)]
            if max(abs(a-b) for a,b in zip(expected_a,x['a_base_ref']))>1e-12: raise ValueError('Six-channel servo formula changed')
            saturation=[j for j,v in enumerate(limit) if v<=0 or abs(tau[j])>=.99*v]
            if ir['authority_gate_saturated_actuators']!=saturation: raise ValueError('Authority gate log mismatch')
            enabled=r['configuration']=='S22_POSE_PID'
            update=enabled and x['valid_command'] and not saturation
            if bool(ir['updated'])!=bool(update): raise ValueError('Integral update gate mismatch')
            candidate=[b+.02*gains['ki_s_inv3']*ep for b,ep in zip(before,e)]
            expected=[max(-1.,min(1.,v)) for v in candidate] if update else before if enabled else [0.]*6
            if max(abs(a-b) for a,b in zip(after,expected))>1e-12: raise ValueError('Integral update/clamp mismatch')
            if update:
                updates+=1
                clamps=[n+int(abs(v)>1.) for n,v in zip(clamps,candidate)]
            freeze[str(ir['freeze_reason'])]+=1;previous=after
        count.update(r['counts']);statuses.update(str(x['status']) for x in r['solver_ledger'])
        cases.append({'identity':event['identity'],'case_hash_matches':True,'initial_state_matches':True,
            'controls':110,'solver_calls':110,'physics_steps':1100,'independent_points':21,
            'integral_formula_order_gate_and_limits_verified':True,'integral_updates':updates,
            'integral_unclipped_candidate_exceeds_bound_counts_per_axis':clamps,'integral_reason_counts':dict(freeze)})
    if count['control_qp_calls']!=880 or count['physics_steps']!=8800: raise ValueError('Fixed batch budget mismatch')
    result={'schema':'STEP22_FINAL_SAVED_EVIDENCE_CHECK_V1','status':'PASS','checked_at_utc':datetime.now(timezone.utc).isoformat(),
        'attempts':8,'ledger_events':16,'missing_failed_unknown':0,'cases':cases,'counts':dict(count),
        'frozen_source_and_model_unchanged':True,'new_episode_or_control_QP_or_integration_calls':0,
        'scientific_engineering_criteria_pass':s['common_task_execution_ready'],
        'command':'python -B -X utf8 -m cavr_wbc.experiments.step22_saved_delivery --output '+str(out)+' --stage finalize'}
    (out/'FINAL_VERIFICATION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    lines=['','## PD与PID的实际效果及剩余问题','',
        '两种全位姿配置的ZERO raw漂移均满足0.5 mm：PD为+0.438298 mm、PID为−0.223383 mm。'
        '两者都建立了正负方向响应；相较此前KF的漂移/方向问题，共同闭环载体已经向前推进。跨批共同修改较多，不能将变化唯一归因于某个增益。',
        'PD正/负raw末位移为+4.012912/−4.362682 mm，末位置误差−5.987088/+5.637318 mm超出2 mm，末速度1.146318/−1.035169 mm/s和hold RMS 1.429022/1.467249 mm/s也未通过。',
        'PID正/负raw末位移+10.628194/−10.941885 mm，末位置误差+0.628194/−0.941885 mm、末速度+0.095304/−0.264053 mm/s均通过。'
        'PID只在两方向hold RMS 1.383259/1.480623 mm/s上未达到1 mm/s。参考进入保持段后仍有速度衰减过程，末态已慢下来不等于整个保持段都满足RMS。',
        'PID正/负末y偏移−0.011317/−0.006252 mm，末z偏移−0.076614/−0.308966 mm；姿态误差范数0.000213/0.005120 rad。'
        '完整六通道记录显示位姿反馈确实工作，但仍存在轴间差异；这些跟踪量未用作新通过阈值。',
        'PID的440个tick均按有效且未触发99% actuator门的规则更新。旋转y积分偏置出现±1 rad/s²裁剪，裁剪计数与逐tick候选/更新验证在FINAL_VERIFICATION.json。'
        '积分界裁剪与actuator饱和冻结是两种不同记录；这里没有把接触摩擦用作冻结门。',
        '健康0.5正向与同配置健康正向任务结果一致，FR_thigh最小命令余量PD/PID为10.688931/10.680809 N·m；物理bound及99%门计数均0。'
        '本输入仍未激发健康边界，不提供健康收益结论。',
        'QP与命令后实际加速度仍有明显差异（运动段x RMS：PD正/负0.404105/0.396743 m/s²，PID0.420662/0.429568 m/s²）。'
        '命令前后记录的M逐值一致，记录的真实力平衡余项仍保留；真实干摩擦与condim=6接触反作用不能由仅有点力的QP完全重建。'
        '这些数据描述模型/plant差异，不把相互相关的力分量RMS相加成独立因果解释。','',
        '## 全输入响应图与积分图','',
        '使用scipilot-figure-skill：从880条控制前时序做数据剖析，绘制全部4输入×2配置。每组合n=1 episode，时间点不是独立重复，图中无统计误差带。'
        '响应图含独立2.2 s终态；b_k曲线只到最后控制tick 2.18 s。虚线竖标为0.2与1.2 s参考阶段边界。'
        'H050与健康正向的积分曲线重合来自本批实际保存值。','',
        f"![全输入位置、速度及x积分状态]({(out/'figures/STEP22_RESPONSE_preview.png').as_posix()})",'',
        f"![PID完整六通道积分状态]({(out/'figures/STEP22_INTEGRAL_preview.png').as_posix()})",'',
        f"[响应矢量PDF]({(out/'figures/STEP22_RESPONSE.pdf').as_posix()}) · [六通道积分矢量PDF]({(out/'figures/STEP22_INTEGRAL.pdf').as_posix()})",'',
        '图形程序及彩色/灰度读图检查通过，PDF嵌入字体已核验；PNG按600 DPI导出。所有图由已保存数据生成，无新增求解或积分。','',
        '当前冻结工程判据仍为PD=NOT_MET、PID=NOT_MET。PID可作为后续开发的具体参考实现，但本批未完全满足停止判据，尚未进入预测backup或正式H2面板。','']
    report=out/'TASK_RESPONSE_REPORT.md';text=report.read_text(encoding='utf-8')
    marker='\n## PD与PID的实际效果及剩余问题';text=text.split(marker)[0]
    report.write_text(text+'\n'.join(lines),encoding='utf-8')
    s['final_verification_status']='PASS'
    s['postprocessing_source_sha256']={str(p.relative_to(root)):digest(p) for p in
        (Path(__file__),root/'cavr_wbc/experiments/step22_visualize.py')}
    s['freeze_static_initialization_forward_calls']=1
    s['artifact_sha256']={str(p.relative_to(out)):digest(p) for p in out.rglob('*') if p.is_file() and p.name!='EXECUTION_SUMMARY.json'}
    (out/'EXECUTION_SUMMARY.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'saved_evidence':'PASS','attempts':8,'control_QP':880,'physics_steps':8800,
        'new_solver_or_integrations':0,'criteria_pass':s['common_task_execution_ready']}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True)
    p.add_argument('--stage',choices=['fonts','finalize'],required=True);args=p.parse_args()
    if args.stage=='fonts': fonts(args.output.resolve())
    else: finalize(args.output.resolve())
