"""STEP22 saved-table profiling and figures; no MuJoCo/controller imports."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import sys

SKILL=Path('C:/Users/ZhuanZ（无密码）/.codex/skills/scipilot-figure')
sys.path.insert(0,str(SKILL/'scripts'))


def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1048576),b''): h.update(chunk)
    return h.hexdigest()


def prepare(out):
    rows=list(csv.DictReader((out/'TASK_TIMESERIES.csv').open(encoding='utf-8',newline='')))
    fields=['configuration','input_id','time_s','p_m','v_m_s','p_ref_m','v_ref_m_s','b_x','b_y','b_z','b_rx','b_ry','b_rz']
    data=[]
    for r in rows:
        if r['sample_kind']!='CONTROL_PRE_STATE': continue
        v={k:r[k] for k in fields[:7]};v.update(zip(fields[7:],json.loads(r['b_used_m_s2_rad_s2_json'])))
        data.append(v)
    with (out/'FIGURE_DATA.csv').open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields,lineterminator='\n');w.writeheader();w.writerows(data)
    print(json.dumps({'figure_control_samples':len(data),'actual_episode_replicates_per_input_config':1}))


def profile(out):
    from profile_data import profile_data
    info=profile_data(str(out/'FIGURE_DATA.csv'),group_cols=['configuration','input_id'])
    info['experiment_unit_note']='Each of eight groups is ONE episode; 110 time points are dependent trajectory samples, not independent n.'
    info['chart_decision']={'recommended':'Shared-time trajectory panels for p/v/integral; all four inputs and both configs',
        'alternative':'Raw endpoint dot plot beside complete time table','uncertainty':'No replicate error bands, tests or mean bars',
        'purpose':'Compare displacement, controlled ZERO drift, stopping transient, and integral evolution'}
    (out/'FIGURE_DATA_PROFILE.json').write_text(json.dumps(info,ensure_ascii=False,indent=2,default=float)+'\n',encoding='utf-8')
    print(json.dumps({'profile_saved':True,'replicates_per_group':1,'selected_chart':'time-series'}))


def build(out):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import numpy as np
    from matplotlib.lines import Line2D
    from setup_style import setup_style
    from layout_tools import add_panel_labels
    setup_style(journal='ieee',lang='en',use_sciplots=False)
    plt.rcParams.update({'font.size':8,'axes.labelsize':8,'axes.titlesize':8,
        'xtick.labelsize':8,'ytick.labelsize':8,'legend.fontsize':8,'figure.constrained_layout.use':False})
    rows=list(csv.DictReader((out/'TASK_TIMESERIES.csv').open(encoding='utf-8',newline='')))
    inputs=['S22_HEALTHY_ZERO','S22_HEALTHY_POS','S22_HEALTHY_NEG','S22_H050_POS']
    names=['ZERO','+10 mm','-10 mm','h=0.5, +10 mm']
    configs=['S22_POSE_PD','S22_POSE_PID']
    colors=['#0072B2','#D55E00'];styles=['-','--'];markers=['o','s']
    fig,axes=plt.subplots(4,3,figsize=(7.16,8.2),sharex=True,layout='none')
    for row,(inp,name) in enumerate(zip(inputs,names)):
        for c,config in enumerate(configs):
            selected=[r for r in rows if r['input_id']==inp and r['configuration']==config]
            control=[r for r in selected if r['sample_kind']=='CONTROL_PRE_STATE']
            t=[float(r['time_s']) for r in selected]
            for col,key,scale in ((0,'p_m',1000),(1,'v_m_s',1000)):
                axes[row,col].plot(t,[float(r[key])*scale for r in selected],color=colors[c],ls=styles[c],
                    marker=markers[c],markevery=14,ms=2.2,lw=1.05,label=config)
            axes[row,2].plot([float(r['time_s']) for r in control],
                [json.loads(r['b_used_m_s2_rad_s2_json'])[0] for r in control],color=colors[c],ls=styles[c],
                marker=markers[c],markevery=14,ms=2.2,lw=1.05)
            if c==0:
                axes[row,0].plot(t,[float(r['p_ref_m'])*1000 for r in selected],color='#555555',ls=':',lw=1.0)
                axes[row,1].plot(t,[float(r['v_ref_m_s'])*1000 for r in selected],color='#555555',ls=':',lw=1.0)
        for col,ax in enumerate(axes[row]):
            ax.set_title(name,pad=3);ax.set_xlim(0,2.2);ax.set_xticks([0,1,2])
            ax.axvline(.2,color='#CCCCCC',lw=.5,ls=':');ax.axvline(1.2,color='#CCCCCC',lw=.5,ls=':')
            ax.axhline(0,color='#DDDDDD',lw=.4,zorder=0)
            ax.set_ylabel(['Base x (mm)','Base vx (mm/s)','Integral bx (m/s²)'][col])
            ax.set_ylim([(-12,12),(-22,22),(-.6,.6)][col])
            if row==3: ax.set_xlabel('Time (s)')
    handles=[Line2D([],[],color='#555555',ls=':',label='Reference (p/v)'),
        Line2D([],[],color=colors[0],ls='-',marker='o',ms=3,label='PD'),
        Line2D([],[],color=colors[1],ls='--',marker='s',ms=3,label='PID')]
    fig.suptitle('STEP22: displacement, stopping, and integral state',fontsize=9)
    fig.legend(handles=handles,loc='upper center',ncol=3,frameon=False,bbox_to_anchor=(.5,.97))
    fig.subplots_adjust(left=.10,right=.985,bottom=.065,top=.895,hspace=.30,wspace=.32)
    add_panel_labels(fig,axes=axes.flat,style='ieee',fontsize=8,x_offset_pt=-2,y_offset_pt=2)
    labels=['bx (m/s²)','by (m/s²)','bz (m/s²)','brx (rad/s²)','bry (rad/s²)','brz (rad/s²)']
    fig2,axes2=plt.subplots(2,3,figsize=(7.16,4.8),sharex=True,sharey=True,layout='none')
    input_colors=['#333333','#0072B2','#D55E00','#009E73'];input_ls=['-','--','-.',':'];input_mark=['o','s','^','D']
    for k,ax in enumerate(axes2.flat):
        for j,inp in enumerate(inputs):
            selected=[r for r in rows if r['input_id']==inp and r['configuration']=='S22_POSE_PID' and r['sample_kind']=='CONTROL_PRE_STATE']
            ax.plot([float(r['time_s']) for r in selected],
                [json.loads(r['b_used_m_s2_rad_s2_json'])[k] for r in selected],
                color=input_colors[j],ls=input_ls[j],marker=input_mark[j],markevery=15,ms=2.5,lw=1.0)
        ax.axhline(0,color='#999999',lw=.5,ls=':');ax.set_ylim(-1.05,1.05);ax.set_xlim(0,2.2);ax.set_xticks([0,1,2])
        ax.set_ylabel(labels[k]);ax.set_xlabel('Time (s)')
    h2=[Line2D([],[],color=color,ls=ls,marker=mk,ms=3,label=name) for color,ls,mk,name in zip(input_colors,input_ls,input_mark,names)]
    fig2.suptitle('STEP22: all six PID integral channels',fontsize=9)
    fig2.legend(handles=h2,loc='upper center',ncol=2,frameon=False,bbox_to_anchor=(.5,.952))
    fig2.subplots_adjust(left=.10,right=.985,bottom=.11,top=.805,hspace=.33,wspace=.30)
    add_panel_labels(fig2,axes=axes2.flat,style='ieee',fontsize=8,x_offset_pt=-2,y_offset_pt=2)
    return [('STEP22_RESPONSE',fig,(7.16,8.2)),('STEP22_INTEGRAL',fig2,(7.16,4.8))]


def draw(out,export=False):
    from visual_qa import audit_layout,render_preview
    from export_figure import export_figure
    from PIL import Image
    figs=out/'figures';figs.mkdir(exist_ok=True);qa=[]
    for name,fig,size in build(out):
        render_preview(fig,str(figs/(name+'_preview.png')),dpi=150)
        issues=audit_layout(fig)
        if any(sev=='FAIL' for sev,msg in issues): raise ValueError('Figure layout/glyph failure: '+str(issues))
        qa.append({'name':name,'layout_issues':issues,'size_inches':size,'min_font_pt':8})
        if export:
            export_figure(fig,str(figs/name),formats=['pdf','svg','png'],dpi=600,size_inches=size,tight=False)
        with Image.open(figs/(name+('.png' if export else '_preview.png'))) as im:
            im.convert('L').save(figs/(name+'_grayscale.png'),dpi=(600,600) if export else (150,150))
    (out/'FIGURE_LAYOUT_QA.json').write_text(json.dumps({'figures':qa,'skill':'scipilot-figure-skill',
        'stage':'export' if export else 'preview','source_sha256':digest(Path(__file__)),
        'actual_replicates_per_input_configuration':1,'new_solver_calls':0,'new_physics_steps':0},indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'stage':'export' if export else 'preview','layout':qa}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True)
    p.add_argument('--stage',choices=['prepare','profile','preview','export'],required=True);args=p.parse_args()
    if args.stage=='prepare': prepare(args.output)
    elif args.stage=='profile': profile(args.output)
    else: draw(args.output,export=args.stage=='export')
