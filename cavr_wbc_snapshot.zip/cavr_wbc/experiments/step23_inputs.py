"""Reconstruct only the two saved STEP22 states and their fixed translations."""
from copy import deepcopy
import json
from pathlib import Path
import mujoco
import numpy as np
from cavr_wbc.experiments import step17_formal_panel as frozen

SOURCE_TICKS=(30,40)
GAPS_M=(.008,.002,.0008)
HEALTH_LEVELS=(1.,.05,.02)
BOUNDARY_X_M=1.
STATE_FIELDS=('qpos','qvel','act','ctrl','qacc_warmstart','xfrc_applied')


def source_records(path):
    payload=json.loads(Path(path).read_text(encoding='utf-8'));r=payload['result']
    if r['configuration']!='S22_POSE_PID' or r['input_id']!='S22_HEALTHY_POS':
        raise ValueError('Incorrect source trajectory')
    records=[]
    for tick in SOURCE_TICKS:
        previous=r['controls'][tick-1]['post_control_state'];current=r['controls'][tick]
        if current['tick']!=tick or abs(current['time_s']-tick*.02)>1e-9: raise ValueError('Source control tick mismatch')
        for field in ('qpos','qvel'):
            if not np.array_equal(previous[field],current['physical_at_decision'][field]): raise ValueError('Source post/pre state mismatch')
        if abs(previous['time_s']-tick*.02)>1e-9: raise ValueError('Source post-control clock mismatch')
        records.append({'source_tick':tick,'source_time_s':tick*.02,
            'source_state':deepcopy(previous),'nominal_q_init':deepcopy(r['q_init']),
            'nominal_b_used':deepcopy(current['integral_record']['b_used']),
            'source_external_reference':deepcopy(current['external_reference']),
            'source_backup_version':'S22_POSE_PID','source_shard':str(path),'source_result_hash':payload['result_hash'],
            'source_qpos_qvel_alignment_verified':True})
    return records


def build_cases(records):
    cases=[]
    for src in records:
        for gap in GAPS_M:
            for health in HEALTH_LEVELS:
                case=deepcopy(src);shift=BOUNDARY_X_M-gap-src['source_state']['qpos'][0]
                state=deepcopy(src['source_state']);state['qpos'][0]+=shift;state['time_s']=0.
                nominal=deepcopy(src['nominal_q_init']);nominal[0]+=shift
                h=np.ones(12);h[1]=health
                identity=f"S23_T{src['source_tick']:02d}_G{int(round(gap*1000000)):05d}um_H{int(round(health*1000)):04d}"
                case.update(case_id=identity,gap_m=gap,health=health,health_vector=h.tolist(),shift_x_m=shift,
                    boundary_x_m=BOUNDARY_X_M,state=state,shifted_nominal_q_init=nominal,
                    backup_anchor_q_init=deepcopy(state['qpos']),backup_id='STEP23-'+identity,
                    nominal_d_m=.01,source_absolute_clock_reset_to_relative_zero=True)
                cases.append(case)
    return cases


def integration_state(model,data):
    sig=int(mujoco.mjtState.mjSTATE_INTEGRATION)
    vector=np.zeros(mujoco.mj_stateSize(model,sig));mujoco.mj_getState(model,data,vector,sig)
    return {'signature':sig,'vector':vector.tolist(),'hash':frozen.sha(vector.tolist())}


def restore_case(model,case):
    data=mujoco.MjData(model)
    # These unused integration fields were not serialized by STEP22. The
    # frozen Go2 has no entries, so none can be silently lost on restoration.
    unused={name:int(np.asarray(getattr(data,name)).size) for name in
        ('history','plugin_state','mocap_pos','mocap_quat','eq_active','userdata')}
    if any(unused.values()): raise ValueError('Source lacks nonempty optional integration fields')
    for field in STATE_FIELDS:
        dest=getattr(data,field);values=np.asarray(case['state'][field],dtype=float)
        if dest.shape!=values.shape: raise ValueError('Saved state field dimensions mismatch: '+field)
        dest[:]=values
    data.time=0.;data.qfrc_applied[:]=0.
    mujoco.mj_forward(model,data)
    for field in STATE_FIELDS:
        if not np.array_equal(getattr(data,field),case['state'][field]): raise ValueError('Forward changed preserved state field '+field)
    return data,{'optional_integration_field_sizes':unused,'supported_integration_state':integration_state(model,data),
        'state_restore_forward_calls':1,'state_restore_model_changes':0}
