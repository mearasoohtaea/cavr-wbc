"""Bounded STEP23 offline pilot: 18 inputs, one decision, independent actual branches."""
import argparse
from collections import Counter
import gc
import json
import os
from pathlib import Path
import sys
from time import perf_counter
import traceback
import mujoco
import numpy as np

from cavr_wbc.control.step22_pose_servo import Step22WBC,BasePoseServo,specification
from cavr_wbc.control.step23_backup_filter import (
    HOLD_VERSION,clone_data,run_branch,preview_candidate,choose_methods,predicted_physical_check,
)
from cavr_wbc.experiments import step17_formal_panel as frozen
from cavr_wbc.experiments.step20_episode import json_safe
from cavr_wbc.experiments.step21_response import digest,utc,write_json,append
from cavr_wbc.experiments.step23_inputs import source_records,build_cases,restore_case,integration_state
from cavr_wbc.evaluation.step23_actual import evaluate_actual
from cavr_wbc.platforms.go2_mujoco import extract_healthy_torque_limits

ROOT=Path(__file__).resolve().parents[2]
PROTOCOL=Path('E:/CAVR-WBC/experiment_handoff_20260921/NEXT_CODEX_INSTRUCTIONS_STEP23_ONE_DECISION_BACKUP_FILTER_20261007.md')
OLD_OUT=ROOT/'artifacts/step22_full_pose_response_20261007/step22-full-pose-response-20261007-01'
SOURCE_SHARD=OLD_OUT/'cases/S22_POSE_PID__S22_HEALTHY_POS/STEP22_CASE_SHARD.json'
METHODS=('M0_QP_CANDIDATE','M1_ONE_STEP_FILTER','M2_HORIZON_FILTER')
NEW_SOURCE=('cavr_wbc/control/step23_backup_filter.py','cavr_wbc/experiments/step23_inputs.py',
    'cavr_wbc/evaluation/step23_actual.py','cavr_wbc/experiments/step23_one_decision.py',
    'cavr_wbc/experiments/step23_report.py','tests/test_step23_backup_filter.py','tests/test_step23_runner.py')


class BudgetExceeded(RuntimeError): pass


class PilotBudget:
    def __init__(self,out,timeout_s=1800):
        self.out=out;self.started=perf_counter();self.timeout_s=timeout_s
        self.qp_calls=0;self.physics_steps=0;self.qp_counts=Counter();self.step_counts=Counter();self.active={}
    def check_time(self):
        if perf_counter()-self.started>self.timeout_s: raise BudgetExceeded('1800 s wall timeout')
    def qp_callback(self,kind,owner,first_mode=None):
        offset=1 if first_mode in ('CANDIDATE','ZERO') else 0
        active={}
        def callback(stage,payload,solve):
            if stage=='before':
                self.check_time()
                if self.qp_calls>=4500: raise BudgetExceeded('4500 total QP bound')
                self.qp_calls+=1;self.qp_counts[kind]+=1
                row={'event':'QP_START','global_qp_index':self.qp_calls,'kind':kind,'owner':owner,
                    'local_qp_index':payload['solver_call_index'],'solver_stage':payload['stage'],
                    'relative_backup_slot':payload['solver_call_index']-1+offset if kind!='NOMINAL' else None,
                    'timestamp_utc':utc()}
                active.clear();active.update(row);append(self.out/'QP_LEDGER.jsonl',row)
                return solve()
            result=payload['result']
            append(self.out/'QP_LEDGER.jsonl',json_safe({**active,'event':'QP_RETURN','timestamp_utc':utc(),
                **{k:result.get(k) for k in ('status','status_val','iterations','primal_residual','dual_residual',
                    'solve_wall_time_s','solve_time_s','setup_time_s','update_time_s','workspace_reused','warm_started','real_optimizer_called')}}))
            return None
        return callback
    def step_observer(self,kind,owner):
        def before_step():
            self.check_time()
            if self.physics_steps>=45180: raise BudgetExceeded('45180 total integration bound')
            if kind=='PREDICTION' and self.step_counts[kind]>=18000: raise BudgetExceeded('18000 prediction step bound')
            if kind=='ACTUAL' and self.step_counts[kind]>=27000: raise BudgetExceeded('27000 actual step bound')
            if kind=='PREVIEW' and self.step_counts[kind]>=180: raise BudgetExceeded('180 preview step bound')
            self.physics_steps+=1;self.step_counts[kind]+=1
        return before_step
    def snapshot(self):
        return {'total_qp_calls':self.qp_calls,'qp_calls_by_kind':dict(self.qp_counts),
            'total_physics_steps':self.physics_steps,'physics_steps_by_kind':dict(self.step_counts)}


def freeze(out,run_id):
    old=json.loads((OLD_OUT/'PROTOCOL_AND_MANIFEST.json').read_text(encoding='utf-8'))
    records=source_records(SOURCE_SHARD);cases=build_cases(records)
    model=frozen.load_model();restores=0
    for case in cases:
        data,info=restore_case(model,case);restores+=1
        case['complete_current_integration_state']=info['supported_integration_state']
        case['optional_integration_field_sizes']=info['optional_integration_field_sizes'];del data
    direct=('cavr_wbc/control/step22_pose_servo.py','cavr_wbc/control/step21_contact_reference.py',
        'cavr_wbc/control/e2b_dynamic.py','cavr_wbc/control/step20_task_reference.py',
        'cavr_wbc/experiments/step17_formal_panel.py','cavr_wbc/evaluation/e2b_physical.py',
        'cavr_wbc/evaluation/step16_independent_evaluator.py','cavr_wbc/platforms/go2_mujoco.py')
    manifest={'schema':'STEP23_PROTOCOL_V1','run_id':run_id,'frozen_at_utc':utc(),
        'client_date':'2026-10-07','client_timezone':'Asia/Seoul','source_commit':'4577e8f472cdf3350fb04c5e35293505ad6f94d7',
        'protocol':str(PROTOCOL),'protocol_sha256':digest(PROTOCOL),'source_shard':str(SOURCE_SHARD),
        'source_shard_sha256':digest(SOURCE_SHARD),'source_result_hash':records[0]['source_result_hash'],
        'source_step22_output':str(OLD_OUT),'source_step22_reports_state':'PD/PID both NOT_MET, retained',
        'input_cases':cases,'methods':list(METHODS),'case_order':'tick30 then40; gap8/2/.8mm;health1/.05/.02',
        'backup_version':HOLD_VERSION,'backup_reference':'fixed decision-before current full base pose, zero p/v/a motion reference',
        'backup_integral_initial':[0.]*6,'nominal_integral':'source b_used; distinct policy object',
        'servo_design':specification(),'wbc_config':old['wbc_config'],'world_boundary_x_m':1.,
        'horizon_s':1.,'physics_dt_s':.002,'control_dt_s':.02,'slots_per_full_branch':50,'steps_per_full_branch':500,
        'candidate_hold_slots':1,'candidate_branch_backup_slots':49,'immediate_backup_slots':50,
        'prediction_checkpoints_steps':list(range(0,501,25)),
        'prediction_checkpoints_times_s':[j*.05 for j in range(21)],
        'terminal_set':{'anchor_x_error_abs_max_m':.002,'base_x_speed_abs_max_m_s':.001,
            'roll_pitch_abs_max_rad':.20,'lateral_speed_abs_max_m_s':.25,'existing_physical_boundaries_required':True},
        'prediction_acceptance':'21 numeric predicted physical predicates + valid dispatched backup commands + finite state + frozen terminal; no actual labels',
        'actual_evaluation':'independent actual 500physics states and21window; future actual trajectory never used to select',
        'max_nominal_candidate_QPs':18,'max_prediction_branches':36,'max_actual_branches':54,'max_one_step_previews':18,
        'max_total_QP_calls':4500,'max_total_physics_steps':45180,'max_prediction_steps':18000,
        'max_actual_steps':27000,'max_preview_steps':180,'deadline_ms':20.,'wall_timeout_s':1800,
        'latency_definition':'shared nominal clone/policy/QP generation + method filter cloning/prediction/checks + choice + fresh actual initialization + slot0 backup QP when switching; later actual physics/control separate',
        'deadline_miss_policy':'record realtime failure; complete fixed OFFLINE branches',
        'simulated_time_during_wall_computation':'no advancement; no missed-deadline delayed action simulation',
        'clone_API':'mj_copyData to fresh MjData; full mjSTATE_INTEGRATION retained; independent backup/controller/cache per branch',
        'frozen_physical_task_limits':old['physical_task_limits'],'independent_evaluator_config':old['independent_evaluator_config'],
        'model_files_sha256':old['model_files_sha256'],'source_sha256':{p:digest(ROOT/p) for p in direct+NEW_SOURCE},
        'input_freeze_model_loads':1,'input_freeze_forward_calls':restores,
        'source_current_consistency':'previous post_control_state equals current saved qpos/qvel; no historical commit byte audit',
        'python':sys.executable,'mujoco_version':mujoco.__version__,'TEMP':os.environ.get('TEMP'),'TMP':os.environ.get('TMP'),
        'native_osqp_dll':os.environ.get('CAVR_WBC_NATIVE_OSQP_DLL'),
        'numerical_retries':0,'parameter_or_scenario_search':False,'formal_continuous_panel_authorized':False,
        'E3_authorized':False,'RL_or_hardware_authorized':False}
    manifest['manifest_hash']=frozen.sha(manifest);write_json(out/'PROTOCOL_AND_MANIFEST.json',manifest)
    write_json(out/'INPUT_CASES.json',{'schema':'STEP23_FIXED_INPUTS_V1','cases':cases})
    return manifest


def branch_store(out,run_id,case_id,kind,label,function):
    path=out/'cases'/case_id/'branches'/f'{label}.json';owner=case_id+':'+label
    if path.exists(): raise RuntimeError('Refusing branch shard overwrite')
    append(out/'BRANCH_LEDGER.jsonl',{'event':'START','owner':owner,'kind':kind,'run_id':run_id,'timestamp_utc':utc()})
    try: result=function()
    except BaseException as exc:
        append(out/'BRANCH_LEDGER.jsonl',{'event':'FAILED','owner':owner,'kind':kind,'run_id':run_id,
            'timestamp_utc':utc(),'error_type':type(exc).__name__,'error_message':str(exc),
            'reason':'Infrastructure interruption; already-started branch is not numerically retried'})
        raise
    safe=json_safe(result);payload={'schema':'STEP23_BRANCH_SHARD_V1','owner':owner,'kind':kind,'run_id':run_id,
        'result':safe,'result_hash':frozen.sha(safe)}
    for attempt in range(2):
        try:
            write_json(path,payload);checked=json.loads(path.read_text(encoding='utf-8'))
            if frozen.sha(checked['result'])!=payload['result_hash']: raise RuntimeError('Branch readback hash mismatch')
            break
        except OSError:
            if attempt:
                append(out/'BRANCH_LEDGER.jsonl',{'event':'UNKNOWN','owner':owner,'kind':kind,
                    'reason':'Result persistence unavailable; no trajectory replay','timestamp_utc':utc()})
                raise
    append(out/'BRANCH_LEDGER.jsonl',{'event':'DONE','owner':owner,'kind':kind,'run_id':run_id,
        'timestamp_utc':utc(),'status':result.get('status'),'counts':result.get('counts'),
        'result_hash':payload['result_hash'],'shard':str(path.relative_to(out))})
    return result,str(path.relative_to(out))


def candidate(model,current,case,budget):
    begin=perf_counter();data=clone_data(model,current)
    controller=Step22WBC(model,solve_callback=budget.qp_callback('NOMINAL',case['case_id']+':NOMINAL'))
    servo=BasePoseServo(model,case['shifted_nominal_q_init'],.01,'S22_POSE_PID')
    servo.b_integral[:]=case['nominal_b_used']
    response=servo.compute(controller,data,np.asarray(case['health_vector']),case['source_tick'])
    wb=response.pop('wbc');response.pop('wb',None);tau=np.asarray(response['tau_cmd'])
    data.ctrl[:]=tau;mujoco.mj_forward(model,data)
    fact=frozen._facts(model,data,tau,data.actuator_force.copy(),np.asarray(case['health_vector']),
        extract_healthy_torque_limits(model),response['latency_ms'],t=0.,tick=0,backup_id=case['backup_id'],
        scenario_id=case['case_id'],action=response['a_base_ref'][0],base_id=frozen._base_id(model))
    fact['physics_step']=0
    physical=predicted_physical_check(fact)
    generation_ms=(perf_counter()-begin)*1000
    return json_safe({'schema':'STEP23_NOMINAL_CANDIDATE_V1','command_valid':response['valid_command'],
        'tau':tau.tolist(),'generation_ms':generation_ms,'response':response,'solver_status':wb.get('status'),
        'solver_status_val':wb.get('status_val'),'qdd':wb.get('qdd'),'contact_lambda':wb.get('contact_force'),
        'QP_validation':wb.get('validation'),'assembly':controller.last_trace,'solver_ledger':controller.solver_ledger,
        'initial_new_command_fact':fact,'current_physical_check':physical,
        'source_b_used':case['nominal_b_used'],'backup_initial_b':[0.]*6,
        'counts':{'nominal_qp_calls':len(controller.solver_ledger),'clone_data_calls':1,'nominal_controller_instances':1,'nominal_command_diagnostic_forward_calls':1}})


def execute_case(out,m,case,budget):
    case_id=case['case_id'];case_path=out/'cases'/case_id/'DECISION.json'
    append(out/'ATTEMPT_LEDGER.jsonl',{'status':'START','case_id':case_id,'timestamp_utc':utc(),'run_id':m['run_id'],'manifest_hash':m['manifest_hash']})
    model=frozen.load_model();current,info=restore_case(model,case)
    if info['supported_integration_state']['hash']!=case['complete_current_integration_state']['hash']: raise ValueError('Restored input changed')
    nominal=candidate(model,current,case,budget);write_json(out/'cases'/case_id/'NOMINAL.json',nominal)
    valid=nominal['command_valid'];tau=nominal['tau'];health=np.asarray(case['health_vector']);anchor=case['backup_anchor_q_init'];bid=case['backup_id']
    preview=None;preview_path=None
    if valid:
        preview,preview_path=branch_store(out,m['run_id'],case_id,'PREVIEW','PREVIEW',lambda:
            preview_candidate(model,current,health,tau,bid,case_id+':PREVIEW',step_observer=budget.step_observer('PREVIEW',case_id+':PREVIEW')))
    pred_candidate=None;pred_candidate_path=None
    if valid:
        pred_candidate,pred_candidate_path=branch_store(out,m['run_id'],case_id,'PREDICTION','PRED_CANDIDATE',lambda:
            run_branch(model,current,health,anchor,bid,'CANDIDATE',tau,'PREDICTION_CANDIDATE',case_id+':PRED_CANDIDATE',
                solve_callback=budget.qp_callback('PREDICTION',case_id+':PRED_CANDIDATE','CANDIDATE'),step_observer=budget.step_observer('PREDICTION',case_id+':PRED_CANDIDATE')))
    pred_backup,pred_backup_path=branch_store(out,m['run_id'],case_id,'PREDICTION','PRED_BACKUP',lambda:
        run_branch(model,current,health,anchor,bid,'BACKUP',tau,'PREDICTION_IMMEDIATE',case_id+':PRED_BACKUP',
            solve_callback=budget.qp_callback('PREDICTION',case_id+':PRED_BACKUP','BACKUP'),step_observer=budget.step_observer('PREDICTION',case_id+':PRED_BACKUP')))
    begin=perf_counter()
    decisions=choose_methods(valid,bool(preview and preview['pass']),bool(pred_candidate and pred_candidate['sampled_screen']['pass']),pred_backup['sampled_screen']['pass'])
    choice_ms=(perf_counter()-begin)*1000
    filters={'M0_QP_CANDIDATE':0.,'M1_ONE_STEP_FILTER':preview['elapsed_ms'] if preview else 0.,
        'M2_HORIZON_FILTER':(pred_candidate['elapsed_ms'] if pred_candidate else 0.)+pred_backup['elapsed_ms']}
    actual={}
    for method in METHODS:
        mode=decisions[method]['first_mode'];label='ACTUAL_'+method
        result,path=branch_store(out,m['run_id'],case_id,'ACTUAL',label,lambda:
            run_branch(model,current,health,anchor,bid,mode,tau,'ACTUAL_'+method,case_id+':'+label,
                solve_callback=budget.qp_callback('ACTUAL',case_id+':'+label,mode),step_observer=budget.step_observer('ACTUAL',case_id+':'+label)))
        eval_begin=perf_counter();evaluation=evaluate_actual(result,anchor);eval_s=perf_counter()-eval_begin
        latency=nominal['generation_ms']+filters[method]+choice_ms+result['initialization_ms']+result['first_backup_decision_ms']
        actual[method]={'trajectory_shard':path,'evaluation':evaluation,'decision_latency_ms':latency,
            'deadline_miss':latency>20.,'actual_evaluation_s':eval_s,'counts':result['counts'],
            'initialization_ms':result['initialization_ms'],'first_backup_decision_ms':result['first_backup_decision_ms'],
            'subsequent_backup_control_latency_ms':[x['latency_ms'] for x in result['controls'] if 'BACKUP_QP' in x.get('action_source','') and x.get('slot',0)>0]}
        del result;gc.collect()
    decision={'schema':'STEP23_CASE_DECISION_V1','case_id':case_id,'run_id':m['run_id'],
        'source_tick':case['source_tick'],'source_time_s':case['source_time_s'],'gap_m':case['gap_m'],'health':case['health'],
        'nominal_generation_ms':nominal['generation_ms'],'current_candidate_valid':valid,
        'current_candidate_physical_check':nominal['current_physical_check'],
        'candidate_qualified_for_main_comparison':valid and nominal['current_physical_check']['pass'],
        'one_step_pass':bool(preview and preview['pass']),
        'candidate_horizon_pass':bool(pred_candidate and pred_candidate['sampled_screen']['pass']),
        'immediate_backup_horizon_pass':pred_backup['sampled_screen']['pass'],
        'preview_shard':preview_path,'candidate_prediction_shard':pred_candidate_path,'immediate_prediction_shard':pred_backup_path,
        'prediction_skip_if_invalid_candidate':not valid,'method_decisions':decisions,
        'filter_latency_ms':filters,'selection_ms':choice_ms,'actual_methods':actual,
        'backup_id':bid,'backup_version':HOLD_VERSION,'backup_anchor_q_init':anchor,
        'input_restore_info':info,'budget_cumulative':budget.snapshot(),'status':'CASE_COMPLETED_WITH_RESULTS'}
    write_json(case_path,decision)
    append(out/'ATTEMPT_LEDGER.jsonl',{'status':'DONE','case_id':case_id,'timestamp_utc':utc(),'run_id':m['run_id'],
        'manifest_hash':m['manifest_hash'],'decision_hash':frozen.sha(decision),'shard':str(case_path.relative_to(out)),'budget_cumulative':budget.snapshot()})
    print(json.dumps({'case_done':case_id,'nominal_valid':valid,'one_step':decision['one_step_pass'],
        'candidate_screen':decision['candidate_horizon_pass'],'backup_screen':decision['immediate_backup_horizon_pass'],
        'counts':budget.snapshot()}),flush=True)
    return decision


def run(out,run_id):
    out=out.resolve();allowed=(ROOT/'artifacts/step23_one_decision_backup_20261007').resolve()
    if allowed not in out.parents: raise ValueError('Output must be unique STEP23 child')
    out.mkdir(parents=True,exist_ok=True)
    if (out/'ATTEMPT_LEDGER.jsonl').exists() or (out/'PROTOCOL_AND_MANIFEST.json').exists(): raise RuntimeError('Batch cannot restart')
    manifest=freeze(out,run_id);budget=PilotBudget(out)
    write_json(out/'RUN_STARTED.json',{'run_id':run_id,'pid':os.getpid(),'timestamp_utc':utc(),'command':sys.argv,'cwd':str(ROOT)})
    completed=0;stopped=None
    try:
        for case in manifest['input_cases']:
            decision=execute_case(out,manifest,case,budget);completed+=1
            write_json(out/'PROGRESS.json',{'updated_utc':utc(),'completed_cases':completed,'target_cases':18,
                'last_case_id':case['case_id'],'budget':budget.snapshot()})
            del decision;gc.collect()
    except BaseException as exc:
        stopped={'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()}
        write_json(out/'INTERRUPTION.json',{'timestamp_utc':utc(),'completed_cases':completed,'budget':budget.snapshot(),'error':stopped})
    write_json(out/'RUN_FINISHED.json',{'timestamp_utc':utc(),'completed_cases':completed,'budget':budget.snapshot(),
        'status':'FIXED_PILOT_COMPLETED' if stopped is None else 'INTERRUPTED','error':stopped})
    from cavr_wbc.experiments.step23_report import report
    report(out)
    if stopped: raise RuntimeError('STEP23 incomplete; evidence preserved: '+str(stopped))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--run-id')
    p.add_argument('--summarize',action='store_true');args=p.parse_args()
    if args.summarize:
        from cavr_wbc.experiments.step23_report import report
        report(args.output.resolve())
    else:
        if not args.run_id: p.error('--run-id required')
        run(args.output,args.run_id)
