"""STEP23 saved-result mechanism report; no solver or simulation imports."""
from collections import Counter
from datetime import datetime,timezone
import json
from pathlib import Path
from cavr_wbc.experiments.step21_report import csv_write,digest,canonical_hash


METHODS=('M0_QP_CANDIDATE','M1_ONE_STEP_FILTER','M2_HORIZON_FILTER')


def report(out):
    root=Path(__file__).resolve().parents[2]
    m=json.loads((out/'PROTOCOL_AND_MANIFEST.json').read_text(encoding='utf-8'))
    qlog=[json.loads(x) for x in (out/'QP_LEDGER.jsonl').read_text().splitlines() if x] if (out/'QP_LEDGER.jsonl').exists() else []
    blog=[json.loads(x) for x in (out/'BRANCH_LEDGER.jsonl').read_text().splitlines() if x] if (out/'BRANCH_LEDGER.jsonl').exists() else []
    history=[json.loads(x) for x in (out/'ATTEMPT_LEDGER.jsonl').read_text().splitlines() if x] if (out/'ATTEMPT_LEDGER.jsonl').exists() else []
    rows=[];actual_rows=[];mechanisms=[];reverse=[];unnecessary=[];false_accept=[];decisions=[];branch_counts=Counter();counts=Counter()
    for case in m['input_cases']:
        cid=case['case_id'];path=out/'cases'/cid/'DECISION.json'
        row={'case_id':cid,'source_tick':case['source_tick'],'source_time_s':case['source_time_s'],'gap_m':case['gap_m'],'health':case['health']}
        if not path.exists():
            row['status']='MISSING_OR_INTERRUPTED';rows.append(row)
            for method in METHODS: actual_rows.append({**row,'method':method,'status':'NOT_COMPLETED'})
            continue
        d=json.loads(path.read_text(encoding='utf-8'));decisions.append(d)
        done=next((x for x in history if x['case_id']==cid and x['status']=='DONE'),None)
        if not done or canonical_hash(d)!=done['decision_hash']: raise ValueError('Decision ledger/hash mismatch')
        row.update(status=d['status'],candidate_valid=d['current_candidate_valid'],
            candidate_initial_physical_pass=d['current_candidate_physical_check']['pass'],
            qualified_main_comparison=d['candidate_qualified_for_main_comparison'],
            one_step_pass=d['one_step_pass'],candidate_horizon_pass=d['candidate_horizon_pass'],
            immediate_backup_horizon_pass=d['immediate_backup_horizon_pass'],nominal_generation_ms=d['nominal_generation_ms'])
        for method in METHODS:
            choice=d['method_decisions'][method];a=d['actual_methods'][method];e=a['evaluation']
            payload=json.loads((out/a['trajectory_shard']).read_text(encoding='utf-8'));r=payload['result']
            if canonical_hash(r)!=payload['result_hash']: raise ValueError('Actual trajectory hash mismatch')
            counts.update(r['counts']);branch_counts['actual_started']+=1
            if r['status']=='COMPLETE': branch_counts['actual_complete']+=1
            row[method+'_first_mode']=choice['first_mode'];row[method+'_safety_label']=choice['safety_label']
            row[method+'_actual_safe']=e['actual_safe_all_physics_states'];row[method+'_terminal']=e['actual_terminal_pass']
            row[method+'_decision_ms']=a['decision_latency_ms'];row[method+'_deadline_miss']=a['deadline_miss']
            control_times=a['subsequent_backup_control_latency_ms']
            ar={'case_id':cid,'method':method,'source_tick':case['source_tick'],'gap_m':case['gap_m'],'health':case['health'],
                'candidate_valid':d['current_candidate_valid'],'candidate_initial_physical_pass':d['current_candidate_physical_check']['pass'],
                'status':r['status'],'branch_failure_reason':json.dumps(r['reason']),
                'first_mode':choice['first_mode'],'safety_label':choice['safety_label'],
                'decision_latency_ms':a['decision_latency_ms'],'deadline_miss':a['deadline_miss'],
                'later_backup_control_max_ms':max(control_times,default=None),'later_backup_control_deadline_misses':sum(t>20 for t in control_times),
                'actual_safe_all_physics':e['actual_safe_all_physics_states'],'actual_terminal_pass':e['actual_terminal_pass'],
                'actual_safe_and_terminal':e['actual_safe_and_terminal'],
                'workspace_failure':e['workspace_failure'],'height_failure':e['height_failure'],'pose_failure':e['pose_failure'],
                'first_failure_time_s':(e['first_physical_failure'] or {}).get('time_s'),
                'first_failure_reasons':json.dumps((e['first_physical_failure'] or {}).get('reasons')),
                'between_checkpoint_failure_count':e['between_checkpoint_failure_count'],
                'terminal_anchor_x_error_m':e['terminal_anchor_x_error_m'],'terminal_base_vx_m_s':e['terminal_base_vx_m_s'],
                'min_workspace_margin_m':e['min_workspace_margin_m'],
                'min_command_torque_margin_nm':e['min_command_torque_margin_nm'],
                'min_applied_torque_margin_nm':e['min_applied_torque_margin_nm'],
                'actual_physics_steps':r['counts']['physical_steps'],'actual_backup_QP_calls':r['counts']['backup_qp_calls'],
                'backup_id':r['backup_id'],'backup_version':r['backup_version'],'actual_trajectory_shard':a['trajectory_shard']}
            actual_rows.append(ar)
            if choice['first_mode']=='CANDIDATE' and method!='M0_QP_CANDIDATE' and not e['actual_safe_all_physics_states']:
                false_accept.append({'case_id':cid,'method':method,'failure':e['first_physical_failure'],
                    'between_checkpoint_failure_count':e['between_checkpoint_failure_count']})
        for label,pathkey in (('preview','preview_shard'),('prediction','candidate_prediction_shard'),('prediction','immediate_prediction_shard')):
            if d[pathkey]:
                payload=json.loads((out/d[pathkey]).read_text(encoding='utf-8'));r=payload['result']
                if canonical_hash(r)!=payload['result_hash']: raise ValueError('Predicted/preview shard hash mismatch')
                counts.update(r['counts']);branch_counts[label+'_started']+=1
                if r['status']=='COMPLETE': branch_counts[label+'_complete']+=1
        a0=d['actual_methods'][METHODS[0]]['evaluation'];a1=d['actual_methods'][METHODS[1]]['evaluation'];a2=d['actual_methods'][METHODS[2]]['evaluation']
        switched=d['method_decisions'][METHODS[2]]['first_mode']=='BACKUP'
        if d['candidate_qualified_for_main_comparison'] and d['one_step_pass'] and not a0['actual_safe_all_physics_states'] and not a1['actual_safe_all_physics_states'] and switched and a2['actual_safe_and_terminal']:
            mechanisms.append({'case_id':cid,'source_tick':case['source_tick'],'gap_m':case['gap_m'],'health':case['health'],
                'M0_failure':a0['first_physical_failure'],'M1_failure':a1['first_physical_failure'],
                'M2_terminal_error_m':a2['terminal_anchor_x_error_m'],'M2_terminal_vx_m_s':a2['terminal_base_vx_m_s']})
        if d['current_candidate_valid'] and switched and a0['actual_safe_and_terminal']:
            unnecessary.append(cid)
            if not a2['actual_safe_and_terminal']: reverse.append(cid)
        rows.append(row)
    csv_write(out/'DECISION_TABLE.csv',rows);csv_write(out/'ACTUAL_CASE_TABLE.csv',actual_rows)
    qp_started=[x for x in qlog if x['event']=='QP_START'];qp_returned=[x for x in qlog if x['event']=='QP_RETURN']
    qp_kinds=Counter(x['kind'] for x in qp_started);solver_status=Counter(str(x['status']) for x in qp_returned)
    nominal_invalid=sum(not d['current_candidate_valid'] for d in decisions)
    backup_not_screened=sum(d['method_decisions'][METHODS[2]]['safety_label']=='BACKUP_NOT_SCREENED_SAFE' for d in decisions)
    current_bound_counts=[]
    for d in decisions:
        case_id=d['case_id'];nom=json.loads((out/'cases'/case_id/'NOMINAL.json').read_text())
        lim=nom['assembly']['tau_lim'];tau=nom['tau'];near=[j for j,(t,l) in enumerate(zip(tau,lim)) if l<=0 or abs(t)>=.99*l]
        current_bound_counts.append({'case_id':case_id,'health':d['health'],'nominal_authority_99pct_actuators':near,
            'FR_thigh_near_bound':1 in near,'candidate_valid':d['current_candidate_valid']})
    aggregate={}
    for method in METHODS:
        rr=[r for r in actual_rows if r['method']==method and 'decision_latency_ms' in r]
        aggregate[method]={'decision_latency_max_ms':max((r['decision_latency_ms'] for r in rr),default=None),
            'decision_latency_mean_ms':sum(r['decision_latency_ms'] for r in rr)/len(rr) if rr else None,
            'decision_deadline_misses':sum(r['deadline_miss'] for r in rr),
            'actual_complete_branches':sum(r['status']=='COMPLETE' for r in rr),
            'actual_safe_and_terminal_branches':sum(r['actual_safe_and_terminal'] for r in rr),
            'later_backup_control_deadline_misses':sum(r['later_backup_control_deadline_misses'] for r in rr)}
    summary={'schema':'STEP23_EXECUTION_SUMMARY_V1','run_id':m['run_id'],'checked_at_utc':datetime.now(timezone.utc).isoformat(),
        'completed_input_cases':len(decisions),'fixed_pilot_completed':len(decisions)==18,'planned_input_cases':18,
        'nominal_candidate_QP_calls':qp_kinds['NOMINAL'],'total_QP_calls':len(qp_started),'QP_returns':len(qp_returned),
        'unreturned_QP_reservations':len(qp_started)-len(qp_returned),'QP_calls_by_kind':dict(qp_kinds),
        'total_physics_steps':counts['physical_steps'],'branch_counts':dict(branch_counts),'counts':dict(counts),
        'solver_status_counts':dict(solver_status),'method_observed_metrics':aggregate,
        'mechanism_status':'DISCRIMINATING_INSTANCE_OBSERVED' if mechanisms else 'NO_DISCRIMINATING_INSTANCE_OBSERVED',
        'discriminating_instances':mechanisms,'current_candidate_invalid_cases':nominal_invalid,
        'specified_backup_not_screened_safe_cases':backup_not_screened,'reverse_harm_cases':reverse,
        'unnecessary_rejection_cases':unnecessary,'false_acceptance_cases':false_accept,
        'current_nominal_health_bound_diagnostics':current_bound_counts,
        'source_sha256':m['source_sha256'],'numerical_retries':0,'step22_results_unchanged':'NOT_MET',
        'git_status':'SOURCE_AND_EVIDENCE_SAVED_PENDING_SCOPED_COMMIT',
        'new_report_QP_or_integration_calls':0,'formal_continuous_panel_authorized':False,'E3_authorized':False,'RL_or_hardware_authorized':False}
    if len(qp_started)>4500 or counts['physical_steps']>45180: raise ValueError('Pilot budget exceeded')
    if len(decisions)==18:
        if qp_kinds['NOMINAL']!=18 or branch_counts['actual_started']!=54: raise ValueError('Nominal/actual dispatch count mismatch')
    (out/'MECHANISM_INSTANCES.json').write_text(json.dumps({'positive_instances':mechanisms,'reverse_harm':reverse,
        'unnecessary_rejection':unnecessary,'false_acceptance':false_accept,'current_bound_counts':current_bound_counts},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    lines=['# STEP23 离线单决策 feedback-backup 预测筛选','', '## Material Passport','',
        'experiment-agent／run；2026-10-07（Asia/Seoul）；固定18个派生状态的离线机制pilot，无独立随机重复。','',
        '## 执行与机制结果','',
        f"完成输入 {len(decisions)}/18；实际分支派发 {branch_counts['actual_started']}/54，其中完整积分到1秒 {branch_counts['actual_complete']} 条；完整horizon预测派发 {branch_counts['prediction_started']} 条，一步预览 {branch_counts['preview_started']} 条。",
        f"真实当前nominal QP {qp_kinds['NOMINAL']} 次，总QP {len(qp_started)} 次，积分 {counts['physical_steps']} 步。数值失败、物理失败与deadline miss均保留。",
        '机制状态：`'+summary['mechanism_status']+'`。','',
        '三方法之后0.98秒都使用同一固定HOLD-current-pose PID backup。唯一选择差异是最初20 ms候选或立即backup。'
        '各分支重新复制完整当前物理状态并拥有独立backup积分/求解器；实际分支逐tick重新求解，不重放预测tau。','',
        '## 逐状态配对结果','',
        '| case | health | gap mm | 当前QP有效 | 当前物理 | 一步 | 候选horizon | 立即backup horizon | M0实际安全/终端 | M1实际安全/终端 | M2选择/实际安全/终端 |',
        '|---|---:|---:|---|---|---|---|---|---|---|---|']
    for r in rows:
        if r.get('status')!='CASE_COMPLETED_WITH_RESULTS':
            lines.append(f"| {r['case_id']} | {r['health']} | {r['gap_m']*1000:g} | INCOMPLETE | | | | | | | |")
            continue
        cells=[r['case_id'],str(r['health']),f"{r['gap_m']*1000:g}",str(r['candidate_valid']),str(r['candidate_initial_physical_pass']),
            str(r['one_step_pass']),str(r['candidate_horizon_pass']),str(r['immediate_backup_horizon_pass'])]
        cells+=[str(r[method+'_actual_safe'])+'/'+str(r[method+'_terminal']) for method in METHODS[:2]]
        cells+=[r[METHODS[2]+'_first_mode']+'/'+str(r[METHODS[2]+'_actual_safe'])+'/'+str(r[METHODS[2]+'_terminal'])]
        lines.append('| '+' | '.join(cells)+' |')
    lines+=['','当前QP无有效命令的案例单独报告：M0明确zero-command20ms，M1/M2立即指定backup，未混入当前可行候选的主机制集合。'
        '主实例还要求新health/new command后的初始物理事实通过；未使用旧健康命令判断新fault。','',
        '## 具体实例及反例','',
        f"满足‘当前候选有效且初始物理通过、一步通过、M0/M1后续实际失败、M2拒绝后实际安全且到达终端’的实例：{len(mechanisms)} 个。"]
    for inst in mechanisms:
        lines.append('`'+inst['case_id']+'`：'+json.dumps(inst,ensure_ascii=False)+'。')
    if not mechanisms: lines.append('`NO_DISCRIMINATING_INSTANCE_OBSERVED`：完整保留18输入的结果，不搜索更小gap、其他health或PID参数来替换本批。')
    lines += [f"反向受损 {len(reverse)}，不必要拒绝 {len(unnecessary)}，接受后实际失败记录 {len(false_accept)}；详见MECHANISM_INSTANCES.json。",
        f"当前候选无效 {nominal_invalid} 个；两条预测均未满足采样判据、执行best effort指定backup的案例 {backup_not_screened} 个，标签BACKUP_NOT_SCREENED_SAFE。",
        '某个指定backup筛选失败仅说明该策略未满足当前采样/终端判据，不推断全局不可恢复或viability kernel之外。'
        'workspace越界、实际高度与姿态失败在ACTUAL_CASE_TABLE.csv分开，不将工作空间边界包装成悬崖/跌倒。','',
        '## 复制、预测与独立实际评价','',
        '两个来源为原PID正向轨迹tick30/40，以前一tick完整post-control-state对齐当前qpos/qvel；保留关节速度、ctrl、act、warmstart。'
        '只水平平移free-base及nominal参考，health在相对t=0已知并保持。该模型未保存的optional integration字段为空，已明确记录；分支使用[mj_copyData](https://mujoco.readthedocs.io/en/stable/APIreference/APIfunctions.html#mj-copydata)独立克隆。',
        '预测50slot/500step；候选20 ms后49次共同backup，立即backup50次；21点为0、0.05、…、1 s。'
        '预测只重算模型数值事实的冻结物理谓词，不读取实际评价标签。终端为anchor x误差≤2 mm、|vx|≤1 mm/s及原终端姿态/物理条件。'
        '实际评价读独立实际序列的全部500个状态及21点，checkpoint间失败记录为false acceptance，不改采样门。','',
        '## 时延与调用预算','',
        '| 方法 | 首次decision最大 ms | 首次decision平均 ms | >20ms case | 后续backup >20ms tick |',
        '|---|---:|---:|---:|---:|']
    for method,v in aggregate.items():
        lines.append(f"| {method} | {v['decision_latency_max_ms'] or 0:.6f} | {v['decision_latency_mean_ms'] or 0:.6f} | {v['decision_deadline_misses']} | {v['later_backup_control_deadline_misses']} |")
    lines+=['','首次decision计时包含共享nominal生成（调用实际只发生一次，三方法各加生成耗时）、数据/策略复制、预测backup QP/积分/采样检查及选择。'
        'M2包含候选与立即backup两条horizon；立即执行backup的首次实际控制生成也计入，后续实际backup耗时另列。',
        '该pilot在离线计算后于虚拟t=0执行，没有模拟真实墙钟错失deadline造成的延迟动作。超20 ms仍为实时性失败结果，物理结果不作为20 ms在线安全恢复证明。',
        'QP分类：`'+json.dumps(dict(qp_kinds),sort_keys=True)+'`；求解状态：`'+json.dumps(dict(solver_status),sort_keys=True)+'`。',
        '分支调用计数：`'+json.dumps(dict(counts),sort_keys=True)+'`。18个当前候选生成之外，不存在隐藏solver搜索或预测warmup重跑。','',
        '## 研究范围与交付','',
        'STEP22 PD/PID原工程判据继续NOT_MET，hold RMS与旧阈值/窗口未改。这次授权只解除其作为离线机制开发派发门的作用。'
        '18个输入由同一轨迹两个状态派生，按health/gap/来源分列，不作独立随机重复、显著性/非劣/泛化成功率检验。'
        '模型与实际plant相同；观察到的实例也只限于离线单决策、当前模型与采样条件，不证明模型失配鲁棒性、持续在线决策或T-RO投稿证据完整。',
        '交付：PROTOCOL_AND_MANIFEST.json、INPUT_CASES.json、18行DECISION_TABLE.csv、54行ACTUAL_CASE_TABLE.csv、'
        'cases/*/NOMINAL.json、预测/actual/preview独立分片、QP_LEDGER.jsonl、BRANCH_LEDGER.jsonl、ATTEMPT_LEDGER.jsonl、MECHANISM_INSTANCES.json及EXECUTION_SUMMARY.json。','',
        '```ini',f"STEP23_FIXED_PILOT = {'COMPLETED_18_CASES' if len(decisions)==18 else 'INCOMPLETE'}",
        'STEP22_RESULTS_UNCHANGED = NOT_MET','MECHANISM_RESULT = '+summary['mechanism_status'],
        f"NOMINAL_CANDIDATE_QP_CALLS = {qp_kinds['NOMINAL']}",f'ALL_QP_CALLS = {len(qp_started)}',
        f"ALL_PHYSICS_STEPS = {counts['physical_steps']}",f"ACTUAL_BRANCHES = {branch_counts['actual_started']}",
        f"PREDICTION_BRANCHES = {branch_counts['prediction_started']}",f"ONE_STEP_PREVIEWS = {branch_counts['preview_started']}",
        'REALTIME_PREDICTIVE_CLAIM = NOT_ESTABLISHED','PARAMETER_OR_SCENARIO_SEARCH = FALSE','NUMERICAL_RETRIES = 0',
        'HISTORICAL_RESULTS_UNCHANGED = TRUE','FORMAL_CONTINUOUS_PANEL = NOT_AUTHORIZED','E3 = NOT_AUTHORIZED','RL_OR_HARDWARE = NOT_AUTHORIZED','```','']
    gdpath=out/'GIT_DELIVERY.json'
    if gdpath.exists():
        gd=json.loads(gdpath.read_text());summary['git_status']=gd['status'];summary['git_delivery']=gd
        lines+=['Git交付：`'+gd['status']+'`；核心提交`'+gd['core_commit']+'`；分支`'+gd['branch']+'`。原工作树HEAD未reset。']
    (out/'MECHANISM_REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
    summary['artifact_sha256']={str(p.relative_to(out)):digest(p) for p in out.rglob('*') if p.is_file() and p.name!='EXECUTION_SUMMARY.json'}
    (out/'EXECUTION_SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'cases_complete':len(decisions),'nominal_QP':qp_kinds['NOMINAL'],'total_QP':len(qp_started),
        'total_steps':counts['physical_steps'],'branches':dict(branch_counts),'mechanism_instances':len(mechanisms),
        'current_candidate_invalid':nominal_invalid,'backup_not_screened':backup_not_screened,'method_metrics':aggregate},ensure_ascii=False),flush=True)
