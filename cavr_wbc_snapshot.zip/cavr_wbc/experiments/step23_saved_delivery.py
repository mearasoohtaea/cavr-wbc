"""Saved STEP23 call reconciliation, clone/anchor checks and scene interpretation."""
from collections import Counter
from datetime import datetime,timezone
import argparse
import json
from pathlib import Path
import xml.etree.ElementTree as ET
from cavr_wbc.experiments.step21_report import digest,canonical_hash,csv_write


def finalize(out):
    root=Path(__file__).resolve().parents[2]
    m=json.loads((out/'PROTOCOL_AND_MANIFEST.json').read_text(encoding='utf-8'))
    s=json.loads((out/'EXECUTION_SUMMARY.json').read_text(encoding='utf-8'))
    csv_write(out/'INPUT_CASE_TABLE.csv',[{'case_id':c['case_id'],'source_tick':c['source_tick'],
        'source_time_s':c['source_time_s'],'gap_m':c['gap_m'],'health_FR_thigh':c['health'],
        'shift_x_m':c['shift_x_m'],'current_base_x_m':c['state']['qpos'][0],
        'shifted_nominal_reference_initial_x_m':c['shifted_nominal_q_init'][0],
        'source_nominal_integral_b_used_json':json.dumps(c['nominal_b_used']),
        'complete_current_integration_state_hash':c['complete_current_integration_state']['hash'],
        'backup_id':c['backup_id']} for c in m['input_cases']])
    hist=[json.loads(x) for x in (out/'ATTEMPT_LEDGER.jsonl').read_text().splitlines() if x]
    qlog=[json.loads(x) for x in (out/'QP_LEDGER.jsonl').read_text().splitlines() if x]
    blog=[json.loads(x) for x in (out/'BRANCH_LEDGER.jsonl').read_text().splitlines() if x]
    starts=[x for x in qlog if x['event']=='QP_START'];returns=[x for x in qlog if x['event']=='QP_RETURN']
    if [x['global_qp_index'] for x in starts]!=list(range(1,len(starts)+1)) or [x['global_qp_index'] for x in returns]!=list(range(1,len(starts)+1)):
        raise ValueError('QP ledger missing or duplicate return/reservation')
    if len(starts)>4500: raise ValueError('QP budget exceeded')
    owners=[x['owner'] for x in blog if x['event']=='START']
    if len(owners)!=len(set(owners)): raise ValueError('Branch retried')
    source_changed={p:digest(root/p) for p,h in m['source_sha256'].items() if digest(root/p)!=h}
    if source_changed: raise ValueError('Frozen runtime source changed')
    if digest(Path(m['source_shard']))!=m['source_shard_sha256']: raise ValueError('Source input shard changed')
    for p,h in m['model_files_sha256'].items():
        if digest(root/p)!=h: raise ValueError('Frozen model changed')
    box_nodes=ET.parse(root/'third_party/unitree_mujoco_snapshot/unitree_robots/go2/scene.xml').getroot().findall('./worldbody/geom')
    boxes=[]
    for g in box_nodes:
        if g.get('type')!='box' or g.get('quat','1 0 0 0')!='1.0 0 0 0' and g.get('quat','1 0 0 0')!='1 0 0 0': continue
        center=[float(v) for v in g.get('pos').split()];size=[float(v) for v in g.get('size').split()]
        boxes.append({'center':center,'half_size':size,'lower':[a-b for a,b in zip(center,size)],'upper':[a+b for a,b in zip(center,size)]})
    geometry=[];checked=[];physics=Counter();qp_local=Counter();candidate_qp=0;health_bounds=[]
    for case in m['input_cases']:
        cid=case['case_id'];nom=json.loads((out/'cases'/cid/'NOMINAL.json').read_text())
        candidate_qp+=len(nom['solver_ledger'])
        event=[x for x in hist if x['case_id']==cid]
        if [x['status'] for x in event]!=['START','DONE']: raise ValueError('Case retry or interruption')
        d=json.loads((out/'cases'/cid/'DECISION.json').read_text())
        if canonical_hash(d)!=event[-1]['decision_hash']: raise ValueError('Decision hash mismatch')
        foot_hits=[]
        for name,point in zip(('FL','FR','RL','RR'),nom['assembly']['points']):
            hits=[b for b in boxes if all(lo<=v<=hi for v,lo,hi in zip(point,b['lower'],b['upper']))]
            foot_hits.append({'foot':name,'world_geom_center':point,'axis_aligned_scene_box_center_inside':bool(hits),'boxes':hits})
        initial=nom['initial_new_command_fact']
        nominal_limit=nom['assembly']['tau_lim'][1]
        nominal_near=nom['command_valid'] and abs(nom['tau'][1])>=.99*nominal_limit
        bound_record={'case_id':cid,'health':case['health'],'current_nominal_FR_thigh_99pct':nominal_near,
            'actual_valid_control_FR_thigh_99pct_counts':{},'any_actual_FR_thigh_99pct':False}
        geometry.append({'case_id':cid,'source_tick':case['source_tick'],'gap_m':case['gap_m'],'health':case['health'],
            'candidate_QP_valid':nom['command_valid'],'initial_new_command_numeric_physical_pass':nom['current_physical_check']['pass'],
            'initial_failure_reasons':nom['current_physical_check']['failure_reasons'],'foot_geometry':foot_hits,
            'front_normal_force_n':{f:initial['contacts'][f]['normal_force_n'] for f in ('FL','FR')},
            'front_friction_margin_n':{f:initial['contacts'][f]['friction_margin_n'] for f in ('FL','FR')}})
        for key in ('preview_shard','candidate_prediction_shard','immediate_prediction_shard'):
            path=d[key]
            if path:
                payload=json.loads((out/path).read_text(encoding='utf-8'));r=payload['result']
                if canonical_hash(r)!=payload['result_hash']: raise ValueError('Branch shard hash mismatch')
                if r['initial_state']['integration_state']!=case['complete_current_integration_state']['vector']: raise ValueError('Prediction did not start from original input clone')
                phase='PREVIEW' if key=='preview_shard' else 'PREDICTION'
                physics[phase]+=r['counts']['physical_steps'];qp_local[phase]+=len(r.get('solver_ledger',[]))
                if key!='preview_shard':
                    if r['fixed_anchor_q_init']!=case['backup_anchor_q_init'] or r['backup_id']!=case['backup_id']: raise ValueError('Prediction anchor/ID changed')
        for method,a in d['actual_methods'].items():
            payload=json.loads((out/a['trajectory_shard']).read_text(encoding='utf-8'));r=payload['result']
            if canonical_hash(r)!=payload['result_hash']: raise ValueError('Actual branch hash mismatch')
            if r['initial_state']['integration_state']!=case['complete_current_integration_state']['vector']: raise ValueError('Actual initial state was prediction terminal or mutated input')
            if not r['kind'].startswith('ACTUAL_') or r['fixed_anchor_q_init']!=case['backup_anchor_q_init'] or r['backup_id']!=case['backup_id']: raise ValueError('Actual branch identity changed')
            physics['ACTUAL']+=r['counts']['physical_steps'];qp_local['ACTUAL']+=len(r['solver_ledger'])
            backup_rows=[x for x in r['controls'] if x['integral_record'] is not None]
            near_count=sum(bool(x['valid_command']) and abs(x['tau_total'][1])>=.99*x['health_vector'][1]*x['physical_at_decision']['actuator_limits'][1]
                for x in r['controls'] if x.get('physical_at_decision'))
            bound_record['actual_valid_control_FR_thigh_99pct_counts'][method]=near_count
            bound_record['any_actual_FR_thigh_99pct']=bound_record['any_actual_FR_thigh_99pct'] or near_count>0
            if backup_rows and backup_rows[0]['integral_record']['b_used']!=[0.]*6: raise ValueError('Nominal integral leaked into backup')
            if r['first_mode']=='CANDIDATE' and r['controls'][0]['tau_total']!=nom['tau']: raise ValueError('First candidate tau changed')
            if any(x['action_source'].startswith('FIXED_CANDIDATE') for x in r['controls'][1:]): raise ValueError('Candidate held after20ms')
            if r['status']=='COMPLETE':
                if r['counts']['physical_steps']!=500 or len(r['controls'])!=50 or [x['physics_step'] for x in r['checkpoints']]!=list(range(0,501,25)):
                    raise ValueError('Full branch schedule/grid mismatch')
            checked.append({'case_id':cid,'method':method,'branch_status':r['status'],'steps':r['counts']['physical_steps'],
                'backup_QP_calls':len(r['solver_ledger']),'original_input_clone':True,'fixed_backup_anchor_ID':True,
                'backup_starts_zero_integral':True,'candidate_first_slot_only':True})
        health_bounds.append(bound_record)
    qp_global=Counter(x['kind'] for x in starts)
    if qp_global['NOMINAL']!=candidate_qp or qp_global['ACTUAL']!=qp_local['ACTUAL'] or qp_global['PREDICTION']!=qp_local['PREDICTION']:
        raise ValueError('Global/per-branch QP ledgers disagree')
    finish=json.loads((out/'RUN_FINISHED.json').read_text())
    if dict(physics)!=finish['budget']['physics_steps_by_kind'] or sum(physics.values())!=s['total_physics_steps']:
        raise ValueError('Integration budget and branch counts disagree')
    if len(checked)!=54 or candidate_qp!=18: raise ValueError('Actual/current candidate coverage mismatch')
    (out/'INITIAL_SCENE_DIAGNOSTICS.json').write_text(json.dumps({'schema':'STEP23_SAVED_INITIAL_SCENE_DIAGNOSTICS_V1',
        'basis':'only saved WBC geometry centres and unchanged scene XML box bounds, no new model forward/solver/integration',
        'boxes':boxes,'cases':geometry,'interpretation':'Geometric overlap diagnostic; retain frozen predicate failures and do not retune/relabel this batch'},
        ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (out/'HEALTH_BOUND_DIAGNOSTICS.json').write_text(json.dumps({'schema':'STEP23_OBSERVED_HEALTH_AUTHORITY_V1',
        'definition':'At least99 percent of current FR_thigh health-scaled torque limit, valid applied command only; same frozen integral authority gate',
        'current_nominal_near_bound_cases':sum(x['current_nominal_FR_thigh_99pct'] for x in health_bounds),
        'any_actual_control_near_bound_cases':sum(x['any_actual_FR_thigh_99pct'] for x in health_bounds),
        'cases':health_bounds},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    validation={'schema':'STEP23_FINAL_SAVED_EVIDENCE_CHECK_V1','status':'PASS','checked_at_utc':datetime.now(timezone.utc).isoformat(),
        'input_cases':18,'actual_attempts':54,'nominal_candidate_QP_calls':candidate_qp,'total_QP_calls':len(starts),
        'all_QP_returned':len(returns)==len(starts),'QP_calls_by_kind':dict(qp_global),'physics_steps_by_kind':dict(physics),
        'total_physics_steps':sum(physics.values()),'no_branch_retries':True,'source_and_model_unchanged':True,
        'actual_clone_policy_and_schedule_checks':checked,'new_QP_or_forward_or_integration_calls':0,
        'command':'python -B -X utf8 -m cavr_wbc.experiments.step23_saved_delivery --output '+str(out)}
    (out/'FINAL_VERIFICATION.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    lines=['','## 初始输入与场景几何：本批为何没有区分实例','',
        '15/18个当前nominal QP返回有效命令，另3个无效；但18/18个新health、新命令后的初始数值物理检查都未通过，失败项为前足normal/friction。'
        '因此本批“当前候选QP与初始物理同时成立”的主机制资格集合为空；15条一步预览也全部失败，M2全部执行未通过horizon认证的best-effort backup。',
        '保存的WBC前足几何中心落在原scene.xml已有箱体的轴对齐范围内。第一箱体中心[1.2,0,0.04]、half-size[0.1,2,0.04]，范围x=[1.1,1.3]、z=[0,0.08]。'
        '例如tick30/gap8mm/health1的FL/FR中心约[1.18594,+0.14479,0.02175]/[1.18587,−0.14038,0.02172]，均在该范围中。'
        '平移虽保留原姿态/速度和原模型，却没有形成预期的“仅平面地面+workspace边界”有效初始挑战。此为保存数据与原几何的直接诊断，不改变本批输入或重分类旧结果。',
        '在该例新命令后，冻结接触事实报告FL/FR normal force约−1007.92/−1009.21 N、friction margin约−757.27/−754.73 N。'
        '这些数值依照既有接触-frame约定保留；它们及几何重叠不支持把结果解释为单纯边界制动对照，也不据此给出全局不可恢复结论。',
        '54条实际分支中17条推进到1秒，37条因后续backup QP未返回有效命令而提前终止；预测33条中11条完整。'
        '全部已经开始的分支均未重试，当前candidate无效时的3个candidate预测和3个一步预览按协议跳过。','',
        '## 实时性与健康约束分列','',
        '首次decision超20 ms数量为M0 16/18、M1 18/18、M2 18/18；M2最大3281.335 ms、平均1772.940 ms。'
        '共享nominal生成、克隆、两条预测、backup求解与采样检查都计入。该离线结果不能宣称20 ms在线恢复。',
        '当前nominal中，tick40、health0.02的三个gap均激发FR_thigh的99% authority门；tick30、health0.02的三个当前candidate无效。'
        '后续backup的限制和求解失败按每状态/方法完整保留。健康挑战已改变命令可行性，但由于全部初始物理资格失败，本批不提供预测筛选收益的实例。',
        f"实际后续控制中，{sum(x['any_actual_FR_thigh_99pct'] for x in health_bounds)}/18 case至少一次有效FR_thigh命令达到99%能力门；逐方法/tick计数见HEALTH_BOUND_DIAGNOSTICS.json。",
        '研究结论保持`NO_DISCRIMINATING_INSTANCE_OBSERVED`；指定backup 18/18未满足采样判据并标记BACKUP_NOT_SCREENED_SAFE。'
        '若继续机制研究，需要先明确平面挑战与保留的场景几何的关系，再冻结新的有效当前输入；本轮不自动改场景、gap、health、PID或重跑。',
        '调用总数核对：nominal18、预测803、实际1231，合计2052；预测积分7960、实际12120、一步预览150，合计20230。'
        '原始求解状态为solved1990、maximum iterations reached29、solved inaccurate31、primal infeasible2；原控制器不把status2当有效命令。','']
    report=out/'MECHANISM_REPORT.md';text=report.read_text(encoding='utf-8')
    marker='\n## 初始输入与场景几何：本批为何没有区分实例';text=text.split(marker)[0]
    report.write_text(text+'\n'.join(lines),encoding='utf-8')
    s['final_verification_status']='PASS'
    s['postprocessing_source_sha256']={str(Path(__file__).relative_to(root)):digest(Path(__file__))}
    s['initial_current_physical_pass_cases']=sum(g['initial_new_command_numeric_physical_pass'] for g in geometry)
    s['scene_box_overlap_cases']=sum(any(f['axis_aligned_scene_box_center_inside'] for f in g['foot_geometry'][:2]) for g in geometry)
    s['health_authority_actual_near_bound_cases']=sum(x['any_actual_FR_thigh_99pct'] for x in health_bounds)
    s['artifact_sha256']={str(p.relative_to(out)):digest(p) for p in out.rglob('*') if p.is_file() and p.name!='EXECUTION_SUMMARY.json'}
    (out/'EXECUTION_SUMMARY.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'saved_evidence':'PASS','cases':18,'actual_branches':54,'total_QP':len(starts),
        'total_steps':sum(physics.values()),'initial_physical_pass_cases':s['initial_current_physical_pass_cases'],
        'scene_overlap_cases':s['scene_box_overlap_cases'],'new_numerical_calls':0}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True)
    finalize(p.parse_args().output.resolve())
