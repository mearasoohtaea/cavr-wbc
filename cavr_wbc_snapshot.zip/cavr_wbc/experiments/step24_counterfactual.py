"""STEP24 unshifted local workspace queries with reusable physical counterfactuals."""
import argparse
from collections import Counter
import gc
import json
import os
from pathlib import Path
import sys
from time import perf_counter
import traceback
import mujoco
import numpy as np

from cavr_wbc.control.step23_backup_filter import run_branch,preview_candidate,HOLD_VERSION
from cavr_wbc.control.step24_local_workspace import (
    VARIANT,GAPS_M,query_decisions,excursion_metrics,mechanism_interval,original_prediction_screen,
)
from cavr_wbc.experiments import step17_formal_panel as frozen
from cavr_wbc.experiments.step21_response import digest,utc,write_json,append
from cavr_wbc.experiments.step23_inputs import restore_case
from cavr_wbc.experiments.step23_one_decision import PilotBudget,BudgetExceeded,branch_store,candidate
from cavr_wbc.experiments.step24_inputs import build_contexts,geometry_qualification
from cavr_wbc.evaluation.step23_actual import evaluate_actual

ROOT=Path(__file__).resolve().parents[2]
PROTOCOL=Path('E:/CAVR-WBC/experiment_handoff_20260921/NEXT_CODEX_INSTRUCTIONS_STEP24_QUALIFIED_LOCAL_WORKSPACE_20261007.md')
SOURCE=ROOT/'artifacts/step22_full_pose_response_20261007/step22-full-pose-response-20261007-01/cases/S22_POSE_PID__S22_HEALTHY_POS/STEP22_CASE_SHARD.json'
METHODS=('M0_QP_CANDIDATE','M1_ONE_STEP_FILTER','M2_HORIZON_FILTER')
NEW_SOURCE=('cavr_wbc/control/step24_local_workspace.py','cavr_wbc/experiments/step24_inputs.py',
    'cavr_wbc/experiments/step24_counterfactual.py','cavr_wbc/experiments/step24_report.py',
    'tests/test_step24_local_workspace.py','tests/test_step24_runner.py')


class LocalBudget(PilotBudget):
    def qp_callback(self,kind,owner,first_mode=None):
        inner=super().qp_callback(kind,owner,first_mode)
        def callback(stage,payload,solve):
            if stage=='before':
                if self.qp_calls>=400: raise BudgetExceeded('STEP24 400 total QP limit')
                if kind=='NOMINAL' and self.qp_counts[kind]>=2: raise BudgetExceeded('STEP24 only two current candidate QPs')
            return inner(stage,payload,solve)
        return callback
    def step_observer(self,kind,owner):
        inner=super().step_observer(kind,owner)
        def before():
            limits={'PREDICTION':2000,'ACTUAL':2000,'PREVIEW':20}
            if self.physics_steps>=4020 or self.step_counts[kind]>=limits[kind]: raise BudgetExceeded('STEP24 integration limit')
            inner()
        return before


def freeze(out,run_id):
    contexts=build_contexts(SOURCE)
    direct=('cavr_wbc/control/step22_pose_servo.py','cavr_wbc/control/step23_backup_filter.py',
        'cavr_wbc/control/step21_contact_reference.py','cavr_wbc/control/e2b_dynamic.py',
        'cavr_wbc/experiments/step17_formal_panel.py','cavr_wbc/evaluation/step23_actual.py',
        'cavr_wbc/experiments/step23_inputs.py','cavr_wbc/experiments/step23_one_decision.py',
        'cavr_wbc/evaluation/step16_independent_evaluator.py','cavr_wbc/platforms/go2_mujoco.py')
    files=direct+NEW_SOURCE
    old=json.loads((ROOT/'artifacts/step23_one_decision_backup_20261007/step23-one-decision-backup-20261007-01/PROTOCOL_AND_MANIFEST.json').read_text(encoding='utf-8'))
    scene=frozen.MODEL_REL;robot=scene.with_name('go2.xml')
    manifest={'schema':'STEP24_PROTOCOL_V1','run_id':run_id,'frozen_at_utc':utc(),
        'client_date':'2026-10-07','client_timezone':'Asia/Seoul','source_commit':'bddff94ba0b3cd9bc2919b13c6b22bba589ac006',
        'protocol':str(PROTOCOL),'protocol_sha256':digest(PROTOCOL),'source_shard':str(SOURCE),'source_shard_sha256':digest(SOURCE),
        'contexts':contexts,'variant':VARIANT,'methods':list(METHODS),'gap_order_m':list(GAPS_M),
        'queries':[{'query_id':c['context_id']+f'_G{int(round(g*1e6)):05d}um','context_id':c['context_id'],
            'gap_m':g,'local_upper_x_m':c['x0_m']+g,'x0_m':c['x0_m'],'health':c['health']} for c in contexts for g in GAPS_M],
        'robot_and_reference_translation':False,'source_tick':40,'health_levels':[1.,.05],
        'global_boundary_x_m':1.,'original_boundary_margin_semantics':'1.0-base_x, unchanged',
        'local_boundary_semantics':'explicit additional task upper bound x0+gap, never passed into PID/WBC/backup',
        'backup_version':HOLD_VERSION,'backup_anchor':'source current base pose, fixed within each context',
        'wbc_config':old['wbc_config'],'frozen_physical_task_limits':old['frozen_physical_task_limits'],
        'independent_evaluator_config':old['independent_evaluator_config'],
        'backup_integral_initial':[0.]*6,'servo_parameters':'unchanged S22_PID192/24/512, original limits/99percent gate',
        'prediction_checkpoints_steps':list(range(0,501,25)),'physics_dt_s':.002,'control_dt_s':.02,'horizon_s':1.,
        'full_branch_steps':500,'full_branch_slots':50,'C_backup_QPs':49,'B_backup_QPs':50,
        'terminal_set':{'anchor_x_abs_error_max_m':.002,'base_x_abs_speed_max_m_s':.001,
            'original_terminal_angles_abs_max_rad':.20,'original_terminal_y_abs_speed_max_m_s':.25},
        'decision_freeze':'all three gap queries in a context stored before either independent actual C/B trajectory',
        'actual_trace_reuse':'one C/B actual counterfactual per qualified health; three gaps/methods reference trace IDs',
        'qualification':'unshifted source alignment + robot/non-ground contacts/distance + new-health nominal QP and numeric physical + local initial margin',
        'unqualified_context':'all3query/9method rows NOT_RUN_INITIAL_UNQUALIFIED; no replacement state or tuning',
        'geometry_distance_API':'mj_geomDistance signed distance, cutoff10m; plane ground contacts/soft penetration retained',
        'interval_formula':{'range_m':[0.,.008],'lower':'max(0,d_step,d_pred_B,d_actual_B)',
            'upper_open':'min(d_pred_C,d_actual_C)','raw':'[lower,upper_open)','intersection':'with closed[0,.008]',
            'original_eligibility_excludes_local_condition':True,'nonworkspace_failure_or_incomplete':'NOT_APPLICABLE'},
        'max_nominal_QPs':2,'max_total_QP_calls':400,'QP_schedule_max_used':398,'unused_QP_allowance_not_probed':2,
        'max_full_prediction_trajectories':4,'max_full_actual_counterfactuals':4,'max_preview_trajectories':2,
        'max_formal_physics_steps':4020,'deadline_ms':20.,'wall_timeout_s':1800,
        'shared_query_latency':'fresh-cost nominal + preview or two full predictions + numerical local selection + selected actual initialization/first backup command, no cache microsecond claim',
        'offline_latency_rule':'deadline miss realtime failure retained; no delayed-action wallclock simulation',
        'source_sha256':{p:digest(ROOT/p) for p in files},
        'model_files_sha256':{str(p):digest(ROOT/p) for p in (scene,robot)},
        'python':sys.executable,'mujoco_version':mujoco.__version__,'TEMP':os.environ.get('TEMP'),'TMP':os.environ.get('TMP'),
        'native_osqp_dll':os.environ.get('CAVR_WBC_NATIVE_OSQP_DLL'),'numerical_retries':0,
        'parameter_or_extra_scenario_search':False,'formal_panel_or_E3_authorized':False,'RL_or_hardware_authorized':False}
    manifest['manifest_hash']=frozen.sha(manifest);write_json(out/'PROTOCOL_AND_MANIFEST.json',manifest)
    frozen._atomic_write_text(out/'PROTOCOL_SOURCE.md',PROTOCOL.read_text(encoding='utf-8'))
    write_json(out/'INPUT_CONTEXTS.json',{'contexts':contexts})
    write_json(out/'WORKSPACE_QUERIES.json',{'queries':manifest['queries']})
    return manifest


def global_annotations(r):
    for row in [r.get('initial_fact')]+r.get('physics_trajectory',[])+r.get('checkpoints',[]):
        if row and 'boundary_margin_m' in row: row['global_boundary_margin_m']=row['boundary_margin_m']
    return r


def actual_query_eval(raw,original,anchor,upper):
    rows=([raw['initial_fact']] if raw.get('initial_fact') else [])+raw['physics_trajectory']
    valid=[r for r in rows if 'qpos' in r]
    margins=[upper-r['qpos'][0] for r in valid]
    complete=raw['status']=='COMPLETE' and raw['counts']['physical_steps']==500
    local_safe=complete and len(valid)==501 and all(v>=0 for v in margins)
    local_end=bool(valid and upper-valid[-1]['qpos'][0]>=0)
    local_failure=[{'time_s':r['time_s'],'local_margin_m':upper-r['qpos'][0]} for r in valid if upper-r['qpos'][0]<0]
    times={round(r['time_s'],9) for r in raw['checkpoints']}
    between=[r for r in local_failure if round(r['time_s'],9) not in times]
    return {'original_physical_safe':original['actual_safe_all_physics_states'],
        'local_workspace_safe':local_safe,'original_terminal_pass_without_local':original['actual_terminal_pass'],
        'terminal_pass':original['actual_terminal_pass'] and local_end,
        'combined_safe_and_terminal':original['actual_safe_all_physics_states'] and local_safe and original['actual_terminal_pass'] and local_end,
        'local_workspace_upper_x_m':upper,'min_local_workspace_margin_m':min(margins,default=None),
        'first_local_workspace_failure':local_failure[0] if local_failure else None,
        'between_checkpoint_local_failure_count':len(between),'original_actual_evaluation':original,
        'incomplete':not complete,'workspace_not_fall':True,
        'local_numeric_sequence':[{'physics_step':r['physics_step'],'time_s':r['time_s'],'base_x_m':r['qpos'][0],
            'boundary_margin_m':r['boundary_margin_m'],'global_boundary_margin_m':r['boundary_margin_m'],
            'local_workspace_upper_x_m':upper,'local_workspace_margin_m':upper-r['qpos'][0]} for r in valid]}


def execute_context(out,m,ctx,budget):
    cid=ctx['context_id'];model=frozen.load_model();current,restore=restore_case(model,ctx)
    if current.qpos.tolist()!=ctx['state']['qpos'] or current.qvel.tolist()!=ctx['state']['qvel']:
        raise ValueError('Unshifted restoration changed source')
    geometry=geometry_qualification(model,current)
    write_json(out/'contexts'/cid/'INITIAL_GEOMETRY.json',geometry)
    if not geometry['pass']: raise ValueError('Input coordinate/geometry error; long branches not dispatched')
    # Compatibility adapter uses the unchanged source reference; no shift is performed.
    nominal=candidate(model,current,{**ctx,'shifted_nominal_q_init':ctx['nominal_q_init']},budget)
    write_json(out/'contexts'/cid/'NOMINAL.json',nominal)
    local_initial=[ctx['x0_m']+g-current.qpos[0]>=0 for g in GAPS_M]
    qualified=geometry['pass'] and nominal['command_valid'] and nominal['current_physical_check']['pass'] and all(local_initial)
    qualification={'context_id':cid,'health':ctx['health'],'source_tick':40,'x0_m':ctx['x0_m'],
        'source_state_untranslated':True,'source_reference_untranslated':True,'geometry':geometry,
        'current_nominal_QP_valid':nominal['command_valid'],'current_nominal_physical_check':nominal['current_physical_check'],
        'initial_local_margins_nonnegative':all(local_initial),'qualified':qualified,
        'status':'QUALIFIED' if qualified else 'NOT_RUN_INITIAL_UNQUALIFIED','restore_info':restore,
        'nominal_generation_ms':nominal['generation_ms']}
    write_json(out/'contexts'/cid/'QUALIFICATION.json',qualification)
    if not qualified:
        result={'context_id':cid,'qualification':qualification,'status':'NOT_RUN_INITIAL_UNQUALIFIED',
            'queries':[{'query_id':cid+f'_G{int(round(g*1e6)):05d}um','gap_m':g,'local_upper':ctx['x0_m']+g,
                'query_status':'NOT_RUN_INITIAL_UNQUALIFIED','method_decisions':{method:{'selected_mode':None,'safety_label':'NOT_RUN_INITIAL_UNQUALIFIED'} for method in METHODS}} for g in GAPS_M],
            'predictions':{},'actual':{},'interval':{'status':'NOT_APPLICABLE','reasons':['INITIAL_UNQUALIFIED']},'budget':budget.snapshot()}
        write_json(out/'contexts'/cid/'RESULT.json',result);return result
    health=np.asarray(ctx['health_vector']);anchor=ctx['backup_anchor_q_init'];bid=ctx['backup_id'];tau=nominal['tau']
    preview,preview_path=branch_store(out,m['run_id'],cid,'PREVIEW','PREVIEW',lambda:
        preview_candidate(model,current,health,tau,bid,cid+':PREVIEW',step_observer=budget.step_observer('PREVIEW',cid+':PREVIEW')))
    pred={};pred_paths={}
    for mode,first in (('C','CANDIDATE'),('B','BACKUP')):
        label='PRED_'+mode
        pred[mode],pred_paths[mode]=branch_store(out,m['run_id'],cid,'PREDICTION',label,lambda:
            global_annotations(run_branch(model,current,health,anchor,bid,first,tau,'PREDICTION_'+mode,cid+':'+label,
                solve_callback=budget.qp_callback('PREDICTION',cid+':'+label,first),step_observer=budget.step_observer('PREDICTION',cid+':'+label))))
    queries=[];select_ms={}
    for gap in GAPS_M:
        begin=perf_counter();q=query_decisions(nominal,preview,pred['C'],pred['B'],anchor,ctx['x0_m'],gap)
        q['query_id']=cid+f'_G{int(round(gap*1e6)):05d}um';select_ms[q['query_id']]=(perf_counter()-begin)*1000
        queries.append(q)
    frozen_decisions={'schema':'STEP24_QUERY_DECISIONS_FROZEN_V1','context_id':cid,'frozen_at_utc':utc(),
        'queries':queries,'decision_hash':frozen.sha(queries),'actual_not_yet_dispatched':True}
    write_json(out/'contexts'/cid/'DECISIONS_FROZEN.json',frozen_decisions)
    actual={};actual_paths={};original={}
    for mode,first in (('C','CANDIDATE'),('B','BACKUP')):
        label='ACTUAL_'+mode
        actual[mode],actual_paths[mode]=branch_store(out,m['run_id'],cid,'ACTUAL',label,lambda:
            global_annotations(run_branch(model,current,health,anchor,bid,first,tau,'ACTUAL_'+mode,cid+':'+label,
                solve_callback=budget.qp_callback('ACTUAL',cid+':'+label,first),step_observer=budget.step_observer('ACTUAL',cid+':'+label))))
        original[mode]=evaluate_actual(actual[mode],anchor)
    method_results=[];query_actual={}
    for q in queries:
        query_actual[q['query_id']]={}
        for mode in ('C','B'):
            evaluated=actual_query_eval(actual[mode],original[mode],anchor,q['local_upper'])
            local_path=Path('contexts')/cid/'queries'/q['query_id']/('ACTUAL_'+mode+'_LOCAL.json')
            write_json(out/local_path,evaluated)
            query_actual[q['query_id']][mode]={k:v for k,v in evaluated.items() if k!='local_numeric_sequence'}
            query_actual[q['query_id']][mode]['local_numeric_shard']=str(local_path)
        for method in METHODS:
            choice=q['method_decisions'][method];mode=choice['selected_mode'];raw=actual[mode]
            evaluated=query_actual[q['query_id']][mode]
            filter_ms=0. if method==METHODS[0] else preview['elapsed_ms'] if method==METHODS[1] else pred['C']['elapsed_ms']+pred['B']['elapsed_ms']
            latency=nominal['generation_ms']+filter_ms+select_ms[q['query_id']]+raw['initialization_ms']+raw['first_backup_decision_ms']
            method_results.append({'query_id':q['query_id'],'method':method,'variant':VARIANT,'gap_m':q['gap_m'],
                'selected_mode':mode,'safety_label':choice['safety_label'],'actual_trace_id':cid+':ACTUAL_'+mode,
                'execution_mode':choice.get('execution_mode','ONE_DECISION_SELECTION'),
                'prediction_reasons':{'C':q['C_screen']['reasons'],'B':q['B_screen']['reasons']} if method==METHODS[2] else None,
                'actual_trace_shard':actual_paths[mode],'backup_id':bid,'decision_latency_ms':latency,
                'deadline_miss':latency>20.,'evaluation':evaluated})
    metrics=excursion_metrics(ctx['x0_m'],preview,pred['C'],pred['B'],actual['C'],actual['B'])
    eligibility={'initial_qualified':qualified,'one_step_original_physical':nominal['current_physical_check']['pass'] and preview['physical_check']['pass']}
    for mode in ('C','B'):
        eligibility['prediction_'+mode+'_original_physical_and_terminal']=original_prediction_screen(pred[mode],anchor)['pass']
        eligibility['actual_'+mode+'_complete_valid_original_physical_and_terminal']=original[mode]['actual_safe_and_terminal']
    interval=mechanism_interval(metrics,eligibility)
    result={'context_id':cid,'status':'CONTEXT_COMPLETED_WITH_RESULTS','qualification':qualification,
        'queries':queries,'decisions_frozen_hash':frozen_decisions['decision_hash'],'method_results':method_results,
        'preview_shard':preview_path,'predictions':pred_paths,'actual':actual_paths,'original_actual_evaluation':original,
        'query_actual_evaluations':query_actual,
        'excursion_metrics':metrics,'interval_eligibility_without_local':eligibility,'interval':interval,
        'elapsed_ms':{'nominal':nominal['generation_ms'],'preview':preview['elapsed_ms'],
            'prediction_C':pred['C']['elapsed_ms'],'prediction_B':pred['B']['elapsed_ms'],
            'actual_C':actual['C']['elapsed_ms'],'actual_B':actual['B']['elapsed_ms']},'budget':budget.snapshot()}
    write_json(out/'contexts'/cid/'RESULT.json',result)
    print(json.dumps({'context_done':cid,'qualified':qualified,'interval':interval,'budget':budget.snapshot()}),flush=True)
    return result


def run(out,run_id):
    batch_begin=perf_counter()
    out=out.resolve();allowed=(ROOT/'artifacts/step24_local_workspace_20261007').resolve()
    if allowed not in out.parents: raise ValueError('STEP24 output must be unique child')
    out.mkdir(parents=True,exist_ok=True)
    if (out/'PROTOCOL_AND_MANIFEST.json').exists(): raise RuntimeError('STEP24 context attempts cannot restart')
    m=freeze(out,run_id);budget=LocalBudget(out);completed=0;error=None
    write_json(out/'RUN_STARTED.json',{'run_id':run_id,'pid':os.getpid(),'timestamp_utc':utc(),'command':sys.argv,'cwd':str(ROOT)})
    try:
        for ctx in m['contexts']:
            append(out/'ATTEMPT_LEDGER.jsonl',{'event':'START','context_id':ctx['context_id'],'run_id':run_id,'timestamp_utc':utc()})
            result=execute_context(out,m,ctx,budget);completed+=1
            append(out/'ATTEMPT_LEDGER.jsonl',{'event':'DONE','context_id':ctx['context_id'],'run_id':run_id,'timestamp_utc':utc(),'status':result['status'],'result_hash':frozen.sha(result)})
            write_json(out/'PROGRESS.json',{'updated_utc':utc(),'completed_contexts':completed,'budget':budget.snapshot()})
            del result;gc.collect()
    except BaseException as exc:
        error={'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()}
        write_json(out/'INTERRUPTION.json',{'timestamp_utc':utc(),'error':error,'budget':budget.snapshot()})
    write_json(out/'RUN_FINISHED.json',{'timestamp_utc':utc(),'completed_contexts':completed,
        'status':'FIXED_CONTEXT_BATCH_COMPLETED' if error is None else 'INTERRUPTED','error':error,
        'true_elapsed_s':perf_counter()-batch_begin,'numerical_work_elapsed_s':perf_counter()-budget.started,
        'reporting_time_excluded':True,'budget':budget.snapshot()})
    from cavr_wbc.experiments.step24_report import report
    report(out)
    if error: raise RuntimeError('STEP24 interrupted; started work not retried')


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--run-id')
    p.add_argument('--summarize',action='store_true');args=p.parse_args()
    if args.summarize:
        from cavr_wbc.experiments.step24_report import report
        report(args.output.resolve())
    else:
        if not args.run_id: p.error('--run-id required')
        run(args.output,args.run_id)
