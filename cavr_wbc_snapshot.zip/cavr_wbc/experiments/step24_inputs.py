"""Untranslated STEP22 tick40 contexts and current geometry qualification."""
from copy import deepcopy
import json
from pathlib import Path
from time import perf_counter
import mujoco
import numpy as np
from cavr_wbc.experiments.step23_inputs import restore_case,integration_state

HEALTH_LEVELS=(1.,.05)
SOURCE_TICK=40


def build_contexts(source_path):
    payload=json.loads(Path(source_path).read_text(encoding='utf-8'));r=payload['result']
    if r['configuration']!='S22_POSE_PID' or r['input_id']!='S22_HEALTHY_POS': raise ValueError('Wrong source episode')
    previous=r['controls'][39]['post_control_state'];current=r['controls'][40]
    if current['tick']!=40 or abs(current['time_s']-.8)>1e-9 or abs(previous['time_s']-.8)>1e-9:
        raise ValueError('Source tick40 clock mismatch')
    for field in ('qpos','qvel'):
        if not np.array_equal(previous[field],current['physical_at_decision'][field]): raise ValueError('Saved post/pre alignment mismatch')
    contexts=[]
    for h in HEALTH_LEVELS:
        state=deepcopy(previous);state['time_s']=0.
        hv=[1.]*12;hv[1]=h
        cid=f'S24_T40_H{int(round(h*1000)):04d}'
        contexts.append({'context_id':cid,'case_id':cid,'source_tick':40,'source_time_s':.8,
            'source_state':deepcopy(previous),'state':state,'health':h,'health_vector':hv,
            'x0_m':state['qpos'][0],'nominal_q_init':deepcopy(r['q_init']),
            'nominal_b_used':deepcopy(current['integral_record']['b_used']),
            'source_external_reference':deepcopy(current['external_reference']),
            'backup_anchor_q_init':deepcopy(state['qpos']),'backup_id':'STEP24-'+cid,
            'source_result_hash':payload['result_hash'],'source_shard':str(source_path),
            'robot_translation_m':0.,'nominal_reference_translation_m':0.,'qpos_qvel_alignment_verified':True})
    return contexts


def geom_info(model,data,g):
    return {'geom_id':int(g),'name':mujoco.mj_id2name(model,mujoco.mjtObj.mjOBJ_GEOM,int(g)),
        'body_id':int(model.geom_bodyid[g]),'type':mujoco.mjtGeom(int(model.geom_type[g])).name,
        'world_position':data.geom_xpos[g].copy().tolist(),'size':model.geom_size[g].copy().tolist(),
        'contype':int(model.geom_contype[g]),'conaffinity':int(model.geom_conaffinity[g])}


def geometry_qualification(model,data):
    begin=perf_counter();before=integration_state(model,data)
    robot=[g for g in range(model.ngeom) if model.geom_bodyid[g]!=0 and (model.geom_contype[g]!=0 or model.geom_conaffinity[g]!=0)]
    static=[g for g in range(model.ngeom) if model.geom_bodyid[g]==0 and (model.geom_contype[g]!=0 or model.geom_conaffinity[g]!=0)]
    ground=[g for g in static if int(model.geom_type[g])==int(mujoco.mjtGeom.mjGEOM_PLANE)]
    obstacles=[g for g in static if g not in ground]
    contacts=[];non_ground=[]
    for k in range(data.ncon):
        c=data.contact[k];g1=int(c.geom1);g2=int(c.geom2)
        if (g1 in robot and g2 in static) or (g2 in robot and g1 in static):
            record={'index':k,'geom1':geom_info(model,data,g1),'geom2':geom_info(model,data,g2),
                'signed_contact_distance_m':float(c.dist),'ground_contact':g1 in ground or g2 in ground}
            contacts.append(record)
            if not record['ground_contact']: non_ground.append(record)
    distances=[];overlap=[];calls=0
    for r in robot:
        for o in obstacles:
            segment=np.zeros(6)
            distance=float(mujoco.mj_geomDistance(model,data,r,o,10.,segment));calls+=1
            record={'robot_geom_id':int(r),'static_geom_id':int(o),'signed_distance_m':distance,
                'distance_upper_cutoff_m':10.,'fromto_world':segment.tolist()}
            distances.append(record)
            if distance<=0.: overlap.append(record)
    after=integration_state(model,data)
    if before!=after: raise ValueError('Geometry query mutated input integration state')
    return {'schema':'STEP24_INITIAL_GEOMETRY_V1','pass':not non_ground and not overlap,
        'robot_collision_geoms':[geom_info(model,data,g) for g in robot],
        'ground_geoms':[geom_info(model,data,g) for g in ground],
        'non_ground_static_geoms':[geom_info(model,data,g) for g in obstacles],
        'robot_static_contacts':contacts,'non_ground_actual_contacts':non_ground,
        'geometry_distances':distances,'non_ground_overlaps_or_touching':overlap,
        'minimum_non_ground_geom_distance_m':min((x['signed_distance_m'] for x in distances),default=None),
        'geometry_distance_calls':calls,'forward_calls':0,'integration_steps':0,
        'input_state_unchanged':True,'elapsed_ms':(perf_counter()-begin)*1000,
        'ground_contact_and_soft_penetration_allowed':True,
        'geometry_distance_api':'mj_geomDistance, signed robot-collision vs non-ground static geom distance'}
