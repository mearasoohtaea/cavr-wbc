"""STEP24 saved-evidence delivery; no simulator, controller or solver import."""
from collections import Counter
from datetime import datetime, timezone
import json
import math
from pathlib import Path

from cavr_wbc.experiments.step21_report import csv_write, digest, canonical_hash


METHODS = ("M0_QP_CANDIDATE", "M1_ONE_STEP_FILTER", "M2_HORIZON_FILTER")
GAPS_M = (.008, .002, .0008)
VARIANT = "STEP24_ADDITIONAL_LOCAL_WORKSPACE_V1"


def _json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)+"\n", encoding="utf-8")


def _compact(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _number(value):
    return isinstance(value, (float, int)) and not isinstance(value, bool) and math.isfinite(value)


def _fmt(value, scale=1., digits=3):
    return f"{value*scale:.{digits}f}" if _number(value) else "—"


def _mark(value):
    return "是" if value is True else "否" if value is False else "未记录"


def _interval_text(interval):
    status = interval.get("status", "NOT_APPLICABLE")
    part = interval.get("intersection_interval")
    if status == "NONEMPTY" and part:
        right = "]" if part.get("upper_inclusive") else ")"
        return f"[{_fmt(part.get('lower_m'),1000,6)}, {_fmt(part.get('upper_m'),1000,6)}{right} mm"
    return "空区间" if status == "EMPTY" else "不适用："+", ".join(interval.get("reasons", ["缺失结果"]))


def _paired_categories(context_id, health, query, evaluations):
    """Classify predeclared paired observations after all decisions are frozen."""
    categories = {}
    choices = query.get("method_decisions", {})
    C, B = evaluations.get("C"), evaluations.get("B")
    if not isinstance(C, dict) or not isinstance(B, dict): return categories
    m1, m2 = choices.get(METHODS[1], {}), choices.get(METHODS[2], {})
    record = {"context_id": context_id, "health": health, "query_id": query.get("query_id"),
              "gap_m": query.get("gap_m"), "M1_selected_mode": m1.get("selected_mode"),
              "M2_selected_mode": m2.get("selected_mode"),
              "C_original_physical_safe": C.get("original_physical_safe"),
              "C_local_workspace_safe": C.get("local_workspace_safe"),
              "C_original_terminal_pass_without_local": C.get("original_terminal_pass_without_local"),
              "B_original_physical_safe": B.get("original_physical_safe"),
              "B_local_workspace_safe": B.get("local_workspace_safe"),
              "B_terminal_pass": B.get("terminal_pass"),
              "B_combined_safe_and_terminal": B.get("combined_safe_and_terminal")}
    if (m1.get("selected_mode") == "C" and C.get("original_physical_safe") is True
            and C.get("local_workspace_safe") is False and m2.get("selected_mode") == "B"
            and B.get("combined_safe_and_terminal") is True):
        categories["fixed_gap_workspace_mechanism_instances"] = [record]
    if (m1.get("selected_mode") == "C" and m2.get("selected_mode") == "B"
            and C.get("combined_safe_and_terminal") is True and B.get("combined_safe_and_terminal") is False):
        categories["reverse_harm"] = [record]
    if m2.get("selected_mode") == "B" and C.get("combined_safe_and_terminal") is True:
        categories["unnecessary_rejections"] = [record]
    if m1.get("selected_mode") == "C" and C.get("combined_safe_and_terminal") is False:
        categories["one_step_acceptance_then_actual_failure"] = [record]
    if m2.get("selected_mode") == "C" and C.get("combined_safe_and_terminal") is False:
        categories["horizon_candidate_acceptance_then_actual_failure"] = [record]
    for mode, evaluation in (("C", C), ("B", B)):
        screen = query.get(mode+"_screen") or {}
        between_local = evaluation.get("between_checkpoint_local_failure_count", 0)
        between_original = (evaluation.get("original_actual_evaluation") or {}).get("between_checkpoint_failure_count", 0)
        if screen.get("pass") is True and evaluation.get("combined_safe_and_terminal") is False:
            item = dict(record, mode=mode, selected_by_M2=m2.get("selected_mode") == mode,
                        between_checkpoint_local_failure_count=between_local,
                        between_checkpoint_original_failure_count=between_original)
            categories.setdefault("sampled_screen_false_acceptance", []).append(item)
            if between_local or between_original:
                categories.setdefault("between_checkpoint_false_acceptance", []).append(item)
        if screen.get("local_workspace_safe") is True and evaluation.get("local_workspace_safe") is False and between_local:
            categories.setdefault("checkpoint_local_peak_missed", []).append(dict(record, mode=mode,
                between_checkpoint_local_failure_count=between_local))
    return categories


def report(out):
    out = Path(out).resolve()
    issues = []
    def read(path, default=None):
        if not path.exists(): return default
        try: return json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            issues.append({"path": str(path.relative_to(out)), "error": type(exc).__name__, "message": str(exc)})
            return default
    def ledger(path):
        if not path.exists(): return []
        rows = []
        try:
            for i, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
                if line.strip():
                    try: rows.append(json.loads(line))
                    except ValueError as exc: issues.append({"path": str(path.relative_to(out)), "line": i, "error": str(exc)})
        except OSError as exc: issues.append({"path": str(path.relative_to(out)), "error": str(exc)})
        return rows
    manifest = read(out/"PROTOCOL_AND_MANIFEST.json")
    if not isinstance(manifest, dict): raise ValueError("STEP24 report needs its saved manifest")
    contexts = manifest.get("contexts", [])
    finish = read(out/"RUN_FINISHED.json", {})
    interruption = read(out/"INTERRUPTION.json")
    attempts = ledger(out/"ATTEMPT_LEDGER.jsonl")
    branch_ledger = ledger(out/"BRANCH_LEDGER.jsonl")
    qp_ledger = ledger(out/"QP_LEDGER.jsonl")
    qualification_rows = []; query_rows = []; method_rows = []; interval_rows = []
    results = {}; qualifications = {}; nominals = {}; queries_by_context = {}
    reference_paths = {}
    categories = {name: [] for name in ("fixed_gap_workspace_mechanism_instances", "reverse_harm",
        "unnecessary_rejections", "one_step_acceptance_then_actual_failure",
        "horizon_candidate_acceptance_then_actual_failure", "sampled_screen_false_acceptance",
        "between_checkpoint_false_acceptance", "checkpoint_local_peak_missed")}
    resource_counts = Counter()
    for ctx in contexts:
        cid = ctx["context_id"]; directory = out/"contexts"/cid
        r = read(directory/"RESULT.json")
        qf = read(directory/"QUALIFICATION.json", {})
        nominal = read(directory/"NOMINAL.json", {})
        if r is not None:
            results[cid] = r
            matches = [x for x in attempts if x.get("event") == "DONE" and x.get("context_id") == cid]
            if matches and matches[-1].get("result_hash") != canonical_hash(r):
                issues.append({"path": str((directory/"RESULT.json").relative_to(out)), "error": "Current RESULT/DONE hash mismatch"})
        qualifications[cid] = qf
        nominals[cid] = nominal
        geometry = qf.get("geometry", {})
        local_status = qf.get("status", "MISSING_QUALIFICATION")
        physics_check = qf.get("current_nominal_physical_check") or {}
        front = [g for g in geometry.get("robot_collision_geoms", []) if g.get("name") in ("FL", "FR")]
        qualification_rows.append({"context_id": cid, "health": ctx.get("health"), "source_tick": 40,
            "x0_m": ctx.get("x0_m"), "status": local_status, "qualified": qf.get("qualified"),
            "source_state_untranslated": qf.get("source_state_untranslated"),
            "source_reference_untranslated": qf.get("source_reference_untranslated"),
            "geometry_pass": geometry.get("pass"),
            "non_ground_contact_count": len(geometry.get("non_ground_actual_contacts", [])) if geometry else None,
            "non_ground_overlap_count": len(geometry.get("non_ground_overlaps_or_touching", [])) if geometry else None,
            "min_non_ground_geometry_distance_m": geometry.get("minimum_non_ground_geom_distance_m"),
            "geometry_distance_calls": geometry.get("geometry_distance_calls"),
            "front_foot_positions_world_m": _compact([{ "name": g.get("name"), "world_position": g.get("world_position")} for g in front]),
            "nominal_command_valid": qf.get("current_nominal_QP_valid"),
            "nominal_physical_pass": physics_check.get("pass"),
            "nominal_physical_reasons": _compact(physics_check.get("failure_reasons", [])),
            "initial_local_margins_nonnegative": qf.get("initial_local_margins_nonnegative"),
            "nominal_generation_ms": qf.get("nominal_generation_ms"),
            "qualification_json": str((directory/"QUALIFICATION.json").relative_to(out))})
        if qf:
            resource_counts["context_model_loads_confirmed"] += 1
            resource_counts["state_restore_forward_calls"] += qf.get("restore_info", {}).get("state_restore_forward_calls", 0)
            resource_counts["geometry_distance_calls"] += geometry.get("geometry_distance_calls", 0)
            resource_counts["geometry_forward_calls"] += geometry.get("forward_calls", 0)
        resource_counts.update({key: value for key, value in nominal.get("counts", {}).items()
                                if key != "nominal_qp_calls"})
        frozen = read(directory/"DECISIONS_FROZEN.json", {})
        saved_queries = r.get("queries", []) if r else frozen.get("queries", [])
        if r and r.get("decisions_frozen_hash"):
            if r["decisions_frozen_hash"] != canonical_hash(r.get("queries", [])):
                issues.append({"path": str((directory/"RESULT.json").relative_to(out)), "error": "Frozen query hash mismatch"})
            if frozen and frozen.get("decision_hash") != r["decisions_frozen_hash"]:
                issues.append({"path": str((directory/"DECISIONS_FROZEN.json").relative_to(out)), "error": "Saved frozen decisions disagree with RESULT"})
        query_map = {q.get("query_id"): q for q in saved_queries}
        queries_by_context[cid] = query_map
        method_map = {(m.get("query_id"), m.get("method")): m for m in (r.get("method_results", []) if r else [])}
        for gap in manifest.get("gap_order_m", GAPS_M):
            query_id = cid+f"_G{int(round(gap*1e6)):05d}um"
            q = query_map.get(query_id)
            if q is None:
                q = {"query_id": query_id, "gap_m": gap, "local_upper": ctx.get("x0_m", 0.)+gap,
                     "query_status": "MISSING_CONTEXT_RESULT", "method_decisions": {}}
            actual_eval = ((r or {}).get("query_actual_evaluations", {}) or {}).get(query_id, {})
            c_screen, b_screen = q.get("C_screen") or {}, q.get("B_screen") or {}
            C, B = actual_eval.get("C") or {}, actual_eval.get("B") or {}
            choices = q.get("method_decisions", {})
            query_rows.append({"context_id": cid, "health": ctx.get("health"), "query_id": query_id,
                "variant": VARIANT, "gap_m": gap, "local_upper_x_m": q.get("local_upper"),
                "query_status": q.get("query_status"), "decision_result_persisted": r is not None,
                "M1_one_step_pass": q.get("step_pass"),
                "C_prediction_original_pass": c_screen.get("original", {}).get("pass"),
                "C_prediction_local_safe": c_screen.get("local_workspace_safe"),
                "C_prediction_combined_screen_pass": c_screen.get("pass"),
                "B_prediction_original_pass": b_screen.get("original", {}).get("pass"),
                "B_prediction_local_safe": b_screen.get("local_workspace_safe"),
                "B_prediction_combined_screen_pass": b_screen.get("pass"),
                "C_prediction_reasons": _compact(c_screen.get("reasons", [])),
                "B_prediction_reasons": _compact(b_screen.get("reasons", [])),
                "M0_selected_mode": choices.get(METHODS[0], {}).get("selected_mode"),
                "M1_selected_mode": choices.get(METHODS[1], {}).get("selected_mode"),
                "M2_selected_mode": choices.get(METHODS[2], {}).get("selected_mode"),
                "M2_safety_label": choices.get(METHODS[2], {}).get("safety_label"),
                "C_actual_original_physical_safe": C.get("original_physical_safe"),
                "C_actual_local_workspace_safe": C.get("local_workspace_safe"),
                "C_actual_original_terminal_pass_without_local": C.get("original_terminal_pass_without_local"),
                "C_actual_terminal_pass": C.get("terminal_pass"),
                "C_actual_combined_safe_and_terminal": C.get("combined_safe_and_terminal"),
                "B_actual_original_physical_safe": B.get("original_physical_safe"),
                "B_actual_local_workspace_safe": B.get("local_workspace_safe"),
                "B_actual_terminal_pass": B.get("terminal_pass"),
                "B_actual_combined_safe_and_terminal": B.get("combined_safe_and_terminal"),
                "C_actual_between_checkpoint_local_failure_count": C.get("between_checkpoint_local_failure_count"),
                "B_actual_between_checkpoint_local_failure_count": B.get("between_checkpoint_local_failure_count")})
            for method in manifest.get("methods", METHODS):
                stored = method_map.get((query_id, method))
                choice = choices.get(method, {})
                not_run = q.get("query_status") == "NOT_RUN_INITIAL_UNQUALIFIED"
                status = "EVALUATED_INCOMPLETE_TRACE" if stored and stored.get("evaluation", {}).get("incomplete") else "EVALUATED_TRACE" if stored else "NOT_RUN_INITIAL_UNQUALIFIED" if not_run else "MISSING_CONTEXT_RESULT"
                evaluation = stored.get("evaluation", {}) if stored else {}
                method_rows.append({"context_id": cid, "health": ctx.get("health"), "query_id": query_id,
                    "variant": VARIANT, "gap_m": gap, "method": method, "status": status,
                    "selected_mode": stored.get("selected_mode") if stored else choice.get("selected_mode"),
                    "safety_label": stored.get("safety_label") if stored else choice.get("safety_label"),
                    "actual_trace_id": stored.get("actual_trace_id") if stored else None,
                    "actual_trace_shard": stored.get("actual_trace_shard") if stored else None,
                    "backup_id": stored.get("backup_id") if stored else ctx.get("backup_id"),
                    "decision_latency_ms": stored.get("decision_latency_ms") if stored else None,
                    "deadline_miss": stored.get("deadline_miss") if stored else None,
                    "original_physical_safe": evaluation.get("original_physical_safe"),
                    "local_workspace_safe": evaluation.get("local_workspace_safe"),
                    "original_terminal_pass_without_local": evaluation.get("original_terminal_pass_without_local"),
                    "terminal_pass": evaluation.get("terminal_pass"),
                    "combined_safe_and_terminal": evaluation.get("combined_safe_and_terminal"),
                    "min_local_workspace_margin_m": evaluation.get("min_local_workspace_margin_m"),
                    "first_local_workspace_failure": _compact(evaluation.get("first_local_workspace_failure")),
                    "between_checkpoint_local_failure_count": evaluation.get("between_checkpoint_local_failure_count"),
                    "original_between_checkpoint_failure_count": evaluation.get("original_actual_evaluation", {}).get("between_checkpoint_failure_count"),
                    "local_numeric_shard": evaluation.get("local_numeric_shard"),
                    "trace_is_reused_for_queries": True})
            for name, items in _paired_categories(cid, ctx.get("health"), q, actual_eval).items(): categories[name].extend(items)
        metrics = (r or {}).get("excursion_metrics", {})
        interval = (r or {}).get("interval") or {"status": "NOT_APPLICABLE", "reasons": ["MISSING_CONTEXT_RESULT"]}
        part = interval.get("intersection_interval") or {}
        interval_rows.append({"context_id": cid, "health": ctx.get("health"), "status": interval.get("status"),
            "reasons": _compact(interval.get("reasons", [])),
            **{key+"_m": metrics.get(key) for key in ("d_step", "d_preview_full", "d_pred_C", "d_pred_B", "d_actual_C", "d_actual_B")},
            "lower_m": interval.get("lower_m"), "upper_open_m": interval.get("upper_open_m"),
            "intersection_lower_m": part.get("lower_m"), "intersection_upper_m": part.get("upper_m"),
            "lower_inclusive": part.get("lower_inclusive"), "upper_inclusive": part.get("upper_inclusive"),
            "is_singleton": part.get("is_singleton"), "width_m": interval.get("width_m"),
            "predicted_minus_actual_required_C_margin_m": metrics.get("d_pred_C")-metrics.get("d_actual_C") if _number(metrics.get("d_pred_C")) and _number(metrics.get("d_actual_C")) else None,
            "predicted_minus_actual_required_B_margin_m": metrics.get("d_pred_B")-metrics.get("d_actual_B") if _number(metrics.get("d_pred_B")) and _number(metrics.get("d_actual_B")) else None,
            "observed_prefix_diagnostics": _compact(metrics.get("observed_prefix_diagnostics", {})),
            "eligibility_without_local": _compact((r or {}).get("interval_eligibility_without_local", {}))})
        if r:
            for mode, path in r.get("predictions", {}).items(): reference_paths[cid+":PRED_"+mode] = path
            for mode, path in r.get("actual", {}).items(): reference_paths[cid+":ACTUAL_"+mode] = path
            if r.get("preview_shard"): reference_paths[cid+":PREVIEW"] = r["preview_shard"]

    starts = {row.get("owner"): row for row in branch_ledger if row.get("event") == "START"}
    ends = {row.get("owner"): row for row in branch_ledger if row.get("event") in ("DONE", "FAILED", "UNKNOWN")}
    owners = list(dict.fromkeys(list(starts)+list(reference_paths)))
    trace_rows = []; verified = []; branch_counts = Counter(); trace_by_id = {}
    for owner in owners:
        start, end = starts.get(owner, {}), ends.get(owner, {})
        cid, label = owner.rsplit(":", 1)
        rel = reference_paths.get(owner) or end.get("shard") or str(Path("cases")/cid/"branches"/(label+".json"))
        payload = read(out/rel)
        raw = payload.get("result") if isinstance(payload, dict) else None
        category = start.get("kind") or "ACTUAL" if label.startswith("ACTUAL") else start.get("kind") or "PREDICTION" if label.startswith("PRED") else "PREVIEW"
        row = {"owner": owner, "context_id": cid, "trace_id": owner,
               "category": category, "raw_kind": raw.get("kind") if raw else None,
               "mode": "C" if label.endswith("_C") else "B" if label.endswith("_B") else None,
               "ledger_state": end.get("event", "START_WITHOUT_FINAL_EVENT"), "shard": rel,
               "status": raw.get("status") if raw else "UNKNOWN_OR_MISSING_RESULT"}
        if raw:
            matches = payload.get("result_hash") == canonical_hash(raw)
            if end.get("result_hash") is not None: matches = matches and end["result_hash"] == payload.get("result_hash")
            verified.append({"owner": owner, "current_result_hash_matches": matches})
            if not matches: issues.append({"path": rel, "error": "Current branch hash mismatch"})
            counts = raw.get("counts", {}); branch_counts.update(counts)
            resource_counts.update({key: val for key, val in counts.items() if key not in ("control_qp_calls", "backup_qp_calls", "physical_steps")})
            controls = raw.get("controls", [])
            facts = ([raw.get("initial_fact")] if raw.get("initial_fact") else [])+raw.get("physics_trajectory", [])
            margins = []; applied_margins = []; exact_active = 0; authority99 = 0
            for control in controls:
                tau = control.get("tau_cmd", []); hv = control.get("health_vector", [])
                limits = (control.get("physical_at_decision") or {}).get("actuator_limits", [])
                if len(tau)>1 and len(hv)>1 and len(limits)>1:
                    margin = hv[1]*limits[1]-abs(tau[1]); margins.append(margin)
                    exact_active += int(margin <= 0.)
                if 1 in (control.get("integral_record") or {}).get("authority_gate_saturated_actuators", []): authority99 += 1
            for fact in facts:
                if fact and all(len(fact.get(key, []))>1 for key in ("tau_cmd", "tau_applied", "health_vector", "actuator_limits")):
                    cap = fact["health_vector"][1]*fact["actuator_limits"][1]
                    margins.append(cap-abs(fact["tau_cmd"][1])); applied_margins.append(cap-abs(fact["tau_applied"][1]))
            row.update(physics_steps=counts.get("physical_steps"),
                recorded_backup_qp_calls=len(raw.get("solver_ledger", [])),
                counts_backup_qp_calls=counts.get("backup_qp_calls"),
                controls=len(controls), checkpoints=len(raw.get("checkpoints", [])),
                clone_data_calls=counts.get("clone_data_calls"),
                action_conditioned_forward_calls=counts.get("action_conditioned_forward_calls"),
                integration_refresh_forward_calls=counts.get("integration_refresh_forward_calls"),
                initialization_ms=raw.get("initialization_ms"), elapsed_ms=raw.get("elapsed_ms"),
                first_backup_decision_ms=raw.get("first_backup_decision_ms"),
                backup_latency_max_ms=max((c.get("latency_ms", 0.) for c in controls), default=None),
                backup_deadline_miss_slots=sum(c.get("latency_ms", 0.)>20. for c in controls),
                min_fr_thigh_command_margin_nm=min(margins, default=None),
                min_fr_thigh_applied_margin_nm=min(applied_margins, default=None),
                fr_thigh_exact_active_or_violated_control_slots=exact_active,
                fr_thigh_99pct_authority_gate_slots=authority99,
                terminal_base_vx_m_s=(raw.get("final_state") or {}).get("qvel", [None])[0],
                sampled_screen_pass=(raw.get("sampled_screen") or {}).get("pass"),
                result_hash_matches=matches)
        trace_rows.append(row); trace_by_id[owner] = row

    qp_starts = [r for r in qp_ledger if r.get("event") == "QP_START"]
    qp_returns = [r for r in qp_ledger if r.get("event") == "QP_RETURN"]
    start_ids = {r.get("global_qp_index") for r in qp_starts}
    return_ids = {r.get("global_qp_index") for r in qp_returns}
    unknown_qp = sorted(start_ids-return_ids)
    if len(qp_starts) != len(start_ids): issues.append({"error": "Duplicate QP_START global indexes"})
    statuses = Counter(str(r.get("status")) for r in qp_returns)
    qp_kind = Counter(r.get("kind") for r in qp_starts)
    budget = finish.get("budget") or (read(out/"PROGRESS.json", {}) or {}).get("budget") or {}
    true_qp = budget.get("total_qp_calls", len(qp_starts))
    true_steps = budget.get("total_physics_steps")
    attempted_counts = Counter(row["category"] for row in trace_rows)
    complete_counts = Counter(row["category"] for row in trace_rows if row["status"] == "COMPLETE")
    actual_ids = {r["actual_trace_id"] for r in method_rows if r.get("actual_trace_id")}
    missing_methods = [r for r in method_rows if r["status"] == "MISSING_CONTEXT_RESULT"]
    known_methods = [r for r in method_rows if r["status"].startswith("EVALUATED_")]
    skipped_methods = [r for r in method_rows if r["status"] == "NOT_RUN_INITIAL_UNQUALIFIED"]
    contexts_done = {r.get("context_id") for r in attempts if r.get("event") == "DONE"}
    execution_complete = bool(finish.get("status") == "FIXED_CONTEXT_BATCH_COMPLETED"
        and len(results) == len(contexts) == 2 and len(contexts_done) == 2 and not missing_methods and not issues)
    state = "COMPLETED" if execution_complete else "INCOMPLETE"
    latency = {}
    for method in METHODS:
        values = [row["decision_latency_ms"] for row in known_methods if row["method"] == method and _number(row["decision_latency_ms"])]
        latency[method] = {"known_query_decisions": len(values), "deadline_misses": sum(v>20. for v in values),
                          "min_ms": min(values, default=None), "max_ms": max(values, default=None)}
    nonempty = [r for r in interval_rows if r["status"] == "NONEMPTY"]
    fixed_instances = categories["fixed_gap_workspace_mechanism_instances"]
    mechanism_result = ("FIXED_GAP_MECHANISM_INSTANCE_OBSERVED" if fixed_instances else
        "ANALYTIC_WORKSPACE_MECHANISM_INTERVAL_OBSERVED" if nonempty else
        "NO_DISCRIMINATING_INSTANCE_OBSERVED" if execution_complete else "INCOMPLETE_OBSERVATION")
    mechanism = {"schema": "STEP24_PAIRED_MECHANISM_OBSERVATIONS_V1", "run_id": manifest.get("run_id"),
        "execution_status": state, "mechanism_result": mechanism_result,
        "fixed_gap_definition": "M1 selects C; C original physical safe and local workspace unsafe; M2 selects B and B combined safe plus terminal",
        "candidate_original_terminal_reported_separately": True, **categories,
        "nonempty_analytic_interval_contexts": nonempty,
        "counts": {key: len(value) for key, value in categories.items()},
        "not_independent_random_repeats": True, "no_additional_solver_or_physics_calls": True}
    _json(out/"MECHANISM_INSTANCES.json", mechanism)
    for name, rows in (("QUALIFICATION_TABLE.csv", qualification_rows), ("QUERY_RESULTS.csv", query_rows),
                       ("METHOD_RESULTS.csv", method_rows), ("TRACE_RESULTS.csv", trace_rows),
                       ("MECHANISM_INTERVALS.csv", interval_rows)): csv_write(out/name, rows)
    qualified = sum(row["qualified"] is True for row in qualification_rows)
    protocol_lines = [f"STEP24 = {state}", f"INITIAL_QUALIFIED_CONTEXTS = {qualified}/2",
        "PHYSICAL_CONTEXTS = 2", "SOURCE_TICK = 40", "ROBOT_AND_NOMINAL_REFERENCE_TRANSLATION = FALSE",
        f"FIXED_WORKSPACE_QUERIES = {len(query_rows)}/6", f"METHOD_RESULT_ROWS = {len(method_rows)}/18",
        f"ACTUAL_COUNTERFACTUAL_TRAJECTORIES_STARTED = {attempted_counts['ACTUAL']}",
        f"ACTUAL_COUNTERFACTUAL_TRAJECTORIES_COMPLETE = {complete_counts['ACTUAL']}",
        f"PREDICTION_TRAJECTORIES_STARTED = {attempted_counts['PREDICTION']}",
        f"PREDICTION_TRAJECTORIES_COMPLETE = {complete_counts['PREDICTION']}",
        f"ONE_STEP_PREVIEWS_STARTED = {attempted_counts['PREVIEW']}",
        f"TRUE_TOTAL_QP_CALLS = {true_qp}/400", f"UNKNOWN_QP_RESERVATIONS = {len(unknown_qp)}",
        f"TRUE_FORMAL_PHYSICS_STEPS = {true_steps if true_steps is not None else 'UNKNOWN'}/4020",
        "CONTROL_DEADLINE_MS = 20", f"M2_FRESH_DECISION_DEADLINE_MISSES = {latency[METHODS[2]]['deadline_misses']}/{latency[METHODS[2]]['known_query_decisions']}",
        f"FIXED_GAP_MECHANISM_INSTANCES = {len(fixed_instances)}", f"NONEMPTY_ANALYTIC_INTERVAL_CONTEXTS = {len(nonempty)}",
        f"MECHANISM_RESULT = {mechanism_result}", "NUMERICAL_RETRIES = 0", "PARAMETER_OR_EXTRA_SCENARIO_SEARCH = FALSE",
        "GLOBAL_AND_PHYSICAL_LIMITS_UNCHANGED = TRUE", "HISTORICAL_RESULTS_UNCHANGED = TRUE",
        "FORMAL_PANEL_OR_E3 = NOT_AUTHORIZED", "RL_OR_HARDWARE = NOT_AUTHORIZED"]
    summary = {"schema": "STEP24_EXECUTION_SUMMARY_V1", "run_id": manifest.get("run_id"), "status": state,
        "client_date": manifest.get("client_date"), "client_timezone": manifest.get("client_timezone"),
        "generated_at_utc": datetime.now(timezone.utc).isoformat(), "mechanism_result": mechanism_result,
        "qualified_contexts": qualified, "expected_contexts": 2, "persisted_context_results": len(results),
        "query_table_rows": len(query_rows), "method_table_rows": len(method_rows),
        "known_evaluated_method_rows": len(known_methods), "not_run_initial_unqualified_method_rows": len(skipped_methods),
        "missing_result_method_rows": len(missing_methods), "unique_method_referenced_actual_trace_ids": sorted(actual_ids),
        "unique_trace_counts_started_or_saved": dict(attempted_counts), "complete_trace_counts": dict(complete_counts),
        "true_elapsed_s": finish.get("true_elapsed_s"), "global_budget": budget,
        "QP_accounting": {"start_events": len(qp_starts), "return_events": len(qp_returns),
            "unknown_global_qp_indices": unknown_qp, "raw_return_status_counts": dict(statuses),
            "calls_by_kind": dict(qp_kind), "real_optimizer_returns": sum(r.get("real_optimizer_called") is True for r in qp_returns),
            "backup_qp_calls_and_control_qp_calls_are_aliases": True, "total_not_sum_of_aliases": true_qp},
        "saved_branch_count_sum_diagnostic": dict(branch_counts), "non_QP_resource_counts": dict(resource_counts),
        "resource_count_semantics": "confirmed saved model/restore/geometry/nominal/unique branches only; UNKNOWN interrupted allocations not invented",
        "method_fresh_latency": latency, "fixed_gap_mechanism_instances": len(fixed_instances),
        "nonempty_interval_contexts": len(nonempty), "paired_category_counts": mechanism["counts"],
        "intervals": [{"context_id": ctx["context_id"], "interval": (results.get(ctx["context_id"]) or {}).get("interval", {"status": "NOT_APPLICABLE", "reasons": ["MISSING_CONTEXT_RESULT"]})} for ctx in contexts],
        "current_output_hash_checks": verified, "delivery_issues": issues, "run_finished": finish,
        "interruption": interruption, "protocol_status_lines": protocol_lines,
        "reporting_only_new_QP_calls": 0, "reporting_only_new_physics_steps": 0,
        "numerical_retries": 0, "parameter_search": False, "historical_results_unchanged": True,
        "E3_authorized": False, "formal_panel_authorized": False}
    heading = "本批固定流程已完成" if execution_complete else "本批交付为 INCOMPLETE，缺失／中断结果保留"
    conclusion = (f"固定三个 gap 观察到 {len(fixed_instances)} 个 workspace 配对机制实例。" if fixed_instances else
                  "固定三个 gap 未观察到符合定义的配对机制实例。" if execution_complete else
                  "已保存部分的机制观察见下表，不能据缺失结果给出完整批次阴性结论。")
    report_lines = ["# STEP24：合格原位初态上的局部 workspace 单次筛选", "", "## Material Passport", "",
        f"experiment-agent／ARS；{manifest.get('client_date','2026-10-07')}（{manifest.get('client_timezone','Asia/Seoul')}）；保存结果描述；Verification Status: ANALYZED。报告新增求解和积分均为 0。", "",
        f"{heading}。初始合格上下文 {qualified}/2；生成 {len(query_rows)} 条查询和 {len(method_rows)} 条方法行，实际启动 {attempted_counts['ACTUAL']} 条独立 C/B 轨迹、完整到达 1 秒 {complete_counts['ACTUAL']} 条。18 条方法行是对同上下文 C/B 轨迹的条件评价。", "",
        conclusion+f"预定义 [0,8 mm] 范围内非空解析机制区间有 {len(nonempty)} 个上下文；不适用和空区间均保留。", "",
        "## 初始资格与 health authority", "", "| health | 资格 | 非地面接触／重叠 | 最小几何距离 mm | 当前 QP／物理 |", "|---|---|---|---:|---|"]
    for row in qualification_rows:
        report_lines.append(f"| {row['health']} | {row['status']} | {row['non_ground_contact_count']}/{row['non_ground_overlap_count']} | {_fmt(row['min_non_ground_geometry_distance_m'],1000)} | {_mark(row['nominal_command_valid'])}/{_mark(row['nominal_physical_pass'])} |")
    report_lines += ["", "机器人与 nominal 参考保持原位置；原 global x≤1 m 单独记录，local_upper=x0+gap 为额外任务约束。原地面接触／软穿入保留。前足及 collision geom、静态箱体位置和距离查询记录在各上下文 QUALIFICATION.json。", "",
        "| health | 模式／种类 | FR_thigh 最小命令余量 N·m | 最小实际余量 N·m | 精确界激活／越界 slots | 99% authority gate slots |", "|---|---|---:|---:|---:|---:|"]
    for row in trace_rows:
        cid = row["context_id"]; health = next((c.get("health") for c in contexts if c["context_id"]==cid), None)
        if row["category"] in ("PREDICTION", "ACTUAL"):
            report_lines.append(f"| {health} | {row['category']} {row['mode']} | {_fmt(row.get('min_fr_thigh_command_margin_nm'),1,6)} | {_fmt(row.get('min_fr_thigh_applied_margin_nm'),1,6)} | {row.get('fr_thigh_exact_active_or_violated_control_slots','—')} | {row.get('fr_thigh_99pct_authority_gate_slots','—')} |")
    report_lines += ["", "99% 积分冻结门与力矩界精确激活分别统计。两种 health 来自同一开发状态，以上数值描述 authority／停止余量，不估计总体健康收益。", "", "## 六个固定查询及配对结果", "",
        "| health | gap mm | M1／M2 选择 | C 原物理／local／终端 | B 原物理／local／终端 | M2 label |", "|---|---:|---|---|---|---|"]
    for row in query_rows:
        report_lines.append(f"| {row['health']} | {_fmt(row['gap_m'],1000,1)} | {row.get('M1_selected_mode')}/{row.get('M2_selected_mode')} | {_mark(row.get('C_actual_original_physical_safe'))}/{_mark(row.get('C_actual_local_workspace_safe'))}/{_mark(row.get('C_actual_terminal_pass'))} | {_mark(row.get('B_actual_original_physical_safe'))}/{_mark(row.get('B_actual_local_workspace_safe'))}/{_mark(row.get('B_actual_terminal_pass'))} | {row.get('M2_safety_label') or row['query_status']} |")
    report_lines += ["", "固定 gap 实例定义：M1 接受 C，C 的原物理安全但 local workspace 越界，M2 选择 B 且 B 全部安全并到达终端。C 原终端资格另列；解析区间还要求 C/B 都通过原终端，未把 local 条件提前放入区间资格。", "",
        "| 配对分类 | 查询／分支观察数 |", "|---|---:|"]
    labels = {"fixed_gap_workspace_mechanism_instances": "固定 gap workspace 机制实例", "reverse_harm": "反向受损",
        "unnecessary_rejections": "不必要拒绝", "one_step_acceptance_then_actual_failure": "一步接受后实际失败",
        "horizon_candidate_acceptance_then_actual_failure": "horizon 接受 C 后实际失败",
        "sampled_screen_false_acceptance": "21 点 screen 通过、实际 combined 未通过",
        "between_checkpoint_false_acceptance": "其中 checkpoint 间出现失败", "checkpoint_local_peak_missed": "21 点 local 未见实际采样间峰值"}
    for name, label in labels.items(): report_lines.append(f"| {label} | {len(categories[name])} |")
    if fixed_instances:
        report_lines += ["", "实例："+"；".join(f"{x['context_id']} / gap {_fmt(x['gap_m'],1000,1)} mm" for x in fixed_instances)+"。"]
    report_lines += ["", "上述分类可重叠，计数不是独立样本或成功率。workspace 越界独立于高度、姿态等原物理失败，不称为实际跌倒。指定 backup 未通过也不代表全局不可恢复。", "", "## 预定义完整 gap 范围", "",
        "| health | d_step／preview 全峰值 mm | pred C／B mm | actual C／B mm | 区间／原因 | 宽度 mm |", "|---|---|---|---|---|---:|"]
    for row in interval_rows:
        interval = (results.get(row["context_id"]) or {}).get("interval") or {"status":"NOT_APPLICABLE","reasons":["MISSING_CONTEXT_RESULT"]}
        report_lines.append(f"| {row['health']} | {_fmt(row['d_step_m'],1000,6)}/{_fmt(row['d_preview_full_m'],1000,6)} | {_fmt(row['d_pred_C_m'],1000,6)}/{_fmt(row['d_pred_B_m'],1000,6)} | {_fmt(row['d_actual_C_m'],1000,6)}/{_fmt(row['d_actual_B_m'],1000,6)} | {_interval_text(interval)} | {_fmt(row.get('width_m'),1000,6)} |")
    report_lines += ["", "一步算法只查 20 ms 端点，额外保留全 10 步峰值；预测余量取 21 点，实际余量取初态和全部 500 步。canonical 全 horizon 余量对不完整分支为缺失，观察前缀仅作显式诊断。区间 lower=max(0,d_step,d_pred_B,d_actual_B)，upper=min(d_pred_C,d_actual_C)，右端开；8 mm 仅截断范围时才闭。未添加 buffer 或新的积分／QP。", "",
        "## 真实调用、轨迹数量与时延", "",
        f"RUN_FINISHED 记录真实总耗时 {_fmt(finish.get('true_elapsed_s'),1,3)} s；总 QP {true_qp}/400，总正式积分 {true_steps if true_steps is not None else 'UNKNOWN'}/4020。QP_RETURN 原始状态：{_compact(dict(statuses))}；未返回预留 {len(unknown_qp)}。backup_qp_calls 与 control_qp_calls 是同义字段，总计以 global budget／QP ledger 为准。", "",
        f"独立轨迹启动数量：prediction {attempted_counts['PREDICTION']}、actual {attempted_counts['ACTUAL']}、preview {attempted_counts['PREVIEW']}；方法行实际引用 {len(actual_ids)} 个唯一 actual trace ID。未完成分支状态和已发生调用保留在 TRACE_RESULTS.csv／原账本。", "",
        "| 方法 | 已记录 fresh decisions | >20 ms | 最小／最大 ms |", "|---|---:|---:|---:|"]
    for method in METHODS:
        value = latency[method]
        report_lines.append(f"| {method} | {value['known_query_decisions']} | {value['deadline_misses']} | {_fmt(value['min_ms'],1,3)}/{_fmt(value['max_ms'],1,3)} |")
    report_lines += ["", "每个 M2 查询的 fresh latency 含 nominal 生成、两条完整 horizon 预测、数值筛选／选择及所选实际执行的初始化／首个 backup 命令。共享物理计算只减少真实调用数，不把缓存查询耗时当作新预测成本。后续实际 backup 单 tick 耗时在 trace 表单列。", "",
        "非 QP 资源计数："+_compact(dict(resource_counts))+"。model／forward／clone／geometry 与纯接口测试计数分开；中断时没有记录的分配不虚构。", "",
        "本批在离线墙钟计算结束后于虚拟 t=0 执行选择；未模拟 deadline miss 导致的延迟动作。即使存在机制实例或区间，也限定为当前状态、指定策略、同模型及采样设置，尚不构成持续反馈、模型失配鲁棒性、部署泛化或 20 ms 在线安全证据。", "",
        "## 文件与协议状态", "",
        "[资格表](QUALIFICATION_TABLE.csv)、[六查询表](QUERY_RESULTS.csv)、[18方法结果](METHOD_RESULTS.csv)、[唯一轨迹表](TRACE_RESULTS.csv)、[余量区间表](MECHANISM_INTERVALS.csv)、[配对实例与反例](MECHANISM_INSTANCES.json)。原始轨迹与 solver／branch ledger 保留；报告不重跑历史核验。", "",
        "```ini", *protocol_lines, "```", ""]
    if issues or missing_methods:
        report_lines += ["交付缺失／证据问题："+_compact(issues)+f"；缺失方法结果 {len(missing_methods)} 行。", ""]
    (out/"MECHANISM_REPORT.md").write_text("\n".join(report_lines), encoding="utf-8")
    names = ("QUALIFICATION_TABLE.csv", "QUERY_RESULTS.csv", "METHOD_RESULTS.csv", "TRACE_RESULTS.csv",
             "MECHANISM_INTERVALS.csv", "MECHANISM_INSTANCES.json", "MECHANISM_REPORT.md")
    summary["derived_artifact_sha256"] = {name: digest(out/name) for name in names}
    _json(out/"EXECUTION_SUMMARY.json", summary)
    return summary
