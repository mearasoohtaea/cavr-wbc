"""Fixed STEP25 saved healthy reassessment and two capacity-fault contexts."""
import argparse
from collections import Counter
from copy import deepcopy
import gc
import json
import os
from pathlib import Path
import sys
from time import perf_counter
import traceback
import mujoco
import numpy as np

from cavr_wbc.experiments import step17_formal_panel as frozen
from cavr_wbc.experiments.step21_response import utc,digest,write_json,append
from cavr_wbc.experiments.step23_inputs import restore_case
from cavr_wbc.experiments.step24_counterfactual import LocalBudget,actual_query_eval
from cavr_wbc.control.step24_local_workspace import query_decisions as old21_query,excursion_metrics as old21_metrics,original_prediction_screen
from cavr_wbc.control.step25_dense_screen import VARIANT,dense_original_screen,dense_query_decisions,excursion_metrics,analyze_range
from cavr_wbc.control.step25_capacity_backup import capacity_command,nominal,run_branch,preview_candidate
from cavr_wbc.evaluation.step25_actual import evaluate_actual
from cavr_wbc.platforms.go2_mujoco import extract_healthy_torque_limits

ROOT=Path(__file__).resolve().parents[2]
OLD=ROOT/'artifacts/step24_local_workspace_20261007/step24-local-workspace-20261007-01'
PROTOCOL=Path('E:/CAVR-WBC/experiment_handoff_20260921/NEXT_CODEX_INSTRUCTIONS_STEP25_DENSE_HEALTH_MECHANISM_20261008.md')
SOURCE_COMMIT='53bbe48bac0df3614b5673bf50190965400ac6ef'
METHODS=('M0_QP_CANDIDATE','M1_ONE_STEP_FILTER','M2_HORIZON_FILTER')
PROBE_GAP=.0005
NEW_SOURCE=('cavr_wbc/control/step25_capacity_backup.py','cavr_wbc/control/step25_dense_screen.py',
    'cavr_wbc/evaluation/step25_actual.py','cavr_wbc/experiments/step25_dense_health.py',
    'cavr_wbc/experiments/step25_report.py','tests/test_step25_capacity.py',
    'tests/test_step25_dense_screen.py','tests/test_step25_runner.py')


def read(path): return json.loads(Path(path).read_text(encoding='utf-8'))


def store_branch(out,run_id,cid,kind,label,function):
    path=out/'cases'/cid/'branches'/(label+'.json');owner=cid+':'+label
    if path.exists(): raise RuntimeError('Refusing single shard overwrite')
    append(out/'BRANCH_LEDGER.jsonl',{'event':'START','owner':owner,'kind':kind,'run_id':run_id,'timestamp_utc':utc()})
    begin=perf_counter()
    try: result=function()
    except BaseException as exc:
        append(out/'BRANCH_LEDGER.jsonl',{'event':'FAILED','owner':owner,'kind':kind,'run_id':run_id,
            'timestamp_utc':utc(),'error':str(exc),'numerical_retry':False})
        raise
    returned_ms=(perf_counter()-begin)*1000
    payload={'schema':'STEP25_BRANCH_SHARD_V1','owner':owner,'kind':kind,'run_id':run_id,'result':result,'result_hash':frozen.sha(result)}
    serialization=perf_counter();encoded=json.dumps(payload,sort_keys=True,separators=(',',':'),allow_nan=False)
    serialization_ms=(perf_counter()-serialization)*1000;writing=perf_counter()
    frozen._atomic_write_text(path,encoded+'\n');write_ms=(perf_counter()-writing)*1000
    timing={'branch_function_return_wall_ms':returned_ms,'serialization_ms':serialization_ms,'atomic_write_ms':write_ms,
        'generator_elapsed_ms':result.get('elapsed_ms'),'timing_scope':'serialization/write outside numerical generation; no differences claimed as isolated kernel timings'}
    append(out/'BRANCH_LEDGER.jsonl',{'event':'DONE','owner':owner,'kind':kind,'run_id':run_id,'timestamp_utc':utc(),
        'status':result['status'],'counts':result['counts'],'shard':str(path.relative_to(out)),'result_hash':payload['result_hash'],'storage_timing':timing})
    write_json(path.with_name(label+'_STORAGE_TIMING.json'),timing)
    return result,str(path.relative_to(out))


def saved_inputs():
    m=read(OLD/'PROTOCOL_AND_MANIFEST.json');ctx=deepcopy(m['contexts'][0]);r=read(OLD/'contexts'/ctx['context_id']/'RESULT.json')
    branches={k:{mode:read(OLD/path)['result'] for mode,path in r[k].items()} for k in ('predictions','actual')}
    return m,ctx,r,branches,read(OLD/r['preview_shard'])['result'],read(OLD/'contexts'/ctx['context_id']/'NOMINAL.json')


def freeze(out,run_id,old,base,healthy_result,branches):
    model=frozen.load_model();limits=extract_healthy_torque_limits(model)
    names=[mujoco.mj_id2name(model,mujoco.mjtObj.mjOBJ_ACTUATOR,j) for j in range(model.nu)]
    mapping=[]
    for j,name in enumerate(names):
        joint=int(model.actuator_trnid[j,0]);mapping.append({'index':j,'name':name,
            'joint_name':mujoco.mj_id2name(model,mujoco.mjtObj.mjOBJ_JOINT,joint),
            'dof_address':int(model.jnt_dofadr[joint]),'healthy_limit_nm':float(limits[j])})
    C=branches['actual']['C'];B=branches['actual']['B']
    peaks={mode:[max(abs(row['tau_cmd'][j]) for row in [branch['initial_fact']]+branch['physics_trajectory'])
        for j in range(model.nu)] for mode,branch in (('C',C),('B',B))}
    contexts=[]
    for name,cid in (('FR_thigh','S25_FR_THIGH_C075'),('FR_calf','S25_FR_CALF_C075')):
        if names.count(name)!=1: raise ValueError('Compiled fault actuator mapping is not unique: '+name)
        j=names.index(name)
        # Actuator identifiers and transmission-joint identifiers are separate
        # compiled namespaces (e.g. FR_thigh -> FR_thigh_joint).
        requested=.75*peaks['C'][j];h=requested/float(limits[j]);hv=[1.]*model.nu;hv[j]=h
        if not 0.<h<1.: raise ValueError('Frozen capacity formula lies outside health bounds')
        c=deepcopy(base);c.pop('health',None)
        c.update(context_id=cid,case_id=cid,faulted_actuator_name=name,faulted_actuator_index=j,
            faulted_health=h,health_vector=hv,legacy_FR_thigh_scalar=hv[1],
            requested_capacity_nm=requested,effective_capacity_nm=float(np.asarray(hv)[j]*limits[j]),
            healthy_C_peak_nm=peaks['C'][j],healthy_B_peak_nm=peaks['B'][j],
            backup_id='STEP25-'+cid,capacity_coefficient=.75)
        contexts.append(c)
    direct=('cavr_wbc/control/step22_pose_servo.py','cavr_wbc/control/step23_backup_filter.py',
        'cavr_wbc/control/e2b_dynamic.py','cavr_wbc/control/step21_contact_reference.py',
        'cavr_wbc/evaluation/step23_actual.py','cavr_wbc/evaluation/step16_independent_evaluator.py')
    manifest={'schema':'STEP25_PROTOCOL_V1','run_id':run_id,'source_commit':SOURCE_COMMIT,'frozen_at_utc':utc(),
        'client_date':'2026-10-08','client_timezone':'Asia/Seoul','variant':VARIANT,
        'protocol':str(PROTOCOL),'protocol_sha256':digest(PROTOCOL),'healthy_source_directory':str(OLD),
        'source_healthy_context_id':base['context_id'],'healthy_baseline_id':'S25_SAVED_HEALTHY',
        'healthy_baseline':'saved data reused only; no newQP/physics','contexts':contexts,'actuator_mapping':mapping,
        'healthy_limits_nm':limits.tolist(),'healthy_saved_C_command_peaks_nm':peaks['C'],'healthy_saved_B_command_peaks_nm':peaks['B'],
        'probe_gap_m':PROBE_GAP,'probe_is_targeted_development':True,'analytic_gap_range_m':[0.,.008],
        'dense_grid_s':.002,'dense_states':501,'report_landmarks':21,'horizon_s':1.,'physics_dt_s':.002,'control_dt_s':.02,
        'methods':list(METHODS),'source_tick':40,'robot_and_nominal_translation':False,
        'wbc_config':old['wbc_config'],'frozen_physical_task_limits':old['frozen_physical_task_limits'],
        'independent_evaluator_config':old['independent_evaluator_config'],
        'backup_version':old['backup_version'],'backup_integral_initial':[0.]*6,'terminal_set':old['terminal_set'],
        'capacity_interface':'onlySolvedfinite raw actuator torque -> clip(raw,-health*healthy_limit,+health*healthy_limit); rawQP/validation never rewritten',
        'fault_recipe':'effective health vector from full precision0.75*savedhealthyC command envelope/healthy limit',
        'geometry_reuse':'same qualified state/reference/model; only new non-ground actual-contact check, no newgeometrydistance scan',
        'new_geometry_distance_calls':0,'freeze_model_loads':1,
        'decision_freeze':'dense predictions only, before either actual trajectory; localbound neverenters controller',
        'interval_original_eligibility_excludes_local_bound':True,
        'latency':'M0its ownchoice;M1ownendpointcheck;M2twofullhorizons+densecheck;allnewnominal+firstactualinit/command;capcostincluded',
        'budget':{'max_new_QP_calls':400,'planned_new_QP_calls':398,'max_new_physics_steps':4020,
            'max_nominal':2,'max_prediction':4,'max_actual':4,'max_preview':2,'wall_timeout_s':1800},
        'source_sha256':{p:digest(ROOT/p) for p in NEW_SOURCE+direct},'model_files_sha256':old['model_files_sha256'],
        'healthy_source_hashes':{str(path.relative_to(OLD)):digest(path) for path in
            [OLD/'PROTOCOL_AND_MANIFEST.json',OLD/'contexts'/base['context_id']/'NOMINAL.json']+
            [OLD/p for k in ('predictions','actual') for p in healthy_result[k].values()]+[OLD/healthy_result['preview_shard']]},
        'python':sys.executable,'mujoco_version':mujoco.__version__,'TEMP':os.environ.get('TEMP'),'TMP':os.environ.get('TMP'),
        'deadline_ms':20.,'numerical_retries':0,'parameter_or_extra_health_search':False,
        'formal_panel_or_E3_authorized':False,'RL_or_hardware_authorized':False}
    manifest['manifest_hash']=frozen.sha(manifest);write_json(out/'PROTOCOL_AND_MANIFEST.json',manifest)
    frozen._atomic_write_text(out/'PROTOCOL_SOURCE.md',PROTOCOL.read_text(encoding='utf-8'))
    return manifest


def geometry_contact_confirmation(model,data,context,old_geometry):
    if data.qpos.tolist()!=context['state']['qpos'] or data.qvel.tolist()!=context['state']['qvel']:
        raise ValueError('STEP25 restoration changed unshifted state')
    contacts=[]
    for k in range(data.ncon):
        c=data.contact[k];a,b=int(c.geom1),int(c.geom2)
        if (model.geom_bodyid[a]==0)!=(model.geom_bodyid[b]==0):
            world=a if model.geom_bodyid[a]==0 else b
            if int(model.geom_type[world])!=int(mujoco.mjtGeom.mjGEOM_PLANE):
                contacts.append({'geom1':a,'geom2':b,'distance_m':float(c.dist)})
    return {'pass':not contacts and old_geometry['pass'],'new_non_ground_contacts':contacts,
        'source_state_and_reference_unshifted':True,'prior_geometry_evidence_reused':True,
        'previous_min_geometry_distance_m':old_geometry['minimum_non_ground_geom_distance_m'],
        'new_geometry_distance_calls':0,'integration_steps':0}


def interval_eligibility(qualified,preview,predictions,original,anchor):
    eligibility={'current_qualified':qualified,'step_original_physical':bool(preview['physical_check']['pass'])}
    screens={mode:dense_original_screen(predictions[mode],anchor) for mode in ('C','B')}
    for mode in ('C','B'):
        eligibility['prediction_'+mode+'_original_safe_and_terminal']=screens[mode]['pass']
        eligibility['actual_'+mode+'_original_safe_and_terminal']=original[mode]['actual_safe_and_terminal']
    return eligibility,screens


def capacity_diagnostics(raw,mapping):
    controls=raw.get('controls',[]);facts=([raw['initial_fact']] if raw.get('initial_fact') else [])+raw.get('physics_trajectory',[])
    channels=[]
    for entry in mapping:
        j=entry['index'];sent=[x['tau_cmd'][j] for x in facts if 'tau_cmd' in x]
        applied=[x['tau_applied'][j] for x in facts if 'tau_applied' in x]
        hv=raw.get('health_vector',facts[0].get('health_vector') if facts else [1.]*len(mapping))
        cap=hv[j]*entry['healthy_limit_nm']
        raw_values=[];clipped=0;raw99=sent99=exact=0
        for x in controls:
            interface=x.get('capacity_interface') or (x.get('servo_response') or {}).get('capacity_interface') or {}
            tau=interface.get('tau_raw',x.get('tau_raw',x.get('tau_cmd')))
            if isinstance(tau,list) and j<len(tau) and isinstance(tau[j],(float,int)):
                raw_values.append(tau[j]);raw99+=int(abs(tau[j])>=.99*cap)
            command=x.get('tau_cmd',[])
            if j<len(command):
                sent99+=int(abs(command[j])>=.99*cap);exact+=int(abs(command[j])==cap)
            mask=interface.get('saturation_mask',[])
            if j<len(mask): clipped+=int(mask[j])
        if not controls:
            raw_values=[x.get('tau_raw',x.get('tau_cmd'))[j] for x in facts if isinstance(x.get('tau_raw',x.get('tau_cmd')),list)
                and len(x.get('tau_raw',x.get('tau_cmd')))>j and isinstance(x.get('tau_raw',x.get('tau_cmd'))[j],(int,float))]
        channels.append({'actuator_index':j,'name':entry['name'],'health':hv[j],'capacity_nm':cap,
            'raw_peak_nm':max(map(abs,raw_values),default=None),'sent_peak_nm':max(map(abs,sent),default=None),
            'applied_peak_nm':max(map(abs,applied),default=None),
            'raw_min_margin_nm':min((cap-abs(x) for x in raw_values),default=None),
            'sent_min_margin_nm':min((cap-abs(x) for x in sent),default=None),
            'applied_min_margin_nm':min((cap-abs(x) for x in applied),default=None),
            'clipped_count':clipped,'exact_active_count':exact,'raw99_count':raw99,'sent99_count':sent99})
    freezes=Counter();updates=0;axis_clips=[0]*6;axis_updates=[0]*6;task_errors=[[] for _ in range(6)]
    for c in controls:
        record=c.get('integral_record') or {};updated=bool(record.get('updated'));updates+=int(updated)
        freezes[str(record.get('freeze_reason'))]+=1
        for k in range(6):
            axis_updates[k]+=int(updated)
            before=record.get('b_before',[0.]*6);after=record.get('b_after',[0.]*6)
            if 'six_axis_clipped' in record: axis_clips[k]+=int(record['six_axis_clipped'][k])
            elif k<len(after) and updated: axis_clips[k]+=int(abs(after[k])==1. and (k>=len(before) or after[k]!=before[k]))
        wb=c.get('solver_raw_result') or {};response=c.get('servo_response') or {}
        execution=c.get('execution_diagnostics') or response.get('execution_diagnostics') or {}
        if execution.get('raw_qp_base_acceleration_error') is not None:
            for k in range(6): task_errors[k].append(execution['raw_qp_base_acceleration_error'][k])
        elif wb.get('qdd') is not None and response.get('a_base_ref') is not None:
            for k in range(6): task_errors[k].append(wb['qdd'][k]-response['a_base_ref'][k])
    axes=[]
    for k,name in enumerate(('x','y','z','roll','pitch','yaw')):
        vals=task_errors[k];axes.append({'axis':name,'unit':'m/s^2' if k<3 else 'rad/s^2',
            'max_abs_raw_qdd_error':max(map(abs,vals),default=None),'mean_raw_qdd_error':sum(vals)/len(vals) if vals else None})
    final=raw.get('final_state',{});initial=raw.get('initial_state',{})
    residuals=[(c.get('execution_diagnostics') or {}).get('sent_dynamics_residual_inf') for c in controls]
    residuals=[v for v in residuals if isinstance(v,(int,float))]
    return {'status':raw.get('status'),'steps':raw.get('counts',{}).get('physical_steps'),
        'QP_calls':raw.get('counts',{}).get('backup_qp_calls',0),'counts':raw.get('counts',{}),
        'timing':raw.get('timing',{}),'elapsed_ms':raw.get('elapsed_ms'),
        'actuator_diagnostics':channels,'task_error_axes':axes,
        'integral_diagnostics':{'update_count':updates,'freeze_reasons':dict(freezes),'axis_clip_counts':axis_clips,'axis_update_counts':axis_updates},
        'sent_execution_algebraic_dynamics_residual_inf_max':max(residuals,default=None),
        'sent_execution_residual_version':'M@raw_qdd+bias_eff-B@tau_sent-Jc.T@raw_lambda; rawqdd notactualacceleration',
        'progress':{'endpoint_dx_m':final.get('qpos',[None])[0]-initial.get('qpos',[0.])[0] if final.get('qpos') and initial.get('qpos') else None,
            'endpoint_vx':final.get('qvel',[None])[0],'complete':raw.get('status')=='COMPLETE'}}


def nominal_diagnostics(n,mapping,context):
    fact=n.get('initial_new_command_fact');response=n.get('response',{});wb=n.get('raw_solver_result') or {}
    synthetic={'controls':[{'tau_cmd':n.get('tau',[]),'tau_raw':n.get('tau_raw'),
        'capacity_interface':n.get('capacity_interface',response.get('capacity_interface')),
        'execution_diagnostics':n.get('execution_diagnostics',response.get('execution_diagnostics')),
        'integral_record':response.get('integral_record'),'servo_response':response,'solver_raw_result':wb}],
        'initial_fact':fact,'physics_trajectory':[],'health_vector':context['health_vector'],
        'status':'CURRENT_COMMAND','counts':n.get('counts',{}),'timing':n.get('timing',{}),'elapsed_ms':n.get('generation_ms')}
    diag=capacity_diagnostics(synthetic,mapping)
    diag.update(raw_solver_status=wb.get('status',n.get('solver_status')),
        raw_solver_status_val=wb.get('status_val',n.get('solver_status_val')),
        raw_QP_validation=n.get('QP_validation',wb.get('validation')),current_executable_command=n.get('command_valid'),
        capacity_interface=n.get('capacity_interface',response.get('capacity_interface')),
        raw_QP_bound_pass=all((r['raw_min_margin_nm'] is not None and r['raw_min_margin_nm']>=0.) for r in diag['actuator_diagnostics']))
    return diag


def build_result(out,m,ctx,n,preview,pred,actual,paths,reused=False,extra=None,frozen_query=None):
    cid=ctx['context_id'];anchor=ctx['backup_anchor_q_init'];x0=ctx['x0_m'];mapping=m['actuator_mapping']
    original={mode:evaluate_actual(actual[mode],anchor,ctx) for mode in ('C','B')}
    query=deepcopy(frozen_query) if frozen_query is not None else dense_query_decisions(n,preview,pred['C'],pred['B'],anchor,x0,PROBE_GAP)
    query['query_id']=cid+'_G00500um';evaluated={mode:actual_query_eval(actual[mode],original[mode],anchor,x0+PROBE_GAP) for mode in ('C','B')}
    methods=[]
    for method in METHODS:
        choice=query['method_decisions'][method];mode=choice['selected_mode'];raw=actual[mode]
        selection_ms=query['timing_by_method_ms'][method]
        filter_ms=0. if method==METHODS[0] else preview['elapsed_ms'] if method==METHODS[1] else pred['C']['elapsed_ms']+pred['B']['elapsed_ms']
        latency=None if reused else n['generation_ms']+filter_ms+selection_ms+raw['initialization_ms']+raw['first_backup_decision_ms']
        e={k:v for k,v in evaluated[mode].items() if k!='local_numeric_sequence'}
        methods.append({'method':method,'variant':VARIANT,'gap_m':PROBE_GAP,'selected_mode':mode,
            'safety_label':choice['safety_label'],'actual_trace_id':actual[mode]['branch_id'],
            'decision_latency_ms':latency,'deadline_miss':latency>20. if latency is not None else None,
            'own_selection_and_check_ms':selection_ms,'latency_status':'SAVED_REASSESSMENT_NOT_FRESH_EXECUTION' if reused else 'FRESH_METHOD_SEPARATE_COST',
            'evaluation':e})
    metrics=excursion_metrics(x0,preview,pred['C'],pred['B'],actual['C'],actual['B'])
    eligible,screens=interval_eligibility(True,preview,pred,original,anchor)
    intervals=analyze_range(metrics,eligible,screens['C'],screens['B'])
    diagnostics=[]
    for category,b in (('PREDICTION',pred),('ACTUAL',actual)):
        for mode,raw in b.items(): diagnostics.append(dict(capacity_diagnostics(raw,mapping),category=category,mode=mode))
    diagnostics.append(dict(capacity_diagnostics(preview,mapping),category='PREVIEW',mode='C'))
    return {'context_id':cid,'metadata':ctx,'status':'SAVED_REASSESSED' if reused else 'CONTEXT_COMPLETED_WITH_RESULTS',
        'qualification':{'qualified':True,'status':'QUALIFIED'},'nominal_diagnostics':nominal_diagnostics(n,mapping,ctx),
        'probe_query':query,'method_results':methods,'query_actual_evaluations':{mode:{k:v for k,v in e.items() if k!='local_numeric_sequence'} for mode,e in evaluated.items()},
        'excursion_metrics':metrics,'range_analysis':intervals,'interval_eligibility':eligible,
        'original_actual_evaluation':original,'branch_diagnostics':diagnostics,'reused_saved_data':reused,
        **paths,**(extra or {})}


def reassess_healthy(out,m,base,r,branches,preview,n):
    begin=perf_counter();mapping=m['actuator_mapping'];limits=np.asarray(m['healthy_limits_nm']);commands=0;maxdelta=0.
    for kind in ('predictions','actual'):
        for raw in branches[kind].values():
            for c in raw['controls']:
                status=(c.get('solver_raw_result') or {}).get('status_val',n['solver_status_val'])
                interface=capacity_command(c['tau_cmd'],[1.]*len(limits),limits,status)
                sent=np.clip(np.asarray(c['tau_cmd']),-limits,limits)
                delta=float(np.max(np.abs(sent-np.asarray(c['tau_cmd']))));commands+=1;maxdelta=max(maxdelta,delta)
                if not interface['command_valid'] or status!=1 or delta!=0.: raise ValueError('Saved healthy interface is not aSolvedfinite identity')
            for f in [raw['initial_fact']]+raw['physics_trajectory']:
                if not np.isfinite(f['tau_cmd']).all() or np.any(np.abs(f['tau_cmd'])>limits):
                    raise ValueError('Saved healthy physics command exceeds healthy limit')
    ctx=deepcopy(base);ctx.pop('health',None);ctx.update(context_id='S25_SAVED_HEALTHY',
        faulted_actuator_name='NONE',faulted_actuator_index=None,faulted_health=1.,legacy_FR_thigh_scalar=1.)
    n=deepcopy(n);n['raw_solver_result']=n.get('raw_solver_result',{'status':n['solver_status'],'status_val':n['solver_status_val'],
        'tau':n['tau'],'qdd':n.get('qdd'),'contact_force':n.get('contact_lambda'),'success':n['command_valid'],'validation':n['QP_validation']})
    n['tau_raw']=n['tau']
    n['capacity_interface']=capacity_command(n['tau'],ctx['health_vector'],limits,n['solver_status_val'])
    if not n['capacity_interface']['command_valid'] or any(n['capacity_interface']['saturation_mask']):
        raise ValueError('Saved healthy nominal interface is not identity')
    commands+=1
    pred=branches['predictions'];actual=branches['actual'];anchor=ctx['backup_anchor_q_init']
    oldmetrics=old21_metrics(ctx['x0_m'],preview,pred['C'],pred['B'],actual['C'],actual['B'])
    oldquery=old21_query(n,preview,pred['C'],pred['B'],anchor,ctx['x0_m'],PROBE_GAP)
    orig={mode:evaluate_actual(actual[mode],anchor,ctx) for mode in ('C','B')}
    oldscreens={mode:original_prediction_screen(pred[mode],anchor) for mode in ('C','B')}
    eligibility={'current_qualified':True,'step_original_physical':preview['physical_check']['pass'],
        **{'prediction_'+mode+'_original_safe_and_terminal':oldscreens[mode]['pass'] for mode in ('C','B')},
        **{'actual_'+mode+'_original_safe_and_terminal':orig[mode]['actual_safe_and_terminal'] for mode in ('C','B')}}
    oldrange=analyze_range(oldmetrics,eligibility,oldscreens['C'],oldscreens['B'])
    result=build_result(out,m,ctx,n,preview,pred,actual,{'predictions':r['predictions'],'actual':r['actual'],
        'preview_shard':r['preview_shard'],'trajectory_paths_relative_to':str(OLD)},True,
        {'healthy_interface_identity':{'pass':True,'commands_checked':commands,'max_correction_nm':maxdelta},
         'saved_dense_comparison':{'old21_metrics':oldmetrics,'old21_probe_query':oldquery,'old21_range_analysis':oldrange},
         'saved_STEP24_wrapper_method_timings':r['method_results'],'new_QP_calls':0,'new_physics_steps':0})
    result['saved_reassessment_elapsed_ms']=(perf_counter()-begin)*1000
    write_json(out/'HEALTHY_SAVED_REASSESSMENT.json',result)
    return result


def execute_context(out,m,ctx,budget,oldgeo):
    cid=ctx['context_id'];model=frozen.load_model();current,restore=restore_case(model,ctx)
    geometry=geometry_contact_confirmation(model,current,ctx,oldgeo)
    if not geometry['pass']: raise ValueError('New non-ground contact or changed initial state')
    n=nominal(model,current,ctx,solve_callback=budget.qp_callback('NOMINAL',cid+':NOMINAL'))
    write_json(out/'contexts'/cid/'NOMINAL.json',n)
    diag=nominal_diagnostics(n,m['actuator_mapping'],ctx)
    qualified=bool(n['command_valid'] and n['current_physical_check']['pass'])
    qualification={'qualified':qualified,'status':'QUALIFIED' if qualified else 'NOT_RUN_INITIAL_UNQUALIFIED',
        'geometry_confirmation':geometry,'restore_info':restore,'current_physical_check':n['current_physical_check'],
        'current_executable_command':n['command_valid'],'raw_QP_bound_pass':diag['raw_QP_bound_pass'],
        'raw_QP_validation':diag['raw_QP_validation'],'faulted_actuator_name':ctx['faulted_actuator_name'],
        'faulted_actuator_index':ctx['faulted_actuator_index'],'health_vector':ctx['health_vector']}
    write_json(out/'contexts'/cid/'QUALIFICATION.json',qualification)
    if not qualified:
        result={'context_id':cid,'metadata':ctx,'status':'NOT_RUN_INITIAL_UNQUALIFIED','qualification':qualification,
            'nominal_diagnostics':diag,'branch_diagnostics':[],'predictions':{},'actual':{},'excursion_metrics':{},
            'range_analysis':{'mechanism_interval':{'status':'NOT_APPLICABLE','reasons':['INITIAL_UNQUALIFIED']}},
            'method_results':[{'method':method,'variant':VARIANT,'gap_m':PROBE_GAP,'selected_mode':None,
                'status':'NOT_RUN_INITIAL_UNQUALIFIED','safety_label':'NOT_RUN_INITIAL_UNQUALIFIED','evaluation':{}} for method in METHODS],
            'budget':budget.snapshot()}
        write_json(out/'contexts'/cid/'RESULT.json',result);return result
    hv=np.asarray(ctx['health_vector']);anchor=ctx['backup_anchor_q_init'];bid=ctx['backup_id']
    preview,path=store_branch(out,m['run_id'],cid,'PREVIEW','PREVIEW',lambda:preview_candidate(model,current,hv,n,bid,cid+':PREVIEW',step_observer=budget.step_observer('PREVIEW',cid+':PREVIEW')))
    pred={};predpaths={};actual={};actpaths={}
    for mode,first in (('C','CANDIDATE'),('B','BACKUP')):
        label='PRED_'+mode
        pred[mode],predpaths[mode]=store_branch(out,m['run_id'],cid,'PREDICTION',label,lambda:run_branch(model,current,hv,anchor,bid,first,n,'PREDICTION_'+mode,cid+':'+label,
            solve_callback=budget.qp_callback('PREDICTION',cid+':'+label,first),step_observer=budget.step_observer('PREDICTION',cid+':'+label)))
    q=dense_query_decisions(n,preview,pred['C'],pred['B'],anchor,ctx['x0_m'],PROBE_GAP)
    q['query_id']=cid+'_G00500um'
    write_json(out/'contexts'/cid/'DECISION_FROZEN.json',{'query':q,'decision_hash':frozen.sha(q),'timestamp_utc':utc(),'before_actual_dispatch':True})
    for mode,first in (('C','CANDIDATE'),('B','BACKUP')):
        label='ACTUAL_'+mode
        actual[mode],actpaths[mode]=store_branch(out,m['run_id'],cid,'ACTUAL',label,lambda:run_branch(model,current,hv,anchor,bid,first,n,'ACTUAL_'+mode,cid+':'+label,
            solve_callback=budget.qp_callback('ACTUAL',cid+':'+label,first),step_observer=budget.step_observer('ACTUAL',cid+':'+label)))
    result=build_result(out,m,ctx,n,preview,pred,actual,{'preview_shard':path,'predictions':predpaths,'actual':actpaths},frozen_query=q)
    if frozen.sha(q)!=frozen.sha(result['probe_query']):
        raise ValueError('Frozen prediction decision changed')
    result['probe_query']=q;result['decision_frozen_hash']=frozen.sha(q)
    for row in result['method_results']:
        method=row['method'];mode=row['selected_mode'];a=actual[mode]
        filter_ms=0. if method==METHODS[0] else preview['elapsed_ms'] if method==METHODS[1] else pred['C']['elapsed_ms']+pred['B']['elapsed_ms']
        row['own_selection_and_check_ms']=q['timing_by_method_ms'][method]
        row['decision_latency_ms']=n['generation_ms']+filter_ms+q['timing_by_method_ms'][method]+a['initialization_ms']+a['first_backup_decision_ms']
        row['deadline_miss']=row['decision_latency_ms']>20.
    result.update(qualification=qualification,nominal_diagnostics=diag,budget=budget.snapshot())
    write_json(out/'contexts'/cid/'RESULT.json',result)
    print(json.dumps({'context_done':cid,'qualified':qualified,'budget':budget.snapshot(),'range':result['range_analysis']}),flush=True)
    return result


def run(out,run_id):
    started=perf_counter();out=out.resolve();allowed=(ROOT/'artifacts/step25_dense_health_20261008').resolve()
    if allowed not in out.parents: raise ValueError('New output must be a unique STEP25 child')
    out.mkdir(parents=True,exist_ok=True)
    if (out/'PROTOCOL_AND_MANIFEST.json').exists(): raise RuntimeError('This numerical batch cannot restart')
    old,base,r,branches,preview,n=saved_inputs();m=freeze(out,run_id,old,base,r,branches)
    budget=LocalBudget(out);completed=0;error=None
    write_json(out/'RUN_STARTED.json',{'run_id':run_id,'pid':os.getpid(),'timestamp_utc':utc(),'command':sys.argv,'cwd':str(ROOT)})
    try:
        reassess_healthy(out,m,base,r,branches,preview,n)
        del branches,preview,n;gc.collect()
        oldgeo=read(OLD/'contexts'/base['context_id']/'QUALIFICATION.json')['geometry']
        for ctx in m['contexts']:
            append(out/'ATTEMPT_LEDGER.jsonl',{'event':'START','context_id':ctx['context_id'],'timestamp_utc':utc(),'run_id':run_id})
            result=execute_context(out,m,ctx,budget,oldgeo);completed+=1
            append(out/'ATTEMPT_LEDGER.jsonl',{'event':'DONE','context_id':ctx['context_id'],'timestamp_utc':utc(),'run_id':run_id,'result_hash':frozen.sha(result)})
            write_json(out/'PROGRESS.json',{'updated_utc':utc(),'completed_new_contexts':completed,'budget':budget.snapshot()})
            del result;gc.collect()
    except BaseException as exc:
        error={'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()}
        write_json(out/'INTERRUPTION.json',{'timestamp_utc':utc(),'error':error,'budget':budget.snapshot()})
    write_json(out/'RUN_FINISHED.json',{'status':'FIXED_BATCH_COMPLETED' if error is None else 'INTERRUPTED',
        'completed_new_contexts':completed,'timestamp_utc':utc(),'error':error,'true_elapsed_s':perf_counter()-started,
        'budget':budget.snapshot(),'freeze_model_loads':1,'context_model_loads':completed,
        'geometry_distance_calls':0,'healthy_new_QP_calls':0,'healthy_new_physics_steps':0})
    from cavr_wbc.experiments.step25_report import report
    report(out)
    if error: raise RuntimeError('Started numerical work not retried')


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--run-id',required=True)
    args=p.parse_args();run(args.output,args.run_id)
