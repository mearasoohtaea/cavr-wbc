"""STEP25 saved-only delivery: no model, controller, solver or physics imports."""
from collections import Counter
from datetime import datetime, timezone
import json
import math
from pathlib import Path

from cavr_wbc.experiments.step21_report import csv_write, digest


METHODS = ("M0_QP_CANDIDATE", "M1_ONE_STEP_FILTER", "M2_HORIZON_FILTER")


def _compact(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _fmt(value, scale=1., digits=6):
    return f"{value*scale:.{digits}f}" if isinstance(value, (float, int)) and not isinstance(value, bool) and math.isfinite(value) else "—"


def _mark(value):
    return "是" if value is True else "否" if value is False else "未记录"


def _interval(value):
    if not isinstance(value, dict): return "未记录"
    part = value.get("intersection_interval") or value
    lower = part.get("lower_m", part.get("lower")); upper = part.get("upper_m", part.get("upper"))
    if value.get("status") == "EMPTY": return "空区间"
    if lower is None or upper is None: return "不适用：" + ", ".join(value.get("reasons", []))
    return ("[" if part.get("lower_inclusive", True) else "(") + _fmt(lower, 1000) + ", " + _fmt(upper, 1000) + ("]" if part.get("upper_inclusive", False) else ")") + " mm"


def _cell(value):
    return _compact(value) if isinstance(value, (dict, list)) else value


def report(out):
    out = Path(out).resolve(); issues = []
    def read(name, default=None):
        path = out/name
        if not path.exists(): return default
        try: return json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            issues.append({"path": str(name), "error": str(exc)}); return default
    def ledger(name):
        path = out/name
        if not path.exists(): return []
        rows = []
        for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            if line.strip():
                try: rows.append(json.loads(line))
                except ValueError as exc: issues.append({"path": name, "line": number, "error": str(exc)})
        return rows
    manifest = read("PROTOCOL_AND_MANIFEST.json")
    if not isinstance(manifest, dict): raise ValueError("STEP25 report requires its saved manifest")
    healthy = read("HEALTHY_SAVED_REASSESSMENT.json", {})
    fault_results = [read(Path("contexts")/c["context_id"]/"RESULT.json", {}) for c in manifest.get("contexts", [])]
    for context, result in zip(manifest.get("contexts", []), fault_results):
        if not result: issues.append({"context_id": context["context_id"], "error": "MISSING_CONTEXT_RESULT"})
    results = [healthy, *fault_results]
    finish = read("RUN_FINISHED.json", {}); qp = ledger("QP_LEDGER.jsonl"); branches = ledger("BRANCH_LEDGER.jsonl")
    probe_rows = []; qualification_rows = []; interval_rows = []; actuator_rows = []; task_rows = []; integral_rows = []; timing_rows = []; progress_rows = []
    for result in results:
        if not result: continue
        cid = result["context_id"]; metadata = result.get("metadata", {})
        base = {"context_id": cid, "reused_saved_data": result.get("reused_saved_data", False),
                "faulted_actuator_name": metadata.get("faulted_actuator_name"), "faulted_actuator_index": metadata.get("faulted_actuator_index"),
                "faulted_health": metadata.get("faulted_health"), "health_vector": _cell(metadata.get("health_vector")),
                "requested_capacity_nm": metadata.get("requested_capacity_nm"), "effective_capacity_nm": metadata.get("effective_capacity_nm")}
        qualification = result.get("qualification", {})
        if not base["reused_saved_data"]:
            qualification_rows.append({**base, **{k: _cell(v) for k, v in qualification.items()}})
        methods = result.get("method_results", [])
        if not methods:
            methods = [{"method": method, "status": "NOT_RUN_INITIAL_UNQUALIFIED" if qualification else "MISSING_CONTEXT_RESULT"} for method in METHODS]
        for method in methods:
            row = {**base, **{k: _cell(v) for k, v in method.items() if k != "evaluation"}}
            row.update({k: _cell(v) for k, v in (method.get("evaluation") or {}).items()}); probe_rows.append(row)
        metrics = result.get("excursion_metrics", {}); analysis = result.get("range_analysis", {})
        interval_rows.append({**base, **{k: _cell(v) for k, v in metrics.items()}, **{k: _cell(v) for k, v in analysis.items()},
                              "mechanism_interval_text": _interval(analysis.get("mechanism_interval"))})
        diagnostics = [{"category": "NOMINAL", "mode": "NOMINAL", **(result.get("nominal_diagnostics") or {})}, *result.get("branch_diagnostics", [])]
        for diagnostic in diagnostics:
            identity = {**base, "category": diagnostic.get("category"), "mode": diagnostic.get("mode"), "status": diagnostic.get("status")}
            actuator_rows.extend({**identity, **item} for item in diagnostic.get("actuator_diagnostics", []))
            task_rows.extend({**identity, **item} for item in diagnostic.get("task_error_axes", []))
            integral = diagnostic.get("integral_diagnostics", {})
            if integral: integral_rows.append({**identity, **{k: _cell(v) for k, v in integral.items()}})
            progress = diagnostic.get("progress", {})
            if progress: progress_rows.append({**identity, **progress})
            timing = diagnostic.get("timing", {})
            if timing: timing_rows.append({**identity, "steps": diagnostic.get("steps"), "QP_calls": diagnostic.get("QP_calls"), **{k: _cell(v) for k, v in timing.items()}})
    starts = [x for x in qp if x.get("event") == "QP_START"]; returns = [x for x in qp if x.get("event") == "QP_RETURN"]
    started = {x.get("owner"): x.get("kind") for x in branches if x.get("event") == "START"}
    done = {x.get("owner"): x for x in branches if x.get("event") == "DONE"}
    new_started = Counter(started.values()); new_complete = Counter(started[owner] for owner, row in done.items() if owner in started and row.get("status") == "COMPLETE")
    saved_counts = Counter()
    for row in done.values(): saved_counts.update(row.get("counts", {}))
    resources=Counter({key:val for key,val in saved_counts.items() if key not in ('physical_steps','backup_qp_calls','control_qp_calls')})
    for result in fault_results:
        resources.update({key:val for key,val in result.get('nominal_diagnostics',{}).get('counts',{}).items() if key!='nominal_qp_calls'})
    resources['freeze_model_loads']=finish.get('freeze_model_loads',0)
    resources['context_model_loads']=finish.get('context_model_loads',0)
    resources['pre_freeze_implementation_error_model_loads']=read('PREFREEZE_ERROR_01.json',{}).get('new_model_loads',0)
    resources['state_restore_forward_calls']=sum(result.get('qualification',{}).get('restore_info',{}).get('state_restore_forward_calls',0) for result in fault_results)
    for owner,row in done.items():
        if row.get('storage_timing'): timing_rows.append({'context_id':owner.split(':')[0],'category':'STORAGE','mode':owner.split(':')[-1],**row['storage_timing']})
    for result in results:
        for method in result.get('method_results',[]):
            if method.get('own_selection_and_check_ms') is not None:
                timing_rows.append({'context_id':result['context_id'],'category':'DECISION_SCREEN','mode':method['method'],
                    'screen_and_selection_ms':method['own_selection_and_check_ms'],'reused_saved_data':result.get('reused_saved_data',False)})
    budget = finish.get("budget") or read("PROGRESS.json", {}).get("budget", {})
    total_qp = budget.get("total_qp_calls", len(starts)); total_steps = budget.get("total_physics_steps", saved_counts.get("physical_steps"))
    unknown_qp = sorted({x.get("global_qp_index") for x in starts} - {x.get("global_qp_index") for x in returns})
    latency = {}
    for method in METHODS:
        values = [row.get("decision_latency_ms") for row in probe_rows if row.get("method") == method and not row["reused_saved_data"] and isinstance(row.get("decision_latency_ms"), (float, int))]
        latency[method] = {"fresh_decisions": len(values), "deadline_misses": sum(value > 20 for value in values), "min_ms": min(values, default=None), "max_ms": max(values, default=None)}
    complete = bool(finish.get('status')=='FIXED_BATCH_COMPLETED' and len(fault_results) == 2 and all(fault_results) and healthy and len(probe_rows) == 9 and not issues and not unknown_qp)
    state = "COMPLETED" if complete else "INCOMPLETE"
    summary = {"schema": "STEP25_EXECUTION_SUMMARY_V1", "run_id": manifest.get("run_id"), "status": state,
               "generated_at_utc": datetime.now(timezone.utc).isoformat(), "run_finished": finish,
               "qualified_new_contexts": sum(r.get("qualification", {}).get("qualified") is True for r in fault_results),
               "healthy_saved_reassessment_new_QP_calls": 0, "healthy_saved_reassessment_new_physics_steps": 0,
               "probe_rows": len(probe_rows), "probe_is_targeted_development_check": True,
               "new_branches_started": dict(new_started), "new_complete_branches": dict(new_complete),
               "unique_method_selected_actual_trace_ids": sorted({row["actual_trace_id"] for row in probe_rows if row.get("actual_trace_id")}),
               "QP_accounting": {"starts": len(starts), "returns": len(returns), "unknown_global_qp_indices": unknown_qp,
                                 "status_counts": dict(Counter(str(x.get("status")) for x in returns)), "calls_by_kind": dict(Counter(x.get("kind") for x in starts))},
               "true_total_new_QP_calls": total_qp, "true_total_new_physics_steps": total_steps, "global_budget": budget,
               "saved_new_branch_resource_counts": dict(saved_counts), "new_non_QP_resource_counts":dict(resources),"method_fresh_latency": latency,
               "reporting_new_QP_calls": 0, "reporting_new_physics_steps": 0, "delivery_issues": issues,
               "numerical_retries": 0, "extra_health_or_actuator_search": False, "historical_results_unchanged": True,
               "TRO_submission_ready": False, "E3_authorized": False}
    healthy_metrics = healthy.get("excursion_metrics", {}); capacity_rows = []
    for row in interval_rows:
        comparison = {k: row.get(k) for k in ("context_id", "faulted_actuator_name", "faulted_health", "requested_capacity_nm", "effective_capacity_nm", "mechanism_interval_text")}
        for mode in ("C", "B"):
            value = row.get("d_actual_"+mode); reference = healthy_metrics.get("d_actual_"+mode)
            comparison["actual_"+mode+"_maximum_excursion_m"] = value
            comparison["actual_"+mode+"_excursion_change_from_healthy_m"] = value-reference if isinstance(value, (float, int)) and isinstance(reference, (float, int)) else None
            for name in ("FR_thigh", "FR_calf"):
                diagnostic = next((item for item in actuator_rows if item["context_id"] == row["context_id"] and item["category"] == "ACTUAL" and item["mode"] == mode and item.get("name") == name), {})
                for key in ("capacity_nm", "raw_peak_nm", "sent_peak_nm", "applied_min_margin_nm", "clipped_count", "exact_active_count", "sent99_count"):
                    comparison[mode+"_"+name+"_"+key] = diagnostic.get(key)
        capacity_rows.append(comparison)
    tables = {"PROBE_RESULTS.csv": probe_rows, "QUALIFICATION_TABLE.csv": qualification_rows, "INTERVAL_RESULTS.csv": interval_rows, "CAPACITY_COMPARISON.csv": capacity_rows,
              "ALL_ACTUATOR_DIAGNOSTICS.csv": actuator_rows, "TASK_ACCEL_ERRORS.csv": task_rows,
              "INTEGRAL_DIAGNOSTICS.csv": integral_rows, "TIMING.csv": timing_rows, "TRAJECTORY_PROGRESS.csv": progress_rows}
    for name, rows in tables.items(): csv_write(out/name, rows)
    lines = ["# STEP25：密集离散筛选与需求归一化能力损伤", "", "## Material Passport", "",
             "- Origin Skill: experiment-agent", "- Origin Mode: validate", f"- Origin Date: {datetime.now(timezone.utc).isoformat()}",
             "- Verification Status: ANALYZED", "- Version Label: step25_saved_mechanism_analysis_v1", "",
             f"本批状态 {state}，新上下文资格 {summary['qualified_new_contexts']}/2。真实新增 QP {total_qp}/400、正式积分 {total_steps}/4020；新轨迹启动 {_compact(dict(new_started))}，完整 {_compact(dict(new_complete))}。", "",
             f"固定 0.5 mm probe 产生 {len(probe_rows)}/9 条方法评价；healthy 复用 STEP24 保存轨迹，新增求解和积分均为 0。方法行共享同上下文 C/B 反事实轨迹，不是九次独立实验。", "",
             "## 采样遗漏与全范围机制", "",
             f"healthy 保存命令接口恒等检查：{_compact(healthy.get('healthy_interface_identity', {}))}。原 21 点结果保留；新检查覆盖初态及全部 500 个 2 ms 状态，21 点仅作为报告 landmarks。预测选择只读取预测数据，actual 结果独立评价。", "",
             "| 上下文 | 一步 mm | dense pred C/B mm | actual C/B mm | 机制区间 | C误接受 | B误接受 | backup未认证 |", "|---|---:|---|---|---|---|---|---|"]
    for result in results:
        if not result: continue
        m = result.get("excursion_metrics", {}); a = result.get("range_analysis", {})
        lines.append(f"| {result['context_id']} | {_fmt(m.get('d_step'),1000)} | {_fmt(m.get('d_pred_C'),1000)}/{_fmt(m.get('d_pred_B'),1000)} | {_fmt(m.get('d_actual_C'),1000)}/{_fmt(m.get('d_actual_B'),1000)} | {_interval(a.get('mechanism_interval'))} | {_interval(a.get('candidate_acceptance_actual_failure_band'))} | {_interval(a.get('backup_screened_selected_actual_failure_band'))} | {_interval(a.get('backup_uncertified_gap_band'))} |")
    old = healthy.get("saved_dense_comparison", {}).get("old21_range_analysis", {})
    lines += ["", f"healthy 原 21 点机制 {_interval(old.get('mechanism_interval'))}；原 C/B 误接受带分别 {_interval(old.get('candidate_acceptance_actual_failure_band'))} / {_interval(old.get('backup_screened_selected_actual_failure_band'))}。这是已知保存数据回归检查，不是新独立确认性检验。", "",
              "区间范围预设为 [0,8 mm]，沿用保存公式和端点规则：实际峰值等号安全；真实失败侧右端开。完整 horizon 缺失时不使用前缀冒充最大余量。global 1.0−x 与额外 local margin 分列，workspace 越界不称跌倒。dense 接受是 2 ms 离散检查。", "",
              "## 固定 probe 与当前执行资格", "", "| 上下文 | 方法 | 选择/label | 原物理/local/终端/combined | fresh ms |", "|---|---|---|---|---:|"]
    for row in probe_rows:
        lines.append(f"| {row['context_id']} | {row.get('method')} | {row.get('selected_mode','—')}/{row.get('safety_label',row.get('status','—'))} | {_mark(row.get('original_physical_safe'))}/{_mark(row.get('local_workspace_safe'))}/{_mark(row.get('terminal_pass'))}/{_mark(row.get('combined_safe_and_terminal'))} | {_fmt(row.get('decision_latency_ms'),1,3)} |")
    lines += ["", "| 新上下文 | 故障通道/health | raw QP bound | solved有限可执行 | 发送后物理 | 资格 |", "|---|---|---|---|---|---|"]
    for result in fault_results:
        if not result: continue
        q = result.get("qualification", {}); meta = result.get("metadata", {})
        lines.append(f"| {result['context_id']} | {meta.get('faulted_actuator_name')}/{_fmt(meta.get('faulted_health'),1,12)} | {_mark(q.get('raw_QP_bound_pass'))} | {_mark(q.get('current_executable_command'))} | {_mark((q.get('current_physical_check') or {}).get('pass'))} | {q.get('status')} |")
    lines += ["", "tau_raw 是严格 solved 且有限的原 QP 解；tau_sent=clip(tau_raw, ±health_vector×healthy_limit) 是统一发送接口。原验证、raw bound 违反量和 raw qdd/lambda 保留；发送后零容差物理检查单独报告。未 solved、solved-inaccurate 或非有限结果不经 clip 获救。raw qdd 是 QP 代数量，不能当作实际 achieved acceleration；执行命令对应动力学残差使用单独版本。", "",
              "## 能力、任务误差与实际运动", "", "| 上下文 | 类别/模式 | 故障通道 | cap/raw/sent/applied峰值 N·m | sent/applied最小余量 N·m | clip/exact/99%次数 |", "|---|---|---|---|---|---|"]
    for row in actuator_rows:
        if row.get("actuator_index") == row.get("faulted_actuator_index"):
            lines.append(f"| {row['context_id']} | {row['category']}/{row['mode']} | {row.get('name')} | {_fmt(row.get('capacity_nm'))}/{_fmt(row.get('raw_peak_nm'))}/{_fmt(row.get('sent_peak_nm'))}/{_fmt(row.get('applied_peak_nm'))} | {_fmt(row.get('sent_min_margin_nm'))}/{_fmt(row.get('applied_min_margin_nm'))} | {row.get('clipped_count','—')}/{row.get('exact_active_count','—')}/{row.get('sent99_count','—')} |")
    lines += ["", "所有 12 通道的 raw/sent/applied 峰值、能力余量、精确界及 99% 次数保存在 ALL_ACTUATOR_DIAGNOSTICS.csv；nominal 与所有分支分列。CAPACITY_COMPARISON.csv 比较三个上下文的两故障通道需求、实际行程及相对 healthy 变化。两条件的能力固定为相应 healthy C 命令包络的 75%，health 向量完整精度冻结，不能把两者解释为相同额定损伤严重度。", "",
              "| 上下文 | nominal任务轴 | 单位 | raw qdd 最大绝对目标误差 | 均值误差 |", "|---|---|---|---:|---:|"]
    for row in task_rows:
        if row["category"] == "NOMINAL": lines.append(f"| {row['context_id']} | {row.get('axis')} | {row.get('unit')} | {_fmt(row.get('max_abs_raw_qdd_error'))} | {_fmt(row.get('mean_raw_qdd_error'))} |")
    healthy_progress = {(row["category"], row["mode"]): row.get("endpoint_dx_m") for row in progress_rows if row["reused_saved_data"]}
    lines += ["", "六轴误差按各自单位分列，全部分支见 TASK_ACCEL_ERRORS.csv。当前 20 ms 进度、C/B 终点和终端速度见 TRAJECTORY_PROGRESS.csv；最大前向行程见区间表。", "",
              "| 上下文 | 类别/模式 | 终点 dx mm | 相对healthy变化 mm | endpoint vx m/s | complete |", "|---|---|---:|---:|---:|---|"]
    for row in progress_rows:
        if row["category"] not in ("ACTUAL", "PREVIEW"): continue
        reference = healthy_progress.get((row["category"], row["mode"])); dx = row.get("endpoint_dx_m")
        delta = dx-reference if isinstance(dx, (float, int)) and isinstance(reference, (float, int)) else None
        lines.append(f"| {row['context_id']} | {row['category']}/{row['mode']} | {_fmt(dx,1000)} | {_fmt(delta,1000)} | {_fmt(row.get('endpoint_vx'))} | {_mark(row.get('complete'))} |")
    lines += ["", "积分更新/冻结原因和六轴 update/clip 次数见 INTEGRAL_DIAGNOSTICS.csv。cap 界激活、余量减少、命令分配变化、积分冻结和实际运动变化分别评价；单通道触发原 99% 门会影响六轴积分，闭环差异不能唯一归因于机械力矩损失。M2 两条预测都不通过时，指定 backup 未通过离散检查；best-effort B 不保证安全，也不代表全局不可恢复。", "",
              "## 成本与执行状态", "", "| 方法 | fresh decisions | >20 ms | min/max ms |", "|---|---:|---:|---:|"]
    for method, value in latency.items(): lines.append(f"| {method} | {value['fresh_decisions']} | {value['deadline_misses']} | {_fmt(value['min_ms'],1,3)}/{_fmt(value['max_ms'],1,3)} |")
    lines += ["", f"RUN_FINISHED 的真实墙钟耗时 {_fmt(finish.get('true_elapsed_s'),1,3)} s；时间戳按真实 UTC 写出。nominal、control含QP、solver wall、integration/refresh、numeric extraction、dense screen 和写出分项见 TIMING.csv 与各 RESULT。分项可能重叠或遗漏，不用相减生成独立 kernel benchmark。", "",
              "M0 仅计当前候选规则，M1 仅计一步规则，M2 计两条完整 fresh horizon 与 dense 筛选及 clip 成本。healthy 重评没有 fresh execution latency；原 STEP24 baseline wrapper 的计时解释保留，不能据保存数据读取宣布实时通过。离线计算后在虚拟 t=0 执行，未模拟墙钟 deadline miss 的动作延迟；超时标为实时失败，固定离线对照仍完成。", "",
              f"QP_RETURN 状态 {_compact(summary['QP_accounting']['status_counts'])}；未返回预约 {_compact(unknown_qp)}。新模型/forward/clone计数 {_compact(dict(resources))}，冻结前实现错误的模型加载另列，pure-test fixture 与正式积分独立计费；QP别名字段不相加。源码、两个 health 向量、probe 和规则的冻结信息以 PROTOCOL_AND_MANIFEST.json 为准。", "",
              "报告回答的是固定状态、固定 backup 和同模型传播下的工程机制。当前未具备泛化、鲁棒性和实时证据，不能宣布 T-RO 投稿就绪。下一项预测架构工作应以这些物理数据验证更快模型及保守误差余量；全 MuJoCo 路径保留为离线 reference/实际评价，同轨迹拟合不能称独立验证。", "",
              "```ini", f"STEP25 = {state}", "NUMERICAL_RETRIES = 0", "EXTRA_HEALTH_OR_ACTUATOR_SEARCH = FALSE",
              "HISTORICAL_RESULTS_UNCHANGED = TRUE", "PHYSICAL_THRESHOLDS_UNCHANGED = TRUE", "FORMAL_PANEL_OR_E3 = NOT_AUTHORIZED", "RL_OR_HARDWARE = NOT_AUTHORIZED", "```", ""]
    if issues: lines += ["交付缺失：" + _compact(issues), ""]
    (out/"MECHANISM_REPORT.md").write_text("\n".join(lines), encoding="utf-8")
    summary["derived_artifact_sha256"] = {name: digest(out/name) for name in [*tables, "MECHANISM_REPORT.md"]}
    (out/"EXECUTION_SUMMARY.json").write_text(json.dumps(summary, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)+"\n", encoding="utf-8")
    return summary
