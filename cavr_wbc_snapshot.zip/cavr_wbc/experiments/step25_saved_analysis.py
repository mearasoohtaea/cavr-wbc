"""Describe saved STEP25 differences and timing; no simulator/solver imports."""
from collections import Counter
import json
from pathlib import Path
import argparse
from cavr_wbc.experiments.step21_report import canonical_hash


def read(path): return json.loads(path.read_text(encoding='utf-8'))


def analyze(out):
    m=read(out/'PROTOCOL_AND_MANIFEST.json');healthy=read(out/'HEALTHY_SAVED_REASSESSMENT.json')
    records=[]
    for c in m['contexts']:
        r=read(out/'contexts'/c['context_id']/'RESULT.json')
        frozen=read(out/'contexts'/c['context_id']/'DECISION_FROZEN.json')
        modes={}
        for mode in ('C','B'):
            pred=read(out/r['predictions'][mode])['result'];actual=read(out/r['actual'][mode])['result']
            p=[pred['initial_fact']]+pred['physics_trajectory'];a=[actual['initial_fact']]+actual['physics_trajectory']
            complete=pred['status']=='COMPLETE' and actual['status']=='COMPLETE' and len(p)==len(a)==501
            differences={key:max(abs(x-y) for pr,ar in zip(p,a) for x,y in zip(pr[key],ar[key])) if complete else None
                for key in ('qpos','qvel','tau_cmd','tau_applied')}
            events=[x['integral_record'] for x in actual['controls'] if x.get('integral_record') is not None]
            freezes=Counter(e['freeze_reason'] for e in events if not e['updated'])
            raw_bound_failures=[]
            for control in actual['controls']:
                interface=control['capacity_interface']
                if interface['command_valid'] and not interface['raw_command_within_capacity_exact']:
                    raw_bound_failures.append({'slot':control['slot'],'time_s':control['time_s'],
                        'raw_solver_status_val':control['solver_raw_result']['status_val'],
                        'raw_QP_validation':control['solver_raw_result']['validation'],
                        'max_raw_bound_violation_nm':max(interface['raw_command_bound_violation_nm']),
                        'sent_exact_bound_pass':interface['sent_command_within_capacity_exact'],
                        'sent_algebraic_residual_inf':control['execution_diagnostics'].get('sent_dynamics_residual_inf'),
                        'residual_version':control['execution_diagnostics']['sent_dynamics_residual_definition']})
            modes[mode]={'complete':complete,'prediction_actual_max_abs_numeric_differences':differences,
                'backup_integral_events':len(events),'all_axis_updated_events':sum(e['updated'] for e in events),
                'all_axis_frozen_events':sum(not e['updated'] for e in events),'actual_freeze_reasons':dict(freezes),
                'held_candidate_without_backup_integral_event':len(actual['controls'])-len(events),
                'axis_clip_counts':[sum((e.get('six_axis_clipped') or [False]*6)[k] for e in events) for k in range(6)],
                'raw_bound_failure_controls':raw_bound_failures,'prediction_elapsed_ms':pred['elapsed_ms'],
                'prediction_timing':pred['timing'],
                'prediction_max_solver_wall_ms':max((x.get('solve_wall_time_s',0.)*1000 for x in pred['solver_ledger']),default=None),
                'prediction_max_iterations':max((x.get('iterations',0) for x in pred['solver_ledger']),default=None),
                'actual_peak_change_from_healthy_m':r['excursion_metrics']['d_actual_'+mode]-healthy['excursion_metrics']['d_actual_'+mode],
                'endpoint_change_from_healthy_m':next(d['progress']['endpoint_dx_m'] for d in r['branch_diagnostics'] if d['category']=='ACTUAL' and d['mode']==mode)
                    -next(d['progress']['endpoint_dx_m'] for d in healthy['branch_diagnostics'] if d['category']=='ACTUAL' and d['mode']==mode)}
        records.append({'context_id':c['context_id'],'faulted_actuator_name':c['faulted_actuator_name'],
            'faulted_health':c['faulted_health'],'effective_capacity_nm':c['effective_capacity_nm'],
            'decision_frozen_hash_matches':canonical_hash(frozen['query'])==r['decision_frozen_hash']==canonical_hash(r['probe_query']),
            'mechanism_interval':r['range_analysis']['mechanism_interval'],'modes':modes})
    result={'schema':'STEP25_SAVED_DATA_INTERPRETATION_V1','client_date':'2026-10-08','contexts':records,
        'new_QP_calls':0,'new_physics_steps':0,'new_queries':0,
        'pure_saved_comparison_not_new_validation_experiment':True,
        'integral_counter_rule':'Only actual integral records count; held candidate slot0 is not a backup integral event; updated None reason is not a freeze',
        'healthy_is_reused_targeted_development_not_independent_confirmation':True}
    (out/'SAVED_DATA_INTERPRETATION.json').write_text(json.dumps(result,sort_keys=True,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps({'saved_comparison_done':True,'new_QP':0,'new_steps':0,
        'contexts':[{'id':r['context_id'],'decision_hash_matches':r['decision_frozen_hash_matches'],
            'modes':{k:{'numeric_differences':v['prediction_actual_max_abs_numeric_differences'],
                'updates':v['all_axis_updated_events'],'freezes':v['all_axis_frozen_events'],
                'raw_bound_failure_slots':[e['slot'] for e in v['raw_bound_failure_controls']],
                'pred_max_iterations':v['prediction_max_iterations']} for k,v in r['modes'].items()}} for r in records]}))
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
    analyze(parser.parse_args().output)
