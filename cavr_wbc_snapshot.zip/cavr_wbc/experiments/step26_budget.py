"""One immutable STEP26 numerical budget and append-only event ledger."""
from collections import Counter
from datetime import datetime,timezone
import json
import os
from pathlib import Path
from time import perf_counter


class SprintLimit(RuntimeError): pass


class SprintBudget:
    def __init__(self,out):
        self.out=Path(out);self.out.mkdir(parents=True,exist_ok=True)
        self.path=self.out/'STEP26_LEDGER.jsonl';self.qp_calls=0;self.physics_steps=0
        self.qp_kinds=Counter();self.step_kinds=Counter();self.started=None;self.start_utc=None
        self.fit_count=0;self.dev_recomputations=0
        self.stream=self.path.open('a',encoding='utf-8',buffering=1)
    def event(self,event,**values):
        self.stream.write(json.dumps({'event':event,'timestamp_utc':datetime.now(timezone.utc).isoformat(),**values},sort_keys=True,allow_nan=False)+'\n')
    def check(self):
        if self.qp_calls>=16000: raise SprintLimit('16000 real QP hard limit')
        if self.physics_steps>=160000: raise SprintLimit('160000 physics step hard limit')
        if self.started is not None and perf_counter()-self.started>=7200: raise SprintLimit('2 hour fixed numerical wall limit')
    def start(self):
        if self.started is None:
            self.started=perf_counter();self.start_utc=datetime.now(timezone.utc).isoformat()
            self.event('NUMERICAL_STARTED',hard_wall_s=7200,QP_limit=16000,step_limit=160000)
    def qp_callback(self,kind,owner,first_mode=None):
        active={}
        def call(stage,payload,solve):
            if stage=='before':
                self.start();self.check();self.qp_calls+=1;self.qp_kinds[kind]+=1
                active.clear();active.update(global_qp_index=self.qp_calls,kind=kind,owner=owner,local_qp_index=payload['solver_call_index'])
                self.event('QP_START',**active);return solve()
            r=payload['result'];self.event('QP_RETURN',**active,**{k:r.get(k) for k in ('status','status_val','iterations','solve_wall_time_s','real_optimizer_called')})
        return call
    def step_observer(self,kind,owner):
        def before():
            self.start();self.check();self.physics_steps+=1;self.step_kinds[kind]+=1
            if self.physics_steps%1000==0: self.event('PHYSICS_PROGRESS',owner=owner,**self.snapshot())
        return before
    def snapshot(self):
        return {'total_QP_calls':self.qp_calls,'total_physics_steps':self.physics_steps,
            'QP_by_kind':dict(self.qp_kinds),'physics_by_kind':dict(self.step_kinds),
            'numerical_started_utc':self.start_utc,'numerical_elapsed_s':perf_counter()-self.started if self.started is not None else 0.,
            'estimator_fits':self.fit_count,'DEV_context_recomputations':self.dev_recomputations}
    def persist(self,**extra):
        value={**self.snapshot(),**extra};path=self.out/'STEP26_PROGRESS.json';tmp=path.with_suffix('.tmp')
        tmp.write_text(json.dumps(value,sort_keys=True,allow_nan=False)+'\n',encoding='utf-8');os.replace(tmp,path)
        self.stream.flush();os.fsync(self.stream.fileno())
    def close(self): self.persist();self.stream.close()
