"""One final file verification of this STEP26 output, never historical data."""
import argparse
import hashlib
import json
from pathlib import Path
from pypdf import PdfReader


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for part in iter(lambda:f.read(1024*1024),b''): h.update(part)
    return h.hexdigest()


def verify(out,root):
    manifest=json.loads((out/'STEP26_PROTOCOL_AND_MANIFEST.json').read_text(encoding='utf-8'))
    source={p:sha(root/p)==value for p,value in manifest['source_sha256'].items()}
    models={}
    for path in (out/'models').glob('round*/step26_model_*_freeze.json'):
        record=json.loads(path.read_text(encoding='utf-8'));models[str(path.relative_to(out))]=sha(Path(record['weights_path']))==record['sha256']
    starts={};returns={};seen_test=[];seals={}
    for path in (out/'models').glob('round*/MODELS_FROZEN.json'): seals[int(path.parent.name.replace('round',''))]=True
    for line in (out/'STEP26_LEDGER.jsonl').read_text(encoding='utf-8').splitlines():
        event=json.loads(line)
        if event['event']=='QP_START': starts[event['global_qp_index']]=event
        if event['event']=='QP_RETURN': returns[event['global_qp_index']]=event
        if event['event']=='SEALED_TEST_OPEN': seen_test.append(event['round'])
    finish=json.loads((out/'RUN_FINISHED.json').read_text(encoding='utf-8'))
    pdf=[]
    for path in (out/'figures').glob('STEP26_*.pdf'):
        pages=PdfReader(path).pages
        for page in pages:
            fonts=[]
            for ref in page['/Resources']['/Font'].values():
                parent=ref.get_object()
                for child in parent.get('/DescendantFonts',[parent]):
                    font=child.get_object();descriptor=font.get('/FontDescriptor');descriptor=descriptor.get_object() if descriptor else {}
                    fonts.append({'name':str(parent.get('/BaseFont')),'subtype':str(font.get('/Subtype')),
                        'embedded':any(k in descriptor for k in ('/FontFile','/FontFile2','/FontFile3'))})
            pdf.append({'path':str(path.relative_to(out)),'width_inches':float(page.mediabox.width)/72,
                'height_inches':float(page.mediabox.height)/72,'fonts':fonts})
    entries={str(p.relative_to(out)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in out.rglob('*') if p.is_file() and p.name!='FINAL_FILE_VERIFICATION.json'}
    checks={'frozen_source_hashes':all(source.values()),'model_hashes':all(models.values()),
        'QP_start_return_identity':set(starts)==set(returns),'QP_count_matches_budget':len(starts)==finish['budget']['total_QP_calls'],
        'all_returned_optimizer_called':all(r['real_optimizer_called'] is True for r in returns.values()),
        'hard_budget_not_exceeded':finish['budget']['total_QP_calls']<=16000 and finish['budget']['total_physics_steps']<=160000 and finish['budget']['numerical_elapsed_s']<=7200,
        'both_rounds_seal_records_present':all(seals.get(r) for r in seen_test),
        'all_PDF_fonts_embedded_nonType3':all(f['embedded'] and f['subtype']!='/Type3' for page in pdf for f in page['fonts'])}
    result={'schema':'STEP26_FINAL_FILE_VERIFICATION_V1','scope':'single current output, no historical/fullrepo audit',
        'checks':checks,'source_details':source,'model_details':models,'PDF_recursive_font_check':pdf,
        'stock_font_warning_resolution':'Type0 parent lacked direct descriptor; embedded CIDFontType2 descendants verified',
        'files':entries,'file_count':len(entries),'total_bytes':sum(v['bytes'] for v in entries.values()),
        'new_QP_steps_fits':0,'all_checks_passed':all(checks.values())}
    (out/'FINAL_FILE_VERIFICATION.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'file_count':len(entries),'bytes':result['total_bytes'],'checks':checks}))
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    result=verify(args.output,Path(__file__).resolve().parents[2]);raise SystemExit(0 if result['all_checks_passed'] else 1)
