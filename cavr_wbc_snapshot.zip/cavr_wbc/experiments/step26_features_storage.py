"""Frozen current-state features and lossless compact STEP26 trajectory shards.

There is no simulator, solver, model fitting, or evaluator dependency here.
Features deliberately read a small current-input allowlist. NPZ storage keeps
the numeric facts consumed by the independent STEP25 evaluator, not its labels.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
import math
import os
from pathlib import Path
import tempfile
from typing import Any, Mapping

import numpy as np


FEATURE_VERSION = "STEP26_CURRENT_FEATURES_48_V1"
FEATURE_NAMES = (
    "direction_vx_m_s", "vx_squared_m2_s2", "vy_m_s", "vz_m_s",
    "roll_rad", "direction_pitch_rad", "wx_rad_s", "direction_wy_rad_s", "wz_rad_s",
    "subtree_com_z_m", "direction_com_minus_base_x_m", "com_minus_base_y_m",
    "direction_foot_relative_x_min_m", "direction_foot_relative_x_max_m",
    "foot_relative_y_min_m", "foot_relative_y_max_m",
    "direction_side_joint_q_mean_rad", "direction_side_joint_q_std_rad",
    "direction_side_joint_v_mean_rad_s", "direction_side_joint_v_std_rad_s",
) + tuple(f"health_compiled_channel_{j:02d}" for j in range(12)) + (
    "fault_channel_or_healthy_side_max_sent_utilization", "sent_utilization_max",
    "sent_utilization_mean", "sent_utilization_std",
) + tuple("desired_" + name for name in (
    "direction_ax_m_s2", "ay_m_s2", "az_m_s2", "aroll_rad_s2", "apitch_rad_s2", "ayaw_rad_s2",
)) + tuple("current_forward_actual_" + name for name in (
    "direction_ax_m_s2", "ay_m_s2", "az_m_s2", "aroll_rad_s2", "apitch_rad_s2", "ayaw_rad_s2",
))
FOOT_NAMES = ("FL", "FR", "RL", "RR")
BANK_VERSION = "STEP26_COMPACT_NUMERIC_BANK_V1"


def feature_specification():
    return {
        "version": FEATURE_VERSION, "count": len(FEATURE_NAMES), "names": list(FEATURE_NAMES),
        "direction": "sign(current snapshot vx); abs(vx)>=0.01 m/s",
        "direction_side": "FR for positive vx, RR for negative vx; compiled joint addresses",
        "joint_summary": "population mean/std of three side joints; angles radians",
        "utilization": "abs(candidate sent torque)/(health*compiled healthy limit)",
        "healthy_feature_33": "max utilization over the three direction-side actuators",
        "health_order": "compiled actuator index 0..11; full health vector",
        "acceleration": "six current desired and six actual once-current-forward components; x only normalized",
        "forbidden_inputs": ["episode", "tick", "split", "label", "evaluator_output", "future_trajectory", "gap"],
        "standard_deviation_ddof": 0, "missing_or_nonfinite_features": "reject input",
    }


def copy_snapshot(snapshot):
    """Copy all serialized state/control memory without changing the source."""
    return deepcopy(snapshot)


def _vector(value, name, size=None):
    result = np.asarray(value, dtype=float)
    if result.ndim != 1 or (size is not None and result.size != size) or not np.isfinite(result).all():
        raise ValueError(f"finite vector of size {size} required: {name}")
    return result


def _compiled_mapping(mapping):
    if isinstance(mapping, Mapping):
        mapping = mapping.get("actuator_mapping", mapping.get("mapping"))
    entries = list(mapping)
    if len(entries) != 12:
        raise ValueError("STEP26 requires a compiled 12-actuator mapping")
    result = []
    for entry in entries:
        idx = entry.get("actuator_index", entry.get("index"))
        name = entry.get("actuator_name", entry.get("name"))
        if not isinstance(idx, (int, np.integer)) or not isinstance(name, str):
            raise ValueError("compiled actuator index/name missing")
        result.append(dict(entry, index=int(idx), name=name))
    result.sort(key=lambda entry: entry["index"])
    if [entry["index"] for entry in result] != list(range(12)) or len({e["name"] for e in result}) != 12:
        raise ValueError("compiled actuator mapping is not one-to-one")
    return result


def _feet(fact, nominal, foot_positions):
    points = foot_positions if foot_positions is not None else nominal.get("foot_positions", fact.get("foot_positions"))
    if points is None:
        points = {}
        for foot in FOOT_NAMES:
            contacts = fact.get("contacts", {})
            contact = contacts.get(foot, contacts.get(foot+"_foot", {}))
            for key in ("position_world_m", "position", "point_world_m", "world_position"):
                if key in contact:
                    points[foot] = contact[key]
                    break
    if isinstance(points, Mapping):
        if all(foot in points for foot in FOOT_NAMES):
            points = [points[foot] for foot in FOOT_NAMES]
        elif all(foot+"_foot" in points for foot in FOOT_NAMES):
            points = [points[foot+"_foot"] for foot in FOOT_NAMES]
        else:
            raise ValueError("all four current compiled foot positions required")
    points = np.asarray(points, dtype=float)
    if points.shape != (4, 3) or not np.isfinite(points).all():
        raise ValueError("finite current foot positions must have shape (4,3)")
    return points


def extract_features(snapshot, nominal, mapping, foot_positions=None):
    """Return exactly 48 finite features, using current inputs only.

    ``mapping`` is the compiled actuator audit with qpos_address/dof_index.
    ``nominal`` supplies the action-conditioned current fact, sent torque,
    health vector, desired base acceleration, and four current foot positions.
    """
    fact = nominal["initial_new_command_fact"]
    state = snapshot.get("state", snapshot)
    qpos = _vector(state.get("qpos", fact.get("qpos")), "current qpos")
    qvel = _vector(state.get("qvel", fact.get("qvel")), "current qvel")
    if qpos.size < 7 or qvel.size < 6 or abs(qvel[0]) < .01:
        raise ValueError("STEP26 feature input requires free-joint state and abs(vx)>=0.01 m/s")
    direction = 1. if qvel[0] > 0 else -1.
    entries = _compiled_mapping(mapping)
    side = "FR" if direction > 0 else "RR"
    side_entries = [entry for entry in entries if entry["name"] in (side+"_hip", side+"_thigh", side+"_calf")]
    if len(side_entries) != 3:
        raise ValueError("three direction-side actuators missing from compiled mapping")
    addresses = [entry["qpos_address"] for entry in side_entries]
    dofs = [entry.get("dof_index", entry.get("dof_address")) for entry in side_entries]
    if any(not isinstance(j, (int, np.integer)) or j < 0 or j >= qpos.size for j in addresses):
        raise ValueError("invalid compiled joint qpos addresses")
    if any(not isinstance(j, (int, np.integer)) or j < 0 or j >= qvel.size for j in dofs):
        raise ValueError("invalid compiled joint dof addresses")
    health = _vector(fact.get("health_vector", nominal.get("health_vector")), "health vector", 12)
    if np.any((health < 0.) | (health > 1.)):
        raise ValueError("health must be in [0,1]")
    sent = _vector(nominal.get("tau_sent", nominal.get("tau", fact.get("tau_sent", fact.get("tau_cmd")))), "sent torque", 12)
    capacities = fact.get("effective_capacity_nm", nominal.get("capacity_interface", {}).get("effective_capacity_nm"))
    if capacities is None:
        limits = [entry.get("healthy_limit_nm", entry.get("healthy_torque_limit_nm")) for entry in entries]
        if any(v is None for v in limits):
            limits = fact.get("actuator_limits")
        capacities = health * _vector(limits, "compiled healthy limits", 12)
    capacities = _vector(capacities, "effective capacity", 12)
    if np.any(capacities <= 0.):
        raise ValueError("positive effective capacity required for STEP26 utilization features")
    utilization = np.abs(sent) / capacities
    fault = nominal.get("faulted_actuator_index", snapshot.get("faulted_actuator_index", fact.get("faulted_actuator_index")))
    if np.any(health < 1.):
        if not isinstance(fault, (int, np.integer)) or int(fault) not in [entry["index"] for entry in side_entries]:
            raise ValueError("degraded feature input requires explicit compiled direction-side fault index")
        if np.count_nonzero(health < 1.) != 1 or health[int(fault)] >= 1.:
            raise ValueError("declared fault index differs from the full health vector")
        fault_name = nominal.get("faulted_actuator_name", snapshot.get("faulted_actuator_name", fact.get("faulted_actuator_name")))
        if fault_name is not None and fault_name != entries[int(fault)]["name"]:
            raise ValueError("declared fault name differs from the compiled fault index")
        fault_utilization = utilization[int(fault)]
    else:
        if fault is not None:
            raise ValueError("healthy feature input requires faulted_actuator_index=None")
        fault_utilization = max(utilization[entry["index"]] for entry in side_entries)
    com = np.asarray(fact["subtree_com"], dtype=float)
    if com.ndim == 2:
        com = com[int(fact["base_body_id"])]
    com = _vector(com, "current subtree COM", 3)
    feet = _feet(fact, nominal, foot_positions) - qpos[:3]
    q = qpos[addresses]; velocity = qvel[dofs]
    desired = _vector(nominal["response"]["a_base_ref"], "desired base acceleration", 6).copy()
    actual_value = fact.get("actual_mujoco_qacc", fact.get("qacc_after_command_or_integration_refresh"))
    actual = _vector(actual_value, "actual current-forward qacc")[:6].copy()
    if actual.size != 6:
        raise ValueError("six actual current-forward base acceleration components required")
    desired[0] *= direction; actual[0] *= direction
    values = [direction*qvel[0], qvel[0]**2, qvel[1], qvel[2],
              fact["roll"], direction*fact["pitch"], qvel[3], direction*qvel[4], qvel[5],
              com[2], direction*(com[0]-qpos[0]), com[1]-qpos[1],
              np.min(direction*feet[:, 0]), np.max(direction*feet[:, 0]),
              np.min(feet[:, 1]), np.max(feet[:, 1]),
              np.mean(q), np.std(q), np.mean(velocity), np.std(velocity),
              *health, fault_utilization, np.max(utilization), np.mean(utilization), np.std(utilization),
              *desired, *actual]
    return _vector(values, "frozen STEP26 features", 48)


def _json_safe(value):
    if isinstance(value, np.ndarray):
        return _json_safe(value.tolist())
    if isinstance(value, np.generic):
        return _json_safe(value.item())
    if isinstance(value, Mapping):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    if isinstance(value, float) and not math.isfinite(value):
        return {"__step26_nonfinite_float__": repr(value)}
    return value


def _json_restore(value):
    if isinstance(value, dict):
        if set(value) == {"__step26_nonfinite_float__"}:
            return float(value["__step26_nonfinite_float__"])
        return {k: _json_restore(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_json_restore(v) for v in value]
    return value


def _flatten(value, prefix=()):
    out = {}
    for key, item in value.items():
        if key == "physical_evaluation":
            continue
        path = prefix + (str(key),)
        if isinstance(item, Mapping) and item:
            out.update(_flatten(item, path))
        else:
            out[path] = item
    return out


def _assign(target, path, value):
    for key in path[:-1]:
        target = target.setdefault(key, {})
    target[path[-1]] = value


def _pack(array):
    """Lossless byte planes improve compression without rounding physical facts."""
    values = np.ascontiguousarray(array)
    if values.dtype.kind == "f":
        bits = values.view(np.uint64).copy()
        if len(bits) > 1:
            bits[1:] ^= values.view(np.uint64)[:-1]
        payload = bits.view(np.uint8).reshape(values.shape + (8,))
        return np.ascontiguousarray(np.moveaxis(payload, -1, 0)), {"dtype": values.dtype.str, "shape": list(values.shape), "encoding": "float64_xor_byteplanes"}
    return values, {"dtype": values.dtype.str, "shape": list(values.shape), "encoding": "plain"}


def _unpack(payload, spec):
    if spec["encoding"] == "plain":
        return np.asarray(payload, dtype=np.dtype(spec["dtype"])).reshape(spec["shape"])
    packed = np.ascontiguousarray(np.moveaxis(payload, 0, -1))
    bits = packed.reshape(-1).view(np.uint64).reshape(spec["shape"]).copy()
    np.bitwise_xor.accumulate(bits, axis=0, out=bits)
    return bits.view(np.dtype(spec["dtype"]))


def _compact_control(control):
    keep = ("slot", "time_s", "first_mode", "action_source", "backup_id", "backup_version",
            "tau_cmd", "tau_raw", "tau_sent", "tau_applied", "health_vector", "valid_command",
            "latency_ms", "integral_record", "faulted_actuator_name", "faulted_actuator_index", "faulted_health")
    out = {key: control[key] for key in keep if key in control}
    raw = control.get("solver_raw_result") or {}
    out["solver_raw_result"] = {key: raw[key] for key in ("status", "status_val", "success", "validation") if key in raw}
    interface = control.get("capacity_interface") or {}
    keys = ("command_valid", "solver_exact_solved", "effective_capacity_nm", "saturation_mask",
            "raw_99_percent_active_indices", "sent_99_percent_active_indices", "invalid_reason",
            "raw_command_within_capacity_exact", "sent_command_within_capacity_exact")
    if interface:
        out["capacity_interface"] = {key: interface[key] for key in keys if key in interface}
    response = control.get("servo_response") or {}
    if response:
        out["servo_response"] = {key: response[key] for key in ("a_base_ref", "valid_command", "integral_record", "b_used", "b_after") if key in response}
    return out


def save_bank(path, branch, metadata=None, landmark_steps=None):
    """Atomically save an unpadded branch; return an identity-only manifest record.

    Each finite state is stored once in typed columns. Scalar constants and
    control gates/integrals are JSON; giant matrix diagnostics are omitted.
    Explicit numerical-failure rows remain raw JSON and cannot become a
    completed prefix. Float columns are bit-exact and allow_pickle is never used.
    """
    path = Path(path).resolve()
    if path.exists():
        raise FileExistsError("STEP26 bank shards may not overwrite an attempt: " + str(path))
    path.parent.mkdir(parents=True, exist_ok=True)
    initial = branch.get("initial_fact")
    rows = ([initial] if initial is not None else []) + list(branch.get("physics_trajectory", []))
    regular_indices = []; flat_rows = []; exceptional = {}
    for idx, row in enumerate(rows):
        if row.get("numerical_failure") or "qpos" not in row or "qvel" not in row:
            exceptional[str(idx)] = _json_safe(row)
        else:
            _vector(row["qpos"], "bank qpos"); _vector(row["qvel"], "bank qvel")
            for field in ("act", "ctrl", "qacc_warmstart", "integration_state", "actual_mujoco_qacc",
                          "qacc_after_command_or_integration_refresh"):
                if field in row:
                    values = np.asarray(row[field], dtype=float)
                    if not np.isfinite(values).all():
                        raise ValueError("unexpected nonfinite numeric bank state field: " + field)
            regular_indices.append(idx); flat_rows.append(_flatten(row))
    keys = sorted(set().union(*(set(row) for row in flat_rows))) if flat_rows else []
    payload = {}; descriptors = []; stored = []
    for key in keys:
        present = [key in row for row in flat_rows]
        values = [row.get(key) for row in flat_rows]
        descriptor = {"path": list(key), "present": present}
        safe_values = _json_safe(values)
        for value in values:
            try:
                numeric_value = np.asarray(value)
            except (TypeError, ValueError):
                continue
            if numeric_value.dtype.kind == "f" and not np.isfinite(numeric_value).all():
                raise ValueError("unexpected nonfinite numeric bank column: " + ".".join(key))
        if all(present) and all(v == safe_values[0] for v in safe_values):
            descriptor.update(kind="constant", value=safe_values[0])
        else:
            array = None
            if all(present):
                try:
                    candidate = np.asarray(values)
                    if candidate.dtype.kind in "biuf" and candidate.ndim >= 1:
                        array = candidate.astype(np.float64) if candidate.dtype.kind == "f" else candidate
                        if array.dtype.kind == "f" and not np.isfinite(array).all():
                            raise ValueError("unexpected nonfinite numeric bank column: " + ".".join(key))
                except (TypeError, ValueError) as exc:
                    if "unexpected nonfinite" in str(exc):
                        raise
            if array is None:
                descriptor.update(kind="json", values=safe_values)
            else:
                name = None
                for previous_name, previous in stored:
                    if previous.dtype == array.dtype and previous.shape == array.shape and np.array_equal(previous, array):
                        name = previous_name
                        break
                if name is None:
                    name = "column_" + str(len(stored)).zfill(3)
                    payload[name], spec = _pack(array)
                    stored.append((name, array))
                    descriptor["spec"] = spec
                else:
                    spec = next(d["spec"] for d in descriptors if d.get("array") == name and "spec" in d)
                    descriptor["spec"] = spec
                descriptor.update(kind="numeric", array=name)
        descriptors.append(descriptor)
    omit = {"initial_fact", "physics_trajectory", "checkpoints", "controls", "sampled_screen"}
    header = {key: value for key, value in branch.items() if key not in omit}
    header["controls"] = [_compact_control(c) for c in branch.get("controls", [])]
    document = {"schema": BANK_VERSION, "header": _json_safe(header), "metadata": _json_safe(metadata or {}),
                "row_count": len(rows), "initial_present": initial is not None,
                "regular_indices": regular_indices, "exceptional_rows": exceptional, "columns": descriptors,
                "landmark_steps": list(range(0, 501, 25)) if landmark_steps is None else list(landmark_steps), "diagnostics_omitted": ["physical_evaluation", "sampled_screen", "control_matrix_assembly"]}
    encoded = json.dumps(document, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode("utf-8")
    payload["metadata_json_utf8"] = np.frombuffer(encoded, dtype=np.uint8)
    pending = None
    try:
        with tempfile.NamedTemporaryFile(prefix=".step26-bank-", suffix=".npz", dir=path.parent, delete=False) as stream:
            pending = Path(stream.name)
            np.savez_compressed(stream, **payload)
            stream.flush(); os.fsync(stream.fileno())
        if path.exists():
            raise FileExistsError("STEP26 attempt shard appeared during write: " + str(path))
        os.replace(pending, path)
        pending = None
    finally:
        if pending is not None and pending.exists():
            pending.unlink()
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    return {"path": str(path), "sha256": digest, "size_bytes": path.stat().st_size,
            "source_id": branch.get("branch_id"), "row_count": len(rows), "schema": BANK_VERSION}


def load_bank(path):
    """Reconstruct independent-evaluator facts and actual observed landmarks."""
    with np.load(Path(path), allow_pickle=False) as archive:
        document = json.loads(archive["metadata_json_utf8"].tobytes().decode("utf-8"))
        if document.get("schema") != BANK_VERSION:
            raise ValueError("unsupported STEP26 bank schema")
        rows = [{} for _ in range(document["row_count"])]
        for index, row in document["exceptional_rows"].items():
            rows[int(index)] = _json_restore(row)
        numeric = {}
        for descriptor in document["columns"]:
            if descriptor["kind"] == "numeric" and descriptor["array"] not in numeric:
                numeric[descriptor["array"]] = _unpack(archive[descriptor["array"]], descriptor["spec"])
            for pos, index in enumerate(document["regular_indices"]):
                if not descriptor["present"][pos]:
                    continue
                kind = descriptor["kind"]
                if kind == "constant":
                    value = _json_restore(deepcopy(descriptor["value"]))
                elif kind == "json":
                    value = _json_restore(deepcopy(descriptor["values"][pos]))
                else:
                    value = numeric[descriptor["array"]][pos].tolist()
                _assign(rows[index], descriptor["path"], value)
    branch = _json_restore(document["header"])
    branch["initial_fact"] = rows[0] if document["initial_present"] else None
    branch["physics_trajectory"] = rows[1:] if document["initial_present"] else rows
    checkpoints = []
    for row in rows:
        step = row.get("physics_step")
        if step in document["landmark_steps"] and "qpos" in row and not row.get("numerical_failure"):
            checkpoint = deepcopy(row)
            checkpoint.update(checkpoint_index=len(checkpoints), checkpoint_target_s=float(row["time_s"]))
            checkpoints.append(checkpoint)
    branch["checkpoints"] = checkpoints
    return branch
