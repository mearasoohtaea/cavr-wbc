"""Two STEP26 saved-evidence figures; scipilot style/profile/QA workflow."""
import argparse
import json
from pathlib import Path
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

SKILL=Path('C:/Users/ZhuanZ（无密码）/.codex/skills/scipilot-figure')
sys.path.insert(0,str(SKILL/'scripts'))
from profile_data import profile_data
from setup_style import setup_style
from layout_tools import finalize_figure,add_panel_labels
from visual_qa import render_preview,audit_layout
from export_figure import export_figure
from check_figure import check_figure
from PIL import Image


def export_exact(fig,basename,size):
    # The supplied grayscale helper redraws basename.png with a tight bbox.
    # Derive the proof from the exact-size PNG instead, preserving its pixels.
    export_figure(fig,str(basename),formats=['pdf','png'],dpi=600,size_inches=size,grayscale_preview=False,tight=False)
    with Image.open(str(basename)+'.png') as source:
        source.convert('L').save(str(basename)+'_grayscale.png',dpi=(600,600))


def read(path): return json.loads(path.read_text(encoding='utf-8'))


def plot_data(out):
    registry=read(out/'SPLIT_REGISTRY.json');lookup={r['context_id']:r for r in registry};points=[]
    for round_id in (1,2):
        path=out/'evaluation'/('round'+str(round_id))/'TEST_QUERIES.json'
        if not path.exists(): continue
        rows=read(path);unique={r['context_id']:r for r in rows if r['method']=='M3_FAST_MARGIN'}
        for cid,row in unique.items():
            labels=read(out/lookup[cid]['bank_directory']/'LABELS.json');pred=row.get('M3_prediction')
            for mode in ('C','B'):
                p=pred[mode] if pred else {};truth=labels[mode]
                points.append({'round':round_id,'context_id':cid,'branch':mode,'health_kind':row['health_kind'],
                    'D_true_m':truth.get('D'),'U_m':p.get('U'),'actual_valid':truth.get('valid'),
                    'gate_passed':p.get('gate_passed'),'score':p.get('validity_score'),'threshold':p.get('validity_threshold')})
    pd.DataFrame(points).to_csv(out/'FIGURE_POINT_DATA.csv',index=False)
    return points


def figures(out,finalize=False):
    destination=out/'figures';destination.mkdir(exist_ok=True)
    points=plot_data(out);df=pd.DataFrame(points)
    profiling=profile_data(df,group_cols=['round','branch'])
    (destination/'DATA_PROFILE.json').write_text(json.dumps(profiling,ensure_ascii=False,indent=2,default=str)+'\n',encoding='utf-8')
    setup_style(journal='ieee',lang='en',use_sciplots=False)
    plt.rcParams['savefig.bbox']=None
    plt.rcParams.update({'font.size':8,'axes.labelsize':8,'axes.titlesize':9,'xtick.labelsize':8,'ytick.labelsize':8,'legend.fontsize':7.5})
    colors={'HEALTHY':'#555555','THIGH_50':'#56B4E9','THIGH_15':'#0072B2','CALF_50':'#E69F00','CALF_15':'#D55E00'}
    markers={'HEALTHY':'o','THIGH_50':'s','THIGH_15':'^','CALF_50':'D','CALF_15':'v'}
    finalround=max(df['round']);sub=df[df['round']==finalround]
    pairs=sub[sub['D_true_m'].notna()&sub['U_m'].notna()]
    common_x=max(pairs['D_true_m'].max() if len(pairs) else 0.,.001)*1000
    common_y=max(pairs['U_m'].max() if len(pairs) else 0.,common_x/1000,.001)*1000
    fig,axes=plt.subplots(1,2,figsize=(7.16,3.45),constrained_layout=True)
    for ax,mode in zip(axes,('C','B')):
        data=sub[sub['branch']==mode];valid=data['D_true_m'].notna()&data['U_m'].notna()
        values=data[valid]
        xmax=max(values['D_true_m'].max() if len(values) else 0.,.001)*1000
        ymax=max(values['U_m'].max() if len(values) else 0.,xmax/1000,.001)*1000
        for kind in colors:
            group=values[values['health_kind']==kind]
            ax.scatter(group['D_true_m']*1000,group['U_m']*1000,s=24,marker=markers[kind],
                facecolors='none',edgecolors=colors[kind],linewidths=.8,alpha=.9)
        unsafe=values[values['actual_valid']==False]
        ax.scatter(unsafe['D_true_m']*1000,unsafe['U_m']*1000,s=10,marker='x',color='#111111',linewidths=.7)
        bound=max(xmax,ymax)*1.08
        ax.plot([0,bound],[0,bound],color='#888888',linestyle='--',linewidth=.7)
        ax.set(xlim=(0,common_x*1.12),ylim=(0,common_y*1.1),xlabel='Actual maximum D (mm)',ylabel='Predicted upper U (mm)',title='Candidate + backup' if mode=='C' else 'Immediate backup')
        ax.text(.03,.97,f"{len(values)}/{len(data)} complete D/U pairs\n40/40 validity-gate rejections\nCross: original unsafe or terminal miss",transform=ax.transAxes,va='top',fontsize=7)
    handles=[Line2D([],[],color=colors[k],marker=markers[k],linestyle='none',markerfacecolor='none',label=k.replace('_',' ').title()) for k in colors]
    fig.legend(handles=handles,loc='outside lower center',ncol=5,frameon=False)
    finalize_figure(fig);add_panel_labels(fig,style='ieee')
    render_preview(fig,str(destination/'margin_preview.png'),dpi=150);qa1=audit_layout(fig)
    if finalize: export_exact(fig,destination/'STEP26_margin_evidence',(7.16,3.45))
    plt.close(fig)

    rows=read(out/'evaluation'/('round'+str(finalround))/'TEST_QUERIES.json')
    fig,axes=plt.subplots(1,3,figsize=(7.16,3.3),constrained_layout=True)
    methodcolors={'M0_CURRENT':'#0072B2','M1_ONE_STEP':'#E69F00','M3_FAST_MARGIN':'#111111'}
    styles={'M0_CURRENT':('o','--'),'M1_ONE_STEP':('s',':'),'M3_FAST_MARGIN':('^','-')}
    gaps=sorted({r['gap_m'] for r in rows})
    for method in methodcolors:
        cov=[];retain=[]
        for gap in gaps:
            group=[r for r in rows if r['method']==method and r['gap_m']==gap]
            denominator=sum(r['oracle_safe_available'] for r in group)
            cov.append(sum(r['safe_accepted'] for r in group)/denominator if denominator else 0.)
            retain.append(sum(r['safe_accepted'] and r['mode']=='C' for r in group)/len(group) if group else 0.)
        marker,line=styles[method]
        for ax,values in zip(axes[:2],(cov,retain)):
            ax.plot(np.asarray(gaps)*1000,np.asarray(values)*100,color=methodcolors[method],marker=marker,linestyle=line,markersize=3,linewidth=.9,label=method)
            ax.set_xscale('log',base=2);ax.set_xticks(np.asarray(gaps)*1000,[str(int(g*1000)) for g in gaps]);ax.set_ylim(-3,103);ax.set_xlabel('Gap (mm)')
    axes[0].set_ylabel('Oracle-safe query coverage (%)');axes[0].axhline(20,color='#888888',linestyle='--',linewidth=.7)
    axes[1].set_ylabel('Safe C retention / all queries (%)')
    infer=read(out/'evaluation'/('round'+str(finalround))/'INFERENCE_TIMING.json')['all_ms']
    ready=read(out/'evaluation'/('round'+str(finalround))/'FULL_READY_TIMING.json');rng=np.random.default_rng(26)
    timings=[infer,[r['command_ready_ms'] for r in ready if r['warm_or_cold']=='COLD'],[r['command_ready_ms'] for r in ready if r['warm_or_cold']=='WARM']]
    for j,(vals,color,marker) in enumerate(zip(timings,['#555555','#0072B2','#E69F00'],['.','o','s'])):
        axes[2].scatter(j+rng.uniform(-.16,.16,len(vals)),vals,s=7 if j==0 else 11,marker=marker,color=color,alpha=.18 if j==0 else .55)
    axes[2].set_yscale('log');axes[2].axhline(20,color='#111111',linestyle='--',linewidth=.7)
    axes[2].set_xticks([0,1,2],['Infer','Cold','Warm']);axes[2].set_ylabel('Elapsed time (ms, log)')
    axes[2].set_ylim(.5,max(max(v) for v in timings if v)*1.3)
    handles=[Line2D([],[],color=methodcolors[m],marker=styles[m][0],linestyle=styles[m][1],label=m.replace('_',' ')) for m in methodcolors]
    fig.legend(handles=handles,loc='outside lower center',ncol=3,frameon=False)
    finalize_figure(fig);add_panel_labels(fig,style='ieee')
    render_preview(fig,str(destination/'coverage_timing_preview.png'),dpi=150);qa2=audit_layout(fig)
    if finalize: export_exact(fig,destination/'STEP26_coverage_timing',(7.16,3.3))
    plt.close(fig)
    audit={'skill':'scipilot-figure','round':int(finalround),'publication':'IEEE double-column7.16in;600DPI PNG andembedded-font PDF',
        'margin_layout_issues':qa1,'coverage_timing_layout_issues':qa2,'no_mean_bars':True,'no_inferential_CI':True,
        'shared_gap_queries_not_independent_repeats':True,'jitter_for_display_only_seed':26,'models_not_refit':True,'new_QP_physics':0}
    if finalize:
        audit['file_checks']={str(p.name):check_figure(str(p),min_dpi=600,target_inches=(7.16,3.45 if 'margin' in p.name else 3.3))
            for p in destination.glob('STEP26_*') if p.suffix in ('.pdf','.png') and 'grayscale' not in p.name}
    (destination/'FIGURE_QA.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2,default=str)+'\n',encoding='utf-8')
    print(json.dumps(audit,default=str))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--finalize',action='store_true')
    args=p.parse_args();figures(args.output,args.finalize)
