"""Saved-only STEP26 analysis. No model fitting, inference, QP or integration."""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
import json
from pathlib import Path
from statistics import mean


def _read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")


def _csv(path, rows):
    keys = list(dict.fromkeys(key for row in rows for key in row))
    with Path(path).open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=keys)
        writer.writeheader()
        writer.writerows({key: json.dumps(value, ensure_ascii=False) if isinstance(value, (dict, list)) else value
                         for key, value in row.items()} for row in rows)


def _stats(values):
    values = sorted(float(v) for v in values if v is not None)
    if not values:
        return {"n": 0, "p50_ms": None, "p95_ms": None, "p99_ms": None, "max_ms": None}
    def percentile(p):
        index = (len(values) - 1) * p
        lo = int(index)
        return values[lo] + (values[min(lo + 1, len(values) - 1)] - values[lo]) * (index - lo)
    return {"n": len(values), "p50_ms": percentile(.5), "p95_ms": percentile(.95),
            "p99_ms": percentile(.99), "max_ms": max(values)}


def _physical_status(label):
    if label.get("original_failure") is not None:
        return "OBSERVED_PHYSICAL_FAILURE"
    if not label.get("complete", False):
        return "UNKNOWN_INCOMPLETE"
    return "COMPLETE_PASS" if label.get("original_physical_safe", False) else "OBSERVED_PHYSICAL_FAILURE"


def _metrics(rows):
    safe = [r for r in rows if r.get("safe_accepted")]
    oracle = sum(bool(r.get("oracle_safe_available")) for r in rows)
    progress = [r["actual_endpoint_progress_m"] for r in safe if r.get("actual_endpoint_progress_m") is not None]
    progress20 = [r["actual_step_progress_m"] for r in safe if r.get("actual_step_progress_m") is not None]
    return {"queries": len(rows), "accepts": sum(bool(r["accepted"]) for r in rows),
            "safe_accepts": len(safe), "unsafe_accepts": sum(bool(r["unsafe_accepted"]) for r in rows),
            "oracle_safe_queries": oracle, "oracle_safe_coverage": len(safe) / oracle if oracle else None,
            "ABSTAIN": sum(r["mode"] == "ABSTAIN" for r in rows),
            "C_retained": sum(r["mode"] == "C" and r["safe_accepted"] for r in rows),
            "B_safe_accepts": sum(r["mode"] == "B" for r in safe),
            "missed_oracle_safe_queries": sum(r["oracle_safe_available"] and not r["safe_accepted"] for r in rows),
            "recognized_safe_task_progress_mean_m": mean(progress) if progress else None,
            "recognized_safe_step_progress_mean_m": mean(progress20) if progress20 else None}


def report(out):
    """Flatten frozen saved data and write the compact evidence handoff."""
    out = Path(out).resolve()
    freezes = [_read(out / "models" / f"round{n}" / "MODELS_FROZEN.json") for n in (1, 2)]
    if not all(item.get("frozen_before_test_open") for item in freezes):
        raise ValueError("Saved frozen-before-test evidence required")
    finished, manifest = _read(out / "RUN_FINISHED.json"), _read(out / "STEP26_PROTOCOL_AND_MANIFEST.json")
    registry, rounds = _read(out / "SPLIT_REGISTRY.json"), _read(out / "SPRINT_ROUNDS.json")
    labels = {r["context_id"]: _read(out / r["bank_directory"] / "LABELS.json") for r in registry}
    by_id = {r["context_id"]: r for r in registry}
    cases, query_rows, ready_rows, fresh_rows, points, groups, summaries = [], [], [], [], [], [], []
    references = [{k: value.get(k) for k in ("episode_id", "d_ref_m", "status", "actual_vx_range_m_s",
                   "max_abs_vx_m_s", "motion_excitation_reaches_0p08_m_s", "missing_snapshot_ticks")}
                  for value in (_read(p) for p in sorted((out / "references").glob("*.json")))]
    for record in registry:
        for branch in ("C", "B"):
            label = labels[record["context_id"]][branch]
            cases.append({"round": record["round_id"], "context_id": record["context_id"],
                          "episode_id": record["episode_id"], "split": record["split"], "branch": branch,
                          "health_kind": record["context"]["health_kind"], "attempt_id": record["attempt_id"],
                          "snapshot_eligible": record["snapshot_eligible"],
                          "current_candidate_valid": record["current_candidate_valid"],
                          "vx_m_s": record["context"]["vx_m_s"], "complete": label.get("complete", False),
                          "D_true_m": label.get("D") if label.get("complete") else None,
                          "status": label.get("status", "NO_USABLE_TRAJECTORY"),
                          "physical_status": _physical_status(label),
                          "original_physical_safe_saved": label.get("original_physical_safe"),
                          "terminal_pass": label.get("terminal_pass") if label.get("complete") else None,
                          "actual_original_valid": label.get("valid", False),
                          "endpoint_progress_m": label.get("endpoint_progress_m"),
                          "reason": label.get("reason"), "observed_physical_failure": label.get("original_failure")})
    for entry in rounds:
        n = entry["round"]
        folder = out / "evaluation" / f"round{n}"
        queries = _read(folder / "TEST_QUERIES.json")
        m3 = [r for r in queries if r["method"] == "M3_FAST_MARGIN"]
        query_rows.extend({k: v for k, v in r.items() if k not in ("M3_prediction", "M3_reasons")} for r in queries)
        ready = _read(folder / "FULL_READY_TIMING.json")
        ready_rows.extend({"round": n, **{k: v for k, v in r.items() if k not in ("model_prediction", "tau_sent")}} for r in ready)
        timing = {kind: {**_stats([r["command_ready_ms"] for r in ready if r["warm_or_cold"] == kind]),
                         "deadline_misses": sum(r["deadline_miss"] for r in ready if r["warm_or_cold"] == kind),
                         "invalid_commands": sum(not r["command_valid"] for r in ready if r["warm_or_cold"] == kind)}
                  for kind in ("COLD", "WARM")}
        timing["ALL"] = {**_stats([r["command_ready_ms"] for r in ready]),
                         "deadline_misses": sum(r["deadline_miss"] for r in ready)}
        component_means = {key: mean(r[key] for r in ready) for key in
                           ("input_prepare_ms", "nominal_generation_ms", "feature_ms", "inference_ms", "first_backup_ms", "final_clip_ms")}
        point_by_context = defaultdict(list)
        for row in m3:
            point_by_context[row["context_id"]].append(row)
        for context_id, context_queries in point_by_context.items():
            prediction = context_queries[0]["M3_prediction"]
            if prediction is None:
                continue
            for branch in ("C", "B"):
                item, label = prediction[branch], labels[context_id][branch]
                points.append({"round": n, "context_id": context_id, "branch": branch,
                               "health_kind": by_id[context_id]["context"]["health_kind"],
                               "D_true_m": label.get("D") if label.get("complete") else None,
                               "U_m": item["U"], "D_hat_m": item["D_hat"],
                               "validity_score": item["validity_score"], "validity_threshold": item["validity_threshold"],
                               "gate_passed": item["gate_passed"], "gate_reasons": item["reasons"],
                               "actual_original_valid": label["valid"], "actual_complete": label["complete"],
                               "physical_status": _physical_status(label), "ood_passed": prediction["ood_passed"],
                               "accepted_any_gap": any(q["accepted"] and q["mode"] == branch for q in context_queries),
                               "unsafe_accepted_any_gap": any(q["unsafe_accepted"] and q["mode"] == branch for q in context_queries),
                               "D_exceeds_U": label.get("complete") and item["U"] is not None and label["D"] > item["U"]})
        for item in _read(folder / "FRESH_CHECKS.json"):
            m2, decision, actual = item.get("M2", {}), item.get("M3", {}), item.get("M3_actual_label", {})
            fresh_rows.append({"round": n, "context_id": decision.get("context_id", m2.get("context_id")),
                               **{"M2_" + k: v for k, v in m2.items() if k != "paths"},
                               **{"M3_" + k: v for k, v in decision.items() if k not in ("model_prediction", "tau_sent")},
                               "actual_complete": actual.get("complete"), "actual_valid": actual.get("valid"),
                               "actual_D_m": actual.get("D"), "actual_physical_status": _physical_status(actual),
                               "actual_status": actual.get("status"),
                               "actual_local_workspace_safe": actual["D"] <= decision["gap_m"] if actual.get("complete") else None,
                               "actual_endpoint_progress_m": actual.get("endpoint_progress_m"),
                               "actual_step_progress_m": actual.get("progress20_m"),
                               "actual_observed_physical_failure": actual.get("original_failure"),
                               "actual_terminal_pass": actual.get("terminal_pass") if actual.get("complete") else None,
                               "actual_reason": actual.get("reason"),
                               "command_ready_matches_first_executed_sent": item.get("command_ready_matches_first_executed_sent")})
        for health in sorted({r["context"]["health_kind"] for r in registry}):
            health_cases = [r for r in cases if r["round"] == n and r["health_kind"] == health]
            health_queries = [r for r in m3 if r["health_kind"] == health]
            groups.append({"round": n, "health_kind": health, "planned_contexts": len(health_cases) // 2,
                           "bank_scope": "ALL_PLANNED_ROUND", "query_scope": "HELD_OUT_M3_ONLY",
                           "candidate_invalid_contexts": sum(not r["current_candidate_valid"] for r in health_cases) // 2,
                           "bank_branches": len(health_cases), "complete_branches": sum(r["complete"] for r in health_cases),
                           "valid_branches": sum(r["actual_original_valid"] for r in health_cases),
                           "incomplete_branches": sum(not r["complete"] for r in health_cases),
                           "failed_numerical_branches": sum(r["status"] == "FAILED_NUMERICAL" for r in health_cases),
                           "no_usable_trajectory_branches": sum(r["status"] == "NO_USABLE_TRAJECTORY" for r in health_cases),
                           "observed_physical_failure_branches": sum(r["physical_status"] == "OBSERVED_PHYSICAL_FAILURE" for r in health_cases),
                           "unknown_incomplete_physical_branches": sum(r["physical_status"] == "UNKNOWN_INCOMPLETE" for r in health_cases),
                           "terminal_failure_complete_branches": sum(r["complete"] and not r["terminal_pass"] for r in health_cases),
                           **_metrics(health_queries)})
        round_points = [p for p in points if p["round"] == n]
        gates = {branch: {"current_feature_unavailable": sum("CURRENT_FEATURES_UNAVAILABLE" in p["gate_reasons"] for p in round_points if p["branch"] == branch),
                         "validity_reject_contexts": sum("VALIDITY_REJECT" in p["gate_reasons"] for p in round_points if p["branch"] == branch),
                         "OOD_reject_contexts": sum(not p["ood_passed"] for p in round_points if p["branch"] == branch),
                         "uncalibrated_contexts": sum("UNCALIBRATED" in p["gate_reasons"] for p in round_points if p["branch"] == branch),
                         "D_exceeds_U_complete_contexts": sum(p["D_exceeds_U"] for p in round_points if p["branch"] == branch),
                         "local_margin_reject_queries": sum("LOCAL_MARGIN_REJECT" in q["M3_reasons"].get(branch, []) for q in m3 if q["M3_reasons"])}
                 for branch in ("C", "B")}
        summaries.append({"round": n, "role": "DEVELOPMENT" if n == 1 else "FINAL_HELD_OUT",
                          "selected_config": entry["fit"]["selected"], "CAL_selection": entry["fit"]["CAL_selection"],
                          "TEST": entry["TEST"], "metrics_recomputed": _metrics(m3), "inference": entry["inference"],
                          "method_metrics": {method: _metrics([r for r in queries if r["method"] == method])
                                             for method in sorted({r["method"] for r in queries})},
                          "M3_unsafe_complete_terminal_only_queries": sum(q["unsafe_accepted"] and q["original_physical_safe"] is True
                              and q["local_workspace_safe"] is True and q["original_terminal_pass"] is False
                              and labels[q["context_id"]][q["mode"]]["complete"] for q in m3),
                          "full_command_ready": timing, "component_mean_ms": component_means, "gates": gates,
                          "model_settings": {kind: _read(out / "models" / f"round{n}" / f"step26_model_{kind}_freeze.json")
                                             for kind in ("A", "B")}})
    ledger_status, events = Counter(), Counter()
    qp_real = qp_unknown = 0
    for line in (out / "STEP26_LEDGER.jsonl").open(encoding="utf-8"):
        event = json.loads(line)
        events[event["event"]] += 1
        if event["event"] == "QP_RETURN":
            ledger_status[str(event.get("status", "UNKNOWN"))] += 1
            qp_real += event.get("real_optimizer_called") is True
            qp_unknown += "real_optimizer_called" not in event
    speeds = [abs(r["context"]["vx_m_s"]) for r in registry if r["snapshot_eligible"]]
    result = {"schema": "STEP26_SAVED_RESULTS_V1", "primary_conclusion": "SURROGATE_NOT_ESTABLISHED",
              "secondary_conclusion": "CONTROL_BACKEND_BOTTLENECK", "numerical_status": finished["status"],
              "budget": finished["budget"], "planned_contexts": len(registry), "eligible_contexts": sum(r["snapshot_eligible"] for r in registry),
              "current_candidate_valid_contexts": sum(r["current_candidate_valid"] for r in registry),
              "counterfactual_branches": len(cases), "complete_counterfactual_branches": sum(r["complete"] for r in cases),
              "observed_physical_failure_branches": sum(r["physical_status"] == "OBSERVED_PHYSICAL_FAILURE" for r in cases),
              "unknown_incomplete_physical_branches": sum(r["physical_status"] == "UNKNOWN_INCOMPLETE" for r in cases),
              "terminal_failure_complete_branches": sum(r["complete"] and not r["terminal_pass"] for r in cases),
              "reference_episodes": references, "eligible_decision_abs_vx_range_m_s": [min(speeds), max(speeds)],
              "QP_return_status_counts": dict(ledger_status), "real_QP_returns": qp_real, "QP_return_identity_unknown": qp_unknown,
              "ledger_event_counts": dict(events), "rounds": summaries, "health_groups": groups,
              "post_command_ready_disk_write_ms": None,
              "post_command_ready_disk_write_recording": "NOT_RECORDED_PER_DECISION",
              "shared_bank_gap_queries_are_not_independent_trajectories": True,
              "safe_task_progress_without_safe_acceptance": None, "final_TEST_tuning": False, "development_rounds": len(rounds)}
    _write(out / "STEP26_RESULTS.json", result)
    for filename, rows in (("STEP26_RESULTS.csv", query_rows), ("CASE_OUTCOMES.csv", cases),
                           ("FRESH_RESULTS.csv", fresh_rows), ("FULL_READY_TIMING.csv", ready_rows),
                           ("PREDICTION_POINTS.csv", points), ("GROUP_RESULTS.csv", groups)):
        _csv(out / filename, rows)
    _documents(out, result, manifest, fresh_rows)
    return result


def _documents(out, result, manifest, fresh_rows):
    budget = result["budget"]
    lines = ["# STEP26：快速恢复余量研发结果", "", "## Material Passport", "",
             f"- ID：{manifest['run_id']}；日期：2026-10-08（Asia/Seoul）。",
             "- 模式：experiment-agent run；Verification Status：ANALYZED。",
             "- 来源：冻结协议、实际反事实 bank、一次性留出评价、fresh 执行和完整 ledger。", "",
             "结论为 **SURROGATE_NOT_ESTABLISHED**，同时存在 **CONTROL_BACKEND_BOTTLENECK**。最终留出没有观察到不安全接受，但 240 个查询全部 ABSTAIN；121 个存在 oracle 安全分支的查询接受覆盖为 0%，未达到 20% 要求。", "",
             "第一轮 −80 mm episode 已用于第二轮开发；最终确认数据仅为新生成的 ±60 mm episodes。两轮均按 CAL 选择 A，第一轮 CAL 覆盖 0%，第二轮 4.29%。第二轮结束后没有调参或第三轮。", "",
             "## 方法和样本", "",
             "六条参考 episode 为同一健康初态、同一 recipe/seed 20261170 的短距离 stance 任务；参考 x 位移为 ±40、±80、±60 mm，不能称步态行走。每个快照使用 HEALTHY、THIGH_50、THIGH_15、CALF_50、CALF_15 五个能力上下文，方向和故障通道由编译映射确定。", "",
             f"计划 {result['planned_contexts']} 个上下文，资格合格 {result['eligible_contexts']} 个，当前候选可用 {result['current_candidate_valid_contexts']} 个；{result['counterfactual_branches']} 条 C/B bank 分支中 {result['complete_counterfactual_branches']} 条完整。决策点 |vx| 范围为 [{result['eligible_decision_abs_vx_range_m_s'][0]:.6f}, {result['eligible_decision_abs_vx_range_m_s'][1]:.6f}] m/s。", "",
             "| episode | 参考位移 mm | 真实 vx 范围 m/s | 最大绝对 vx m/s | 达到 0.08 m/s |", "|---|---:|---|---:|---|"]
    for r in result["reference_episodes"]:
        lines.append(f"| {r['episode_id']} | {r['d_ref_m'] * 1000:+.0f} | {r['actual_vx_range_m_s']} | {r['max_abs_vx_m_s']:.6f} | {r['motion_excitation_reaches_0p08_m_s']} |")
    lines += ["", "48 个当前特征使用 TRAIN-only 标准化。C 持有当前候选 20 ms 后执行反馈 backup；B 立即执行同一 backup。两条 actual teacher 轨迹独立恢复初态，检查初始状态和全部 500 个物理步，horizon 1 s、dt 2 ms。固定 gap 1/2/4/8/16/32 mm 的查询共享 C/B bank，不是新增独立轨迹。M1 只读 20 ms preview；oracle 为离线实际反事实上限。", "",
              "A 为二次特征＋Ridge(alpha=1e-3) 和 LogisticRegression(C=1,max_iter=2000)；B 为 128 棵、深度 5、min_samples_leaf=3、seed 26、n_jobs=1 的 RF。使用 scikit-learn 1.9.1，完整依赖见 DEPENDENCY_LOCK.json。接口来源：[Ridge](https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.Ridge.html)、[LogisticRegression](https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LogisticRegression.html)、[RF regressor](https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.RandomForestRegressor.html)、[RF classifier](https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.RandomForestClassifier.html)。", "",
              "U=max(0,D_hat)+max(0,max_CAL(D−D_hat))+1 mm。有效性阈值至少 0.90，严格高于 CAL 全部不安全/不可用样本得分；OOD 为 TRAIN 标准化距离、3 倍 CAL 最大最近距离、数值底限 1e−12。固定 1 mm 是设计储备，经验校准和 OOD 门没有统计覆盖保证。模型、scaler、阈值和余量均在打开各轮 TEST 前冻结。", "",
              "## 两轮留出与门控", "", "| 轮次 | 用途 | 查询 | 误接受 | oracle 安全 | 安全覆盖 | C 保留 | ABSTAIN |", "|---|---|---:|---:|---:|---:|---:|---:|"]
    for r in result["rounds"]:
        t = r["TEST"]
        lines.append(f"| {r['round']} | {r['role']} | {t['queries']} | {t['unsafe_accepts']} | {t['oracle_safe_queries']} | {t['oracle_safe_coverage']:.1%} | {t['C_retained']} | {t['ABSTAIN']} |")
    for r in result["rounds"]:
        lines.append("")
        for b in ("C", "B"):
            f, g = r["model_settings"]["A"]["branches"][b], r["gates"][b]
            lines.append(f"第 {r['round']} 轮 {b}：有效性阈值 {f['validity_threshold']:.15g}，CAL 余量 {f['cal_margin_m'] * 1000:.6f} mm；{g['validity_reject_contexts']} 个上下文有效性拒收、{g['OOD_reject_contexts']} 个 OOD 拒收；{g['local_margin_reject_queries']} 个 gap 查询余量拒收，完整轨迹 D>U 的上下文 {g['D_exceeds_U_complete_contexts']} 个。")
    lines += ["", "第一轮 16 个接受均选择 B，原物理和 local 均通过，失败来自完整轨迹的终端要求；不能称为物理跌倒或位移上界误接受。最终 A 的 CAL 不安全得分接近 1，把阈值推至约 0.9999997（C）与 0.9999976（B）；有效性门失去覆盖。没有获认可的安全接受，因此任务进度均值记为缺失，不能用 0 伪装为任务保留证据。分 health 结果见 GROUP_RESULTS.csv，完整分支事实见 CASE_OUTCOMES.csv。", "",
              "| 轮次 | 同 bank 方法 | 安全接受 | 不安全接受 | oracle 安全覆盖 | ABSTAIN |", "|---|---|---:|---:|---:|---:|"]
    for r in result["rounds"]:
        for method, m in r["method_metrics"].items():
            lines.append(f"| {r['round']} | {method} | {m['safe_accepts']} | {m['unsafe_accepts']} | {m['oracle_safe_coverage']:.1%} | {m['ABSTAIN']} |")
    lines += ["",
              f"全 bank 中已观察到原物理违反的分支 {result['observed_physical_failure_branches']} 条；未完整且未观察到物理违反的 {result['unknown_incomplete_physical_branches']} 条，归为数值/执行不可用。完整轨迹终端失败 {result['terminal_failure_complete_branches']} 条。数值未完成不是物理跌倒，峰值 D 保持缺失；已有接触等物理违反按实际事实保留。", "",
              "## 组件与完整出令时延", "", "| 轮次/边界 | n | p50 ms | p95 ms | p99 ms | max ms | 超过 20 ms |", "|---|---:|---:|---:|---:|---:|---:|"]
    for r in result["rounds"]:
        inference = r["inference"]
        lines.append(f"| {r['round']}/resident 推断 | {inference['iterations']} | {inference['p50_ms']:.4f} | {inference['p95_ms']:.4f} | {inference['p99_ms']:.4f} | {inference['max_ms']:.4f} | 组件目标 p99≤1 ms 未达标 |")
        for kind, stats in r["full_command_ready"].items():
            lines.append(f"| {r['round']}/{kind} command-ready | {stats['n']} | {stats['p50_ms']:.4f} | {stats['p95_ms']:.4f} | {stats['p99_ms']:.4f} | {stats['max_ms']:.4f} | {stats['deadline_misses']} |")
    for r in result["rounds"]:
        lines.append("")
        lines.append(f"第 {r['round']} 轮完整路径组件平均耗时 ms：{json.dumps(r['component_mean_ms'], ensure_ascii=False)}。")
    final_fresh = [r for r in fresh_rows if r["round"] == 2]
    lines += ["", "完整时延包含输入准备、候选 QP、当前特征和资格、M3 推断/选择、必要的首条 backup QP、clip 及 command-ready 前 ledger 同步写出；没有提前积分。command-ready 之后的磁盘写出在出令计时区间外，其逐条耗时未单独记录，保留为缺失项。冷启动含控制器构建，warm 保持 resident 路径。正常拒收和无有效命令的时间也全部保留，没有取最快重复。", "",
              f"最终 6 个 fresh M3 全部为 ABSTAIN 后 best-effort B；其首条实际发送命令与 fresh command-ready 一致 {sum(r['command_ready_matches_first_executed_sent'] is True for r in final_fresh)}/6。这些执行没有筛选认可，不能计为安全接受。两轮全部 fresh M2/M3 的选择、实际事实和耗时见 FRESH_RESULTS.csv；M2 数值过程完成不等于全部分支轨迹完整。", "",
              "## 预算、复现和交付", "",
              f"真实 QP {budget['total_QP_calls']} / 16000；积分 {budget['total_physics_steps']} / 160000；数值墙钟 {budget['numerical_elapsed_s']:.3f} / 7200 s。4 个模型配置拟合事件、16 次实际子估计器拟合；DEV 上下文重算 {budget['DEV_context_recomputations']}。QP 返回状态：{json.dumps(result['QP_return_status_counts'], ensure_ascii=False)}；缺失真实优化器身份的返回 {result['QP_return_identity_unknown']} 次。没有隐去失败尝试。", "",
              "模型资产和分支校准见 models/round1、models/round2；NPZ 紧凑 bank、LABELS、原始 query/timing/fresh JSON 与尝试 ledger 保留。STEP26_RESULTS.csv 为所有 M0/M1/M3 gap 查询；PREDICTION_POINTS.csv 为每轮 TEST 上下文×分支一次的数据点。", "",
              "保存数据分析命令：`python -B -X utf8 -m cavr_wbc.experiments.step26_report --output <本运行目录>`。新的数值复现命令为 `python -B -X utf8 -m cavr_wbc.experiments.step26_sprint --output <新的唯一目录> --run-id <新 ID>`，使用 DEPENDENCY_LOCK.json 中 E 盘解释器与 PYTHONPATH；不能覆写本次冻结输出。", "",
              "该结果检验单 seed、单机器人、相关初态上的单次恢复筛选，不能外推多 seed、模型失配、持续闭环 recoverability、连续时间保证或硬件实时性。后续研究应独立设计能校准有效性且具有 oracle 安全覆盖的状态分布，并分开解决候选/backup QP 与 Python 出令路径的瓶颈；本轮按两轮规则结束。"]
    (out / "STEP26_REPORT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    handoff = ["# STEP26 研究交接", "", "结论：SURROGATE_NOT_ESTABLISHED；完整控制后端仍为 CONTROL_BACKEND_BOTTLENECK。", "",
               "最终 ±60 mm 留出：40 上下文、240 gap 查询，0 误接受、240 ABSTAIN；oracle 安全查询 121，安全接受覆盖 0%。第一轮 −80 mm 测试已明确用于第二轮 DEV，16 次不安全接受保留为开发结果。最终留出后没有调整权重、阈值、特征或配置。", "",
               "A 在两轮 CAL 被选择；最终 CAL 安全覆盖仅 4.29%，有效性阈值几乎为 1。Ridge 的 D 上界和有效性门应分开看，PREDICTION_POINTS.csv 同时提供 D/U、分类得分、阈值和 actual 事实，不能把全部拒收称为成功。", "",
               "两轮 resident p99 为 1.6335/1.9056 ms，组件 1 ms 目标未达。完整出令 60/60 与 118/120 超过 20 ms；最终 cold 40/40、warm 78/80 超时。即使接口完成，也没有在线控制通过证据。", "",
               "继续研究的具体输入：冻结的 48 特征、两组配置、TRAIN/CAL/FINAL 分组、完整/数值未完成/物理违反/终端失败分列。新的研发应先提出新的分布或校准设计，保持最终留出独立，优化 native QP 到 command-ready 的整条路径；不对本最终 TEST 继续调参，不自动第三轮或进入 E3/RL/硬件。", "",
               "阅读顺序：STEP26_RESULTS.json → GROUP_RESULTS.csv/CASE_OUTCOMES.csv → PREDICTION_POINTS.csv → FULL_READY_TIMING.csv/FRESH_RESULTS.csv；原始数值资产由 SPLIT_REGISTRY.json 的路径和 hash 定位。复现命令和固定版本见 STEP26_REPORT.md、DEPENDENCY_LOCK.json。"]
    (out / "STEP26_RESEARCH_HANDOFF.md").write_text("\n".join(handoff) + "\n", encoding="utf-8")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    report(parser.parse_args().output)
