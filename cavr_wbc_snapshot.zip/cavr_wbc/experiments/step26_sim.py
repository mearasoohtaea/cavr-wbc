"""Compact STEP26 trajectories with unchanged STEP25 execution semantics.

Only this module propagates STEP26 reference, teacher and fresh prediction
trajectories.  Every branch restores a complete independent integration state,
uses the original capacity PID interface, and observes the common hard budget.
"""
from __future__ import annotations

from copy import deepcopy
from time import perf_counter
from types import SimpleNamespace
from typing import Mapping

import mujoco
import numpy as np

from cavr_wbc.control.step20_task_reference import reference
from cavr_wbc.control.step22_pose_servo import Step22WBC
from cavr_wbc.control.step23_backup_filter import (
    CHECKPOINT_STEPS, CONTROL_DT_S, CONTROL_SLOTS, HOLD_VERSION, PHYSICS_DT_S,
    PHYSICS_STEPS, PHYSICS_STEPS_PER_SLOT, _facts, _finite_state, _json_safe,
    clone_data, predicted_physical_check, state_values,
)
from cavr_wbc.control.step25_capacity_backup import (
    CAPACITY_VERSION, CapacityHoldBackup, CapacityPoseServo, _candidate_interface,
    _health_limits, _ledger_wall_s, _metadata, capacity_command, preview_candidate,
)
from cavr_wbc.experiments import step17_formal_panel as frozen
from cavr_wbc.platforms.go2_mujoco import FOOT_NAMES, extract_healthy_torque_limits


VERSION = "STEP26_COMPACT_TRAJECTORIES_V1"
REFERENCE_TICKS = 110
REFERENCE_STEPS = 1100
FACT_KEYS = (
    "scenario_id", "tick", "time_s", "qpos", "qvel", "base_joint_height_m",
    "subtree_com", "subtree_com_height_m", "base_body_id", "health_vector",
    "action", "backup_id", "tau_cmd", "tau_applied", "actuator_limits",
    "command_torque_margin_nm", "applied_torque_margin_nm", "command_torque_ok",
    "applied_torque_ok", "contacts", "joint_limit_margins", "friction_coeff",
    "velocity_x_m_s", "velocity_y_m_s", "roll", "pitch", "latency_ms",
    "boundary_margin_m", "physics_step", "simulation_time_s",
)


def _check(budget):
    if budget is not None:
        budget.check()


def _callback(budget, kind, owner, first_mode=None):
    return budget.qp_callback(kind, owner, first_mode) if budget is not None else None


def _observer(budget, kind, owner):
    return budget.step_observer(kind, owner) if budget is not None else None


def _budget_call(operation):
    """Preserve a trajectory prefix when its common guard stops numerical work."""
    try:
        return operation(), None
    except Exception as exc:
        if "budget" not in type(exc).__name__.lower() and type(exc).__name__ != "SprintLimit":
            raise
        return None, {"reason": "GLOBAL_BUDGET_EXHAUSTED", "exception_type": type(exc).__name__,
                      "message": str(exc)}


def _compact_fact(row):
    """Retain numeric evidence, discarding cached labels and redundant state."""
    result = {key: row[key] for key in FACT_KEYS if key in row}
    for key in ("tau_raw", "tau_sent", "effective_capacity_nm", "actual_mujoco_qacc",
                "global_boundary_margin_m", "context_id", "faulted_actuator_name",
                "faulted_actuator_index", "faulted_health"):
        if key in row:
            result[key] = row[key]
    return result


def compact_fact(model, data, health, limits, tau, action, ms, step, slot, bid,
                 branch_id, interface, metadata):
    row = _facts(model, data, health, limits, tau, action, ms, step, slot, bid, branch_id)
    row.update(tau_raw=interface["tau_raw"], tau_sent=np.asarray(tau).tolist(),
               effective_capacity_nm=interface["effective_capacity_nm"],
               actual_mujoco_qacc=data.qacc.copy().tolist(),
               global_boundary_margin_m=row["boundary_margin_m"], **metadata)
    return _compact_fact(row)


def restore_snapshot(model, snapshot):
    """Restore integration and warmstart into a fresh MjData, resetting only time."""
    saved = snapshot.get("state", snapshot.get("source_state", snapshot))
    signature = int(saved["integration_state_signature"])
    if signature != int(mujoco.mjtState.mjSTATE_INTEGRATION):
        raise ValueError("STEP26 snapshot must contain mjSTATE_INTEGRATION")
    vector = np.asarray(saved["integration_state"], dtype=float)
    if vector.shape != (mujoco.mj_stateSize(model, signature),) or not np.isfinite(vector).all():
        raise ValueError("STEP26 snapshot integration state is incomplete/nonfinite")
    data = mujoco.MjData(model)
    mujoco.mj_setState(model, data, vector.copy(), signature)
    data.time = 0.
    mujoco.mj_forward(model, data)
    for name in ("qpos", "qvel", "act", "ctrl", "qacc_warmstart", "qfrc_applied",
                 "xfrc_applied", "mocap_pos", "mocap_quat", "userdata", "plugin_state"):
        if name in saved:
            actual = np.asarray(getattr(data, name))
            expected = np.asarray(saved[name], dtype=float)
            if actual.size != expected.size or not np.array_equal(actual, expected.reshape(actual.shape)):
                raise ValueError("STEP26 forward changed restored integration field " + name)
    return data


def reference_episode(model, scenario, d_m, episode_id, snapshot_ticks, budget):
    """Generate the fixed healthy 2.2 s stance reference and pre-control snapshots."""
    _check(budget)
    begin = perf_counter()
    ticks = tuple(int(t) for t in snapshot_ticks)
    if len(set(ticks)) != len(ticks) or any(t < 0 or t >= REFERENCE_TICKS for t in ticks):
        raise ValueError("STEP26 snapshot ticks must be unique reference control ticks")
    data = mujoco.MjData(model)
    reset_scenario = SimpleNamespace(**scenario) if isinstance(scenario, Mapping) else scenario
    frozen._reset(model, data, reset_scenario)
    if np.any(data.qfrc_applied) or np.any(data.xfrc_applied):
        raise ValueError("STEP26 healthy reference requires the original zero external forces")
    initial = state_values(model, data)
    q_init = data.qpos.copy()
    health = np.ones(int(model.nu))
    limits = extract_healthy_torque_limits(model)
    controller = Step22WBC(model, solve_callback=_callback(budget, "REFERENCE", episode_id))
    servo = CapacityPoseServo(model, q_init, d_m, "S22_POSE_PID")
    observer = _observer(budget, "REFERENCE", episode_id)
    previous = capacity_command(np.asarray(data.ctrl), health, limits, 1)
    snapshots = []
    steps = 0
    forward_calls = 0
    controls = []
    failure = None
    vmin = vmax = float(data.qvel[0])
    for tick in range(REFERENCE_TICKS):
        _check(budget)
        if not _finite_state(data):
            failure = {"reason": "NONFINITE_REFERENCE_BEFORE_CONTROL", "tick": tick, "physics_step": steps}
            break
        if tick in ticks:
            fact = compact_fact(model, data, health, limits, data.ctrl.copy(), 0., 0., steps,
                                tick, "STEP26-REFERENCE-" + episode_id, episode_id,
                                previous, {"health_vector": health.tolist()})
            physical = predicted_physical_check(fact)
            vx = float(data.qvel[0])
            state = state_values(model, data)
            ref = reference(float(q_init[0]), float(d_m), tick * CONTROL_DT_S)
            snapshots.append({"snapshot_id": f"{episode_id}_T{tick:03d}", "episode_id": episode_id,
                "source_tick": tick, "source_time_s": tick * CONTROL_DT_S,
                "state": state, "nominal_q_init": q_init.tolist(), "nominal_d_m": float(d_m),
                "nominal_b_used": servo.b_integral.copy().tolist(),
                "current_reference": ref, "source_external_reference": ref,
                "x0_m": float(data.qpos[0]), "vx_m_s": vx, "vx": vx,
                "direction": 1 if vx > 0. else -1 if vx < 0. else 0,
                "sign": 1 if vx > 0. else -1 if vx < 0. else 0,
                "healthy_fact": fact, "healthy_physical_check": physical,
                "eligible": bool(physical["pass"] and abs(vx) >= .01),
                "eligibility_reason": None if physical["pass"] and abs(vx) >= .01 else
                    "ORIGINAL_PHYSICAL_UNQUALIFIED" if not physical["pass"] else "ABS_VX_LT_0P01_M_S",
                "backup_anchor_q_init": data.qpos.copy().tolist(),
                "source_integration_state_complete": True})
        response = servo.compute(controller, data, health, tick)
        interface = response["capacity_interface"]
        controls.append({"tick": tick, "time_s": tick * CONTROL_DT_S,
                         "valid_command": bool(response["valid_command"]),
                         "solver_status": response["wbc"].get("status"),
                         "solver_status_val": response["wbc"].get("status_val"),
                         "tau_raw": interface["tau_raw"], "tau_sent": response["tau_cmd"],
                         "latency_ms": response["latency_ms"],
                         "integral_record": response["integral_record"]})
        if not response["valid_command"]:
            failure = {"reason": "INVALID_REFERENCE_QP", "tick": tick, "physics_step": steps,
                       "solver_status_val": response["wbc"].get("status_val")}
            break
        data.ctrl[:] = response["tau_cmd"]
        mujoco.mj_forward(model, data)
        forward_calls += 1
        previous = interface
        for _ in range(PHYSICS_STEPS_PER_SLOT):
            if observer is not None:
                observer()
            mujoco.mj_step(model, data)
            steps += 1
            if not _finite_state(data) or abs(float(data.time) - steps * PHYSICS_DT_S) > 1e-9:
                failure = {"reason": "NONFINITE_REFERENCE_OR_SIMULATOR_RESET", "tick": tick, "physics_step": steps}
                break
            mujoco.mj_forward(model, data)
            forward_calls += 1
            if not _finite_state(data):
                failure = {"reason": "NONFINITE_REFERENCE_REFRESH", "tick": tick, "physics_step": steps}
                break
            vx = float(data.qvel[0])
            vmin, vmax = min(vmin, vx), max(vmax, vx)
        if failure:
            break
    complete = steps == REFERENCE_STEPS and len(controls) == REFERENCE_TICKS and failure is None
    return _json_safe({"schema": VERSION, "episode_id": episode_id, "d_ref_m": float(d_m),
        "status": "COMPLETE" if complete else "FAILED_NUMERICAL", "reason": failure,
        "initial_state": initial, "q_init": q_init.tolist(), "snapshots": snapshots,
        "requested_snapshot_ticks": list(ticks), "controls": controls,
        "missing_snapshot_ticks": [tick for tick in ticks if tick not in {s["source_tick"] for s in snapshots}],
        "actual_vx_range_m_s": [vmin, vmax], "max_abs_vx_m_s": max(abs(vmin), abs(vmax)),
        "motion_excitation_reaches_0p08_m_s": max(abs(vmin), abs(vmax)) >= .08,
        "final_state": state_values(model, data), "solver_ledger": controller.solver_ledger,
        "elapsed_ms": (perf_counter() - begin) * 1000.,
        "counts": {"physical_steps": steps, "control_qp_calls": len(controller.solver_ledger),
                   "reference_controller_instances": 1, "initialization_forward_calls": 1,
                   "forward_calls": forward_calls + 1, "clone_data_calls": 0,
                   "contact_linearization_calls": controller.contact_linearization_calls,
                   "svd_calls": controller.svd_calls, "passive_model_calls": controller.passive_model_calls}})


def nominal(model, current, context, budget, controller=None):
    """Fresh capacity candidate with variable signed STEP26 task displacement."""
    _check(budget)
    begin = perf_counter()
    data = clone_data(model, current)
    limits = extract_healthy_torque_limits(model)
    health, _, _ = _health_limits(context["health_vector"], limits)
    if health.shape != (int(model.nu),):
        raise ValueError("STEP26 health shape differs from model.nu")
    fresh = controller is None
    if fresh:
        controller = Step22WBC(model, solve_callback=_callback(budget, "NOMINAL", context["context_id"]))
    else:
        controller.solve_callback = _callback(budget, "NOMINAL", context["context_id"])
    cursor = len(controller.solver_ledger)
    counts_before = [controller.contact_linearization_calls, controller.svd_calls, controller.passive_model_calls]
    servo = CapacityPoseServo(model, context["nominal_q_init"], context["nominal_d_m"], "S22_POSE_PID")
    servo.b_integral[:] = context["nominal_b_used"]
    response = servo.compute(controller, data, health, context["source_tick"])
    raw_wb = response.pop("wbc")
    response.pop("wb", None)
    response.pop("raw_solver_result", None)
    interface = response["capacity_interface"]
    tau = np.asarray(response["tau_cmd"], dtype=float)
    data.ctrl[:] = tau
    t = perf_counter()
    mujoco.mj_forward(model, data)
    forward_s = perf_counter() - t
    metadata = _metadata(context, health)
    fact = compact_fact(model, data, health, limits, tau,
        float(response["a_base_ref"][0]) if response["a_base_ref"] else 0., response["latency_ms"],
        0, 0, context["backup_id"], context["context_id"], interface, metadata) if _finite_state(data) else None
    physical = predicted_physical_check(fact or {})
    ledger = controller.solver_ledger[cursor:]
    points = np.asarray(controller.last_trace.get("points", []), dtype=float)
    foot_positions = {name: points[i].tolist() for i, name in enumerate(FOOT_NAMES)} if points.shape == (4, 3) else None
    return _json_safe({"schema": "STEP26_NOMINAL_CAPACITY_CANDIDATE_V1", **metadata,
        "command_valid": bool(response["valid_command"]), "tau": tau.tolist(),
        "tau_raw": interface["tau_raw"], "tau_sent": tau.tolist(), "capacity_interface": interface,
        "generation_ms": (perf_counter() - begin) * 1000., "response": response,
        "raw_solver_result": raw_wb, "solver_status": raw_wb.get("status"),
        "solver_status_val": raw_wb.get("status_val"), "raw_solver_variables": response["raw_solver_variables"],
        "qdd": raw_wb.get("qdd"), "contact_lambda": raw_wb.get("contact_force"),
        "QP_validation": raw_wb.get("validation"), "raw_QP_success": bool(raw_wb.get("success")),
        "raw_QP_bound_exact_pass": interface["raw_command_within_capacity_exact"],
        "sent_command_exact_pass": interface["sent_command_within_capacity_exact"],
        "assembly": controller.last_trace, "solver_ledger": ledger,
        "execution_diagnostics": response["execution_diagnostics"], "initial_new_command_fact": fact,
        "foot_positions": foot_positions, "actual_mujoco_qacc": data.qacc.copy().tolist(),
        "current_physical_check": physical, "source_b_used": context["nominal_b_used"],
        "backup_initial_b": [0.] * 6, "nominal_d_m": context["nominal_d_m"],
        "counts": {"nominal_qp_calls": len(ledger), "control_qp_calls": len(ledger),
                   "clone_data_calls": 1, "nominal_controller_instances": int(fresh),
                   "nominal_command_diagnostic_forward_calls": 1,
                   **{key: getattr(controller, key) - previous for key, previous in zip(
                       ("contact_linearization_calls", "svd_calls", "passive_model_calls"), counts_before)}},
        "timing": {"control_total_ms": response["latency_ms"], "solver_wall_s": _ledger_wall_s(ledger),
                   "action_conditioned_forward_s": forward_s,
                   "capacity_interface_ms": interface["capacity_interface_ms"]}})


def preview(model, current, context, candidate, budget):
    _check(budget)
    if not candidate.get("command_valid"):
        return {"schema": VERSION, "status": "FAILED_NUMERICAL", "kind": "PREVIEW",
                "reason": {"reason": "INVALID_CANDIDATE_COMMAND"}, "pass": False,
                "initial_fact": None, "physics_trajectory": [],
                "counts": {"physical_steps": 0, "control_qp_calls": 0}, "elapsed_ms": 0.}
    result = preview_candidate(model, current, context["health_vector"], candidate,
        context["backup_id"], context["context_id"] + ":PREVIEW",
        step_observer=_observer(budget, "PREVIEW", context["context_id"] + ":PREVIEW"))
    result["initial_fact"] = _compact_fact(result["initial_fact"]) if result["initial_fact"] else None
    result["physics_trajectory"] = [_compact_fact(row) if "qpos" in row else row
                                     for row in result["physics_trajectory"]]
    result["kind"] = "PREVIEW"
    return result


def _control_row(slot, source, tau, data, health, interface, response, raw_wb, valid, ms):
    return {"slot": slot, "time_s": slot * CONTROL_DT_S, "action_source": source,
        "valid_command": bool(valid), "tau_total": tau.tolist(), "tau_cmd": tau.tolist(),
        "tau_raw": interface["tau_raw"], "tau_sent": tau.tolist(),
        "tau_applied": data.actuator_force.copy().tolist(), "health_vector": health.tolist(),
        "latency_ms": ms, "capacity_interface": {key: interface[key] for key in
            ("command_valid", "effective_capacity_nm", "saturation_mask",
             "raw_command_within_capacity_exact", "sent_command_within_capacity_exact",
             "raw_99_percent_active_indices", "sent_99_percent_active_indices")},
        "solver_status": (raw_wb or {}).get("status"), "solver_status_val": (raw_wb or {}).get("status_val"),
        "integral_record": deepcopy(response["integral_record"]) if response else None}


def actual_branch(model, current, context, candidate, mode, kind, budget,
                  ready_policy=None, ready_response=None):
    """Independent dense teacher/prediction C or B; no local gap enters control."""
    if mode not in ("C", "B") or kind not in ("ACTUAL_C", "ACTUAL_B", "PREDICTION_C", "PREDICTION_B"):
        raise ValueError("STEP26 needs explicit matching C/B mode and actual/prediction kind")
    if not kind.endswith("_" + mode):
        raise ValueError("STEP26 branch kind does not match first control mode")
    _check(budget)
    begin = perf_counter()
    bid = context["backup_id"]
    branch_id = context.get("branch_id", context["context_id"] + ":" + kind)
    first_mode = "CANDIDATE" if mode == "C" else "BACKUP"
    limits = extract_healthy_torque_limits(model)
    health, _, _ = _health_limits(context["health_vector"], limits)
    if health.shape != (int(model.nu),):
        raise ValueError("STEP26 branch health differs from model.nu")
    metadata = _metadata(context, health)
    anchor = np.asarray(context["backup_anchor_q_init"], dtype=float).copy()
    if (ready_policy is None) != (ready_response is None):
        raise ValueError("STEP26 ready backup needs both independent policy and response")
    if ready_policy is not None:
        if (mode != "B" or ready_policy.backup_id != bid
                or not np.array_equal(ready_policy.anchor_q_init, anchor)):
            raise ValueError("STEP26 ready backup does not match the branch's immutable policy")
        if len(ready_policy.controller.solver_ledger) != 1:
            raise ValueError("STEP26 ready backup must contain exactly its first QP")
        if not np.array_equal(ready_response["integral_record"]["b_used"], np.zeros(6)):
            raise ValueError("STEP26 ready backup must have started at zero integral")
        if not np.array_equal(ready_policy.servo.b_integral, ready_response["integral_record"]["b_after"]):
            raise ValueError("STEP26 ready backup integral no longer matches its first response")
        ready_interface = capacity_command(ready_response["capacity_interface"]["tau_raw"], health, limits,
            ready_response["wbc"].get("status_val"))
        valid_ready = bool(ready_response["valid_command"])
        saved_interface = ready_response["capacity_interface"]
        if (saved_interface["health_vector"] != health.tolist()
                or valid_ready != saved_interface["command_valid"]
                or not np.array_equal(ready_response["tau_cmd"], saved_interface["tau_sent"])
                or (valid_ready and (not ready_interface["command_valid"]
                    or not np.array_equal(ready_response["tau_cmd"], ready_interface["tau_sent"])))):
            raise ValueError("STEP26 ready first command differs from the shared capacity interface")
    if mode == "C" and not candidate.get("command_valid"):
        return {"schema": VERSION, "status": "FAILED_NUMERICAL", "reason": {"reason": "INVALID_CANDIDATE_COMMAND"},
            "kind": kind, "branch_id": branch_id, "first_mode": first_mode, "backup_id": bid,
            "fixed_anchor_q_init": anchor.tolist(), **metadata, "initial_fact": None,
            "initial_state": state_values(model, current), "final_state": state_values(model, current),
            "controls": [], "physics_trajectory": [], "checkpoints": [], "solver_ledger": [],
            "elapsed_ms": (perf_counter() - begin) * 1000., "initialization_ms": 0.,
            "first_backup_decision_ms": 0., "skipped_candidate_invalid": True,
            "counts": {"physical_steps": 0, "backup_qp_calls": 0, "control_qp_calls": 0,
                       "clone_data_calls": 0, "backup_controller_instances": 0}}
    interface_c = _candidate_interface(candidate, health, limits) if mode == "C" else None
    data = clone_data(model, current)
    data.time = 0.
    callback = _callback(budget, "PREDICTION" if kind.startswith("PREDICTION") else "ACTUAL", branch_id, first_mode)
    policy = ready_policy if ready_policy is not None else CapacityHoldBackup(model, anchor, bid, solve_callback=callback)
    if ready_policy is not None:
        policy.controller.solve_callback = callback
    observer = _observer(budget, "PREDICTION" if kind.startswith("PREDICTION") else "ACTUAL", branch_id)
    initial = state_values(model, data)
    initialization_ms = (perf_counter() - begin) * 1000.
    controls, physics, checkpoints, ledger = [], [], [], []
    steps = action_forward = refresh = cursor = 0
    failure = None
    first_backup_ms = 0.
    initial_fact = None
    control_ms = integration_s = refresh_s = fact_s = 0.
    for slot in range(CONTROL_SLOTS):
        _, guard_failure = _budget_call(lambda: _check(budget))
        if guard_failure is not None:
            failure = dict(guard_failure, slot=slot, physics_step=steps)
            break
        if not _finite_state(data):
            failure = {"reason": "NONFINITE_STATE_BEFORE_CONTROL", "slot": slot, "physics_step": steps}
            break
        response = None
        if slot == 0 and mode == "C":
            interface = interface_c
            tau = np.asarray(interface["tau_sent"], dtype=float)
            raw_wb = candidate.get("raw_solver_result", {})
            valid, ms, action = True, 0., 0.
            source = "FIXED_CANDIDATE_TAU_20MS"
        else:
            if slot == 0 and ready_response is not None:
                response = ready_response
            else:
                response, guard_failure = _budget_call(lambda: policy.compute(data, health, slot))
                if guard_failure is not None:
                    for entry in policy.controller.solver_ledger[cursor:]:
                        ledger.append(dict(entry, branch_id=branch_id, kind=kind, slot=slot, backup_id=bid))
                    cursor = len(policy.controller.solver_ledger)
                    failure = dict(guard_failure, slot=slot, physics_step=steps)
                    break
            interface = response["capacity_interface"]
            raw_wb = response["wbc"]
            tau = np.asarray(response["tau_cmd"], dtype=float)
            valid, ms = bool(response["valid_command"]), float(response["latency_ms"])
            action = float(response["a_base_ref"][0]) if response["a_base_ref"] else 0.
            source = "FEEDBACK_BACKUP_QP_TOTAL" if valid else "INVALID_BACKUP_QP"
            control_ms += ms
            if slot == 0:
                first_backup_ms = ms
            for row in policy.controller.solver_ledger[cursor:]:
                ledger.append(dict(row, branch_id=branch_id, kind=kind, slot=slot, backup_id=bid))
            cursor = len(policy.controller.solver_ledger)
        data.ctrl[:] = tau
        mujoco.mj_forward(model, data)
        action_forward += 1
        row = _control_row(slot, source, tau, data, health, interface, response, raw_wb, valid, ms)
        row["ready_command_reused"] = bool(slot == 0 and ready_response is not None)
        controls.append(row)
        if _finite_state(data):
            t = perf_counter()
            fact = compact_fact(model, data, health, limits, tau, action, ms, steps, slot,
                                bid, branch_id, interface, metadata)
            fact_s += perf_counter() - t
            if slot == 0:
                initial_fact = fact
                checkpoints.append(dict(fact, checkpoint_index=0, checkpoint_target_s=0.))
        else:
            failure = {"reason": "NONFINITE_STATE_AFTER_COMMAND_FORWARD", "slot": slot, "physics_step": steps}
        if not valid:
            failure = {"reason": "INVALID_BACKUP_QP", "slot": slot, "physics_step": steps,
                       "solver_status": raw_wb.get("status"), "solver_status_val": raw_wb.get("status_val")}
        if failure:
            break
        for _ in range(PHYSICS_STEPS_PER_SLOT):
            if observer is not None:
                _, guard_failure = _budget_call(observer)
                if guard_failure is not None:
                    failure = dict(guard_failure, slot=slot, physics_step=steps)
                    break
            t = perf_counter()
            mujoco.mj_step(model, data)
            steps += 1
            integration_s += perf_counter() - t
            if not _finite_state(data) or abs(float(data.time) - steps * PHYSICS_DT_S) > 1e-9:
                failure = {"reason": "NONFINITE_STATE_OR_SIMULATOR_RESET_AFTER_STEP", "slot": slot, "physics_step": steps}
            else:
                t = perf_counter()
                mujoco.mj_forward(model, data)
                refresh += 1
                refresh_s += perf_counter() - t
                if not _finite_state(data):
                    failure = {"reason": "NONFINITE_STATE_AFTER_INTEGRATION_REFRESH", "slot": slot, "physics_step": steps}
            if failure:
                physics.append({"time_s": steps * PHYSICS_DT_S, "physics_step": steps,
                                "numerical_failure": failure, "state": state_values(model, data)})
                break
            t = perf_counter()
            fact = compact_fact(model, data, health, limits, tau, action, ms, steps, slot,
                                bid, branch_id, interface, metadata)
            fact_s += perf_counter() - t
            physics.append(fact)
            if steps in CHECKPOINT_STEPS:
                checkpoints.append(dict(fact, checkpoint_index=len(checkpoints), checkpoint_target_s=steps * PHYSICS_DT_S))
        if failure:
            break
    complete = steps == PHYSICS_STEPS and len(controls) == CONTROL_SLOTS and failure is None
    status = "COMPLETE" if complete else "FAILED_BUDGET" if failure and failure["reason"] == "GLOBAL_BUDGET_EXHAUSTED" else "FAILED_NUMERICAL"
    return _json_safe({"schema": VERSION, "status": status,
        "reason": failure, "kind": kind, "branch_id": branch_id, "first_mode": first_mode,
        "backup_id": bid, "backup_version": HOLD_VERSION, "capacity_interface_version": CAPACITY_VERSION,
        "fixed_anchor_q_init": anchor.tolist(), **metadata, "initial_state": initial,
        "initial_fact": initial_fact, "final_state": state_values(model, data), "controls": controls,
        "physics_trajectory": physics, "checkpoints": checkpoints, "solver_ledger": ledger,
        "initialization_ms": initialization_ms, "first_backup_decision_ms": first_backup_ms,
        "elapsed_ms": (perf_counter() - begin) * 1000.,
        "counts": {"physical_steps": steps, "backup_qp_calls": len(ledger), "control_qp_calls": len(ledger),
                   "clone_data_calls": 1, "backup_controller_instances": int(ready_policy is None),
                   "action_conditioned_forward_calls": action_forward,
                   "integration_refresh_forward_calls": refresh,
                   "contact_linearization_calls": policy.controller.contact_linearization_calls,
                   "svd_calls": policy.controller.svd_calls, "passive_model_calls": policy.controller.passive_model_calls,
                   "integral_updates": policy.servo.integral_update_calls},
        "timing": {"control_total_ms": control_ms, "solver_wall_s": _ledger_wall_s(ledger),
                   "integration_s": integration_s, "integration_refresh_s": refresh_s,
                   "physical_fact_extraction_s": fact_s}})
