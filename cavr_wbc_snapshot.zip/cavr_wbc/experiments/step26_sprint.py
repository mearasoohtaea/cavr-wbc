"""STEP26 fixed two-round sprint, sealed episode holdout and genuine readiness."""
import argparse
from copy import deepcopy
import gc
import importlib.metadata
import json
from pathlib import Path
from time import perf_counter
import traceback
import os
import sys
import numpy as np
import mujoco
from cavr_wbc.experiments import step17_formal_panel as frozen
from cavr_wbc.experiments.step21_report import digest,canonical_hash,csv_write
from cavr_wbc.experiments.step26_budget import SprintBudget,SprintLimit
from cavr_wbc.experiments import step26_sim as sim
from cavr_wbc.experiments.step26_features_storage import FEATURE_NAMES,feature_specification,extract_features,save_bank
from cavr_wbc.control.step26_fast_margin import fit_models,select_on_cal,save_bundle,decide,specification
from cavr_wbc.control.step22_pose_servo import Step22WBC
from cavr_wbc.control.step25_capacity_backup import CapacityHoldBackup,capacity_command
from cavr_wbc.control.step25_dense_screen import dense_original_screen
from cavr_wbc.evaluation.step25_actual import evaluate_actual
from cavr_wbc.platforms.go2_mujoco import extract_actuator_audit,extract_healthy_torque_limits

ROOT=Path(__file__).resolve().parents[2]
PROTOCOL=Path('E:/CAVR-WBC/experiment_handoff_20260921/NEXT_CODEX_INSTRUCTIONS_STEP26_FAST_MARGIN_RESEARCH_SPRINT_20261008.md')
SOURCE_COMMIT='4e7c4bc51f207c72ad4343c5b1ae9fde89cc1f1b'
OLD25=ROOT/'artifacts/step25_dense_health_20261008/step25-dense-health-20261008-01'
OLD22=ROOT/'artifacts/step22_full_pose_response_20261007/step22-full-pose-response-20261007-01'
GAPS=(.001,.002,.004,.008,.016,.032)
NEW_SOURCE=('cavr_wbc/experiments/step26_budget.py','cavr_wbc/experiments/step26_sprint.py',
    'cavr_wbc/experiments/step26_sim.py','cavr_wbc/experiments/step26_features_storage.py',
    'cavr_wbc/control/step26_fast_margin.py','tests/test_step26_sim.py',
    'tests/test_step26_features_storage.py','tests/test_step26_fast_margin.py','tests/test_step26_sprint.py')


def write(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    def safe(x):
        if isinstance(x,np.ndarray): return safe(x.tolist())
        if isinstance(x,np.generic): return safe(x.item())
        if isinstance(x,float) and not np.isfinite(x): return None
        if isinstance(x,dict): return {k:safe(v) for k,v in x.items()}
        if isinstance(x,(tuple,list)): return [safe(v) for v in x]
        return x
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(safe(obj),sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8');os.replace(tmp,path)


def read(path): return json.loads(Path(path).read_text(encoding='utf-8'))


def freeze(out,run_id,model):
    old25=read(OLD25/'PROTOCOL_AND_MANIFEST.json');old22=read(OLD22/'PROTOCOL_AND_MANIFEST.json')
    versions={name:importlib.metadata.version(name) for name in ('numpy','scipy','osqp','mujoco','scikit-learn','joblib','threadpoolctl','matplotlib','pandas','seaborn','Pillow')}
    mapping=extract_actuator_audit(model)
    source=('cavr_wbc/control/step25_capacity_backup.py','cavr_wbc/control/step25_dense_screen.py','cavr_wbc/evaluation/step25_actual.py','cavr_wbc/control/step22_pose_servo.py')+NEW_SOURCE
    manifest={'schema':'STEP26_FAST_MARGIN_SPRINT_V1','run_id':run_id,'client_date':'2026-10-08','timezone':'Asia/Seoul',
        'source_commit':SOURCE_COMMIT,'protocol':str(PROTOCOL),'protocol_sha256':digest(PROTOCOL),
        'scenario':old22['selected_source_scenario'],'initial_recipe':old22['initial'],'mapping':mapping,
        'model_files_sha256':old25['model_files_sha256'],'wbc_config':old25['wbc_config'],
        'physical_config':old25['frozen_physical_task_limits'],'evaluation_config':old25['independent_evaluator_config'],
        'backup_version':old25['backup_version'],'backup_initial_integral':[0.]*6,'terminal_set':old25['terminal_set'],
        'feature_specification':feature_specification(),'model_specification':specification(),'dependencies':versions,
        'round1':{'TRAIN':[.04,-.04],'CALIBRATION':[.08],'SEALED_TEST':[-.08],'ticks':[20,30,40,50]},
        'round2':{'DEV_TRAIN':'round1 TRAIN plus old TEST','CALIBRATION':'old+.08','FINAL_SEALED_TEST':[.06,-.06],'ticks':[25,35,45,55]},
        'source_qualification':'numeric originalphysical andabs(vx)>=.01; no replacement','motion_excitation_target_m_s':.08,
        'health_recipe':['healthy','direction_side_thigh0.50','direction_side_thigh0.15','direction_side_calf0.50','direction_side_calf0.15'],
        'direction_side':'FR forpositivevx,RR fornegativevx; compiled mapping','gap_range_m':[0.,.05],'fixed_gaps_m':list(GAPS),
        'M3_selection':'C gateandUC<=gap elseB gateandUB<=gap elseABSTAIN; no forcedsafeaccept',
        'bank_labels':'completeD missingifincomplete; validitycomplete&&alloriginalphysical&&originalterminal; no localgap',
        'reference_duration_s':2.2,'quintic_motion_s':[.2,1.2],'control_dt_s':.02,'physics_dt_s':.002,'backup_horizon_s':1.,
        'dense_acceptance_states':501,'report_landmarks':21,'max_rounds':2,'max_DEV_recomputations':5,
        'budget':{'QP':16000,'physics_steps':160000,'numerical_wall_s':7200},'deadline_ms':20.,
        'holdout_policy':'teacher producer writessealed labels; fitloaderonlyTRAIN/CAL; MODELS_FROZEN writtenbeforeTESTopen',
        'cold_warm':'firstfreshgap2mm percontext cold newcontroller;8/32mm warm solverreuse reset same snapshotandnominalmemory',
        'source_sha256':{p:digest(ROOT/p) for p in source},'formal_E3_RL_hardware':False,'automatic_solver_search':False}
    write(out/'STEP26_PROTOCOL_AND_MANIFEST.json',manifest)
    (out/'PROTOCOL_SOURCE.md').write_text(PROTOCOL.read_text(encoding='utf-8'),encoding='utf-8')
    write(out/'DEPENDENCY_LOCK.json',{'E_target':'E:/CAVR-WBC/_deps_step26','versions':versions,'python':sys.executable})
    return manifest


def missing_label(reason):
    return {'complete':False,'D':None,'valid':False,'original_physical_safe':False,'terminal_pass':False,'reason':reason,'progress20_m':None,'endpoint_progress_m':None}


def label_branch(branch,context):
    if not branch or not branch.get('initial_fact'): return missing_label('NO_USABLE_TRAJECTORY')
    original=evaluate_actual(branch,context['backup_anchor_q_init'],context)
    rows=[branch['initial_fact']]+branch['physics_trajectory'];s=context['direction'];x0=context['x0_m']
    complete=original['complete'] and len(rows)==501
    D=max(0.,max(s*(r['qpos'][0]-x0) for r in rows)) if complete else None
    at20=next((r for r in rows if r.get('physics_step')==10 and 'qpos' in r),None)
    last=rows[-1] if rows and 'qpos' in rows[-1] else None
    return {'complete':complete,'D':D,'valid':original['actual_safe_and_terminal'],
        'original_physical_safe':original['actual_safe_all_physics_states'],'terminal_pass':original['actual_terminal_pass'],
        'reason':branch.get('reason'),'status':branch['status'],
        'progress20_m':s*(at20['qpos'][0]-x0) if at20 else None,
        'endpoint_progress_m':s*(last['qpos'][0]-x0) if complete and last else None,
        'original_failure':original['first_physical_failure']}


def source_context(snapshot,kind,mapping,round_id,split,ordinal):
    c=deepcopy(snapshot);cid=f"R{round_id}_{snapshot['snapshot_id']}_{kind}"
    side='FR' if snapshot.get('direction',0)>0 else 'RR'
    hv=[1.]*12;name='NONE';idx=None;health=1.
    if kind!='HEALTHY':
        joint,hs=kind.split('_');name=side+'_'+joint.lower();idx=next(x['actuator_index'] for x in mapping if x['actuator_name']==name)
        health=float(hs)/100;hv[idx]=health
    c.update(context_id=cid,case_id=cid,split=split,round_id=round_id,ordinal=ordinal,health_vector=hv,
        faulted_actuator_name=name,faulted_actuator_index=idx,faulted_health=health,health_kind=kind,backup_id='STEP26-'+cid)
    return c


def produce_context(out,model,c,m,budget):
    cid=c['context_id'];attempt='attempt01';directory=out/'bank'/('round'+str(c['round_id']))/cid/attempt
    budget.event('CONTEXT_START',owner=cid,attempt_id=attempt,split=c['split'])
    public={'context_id':cid,'episode_id':c['episode_id'],'split':c['split'],'round_id':c['round_id'],'ordinal':c['ordinal'],
        'context':c,'features':None,'snapshot_eligible':bool(c.get('eligible')),'bank_directory':str(directory.relative_to(out)),
        'attempt_id':attempt,'bank_status':{}}
    labels={mode:missing_label('SNAPSHOT_INELIGIBLE') for mode in ('C','B')};bank_paths={}
    preview_pass=False;step_D=None
    if c.get('eligible'):
        current=sim.restore_snapshot(model,c);n=sim.nominal(model,current,c,budget)
        try: public['features']=extract_features(c,n,m['mapping']).tolist()
        except (ValueError,KeyError) as exc: public['feature_unavailable_reason']=str(exc)
        public['current_candidate_valid']=n['command_valid'];public['current_physical_pass']=n['current_physical_check']['pass']
        write(directory/'CURRENT_INPUT.json',{'context':c,'features':public['features'],'nominal':n})
        if n['command_valid']:
            p=sim.preview(model,current,c,n,budget);bank_paths['PREVIEW']=save_bank(directory/'preview.npz',p,{'context_id':cid,'kind':'PREVIEW'})
            if p['status']=='COMPLETE':
                from cavr_wbc.control.step23_backup_filter import predicted_physical_check
                last=p['physics_trajectory'][-1];preview_pass=n['current_physical_check']['pass'] and predicted_physical_check(last)['pass']
                step_D=max(0.,c['direction']*(last['qpos'][0]-c['x0_m']))
        for mode in ('C','B'):
            branch=sim.actual_branch(model,current,c,n,mode,'ACTUAL_'+mode,budget)
            bank_paths[mode]=save_bank(directory/(mode+'.npz'),branch,{'context_id':cid,'split':c['split']})
            labels[mode]=label_branch(branch,c);public['bank_status'][mode]=branch['status']
            if branch['status']=='FAILED_BUDGET':
                write(directory/'LABELS.json',labels);write(directory/'PUBLIC_INPUT.json',public);raise SprintLimit('branch budget guard returned partial evidence')
            del branch;gc.collect()
        labels['preview']={'pass':bool(preview_pass),'D_step':step_D}
    write(directory/'LABELS.json',labels);public['bank_paths']=bank_paths
    write(directory/'PUBLIC_INPUT.json',public)
    budget.event('CONTEXT_END',owner=cid,attempt_id=attempt,split=c['split'],input_eligible=public['snapshot_eligible'],bank_status=public['bank_status'],**budget.snapshot())
    budget.persist(last_context=cid,completed_contexts_note='runtime statuses only; sealed test labels not read')
    return public


def collect_episodes(out,model,m,budget,specs,round_id,ticks,registry):
    kinds=('HEALTHY','THIGH_50','THIGH_15','CALF_50','CALF_15')
    for d,split in specs:
        budget.check();eid=f"R{round_id}_{'P' if d>0 else 'N'}{int(round(abs(d)*1000)):03d}"
        budget.event('REFERENCE_START',owner=eid,split=split)
        ep=sim.reference_episode(model,m['scenario'],d,eid,ticks,budget);write(out/'references'/(eid+'.json'),ep)
        budget.event('REFERENCE_END',owner=eid,status=ep['status'],snapshot_count=len(ep['snapshots']),max_abs_vx=ep['max_abs_vx_m_s'],**budget.snapshot())
        found={s['source_tick']:s for s in ep['snapshots']}
        for tick in ticks:
            snapshot=found.get(tick)
            if snapshot is None:
                snapshot={'snapshot_id':eid+f'_T{tick:03d}','episode_id':eid,'source_tick':tick,'eligible':False,'direction':1 if d>0 else -1,
                    'eligibility_reason':'REFERENCE_NUMERICAL_FAILURE_BEFORE_SNAPSHOT'}
            for kind in kinds:
                c=source_context(snapshot,kind,m['mapping'],round_id,split,len([r for r in registry if r['round_id']==round_id and r['split']==split]))
                try: public=produce_context(out,model,c,m,budget)
                except SprintLimit: raise
                except (OSError,MemoryError): raise
                except Exception as exc:
                    # Preserve ordinary isolated implementation attempts. Never hide calls or replace cases.
                    directory=out/'bank'/('round'+str(round_id))/c['context_id']/'attempt01'
                    write(directory/'IMPLEMENTATION_ERROR.json',{'error':str(exc),'traceback':traceback.format_exc(),'budget':budget.snapshot()})
                    public={'context_id':c['context_id'],'episode_id':eid,'round_id':round_id,'split':split,'ordinal':c['ordinal'],
                        'context':c,'features':None,'snapshot_eligible':c.get('eligible',False),'bank_directory':str(directory.relative_to(out)),
                        'attempt_id':'attempt01','bank_status':{'C':'IMPLEMENTATION_UNAVAILABLE','B':'IMPLEMENTATION_UNAVAILABLE'}}
                    write(directory/'LABELS.json',{mode:missing_label('IMPLEMENTATION_UNAVAILABLE') for mode in ('C','B')})
                    budget.event('CONTEXT_IMPLEMENTATION_ERROR',owner=c['context_id'],error=str(exc),attempt_id='attempt01')
                registry.append(public);write(out/'SPLIT_REGISTRY.json',registry)
                if len(registry)%5==0: print(json.dumps({'contexts_written':len(registry),'round':round_id,'budget':budget.snapshot()}),flush=True)
        del ep;gc.collect()


def open_labels(out,entry,phase,round_id):
    split=entry['split']
    if phase=='FIT' and split not in ('TRAIN','CALIBRATION'): raise ValueError('SEALED TEST forbidden in FIT loader')
    if phase=='TEST' and not (out/'models'/('round'+str(round_id))/'MODELS_FROZEN.json').exists():
        raise ValueError('TEST labels sealed until fitted weights/configuration freeze')
    path=out/entry['bank_directory']/'LABELS.json'
    return read(path) if path.exists() else {mode:missing_label('LABELS_MISSING_OR_INTERRUPTED') for mode in ('C','B')}


def fit_round(out,registry,round_id,budget):
    train=[];cal=[]
    for entry in registry:
        old_test_dev=round_id==2 and entry['round_id']==1 and entry['split']=='SEALED_TEST'
        if entry['features'] is None: continue
        if entry['round_id']!=1: continue
        if entry['split'] not in ('TRAIN','CALIBRATION') and not old_test_dev: continue
        labels=open_labels(out,entry,'TEST' if old_test_dev else 'FIT',1)
        item={'context_id':entry['context_id'],'episode_id':entry['episode_id'],'features':entry['features'],'labels':labels,
            'split':'DEV_TRAIN' if old_test_dev else 'TRAIN' if entry['split']=='TRAIN' else 'CALIBRATION'}
        (cal if entry['split']=='CALIBRATION' else train).append(item)
    budget.check();budget.event('MODEL_FIT_START',round=round_id,train_ids=[r['context_id'] for r in train],cal_ids=[r['context_id'] for r in cal])
    models=fit_models(train,cal,FEATURE_NAMES,round_id);selection=select_on_cal(models,cal)
    paths={}
    for name,bundle in models.items():
        paths[name]=save_bundle(out/'models'/('round'+str(round_id)),bundle);budget.fit_count+=bundle['estimator_fit_count']
        budget.event('MODEL_FIT_END',round=round_id,configuration=name,estimator_fits=bundle['estimator_fit_count'],weights_sha256=paths[name]['sha256'])
    freeze={'round':round_id,'selected':selection['selected'],'CAL_selection':selection,'weight_files':paths,
        'features':list(FEATURE_NAMES),'frozen_before_test_open':True,'old_TEST_reclassified_as_DEV_TRAIN':round_id==2}
    write(out/'models'/('round'+str(round_id))/'MODELS_FROZEN.json',freeze)
    return models[selection['selected']],freeze


def safe_truth(label,gap): return bool(label.get('valid') and label.get('complete') and label.get('D') is not None and label['D']<=gap)


def evaluate_test(out,test,model,round_id,budget):
    budget.event('SEALED_TEST_OPEN',round=round_id,context_ids=[e['context_id'] for e in test])
    rows=[];unsafe=accepted_safe=oracle=accepted=Cretained=abstain=0
    for entry in test:
        labels=open_labels(out,entry,'TEST',round_id)
        for gap in GAPS:
            truths={mode:safe_truth(labels[mode],gap) for mode in ('C','B')};oracle+=int(any(truths.values()))
            decision=decide(model,entry['features'],gap) if entry['features'] is not None else {'mode':'ABSTAIN','accepted':False,'prediction':None,'reasons':'INPUT_UNAVAILABLE'}
            accepted+=int(decision['accepted']);abstain+=int(not decision['accepted'])
            if decision['accepted']:
                good=truths[decision['mode']];unsafe+=int(not good);accepted_safe+=int(good);Cretained+=int(good and decision['mode']=='C')
            choices={'M0_CURRENT':'C' if entry.get('current_candidate_valid') else 'ABSTAIN',
                'M1_ONE_STEP':('C' if labels.get('preview',{}).get('pass') and labels.get('preview',{}).get('D_step') is not None and labels['preview']['D_step']<=gap else 'B') if entry.get('snapshot_eligible') else 'ABSTAIN',
                'M3_FAST_MARGIN':decision['mode']}
            for method,mode in choices.items():
                label=labels.get(mode,{})
                rows.append({'round':round_id,'context_id':entry['context_id'],'episode_id':entry['episode_id'],'health_kind':entry['context']['health_kind'],
                    'faulted_actuator_name':entry['context']['faulted_actuator_name'],'faulted_health':entry['context']['faulted_health'],
                    'gap_m':gap,'method':method,'mode':mode,'accepted':mode!='ABSTAIN','oracle_safe_available':any(truths.values()),
                    'safe_accepted':mode!='ABSTAIN' and truths.get(mode,False),'unsafe_accepted':mode!='ABSTAIN' and not truths.get(mode,False),
                    'original_physical_safe':label.get('original_physical_safe'),'local_workspace_safe':label.get('D') is not None and label.get('complete') and label['D']<=gap,
                    'original_terminal_pass':label.get('terminal_pass'),'D_C':labels['C'].get('D'),'D_B':labels['B'].get('D'),
                    'actual_step_progress_m':label.get('progress20_m'),'actual_endpoint_progress_m':label.get('endpoint_progress_m'),
                    'M3_prediction':decision.get('prediction') if method=='M3_FAST_MARGIN' else None,
                    'M3_reasons':decision.get('reasons') if method=='M3_FAST_MARGIN' else None})
    summary={'round':round_id,'planned_contexts':len(test),'qualified_feature_contexts':sum(e['features'] is not None for e in test),
        'queries':len(test)*len(GAPS),'unsafe_accepts':unsafe,'safe_accepts':accepted_safe,'accepts':accepted,'ABSTAIN':abstain,
        'oracle_safe_queries':oracle,'oracle_safe_coverage':accepted_safe/oracle if oracle else 0.,'C_retained':Cretained,
        'criterion_met':unsafe==0 and oracle>0 and accepted_safe/oracle>=.20,'shared_counterfactual_bank_not_independent_gap_runs':True}
    write(out/'evaluation'/('round'+str(round_id))/'TEST_QUERIES.json',rows);write(out/'evaluation'/('round'+str(round_id))/'TEST_SUMMARY.json',summary)
    return summary,rows


def command_ready(model,entry,bundle,gap,budget,resident=None):
    begin=perf_counter();context=deepcopy(entry['context']);context['context_id']=context['context_id']+'_READY'
    current=sim.restore_snapshot(model,context);input_ms=(perf_counter()-begin)*1000
    n=sim.nominal(model,current,context,budget,controller=resident)
    feature_begin=perf_counter();features=extract_features(context,n,MAPPING);feature_ms=(perf_counter()-feature_begin)*1000
    infer_begin=perf_counter();choice=decide(bundle,features,gap);infer_ms=(perf_counter()-infer_begin)*1000
    if not n['command_valid']: choice.update(mode='ABSTAIN',accepted=False,current_numeric_unavailable=True)
    mode=choice['mode'];policy=response=None;backup_ms=0.
    if mode!='C':
        back_begin=perf_counter();policy=CapacityHoldBackup(model,context['backup_anchor_q_init'],context['backup_id'],
            solve_callback=budget.qp_callback('READY_BACKUP',context['context_id']))
        response=policy.compute(current,context['health_vector'],0);backup_ms=(perf_counter()-back_begin)*1000
        interface=response['capacity_interface'];command=response['tau_cmd']
        if not response['valid_command']: choice.update(accepted=False,backup_numeric_unavailable=True)
    else: interface=n['capacity_interface'];command=n['tau']
    clip_begin=perf_counter();final=capacity_command(interface['tau_raw'],context['health_vector'],LIMITS,interface['solver_status_val']);clip_ms=(perf_counter()-clip_begin)*1000
    elapsed=(perf_counter()-begin)*1000
    record={'context_id':entry['context_id'],'gap_m':gap,'mode':choice['mode'],'model_accepted':choice['accepted'],
        'best_effort_B':choice['mode']=='ABSTAIN','command_valid':final['command_valid'],'tau_sent':final['tau_sent'],
        'command_ready_ms':elapsed,'deadline_miss':elapsed>20.,'input_prepare_ms':input_ms,'nominal_generation_ms':n['generation_ms'],
        'feature_ms':feature_ms,'inference_ms':infer_ms,'first_backup_ms':backup_ms,'final_clip_ms':clip_ms,'model_prediction':choice['prediction'],
        'no_integration_before_command_ready':True,'timing_includes_pre_ready_ledger_writes':True}
    return record,current,n,policy,response


def fresh_checks(out,test,bundle,round_id,model,budget):
    indices=[0,4,8,12,16,19] if round_id==1 else [0,7,15,23,31,39]
    freshgaps=[.002,.008,.032,.002,.008,.032];ordered=sorted(test,key=lambda e:e['context_id']);records=[]
    for ix,gap in zip(indices,freshgaps):
        if ix>=len(ordered) or ordered[ix]['features'] is None:
            records.append({'index':ix,'gap_m':gap,'status':'INPUT_UNQUALIFIED_SKIP_NO_REPLACEMENT'});continue
        entry=ordered[ix];c=deepcopy(entry['context']);c['context_id']+='_FRESH_M2';budget.check()
        begin=perf_counter();current=sim.restore_snapshot(model,c);n=sim.nominal(model,current,c,budget);pred={};paths={}
        for mode in ('C','B'):
            pred[mode]=sim.actual_branch(model,current,c,n,mode,'PREDICTION_'+mode,budget)
            paths[mode]=save_bank(out/'fresh'/('round'+str(round_id))/entry['context_id']/('M2_'+mode+'.npz'),pred[mode])
        screen_begin=perf_counter();screens={mode:dense_original_screen(pred[mode],c['backup_anchor_q_init']) for mode in ('C','B')}
        D={mode:max(0.,max(c['direction']*(row['qpos'][0]-c['x0_m']) for row in [pred[mode]['initial_fact']]+pred[mode]['physics_trajectory']))
            if screens[mode]['conditions']['complete_500step_50slot_horizon'] else None for mode in ('C','B')}
        selected='C' if screens['C']['pass'] and D['C']<=gap else 'B'
        recognized=screens[selected]['pass'] and D[selected] is not None and D[selected]<=gap
        dense_ms=(perf_counter()-screen_begin)*1000;elapsed=(perf_counter()-begin)*1000
        labels=open_labels(out,entry,'TEST',round_id)
        m2={'context_id':entry['context_id'],'index':ix,'gap_m':gap,'status':'FRESH_M2_COMPLETED','selected':selected,'recognized':recognized,
            'dense_screen_ms':dense_ms,'fresh_predictive_ms':elapsed,'deadline_miss':elapsed>20.,'actual_bank_safe':safe_truth(labels[selected],gap),'paths':paths}
        write(out/'fresh'/('round'+str(round_id))/entry['context_id']/'M2_RESULT.json',m2)
        ready,base,nominal,policy,response=command_ready(model,entry,bundle,gap,budget)
        budget.event('M3_COMMAND_READY',owner=entry['context_id'],gap_m=gap,mode=ready['mode'],accepted=ready['model_accepted'],command_ready_ms=ready['command_ready_ms'])
        mode=ready['mode'] if ready['mode']!='ABSTAIN' else 'B';execution=sim.actual_branch(model,base,entry['context'],nominal,mode,'ACTUAL_'+mode,budget,
            ready_policy=policy if mode=='B' else None,ready_response=response if mode=='B' else None)
        path=save_bank(out/'fresh'/('round'+str(round_id))/entry['context_id']/'M3_EXECUTION.npz',execution)
        actual=label_branch(execution,entry['context']);matches=execution.get('controls') and execution['controls'][0]['tau_cmd']==ready['tau_sent']
        result={'M2':m2,'M3':ready,'M3_actual_label':actual,'command_ready_matches_first_executed_sent':bool(matches),'actual_path':path}
        write(out/'fresh'/('round'+str(round_id))/entry['context_id']/'FRESH_RESULT.json',result);records.append(result)
        if execution['status']=='FAILED_BUDGET': raise SprintLimit('fresh execution guard')
        budget.persist(last_fresh_context=entry['context_id']);gc.collect()
    write(out/'evaluation'/('round'+str(round_id))/'FRESH_CHECKS.json',records)
    return records


def timing_checks(out,test,bundle,round_id,model,budget):
    inputs=[e for e in test if e['features'] is not None];times=[]
    for i in range(1000):
        if not inputs: break
        begin=perf_counter();decide(bundle,inputs[i%len(inputs)]['features'],.008);times.append((perf_counter()-begin)*1000)
    stats={key:float(np.percentile(times,p)) if times else None for key,p in (('p50_ms',50),('p95_ms',95),('p99_ms',99))}
    stats.update(max_ms=max(times,default=None),iterations=len(times),no_QP_or_simulation=True)
    write(out/'evaluation'/('round'+str(round_id))/'INFERENCE_TIMING.json',{'summary':stats,'all_ms':times})
    rows=[]
    for e in inputs:
        controller=None
        for j,gap in enumerate((.002,.008,.032)):
            budget.check()
            # Resident cache belongs to this context only; state/memory restored on every decision.
            if controller is None:
                start=perf_counter();controller=Step22WBC(model);construction_ms=(perf_counter()-start)*1000
            else: construction_ms=0.
            row,*_=command_ready(model,e,bundle,gap,budget,controller)
            row['warm_or_cold']='COLD' if j==0 else 'WARM';row['controller_construction_ms']=construction_ms
            row['command_ready_ms']+=construction_ms;row['deadline_miss']=row['command_ready_ms']>20.
            rows.append(row);budget.event('FULL_DECISION_READY',owner=e['context_id'],gap_m=gap,warm_or_cold=row['warm_or_cold'],elapsed_ms=row['command_ready_ms'],accepted=row['model_accepted'])
        budget.persist(last_full_timing_context=e['context_id'])
    write(out/'evaluation'/('round'+str(round_id))/'FULL_READY_TIMING.json',rows)
    return stats,rows


MAPPING=None;LIMITS=None


def run(out,run_id):
    global MAPPING,LIMITS
    out=out.resolve();allowed=(ROOT/'artifacts/step26_fast_margin_20261008').resolve()
    if allowed not in out.parents: raise ValueError('STEP26 unique output directory required')
    out.mkdir(parents=True,exist_ok=True)
    if (out/'STEP26_PROTOCOL_AND_MANIFEST.json').exists(): raise RuntimeError('Already frozen sprint: do not reset budget or replay')
    model=frozen.load_model();m=freeze(out,run_id,model);MAPPING=m['mapping'];LIMITS=extract_healthy_torque_limits(model)
    budget=SprintBudget(out);registry=[];rounds=[];error=None
    write(out/'RUN_STARTED.json',{'run_id':run_id,'pid':os.getpid(),'command':sys.argv,'client_date':'2026-10-08'})
    try:
        collect_episodes(out,model,m,budget,[(.04,'TRAIN'),(-.04,'TRAIN'),(.08,'CALIBRATION'),(-.08,'SEALED_TEST')],1,(20,30,40,50),registry)
        bundle,fit=fit_round(out,registry,1,budget);test=[r for r in registry if r['round_id']==1 and r['split']=='SEALED_TEST']
        metrics,rows=evaluate_test(out,test,bundle,1,budget);fresh=fresh_checks(out,test,bundle,1,model,budget);infer,ready=timing_checks(out,test,bundle,1,model,budget)
        rounds.append({'round':1,'fit':fit,'TEST':metrics,'inference':infer,'full_ready_count':len(ready),'full_ready_deadline_misses':sum(r['deadline_miss'] for r in ready)})
        selected=fit['CAL_selection']['ranking'][fit['selected']]
        calok=selected['unsafe_accepts']==0 and selected['oracle_safe_coverage']>=.2
        if not calok or not metrics['criterion_met']:
            budget.event('ROUND2_AUTHORIZED_RULE_TRIGGER',first_CAL_criterion=calok,first_TEST_criterion=metrics['criterion_met'],old_TEST_reclassified_DEV=True)
            collect_episodes(out,model,m,budget,[(.06,'FINAL_SEALED_TEST'),(-.06,'FINAL_SEALED_TEST')],2,(25,35,45,55),registry)
            bundle,fit=fit_round(out,registry,2,budget);test=[r for r in registry if r['round_id']==2]
            metrics,rows=evaluate_test(out,test,bundle,2,budget);fresh=fresh_checks(out,test,bundle,2,model,budget);infer,ready=timing_checks(out,test,bundle,2,model,budget)
            rounds.append({'round':2,'fit':fit,'TEST':metrics,'inference':infer,'full_ready_count':len(ready),'full_ready_deadline_misses':sum(r['deadline_miss'] for r in ready)})
    except BaseException as exc:
        error={'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()}
        write(out/'INTERRUPTION.json',{'error':error,'budget':budget.snapshot(),'previous_completed_contexts':len(registry),'retries_not_hidden':True})
    finally:
        write(out/'SPRINT_ROUNDS.json',rounds);write(out/'SPLIT_REGISTRY.json',registry)
        write(out/'RUN_FINISHED.json',{'status':'NUMERICAL_COMPLETED' if error is None else 'INCOMPLETE','error':error,'budget':budget.snapshot(),'rounds_completed':len(rounds)})
        budget.event('SPRINT_END',status='COMPLETED' if error is None else 'INCOMPLETE',**budget.snapshot());budget.close()
    return error


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--run-id',required=True)
    args=p.parse_args();error=run(args.output,args.run_id)
    if error: sys.exit(1)
