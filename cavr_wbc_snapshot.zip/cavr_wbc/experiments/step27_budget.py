"""STEP27 hard budget with pre-ready in-memory START/RETURN accounting."""
from collections import Counter
from datetime import datetime, timezone
import json
import os
from pathlib import Path
from time import perf_counter


class SprintLimit(RuntimeError):
    pass


class SprintBudget:
    def __init__(self, out, *, authorized_dev_repair=False):
        self.out = Path(out)
        self.out.mkdir(parents=True, exist_ok=True)
        self.path = self.out / 'STEP27_LEDGER.jsonl'
        previous = None
        if self.path.exists() and authorized_dev_repair:
            previous = json.loads((self.out/'STEP27_PROGRESS.json').read_text(encoding='utf-8'))
        elif self.path.exists():
            raise FileExistsError('New run only; no ledger overwrite/restart')
        self.stream = self.path.open('a' if previous else 'x', encoding='utf-8')
        self.buffer = []
        self.qp_calls = self.physics_steps = self.fit_count = self.dev_recomputations = 0
        self.qp_kinds, self.step_kinds = Counter(), Counter()
        self.started = self.start_utc = None
        self.returned = 0
        self.persisted_qp_calls = self.persisted_returns = 0
        if previous:
            self.qp_calls=previous['total_QP_calls'];self.returned=previous['QP_returns']
            self.physics_steps=previous['total_physics_steps'];self.fit_count=previous['estimator_fits']
            self.qp_kinds.update(previous['QP_by_kind']);self.step_kinds.update(previous['physics_by_kind'])
            self.dev_recomputations=previous['DEV_context_recomputations']
            self.start_utc=previous['numerical_started_utc']
            elapsed=(datetime.now(timezone.utc)-datetime.fromisoformat(self.start_utc)).total_seconds()
            self.started=perf_counter()-elapsed
            self.persisted_qp_calls=self.qp_calls;self.persisted_returns=self.returned
            self.event('AUTHORIZED_DEV_IMPLEMENTATION_REPAIR_CONTINUATION',original_start_utc=self.start_utc,
                       budgets_unchanged=True)

    def event(self, event, **values):
        self.buffer.append({'event': event, 'timestamp_utc': datetime.now(timezone.utc).isoformat(), **values})

    def start(self):
        if self.started is None:
            self.started = perf_counter()
            self.start_utc = datetime.now(timezone.utc).isoformat()
            self.event('NUMERICAL_STARTED', hard_wall_s=7200, QP_limit=14000, step_limit=140000)

    def check(self):
        if self.started is not None and perf_counter() - self.started >= 7200:
            raise SprintLimit('2 hour numerical wall limit')
        if self.qp_calls >= 14000:
            raise SprintLimit('14000 real QP hard limit')
        if self.physics_steps >= 140000:
            raise SprintLimit('140000 integration hard limit')

    def qp_callback(self, kind, owner, first_mode=None):
        active = {}
        def call(stage, payload, solve):
            if stage == 'before':
                self.start(); self.check()
                self.qp_calls += 1; self.qp_kinds[kind] += 1
                active.clear()
                active.update(global_qp_index=self.qp_calls, kind=kind, owner=owner,
                              first_mode=first_mode, local_qp_index=payload['solver_call_index'])
                self.event('QP_START', **active)
                return solve()
            r = payload['result']; self.returned += 1
            self.event('QP_RETURN', **active, **{k: r.get(k) for k in (
                'status', 'status_val', 'iterations', 'solve_wall_time_s', 'real_optimizer_called',
                'primal_residual', 'dual_residual', 'setup_time_s', 'update_time_s', 'warm_started',
                'kernel_variant', 'osqp_time_limit_s')})
        return call

    def step_observer(self, kind, owner):
        def before():
            self.start(); self.check()
            self.physics_steps += 1; self.step_kinds[kind] += 1
        return before

    def snapshot(self):
        return {'total_QP_calls': self.qp_calls, 'QP_returns': self.returned,
                'total_physics_steps': self.physics_steps, 'QP_by_kind': dict(self.qp_kinds),
                'physics_by_kind': dict(self.step_kinds), 'numerical_started_utc': self.start_utc,
                'numerical_elapsed_s': perf_counter()-self.started if self.started else 0.,
                'estimator_fits': self.fit_count, 'DEV_context_recomputations': self.dev_recomputations,
                'unknown_native_returns': self.qp_calls-self.returned,
                'buffered_unpersisted_starts': self.qp_calls-self.persisted_qp_calls,
                'buffered_unpersisted_returns': self.returned-self.persisted_returns}

    def persist(self, **extra):
        # Called only after command-ready or after a complete/failed branch.
        for row in self.buffer:
            self.stream.write(json.dumps(row, sort_keys=True, allow_nan=False)+'\n')
        self.stream.flush(); os.fsync(self.stream.fileno())
        self.buffer.clear()
        self.persisted_qp_calls, self.persisted_returns = self.qp_calls, self.returned
        value = {**self.snapshot(), **extra}
        p = self.out/'STEP27_PROGRESS.json'; tmp = p.with_suffix('.tmp')
        tmp.write_text(json.dumps(value, sort_keys=True, allow_nan=False)+'\n', encoding='utf-8')
        os.replace(tmp, p)

    def close(self):
        self.persist(); self.stream.close()
