"""Scoped Git/source provenance; no experiment imports, rerun or extra audit."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess


ROOT=Path(__file__).resolve().parents[2]
PARENT='842367fb68b6b53c29294fd84df496d396416b3e'
BRANCH='codex/step27-structured-margin-resident-20261008'


def git(*args):
    return subprocess.check_output(['git',*args],cwd=ROOT,text=True,encoding='utf-8').strip()


def provenance(out):
    out=Path(out).resolve()
    files=sorted([*ROOT.glob('cavr_wbc/control/step27_*.py'),*ROOT.glob('cavr_wbc/experiments/step27_*.py'),
                  *ROOT.glob('tests/test_step27_*.py')])
    snapshots=[]
    for p in files:
        rel=p.relative_to(ROOT); dest=out/'SOURCE_FINAL_SNAPSHOT'/rel;dest.parent.mkdir(parents=True,exist_ok=True)
        data=p.read_bytes();dest.write_bytes(data)
        snapshots.append({'path':str(rel).replace('\\','/'),'sha256':hashlib.sha256(data).hexdigest(),
                          'snapshot_path':str(dest.relative_to(out)).replace('\\','/')})
    staged=git('diff','--cached',PARENT,'--name-only').splitlines()
    diff=subprocess.run(['git','diff','--cached',PARENT,'--check'],cwd=ROOT,capture_output=True,text=True,encoding='utf-8')
    value={'stage':'PRE_COMMIT','parent':PARENT,'branch':BRANCH,'worktree':str(ROOT),
        'original_HEAD_unchanged':git('rev-parse','HEAD'),'index_on_E':os.environ.get('GIT_INDEX_FILE'),
        'objects_on_E':os.environ.get('GIT_OBJECT_DIRECTORY'),'staged_changes_vs_parent':staged,
        'actual_new_code_and_tests':snapshots,'scoped_diff_check':{'exit_code':diff.returncode,'stdout':diff.stdout,'stderr':diff.stderr},
        'ordinary_worktree_status':'not clean relative to old HEAD; inherited missing/modified files preserved and not staged',
        'protocol_diagnostic_completeness':'PARTIAL_2_OF_12_DEV_COMPARISON_DETAILS; native calls retained, no replay',
        'git_warning':'core.autocrlf warnings do not modify current files; output .gitattributes keeps archived evidence bytes',
        'verification_command':'python -B -X utf8 -m cavr_wbc.experiments.step27_verify <unique_out>',
        'minimal_tests_command':'python -B -X utf8 -m unittest discover -s tests -p test_step27_*.py -v',
        'numerical_commands':['python -B -X utf8 -m cavr_wbc.experiments.step27_sprint step27-structured-margin-20261008-01',
            'python -B -X utf8 -m cavr_wbc.experiments.step27_sprint step27-structured-margin-20261008-01 --dev-repair'],
        'push':False,'old_HEAD_reset':False}
    (out/'DELIVERY_GIT_STATE.json').write_text(json.dumps(value,sort_keys=True,indent=2)+'\n',encoding='utf-8')


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('out');provenance(p.parse_args().out)
