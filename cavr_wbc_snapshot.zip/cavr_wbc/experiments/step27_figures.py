"""Two saved-data STEP27 evidence figures, scipilot IEEE style."""
import argparse
import json
from pathlib import Path
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from PIL import Image
sys.path.insert(0,'C:/Users/ZhuanZ（无密码）/.codex/skills/scipilot-figure/scripts')
from setup_style import setup_style
from profile_data import profile_data
from export_figure import export_figure
from visual_qa import render_preview, audit_layout
from layout_tools import finalize_figure, add_panel_labels
from cavr_wbc.experiments.step27_sprint import write, read


def make(out,export=False):
    out=Path(out);fd=out/'figures';fd.mkdir(exist_ok=True)
    points=read(out/'MARGIN_POINTS.json');q=read(out/'EVALUATION_QUERIES.json');ready=read(out/'FULL_READY_TIMING.json')
    data=[{k:p.get(k) for k in ('context_id','episode','branch','health_kind','D','G_T','prediction_D_hat','prediction_U_D','prediction_G_T_hat','prediction_U_T')} for p in points]
    df=pd.DataFrame(data);write(fd/'DATA_PROFILE.json',profile_data(df,group_cols=['branch']))
    df.to_csv(fd/'MARGIN_POINT_DATA.csv',index=False)
    setup_style(journal='ieee',lang='en',use_sciplots=False)
    plt.rcParams.update({'font.size':8,'axes.labelsize':9,'xtick.labelsize':8,'ytick.labelsize':8,
                         'legend.fontsize':8,'savefig.bbox':None})
    figures=[];fig,ax=plt.subplots(2,2,figsize=(7.16,5.0))
    colors={'HEALTHY':'#000000','THIGH':'#0072B2','CALF':'#D55E00'}
    marks={'HEALTHY':{1.:'o'},'THIGH':{.5:'s',.3:'^',.15:'D'},'CALF':{.5:'v',.3:'P',.15:'>'}}
    for col,branch in enumerate(('C','B')):
        valid=[p for p in points if p['branch']==branch and p.get('D') is not None and p.get('prediction_U_D') is not None]
        for p in valid:
            h=p['health_kind'];category=h.split('_')[0];health=1. if h=='HEALTHY' else int(h.split('_')[1])/100
            color=colors[category];marker=marks[category][health]
            ax[0,col].scatter(p['D']*1000,p['prediction_U_D']*1000,s=16,marker=marker,
                              facecolors='none',edgecolors=color,linewidths=.7)
            ax[1,col].scatter(p['G_T'],p['prediction_U_T'],s=16,marker=marker,
                              facecolors='none',edgecolors=color,linewidths=.7)
            if not p.get('original_physical_safe') or not p.get('terminal_pass'):
                ax[0,col].scatter(p['D']*1000,p['prediction_U_D']*1000,s=10,marker='x',c='black',linewidths=.5)
                ax[1,col].scatter(p['G_T'],p['prediction_U_T'],s=10,marker='x',c='black',linewidths=.5)
        ax[0,col].set(title=f'{branch}: displacement ({len(valid)}/112 complete pairs)',xlabel='Observed D (mm)',ylabel='Calibrated U_D (mm)')
        ax[1,col].set(title=f'{branch}: terminal margin',xlabel='Observed G_T (dimensionless)',ylabel='Calibrated U_T (dimensionless)')
    dlim=max([max(p['D']*1000,p['prediction_U_D']*1000) for p in points if p.get('D') is not None and p.get('prediction_U_D') is not None]+[1.])*1.05
    gtvals=[v for p in points for v in (p.get('G_T'),p.get('prediction_U_T')) if v is not None];lo=min(gtvals+[-1.]);hi=max(gtvals+[1.]);span=hi-lo
    for a in ax[0]:a.set_xlim(0,dlim);a.set_ylim(0,dlim);a.plot([0,dlim],[0,dlim],color='grey',ls='--',lw=.7)
    for a in ax[1]:
        a.set_xlim(lo-.05*span,hi+.05*span);a.set_ylim(lo-.05*span,hi+.05*span)
        a.plot([lo,hi],[lo,hi],color='grey',ls='--',lw=.7);a.axhline(0,color='grey',ls=':',lw=.7);a.axvline(0,color='grey',ls=':',lw=.7)
    handles=[Line2D([],[],color=c,marker={'HEALTHY':'o','THIGH':'s','CALF':'v'}[k],linestyle='none',markerfacecolor='none',label=k.title()) for k,c in colors.items()]
    handles.append(Line2D([],[],color='black',marker='x',linestyle='none',label='Physical or terminal failure'))
    fig.legend(handles=handles,loc='outside lower center',ncol=4,frameon=False)
    figures.append(('STEP27_margin_evidence',fig))
    fig,ax=plt.subplots(2,2,figsize=(7.16,5.0))
    methods=('M0_CURRENT','M1_ONE_STEP','M3_STEP26','M4_STRUCTURED_MARGIN','ORACLE')
    colors2=['#999999','#D55E00','#CC79A7','#0072B2','#000000']; markers=('o','s','^','D','x'); gaps=[.001,.002,.004,.008,.016,.032]
    for method,color,marker in zip(methods,colors2,markers):
        cover=[];ret=[]
        for gap in gaps:
            rows=[r for r in q if r['method']==method and r['gap_m']==gap]
            oracle=sum(r['oracle_safe_available'] for r in rows)
            cover.append(100*sum(r['safe_accepted'] for r in rows)/oracle if oracle else np.nan)
            ret.append(100*sum(r['safe_accepted'] and r['choice']=='C' for r in rows)/112)
        ax[0,0].plot(np.array(gaps)*1000,cover,color=color,marker=marker,ms=3,lw=.8,label=method.replace('_STRUCTURED_MARGIN','').replace('_CURRENT','').replace('_ONE_STEP',''))
        ax[0,1].plot(np.array(gaps)*1000,ret,color=color,marker=marker,ms=3,lw=.8)
    ax[0,0].set(xlabel='Local gap (mm)',ylabel='Oracle-safe coverage (%)',ylim=(-3,103))
    ax[0,1].set(xlabel='Local gap (mm)',ylabel='Safe C retention / planned (%)',ylim=(-3,103))
    for a in ax[0]:a.set_xscale('log',base=2);a.set_xticks(np.array(gaps)*1000,labels=['1','2','4','8','16','32'])
    groups=(('K_RESIDENT',True),('K_RESIDENT',False),('K_BUDGETED',True),('K_BUDGETED',False))
    for index,(variant,cold) in enumerate(groups):
        rows=[r for r in ready if r['variant']==variant and r['cold']==cold]
        for j,r in enumerate(rows):
            jitter=((j*17)%101/100-.5)*.4
            ax[1,0].scatter(index+jitter,r['command_ready_ms'],s=7,marker='o' if r['command_valid'] else 'x',
                            c='#0072B2' if variant=='K_RESIDENT' else '#D55E00',alpha=.55,linewidths=.4)
        unavailable=sum(not r['command_valid'] for r in rows)
        ax[1,1].scatter(index,100*unavailable/len(rows) if rows else 0,marker='s',s=26,color='#000000')
    ticks=['Resident\ncold','Resident\nwarm','Budgeted\ncold','Budgeted\nwarm']
    ax[1,0].set(xticks=range(4),xticklabels=ticks,ylabel='Complete command-ready (ms, log)');ax[1,0].set_yscale('log');ax[1,0].axhline(20,color='black',ls='--',lw=.8)
    ax[1,1].set(xticks=range(4),xticklabels=ticks,ylabel='Command unavailable (%)',ylim=(-3,103))
    fig.legend(*ax[0,0].get_legend_handles_labels(),loc='outside lower center',ncol=5,frameon=False)
    figures.append(('STEP27_coverage_timing',fig))
    qa=[]
    for name,fig in figures:
        finalize_figure(fig);add_panel_labels(fig,style='ieee')
        render_preview(fig,str(fd/(name+'_preview.png')),dpi=150)
        qa.append({'figure':name,'layout':audit_layout(fig),'points_not_filtered_by_success':True})
        Image.open(fd/(name+'_preview.png')).convert('L').save(fd/(name+'_preview_grayscale.png'))
        if export:
            export_figure(fig,str(fd/name),formats=['pdf','png'],size_inches=(7.16,5.0),dpi=600,grayscale_preview=False,tight=False)
            Image.open(fd/(name+'.png')).convert('L').save(fd/(name+'_grayscale.png'),dpi=(600,600))
        plt.close(fig)
    write(fd/'LAYOUT_QA.json',qa)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('out');p.add_argument('--export',action='store_true');a=p.parse_args();make(a.out,a.export)
