"""Saved evidence only: no simulator, solver or fitting imports."""
from collections import Counter
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
from cavr_wbc.experiments.step21_report import csv_write


def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def write(p,v):Path(p).write_text(json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def stats(v):
    v=[x for x in v if x is not None]
    return {k:float(np.percentile(v,p)) if v else None for k,p in (('p50',50),('p95',95),('p99',99))}|{'max':max(v) if v else None,'n':len(v)}


def method_summary(rows):
    oracle=sum(bool(r['oracle_safe_available']) for r in rows)
    safe=sum(bool(r['safe_accepted']) for r in rows)
    c=[r for r in rows if r['safe_accepted'] and r['choice']=='C']
    progress=[r['progress20_m'] for r in c if r['progress20_m'] is not None]
    return {'queries':len(rows),'accepted':sum(bool(r['accepted']) for r in rows),
        'safe_accepted':safe,'unsafe_accepted':sum(bool(r['unsafe_accepted']) for r in rows),
        'ABSTAIN':sum(not r['accepted'] for r in rows),'oracle_safe_queries':oracle,
        'oracle_safe_coverage':safe/oracle if oracle else None,'safe_C_retained':len(c),
        'safe_C_progress20_mean_m':float(np.mean(progress)) if progress else None,
        **{k:sum(bool(r[k]) for r in rows) for k in ('physical_error','local_error','terminal_error','numerical_incomplete')}}


def report(out):
    out=Path(out);manifest=read(out/'STEP27_PROTOCOL_AND_MANIFEST.json');finish=read(out/'RUN_FINISHED.json')
    selection=read(out/'models/MODEL_FREEZE.json') if (out/'models/MODEL_FREEZE.json').exists() else {}
    registry=read(out/'SPLIT_REGISTRY.json') if (out/'SPLIT_REGISTRY.json').exists() else []
    queries=read(out/'EVALUATION_QUERIES.json') if (out/'EVALUATION_QUERIES.json').exists() else []
    methods={name:method_summary([r for r in queries if r['method']==name]) for name in sorted({r['method'] for r in queries})}
    grouped=[]
    for field in ('episode','direction','health_kind','faulted_actuator_name'):
        for value in sorted({str(r[field]) for r in queries}):
            for name in methods:
                sub=[r for r in queries if str(r[field])==value and r['method']==name]
                grouped.append({'group_field':field,'group_value':value,'method':name,**method_summary(sub)})
    csv_write(out/'GROUP_RESULTS.csv',grouped)
    gates=Counter(); errors=[]; complete=Counter(); terminal=Counter(); physical=Counter()
    for e in registry:
        lab=read(out/e['bank_directory']/'LABELS.json')
        for mode in ('C','B'):
            l=lab[mode];complete[mode]+=bool(l['complete']);terminal[mode]+=bool(l.get('terminal_pass'))
            physical[mode]+=bool(l.get('original_failure'))
        for g,d in e.get('current_M4_predictions',{}).items():
            for mode,p in d.get('predictions',{}).items():
                for key in ('support_gate','distance_gate','calibration_gate','terminal_gate','local_gate'):
                    gates[mode+':'+key+':reject']+=not p.get(key,False)
    points=read(out/'MARGIN_POINTS.json') if (out/'MARGIN_POINTS.json').exists() else []
    for mode in ('C','B'):
        ps=[p for p in points if p['branch']==mode and p.get('complete') and p.get('prediction_D_hat') is not None]
        errors.append({'branch':mode,'pairs':len(ps),
            'D_MAE_m':float(np.mean([abs(p['D']-p['prediction_D_hat']) for p in ps])) if ps else None,
            'G_T_MAE':float(np.mean([abs(p['G_T']-p['prediction_G_T_hat']) for p in ps])) if ps else None,
            'D_above_U_D':sum(p['D']>p['prediction_U_D'] for p in ps),
            'G_T_above_U_T':sum(p['G_T']>p['prediction_U_T'] for p in ps)})
    timing=read(out/'FULL_READY_TIMING.json') if (out/'FULL_READY_TIMING.json').exists() else []
    engineering={}
    for variant in ('K_RESIDENT','K_BUDGETED'):
        rows=[r for r in timing if r['variant']==variant];valid=[r for r in rows if r['command_valid']]
        engineering[variant]={'attempts':len(rows),'valid_commands':len(valid),'unavailable':len(rows)-len(valid),
            'recognized':sum(r['recognized'] for r in rows),'best_effort':sum(r['best_effort_B'] for r in rows),
            'all_deadline_misses':sum(r['deadline_miss'] for r in rows),
            'valid_deadline_misses':sum(r['deadline_miss'] for r in valid),
            'all_ready_ms':stats([r['command_ready_ms'] for r in rows]),
            'valid_ready_ms':stats([r['command_ready_ms'] for r in valid]),
            'cold_ready_ms':stats([r['command_ready_ms'] for r in rows if r['cold']]),
            'warm_ready_ms':stats([r['command_ready_ms'] for r in rows if not r['cold']]),
            'parts_mean_ms':{key:float(np.mean([r[key] for r in rows])) if rows else None for key in
                ('input_prepare_ms','nominal_ms','feature_ms','inference_ms','first_backup_ms','clip_ms')},
            'nominal_status_counts':dict(Counter(r['nominal_status'] for r in rows)),
            'backup_status_counts':dict(Counter(r['backup_status'] for r in rows if r['backup_status'] is not None))}
    dev=read(out/'DEV_INTERFACE_COMPARISON.json') if (out/'DEV_INTERFACE_COMPARISON.json').exists() else []
    dev_old=stats([r['old_fresh_pair_ms'] for r in dev]);dev_new=stats([r['resident_fresh_pair_ms'] for r in dev])
    full_dev_count=sum(r.get('old_fresh_pair_ms') is not None and r.get('resident_fresh_pair_ms') is not None for r in dev)
    improved=bool(full_dev_count==12 and dev_new['p50']<dev_old['p50'])
    fresh=read(out/'FRESH_RESULTS.json') if (out/'FRESH_RESULTS.json').exists() else []
    fb={'planned':8,'recorded':len(fresh),'status_counts':dict(Counter(r['status'] for r in fresh)),
        'recognized':sum(bool(r.get('recognized')) for r in fresh),'best_effort_executions':sum(bool(r.get('best_effort')) for r in fresh),
        'complete_executions':sum(r['status']=='COMPLETE' for r in fresh),
        'first_command_mismatches':sum(not r['command_ready_matches_first_sent'] for r in fresh if 'command_ready_matches_first_sent' in r),
        'all_tick_20ms_complete_executions':sum(r['status']=='COMPLETE' and r.get('all_feedback_within_20ms',False) for r in fresh),
        'observed_tick_latency_ms':stats([t for r in fresh for t in r.get('feedback_latency_ms',[])])}
    infer=read(out/'INFERENCE_TIMING.json') if (out/'INFERENCE_TIMING.json').exists() else {}
    science=methods.get('M4_STRUCTURED_MARGIN',{})
    supported=bool(science.get('accepted',0)>0 and science.get('unsafe_accepted',1)==0 and
                   (science.get('oracle_safe_coverage') or 0)>=.2 and science.get('safe_C_retained',0)>0)
    bud=engineering['K_BUDGETED']; bs='BUDGETED_KERNEL_USABLE'
    if not bud['valid_commands'] or bud['valid_commands']<=bud['unavailable']:bs='COMMAND_UNAVAILABLE'
    elif bud['valid_deadline_misses']:bs='DEADLINE_MISS'
    result={'run_id':manifest['run_id'],'numerical_status':finish['status'], 'planned_contexts':112,
        'recorded_contexts':len(registry),'qualified_snapshots':sum(e['snapshot_eligible'] for e in registry),
        'current_candidates_available':sum(bool(e.get('current_candidate_valid')) for e in registry),
        'complete_C_B':dict(complete),'terminal_pass_C_B':dict(terminal),'observed_physical_failure_C_B':dict(physical),
        'methods':methods,'gate_reject_query_counts':dict(gates),'margin_errors':errors,'model_selection':selection,
        'engineering':engineering,'inference':{k:v for k,v in infer.items() if k!='all_ms'},
        'fresh_budgeted':fb,'DEV_interface_timing':{'old_pair_ms':dev_old,'resident_pair_ms':dev_new,
             'planned':12,'complete_diagnostic_records':full_dev_count,
             'diagnostic_persistence':'COMPLETE' if full_dev_count==12 else 'PARTIAL',
             'already_executed_DEV_inputs_not_replayed':True},
        'SCIENCE_STATUS':'STRUCTURED_MARGIN_SUPPORTED' if supported else 'NOT_ESTABLISHED',
        'RESIDENT_STATUS':'RESIDENT_KERNEL_IMPROVED' if improved else 'RESIDENT_IMPROVEMENT_NOT_ESTABLISHED',
        'BUDGETED_STATUS':bs,'budget':finish['budget'],'fixed_episode_not_iid':True,'new_test_tuning':False,
        'STEP26_REPLAY':False,'E3_RL_HARDWARE':'NOT_AUTHORIZED'}
    selected_meta=read(selection['assets'][selection['selected_configuration_id']]['json'])
    nearest=[p['prediction_nearest_distance'] for p in points if p.get('prediction_nearest_distance') is not None]
    result['distance_gate_diagnostic']={'threshold':selected_meta['distance_threshold'],
        'new_nearest_min':min(nearest) if nearest else None,'new_nearest_max':max(nearest) if nearest else None,
        'all_new_contexts_outside':len(nearest)==224 and all(x>selected_meta['distance_threshold'] for x in nearest),
        'empirical_margin_not_valid_outside_support':True}
    write(out/'STEP27_RESULT.json',result)
    lines=['# STEP27：连续恢复余量与常驻出令内核','', '## Material Passport','',
        '- 日期：2026-10-08（Asia/Seoul）；Origin Skill：experiment-agent；Mode：run；Verification Status：ANALYZED。',
        f"- Run ID：{manifest['run_id']}；父提交：{manifest['source_commit']}。",'',
        f"结论：**{result['SCIENCE_STATUS']}**；**{result['RESIDENT_STATUS']}**；有界内核 **{bs}**。",'',
        f"完成记录 {len(registry)}/112 个固定上下文，起点合格 {result['qualified_snapshots']}，当前 candidate 可用 {result['current_candidates_available']}。C/B 完整数 {dict(complete)}，终端通过 {dict(terminal)}；观察到原物理违反 {dict(physical)}。未完成标签 D/G_T 保持缺失。",'',
        '## 固定方法与冻结','',
        '旧 STEP26 全部只作 DEV：TRAIN ±40/±80 mm 共 80 个唯一上下文，CAL ±60 mm 共 40 个；跨轮身份去重，不重算源 bank。16 个当前特征仅包含当前状态、方向侧几何、能力和实际 nominal 加速度。健康类型指示为零，完整 12 通道 health 用于发送和评价一致性。',
        '四个固定配置为线性/二次 Ridge(alpha=1.0) × k=3/5，TRAIN-only scaler，D/0.01 m 和无量纲 G_T 两输出。完整终端失败样本参与回归；有限失败和不完整样本仍在邻域库。D 单侧 CAL 储备 1 mm，G_T 储备 0.05；只有支持、距离、终端和位移门均通过才认可 C/B。',
        f"选择 {selection.get('selected_configuration_id')}；开发状态 {selection.get('selection_status')}。线性配置在 CAL 零接受；两个二次配置均安全接受20个查询、错误0、覆盖20/121=16.53%、C保留0；以k=5并列规则选择quadratic_k5。模型在生成四条新 reference 前冻结，新验证后未调整模型。",'',
        '新参考为 ±50/±70 mm、roll/pitch 固定微偏移，0.5/0.7/0.9/1.1 s 快照和 healthy/thigh/calf .50/.30/.15 共 112 个固定输入。recipe seed 只是标识，不是随机独立重复；任务为四点支撑 stance，不是行走。', '',
        '## 新验证：覆盖、任务与错误分类','',
        '| 方法 | 查询 | 安全接受 | 错误接受 | oracle 覆盖 | 安全 C 保留 | ABSTAIN |',
        '|---|---:|---:|---:|---:|---:|---:|']
    for name,s in methods.items():
        coverage=f"{100*s['oracle_safe_coverage']:.2f}%" if s['oracle_safe_coverage'] is not None else '缺失'
        lines.append(f"| {name} | {s['queries']} | {s['safe_accepted']} | {s['unsafe_accepted']} | {coverage} | {s['safe_C_retained']} | {s['ABSTAIN']} |")
    lines += ['', '错误接受按物理、local、terminal 和数值未完成分开统计，分类可重叠；缺失轨迹不能当作物理安全。M0/M1 的单步出令与 M3_STEP26 跨批迁移均引用同一新 teacher bank，不把 gap 重用计成独立轨迹。oracle 仅为离线反事实上限。分组与每次预测/邻居证据见 GROUP_RESULTS.csv、EVALUATION_QUERIES.json、MARGIN_POINTS.json。',
        f"M4 分类计数：{json.dumps({k:science.get(k) for k in ('physical_error','local_error','terminal_error','numerical_incomplete')},ensure_ascii=False)}；安全 C 的实际 20 ms 进度均值 {science.get('safe_C_progress20_mean_m')} m。距离阈值 {selected_meta['distance_threshold']:.6f}，新输入最近TRAIN距离范围 [{min(nearest):.6f},{max(nearest):.6f}]，112/112上下文在支持距离之外。没有把这些输入的经验余量当作有效置信界；完整C/B的D超过U_D为75/57个，G_T超过U_T为85/103个，门控的零误接受不能掩盖跨状态外推偏差。",'',
        '## 完整出令与实际反馈','',
        'K_RESIDENT 常驻两个 WBC/solver、servo、MjData 和映射。独立输入恢复完整 integration state 与参考/积分，并清零 primal/dual warm start；同一轨迹保留 warm start 和六轴积分。QP 数学问题、1e-7 容差、20000 max_iter、PID 与容量门不变。发送前完成状态、有限形状、容量和必要残差/物理检查；详细诊断和持久化置于 command-ready 后。',
        'K_BUDGETED 通过实际 OSQP 1.1.3 原生 Python 绑定的 time_limit 字段固定每次 0.006 s；首次 setup 与后续 update 均设置。超时和 max_iter 不被 clip 获救。原生时间限不保证整个 Python 内核 6 ms 返回。接口依据：[OSQP settings](https://osqp.org/docs/interfaces/solver_settings.html)、[C API](https://osqp.org/docs/interfaces/C.html)。', '',
        '| 内核 | 测量 | 有效命令 | 不可用 | 有效命令超 20ms | 全体 p50/p99/max ms |',
        '|---|---:|---:|---:|---:|---|']
    for v,s in engineering.items():
        t=s['all_ready_ms'];lines.append(f"| {v} | {s['attempts']} | {s['valid_commands']} | {s['unavailable']} | {s['valid_deadline_misses']} | {t['p50']} / {t['p99']} / {t['max']} |")
    lines += ['',f"纯数组推断：{infer.get('iterations',0)} 次，p99={infer.get('p99_ms')} ms（目标 ≤1 ms）。cold 构建计入完整出令；warm 仅省去构建，不省当前准备、QP、检查、推断或 backup。首次 12 个 TRAIN 的同输入接口比较已执行，详细持久化记录仅 {full_dev_count}/12；DEV 第11个输入的旧非有限JSON诊断触发差值格式错误，使前10个尚未落盘的详细诊断丢失。它们的真实QPs仍在全局账本，但 raw/sent/完整时延无法重建，不伪造、不回放。一次DEV修复仅重算第11个、再完成第12个，模型不重训、时间与预算不重置。该缺口使12例matched改善判据未建立；新112上下文的工程测量独立保留。见 DEV_REPAIR_RECORD.json 与 DEV_INTERFACE_COMPARISON.json。",'',
        f"固定 8 个 fresh 有界输入：{fb}。ABSTAIN 的 best-effort B 单列，不计认可接受；每个 tick 仍采用同一 6 ms solver 限。首条出令与执行一致性直接比较 sent torque，后续状态真实积分。只有完整轨迹全 tick 的时延/物理/终端结果才构成闭环证据。",'',
        '## 预算、测试与交接','',
        f"真实 QP {finish['budget']['total_QP_calls']}/14000；积分 {finish['budget']['total_physics_steps']}/140000；数值耗时 {finish['budget']['numerical_elapsed_s']:.3f}/7200 s。未知返回 {finish['budget']['unknown_native_returns']}；DEV 重算 {finish['budget']['DEV_context_recomputations']}/5。",
        'START/RETURN 在内存缓冲并在出令后落盘；异常中断可能存在尚未持久化的计数，不把这部分静默消除。本次正常结束的最终 ledger 逐调用核验见 FINAL_FILE_VERIFICATION.json；必要纯 mock 测试见 TEST_RESULTS.json。',
        '下一项有价值实验：将预声明的小姿态变化纳入新的TRAIN/CAL分布，在保持距离倍率和物理/终端界不变时，检验是否取得非零安全C覆盖；另用启动期常驻工作区准备隔离cold构建成本，再对有效反馈命令验证完整20ms。该建议需要新授权与新冻结验证输入，本轮不执行、不追加开发轮，不进入E3、RL或硬件。', '',
        '两张证据图按 scipilot 使用真实点和失败标记，数值缺失不补零；经验储备不是置信界或安全证书。新数据是固定 episode 的跨状态验证，不给 iid 成功率、跨机器人或连续时间保证。', '',
        '```ini','AUTHORIZE_STEP27_STRUCTURED_MARGIN_AND_RESIDENT_KERNEL = TRUE',
        'AUTHORIZE_FIXED_K_BUDGETED_VARIANT = TRUE',f"NUMERICAL_STATUS = {finish['status']}",f"SCIENCE_STATUS = {result['SCIENCE_STATUS']}",
        f"RESIDENT_STATUS = {result['RESIDENT_STATUS']}",f"BUDGETED_STATUS = {bs}",
        'SOLVER_TIME_LIMIT_S_PER_CALL = 0.006','DEADLINE_MS = 20','BACKUP_HORIZON_S = 1',
        'DENSE_PHYSICS_DT_S = 0.002','SOLVED_FINITE_STATE_RULE_UNCHANGED = TRUE',
        'MAX_NEW_QP_CALLS = 14000','MAX_NEW_PHYSICS_STEPS = 140000','MAX_NUMERICAL_WALL_HOURS = 2',
        'MAX_FIXED_MODEL_CONFIGURATIONS = 4','MAX_DEV_CONTEXT_RECOMPUTATIONS = 5',
        'MODEL_CONFIGURATIONS = 4',f"ACTUAL_DEV_CONTEXT_RECOMPUTATIONS = {finish['budget']['DEV_context_recomputations']}",
        'DEV_DIAGNOSTIC_PERSISTENCE = PARTIAL_2_OF_12','POST_NEW_TEST_MODEL_TUNING = FALSE',
        'STEP26_REPLAY_OR_RERUN = FALSE','HISTORICAL_RESULTS_UNCHANGED = TRUE','E3_RL_HARDWARE = NOT_AUTHORIZED','```','']
    (out/'STEP27_REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
    (out/'STEP27_RESEARCH_HANDOFF.md').write_text('\n'.join(['# STEP27 研究交接','',
        f"Run ID: {manifest['run_id']}",f"Science: {result['SCIENCE_STATUS']}",f"Resident: {result['RESIDENT_STATUS']}",f"Budgeted: {bs}",'',
        '源 STEP26 bank 保持只读，本轮仅追加 STEP27 文件。MODEL_FREEZE.json 必须保持冻结；已有新验证标签不得再次用于宣称同轮未见 TEST。',
        'STEP27_RESULT.json 汇总科学/工程独立判据，CASE_RESULTS.csv/GROUP_RESULTS.csv 分解错误，FULL_READY_TIMING.json 保留每次 fresh 出令分项，FRESH_RESULTS.json 是 K_BUDGETED 实际反馈证据。',
        '所有新输入均超冻结距离门；下一实验可授权新TRAIN/CAL涵盖预声明姿态扰动，同时保持3倍距离门和终端界；工程侧隔离启动期workspace准备与在线更新。禁止根据当前结果重挑输入、放宽20ms或终端界，不重跑历史，不进入E3。下一实验需新的用户授权及新冻结输入。','']),encoding='utf-8')
    figures_caption='''# STEP27 两张证据图

STEP27_margin_evidence：C/B 每个完整上下文一个点（101/103），缺失的11/9条不填0。上排真实D与经验U_D，虚线为D=U_D；下排真实G_T与U_T，横虚线仅表示终端数值门U_T=0，不是完整安全接受区域。所有新输入距离门均不通过，故整张图不存在获认可的接受点。交叉为原物理或终端失败；黑/蓝/橙为healthy/thigh/calf。healthy为圆；thigh .50/.30/.15用方/上三角/菱形，calf .50/.30/.15用下三角/加号形/右三角，类别与health均可灰度辨识。重叠点不抖动、不删去。两分支可比轴使用相同范围。

STEP27_coverage_timing：上排按固定gap显示oracle-safe接受覆盖和全部计划查询中的安全C保留，下排显示所有336+336次完整出令真实点，圆点为有效、交叉为不可用，20ms为水平虚线；仅横向排布加入确定性抖动，不改变时延。M0与M1的覆盖/C保留曲线重合，oracle与其安全C保留也重合；不是遗漏方法。左下为对数耗时，右下为不可用比例。cold含两个WBC、servo、MjData与映射构建；warm计入正确case重置后的完整路径。MuJoCo模型离线载入一次，非在线出令步骤。零认可接受的best-effort结果不算筛选成功。

图按IEEE双栏7.16in、8–9pt、600dpi PNG及PDF导出；图中是固定相关输入及共享轨迹，没有iid置信区间或显著性标注。MATPLOTLIB预览和灰度复核检查八项，仅进行一次必要QA，不新增物理运行。
'''
    (out/'FIGURE_CAPTIONS.md').write_text(figures_caption,encoding='utf-8')
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('out');report(p.parse_args().out)
