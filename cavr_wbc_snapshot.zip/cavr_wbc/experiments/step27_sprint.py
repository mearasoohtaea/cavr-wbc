"""One frozen STEP27 DEV fit, new teacher bank and resident/budgeted readiness."""
import argparse
from copy import deepcopy
from datetime import datetime, timezone
import gc
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import sys
from time import perf_counter
import traceback
import numpy as np
from cavr_wbc.experiments import step17_formal_panel as frozen
from cavr_wbc.experiments import step26_sim as oldsim
from cavr_wbc.experiments import step27_sim as sim
from cavr_wbc.experiments.step27_budget import SprintBudget, SprintLimit
from cavr_wbc.experiments.step26_features_storage import save_bank, extract_features as oldfeatures
from cavr_wbc.control.step27_structured_margin import (
    extract_features, labels, load_dev, fit_fixed, load_bundle, decide, feature_specification)
from cavr_wbc.control.step27_resident_kernel import ResidentKernel
from cavr_wbc.control.step25_capacity_backup import CapacityHoldBackup, capacity_command
from cavr_wbc.control.step26_fast_margin import decide as olddecide
from cavr_wbc.platforms.go2_mujoco import extract_actuator_audit
from cavr_wbc.experiments.step21_report import csv_write

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT/'artifacts/step26_fast_margin_20261008/step26-fast-margin-20261008-01'
PROTOCOL = Path('E:/CAVR-WBC/experiment_handoff_20260921/NEXT_CODEX_INSTRUCTIONS_STEP27_STRUCTURED_MARGIN_RESIDENT_KERNEL_20261008.md')
PARENT = '842367fb68b6b53c29294fd84df496d396416b3e'
GAPS = (.001,.002,.004,.008,.016,.032)
KINDS = ('HEALTHY','THIGH_50','THIGH_30','THIGH_15','CALF_50','CALF_30','CALF_15')
EPISODES = (('T27_P050',.05,20261171,.003,.003),
            ('T27_N050',-.05,20261171,.003,.003),
            ('T27_P070',.07,20261172,-.003,.003),
            ('T27_N070',-.07,20261172,-.003,.003))


def safe(v):
    if isinstance(v,np.ndarray): return safe(v.tolist())
    if isinstance(v,np.generic): return safe(v.item())
    if isinstance(v,float) and not np.isfinite(v): return None
    if isinstance(v,dict): return {str(k):safe(x) for k,x in v.items()}
    if isinstance(v,(tuple,list)): return [safe(x) for x in v]
    return v


def write(path,obj):
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_suffix(p.suffix+'.tmp')
    tmp.write_text(json.dumps(safe(obj),sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
    os.replace(tmp,p)


def read(path): return json.loads(Path(path).read_text(encoding='utf-8'))
def digest(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def finite_difference(left,right):
    """Nonfinite diagnostic dictionaries represent unavailable comparisons."""
    try:
        x=np.asarray(left,float);y=np.asarray(right,float)
        return float(np.max(np.abs(x-y))) if x.shape==y.shape and x.size and np.isfinite(x).all() and np.isfinite(y).all() else None
    except (TypeError,ValueError):
        return None


def missing(reason):
    return {'complete':False,'D':None,'G_T':None,'valid':False,
            'original_physical_safe':False,'terminal_pass':False,'reason':reason,
            'progress20_m':None,'endpoint_progress_m':None,'original_failure':None}


def truth(label,gap):
    return bool(label.get('complete') and label.get('original_physical_safe') and
                label.get('terminal_pass') and label.get('D') is not None and label['D']<=gap)


def context(snapshot,kind,mapping):
    c=deepcopy(snapshot); side='FR' if c.get('direction',0)>0 else 'RR'
    cid=snapshot['snapshot_id']+'_'+kind
    hv=[1.]*12; name='NONE'; index=None; h=1.
    if kind!='HEALTHY':
        joint, hs=kind.split('_'); name=side+'_'+joint.lower()
        index=next(a['actuator_index'] for a in mapping if a['actuator_name']==name)
        h=int(hs)/100.; hv[index]=h
    c.update(context_id=cid,case_id=cid,health_vector=hv,health_kind=kind,
             faulted_actuator_name=name,faulted_actuator_index=index,faulted_health=h,
             split='FIXED_NEW_VALIDATION',backup_id='STEP27-'+cid)
    return c


def command_ready(kernel,c,bundle,gap,budget):
    """All current work charged; no label/bank/command cache enters this path."""
    t=perf_counter(); kernel.reset(c); prepared=(perf_counter()-t)*1000
    n=kernel.nominal(c,budget=budget,kind='READY_NOMINAL',owner=c['context_id'])
    nt=(perf_counter()-t)*1000-prepared
    ft=perf_counter(); features=None; feature_error=None
    try: features=extract_features(c,n,kernel.mapping)
    except (ValueError,KeyError,TypeError) as exc: feature_error=str(exc)
    feature_ms=(perf_counter()-ft)*1000
    it=perf_counter()
    decision=decide(bundle,features,gap) if features is not None else {'choice':'ABSTAIN','accepted':False,'reject_reasons':['CURRENT_FEATURE_UNAVAILABLE']}
    infer_ms=(perf_counter()-it)*1000
    if not n['command_valid'] or not n['current_physical_check']['pass']:
        decision['choice']='ABSTAIN'; decision['accepted']=False
    selected=decision['choice']; response=None; back_ms=0.
    if selected!='C':
        bt=perf_counter(); kernel.reset_backup(kernel.data,c)
        response=kernel.compute_backup(c,0,budget=budget,kind='READY_BACKUP',owner=c['context_id'])
        interface=response['capacity_interface']; back_ms=(perf_counter()-bt)*1000
    else: interface=n['capacity_interface']
    ct=perf_counter()
    final=capacity_command(interface['tau_raw'],c['health_vector'],kernel.limits,interface['solver_status_val'])
    valid=bool(final['command_valid'] and (n['command_valid'] if selected=='C' else response['valid_command']))
    clip_ms=(perf_counter()-ct)*1000
    # Stop clock before serialization, hashing or ledger flushing; all necessary checks above.
    elapsed=(perf_counter()-t)*1000
    record={'context_id':c['context_id'],'variant':kernel.variant,'gap_m':gap,
        'choice':selected,'recognized':bool(decision['accepted'] and valid),
        'best_effort_B':selected=='ABSTAIN','command_valid':valid,'tau_sent':final['tau_sent'] if valid else None,
        'command_ready_ms':elapsed,'deadline_miss':elapsed>20.,'input_prepare_ms':prepared,
        'nominal_ms':nt,'feature_ms':feature_ms,'inference_ms':infer_ms,'first_backup_ms':back_ms,'clip_ms':clip_ms,
        'feature_error':feature_error,'decision':decision,'no_future_label_or_bank_access':True,
        'no_disk_write_before_ready':True,'nominal_status':n.get('solver_status'),
        'backup_status':response['wbc'].get('status') if response else None}
    return record,n,response


def dev_comparison(out,model,records,bundle,budget,repair=False):
    selected=sorted((r for r in records if r['split']=='TRAIN'),key=lambda r:r['id'])[:12]
    rows=[]; kernel=ResidentKernel(model,variant='K_RESIDENT')
    if repair:
        # First ten native comparisons executed; their detailed response/timing
        # buffer was lost before the original end-of-loop write. Never replay
        # these to manufacture a complete comparison set or consume >5 DEV fixes.
        rows=[{'context_id':r['id'],'old_fresh_pair_ms':None,'resident_fresh_pair_ms':None,
               'evidence_status':'UNPERSISTED_DIAGNOSTIC_BUFFER_AFTER_DEV_EXCEPTION',
               'native_calls_present_in_global_ledger':True} for r in selected[:10]]
        selected=selected[10:]
        budget.dev_recomputations+=1
    for r in selected:
        c=r['context']; budget.check(); current=oldsim.restore_snapshot(model,c)
        start=perf_counter(); old=oldsim.nominal(model,current,c,budget)
        policy=CapacityHoldBackup(model,c['backup_anchor_q_init'],c['backup_id'],solve_callback=budget.qp_callback('DEV_OLD_BACKUP',r['id']))
        oldb=policy.compute(current,c['health_vector'],0); oldms=(perf_counter()-start)*1000
        kernel.reset(c); start=perf_counter()
        new=kernel.nominal(c,budget=budget,kind='DEV_RESIDENT_NOMINAL',owner=r['id'])
        kernel.reset_backup(kernel.data,c)
        newb=kernel.compute_backup(c,0,budget=budget,kind='DEV_RESIDENT_BACKUP',owner=r['id'])
        newms=(perf_counter()-start)*1000
        comparisons={}
        old_nominal_response=dict(old['response'],wbc=old['raw_solver_result'])
        new_nominal_response=dict(new['response'],wbc=new['raw_solver_result'])
        for mode,a,b in (('nominal',old_nominal_response,new_nominal_response),('backup',oldb,newb)):
            def delta(field):
                return finite_difference(a['capacity_interface'][field],b['capacity_interface'][field])
            comparisons[mode]={'old_status':a['wbc']['status'],'new_status':b['wbc']['status'],
                'raw_inf_difference_nm':delta('tau_raw'),'sent_inf_difference_nm':delta('tau_sent'),
                'old_integral':a['integral_record'],'new_integral':b['integral_record'],
                'old_validation':a['wbc'].get('validation'),'new_validation':b['wbc'].get('validation')}
        ready,_,_=command_ready(kernel,c,bundle,.008,budget)
        rows.append({'context_id':r['id'],'old_fresh_pair_ms':oldms,'resident_fresh_pair_ms':newms,
                     'comparison':comparisons,'resident_complete_ready':ready,
                     'attempt_id':'DEV_REPAIR02' if repair else 'DEV_ATTEMPT01'})
        write(out/'DEV_INTERFACE_COMPARISON.json',rows)
        budget.persist(phase='DEV_COMPARISON',contexts=len(rows))
    write(out/'DEV_INTERFACE_COMPARISON.json',rows)
    return rows


def produce(out,model,kernel,c,bundle,budget):
    directory=out/'bank'/c['context_id']/'attempt01'
    entry={'context_id':c['context_id'],'episode_id':c['episode_id'],'context':c,
           'snapshot_eligible':bool(c.get('eligible')),'features':None,'attempt_id':'attempt01',
           'bank_paths':{},'bank_directory':str(directory.relative_to(out))}
    lab={m:missing('SNAPSHOT_INELIGIBLE') for m in ('C','B')}
    lab['preview']={'pass':False,'D_step':None}
    if c.get('eligible'):
        kernel.reset(c)
        n=kernel.nominal(c,budget=budget,kind='TEACHER_NOMINAL',owner=c['context_id'])
        current=kernel.data
        try: entry['features']=extract_features(c,n,kernel.mapping).tolist()
        except (ValueError,KeyError,TypeError) as exc: entry['feature_unavailable_reason']=str(exc)
        try: entry['step26_features']=oldfeatures(c,n,kernel.mapping).tolist()
        except (ValueError,KeyError,TypeError) as exc: entry['step26_feature_unavailable_reason']=str(exc)
        entry['current_candidate_valid']=n['command_valid']
        entry['current_physical_pass']=n['current_physical_check']['pass']
        # Freeze current prediction before producer creates any future branch.
        entry['current_M4_predictions']={str(g):decide(bundle,entry['features'],g) for g in GAPS} if entry['features'] is not None else {}
        write(directory/'CURRENT_INPUT.json',{'context':c,'nominal':n,'features':entry['features'],
                                            'current_predictions':entry['current_M4_predictions']})
        if n['command_valid']:
            p=oldsim.preview(model,current,c,n,budget)
            entry['bank_paths']['PREVIEW']=save_bank(directory/'preview.npz',p)
            if p['status']=='COMPLETE':
                from cavr_wbc.evaluation.step23_actual import actual_reasons
                rows=([p['initial_fact']] if p.get('initial_fact') else [])+p['physics_trajectory']
                lab['preview']={'pass':not any(actual_reasons(x) for x in rows),
                    'D_step':max(0.,max(c['direction']*(x['qpos'][0]-c['x0_m']) for x in rows))}
        for mode in ('C','B'):
            branch=sim.actual_branch(model,current,c,n,mode,'ACTUAL_'+mode,budget,kernel)
            entry['bank_paths'][mode]=save_bank(directory/(mode+'.npz'),branch)
            write(directory/(mode+'_CONTROL_RESULTS.json'),{'branch_id':branch['branch_id'],
                'status':branch['status'],'controls':branch['controls'],'reason':branch.get('reason')})
            lab[mode]=labels(branch,c)
            if mode=='B': entry['first_backup_valid']=bool(branch.get('controls') and branch['controls'][0]['valid_command'])
            if branch['status']=='FAILED_BUDGET':
                write(directory/'LABELS.json',lab);write(directory/'PUBLIC_INPUT.json',entry)
                raise SprintLimit('teacher partial evidence saved')
            del branch
    write(directory/'LABELS.json',lab);write(directory/'PUBLIC_INPUT.json',entry)
    return entry


def new_bank(out,model,manifest,bundle,budget):
    if not (out/'models'/'MODEL_FREEZE.json').exists(): raise RuntimeError('MODEL_FREEZE required before new reference')
    budget.event('NEW_VALIDATION_OPEN',model_freeze_sha256=digest(out/'models'/'MODEL_FREEZE.json'))
    kernel=ResidentKernel(model,variant='K_RESIDENT'); registry=[]
    for eid,d,seed,roll,pitch in EPISODES:
        scenario=deepcopy(manifest['scenario']); scenario.update(seed=seed,
            initial_roll=manifest['scenario']['initial_roll']+roll,
            initial_pitch=manifest['scenario']['initial_pitch']+pitch)
        episode=oldsim.reference_episode(model,scenario,d,eid,(25,35,45,55),budget)
        write(out/'references'/(eid+'.json'),episode)
        found={s['source_tick']:s for s in episode['snapshots']}
        for tick in (25,35,45,55):
            snapshot=found.get(tick,{'snapshot_id':eid+f'_T{tick:03d}','episode_id':eid,
                'source_tick':tick,'eligible':False,'direction':1 if d>0 else -1,
                'eligibility_reason':'REFERENCE_INCOMPLETE'})
            for kind in KINDS:
                c=context(snapshot,kind,manifest['mapping']);c['ordinal']=len(registry)
                budget.event('CONTEXT_START',owner=c['context_id'],attempt_id='attempt01')
                entry=produce(out,model,kernel,c,bundle,budget)
                registry.append(entry);write(out/'SPLIT_REGISTRY.json',registry)
                budget.event('CONTEXT_END',owner=c['context_id'],attempt_id='attempt01')
                budget.persist(phase='NEW_TEACHER',completed_contexts=len(registry),last_context=c['context_id'])
                if len(registry)%7==0: print(json.dumps({'phase':'TEACHER','contexts':len(registry),'budget':budget.snapshot()}),flush=True)
                gc.collect()
    return registry


def evaluation(out,registry,oldbundle):
    rows=[];points=[]
    for e in registry:
        c=e['context']; lab=read(out/e['bank_directory']/'LABELS.json')
        for mode in ('C','B'):
            pred=e.get('current_M4_predictions',{}).get(str(.008),{}).get('predictions',{}).get(mode,{})
            points.append({'context_id':e['context_id'],'episode':e['episode_id'],'health_kind':c['health_kind'],
                'branch':mode,**lab[mode],**{'prediction_'+k:v for k,v in pred.items()}})
        for gap in GAPS:
            truths={mode:truth(lab[mode],gap) for mode in ('C','B')}
            m4=e.get('current_M4_predictions',{}).get(str(gap),{'choice':'ABSTAIN'})
            m3=olddecide(oldbundle,e['step26_features'],gap) if e.get('step26_features') is not None else {'mode':'ABSTAIN'}
            current=bool(e.get('current_candidate_valid') and e.get('current_physical_pass'))
            choices={'M0_CURRENT':'C' if current else 'ABSTAIN',
                'M1_ONE_STEP':'C' if current and lab['preview']['pass'] and lab['preview']['D_step'] is not None and lab['preview']['D_step']<=gap else 'B' if e.get('first_backup_valid') else 'ABSTAIN',
                'M3_STEP26':m3['mode'] if current else 'ABSTAIN',
                'M4_STRUCTURED_MARGIN':m4['choice'] if current else 'ABSTAIN',
                'ORACLE':'C' if truths['C'] else 'B' if truths['B'] else 'ABSTAIN'}
            for method,choice in choices.items():
                label=lab.get(choice,{})
                accept=choice!='ABSTAIN'
                rows.append({'context_id':e['context_id'],'episode':e['episode_id'],'direction':c['direction'],
                    'health_kind':c['health_kind'],'faulted_health':c['faulted_health'],'faulted_actuator_name':c['faulted_actuator_name'],
                    'snapshot_eligible':e['snapshot_eligible'],'gap_m':gap,'method':method,'choice':choice,
                    'accepted':accept,'oracle_safe_available':any(truths.values()),'safe_accepted':accept and truths.get(choice,False),
                    'unsafe_accepted':accept and not truths.get(choice,False),
                    'physical_error':bool(accept and label.get('original_failure')),
                    'local_error':bool(accept and label.get('complete') and label.get('D') is not None and label['D']>gap),
                    'terminal_error':bool(accept and label.get('complete') and not label.get('terminal_pass')),
                    'numerical_incomplete':bool(accept and not label.get('complete')),
                    'D':label.get('D'),'G_T':label.get('G_T'),'progress20_m':label.get('progress20_m'),
                    'M4_decision':m4 if method=='M4_STRUCTURED_MARGIN' else None})
    write(out/'EVALUATION_QUERIES.json',rows);write(out/'MARGIN_POINTS.json',points)
    csv_write(out/'CASE_RESULTS.csv',rows)
    return rows


def engineering(out,model,registry,bundle,budget):
    rows=[]; inference=[]
    qualified=[e for e in registry if e['snapshot_eligible']]
    for i in range(1000):
        if not qualified: break
        e=qualified[i%len(qualified)]
        if e['features'] is None: continue
        t=perf_counter();decide(bundle,e['features'],.008);inference.append((perf_counter()-t)*1000)
    write(out/'INFERENCE_TIMING.json',{'all_ms':inference,'iterations':len(inference),
        'p99_ms':float(np.percentile(inference,99)) if inference else None,'target_ms':1.})
    for variant in ('K_RESIDENT','K_BUDGETED'):
        for e in qualified:
            t=perf_counter();kernel=ResidentKernel(model,variant=variant); construction=(perf_counter()-t)*1000
            for gi,gap in enumerate((.002,.008,.032)):
                record,_,_=command_ready(kernel,e['context'],bundle,gap,budget)
                record.update(cold=gi==0,cold_construction_ms=construction if gi==0 else 0.,
                              warm_excludes_only_construction=gi!=0)
                if gi==0:
                    record['command_ready_ms']+=construction;record['deadline_miss']=record['command_ready_ms']>20.
                rows.append(record)
                budget.event('COMMAND_READY',owner=e['context_id'],variant=variant,gap_m=gap,
                             command_valid=record['command_valid'],command_ready_ms=record['command_ready_ms'])
                budget.persist(phase='ENGINEERING',timing_queries=len(rows),variant=variant,last_context=e['context_id'])
            if len(rows)%42==0: print(json.dumps({'phase':'ENGINEERING','timing_queries':len(rows),'budget':budget.snapshot()}),flush=True)
            gc.collect()
    write(out/'FULL_READY_TIMING.json',rows);csv_write(out/'FULL_READY_TIMING.csv',rows)
    return rows


def fresh(out,model,registry,bundle,budget):
    ordered=sorted(registry,key=lambda e:e['context_id']); rows=[]
    for index,gap in zip((0,15,31,47,63,79,95,111),(.002,.008,.032,.002,.008,.032,.002,.008)):
        if index>=len(ordered) or not ordered[index]['snapshot_eligible']:
            rows.append({'index':index,'gap_m':gap,'status':'INELIGIBLE_SKIP_NO_REPLACEMENT'});continue
        e=ordered[index];c=e['context'];t=perf_counter();kernel=ResidentKernel(model,variant='K_BUDGETED')
        construction=(perf_counter()-t)*1000
        record,n,response=command_ready(kernel,c,bundle,gap,budget)
        record.update(cold=True,cold_construction_ms=construction)
        record['command_ready_ms']+=construction
        record['deadline_miss']=record['command_ready_ms']>20.
        if not record['command_valid']:
            rows.append({'index':index,'gap_m':gap,'ready':record,'status':'COMMAND_UNAVAILABLE'});budget.persist(phase='FRESH');continue
        mode=record['choice'] if record['choice']!='ABSTAIN' else 'B'
        if mode=='C': n['command_ready_ms']=record['command_ready_ms']
        else:
            response['backup_only_command_ready_ms']=response['command_ready_ms']
            response['command_ready_ms']=record['command_ready_ms']
        branch=sim.actual_branch(model,kernel.data,c,n,mode,'ACTUAL_'+mode,budget,kernel,
                                 ready_response=response if mode=='B' else None)
        path=save_bank(out/'fresh'/c['context_id']/'execution.npz',branch)
        write(out/'fresh'/c['context_id']/'CONTROL_RESULTS.json',{'branch_id':branch['branch_id'],
            'controls':branch['controls'],'status':branch['status'],'reason':branch.get('reason')})
        label=labels(branch,c);controls=branch.get('controls',[])
        matches=bool(controls and np.array_equal(controls[0]['tau_sent'],record['tau_sent']))
        rows.append({'index':index,'context_id':c['context_id'],'gap_m':gap,'ready':record,
            'status':branch['status'],'recognized':record['recognized'], 'best_effort':record['best_effort_B'],
            'command_ready_matches_first_sent':matches,'actual_label':label,'path':path,
            'feedback_latency_ms':[x.get('command_ready_ms',x.get('latency_ms')) for x in controls],
            'all_feedback_within_20ms':bool(controls and all(x.get('command_ready_ms',x.get('latency_ms',float('inf')))<=20 for x in controls)),
            'reason':branch.get('reason')})
        write(out/'FRESH_RESULTS.json',rows);budget.persist(phase='FRESH',fresh_done=len(rows))
        if branch['status']=='FAILED_BUDGET':raise SprintLimit('fresh partial saved')
    write(out/'FRESH_RESULTS.json',rows)
    return rows


def manifest(out,run_id,model):
    old=read(SOURCE/'STEP26_PROTOCOL_AND_MANIFEST.json')
    sourcefiles=sorted(str(p.relative_to(ROOT)).replace('\\','/') for directory in ('cavr_wbc','tests')
                       for p in (ROOT/directory).rglob('*step27*.py'))
    m={'run_id':run_id,'date':'2026-10-08','timezone':'Asia/Seoul','source_commit':PARENT,
        'source_dir':str(SOURCE),'protocol':str(PROTOCOL),'protocol_sha256':digest(PROTOCOL),
        'scenario':old['scenario'],'mapping':extract_actuator_audit(model),
        'frozen_physical':{k:old[k] for k in ('physical_config','evaluation_config','terminal_set','wbc_config','model_files_sha256')},
        'episodes':EPISODES,'ticks':[25,35,45,55],'health_kinds':KINDS,'fixed_gaps_m':GAPS,
        'fresh_sorted_indices':[0,15,31,47,63,79,95,111],'fresh_gaps_m':[.002,.008,.032,.002,.008,.032,.002,.008],
        'fresh_sorted_context_ids':sorted(eid+f'_T{tick:03d}_'+kind for eid,*_ in EPISODES for tick in (25,35,45,55) for kind in KINDS),
        'planned_contexts':112,'teacher_kernel':'K_RESIDENT','engineering_variants':['K_RESIDENT','K_BUDGETED'],
        'solver_time_limit_s':.006,'eps_abs':1e-7,'eps_rel':1e-7,'max_iter':20000,
        'deadline_ms':20,'horizon_s':1,'physics_dt_s':.002,'control_dt_s':.02,'dense_states':501,
        'max_QP_calls':14000,'max_physics_steps':140000,'max_numerical_wall_s':7200,
        'max_DEV_context_recomputations':5,'max_model_configurations':4,'post_new_validation_tuning':False,
        'source_sha256':{p:digest(ROOT/p) for p in sourcefiles},
        'all_STEP26_data_DEV':True,'historical_replay':False,'E3_RL_hardware':False,
        'buffered_accounting':'QP_START/RETURN in memory before ready, fsync afterready; interruption can leave unpersisted unknown calls',
        'OSQP_docs':['https://osqp.org/docs/interfaces/solver_settings.html','https://osqp.org/docs/interfaces/C.html'],
        'dependencies':{k:importlib.metadata.version(k) for k in ('numpy','scipy','mujoco','osqp','scikit-learn','joblib')},
        'python':sys.executable,'PYTHONPATH':os.environ.get('PYTHONPATH')}
    write(out/'STEP27_PROTOCOL_AND_MANIFEST.json',m)
    (out/'PROTOCOL_SOURCE.md').write_text(PROTOCOL.read_text(encoding='utf-8'),encoding='utf-8')
    return m


def run(run_id,dev_repair=False):
    out=ROOT/'artifacts/step27_structured_margin_20261008'/run_id
    if dev_repair:
        if not out.exists() or (out/'DEV_REPAIR_RECORD.json').exists() or (out/'SPLIT_REGISTRY.json').exists():
            raise RuntimeError('This one DEV repair is only allowed before new validation opens')
        write(out/'DEV_REPAIR_RECORD.json',{'authorization':'STEP27 protocol DEV implementation repair <=5',
            'attempt_id':'DEV_REPAIR02','original_interruption':read(out/'INTERRUPTION.json'),
            'original_segment_finished':read(out/'RUN_FINISHED.json'),'original_run_started':read(out/'RUN_STARTED.json'),
            'current_pid':os.getpid(),'created_utc':datetime.now(timezone.utc).isoformat(),
            'remaining_DEV_contexts_only':True,'old_first10_not_replayed':True,
            'source_revision_sha256':{str(p.relative_to(ROOT)).replace('\\','/'):digest(p) for p in
                (ROOT/'cavr_wbc/experiments/step27_sprint.py',ROOT/'cavr_wbc/experiments/step27_budget.py',ROOT/'tests/test_step27_sprint.py')}})
    else:
        if out.exists():raise FileExistsError('unique new run required')
        out.mkdir(parents=True)
        write(out/'RUN_STARTED.json',{'run_id':run_id,'pid':os.getpid(),'created_utc':datetime.now(timezone.utc).isoformat()})
    budget=SprintBudget(out,authorized_dev_repair=dev_repair);status='COMPLETED'; registry=[]
    try:
        model=frozen.load_model()
        if dev_repair:
            m=read(out/'STEP27_PROTOCOL_AND_MANIFEST.json');records=read(out/'DEV_SPLIT_REGISTRY.json')
            bundle=load_bundle(out/'models')
        else:
            m=manifest(out,run_id,model)
            records=load_dev(SOURCE,m['mapping']);write(out/'DEV_SPLIT_REGISTRY.json',records)
            budget.start();fitted=fit_fixed(records,out/'models');bundle=fitted['selected'];budget.fit_count=16
            write(out/'MODEL_SELECTION.json',{k:v for k,v in fitted.items() if k not in ('selected','selected_bundle')})
            budget.event('MODEL_FROZEN',selected=fitted['selected_configuration_id'],source_dev_contexts=len(records))
            budget.persist(phase='MODELS_FROZEN')
        dev_comparison(out,model,records,bundle,budget,repair=dev_repair)
        registry=new_bank(out,model,m,bundle,budget)
        import joblib
        oldbundle=joblib.load(SOURCE/'models/round2/step26_model_A.joblib')
        evaluation(out,registry,oldbundle)
        engineering(out,model,registry,bundle,budget)
        fresh(out,model,registry,bundle,budget)
    except SprintLimit as exc:
        status='INCOMPLETE_BUDGET';write(out/'INTERRUPTION.json',{'type':'BUDGET','error':str(exc),'budget':budget.snapshot()})
    except BaseException as exc:
        status='STOPPED_IMPLEMENTATION_OR_RESOURCE';write(out/'INTERRUPTION.json',{'type':type(exc).__name__,'error':str(exc),'traceback':traceback.format_exc(),'budget':budget.snapshot()})
        raise
    finally:
        budget.event('NUMERICAL_FINISHED',status=status,**budget.snapshot());budget.close()
        write(out/'RUN_FINISHED.json',{'run_id':run_id,'status':status,'budget':budget.snapshot(),'finished_utc':datetime.now(timezone.utc).isoformat()})
        print(json.dumps({'status':status,'out':str(out),'budget':budget.snapshot()}),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('run_id');parser.add_argument('--dev-repair',action='store_true')
    args=parser.parse_args();run(args.run_id,args.dev_repair)
