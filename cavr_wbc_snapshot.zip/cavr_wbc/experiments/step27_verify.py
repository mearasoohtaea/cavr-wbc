"""One current-output/ledger closure check, without solver or integration."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import numpy as np
from cavr_wbc.experiments.step26_features_storage import load_bank


def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def verify(out):
    out=Path(out).resolve();root=out.parents[2]
    target=out/'FINAL_FILE_VERIFICATION.json'
    if target.exists():raise FileExistsError('Current file/ledger closure is one-shot')
    ledger=[json.loads(x) for x in (out/'STEP27_LEDGER.jsonl').read_text(encoding='utf-8').splitlines()]
    starts=[r for r in ledger if r['event']=='QP_START'];returns=[r for r in ledger if r['event']=='QP_RETURN']
    ids=[r['global_qp_index'] for r in starts];rid=[r['global_qp_index'] for r in returns]
    finish=read(out/'RUN_FINISHED.json');budget=finish['budget'];manifest=read(out/'STEP27_PROTOCOL_AND_MANIFEST.json')
    registry=read(out/'SPLIT_REGISTRY.json');freeze=read(out/'models/MODEL_FREEZE.json')
    newopen=next(i for i,r in enumerate(ledger) if r['event']=='NEW_VALIDATION_OPEN')
    frozen=next(i for i,r in enumerate(ledger) if r['event']=='MODEL_FROZEN')
    primary=[r for r in returns if r.get('kernel_variant')=='K_RESIDENT']
    bounded=[r for r in returns if r.get('kernel_variant')=='K_BUDGETED']
    checks={'one_run_id':manifest['run_id']==finish['run_id'],
        'contiguous_unique_native_starts':ids==list(range(1,len(starts)+1)),
        'one_native_return_per_start':rid==ids,
        'reported_QPs_equal_ledger':len(starts)==budget['total_QP_calls']==budget['QP_returns'],
        'real_native_not_callback_injection':all(r['real_optimizer_called'] is True for r in returns),
        'budgets_not_exceeded':len(starts)<=14000 and budget['total_physics_steps']<=140000 and budget['numerical_elapsed_s']<=7200,
        'one_unchanged_numerical_start':sum(r['event']=='NUMERICAL_STARTED' for r in ledger)==1,
        'model_frozen_before_new_validation':frozen<newopen,
        'exact_four_frozen_configurations':freeze['fixed_model_configurations']==4,
        'budgeted_fixed_6ms_all_calls':bool(bounded) and all(r['osqp_time_limit_s']==.006 for r in bounded),
        'resident_unbounded_primary_separate':bool(primary) and all(r['osqp_time_limit_s'] is None for r in primary),
        'planned_112_unique_contexts':len(registry)==112 and len({e['context_id'] for e in registry})==112}
    assets=[]
    for name,asset in freeze['assets'].items():
        for key in ('npz','json'):
            assets.append({'configuration':name,'path':asset[key],'hash_pass':sha(asset[key])==asset[key+'_sha256']})
    checks['frozen_model_assets_unchanged']=all(a['hash_pass'] for a in assets)
    snapshots={}; step_total=0;branch_rows=[];paths=[]
    for p in sorted((out/'references').glob('*.json')):
        ep=read(p);step_total+=ep['counts']['physical_steps']
        snapshots[ep['episode_id']]=len(ep['snapshots'])
    for e in registry:
        for mode,artifact in e['bank_paths'].items():
            p=Path(artifact['path']).resolve()
            if not p.is_relative_to(out):raise ValueError('new shard escaped unique output directory')
            branch=load_bank(p);step_total+=branch['counts']['physical_steps']
            rows=([branch['initial_fact']] if branch.get('initial_fact') else [])+branch['physics_trajectory']
            complete=branch['status']=='COMPLETE'
            row={'context_id':e['context_id'],'branch':mode,'status':branch['status'],
                 'row_count':len(rows),'physical_steps':branch['counts']['physical_steps'],
                 'hash_pass':sha(p)==artifact['sha256'],
                 'full_grid_pass':not complete or mode=='PREVIEW' or [x['physics_step'] for x in rows]==list(range(501)),
                 'raw_sent_applied_health_preserved':all(all(k in r for k in ('tau_raw','tau_sent','tau_applied','health_vector')) for r in rows if 'qpos' in r)}
            branch_rows.append(row);paths.append(str(p))
    fresh=read(out/'FRESH_RESULTS.json')
    for r in fresh:
        if 'path' in r:
            p=Path(r['path']['path']).resolve();b=load_bank(p);step_total+=b['counts']['physical_steps']
            branch_rows.append({'context_id':r['context_id'],'branch':'FRESH_BUDGETED','status':b['status'],
                'hash_pass':sha(p)==r['path']['sha256'],'first_command_match':r['command_ready_matches_first_sent']})
    checks['all_new_shard_hashes']=all(r['hash_pass'] for r in branch_rows)
    checks['all_complete_dense_grids']=all(r.get('full_grid_pass',True) for r in branch_rows)
    checks['raw_sent_applied_health_separate']=all(r.get('raw_sent_applied_health_preserved',True) for r in branch_rows)
    checks['integrations_equal_saved_trajectories']=step_total==budget['total_physics_steps']
    checks['fresh_first_sent_consistency']=all(r.get('first_command_match',True) for r in branch_rows)
    revision=read(out/'DEV_REPAIR_RECORD.json') if (out/'DEV_REPAIR_RECORD.json').exists() else {}
    changed=[]
    for path,digest in manifest['source_sha256'].items():
        actual=sha(root/path)
        if actual!=digest:
            reason='AUTHORIZED_PRE_NEW_VALIDATION_DEV_REPAIR' if revision.get('source_revision_sha256',{}).get(path)==actual else 'POSTPROCESS_REPORT_OR_FIGURE_ONLY' if path in ('cavr_wbc/experiments/step27_report.py','cavr_wbc/experiments/step27_figures.py') else 'UNEXPLAINED'
            changed.append({'path':path,'original_sha256':digest,'current_sha256':actual,'reason':reason})
    checks['numerical_source_unchanged_except_authorized_DEV_repair']=all(r['reason']!='UNEXPLAINED' for r in changed)
    tests=read(out/'TEST_RESULTS.json');checks['initial_minimal_mock_tests_passed']=tests['result']['exit_code']==0
    checks['unknown_returns_not_erased']=budget['unknown_native_returns']==len(starts)-len(returns)
    files=[{'path':str(p.relative_to(out)).replace('\\','/'),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(out.rglob('*')) if p.is_file() and p!=target]
    value={'schema':'STEP27_ONE_CURRENT_OUTPUT_LEDGER_VERIFICATION_V1','native_QPs_run_by_verifier':0,
        'physics_steps_by_verifier':0,'checks':checks,'all_checks_pass':all(checks.values()),
        'native_status_counts':dict(Counter(r['status'] for r in returns)),
        'budgeted_status_counts':dict(Counter(r['status'] for r in bounded)),
        'source_changes':changed,'shard_checks':branch_rows,'model_assets':assets,'files_at_verification':files,
        'DEV_comparison_diagnostic_persistence':'PARTIAL_2_OF_12_AFTER_RECORDED_DEV_EXCEPTION',
        'verification_does_not_fill_missing_diagnostics':True,'old_worktree_clean_claim':False}
    target.write_text(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps({'all_checks_pass':value['all_checks_pass'],'checks':checks,'QP_calls':len(starts),'saved_integration_steps':step_total}))
    return value


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('out');verify(p.parse_args().out)
