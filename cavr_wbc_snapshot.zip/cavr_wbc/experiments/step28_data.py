"""Read-only STEP28 DEV inputs and independently loaded ACTUAL labels.

No simulator or optimizer is invoked here.  Old first commands are extracted
from an explicit slot-zero/current-input allowlist before any dense trajectory
is decoded for labels.  A saved valid-command witness is not a fabricated new
qdd/contact-force solution: its provenance is retained in every first record.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
from pathlib import Path

import numpy as np

from cavr_wbc.experiments.step26_features_storage import (
    BANK_VERSION, _compiled_mapping, _json_restore, _vector, load_bank,
)
from cavr_wbc.control.step27_structured_margin import extract_features


VERSION = "STEP28_READ_ONLY_CURRENT_DEV_INPUTS_V1"
SOURCE26_REL = "artifacts/step26_fast_margin_20261008/step26-fast-margin-20261008-01"
SOURCE27_REL = "artifacts/step27_structured_margin_20261008/step27-structured-margin-20261008-01"
TRAIN27 = frozenset(("T27_P050", "T27_N070"))
CAL27 = frozenset(("T27_N050", "T27_P070"))


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def source_split(source_step, episode_id):
    """Episode-level frozen split; no random adjacent-tick reassignment."""
    if source_step == 26:
        return "TRAIN"
    if source_step != 27:
        raise ValueError("only STEP26/STEP27 source DEV is authorized")
    if episode_id in TRAIN27:
        return "TRAIN"
    if episode_id in CAL27:
        return "CAL"
    raise ValueError("STEP27 source episode outside the frozen STEP28 split")


def first_slot_header(path):
    """Decode only saved slot-zero command/status witnesses, not numeric rows.

    The archive JSON header contains later bookkeeping as part of its format;
    none of that is returned or used as a current prediction input.  Numeric
    columns (including states after 20 ms) are never read by this helper.
    """
    with np.load(Path(path), allow_pickle=False) as archive:
        document = json.loads(archive["metadata_json_utf8"].tobytes().decode("utf-8"))
    if document.get("schema") != BANK_VERSION:
        raise ValueError("unsupported source numeric bank schema")
    header = _json_restore(document["header"])
    controls = header.get("controls", [])
    control = deepcopy(controls[0]) if controls and controls[0].get("slot") == 0 else None
    ledger = next((deepcopy(row) for row in header.get("solver_ledger", [])
                   if row.get("slot", 0) == 0), None)
    return {"control": control, "solver_slot0": ledger,
            "branch_id": header.get("branch_id"), "backup_id": header.get("backup_id"),
            "current_feature_reads_future_rows": False}


def _status_witness(row, interface, raw, ledger=None):
    candidates = [("saved_control", row.get("solver_status_val")),
                  ("capacity_interface", interface.get("solver_status_val")),
                  ("saved_raw_solver", raw.get("status_val"))]
    if ledger is not None:
        candidates.append(("original_slot0_solver_ledger", ledger.get("status_val")))
    known = [(where, value) for where, value in candidates if value is not None]
    if not known:
        return None, [], "MISSING_EXACT_SOLVED_STATUS_WITNESS"
    if any(isinstance(value, (bool, np.bool_)) for _, value in known):
        return None, known, "BOOLEAN_SOLVER_STATUS_NOT_EXACT_SOLVED"
    if any(value != known[0][1] for _, value in known):
        return None, known, "CONFLICTING_SLOT0_SOLVER_STATUS_WITNESSES"
    status = known[0][1]
    return status, known, None if status == 1 else "SOURCE_FIRST_SOLVER_NOT_EXACT_SOLVED"


def _unavailable(mode, reason, *, evidence_source=None, status=None, branch_id=None):
    return {"mode": mode, "available": False, "command_valid": False,
            "tau_raw": None, "tau_sent": None, "solver_status_val": status,
            "integral_record": None, "first_capacity_event": None,
            "evidence_source": evidence_source, "branch_id": branch_id,
            "unavailable_reason": reason, "new_solver_called": False,
            "raw_variables_not_reconstructed": True, "future_labels_used": False}


def _recover_first(mode, row, context, mapping, *, evidence_source, ledger=None,
                   branch_id=None, nominal=None):
    if row is None:
        return _unavailable(mode, "SOURCE_FIRST_CONTROL_MISSING", evidence_source=evidence_source,
                            branch_id=branch_id)
    interface = row.get("capacity_interface") or {}
    raw = row.get("solver_raw_result", row.get("raw_solver_result", {})) or {}
    status, witnesses, status_error = _status_witness(row, interface, raw, ledger)
    saved_valid = row.get("valid_command", row.get("command_valid")) is True
    if not saved_valid:
        return _unavailable(mode, "SOURCE_FIRST_COMMAND_UNAVAILABLE", evidence_source=evidence_source,
                            status=status, branch_id=branch_id)
    if status_error:
        return _unavailable(mode, status_error, evidence_source=evidence_source,
                            status=status, branch_id=branch_id)
    try:
        health = _vector(context["health_vector"], "source full health", 12)
        recorded_health = row.get("health_vector", interface.get("health_vector"))
        if recorded_health is None or not np.array_equal(health, _vector(recorded_health, "saved first health", 12)):
            raise ValueError("saved first command/context health identity mismatch")
        entries = _compiled_mapping(mapping)
        limits = []
        for entry in entries:
            limit = entry.get("healthy_limit_nm", entry.get("healthy_torque_limit_nm"))
            if limit is None and entry.get("ctrl_range") is not None:
                interval = _vector(entry["ctrl_range"], "compiled torque ctrl_range", 2)
                if interval[0] != -interval[1] or interval[1] < 0.:
                    raise ValueError("compiled healthy torque interval is not symmetric")
                limit = float(interval[1])
            limits.append(limit)
        if any(x is None for x in limits):
            limits = interface.get("healthy_torque_limits_nm")
        limits = _vector(limits, "compiled healthy capacities", 12)
        if np.any((health < 0.) | (health > 1.)) or np.any(limits < 0.):
            raise ValueError("invalid source full health/capacity")
        capacities = health*limits
        tau_raw = _vector(row.get("tau_raw", interface.get("tau_raw", raw.get("tau"))), "saved raw first tau", 12)
        tau_sent = _vector(row.get("tau_sent", row.get("tau_cmd", interface.get("tau_sent"))), "saved sent first tau", 12)
        if not np.array_equal(tau_sent, np.clip(tau_raw, -capacities, capacities)):
            raise ValueError("saved sent/raw command differs from unchanged capacity clip")
        recorded_capacity = interface.get("effective_capacity_nm")
        if recorded_capacity is not None and not np.array_equal(capacities, _vector(recorded_capacity, "saved first capacities", 12)):
            raise ValueError("saved first command effective capacity identity mismatch")
    except (TypeError, KeyError) as exc:
        return _unavailable(mode, "MISSING_SAVED_COMMAND_PROOF: "+str(exc),
                            evidence_source=evidence_source, status=status, branch_id=branch_id)
    except ValueError as exc:
        if "identity mismatch" in str(exc) or "differs from unchanged" in str(exc):
            raise
        return _unavailable(mode, "MISSING_OR_NONFINITE_SAVED_COMMAND: "+str(exc),
                            evidence_source=evidence_source, status=status, branch_id=branch_id)
    integral = row.get("integral_record", (row.get("response") or {}).get("integral_record"))
    if mode == "B":
        try:
            if integral is None:
                raise ValueError("no saved first backup integral event")
            used = _vector(integral["b_used"], "first backup b_used", 6)
            after = _vector(integral["b_after"], "first backup b_after", 6)
            if not np.array_equal(used, np.zeros(6)) or np.any(np.abs(after) > 1.):
                raise ValueError("saved first backup did not use frozen b0/limit")
        except (ValueError, KeyError, TypeError) as exc:
            return _unavailable(mode, "MISSING_BACKUP_PID_FIRST_EVENT: "+str(exc),
                                evidence_source=evidence_source, status=status, branch_id=branch_id)
    event = bool(np.any((capacities <= 0.) | (np.abs(tau_sent) >= .99*capacities)))
    return {"mode": mode, "available": True, "command_valid": True,
            "tau_raw": tau_raw.tolist(), "tau_sent": tau_sent.tolist(),
            "solver_status_val": int(status), "health_vector": health.tolist(),
            "effective_capacity_nm": capacities.tolist(), "integral_record": deepcopy(integral),
            "first_capacity_event": event, "evidence_source": evidence_source,
            "branch_id": branch_id, "unavailable_reason": None, "new_solver_called": False,
            "saved_valid_command_witness": True, "status_witnesses": witnesses,
            "raw_variables_not_reconstructed": True, "future_labels_used": False,
            "proof_semantics": "original exact-Solved status + saved validation witness + finite raw/sent + identical clip/full health; no fabricated raw qdd/lambda",
            "capacity_interface": {"command_valid": True, "solver_status_val": int(status),
                "tau_raw": tau_raw.tolist(), "tau_sent": tau_sent.tolist(),
                "health_vector": health.tolist(), "healthy_torque_limits_nm": limits.tolist(),
                "effective_capacity_nm": capacities.tolist()}}


def current_firsts(context, nominal, mapping, first_b, *, current_path=None, bank_path=None):
    """Recover C from CURRENT_INPUT and B from ACTUAL_B slot zero only."""
    c_row = dict(nominal)
    c_row["valid_command"] = nominal.get("command_valid")
    if "integral_record" not in c_row:
        c_row["integral_record"] = (nominal.get("response") or {}).get("integral_record")
    c_first = _recover_first("C", c_row, context, mapping,
        evidence_source={"kind": "CURRENT_INPUT_NOMINAL", "path": str(current_path) if current_path else None})
    b_header = first_b or {}
    b_first = _recover_first("B", b_header.get("control"), context, mapping,
        evidence_source={"kind": "SAVED_ACTUAL_B_FIRST_CONTROL_AND_ORIGINAL_SOLVER_STATUS", "path": str(bank_path) if bank_path else None},
        ledger=b_header.get("solver_slot0"), branch_id=b_header.get("branch_id"))
    return {"C": c_first, "B": b_first}


def missing_label(reason):
    return {"complete": False, "D": None, "T": None, "terminal_terms": None,
            "original_physical": False, "original_physical_safe": False,
            "original_terminal": False, "terminal_pass": False,
            "command_valid_all": False, "valid": False, "reason": reason,
            "trajectory_id": None, "original_failure": None}


def _identity(context):
    payload = {key: context.get(key) for key in (
        "state", "health_vector", "nominal_d_m", "nominal_q_init", "nominal_b_used",
        "backup_anchor_q_init", "faulted_actuator_index", "faulted_actuator_name")}
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    return hashlib.sha256(encoded).hexdigest()


def load_sources(root, mapping, labeler=None, *, source26=None, source27=None):
    """Load 232 planned source contexts read-only; failed inputs remain records.

    Source labels and current inputs have separate extraction code.  Every
    unique ACTUAL archive is decoded once for its independent complete label;
    source horizon evidence never enters ``extract_features`` or first-command
    recovery.  Prefix propagation is deliberately deferred to the budgeted
    STEP28 native helper owned by the runner, not performed by this loader.
    """
    if labeler is None:
        from cavr_wbc.control.step28_physics_residual import labelsT_actual
        labeler = labelsT_actual
    root = Path(root).resolve()
    source_dirs = ((26, Path(source26).resolve() if source26 else root/SOURCE26_REL),
                   (27, Path(source27).resolve() if source27 else root/SOURCE27_REL))
    records = []; seen_identity = {}; seen_id = {}; trajectory_cache = {}
    for step, directory in source_dirs:
        registry = read_json(directory/"SPLIT_REGISTRY.json")
        for source in registry:
            episode = source["episode_id"]
            split = source_split(step, episode)
            cid = source["context_id"]
            bankdir = directory/source["bank_directory"]
            current_path = bankdir/"CURRENT_INPUT.json"
            current = read_json(current_path) if current_path.exists() else {"context": source["context"], "nominal": {}}
            context = current["context"]; nominal = current.get("nominal") or {}
            identity = _identity(context)
            if cid in seen_id and seen_id[cid] != identity:
                raise ValueError("same source context ID has different current-state identity")
            seen_id[cid] = identity
            if identity in seen_identity:
                old = seen_identity[identity]
                if old["split"] != split:
                    raise ValueError("same current-state context crosses frozen TRAIN/CAL episodes")
                old["source_alias_ids"].append(cid)
                continue
            first_b_path = bankdir/"B.npz"
            header = first_slot_header(first_b_path) if first_b_path.exists() else None
            firsts = current_firsts(context, nominal, mapping, header,
                                   current_path=current_path, bank_path=first_b_path)
            feature_error = None
            try:
                features = extract_features(context, nominal, mapping).tolist()
            except (ValueError, KeyError, TypeError, IndexError) as exc:
                features = None; feature_error = type(exc).__name__+": "+str(exc)
            # Labels are opened only after current-input allowlists are frozen.
            branch_labels = {}; paths = {"current": str(current_path)}
            for mode in ("C", "B"):
                path = bankdir/(mode+".npz"); paths[mode] = str(path)
                key = str(path.resolve())
                if not path.exists():
                    branch_labels[mode] = missing_label("SOURCE_ACTUAL_ARCHIVE_MISSING")
                else:
                    if key not in trajectory_cache:
                        trajectory_cache[key] = labeler(load_bank(path), context)
                    branch_labels[mode] = deepcopy(trajectory_cache[key])
            record = {"schema": VERSION, "id": cid, "context_id": cid, "split": split,
                "episode_id": episode, "source_step": step, "source_previous_split": source.get("split"),
                "all_source_data_role": "DEV", "source_alias_ids": [], "context": deepcopy(context),
                "nominal": nominal, "features16": features, "features": features,
                "feature_error": feature_error, "firsts": firsts, "labels": branch_labels,
                "paths": paths, "source_paths": paths, "source_current_identity_sha256": identity,
                "source_trajectory_ids": {mode: branch_labels[mode].get("trajectory_id") for mode in ("C", "B")},
                "snapshot_eligible": bool(source.get("snapshot_eligible", context.get("eligible"))),
                "current_candidate_valid": bool(nominal.get("command_valid")),
                "current_physical_pass": bool(nominal.get("current_physical_check", {}).get("pass")),
                "first_commands_frozen_before_actual_label_decode": True,
                "source_prefix_repropagation_required": True, "source_solver_replay": False}
            seen_identity[identity] = record; records.append(record)
    return records


def source_split_summary(records):
    return {"planned_source_contexts": 232, "unique_contexts": len(records),
        "TRAIN": sum(row["split"] == "TRAIN" for row in records),
        "CAL": sum(row["split"] == "CAL" for row in records),
        "source_STEP26": sum(row["source_step"] == 26 for row in records),
        "source_STEP27": sum(row["source_step"] == 27 for row in records),
        "finite_current_features16": sum(row["features16"] is not None for row in records),
        "available_first_C": sum(row["firsts"]["C"]["available"] for row in records),
        "available_first_B": sum(row["firsts"]["B"]["available"] for row in records),
        "source_QP_replays": 0, "source_physics_steps": 0,
        "all_source_data_role": "DEV", "split_is_full_episode": True}
