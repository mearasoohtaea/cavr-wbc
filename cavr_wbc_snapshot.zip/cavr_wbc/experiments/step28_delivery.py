"""STEP28 Git/source closure only; no experiment imports or numerical work."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parents[2]
PARENT='2bc9147b3bf746e07b09f35b1c90a218e5157d3a'
BRANCH='codex/step28-physics-residual-startup-20261008'
WHITESPACE='blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol'


def git(*args):
    return subprocess.check_output(['git',*args],cwd=ROOT,text=True,encoding='utf-8').strip()


def close(out):
    out=Path(out).resolve()
    files=sorted([*ROOT.glob('cavr_wbc/control/step28_*.py'),*ROOT.glob('cavr_wbc/experiments/step28_*.py'),
        *ROOT.glob('tests/test_step28_*.py'),*ROOT.glob('tools/step28_*.py'),*ROOT.glob('native_backend/step28_*.cpp')])
    snapshots=[]
    for source in files:
        rel=source.relative_to(ROOT);target=out/'SOURCE_FINAL_SNAPSHOT'/rel;target.parent.mkdir(parents=True,exist_ok=True)
        data=source.read_bytes();target.write_bytes(data)
        snapshots.append({'path':str(rel).replace('\\','/'),'sha256':hashlib.sha256(data).hexdigest()})
    paths=git('diff','--cached',PARENT,'--name-only').splitlines()
    diff=subprocess.run(['git','-c','core.whitespace='+WHITESPACE,'diff','--cached',PARENT,'--check'],cwd=ROOT,capture_output=True,text=True,encoding='utf-8')
    state={'parent':PARENT,'branch':BRANCH,'worktree':str(ROOT),'original_HEAD':git('rev-parse','HEAD'),
        'push':False,'reset_original_HEAD':False,'actual_new_code_tests_native':snapshots,'staged_paths_before_receipt':paths,
        'index_on_E':os.environ.get('GIT_INDEX_FILE'),'objects_on_E':os.environ.get('GIT_OBJECT_DIRECTORY'),
        'scoped_diff_check_exit':diff.returncode,'scoped_diff_check_stderr':diff.stderr[:2000],
        'original_worktree_clean_claim':False,'inherited_changes_not_staged':True,
        'verification_command':'python -B -X utf8 -m cavr_wbc.experiments.step28_verify <unique_out>',
        'tests_command':'python -B -X utf8 -m unittest discover -s tests -p test_step28_*.py -v',
        'numeric_command':'python -B -X utf8 -m cavr_wbc.experiments.step28_sprint step28-physics-residual-20261008-01 --dll <out>/native/step28_prefix.dll',
        'scope':'STEP28 new code/tests/native helper/new output only'}
    with (out/'DELIVERY_GIT_STATE.json').open('w',encoding='utf-8',newline='\n') as f:json.dump(state,f,sort_keys=True,indent=2);f.write('\n')


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('out');close(p.parse_args().out)
