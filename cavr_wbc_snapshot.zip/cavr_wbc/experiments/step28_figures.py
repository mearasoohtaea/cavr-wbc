"""Saved-only STEP28 points, method/ablation coverage and true ready latency."""
import argparse
import json
from pathlib import Path
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from PIL import Image
sys.path.insert(0,'C:/Users/ZhuanZ（无密码）/.codex/skills/scipilot-figure/scripts')
from setup_style import setup_style
from profile_data import profile_data
from visual_qa import render_preview,audit_layout
from layout_tools import finalize_figure,add_panel_labels
from export_figure import export_figure


def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def write(p,v):
    def clean(x):
        if isinstance(x,np.ndarray):return clean(x.tolist())
        if isinstance(x,np.generic):return clean(x.item())
        if isinstance(x,float) and not np.isfinite(x):return None
        if isinstance(x,dict):return {str(k):clean(y) for k,y in x.items()}
        if isinstance(x,(tuple,list)):return [clean(y) for y in x]
        return x
    with Path(p).open('w',encoding='utf-8',newline='\n') as f:json.dump(clean(v),f,sort_keys=True,allow_nan=False);f.write('\n')


def figures(out,export=False):
    out=Path(out);fd=out/'figures';fd.mkdir(exist_ok=True)
    points=read(out/'MARGIN_POINTS.json');queries=read(out/'EVALUATION_QUERIES.json')
    ready=read(out/'FULL_READY_TIMING.json');fresh=read(out/'FRESH_RESULTS.json');startup=read(out/'STARTUP_RESULT.json')
    flat=[{'context_id':p['context_id'],'group':p['group'],'branch':p['branch'],
           'D_m':p['actual'].get('D'),'U_D_m':p['prediction'].get('U_D'),
           'T_max':max(p['actual']['T']) if p['actual'].get('T') is not None else None,
           'U_T_max':max(p['prediction']['U_T']) if p['prediction'].get('U_T') is not None else None,
           'physical_terminal_failure':not p['actual'].get('valid')} for p in points]
    data=pd.DataFrame(flat);write(fd/'DATA_PROFILE.json',profile_data(data,group_cols=['group','branch']));data.to_csv(fd/'POINT_DATA.csv',index=False)
    setup_style(journal='ieee',lang='en',use_sciplots=False)
    plt.rcParams.update({'font.size':8,'axes.labelsize':9,'xtick.labelsize':8,'ytick.labelsize':8,'legend.fontsize':8,'savefig.bbox':None})
    palette={'ID':'#0072B2','CHALLENGE':'#D55E00'};markers={'ID':'o','CHALLENGE':'^'}
    figs=[];fig,axes=plt.subplots(2,2,figsize=(7.16,5.4))
    pairs=[r for r in flat if r['D_m'] is not None and r['U_D_m'] is not None]
    dmax=max([max(r['D_m'],r['U_D_m'])*1000 for r in pairs]+[1.])*1.05
    tmax=max([max(r['T_max'],r['U_T_max']) for r in pairs]+[1.])*1.05
    for col,branch in enumerate(('C','B')):
        sub=[r for r in pairs if r['branch']==branch]
        for r in sub:
            for row,x,y in ((0,r['D_m']*1000,r['U_D_m']*1000),(1,r['T_max'],r['U_T_max'])):
                axes[row,col].scatter(x,y,s=17,marker=markers[r['group']],facecolors='none',edgecolors=palette[r['group']],linewidths=.7)
                if r['physical_terminal_failure']:axes[row,col].scatter(x,y,s=12,marker='x',c='black',linewidths=.6)
        axes[0,col].set(title=f'{branch}: displacement ({len(sub)}/120 complete)',xlabel='Observed D (mm)',ylabel='Calibrated U_D (mm)',xlim=(0,dmax),ylim=(0,dmax))
        axes[0,col].plot([0,dmax],[0,dmax],ls='--',color='grey',lw=.7)
        axes[1,col].set(title=f'{branch}: terminal components (display max)',xlabel='Observed max(T_j)',ylabel='Calibrated max(U_Tj)',xlim=(0,tmax),ylim=(0,tmax))
        axes[1,col].plot([0,tmax],[0,tmax],ls='--',color='grey',lw=.7)
        axes[1,col].axhline(1,color='grey',ls=':',lw=.7);axes[1,col].axvline(1,color='grey',ls=':',lw=.7)
    fig.legend(handles=[Line2D([],[],marker=markers[g],color=c,linestyle='none',markerfacecolor='none',label=g)for g,c in palette.items()]+
        [Line2D([],[],marker='x',color='black',linestyle='none',label='Physical or terminal failure')],loc='outside lower center',ncol=3,frameon=False)
    figs.append(('STEP28_margin_points',fig))
    fig,axes=plt.subplots(2,2,figsize=(7.16,5.8))
    method_names=('M0_CURRENT','M1_PREFIX20','M4_STEP27','DIRECT_REFIT','M5_PHYSICS_RESIDUAL','ORACLE')
    labels=('M0','M1','M4 old','Direct','M5 residual','Oracle');colors=('#999999','#E69F00','#CC79A7','#56B4E9','#0072B2','#000000');marks=('o','s','^','v','D','x')
    gaps=[.001,.002,.004,.008,.016,.032]
    for col,group in enumerate(('ID','CHALLENGE')):
        for name,label,color,mark in zip(method_names,labels,colors,marks):
            vals=[]
            for gap in gaps:
                q=[r for r in queries if r['method']==name and r['group']==group and r['gap_m']==gap]
                oracle=sum(r['oracle_safe_available'] for r in q)
                vals.append(100*sum(r['safe_accepted'] for r in q)/oracle if oracle else np.nan)
            axes[0,col].plot(np.asarray(gaps)*1000,vals,color=color,marker=mark,ms=3,lw=.8,label=label)
        axes[0,col].set(title=group,xlabel='Local gap (mm)',ylabel='Oracle-safe coverage (%)',ylim=(-3,103))
        axes[0,col].set_xscale('log',base=2);axes[0,col].set_xticks(np.asarray(gaps)*1000,labels=['1','2','4','8','16','32'])
    abl=('M5_PHYSICS_RESIDUAL','DIRECT_REFIT','M5_NO_PRIOR','M5_NO_CAL','M5_NO_SUPPORT')
    for j,name in enumerate(abl):
        for group,offset in (('ID',-.1),('CHALLENGE',.1)):
            number=sum(r['unsafe_accepted'] for r in queries if r['group']==group and r['method']==name)
            axes[1,0].scatter(j+offset,number,s=25,marker=markers[group],color=palette[group])
    axes[1,0].set(xticks=range(5),xticklabels=['M5','Direct','No prior','No CAL','No k5'],ylabel='Error accepts (query count)',ylim=(-3,None))
    axes[1,0].tick_params(axis='x',rotation=25)
    axes[1,0].set_title('Protected model vs saved-only ablations')
    for index,group in enumerate(('ID','CHALLENGE')):
        subset=[r for r in ready if r['group']==group and 'command_ready_ms' in r]
        for j,r in enumerate(subset):
            offset=(((j*17)%101)/100-.5)*.35
            axes[1,1].scatter(index+offset,r['command_ready_ms'],s=13,marker=markers[group] if r['command_valid'] else 'x',
                color=palette[group],alpha=.7,linewidths=.6)
    tick=[v for r in fresh for v in r.get('tick_latency_ms',[])]
    for j,v in enumerate(tick):axes[1,1].scatter(2+(((j*13)%101)/100-.5)*.35,v,s=6,marker='.',color='#000000',alpha=.4)
    axes[1,1].axhline(20,color='black',ls='--',lw=.8)
    axes[1,1].set(xticks=[0,1,2],xticklabels=['ID ready','Challenge\nready','Fresh\nfeedback ticks'],ylabel='Wall time (ms)',ylim=(0,None))
    axes[1,1].set_title(f"Startup {startup['total_startup_wall_ms']:.1f} ms (separate)")
    fig.legend(*axes[0,0].get_legend_handles_labels(),loc='outside lower center',ncol=6,frameon=False)
    figs.append(('STEP28_coverage_latency',fig));qa=[]
    for name,fig in figs:
        finalize_figure(fig);add_panel_labels(fig,style='ieee');render_preview(fig,str(fd/(name+'_preview.png')),dpi=150)
        qa.append({'figure':name,'layout':audit_layout(fig),'missing_not_zero_filled':True})
        Image.open(fd/(name+'_preview.png')).convert('L').save(fd/(name+'_preview_grayscale.png'))
        if export:
            export_figure(fig,str(fd/name),formats=['pdf','png'],size_inches=fig.get_size_inches(),dpi=600,grayscale_preview=False,tight=False)
            Image.open(fd/(name+'.png')).convert('L').save(fd/(name+'_grayscale.png'),dpi=(600,600))
        plt.close(fig)
    write(fd/'LAYOUT_QA.json',qa)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('out');p.add_argument('--export',action='store_true');a=p.parse_args();figures(a.out,a.export)
