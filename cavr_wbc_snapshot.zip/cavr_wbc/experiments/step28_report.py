"""Describe saved STEP28 evidence; no simulator, optimizer or model fitting."""
import argparse
from collections import Counter
import json
from pathlib import Path
import numpy as np
from cavr_wbc.experiments.step21_report import csv_write


def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def write(p,v):
    with Path(p).open('w',encoding='utf-8',newline='\n') as f:json.dump(v,f,sort_keys=True,indent=2,allow_nan=False);f.write('\n')
def stats(values):
    v=[float(x) for x in values if x is not None and isinstance(x,(float,int))]
    return {k:float(np.percentile(v,p)) if v else None for k,p in (('p50',50),('p95',95),('p99',99))}|{'max':max(v) if v else None,'n':len(v)}


def summary(rows):
    oracle=sum(bool(r['oracle_safe_available']) for r in rows);safe=sum(bool(r['safe_accepted']) for r in rows)
    c=[r for r in rows if r['safe_accepted'] and r['choice']=='C']
    damaged=[r for r in c if r['faulted_health']<1.]
    return {'queries':len(rows),'accepted':sum(bool(r['accepted']) for r in rows),'safe_accepted':safe,
        'unsafe_accepted':sum(bool(r['unsafe_accepted']) for r in rows),'ABSTAIN':sum(not r['accepted'] for r in rows),
        'oracle_safe_queries':oracle,'oracle_safe_coverage':safe/oracle if oracle else None,
        'safe_C_retained':len(c),'safe_C_source_snapshots':len({r['snapshot_id'] for r in c}),
        'safe_C_episodes':sorted({r['episode'] for r in c}),'damaged_safe_C_queries':len(damaged),
        'safe_C_progress20_mean_m':float(np.mean([r['progress20_m'] for r in c])) if c else None,
        **{k:sum(bool(r[k]) for r in rows) for k in ('physical_error','local_error','terminal_error','numerical_incomplete')}}


def report(out):
    out=Path(out);m=read(out/'STEP28_PROTOCOL_AND_MANIFEST.json');f=read(out/'RUN_FINISHED.json')
    registry=read(out/'SPLIT_REGISTRY.json') if (out/'SPLIT_REGISTRY.json').exists() else []
    rows=read(out/'EVALUATION_QUERIES.json') if (out/'EVALUATION_QUERIES.json').exists() else []
    methods={group:{name:summary([r for r in rows if r['group']==group and r['method']==name])
        for name in sorted({r['method'] for r in rows})} for group in ('ID','CHALLENGE')}
    groups=[]
    for field in ('episode','health_kind','direction','faulted_actuator_name'):
        for value in sorted({str(r[field]) for r in rows}):
            for name in sorted({r['method'] for r in rows}):
                sub=[r for r in rows if str(r[field])==value and r['method']==name]
                groups.append({'group_field':field,'group_value':value,'method':name,**summary(sub)})
    csv_write(out/'GROUP_RESULTS.csv',groups)
    points=read(out/'MARGIN_POINTS.json') if (out/'MARGIN_POINTS.json').exists() else []
    gates=Counter();errors=[];teacher=Counter()
    for p in points:
        actual=p['actual'];pred=p['prediction'];mode=p['branch'];group=p['group']
        teacher[group+':'+mode+':complete']+=bool(actual['complete'])
        teacher[group+':'+mode+':physical_failure']+=bool(actual.get('original_failure'))
        teacher[group+':'+mode+':terminal_pass']+=bool(actual.get('terminal_pass'))
        for key in ('prefix_available_gate','prefix_physical_gate','support_gate','distance_gate','calibration_gate','terminal_gate','local_gate'):
            gates[group+':'+mode+':'+key+':reject_at8mm']+=not pred.get(key,False)
    for group in ('ID','CHALLENGE'):
        for mode in ('C','B'):
            ps=[p for p in points if p['group']==group and p['branch']==mode and p['actual']['complete'] and p['prediction'].get('D_hat') is not None]
            errors.append({'group':group,'branch':mode,'pairs':len(ps),
                'D_MAE_m':float(np.mean([abs(p['actual']['D']-p['prediction']['D_hat']) for p in ps])) if ps else None,
                'T_MAE':[float(np.mean([abs(p['actual']['T'][j]-p['prediction']['T_hat'][j]) for p in ps])) for j in range(5)] if ps else None,
                'D_above_U_D':sum(p['actual']['D']>p['prediction']['U_D'] for p in ps),
                'T_above_U_T':[sum(p['actual']['T'][j]>p['prediction']['U_T'][j] for p in ps) for j in range(5)]})
    ready=read(out/'FULL_READY_TIMING.json') if (out/'FULL_READY_TIMING.json').exists() else []
    valid=[r for r in ready if r.get('command_valid')];fresh=read(out/'FRESH_RESULTS.json') if (out/'FRESH_RESULTS.json').exists() else []
    infer=read(out/'INFERENCE_TIMING.json') if (out/'INFERENCE_TIMING.json').exists() else {}
    science=methods['ID'].get('M5_PHYSICS_RESIDUAL',{})
    supported=bool(science.get('accepted',0)>0 and science.get('unsafe_accepted',1)==0 and
        (science.get('oracle_safe_coverage') or 0)>=.2 and science.get('safe_C_source_snapshots',0)>=4 and
        len(science.get('safe_C_episodes',[]))>=2 and science.get('damaged_safe_C_queries',0)>0)
    eng={'planned':120,'recorded':len(ready),'valid_commands':len(valid),'unavailable':len(ready)-len(valid),
        'valid_deadline_misses':sum(bool(r.get('deadline_miss')) for r in valid),
        'all_deadline_misses':sum(bool(r.get('deadline_miss')) for r in ready),
        'recognized':sum(bool(r.get('recognized')) for r in ready),
        'best_effort':sum(bool(r.get('best_effort_B')) for r in ready),
        'runtime_setups':sum(r.get('runtime_setup_events',0) for r in ready),
        'all_ready_ms':stats([r.get('command_ready_ms') for r in ready]),
        'valid_ready_ms':stats([r.get('command_ready_ms') for r in valid]),
        'first_after_ready':next((r for r in ready if r.get('first_after_startup_ready')),None),
        'actual_sent_reference_oracle_supported':sum(bool(r.get('recognized') and r.get('source_reference_oracle_safe')) for r in ready),
        'reference_support_not_actual_bounded_label':True,
        'status_nominal':dict(Counter(r.get('nominal_status') for r in ready)),
        'status_backup':dict(Counter(r.get('backup_status') for r in ready))}
    fr={'planned':8,'recorded':len(fresh),'statuses':dict(Counter(r['status'] for r in fresh)),
        'recognized':sum(bool(r.get('recognized')) for r in fresh),'complete':sum(r['status']=='COMPLETE' for r in fresh),
        'best_effort':sum(bool(r.get('best_effort')) for r in fresh),
        'first_mismatches':sum(not r['first_command_matches'] for r in fresh if 'first_command_matches' in r),
        'complete_all_tick20ms':sum(r['status']=='COMPLETE' and r.get('all_tick_20ms',False) for r in fresh),
        'recognized_actual_safe':sum(bool(r.get('recognized') and r.get('actual',{}).get('valid')) for r in fresh),
        'tick_ms':stats([v for r in fresh for v in r.get('tick_latency_ms',[])])}
    status='STARTUP_READY_USABLE' if len(valid)>0 and not eng['valid_deadline_misses'] and len(valid)>eng['unavailable'] else 'DEADLINE_MISS' if eng['valid_deadline_misses'] else 'COMMAND_UNAVAILABLE'
    selected=read(out/'models/MODEL_FREEZE.json') if (out/'models/MODEL_FREEZE.json').exists() else {}
    result={'run_id':m['run_id'],'numerical_status':f['status'],'recorded_contexts':len(registry),
        'qualified':sum(r['snapshot_eligible'] for r in registry),'planned':120,
        'SCIENCE_STATUS':'PHYSICS_RESIDUAL_SUPPORTED' if supported else 'NOT_ESTABLISHED',
        'ENGINEERING_STATUS':status,'methods':methods,'teacher':dict(teacher),'gate_counts':dict(gates),
        'component_errors':errors,'model_selection':selected,'engineering':eng,'fresh_feedback':fr,
        'inference':{k:v for k,v in infer.items() if k!='all_ms'},'startup':read(out/'STARTUP_RESULT.json'),
        'budget':f['budget'],'no_old_solver_replay':True,'post_new_test_tuning':False,'E3_RL_hardware':False}
    paired={}
    for r in rows:paired.setdefault((r['context_id'],r['gap_m']),{})[r['method']]=r['choice']
    identical=sum(v.get('M5_PHYSICS_RESIDUAL')==v.get('DIRECT_REFIT') for v in paired.values())
    result['prior_extra_benefit']={'paired_queries':len(paired),'identical_residual_direct_choices':identical,
        'status':'NOT_ESTABLISHED' if identical==len(paired) else 'DECISION_DIFFERENCE_OBSERVED_NOT_CAUSAL_PROOF',
        'distribution_scale_prefix_and_target_changes_not_attributed_to_prior':True}
    result['engineering_provenance_limit']={'ready_rows_keep_status_sent_torque_gate_predictions_and_latency':True,
        'full_raw_QP_and_native_prefix_arrays_saved_for_teacher_and_fresh_not_each_120_timing_row':True,
        'timing_rows_not_claimed_as_120_actual_bounded_trajectories':True}
    write(out/'STEP28_RESULT.json',result)
    lines=['# STEP28：物理先验残差预测与启动准备','', '## Material Passport','',
        '- 日期：2026-10-08（Asia/Seoul）；Origin Skill：experiment-agent；Mode：run；Verification Status：ANALYZED。',
        f"- Run ID：{m['run_id']}；源提交：{m['source_commit']}。",'',
        f"结论：**{result['SCIENCE_STATUS']}**；启动就绪条件下工程状态 **{status}**。",'',
        f"记录 {len(registry)}/120 个固定上下文，资格合格 {result['qualified']}。科学teacher与6ms有界执行分开，未把旧轨迹或reference teacher当作有界执行的实际标签。",'',
        '## Prior、残差与直接预测消融','',
        '原16当前特征加各分支6项原生prefix特征。20ms prefix从独立预分配副本积分10步，包含初态共11状态，不新求解、不改实际状态或servo记忆；原物理检查返回真实数值与bitmask。全部prefix积分计入PREFIX_PREDICTION。',
        '低阶prior从prefix末状态推进剩余49槽，使用既有192/24/512 PID、20ms步长和±1积分限，先用b、后更新；持续允许/冻结积分两种响应各取较大D/T。C后续backup从b0开始，B恢复真实首槽b_after。prior不是物理上界；完整终端失败参与回归，未完成D/T保持缺失。',
        'TRAIN为STEP26全部120，加STEP27 P050/N070的56个上下文；CAL为STEP27 N050/P070的56个。全部旧数据只作DEV、按episode划分去重。各分支22维尺度=max(TRAIN_std,冻结physical_floor)，均值只读TRAIN；旧首条已完成QP仅用于重新传播prefix，不重跑solver或1s轨迹。',
        f"四配置为线性/二次 × 残差/直接预测；主模型 {selected.get('selected_configuration_id')}，直接消融 {selected.get('selected_direct_configuration_id')}。实际多输出分支fit {selected.get('actual_branch_multioutput_estimator_fit_calls')} 次、等价标量输出回归 {selected.get('scalar_output_regression_equivalents')} 个，不隐藏拟合次数。残差与匹配直接模型在 {identical}/{len(paired)} 个查询上选择相同，ID和CHALLENGE接受/错误/任务指标相同；物理prior的额外决策收益未建立，不能把新分布、尺度下限、prefix和分量化输出的整体改进归因于prior。",
        '部署仅数组运算。D投影不低于0和prefix最大方向位移，T逐项非负；直接预测使用相同投影。k5邻居包含有限失败和不完整记录，支持门要求邻居完整且原物理合格；距离门仍为3倍CAL最大最近TRAIN距离，倍率不变。UD/UT是经验储备，不称置信界或证书。',
        '保存数据消融：NO_PRIOR仅去掉冻结残差模型的prior加项，不重训；DIRECT_REFIT是公平的匹配family直接模型。NO_CAL去掉经验max_CAL项、保留1mm/0.05固定储备；NO_SUPPORT只去掉k5邻居物理/完整门，保留距离门。无保护消融不部署。', '',
        '## 固定ID与分布挑战结果','',
        '六条stance参考任务为±55/±65mm域内、±60mm挑战，四快照及healthy/thigh/calf .30/.15共120上下文。recipe只是标识，不算随机独立重复，不称行走。ID80、CHALLENGE40按冻结清单全部保留，不把挑战自动判为OOD。', '',
        '| 组 | 方法 | 安全接受 | 错误接受 | oracle覆盖 | 安全C | 源快照 | ABSTAIN |',
        '|---|---|---:|---:|---:|---:|---:|---:|']
    for group,data in methods.items():
        for method,s in data.items():
            cov=f"{100*s['oracle_safe_coverage']:.2f}%" if s['oracle_safe_coverage'] is not None else '缺失'
            lines.append(f"| {group} | {method} | {s['safe_accepted']} | {s['unsafe_accepted']} | {cov} | {s['safe_C_retained']} | {s['safe_C_source_snapshots']} | {s['ABSTAIN']} |")
    lines += ['',f"ID主目标明细：{science}。资格/命令不可用项保留在计划分母；错误按原物理、local、terminal、数值未完成分别统计，可能重叠。T五分量误差和逐层拒收见STEP28_RESULT.json，分episode/方向/能力通道结果见GROUP_RESULTS.csv。相同bank的多gap不是独立实验。",'',
        '## 启动准备后的真实完整出令','',
        '启动一次加载模型和native DLL，创建nominal/backup、servo、当前和两个prefix数据缓冲；固定健康home priming的QP也计预算。固定CSC保留所有潜在零项，运行期只更新数值；发生setup必须计时记录。依据[OSQP Python接口](https://osqp.org/docs/interfaces/python.html)与[time_limit设置](https://osqp.org/docs/interfaces/solver_settings.html)，保留1e-7容差、20000max_iter、polishing与严格Solved有限变量门。6ms solver限不保证整个进程6ms返回。',
        f"Startup总耗时 {result['startup'].get('total_startup_wall_ms')} ms；首次准备后命令见engineering.first_after_ready，不把启动阶段当20ms决策。NOT_READY不算通过。",
        f"工程计划120：有效 {eng['valid_commands']}，不可用 {eng['unavailable']}；有效命令超20ms {eng['valid_deadline_misses']}，全部超时 {eng['all_deadline_misses']}，runtime setup {eng['runtime_setups']}。全体耗时 {eng['all_ready_ms']}；有效耗时 {eng['valid_ready_ms']}。两个prefix、动态QP、prior/数组推断及选择均在完整计时内。",
        '120个工程计时行保留了状态、发送向量、门控/邻居预测和时延，但没有逐行保存完整raw QP变量和两条prefix numeric arrays；这些完整初态QP/prefix证据保存在teacher CURRENT_INPUT，实际bounded执行的raw/sent/applied保存在固定fresh轨迹。该计时级明细缺口不能用reference命令替代，也没有新增求解补齐；不把120个计时输入说成120条bounded实际轨迹。',
        f"纯模型推断组件 {result['inference']}。科学reference认可覆盖与有界真实发送的认可数 {eng['recognized']} 分开；reference oracle支持仅是离线匹配，不冒充bounded实际标签。",'',
        f"固定8个fresh反馈结果：{fr}。资格失败/ABSTAIN不换点，best-effort不计认可；每tick采用同一6ms限，检查501状态、首条命令一致及全tick实际耗时。单次筛选后执行feedback backup，不宣称持续在线shield、硬件或任意重启期间恢复已验证。",'',
        '## 预算与交付','',f"预算：{f['budget']}。所有真实QP/actual/reference/prefix步骤与失败保留，START/RETURN在内存缓冲、逐例立即持久化。未知返回及未完成native步预留明确记录，不删除计数换时延。",
        '必要mock测试见TEST_RESULTS.json；一次最终文件/身份核验见FINAL_FILE_VERIFICATION.json；原历史文件未修改，STEP27丢失明细没有补跑。报告中的未建立结果不转写为PASS；本轮按固定批次结束，没有第二确认批次。',
        '下一项最有价值实验应由结果中真实拒收/错误分量确定，在新授权下预声明新TRAIN/CAL与新验证；不根据本轮TEST调参，不拓展E3、RL或硬件。', '',
        '```ini','AUTHORIZE_STEP28_PHYSICS_RESIDUAL_AND_STARTUP_READY = TRUE',f"NUMERICAL_STATUS = {f['status']}",
        f"SCIENCE_STATUS = {result['SCIENCE_STATUS']}",f"ENGINEERING_STATUS = {status}",
        f"PRIOR_EXTRA_BENEFIT = {result['prior_extra_benefit']['status']}",
        'MAX_NEW_QP_CALLS = 16000','MAX_NEW_PHYSICS_STEPS = 160000','MAX_NUMERICAL_WALL_HOURS = 2',
        'MAX_FIXED_MODEL_CONFIGURATIONS = 4','MAX_DEV_CONTEXT_RECOMPUTATIONS = 5','PLANNED_NEW_CONTEXTS = 120',
        'POST_NEW_TEST_TUNING = FALSE','SOLVER_TIME_LIMIT_S_PER_CALL = 0.006','DEADLINE_MS = 20',
        'BACKUP_HORIZON_S = 1','DENSE_PHYSICS_DT_S = 0.002','PHYSICAL_AND_TERMINAL_BOUNDS_UNCHANGED = TRUE',
        'HISTORICAL_RESULTS_UNCHANGED = TRUE','LOST_STEP27_DEV_REPLAY = FALSE','E3_RL_HARDWARE = NOT_AUTHORIZED','```','']
    with (out/'STEP28_REPORT.md').open('w',encoding='utf-8',newline='\n') as stream:stream.write('\n'.join(lines))
    with (out/'STEP28_RESEARCH_HANDOFF.md').open('w',encoding='utf-8',newline='\n') as stream:
        stream.write('\n'.join(['# STEP28研究交接','',f"Run ID: {m['run_id']}",f"Science: {result['SCIENCE_STATUS']}",f"Engineering: {status}",'',
            'MODEL_FREEZE.json是冻结数值资产；DEV prefix和ACTUAL bank分别保存，不能用actual标签构造在线22特征。',
            'STEP28_RESULT.json记录ID/CHALLENGE、直接/残差和saved-only消融；FULL_READY_TIMING.json含全部一次fresh决策；FRESH_RESULTS.json才是bounded反馈实际证据。',
            'M5残差和匹配直接模型选择一致，不能宣称prior额外覆盖收益。挑战16个终端错误接受必须保留。120工程行缺完整raw/prefix数组，不借用teacher作替代，不补求解；后续新runner应在ready后逐行保存这些明细。',
            '所有已见数据后续均为DEV，新实验需新用户授权和新验证。保持20ms、6ms solver、1s及原物理/终端界。不重跑历史，不补STEP27明细，不进入E3。','']))
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('out');report(p.parse_args().out)
