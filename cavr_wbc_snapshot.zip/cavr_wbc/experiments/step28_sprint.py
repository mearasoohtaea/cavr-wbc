"""STEP28 one fixed source-DEV fit, native prefixes and startup-ready batch."""
import argparse
from copy import deepcopy
from datetime import datetime,timezone
import gc
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
from time import perf_counter
import traceback
import numpy as np
import mujoco
from cavr_wbc.experiments import step17_formal_panel as frozen
from cavr_wbc.experiments import step26_sim as oldsim
from cavr_wbc.experiments import step27_sim as sim
from cavr_wbc.experiments.step26_features_storage import save_bank
from cavr_wbc.experiments.step28_data import load_sources
from cavr_wbc.experiments.step28_budget import SprintBudget,SprintLimit
from cavr_wbc.control.step27_structured_margin import extract_features as features16,load_bundle as load27,decide as decide27
from cavr_wbc.control.step28_physics_residual import (
    prior,append_prefix_features,labelsT_actual,fit_fixed,decide,feature_specification,safe as truth)
from cavr_wbc.control.step28_startup_kernel import StartupKernel
from cavr_wbc.platforms.go2_mujoco import extract_actuator_audit
from cavr_wbc.experiments.step21_report import csv_write


ROOT=Path(__file__).resolve().parents[2]
SOURCE27=ROOT/'artifacts/step27_structured_margin_20261008/step27-structured-margin-20261008-01'
PROTOCOL=Path('E:/CAVR-WBC/experiment_handoff_20260921/NEXT_CODEX_INSTRUCTIONS_STEP28_PHYSICS_RESIDUAL_STARTUP_READY_20261008.md')
PARENT='2bc9147b3bf746e07b09f35b1c90a218e5157d3a'
GAPS=(.001,.002,.004,.008,.016,.032)
KINDS=('HEALTHY','THIGH_30','THIGH_15','CALF_30','CALF_15')
EPISODES=(('T28_P055',.055,.0015,.0015,20261173,'ID'),('T28_N055',-.055,.0015,.0015,20261173,'ID'),
    ('T28_P065',.065,-.0015,.0015,20261174,'ID'),('T28_N065',-.065,-.0015,.0015,20261174,'ID'),
    ('T28_P060_C',.060,.0045,.0045,20261175,'CHALLENGE'),('T28_N060_C',-.060,-.0045,.0045,20261175,'CHALLENGE'))


def encode(v):
    if isinstance(v,np.ndarray):return encode(v.tolist())
    if isinstance(v,np.generic):return encode(v.item())
    if isinstance(v,float) and not math.isfinite(v):return {'nonfinite':repr(v)}
    if isinstance(v,dict):return {str(k):encode(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [encode(x) for x in v]
    return v


def write(p,v):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(p.suffix+'.tmp')
    with tmp.open('w',encoding='utf-8',newline='\n') as f:f.write(json.dumps(encode(v),sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)+'\n')
    os.replace(tmp,p)


def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def freeze_value(v):return json.loads(json.dumps(encode(v),sort_keys=True,allow_nan=False))


def missing(reason):
    return {'complete':False,'D':None,'T':None,'original_physical_safe':False,'terminal_pass':False,
        'valid':False,'original_failure':None,'progress20_m':None,'reason':reason}


def make_context(snapshot,kind,mapping,ordinal,group):
    c=deepcopy(snapshot);side='FR' if c.get('direction',0)>0 else 'RR'
    cid=snapshot['snapshot_id']+'_'+kind;hv=[1.]*12;name='NONE';ix=None;health=1.
    if kind!='HEALTHY':
        joint,h=kind.split('_');name=side+'_'+joint.lower();ix=next(r['actuator_index'] for r in mapping if r['actuator_name']==name)
        health=int(h)/100.;hv[ix]=health
    c.update(context_id=cid,case_id=cid,backup_id='STEP28-'+cid,health_vector=hv,
        faulted_actuator_name=name,faulted_actuator_index=ix,faulted_health=health,health_kind=kind,
        ordinal=ordinal,group=group,split='FIXED_NEW_VALIDATION')
    return c


def first_record(response,mode):
    if mode=='C':
        resp=response['response'];ci=response['capacity_interface'];valid=response['command_valid'];status=response['solver_status_val']
    else:
        resp=response;ci=resp['capacity_interface'];valid=resp['valid_command'];status=resp['wbc']['status_val']
    return {'available':bool(valid),'command_valid':bool(valid),'tau_raw':ci['tau_raw'],
        'tau_sent':ci['tau_sent'],'solver_status_val':status,'integral_record':resp['integral_record'],
        'capacity_interface':ci,'first_capacity_event':bool(len(ci['sent_99_percent_active_indices'])),
        'evidence_source':'NEW_STRICT_SOLVED_FINITE_FIRST_QP'}


def branch_input(kernel,c,base,first,mode,budget):
    result={'features':None,'prior':None,'first_command_valid':bool(first.get('available')),
            'prefix':{'complete':False,'available':False,'original_physical_pass':False,'reason':'FIRST_COMMAND_UNAVAILABLE'}}
    if first.get('available'):
        result['prefix']=kernel.prefix(c,first,mode,budget)
        try:
            result['prior']=prior(c,result['prefix'],mode,first)
            result['features']=append_prefix_features(base,result['prefix'],first,context=c)
        except (ValueError,KeyError,TypeError,IndexError) as exc:
            result['input_error']=type(exc).__name__+':'+str(exc)
    return result


def home_context(model,scenario):
    from types import SimpleNamespace
    from cavr_wbc.control.step23_backup_filter import state_values
    data=mujoco.MjData(model);frozen._reset(model,data,SimpleNamespace(**scenario))
    q=data.qpos.copy().tolist()
    return {'context_id':'STEP28_HEALTHY_HOME_PRIMING','state':state_values(model,data),
        'nominal_q_init':q,'nominal_d_m':0.,'nominal_b_used':[0.]*6,'source_tick':0,
        'backup_anchor_q_init':q,'backup_id':'STEP28-HOME','health_vector':[1.]*12,
        'faulted_actuator_name':'NONE','faulted_actuator_index':None,'faulted_health':1.}


def source_prefixes(out,kernel,items,budget):
    records=[]
    for item in items:
        c=item['context'];kernel.reset(c);branches={}
        for mode in ('C','B'):
            branches[mode]=branch_input(kernel,c,item['features16'],item['firsts'][mode],mode,budget)
        record=freeze_value({'id':item['id'],'split':item['split'],'episode_id':item['episode_id'],
            'context':c,'branches':branches,'labels':item['labels'],'source_paths':item['source_paths'],
            'firsts':item['firsts'],'source_trajectory_ids':item['source_trajectory_ids']})
        write(out/'DEV'/item['id']/'attempt01.json',record)
        records.append(record);budget.event('DEV_PREFIX_RECORD_SAVED',owner=item['id'],split=item['split'])
        budget.persist(phase='DEV_NATIVE_PREFIX',DEV_records=len(records),last_context=item['id'])
    write(out/'DEV_SPLIT_REGISTRY.json',[{'id':r['id'],'split':r['split'],'episode_id':r['episode_id'],
        'path':'DEV/'+r['id']+'/attempt01.json'} for r in records])
    return records


def decision_inputs(kernel,c,budget,kind):
    kernel.reset(c);n=kernel.nominal(c,budget=budget,kind=kind+'_NOMINAL',owner=c['context_id'])
    ft=perf_counter();base=None;error=None
    try:base=features16(c,n,kernel.mapping)
    except (ValueError,KeyError,TypeError) as exc:error=str(exc)
    feature16_ms=(perf_counter()-ft)*1000
    kernel.reset_backup(kernel.data,c)
    b=kernel.compute_backup(c,0,budget=budget,kind=kind+'_FIRST_BACKUP',owner=c['context_id'])
    pt=perf_counter()
    inputs={mode:branch_input(kernel,c,base,first_record(n if mode=='C' else b,mode),mode,budget) for mode in ('C','B')}
    return n,b,inputs,base,{'feature16_ms':feature16_ms,'prefix_and_prior_ms':(perf_counter()-pt)*1000,'feature16_error':error}


def command_ready(kernel,c,bundle,gap,budget):
    t=perf_counter();before_setup=kernel.setup_count
    if not kernel.ready:
        return {'context_id':c['context_id'],'status':'NOT_READY','command_valid':False,'recognized':False,
            'choice':'ABSTAIN','command_ready_ms':(perf_counter()-t)*1000,'gap_m':gap},None,None,None
    n,b,inputs,base,parts=decision_inputs(kernel,c,budget,'ONLINE')
    it=perf_counter();decision=decide(bundle,inputs,gap);inference_ms=(perf_counter()-it)*1000
    chosen=decision['choice'];first=n if chosen=='C' else b
    valid=bool(n['command_valid'] if chosen=='C' else b['valid_command'])
    ci=first['capacity_interface'];tau=ci['tau_sent'] if valid else None
    elapsed=(perf_counter()-t)*1000
    record={'context_id':c['context_id'],'ordinal':c['ordinal'],'group':c['group'],'gap_m':gap,
        'choice':chosen,'recognized':bool(decision['accepted'] and valid),'best_effort_B':chosen=='ABSTAIN',
        'command_valid':valid,'tau_sent':tau,'command_ready_ms':elapsed,'deadline_miss':elapsed>20.,
        'startup_ready':True,'runtime_setup_events':kernel.setup_count-before_setup,
        'inference_ms':inference_ms,**parts,'nominal_generation_ms':n['generation_ms'],
        'first_backup_ms':b['command_ready_ms'],'nominal_status':n['solver_status'],'backup_status':b['wbc']['status'],
        'decision':decision,'two_prefixes_charged_online':True,'no_teacher_or_bank_read':True,
        'first_after_startup_ready':not getattr(kernel,'_recorded_first_ready',False)}
    kernel._recorded_first_ready=True
    return record,n,b,inputs


def produce(out,kernel,c,bundles,old27,budget):
    directory=out/'bank'/c['context_id']/'attempt01'
    entry={'context_id':c['context_id'],'episode_id':c['episode_id'],'ordinal':c['ordinal'],'group':c['group'],
        'context':c,'snapshot_eligible':bool(c.get('eligible')),'bank_directory':str(directory.relative_to(out)),
        'attempt_id':'attempt01','branches':{},'bank_paths':{},'current_predictions':{}}
    lab={mode:missing('SNAPSHOT_INELIGIBLE') for mode in ('C','B')}
    if c.get('eligible'):
        n,b,inputs,base,timing=decision_inputs(kernel,c,budget,'TEACHER')
        entry.update(branches=freeze_value(inputs),features16=freeze_value(base),current_candidate_valid=n['command_valid'],
            current_physical_pass=n['current_physical_check']['pass'],first_backup_valid=b['valid_command'])
        for gap in GAPS:
            entry['current_predictions'][str(gap)]={
                'M5':decide(bundles['selected'],inputs,gap),'DIRECT':decide(bundles['selected_direct'],inputs,gap),
                'M4_STEP27':decide27(old27,base,gap) if base is not None else {'choice':'ABSTAIN'},
                **{a:decide(bundles['selected'],inputs,gap,ablation=a) for a in ('no_prior','no_cal','no_support')}}
        # Freeze all current-only decisions before any ACTUAL label is generated.
        write(directory/'CURRENT_INPUT.json',{'context':c,'nominal':n,'first_backup':b,'branches':inputs,
            'current_predictions':entry['current_predictions'],'timing':timing,'prediction_labels_not_open':True})
        # B first reuses its already-computed B0 and exact solver/integral state.
        for mode in ('B','C'):
            branch=sim.actual_branch(kernel.model,kernel.data,c,n,mode,'ACTUAL_'+mode,budget,kernel,
                ready_response=b if mode=='B' else None)
            entry['bank_paths'][mode]=save_bank(directory/(mode+'.npz'),branch)
            write(directory/(mode+'_CONTROL_RESULTS.json'),{'branch_id':branch['branch_id'],'controls':branch['controls'],
                'status':branch['status'],'reason':branch.get('reason')})
            lab[mode]=labelsT_actual(branch,c);write(directory/'LABELS.json',lab)
            budget.persist(phase='TEACHER_BRANCH_SAVED',owner=c['context_id'],branch=mode)
            if branch['status']=='FAILED_BUDGET':raise SprintLimit('partial branch saved at budget')
            del branch;gc.collect()
    entry['labels']=lab;write(directory/'CASE_RESULT.json',entry)
    return entry


def new_batch(out,kernel,manifest,bundles,old27,budget):
    budget.event('NEW_VALIDATION_OPEN',model_freeze_sha256=sha(out/'models/MODEL_FREEZE.json'))
    registry=[]
    for eid,d,r,p,seed,group in EPISODES:
        s=deepcopy(manifest['scenario']);s.update(seed=seed,initial_roll=s['initial_roll']+r,initial_pitch=s['initial_pitch']+p)
        ep=oldsim.reference_episode(kernel.model,s,d,eid,(25,35,45,55),budget)
        write(out/'references'/(eid+'.json'),ep);found={x['source_tick']:x for x in ep['snapshots']}
        for tick in (25,35,45,55):
            snapshot=found.get(tick,{'snapshot_id':eid+f'_T{tick:03d}','episode_id':eid,'source_tick':tick,
                'eligible':False,'direction':1 if d>0 else -1,'eligibility_reason':'REFERENCE_INCOMPLETE'})
            for kind in KINDS:
                c=make_context(snapshot,kind,manifest['mapping'],len(registry),group)
                budget.event('CONTEXT_START',owner=c['context_id'],ordinal=c['ordinal'],attempt_id='attempt01')
                try:entry=produce(out,kernel,c,bundles,old27,budget)
                except BaseException as exc:
                    write(out/'bank'/c['context_id']/'attempt01'/'EXCEPTION.json',
                        {'type':type(exc).__name__,'error':str(exc),'traceback':traceback.format_exc(),'budget':budget.snapshot()})
                    raise
                registry.append(freeze_value(entry));write(out/'SPLIT_REGISTRY.json',registry)
                budget.event('CONTEXT_END',owner=c['context_id']);budget.persist(phase='NEW_TEACHER',contexts=len(registry))
                if len(registry)%5==0:print(json.dumps({'phase':'TEACHER','contexts':len(registry),'budget':budget.snapshot()}),flush=True)
    return registry


def evaluation(out,registry):
    rows=[];points=[]
    for e in registry:
        c=e['context'];lab=e['labels'];branches=e.get('branches',{})
        for mode in ('C','B'):
            pred=e.get('current_predictions',{}).get(str(.008),{}).get('M5',{}).get('predictions',{}).get(mode,{})
            points.append({'context_id':e['context_id'],'episode':e['episode_id'],'group':e['group'],
                'health_kind':c['health_kind'],'branch':mode,'actual':lab[mode],'prediction':pred,
                'prior':branches.get(mode,{}).get('prior')})
        for gap in GAPS:
            truths={mode:truth(lab[mode],gap) for mode in ('C','B')}
            d=e.get('current_predictions',{}).get(str(gap),{})
            cp=branches.get('C',{}).get('prefix',{})
            current=bool(e.get('current_candidate_valid') and e.get('current_physical_pass'))
            one=bool(current and cp.get('complete') and cp.get('original_physical_pass') and cp.get('D_prefix_m',float('inf'))<=gap)
            choices={'M0_CURRENT':'C' if current else 'ABSTAIN',
                'M1_PREFIX20':'C' if one else 'B' if e.get('first_backup_valid') else 'ABSTAIN',
                'M4_STEP27':d.get('M4_STEP27',{}).get('choice','ABSTAIN') if current else 'ABSTAIN',
                'DIRECT_REFIT':d.get('DIRECT',{}).get('choice','ABSTAIN'),
                'M5_PHYSICS_RESIDUAL':d.get('M5',{}).get('choice','ABSTAIN'),
                'M5_NO_PRIOR':d.get('no_prior',{}).get('choice','ABSTAIN'),
                'M5_NO_CAL':d.get('no_cal',{}).get('choice','ABSTAIN'),
                'M5_NO_SUPPORT':d.get('no_support',{}).get('choice','ABSTAIN'),
                'ORACLE':'C' if truths['C'] else 'B' if truths['B'] else 'ABSTAIN'}
            for method,choice in choices.items():
                label=lab.get(choice,{});accept=choice!='ABSTAIN'
                rows.append({'context_id':e['context_id'],'snapshot_id':c['snapshot_id'],'episode':e['episode_id'],
                    'ordinal':e['ordinal'],'group':e['group'],'direction':c['direction'],'health_kind':c['health_kind'],
                    'faulted_health':c['faulted_health'],'faulted_actuator_name':c['faulted_actuator_name'],
                    'gap_m':gap,'method':method,'choice':choice,'accepted':accept,
                    'oracle_safe_available':any(truths.values()),'safe_accepted':accept and truths.get(choice,False),
                    'unsafe_accepted':accept and not truths.get(choice,False),'physical_error':bool(accept and label.get('original_failure')),
                    'local_error':bool(accept and label.get('complete') and label['D']>gap),
                    'terminal_error':bool(accept and label.get('complete') and not label.get('terminal_pass')),
                    'numerical_incomplete':bool(accept and not label.get('complete')),
                    'progress20_m':label.get('progress20_m'),'D':label.get('D'),'T':label.get('T'),
                    'M5_prediction':d.get('M5') if method=='M5_PHYSICS_RESIDUAL' else None})
    write(out/'EVALUATION_QUERIES.json',rows);write(out/'MARGIN_POINTS.json',points);csv_write(out/'CASE_RESULTS.csv',rows)
    return rows


def engineering(out,kernel,registry,bundle,budget):
    times=[];inputs=[e['branches'] for e in registry if e['snapshot_eligible']]
    for i in range(1000):
        if not inputs:break
        t=perf_counter();decide(bundle,inputs[i%len(inputs)],.008);times.append((perf_counter()-t)*1000)
    write(out/'INFERENCE_TIMING.json',{'all_ms':times,'iterations':len(times),
        'p99_ms':float(np.percentile(times,99)) if times else None,'component_only_no_QP_or_prefix':True})
    rows=[]
    for e in registry:
        if not e['snapshot_eligible']:
            rows.append({'context_id':e['context_id'],'ordinal':e['ordinal'],'status':'SOURCE_INELIGIBLE',
                'group':e['group'],'command_valid':False,'recognized':False});continue
        gap=(.002,.008,.032)[e['ordinal']%3]
        ready,n,b,bi=command_ready(kernel,e['context'],bundle,gap,budget)
        ready['source_reference_oracle_safe']=bool(ready['choice'] in ('C','B') and truth(e['labels'][ready['choice']],gap))
        ready['reference_truth_not_bounded_actual_truth']=True
        # Every readiness result is persisted before advancing to next input.
        write(out/'engineering'/e['context_id']/'READY.json',ready)
        rows.append(freeze_value(ready));budget.event('COMMAND_READY_SAVED',owner=e['context_id'],**{k:ready[k] for k in
            ('command_valid','recognized','command_ready_ms','deadline_miss','runtime_setup_events')})
        budget.persist(phase='STARTUP_READY_ENGINEERING',ready_results=len(rows))
    write(out/'FULL_READY_TIMING.json',rows);csv_write(out/'FULL_READY_TIMING.csv',rows)
    return rows


def fresh(out,kernel,registry,bundle,budget):
    byord={e['ordinal']:e for e in registry};rows=[]
    for index,gap in zip((0,15,30,45,60,75,90,119),(.002,.008,.032,.002,.008,.032,.002,.008)):
        e=byord.get(index)
        if e is None or not e['snapshot_eligible']:
            rows.append({'index':index,'gap_m':gap,'status':'INELIGIBLE_SKIP_NO_REPLACEMENT'});continue
        c=e['context'];ready,n,b,inputs=command_ready(kernel,c,bundle,gap,budget)
        result={'index':index,'context_id':c['context_id'],'group':c['group'],'gap_m':gap,'ready':ready}
        if not ready['command_valid']:
            result['status']='COMMAND_UNAVAILABLE'
        else:
            mode=ready['choice'] if ready['choice']!='ABSTAIN' else 'B'
            if mode=='C':n['command_ready_ms']=ready['command_ready_ms']
            else:b['command_ready_ms']=ready['command_ready_ms'];b['latency_ms']=ready['command_ready_ms']
            branch=sim.actual_branch(kernel.model,kernel.data,c,n,mode,'ACTUAL_'+mode,budget,kernel,ready_response=b if mode=='B' else None)
            artifact=save_bank(out/'fresh'/c['context_id']/'execution.npz',branch)
            lab=labelsT_actual(branch,c);controls=branch['controls']
            result.update(status=branch['status'],reason=branch.get('reason'),path=artifact,actual=lab,
                recognized=ready['recognized'],best_effort=ready['best_effort_B'],
                first_command_matches=bool(controls and np.array_equal(controls[0]['tau_sent'],ready['tau_sent'])),
                all_tick_20ms=bool(controls and all(x['latency_ms']<=20. and x['valid_command'] for x in controls)),
                tick_latency_ms=[x['latency_ms'] for x in controls])
            write(out/'fresh'/c['context_id']/'CONTROL_RESULTS.json',{'controls':controls,'status':branch['status'],'reason':branch.get('reason')})
            if branch['status']=='FAILED_BUDGET':write(out/'fresh'/c['context_id']/'RESULT.json',result);raise SprintLimit('fresh partial saved')
        write(out/'fresh'/c['context_id']/'RESULT.json',result);rows.append(freeze_value(result))
        write(out/'FRESH_RESULTS.json',rows);budget.persist(phase='FRESH_FEEDBACK',fresh_results=len(rows))
    write(out/'FRESH_RESULTS.json',rows)
    return rows


def manifest(out,run_id,model,dll):
    source=read(SOURCE27/'STEP27_PROTOCOL_AND_MANIFEST.json')
    files=sorted([*ROOT.glob('cavr_wbc/control/step28_*.py'),*ROOT.glob('cavr_wbc/experiments/step28_*.py'),
        *ROOT.glob('tests/test_step28_*.py'),*ROOT.glob('native_backend/step28*'),*ROOT.glob('tools/step28*')])
    m={'run_id':run_id,'date':'2026-10-08','timezone':'Asia/Seoul','source_commit':PARENT,
        'scenario':source['scenario'],'mapping':extract_actuator_audit(model),'frozen_physical':source['frozen_physical'],
        'protocol_sha256':sha(PROTOCOL),'source_sha256':{str(p.relative_to(ROOT)).replace('\\','/'):sha(p) for p in files if p.is_file()},
        'native_prefix_DLL':str(dll),'native_DLL_sha256':sha(dll),'feature_specification':feature_specification(),
        'episodes':EPISODES,'snapshot_ticks':[25,35,45,55],'kinds':KINDS,'planned':120,'ID':80,'CHALLENGE':40,
        'ordinal_order':[eid+f'_T{tick:03d}_'+kind for eid,*_ in EPISODES for tick in (25,35,45,55) for kind in KINDS],
        'gaps_m':GAPS,'engineering_gap_cycle':[.002,.008,.032],'fresh_indices':[0,15,30,45,60,75,90,119],
        'fresh_gaps_m':[.002,.008,.032,.002,.008,.032,.002,.008],'horizon_s':1,'control_dt_s':.02,'physics_dt_s':.002,
        'dense_states':501,'deadline_ms':20,'solver_time_limit_s':.006,'max_QP':16000,'max_physics_steps':160000,
        'max_wall_s':7200,'max_configs':4,'max_DEV_recompute':5,'post_new_test_tuning':False,
        'prior_gains':[192,24,512],'integral_limit':1.,'capacity_gate_fraction':.99,
        'all_old_data_DEV':True,'teacher_kernel':'K28_REFERENCE','deployment_kernel':'K28_STARTUP_READY',
        'source_history_replay':False,'lost_step27_DEV_replay':False,'E3_RL_hardware':False,
        'dependencies':{k:importlib.metadata.version(k) for k in ('numpy','scipy','mujoco','osqp')}}
    write(out/'STEP28_PROTOCOL_AND_MANIFEST.json',m)
    with (out/'PROTOCOL_SOURCE.md').open('w',encoding='utf-8',newline='\n') as f:f.write(PROTOCOL.read_text(encoding='utf-8'))
    return m


def run(run_id,dll):
    out=ROOT/'artifacts/step28_physics_residual_20261008'/run_id
    out.mkdir(parents=True,exist_ok=True)
    if (out/'RUN_STARTED.json').exists():raise FileExistsError('unique STEP28 run only')
    for name in ('DEV','bank','references','models','engineering','fresh','figures','native'): (out/name).mkdir(exist_ok=True)
    write(out/'RUN_STARTED.json',{'run_id':run_id,'pid':os.getpid(),'start_utc':datetime.now(timezone.utc).isoformat()})
    budget=SprintBudget(out);budget.start();status='COMPLETED'
    try:
        startup=perf_counter();model=frozen.load_model();m=manifest(out,run_id,model,Path(dll));home=home_context(model,m['scenario'])
        reference=StartupKernel(model,variant='K28_REFERENCE',prefixdll=dll,budget=budget)
        deployment=StartupKernel(model,variant='K28_STARTUP_READY',prefixdll=dll,budget=budget)
        startup_reference=reference.startup(home,budget);startup_deployment=deployment.startup(home,budget)
        write(out/'STARTUP_RESULT.json',{'total_startup_wall_ms':(perf_counter()-startup)*1000,
            'reference':startup_reference,'deployment':startup_deployment,'native_ABI':deployment.native_abi})
        budget.persist(phase='STARTUP_READY')
        sources=load_sources(ROOT,m['mapping']);records=source_prefixes(out,reference,sources,budget)
        fitted=fit_fixed(records,out/'models');budget.fit_count=fitted['actual_branch_multioutput_estimator_fit_calls']
        write(out/'MODEL_SELECTION.json',{k:v for k,v in fitted.items() if k not in
            ('selected','selected_bundle','selected_direct','selected_direct_bundle','bundles')})
        budget.event('MODEL_FROZEN',selected=fitted['selected_configuration_id'],multioutput_fits=budget.fit_count)
        budget.persist(phase='MODEL_FROZEN');old27=load27(SOURCE27/'models')
        registry=new_batch(out,reference,m,fitted,old27,budget);evaluation(out,registry)
        engineering(out,deployment,registry,fitted['selected'],budget)
        fresh(out,deployment,registry,fitted['selected'],budget)
    except SprintLimit as exc:
        status='INCOMPLETE_BUDGET';write(out/'INTERRUPTION.json',{'type':'BUDGET','error':str(exc),'budget':budget.snapshot()})
    except BaseException as exc:
        status='STOPPED_IMPLEMENTATION_OR_RESOURCE'
        write(out/'INTERRUPTION.json',{'type':type(exc).__name__,'error':str(exc),'traceback':traceback.format_exc(),'budget':budget.snapshot()})
        raise
    finally:
        budget.event('NUMERICAL_FINISHED',status=status,**budget.snapshot());budget.close()
        write(out/'RUN_FINISHED.json',{'status':status,'run_id':run_id,'budget':budget.snapshot(),'finish_utc':datetime.now(timezone.utc).isoformat()})
        print(json.dumps({'status':status,'budget':budget.snapshot()}),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('run_id');p.add_argument('--dll',required=True);a=p.parse_args();run(a.run_id,a.dll)
