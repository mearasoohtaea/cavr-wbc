"""One final current-output/identity check with no solver or propagation."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import numpy as np
from cavr_wbc.experiments.step26_features_storage import load_bank


def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def verify(out):
    out=Path(out).resolve();root=out.parents[2];target=out/'FINAL_FILE_VERIFICATION.json'
    if target.exists():raise FileExistsError('one final verification only')
    ledger=[json.loads(x) for x in (out/'STEP28_LEDGER.jsonl').read_text(encoding='utf-8').splitlines()]
    qps=[r for r in ledger if r['event']=='QP_START'];returns=[r for r in ledger if r['event']=='QP_RETURN']
    ps=[r for r in ledger if r['event']=='PREFIX_NATIVE_START'];pr=[r for r in ledger if r['event']=='PREFIX_NATIVE_RETURN']
    m=read(out/'STEP28_PROTOCOL_AND_MANIFEST.json');f=read(out/'RUN_FINISHED.json');b=f['budget']
    frozen=read(out/'models/MODEL_FREEZE.json');registry=read(out/'SPLIT_REGISTRY.json')
    checks={'native_start_return_one_to_one':[r['global_qp_index'] for r in qps]==[r['global_qp_index'] for r in returns]==list(range(1,len(qps)+1)),
        'true_optimizer_calls':all(r['real_optimizer_called'] is True for r in returns),
        'counter_matches_ledger':len(qps)==b['total_QP_calls']==b['QP_returns'],
        'budget_caps':len(qps)<=16000 and b['total_physics_steps']<=160000 and b['numerical_elapsed_s']<=7200,
        'no_unknown_native_returns':b['unknown_native_returns']==0,
        'prefix_reservations_one_to_one':[r['reservation_id'] for r in ps]==[r['reservation_id'] for r in pr],
        'prefix_counts_match_counter':sum(r['actual_steps'] for r in pr)==b['physics_by_kind']['PREFIX_PREDICTION'],
        'no_unknown_native_steps':b['uncompleted_native_step_reservations']==0,
        'startup_exact_four_priming_calls':sum(r['kind'].startswith('STARTUP_PRIMING') for r in qps)==4,
        'models_frozen_before_new_test':next(i for i,r in enumerate(ledger) if r['event']=='MODEL_FROZEN')<next(i for i,r in enumerate(ledger) if r['event']=='NEW_VALIDATION_OPEN'),
        'four_configurations_and_eight_actual_fits':frozen['fixed_model_configurations']==4 and frozen['actual_branch_multioutput_estimator_fit_calls']==8,
        'ordered_120_identities':[e['context_id'] for e in registry]==m['ordinal_order'],
        'ID80_CHALLENGE40':sum(e['group']=='ID' for e in registry)==80 and sum(e['group']=='CHALLENGE' for e in registry)==40,
        'fixed_6ms_all_bounded_calls':all(r['osqp_time_limit_s']==.006 for r in returns if r.get('kernel_variant')=='K28_STARTUP_READY'),
        'native_DLL_hash_unchanged':sha(m['native_prefix_DLL'])==m['native_DLL_sha256'],
        'numerical_source_unchanged':all(sha(root/p)==digest for p,digest in m['source_sha256'].items() if p not in
            ('cavr_wbc/experiments/step28_report.py',)),
        'minimal_mock_tests_passed':read(out/'TEST_RESULTS.json')['result']['exit_code']==0}
    assets=[]
    for config,a in frozen['assets'].items():
        for kind in ('npz','json'):assets.append({'path':a[kind],'pass':sha(a[kind])==a[kind+'_sha256']})
    checks['frozen_model_assets_unchanged']=all(a['pass'] for a in assets)
    saved_steps=sum(read(p)['counts']['physical_steps'] for p in (out/'references').glob('*.json'))
    saved_steps+=sum(r['actual_steps'] for r in pr)
    branch_checks=[];prefix_checks=[]
    for e in registry:
        c=e['context']
        for mode,artifact in e['bank_paths'].items():
            branch=load_bank(artifact['path']);saved_steps+=branch['counts']['physical_steps']
            rows=([branch['initial_fact']] if branch.get('initial_fact') else [])+branch['physics_trajectory']
            branch_checks.append({'identity':e['context_id']+':'+mode,'hash_pass':sha(artifact['path'])==artifact['sha256'],
                'grid_pass':branch['status']!='COMPLETE' or [r['physics_step'] for r in rows]==list(range(501)),
                'health_pass':all(r['health_vector']==c['health_vector'] for r in rows if 'qpos' in r),
                'raw_sent_applied_separate':all(all(k in r for k in ('tau_raw','tau_sent','tau_applied')) for r in rows if 'qpos' in r)})
        for mode,entry in e['branches'].items():
            p=entry['prefix']
            if p.get('complete'):
                numeric=p['numeric'];prefix_checks.append({'identity':e['context_id']+':'+mode,
                    'pass':p['state_count']==11 and p['actual_steps']==10 and p['identity']['mode']==mode and
                      p['identity']['kind']=='PREFIX_PREDICTION' and p['identity']['context_id']==e['context_id'] and
                      np.array_equal(numeric['qpos'][0],c['state']['qpos']) and numeric['health_vector']==c['health_vector'],
                    'projection_pass':entry['prior']['D']>=p['D_prefix_m']})
    for row in read(out/'FRESH_RESULTS.json'):
        if row.get('path'):
            branch=load_bank(row['path']['path']);saved_steps+=branch['counts']['physical_steps']
            branch_checks.append({'identity':row['context_id']+':FRESH','hash_pass':sha(row['path']['path'])==row['path']['sha256'],
                'grid_pass':branch['status']!='COMPLETE' or len(branch['physics_trajectory'])==500,
                'first_match':row['first_command_matches']})
    checks['saved_integrations_match_all_counters']=saved_steps==b['total_physics_steps']
    checks['all_shard_hashes_grids_and_health']=all(all(v for k,v in r.items() if k not in ('identity',)) for r in branch_checks)
    checks['prefix_independent_current_identities']=all(r['pass'] and r['projection_pass'] for r in prefix_checks)
    inputs=[read(out/r['path']) for r in read(out/'DEV_SPLIT_REGISTRY.json')]
    checks['source_DEV_episode_split']=sum(r['split']=='TRAIN' for r in inputs)==176 and sum(r['split']=='CAL' for r in inputs)==56
    checks['no_old_solver_replay']=not any(r['kind'].startswith('DEV') for r in qps)
    statuscounts=dict(Counter(r['status'] for r in returns));files=[{'path':str(p.relative_to(out)).replace('\\','/'),'sha256':sha(p),'bytes':p.stat().st_size} for p in out.rglob('*') if p.is_file() and p!=target]
    value={'native_QP_calls_by_verifier':0,'physics_steps_by_verifier':0,'checks':checks,'all_checks_pass':all(checks.values()),
        'native_status_counts':statuscounts,'branch_checks':branch_checks,'prefix_checks':prefix_checks,'model_assets':assets,
        'files_at_verification':files,'original_HEAD_clean_claim':False}
    with target.open('w',encoding='utf-8',newline='\n') as stream:json.dump(value,stream,sort_keys=True,indent=2,allow_nan=False);stream.write('\n')
    print(json.dumps({'all_checks_pass':value['all_checks_pass'],'checks':checks,'true_QPs':len(qps),'steps':saved_steps}))
    return value


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('out');verify(p.parse_args().out)
