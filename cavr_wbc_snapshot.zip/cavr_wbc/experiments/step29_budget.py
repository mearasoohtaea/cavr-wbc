"""STEP29 immutable numerical cap; buffered QP events, reserved native steps."""
from collections import Counter
from datetime import datetime,timezone
import json
import os
from pathlib import Path
from time import perf_counter
import math


class SprintLimit(RuntimeError):pass


class SprintBudget:
    def __init__(self,out):
        self.out=Path(out);self.out.mkdir(parents=True,exist_ok=True)
        self.path=self.out/'STEP29_LEDGER.jsonl'
        self.stream=self.path.open('x',encoding='utf-8',newline='\n')
        self.buffer=[];self.qp_calls=self.returned=self.physics_steps=self.reserved=0
        self.started=self.start_utc=None;self.qp_kinds=Counter();self.step_kinds=Counter()
        self.fit_count=0;self.dev_recomputations=0;self.reservation_id=0;self.tokens={}
        self.persisted_qp_calls=self.persisted_returns=0

    def event(self,event,**values):
        def encode(v):
            if hasattr(v,'tolist'):return encode(v.tolist())
            if isinstance(v,float) and not math.isfinite(v):return {'nonfinite':repr(v)}
            if isinstance(v,dict):return {str(k):encode(x) for k,x in v.items()}
            if isinstance(v,(tuple,list)):return [encode(x) for x in v]
            return v
        self.buffer.append(encode({'event':event,'timestamp_utc':datetime.now(timezone.utc).isoformat(),**values}))

    def start(self):
        if self.started is None:
            self.started=perf_counter();self.start_utc=datetime.now(timezone.utc).isoformat()
            self.event('NUMERICAL_STARTED',hard_wall_s=7200,QP_limit=24000,step_limit=240000)

    def check(self):
        if self.started is not None and perf_counter()-self.started>=7200:raise SprintLimit('2 hour numerical wall cap')
        if self.qp_calls>=24000:raise SprintLimit('24000 true QP cap')
        if self.physics_steps+self.reserved>=240000:raise SprintLimit('240000 integration cap including reservations')

    def qp_callback(self,kind,owner,first_mode=None):
        active={}
        def call(stage,payload,solve):
            if stage=='before':
                self.start();self.check();self.qp_calls+=1;self.qp_kinds[kind]+=1
                active.clear();active.update(global_qp_index=self.qp_calls,kind=kind,owner=owner,
                    first_mode=first_mode,local_qp_index=payload['solver_call_index'])
                self.event('QP_START',**active);return solve()
            r=payload['result'];self.returned+=1
            self.event('QP_RETURN',**active,**{k:r.get(k) for k in ('status','status_val','iterations',
                'solve_wall_time_s','real_optimizer_called','primal_residual','dual_residual',
                'setup_time_s','update_time_s','warm_started','kernel_variant','osqp_time_limit_s')})
        return call

    def reserve_steps(self,kind,owner,n):
        self.start();self.check()
        if int(n)!=n or n<0 or self.physics_steps+self.reserved+n>240000:raise SprintLimit('native prefix reservation exceeds integration cap')
        self.reservation_id+=1;token=self.reservation_id
        self.tokens[token]=(kind,owner,int(n));self.reserved+=int(n)
        self.event('PREFIX_NATIVE_START',reservation_id=token,kind=kind,owner=owner,reserved_steps=int(n))
        return token

    def finish_steps(self,token,actual_steps):
        kind,owner,n=self.tokens.pop(token)
        if int(actual_steps)!=actual_steps or not 0<=actual_steps<=n:raise ValueError('native prefix step identity mismatch')
        self.reserved-=n;self.physics_steps+=int(actual_steps);self.step_kinds[kind]+=int(actual_steps)
        self.event('PREFIX_NATIVE_RETURN',reservation_id=token,kind=kind,owner=owner,actual_steps=int(actual_steps))

    def step_observer(self,kind,owner):
        def before():
            self.start();self.check();self.physics_steps+=1;self.step_kinds[kind]+=1
        return before

    def snapshot(self):
        return {'total_QP_calls':self.qp_calls,'QP_returns':self.returned,'unknown_native_returns':self.qp_calls-self.returned,
            'total_physics_steps':self.physics_steps,'uncompleted_native_step_reservations':self.reserved,
            'QP_by_kind':dict(self.qp_kinds),'physics_by_kind':dict(self.step_kinds),
            'numerical_started_utc':self.start_utc,'numerical_elapsed_s':perf_counter()-self.started if self.started else 0.,
            'multioutput_estimator_fits':self.fit_count,'DEV_context_recomputations':self.dev_recomputations,
            'buffered_unpersisted_starts':self.qp_calls-self.persisted_qp_calls,
            'buffered_unpersisted_returns':self.returned-self.persisted_returns}

    def persist(self,**extra):
        for row in self.buffer:self.stream.write(json.dumps(row,sort_keys=True,allow_nan=False)+'\n')
        self.stream.flush();os.fsync(self.stream.fileno());self.buffer.clear()
        self.persisted_qp_calls=self.qp_calls;self.persisted_returns=self.returned
        p=self.out/'STEP29_PROGRESS.json';tmp=p.with_suffix('.tmp')
        with tmp.open('w',encoding='utf-8',newline='\n') as f:f.write(json.dumps({**self.snapshot(),**extra},sort_keys=True,allow_nan=False)+'\n')
        os.replace(tmp,p)

    def close(self):self.persist();self.stream.close()
