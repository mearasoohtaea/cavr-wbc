"""Bounded persistence-only continuation of unstarted STEP29 inputs.

Previously written scientific results are not rerun. Models, action grid and
input definitions remain frozen; the original ledger/time/caps are continued.
The registry holds small summaries rather than duplicated raw matrices.
"""
import argparse
from collections import Counter
from datetime import datetime,timezone
import gc
import json
import os
from pathlib import Path
import shutil
from time import perf_counter
import traceback
import numpy as np
from cavr_wbc.experiments import step29_sprint as run
from cavr_wbc.experiments.step29_budget import SprintBudget,SprintLimit
from cavr_wbc.control.step29_margin import load_bundle,MAIN,NO_CAPACITY


def compact(e):
    """Raw/primal/native arrays remain in each immutable attempt file."""
    result={key:e[key]for key in('context_id','context','ordinal','group','episode','snapshot_eligible','labels','artifacts','predictions')}
    result['actions']={key:{k:a.get(k)for k in('gamma','available','command_valid','unavailable_reason','kind')}for key,a in e['actions'].items()}
    result['inputs']={key:{'first_command_valid':v.get('first_command_valid',False),
        'prefix':{k:p for k,p in(v.get('prefix')or{}).items()if k!='numeric'}}for key,v in e['inputs'].items()}
    result['full_numeric_attempt_path']='reference/'+e['context_id']+'/attempt01/RESULT.json'
    return result


def restore_budget(out):
    old=run.read(out/'RUN_FINISHED.json')['budget']
    if old['unknown_native_returns']or old['uncompleted_native_step_reservations']:raise ValueError('cannot resume with unknown recorded work')
    b=SprintBudget.__new__(SprintBudget);b.out=out;b.path=out/'STEP29_LEDGER.jsonl';b.stream=b.path.open('a',encoding='utf-8',newline='\n');b.buffer=[]
    b.qp_calls=old['total_QP_calls'];b.returned=old['QP_returns'];b.physics_steps=old['total_physics_steps'];b.reserved=0
    b.start_utc=old['numerical_started_utc'];elapsed=(datetime.now(timezone.utc)-datetime.fromisoformat(b.start_utc)).total_seconds()
    b.started=perf_counter()-elapsed;b.qp_kinds=Counter(old['QP_by_kind']);b.step_kinds=Counter(old['physics_by_kind'])
    b.fit_count=old['multioutput_estimator_fits'];b.dev_recomputations=old['DEV_context_recomputations'];b.tokens={}
    b.persisted_qp_calls=b.qp_calls;b.persisted_returns=b.returned
    b.reservation_id=max((json.loads(line).get('reservation_id',0)for line in b.path.read_text(encoding='utf-8').splitlines()),default=0)
    b.check();return b


def compact_online(r):
    result={key:v for key,v in r.items()if key not in('C','B','actions','selected_action')}
    for mode in('C','B'):
        ep=r.get(mode,{})
        result[mode]={key:ep[key]for key in('status','solver_status_val','command_valid','valid_command','solver_ledger','solver_ledger_delta','runtime_setup_events')if key in ep}
    result['actions']={key:{'gamma':v['gamma'],'evaluation_status':v['evaluation_status']}for key,v in r.get('actions',{}).items()}
    result['full_numeric_is_in_individual_file']=True
    return result


def engineering(out,kernel,registry,bundle,b):
    policies=('BINARY_EAGER','BINARY_LAZY','GOVERNOR_LAZY');records=[];gaps=(.0015,.0025,.004,.008,.016,.032)
    for e in registry:
        ordinal=e['ordinal'];order=policies[ordinal%3:]+policies[:ordinal%3]
        for policy in order:
            r=kernel.governor(e['context'],bundle,gaps[ordinal%6],policy,b)if e['snapshot_eligible']else{
                'context_id':e['context_id'],'policy':policy,'status':'SOURCE_INELIGIBLE','selected_command_sent':False}
            r.update(ordinal=ordinal,group=e['group'],engineering_order=list(order))
            run.write(out/'online'/e['context_id']/(policy+'.json'),r)
            records.append(compact_online(r));del r
            run.write(out/'ONLINE_RESULTS.json',records);b.persist(phase='CONTINUED_ONLINE',online_records=len(records))
        gc.collect()


def fresh(out,kernel,registry,bundle,b):
    byord={e['ordinal']:e for e in registry};records=[]
    for index,gap in zip((0,4,8,13,17,21,26,30,34,39,43,53),(.0015,.0025,.004,.008,.016,.032)*2):
        e=byord[index];c=e['context']
        if not e['snapshot_eligible']:result={'index':index,'gap_m':gap,'status':'SOURCE_INELIGIBLE'}
        else:
            ready=kernel.governor(c,bundle,gap,'GOVERNOR_LAZY',b)
            run.write(out/'fresh'/c['context_id']/'ONLINE_NUMERIC.json',ready)
            result={'index':index,'gap_m':gap,'context_id':c['context_id'],'group':c['group'],
                'online':compact_online(ready),'status':'NO_RECOGNIZED_COMMAND_SENT'}
            if ready['selected_command_sent']:
                action=ready['selected_action'];action['command_ready_ms']=ready['command_ready_ms'];g=action['gamma'];kernel.set_next_call_limit(.006)
                B=ready['B']if g==0. else None
                if B is not None:B['command_ready_ms']=B['latency_ms']=ready['command_ready_ms']
                branch=run.sim.actual_action_branch(kernel.model,kernel.data,c,action,'ACTUAL_GAMMA',b,kernel,ready_response=B)
                result.update(status=branch['status'],gamma=g,labels=run.labels(branch,c),
                    artifact=run.save_bank(out/'fresh'/c['context_id']/'actual.npz',branch),
                    first_command_matches=bool(branch['controls']and np.array_equal(branch['controls'][0]['tau_sent'],action['tau_sent'])),
                    tick_latency_ms=[r['latency_ms']for r in branch['controls']],reason=branch.get('reason'))
                run.write(out/'fresh'/c['context_id']/'CONTROL_RESULTS.json',{'controls':branch['controls'],'status':branch['status']})
                if branch['status']=='FAILED_BUDGET':run.write(out/'fresh'/c['context_id']/'RESULT.json',result);raise SprintLimit('fresh partial saved')
                del branch
            del ready
        run.write(out/'fresh'/c['context_id']/'RESULT.json',result)
        records.append(result);run.write(out/'FRESH_RESULTS.json',records);b.persist(phase='CONTINUED_FRESH',fresh_records=len(records));gc.collect()


def execute(run_id):
    out=run.ROOT/'artifacts/step29_action_governor_20261008'/run_id;segment=out/'persistence_continuation_01'
    segment.mkdir(exist_ok=False)
    for name in('RUN_FINISHED.json','INTERRUPTION.json','TEST_REGISTRY.json','TEST_REGISTRY.json.tmp','STEP29_PROGRESS.json'):
        if(out/name).exists():shutil.copyfile(out/name,segment/('before_'+name))
    run.write(segment/'RUN_STARTED.json',{'pid':os.getpid(),'run_id':run_id,'start_utc':datetime.now(timezone.utc).isoformat(),
        'continuation_of_same_plan':True,'new_model_fits':0,'previous_results_never_rerun':True})
    b=restore_budget(out);status='COMPLETED'
    try:
        b.event('PERSISTENCE_ONLY_CONTINUATION',original_start_utc=b.start_utc,prior_QP_calls=b.qp_calls,
            prior_physics_steps=b.physics_steps,prior_stop_sha256=run.sha(segment/'before_RUN_FINISHED.json'),budget_reset=False)
        manifest=run.read(out/'MANIFEST.json');models=out/'models';fitted={'selected_main':load_bundle(models,MAIN),'nocapacity':load_bundle(models,NO_CAPACITY)}
        frozen_models=run.read(models/'MODEL_FREEZE.json')
        if any(run.sha(asset['npz'])!=asset['npz_sha256']or run.sha(asset['json'])!=asset['json_sha256']for asset in frozen_models['assets'].values()):raise ValueError('frozen model hash mismatch')
        oldfreeze=run.read(run.SOURCE28/'models/MODEL_FREEZE.json');old_direct=run.load28(oldfreeze['assets'][oldfreeze['selected_direct_configuration_id']]['npz'])
        model=run.frozen.load_model();home=run.home_context(model,manifest['scenario']);home.update(context_id='STEP29_HOME_PRIMING',backup_id='STEP29-HOME')
        ref=run.Kernel(model,'REFERENCE',str(run.DLL),b);online=run.Kernel(model,'BOUNDED',str(run.DLL),b)
        run.write(segment/'STARTUP.json',{'reference':ref.startup(home,b),'bounded':online.startup(home,b),
            'new_process_workspace_priming_QPs_counted':True})
        registry=[];reused=[];new=[]
        for eid,d,r,p,seed,group in run.EPISODES:
            ep_path=out/'episodes'/(eid+'.json')
            if ep_path.exists():episode=run.read(ep_path)
            else:
                scenario=dict(manifest['scenario']);scenario.update(seed=seed,initial_roll=scenario['initial_roll']+r,initial_pitch=scenario['initial_pitch']+p)
                episode=run.reference_sim.reference_episode(model,scenario,d,eid,(25,35,55),b);run.write(ep_path,episode)
            found={s['source_tick']:s for s in episode['snapshots']}
            for tick in(25,35,55):
                snap=found.get(tick,{'snapshot_id':eid+f'_T{tick:03d}','episode_id':eid,'source_tick':tick,
                    'direction':1 if d>0 else -1,'eligible':False,'eligibility_reason':'REFERENCE_INCOMPLETE'})
                for kind in run.KINDS:
                    c=run.source_context(snap,kind,manifest['mapping'],len(registry),group)
                    directory=out/'reference'/c['context_id']/'attempt01';path=directory/'RESULT.json'
                    if path.exists():
                        e=run.read(path)
                        if e['ordinal']!=len(registry)or set(e['labels'])!={'1','0.75','0.5','0.25','0'}:raise ValueError('partial/mismatched prior context; no automatic re-solve')
                        reused.append({'context_id':c['context_id'],'RESULT_sha256':run.sha(path),'new_QPs':0,'new_steps':0})
                    else:
                        if directory.exists()and any(directory.iterdir()):raise ValueError('prior partially started context cannot be re-solved')
                        e=run.produce(out,ref,c,fitted,old_direct,b);new.append(c['context_id'])
                    registry.append(compact(e));del e
                    run.write(out/'TEST_REGISTRY.json',registry);b.persist(phase='CONTINUED_REFERENCE',contexts=len(registry),last_context=c['context_id'])
                    run.write(segment/'CONTEXT_REGISTRY.json',{'reused':reused,'newly_started':new})
                    if len(registry)%3==0:print(json.dumps({'contexts':len(registry),'phase':'CONTINUED_REFERENCE','budget':b.snapshot()}),flush=True)
                    gc.collect()
        run.evaluate(out,registry)
        # No prior online or fresh input was started before the persistence
        # crash; fail rather than duplicate any such previous computation.
        if any((out/'online').rglob('*.json'))or any((out/'fresh').rglob('*.json')):raise ValueError('online/fresh already started; no duplicate call')
        engineering(out,online,registry,fitted['selected_main'],b)
        fresh(out,online,registry,fitted['selected_main'],b)
    except SprintLimit as exc:
        status='INCOMPLETE_BUDGET';run.write(segment/'INTERRUPTION.json',{'type':'BUDGET','error':str(exc),'budget':b.snapshot()})
    except BaseException as exc:
        status='STOPPED_IMPLEMENTATION_OR_RESOURCE';run.write(segment/'INTERRUPTION.json',{'type':type(exc).__name__,'error':str(exc),
            'traceback':traceback.format_exc(),'budget':b.snapshot()});raise
    finally:
        b.event('NUMERICAL_FINISHED',status=status,**b.snapshot());b.close()
        finished={'run_id':run_id,'status':status,'budget':b.snapshot(),'finish_utc':datetime.now(timezone.utc).isoformat(),
            'completed_after_persistence_only_continuation':True,'original_interruption_preserved':True}
        run.write(segment/'RUN_FINISHED.json',finished);run.write(out/'RUN_FINISHED.json',finished)
        print(json.dumps({'status':status,'budget':b.snapshot()}),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('run_id');execute(p.parse_args().run_id)
