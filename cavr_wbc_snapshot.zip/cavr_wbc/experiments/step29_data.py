"""Read-only old endpoint evidence and the fixed 36-context middle-action DEV."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import numpy as np
from cavr_wbc.experiments.step26_features_storage import load_bank
from cavr_wbc.experiments.step28_data import current_firsts,first_slot_header

CAL_EPISODES=frozenset(('T27_N050','T27_P070','T28_N055','T28_P065','T28_P060_C','T28_N060_C'))
MID_EPISODES=('T28_P055','T28_N065','T28_P060_C','T28_N060_C')
MID_TICKS=(25,35,55)
MID_KINDS=('HEALTHY','THIGH_15','CALF_15')
SOURCE_DIRS=(
    'artifacts/step26_fast_margin_20261008/step26-fast-margin-20261008-01',
    'artifacts/step27_structured_margin_20261008/step27-structured-margin-20261008-01',
    'artifacts/step28_physics_residual_20261008/step28-physics-residual-20261008-01')


def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))


def source_split(episode):return 'CAL' if episode in CAL_EPISODES else 'TRAIN'
def role(ctx):return ctx['health_kind'].split('_')[0].lower()


def state_identity(ctx):
    keys=('state','health_vector','nominal_d_m','nominal_q_init','nominal_b_used','backup_anchor_q_init')
    return hashlib.sha256(json.dumps({k:ctx.get(k) for k in keys},sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def endpoint_record(ctx,proof,full=None,mode='C'):
    """Saved validation is enough for endpoint features, not missing mixed z."""
    full=full or {};response=full.get('response',full)
    wb=full.get('raw_solver_result',full.get('wbc',full.get('solver_raw_result',{}))) or {}
    variables=full.get('raw_solver_variables') or {}
    qdd=variables.get('qdd',full.get('qdd',wb.get('qdd')))
    tau=variables.get('tau',proof.get('tau_raw',wb.get('tau')))
    force=variables.get('contact_force',variables.get('contact_lambda',full.get('contact_lambda',wb.get('contact_force'))))
    z=None
    try:
        pieces=[np.asarray(v,float) for v in (qdd,tau,force)]
        if all(v.shape==s and np.isfinite(v).all() for v,s in zip(pieces,((18,),(12,),(12,)))):
            z=np.concatenate(pieces)
    except (ValueError,TypeError):pass
    ref=response.get('a_base_ref',full.get('a_base_ref'))
    if ref is None and mode=='B' and np.array_equal(ctx['backup_anchor_q_init'],ctx['state']['qpos']):
        # Original B0: fixed anchor at current pose, zero integral/reference
        # velocity/feedforward. This is its current target, not a horizon prior.
        ref=-24.*np.asarray(ctx['state']['qvel'][:6],float)
    integral=proof.get('integral_record',response.get('integral_record'))
    return {**proof,'available':bool(proof.get('available')),'command_valid':bool(proof.get('command_valid')),
        'health_vector':ctx['health_vector'],'solver_status_val':proof.get('solver_status_val'),
        'qdd':qdd,'contact_lambda':force,'full_z_available':z is not None,'z_raw':z,
        'raw_solver_variables':{'qdd':qdd,'tau':tau,'contact_force':force},
        'raw_solver_result':{**wb,'qdd':qdd,'tau':tau,'contact_force':force,'status_val':proof.get('solver_status_val')},
        'a_base_ref':ref,'response':{'a_base_ref':ref,'integral_record':integral,'wbc':wb},
        'integral_record':integral,'raw_full_variables_not_fabricated':True,
        'reference_source':'SAVED_CURRENT_REFERENCE' if response.get('a_base_ref') is not None else
            'EXACT_ORIGINAL_ZERO_POSE_ERROR_B0_TARGET' if mode=='B' and ref is not None else 'MISSING',
        'execution_qualification_from_saved_original_interface':bool(proof.get('available'))}


def missing(reason):
    return {'complete':False,'D':None,'Y':None,'valid':False,'original_physical_safe':False,
        'terminal_pass':False,'original_failure':None,'progress20_m':None,'reason':reason,'trajectory_id':None}


def load_sources(root,mapping,labeler=None):
    if labeler is None:
        from cavr_wbc.control.step29_margin import labels as labeler
    root=Path(root);items=[];seen={};ids={};cache={}
    for relative in SOURCE_DIRS:
        directory=root/relative
        for entry in read(directory/'SPLIT_REGISTRY.json'):
            c=entry['context'];cid=entry['context_id'];sid=state_identity(c);split=source_split(entry['episode_id'])
            if cid in ids and ids[cid]!=sid:raise ValueError('same source ID different state')
            ids[cid]=sid
            if sid in seen:
                if seen[sid]['split']!=split:raise ValueError('source state crosses TRAIN/CAL')
                seen[sid]['alias_ids'].append(cid);continue
            bank=directory/entry['bank_directory'];current_path=bank/'CURRENT_INPUT.json'
            cur=read(current_path) if current_path.exists() else {'context':c,'nominal':{}}
            c=cur['context'];nom=cur.get('nominal') or {}
            bpath=bank/'B.npz';header=first_slot_header(bpath) if bpath.exists() else None
            proofs=current_firsts(c,nom,mapping,header,current_path=current_path,bank_path=bpath)
            fullB=cur.get('first_backup') or {}
            if not fullB and header:
                fullB=header.get('control') or {}
            endpoints={'C':endpoint_record(c,proofs['C'],nom,'C'),
                       'B':endpoint_record(c,proofs['B'],fullB,'B')}
            labs={};paths={'CURRENT_INPUT':str(current_path)}
            for mode,gamma in (('C','1'),('B','0')):
                path=bank/(mode+'.npz');paths[gamma]=str(path)
                key=str(path.resolve())
                if path.exists():
                    if key not in cache:cache[key]=labeler(load_bank(path),c)
                    labs[gamma]=deepcopy(cache[key])
                else:labs[gamma]=missing('SOURCE_ENDPOINT_ARCHIVE_MISSING')
            item={'id':cid,'context_id':cid,'context':deepcopy(c),'ctx':deepcopy(c),'episode':entry['episode_id'],
                'source_snapshot':c.get('snapshot_id',entry['episode_id']+':'+str(c['source_tick'])),
                'split':split,'role':role(c),'endpoints':endpoints,'nominal_C':nom,'first_B':fullB,
                'labels':labs,'source_paths':paths,'source_identity':sid,'alias_ids':[],
                'all_source_data_DEV':True,'source_solver_replay':False,'source_trajectory_replay':False}
            seen[sid]=item;items.append(item)
    return items


def fixed_mid_DEV(items):
    byid={i['id']:i for i in items};result=[]
    for episode in MID_EPISODES:
        for tick in MID_TICKS:
            for kind in MID_KINDS:
                cid=episode+f'_T{tick:03d}_'+kind
                if cid not in byid:raise ValueError('fixed middle DEV identity missing: '+cid)
                result.append(byid[cid])
    return result
