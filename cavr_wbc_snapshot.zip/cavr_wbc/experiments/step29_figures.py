"""Two saved-only scipilot evidence figures; preview precedes vector export."""
import argparse
from pathlib import Path
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from cavr_wbc.experiments.step29_sprint import read,write
from cavr_wbc.experiments.step21_report import csv_write
from cavr_wbc.control.step29_margin import GAMMA_GRID,gamma_key

SCRIPTS=Path('C:/Users/ZhuanZ（无密码）/.codex/skills/scipilot-figure/scripts')
sys.path.insert(0,str(SCRIPTS))
from setup_style import setup_style
from visual_qa import audit_layout,render_preview
from export_figure import export_figure
from layout_tools import finalize_figure,add_panel_labels
from profile_data import profile_data,render_report


def data(out):
    registry=read(out/'TEST_REGISTRY.json');online=read(out/'ONLINE_RESULTS.json');actions=[];timing=[]
    for e in registry:
        for g in GAMMA_GRID:
            lab=e['labels'].get(gamma_key(g),{});status='SAFE_PHYSICAL_TERMINAL'if lab.get('complete')and lab.get('original_physical_safe')and lab.get('terminal_pass')and lab.get('command_valid_all')else'FAILED_PHYSICAL_OR_TERMINAL'if lab.get('complete')else'INCOMPLETE_OR_UNAVAILABLE'
            actions.append({'ordinal':e['ordinal'],'context_id':e['context_id'],'episode':e['episode'],'group':e['group'],
                'gamma':g,'role':e['context']['health_kind'].split('_')[0].lower(),'complete':lab.get('complete',False),
                'status':status,'minimum_required_gap_mm':1000*lab['D']if lab.get('D')is not None else None,
                'progress20_mm':1000*lab['progress20_m']if lab.get('progress20_m')is not None else None})
    for r in online:
        timing.append({'ordinal':r['ordinal'],'context_id':r['context_id'],'policy':r['policy'],'group':r['group'],
            'command_ready_ms':r.get('command_ready_ms'),'recognized_sent':r.get('selected_command_sent',False),'status':r['status']})
    csv_write(out/'figures/ACTION_FIGURE_DATA.csv',actions);csv_write(out/'figures/ONLINE_FIGURE_DATA.csv',timing)
    for name,groups in [('ACTION_FIGURE_DATA',['group','gamma']),('ONLINE_FIGURE_DATA',['policy'])]:
        profile=profile_data(str(out/'figures'/(name+'.csv')),group_cols=groups)
        (out/'figures'/(name+'_PROFILE.md')).write_text(render_report(profile),encoding='utf-8')
    return actions,timing


def build(out,phase):
    out=Path(out);out.joinpath('figures').mkdir(exist_ok=True);actions,timing=data(out)
    setup_style(journal='ieee',lang='en',use_sciplots=False)
    plt.rcParams.update({'font.size':8,'axes.labelsize':8,'xtick.labelsize':8,'ytick.labelsize':8,'legend.fontsize':8,
        'axes.spines.top':False,'axes.spines.right':False,'figure.constrained_layout.use':True})
    QA=[]
    fig,axes=plt.subplots(1,2,figsize=(7.16,4.4),gridspec_kw={'width_ratios':[1.1,1.]},layout='constrained')
    ax=axes[0];grid=np.full((54,5),np.nan);cross=[];missing=[];ordered=(0.,.25,.5,.75,1.)
    for r in actions:
        ix=ordered.index(r['gamma']);iy=r['ordinal']
        if r['status']=='SAFE_PHYSICAL_TERMINAL':grid[iy,ix]=r['minimum_required_gap_mm']
        elif r['complete']:cross.append((ix,iy))
        else:missing.append((ix,iy))
    color_max=max(1.,float(np.ceil(np.nanmax(grid))))
    color=ax.imshow(np.ma.masked_invalid(grid),cmap='cividis',vmin=0.,vmax=color_max,aspect='auto',origin='lower',interpolation='none')
    if cross:
        x,y=np.asarray(cross).T;ax.scatter(x,y,c='black',marker='x',s=12,linewidths=.6,label='physical/terminal fail')
    if missing:
        x,y=np.asarray(missing).T;ax.scatter(x,y,c='black',marker='.',s=7,label='incomplete/unavailable')
    ax.set_xticks(range(5),['0','.25','.5','.75','1']);ax.set_xlabel('First-command retention gamma')
    ax.set_yticks([4,13,22,31,40,49],['P052','N052','P068','N068','P060-C','N060-C']);ax.set_ylabel('Episode (9 fixed contexts each)')
    for y in(8.5,17.5,26.5,35.5,44.5):ax.axhline(y,color='white',lw=.6)
    ax.axhline(35.5,color='black',lw=1.2,ls='--');ax.set_title('All five actual action branches',pad=12)
    cb=fig.colorbar(color,ax=ax,shrink=.8,pad=.02);cb.set_label('Required local gap (mm)')
    ax.legend(loc='upper left',bbox_to_anchor=(-.02,-.18),frameon=False,fontsize=7)
    ax=axes[1];colors=('#000000','#E69F00','#0072B2','#CC79A7','#56B4E9');markers=('o','s','^','D','v')
    for g,c,marker in zip(ordered,colors,markers):
        rows=[r for r in actions if r['gamma']==g and r['status']=='SAFE_PHYSICAL_TERMINAL']
        ax.scatter([r['minimum_required_gap_mm']for r in rows],[r['progress20_mm']for r in rows],c=c,marker=marker,
            s=15,alpha=.8,linewidths=.35,edgecolors='black',label='gamma='+gamma_key(g))
    ax.axhline(0,color='gray',lw=.6,ls=':');ax.set_xlabel('Actual maximum excursion (mm)');ax.set_ylabel('Actual first-20ms progress (mm)')
    ax.set_title('Task progress versus recovery excursion',pad=12);ax.legend(loc='upper left',bbox_to_anchor=(0.,-.18),ncol=2,frameon=False,fontsize=7)
    ax.margins(.06)
    finish(fig,out/'figures/step29_action_set',phase,QA)
    plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(7.16,3.4),layout='constrained')
    policies=('BINARY_EAGER','BINARY_LAZY','GOVERNOR_LAZY');colors=('#E69F00','#0072B2','#000000');markers=('s','o','^');lines=('--','-.','-')
    for policy,c,marker,ls in zip(policies,colors,markers,lines):
        rows=[r for r in timing if r['policy']==policy and r['command_ready_ms']is not None];v=np.sort([r['command_ready_ms']for r in rows])
        axes[0].step(v,np.arange(1,len(v)+1)/54,where='post',label=policy.replace('_',' ').title(),color=c,ls=ls,lw=1.)
        for sent in(False,True):
            rr=[r for r in rows if r['recognized_sent']==sent]
            axes[1].scatter([r['ordinal']for r in rr],[r['command_ready_ms']for r in rr],marker=marker,s=16,
                edgecolors=c,facecolors=c if sent else'none',linewidths=.6,label=policy if sent else None)
    axes[0].axvline(20,color='gray',lw=.8,ls=':');axes[0].set_ylim(0,1.04);axes[0].set_xlim(left=0)
    axes[0].set_xlabel('Complete command-ready time (ms)');axes[0].set_ylabel('Fraction of all 54 planned inputs')
    axes[0].set_title('All-input latency distribution',pad=12)
    axes[0].legend(loc='upper left',bbox_to_anchor=(0.,-.22),frameon=False,fontsize=7)
    axes[1].axhline(20,color='gray',lw=.8,ls=':');axes[1].set_ylim(bottom=0);axes[1].set_xlabel('Fixed input ordinal')
    axes[1].set_ylabel('Complete command-ready time (ms)');axes[1].set_title('Filled = timely recognized and sent',pad=12)
    finish(fig,out/'figures/step29_all_latency',phase,QA)
    plt.close(fig);write(out/'figures/FIGURE_MACHINE_QA.json',QA)
    (out/'figures/FIGURE_CAPTIONS.md').write_text('\n'.join(['# STEP29 evidence figure captions','',
        'Figure 1. All 54 contexts × five actual first commands. Left: minimum local gap D for branches that complete all 501 states and satisfy unchanged original physical and terminal predicates; cross denotes complete physical/terminal failure, dot denotes numerical incomplete or current-command unavailable. The 36/18 ID/challenge division is fixed; within each episode the nine rows are three ticks × healthy/thigh/calf, in manifest order. The continuous colorbar starts at0 and rounds the maximum of all plotted D values upward to the next1mm; no values are clipped or gap-selected. Right: actual20ms direction progress versus full1s maximum direction excursion for every physically and terminally safe branch, independently of a chosen gap. No statistical independence or monotonic safety is inferred from gamma. Each dot is one distinct branch; repeated gap queries are not drawn as replicates.','',
        'Figure 2. Each of54 planned inputs is timed once perpolicy (162 complete ready windows); inputs are paired, not random independent replicates. Left: empirical CDF uses denominator54 even if an input is unavailable; vertical20ms line retains the late tail. Right: every measured input/policy, no connections across unordered cases; policy uses color and marker, filled marks timely recognized and actually sent while hollow marks rejected/unavailable/late. Horizontal20ms line is the unchanged deadline. No mean-only bars, confidence intervals, or significance tests.','',
        'Both figures: IEEE double-column7.16in, ≥8pt primary text, vector PDF/SVG with embedded TrueType,600dpi PNG and grayscale review; no alternate selected-gap success rate. Publication readiness requires machine checks plus explicit visual review.','']),encoding='utf-8')


def finish(fig,base,phase,QA):
    finalize_figure(fig);add_panel_labels(fig,style='ieee')
    issues=audit_layout(fig);QA.append({'figure':base.name,'issues':issues,'phase':phase})
    if any(severity=='FAIL'for severity,_ in issues):raise RuntimeError('figure glyph/layout failure')
    if phase=='preview':
        render_preview(fig,str(base)+'_preview.png',dpi=180)
        from PIL import Image
        Image.open(str(base)+'_preview.png').convert('L').save(str(base)+'_preview_grayscale.png')
    else:
        export_figure(fig,str(base),formats=['pdf','svg','png'],size_inches=tuple(fig.get_size_inches()),dpi=600,tight=False,grayscale_preview=False)
        from PIL import Image
        Image.open(str(base)+'.png').convert('L').save(str(base)+'_grayscale.png')


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('out');p.add_argument('phase',choices=('preview','export'));args=p.parse_args();build(args.out,args.phase)
