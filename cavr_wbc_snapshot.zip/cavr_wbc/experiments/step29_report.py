"""Saved-only STEP29 analysis and handoff; no solve, integration, or fitting."""
import argparse
from collections import Counter
from pathlib import Path
import numpy as np
from cavr_wbc.experiments.step29_sprint import read,write,ROOT
from cavr_wbc.control.step29_margin import GAMMA_GRID,gamma_key,safe
from cavr_wbc.experiments.step21_report import csv_write


def stats(v):
    a=np.asarray([x for x in v if isinstance(x,(int,float)) and np.isfinite(x)],float)
    return {'n':len(a),**{name:float(np.percentile(a,p)) if len(a)else None for name,p in [('p50',50),('p95',95),('p99',99)]},'max':float(a.max())if len(a)else None}


def query_summary(rows):
    denom=sum(r['oracle_any_gamma']for r in rows);bd=sum(r['oracle_binary']for r in rows);s=sum(r['safe_accepted']for r in rows)
    return {'queries':len(rows),'oracle_any_gamma_queries':denom,'oracle_binary_queries':bd,'safe_accepted':s,
        'safe_coverage_common_oracle':s/denom if denom else None,
        'safe_accepted_on_binary_denominator':sum(r['safe_accepted']and r['oracle_binary']for r in rows),
        'safe_coverage_binary_oracle':sum(r['safe_accepted']and r['oracle_binary']for r in rows)/bd if bd else None,
        'accepted':sum(r['accepted']for r in rows),'unsafe_accepted':sum(r['unsafe_accepted']for r in rows),
        'ABSTAIN':sum(not r['accepted']for r in rows),
        'safe_middle_accepted':sum(r['safe_accepted']and r['choice']not in(0.,1.)for r in rows),
        **{k:sum(bool(r[k])for r in rows)for k in ('physical_error','local_error','terminal_error','numerical_incomplete')}}


def engineering_summary(rows,planned):
    return {'planned':planned,'recorded':len(rows),'timely_recognized_sent':sum(bool(r.get('selected_command_sent'))for r in rows),
        'timely_recognized_rate_planned':sum(bool(r.get('selected_command_sent'))for r in rows)/planned,
        'command_available':sum(bool(r.get('command_available'))for r in rows),
        'raw_valid_but_late':sum(bool(r.get('raw_valid_but_late'))for r in rows),
        'overall_deadline_failure':sum(bool(r.get('overall_deadline_failure'))for r in rows),
        'late_sent':sum(bool(r.get('selected_command_sent')and r.get('command_ready_ms',float('inf'))>20.)for r in rows),
        'budget_cutoff_actions':sum(x.get('evaluation_status')=='NOT_EVALUATED_BUDGET'for r in rows for x in r.get('actions',{}).values()),
        'unrequested_B':sum(r.get('B',{}).get('status')=='NOT_REQUESTED'for r in rows),
        'QP_calls':sum(len(ep.get('solver_ledger',ep.get('solver_ledger_delta',[])))for r in rows for ep in (r.get('C',{}),r.get('B',{}))),
        'runtime_setup_events':sum(ep.get('runtime_setup_events',0)for r in rows for ep in(r.get('C',{}),r.get('B',{}))),
        'all_latency_ms':stats([r.get('command_ready_ms')for r in rows]),
        'selected_gamma_counts':dict(Counter(str(r['selected_gamma'])for r in rows if r.get('selected_command_sent'))),
        'statuses':dict(Counter(r['status']for r in rows))}


def analyze_intervals(out,registry):
    intervals=read(out/'ACTION_CHANGE_INTERVALS.json')if(out/'ACTION_CHANGE_INTERVALS.json').exists()else[]
    byid={e['context_id']:e for e in registry}
    for interval in intervals:
        e=byid[interval['context_id']];gap=(interval['left_m']+interval['right_m'])/2
        candidates=next(iter(e['predictions'].values()),{}).get('GOVERNOR',{}).get('predictions',{})
        static=('support_gate','distance_gate','calibration_gate','pose_gate','current_command_gate','prefix_available_gate','prefix_physical_gate','terminal_gate')
        approved=[g for g in GAMMA_GRID if gamma_key(g)in candidates and all(candidates[gamma_key(g)].get(k)for k in static)
            and candidates[gamma_key(g)].get('U_D')is not None and candidates[gamma_key(g)]['U_D']<=gap]
        true=interval['actual_feasible_gamma'];binary=[g for g in true if g in(0.,1.)]
        interval.update(predicted_gamma=max(approved)if approved else 'ABSTAIN',
            predicted_binary_gamma=max([g for g in approved if g in(0.,1.)],default='ABSTAIN'),
            true_max_gamma=max(true)if true else None,true_binary_max_gamma=max(binary)if binary else None,
            true_gamma_progress20_m={gamma_key(g):e['labels'][gamma_key(g)].get('progress20_m')for g in true},
            true_max_gamma_progress20_m=e['labels'][gamma_key(max(true))].get('progress20_m')if true else None,
            true_binary_max_gamma_progress20_m=e['labels'][gamma_key(max(binary))].get('progress20_m')if binary else None,
            endpoint_equality_included_in_separate_query_table=True)
    write(out/'ACTION_CHANGE_INTERVALS.json',intervals)
    return intervals


def report(out):
    out=Path(out);manifest=read(out/'MANIFEST.json');finished=read(out/'RUN_FINISHED.json')
    registry=read(out/'TEST_REGISTRY.json')if(out/'TEST_REGISTRY.json').exists()else[]
    rows=read(out/'CASE_RESULTS.json')if(out/'CASE_RESULTS.json').exists()else[]
    dev=read(out/'DEV_SPLIT_REGISTRY.json')if(out/'DEV_SPLIT_REGISTRY.json').exists()else[]
    models=read(out/'models/MODEL_FREEZE.json')if(out/'models/MODEL_FREEZE.json').exists()else{}
    online=read(out/'ONLINE_RESULTS.json')if(out/'ONLINE_RESULTS.json').exists()else[]
    fresh=read(out/'FRESH_RESULTS.json')if(out/'FRESH_RESULTS.json').exists()else[]
    methods={group:{method:query_summary([r for r in rows if r['group']==group and r['method']==method])for method in sorted({r['method']for r in rows})}
        for group in ('ID','CHALLENGE')}
    group_rows=[]
    for field in('episode','role','gap_m'):
        for value in sorted({str(r[field])for r in rows}):
            for method in sorted({r['method']for r in rows}):
                group_rows.append({'field':field,'value':value,'method':method,**query_summary([r for r in rows if str(r[field])==value and r['method']==method])})
    csv_write(out/'GROUP_RESULTS.csv',group_rows)
    paired={}
    for r in rows:paired.setdefault((r['context_id'],r['gap_m']),{})[r['method']]=r
    gains=[];coverage_gain=[];ablation_differences=0;byid={e['context_id']:e for e in registry}
    for pair in paired.values():
        g=pair.get('CAPACITY_CONDITIONAL');b=pair.get('BINARY_SAME_MODEL');n=pair.get('NO_EXPLICIT_CAPACITY')
        if not g or not b:continue
        ablation_differences+=bool(n and n['choice']!=g['choice'])
        if g['group']!='ID' or not g['safe_accepted']or g['choice']in(0.,1.):continue
        if not b['accepted']:
            coverage_gain.append(g)
            lab=byid[g['context_id']]['labels'].get('0',{});baseline=0.;base_progress=lab.get('progress20_m')
            baseline_safe=safe(lab,g['gap_m']);comparison='BINARY_ABSTAIN_VS_OBSERVED_SAFE_B'if baseline_safe else 'NO_SAFE_BINARY_BASELINE'
        else:
            baseline=b['choice'];base_progress=b.get('progress20_m');baseline_safe=b['safe_accepted'];comparison='BINARY_SAME_MODEL_SELECTED'
        if baseline_safe and base_progress is not None and g.get('progress20_m')is not None and g['choice']>baseline and g['progress20_m']-base_progress>1e-12:
            gains.append({**g,'binary_choice':b['choice'],'actual_binary_baseline_gamma':baseline,'baseline_progress20_m':base_progress,
                'actual_progress_gain_m':g['progress20_m']-base_progress,'comparison':comparison})
    write(out/'TASK_GAIN_PAIRS.json',gains);csv_write(out/'TASK_GAIN_PAIRS.csv',gains)
    gain_summary={'paired_query_gains':len(gains),'source_snapshots':len({r['source_snapshot']for r in gains}),
        'contexts':len({r['context_id']for r in gains}),'episodes':sorted({r['episode']for r in gains}),
        'damaged_gain_queries':sum(r['health']<1. for r in gains),'selected_binary_comparisons':sum(r['comparison']=='BINARY_SAME_MODEL_SELECTED'for r in gains),
        'binary_abstain_with_observed_safe_B_comparisons':sum(r['comparison']=='BINARY_ABSTAIN_VS_OBSERVED_SAFE_B'for r in gains),
        'additional_safe_middle_vs_binary_abstain_queries':len(coverage_gain),
        'gain_progress20_m':stats([r['actual_progress_gain_m']for r in gains])}
    middle_only=[r for r in rows if r['method']=='ORACLE_ALL_GAMMA'and r['middle_only_actual_safe']]
    middle_only_summary={group:{'queries':sum(r['group']==group for r in middle_only),
        'contexts':len({r['context_id']for r in middle_only if r['group']==group}),
        'source_snapshots':len({r['source_snapshot']for r in middle_only if r['group']==group})}for group in('ID','CHALLENGE')}
    intervals=analyze_intervals(out,registry)
    actions={};gates=Counter();pose_rejections=Counter()
    for group in('ID','CHALLENGE'):
        for gamma in GAMMA_GRID:
            key=gamma_key(gamma);selected=[e for e in registry if e['group']==group]
            labs=[e['labels'].get(key,{})for e in selected]
            actions[group+':'+key]={'planned':36 if group=='ID'else 18,'recorded':len(labs),
                'command_available':sum(e['actions'].get(key,{}).get('command_valid',False)for e in selected),
                'complete_501':sum(l.get('complete',False)for l in labs),'physical_failure':sum(bool(l.get('original_failure'))for l in labs),
                'terminal_failure_complete':sum(l.get('complete',False)and not l.get('terminal_pass',False)for l in labs),
                'numerical_incomplete':sum(not l.get('complete',False)for l in labs),
                'unavailability_reasons':dict(Counter(e['actions'].get(key,{}).get('unavailable_reason')for e in selected if not e['actions'].get(key,{}).get('available')))}
    for e in registry:
        p=e['predictions'].get(str(.008),{}).get('GOVERNOR',{}).get('predictions',{})
        for key,point in p.items():
            for name in ('current_command_gate','prefix_available_gate','prefix_physical_gate','support_gate','distance_gate','calibration_gate','pose_gate','terminal_gate','local_gate'):
                gates[e['group']+':'+key+':'+name]+=not point.get(name,False)
            if not point.get('pose_gate'):pose_rejections[e['group']+':'+key]+=1
    eng={policy:engineering_summary([r for r in online if r['policy']==policy],54)for policy in('BINARY_EAGER','BINARY_LAZY','GOVERNOR_LAZY')}
    eng['all']=engineering_summary(online,162)
    fr={'planned':12,'recorded':len(fresh),'statuses':dict(Counter(r['status']for r in fresh)),
        'actually_sent':sum(bool(r.get('online',{}).get('selected_command_sent'))for r in fresh),
        'complete':sum(r['status']=='COMPLETE'for r in fresh),
        'actual_safe_at_own_gap':sum(safe(r.get('labels',{}),r['gap_m'])for r in fresh),
        'first_mismatches':sum(not r['first_command_matches']for r in fresh if 'first_command_matches'in r),
        'complete_all_ticks_20ms':sum(r['status']=='COMPLETE'and all(t<=20. for t in r['tick_latency_ms'])for r in fresh),
        'late_feedback_ticks':sum(t>20. for r in fresh for t in r.get('tick_latency_ms',[])),
        'all_tick_ms':stats([t for r in fresh for t in r.get('tick_latency_ms',[])])}
    main=methods['ID'].get('CAPACITY_CONDITIONAL',{})
    safety_coverage=bool(main.get('queries')and main.get('unsafe_accepted')==0 and(main.get('safe_coverage_common_oracle')or 0)>=.30)
    task_gain=bool(gain_summary['source_snapshots']>=4 and len(gain_summary['episodes'])>=2 and gain_summary['damaged_gain_queries']>0)
    completed=finished['status']=='COMPLETED'and len(registry)==54 and len(online)==162 and len(fresh)==12
    science='CAPACITY_ACTION_GOVERNOR_SUPPORTED'if completed and safety_coverage and task_gain else'NOT_ESTABLISHED'
    engineering='TIMELY_RECOGNIZED_COMMANDS_OBSERVED'if eng['all']['timely_recognized_sent']and not eng['all']['late_sent']else'NO_TIMELY_RECOGNIZED_COMMAND'
    if eng['all']['overall_deadline_failure']:engineering+=' / DEADLINE_FAILURES_RETAINED'
    result={'run_id':manifest['run_id'],'NUMERICAL_STATUS':finished['status'],'SCIENCE_STATUS':science,'ENGINEERING_STATUS':engineering,
        'GOAL_ID_SAFETY_COVERAGE':safety_coverage,'GOAL_ACTUAL_MIDDLE_TASK_GAIN':task_gain,
        'recorded_contexts':len(registry),'planned_contexts':54,'qualified_contexts':sum(e['snapshot_eligible']for e in registry),
        'methods':methods,'actions':actions,'task_gain':gain_summary,'middle_only_actual_safe':middle_only_summary,
        'capacity_ablation_choice_differences':ablation_differences,'capacity_ablation_extra_benefit':'NOT_ESTABLISHED'if ablation_differences==0 else'PAIRED_DECISION_DIFFERENCES_REPORTED',
        'gate_rejections_at_8mm':dict(gates),'pose_rejected_actions_at_8mm':dict(pose_rejections),
        'DEV_endpoint_records_reused':sum(d['reused_endpoint']for d in dev),'DEV_middle_records':sum(not d['reused_endpoint']for d in dev),
        'model_freeze':models,'engineering':eng,'fresh_feedback':fr,'startup':read(out/'STARTUP.json'),
        'budget':finished['budget'],'historical_STEP28_prior_extra_benefit':'NOT_ESTABLISHED',
        'post_new_TEST_tuning':False,'PID_prior_online_calls':0,'actual_queries_not_independent_replicates':True,
        'continuous_interval_count':len(intervals),'E3_RL_hardware_authorized':False}
    recovery=out/'persistence_continuation_01'
    if recovery.exists():
        result['persistence_resource_recovery']={'initial_interruption':read(recovery/'before_INTERRUPTION.json'),
            'frozen_numeric_code_changed':False,'model_refits':0,'original_budget_reset':False,
            'context_reuse':read(recovery/'CONTEXT_REGISTRY.json'),'continuation_startup':read(recovery/'STARTUP.json')}
    write(out/'STEP29_RESULT.json',result)
    lines=['# STEP29：能力条件化恢复动作集与有界任务调节','','## Material Passport','',
        '日期：2026-10-08（Asia/Seoul）；Origin Skill：experiment-agent；Mode：run；Verification Status：ANALYZED。',
        f"Run ID：{manifest['run_id']}；源提交：{manifest['source_commit']}。",'',
        f"结论：**{science}**；工程状态 **{engineering}**。固定54上下文记录{len(registry)}，资格合格{result['qualified_contexts']}；科学reference与有界真实出令、fresh反馈分别保存。",'',
        '## 方法与冻结条件','',
        '同一当前状态/health下的严格Solved C/B端点构造五动作 {1,.75,.5,.25,0}。中间z为全primal凸组合，发送clip后按原动力学1e-4 N/Nm、接触1e-5 m/s²和零额外不等式slack逐行复核。它是SYNTHESIZED_CONVEX_COMMAND，不是新Solved或QP最优解。共用仿射约束只支持当前命令可行性；恢复安全由独立实际轨迹评价，不能由端点推断单调可行集。',
        '每个γ>0只在首20ms执行一次所选命令，随后49槽执行同一固定anchor、零初始积分的feedback backup。γ=0复用本次真实B0及其b_after；原49后续槽不把b_after清零。全部实际处理含初态共501状态、2ms dense采样，原20ms、1s物理/local/终端边界不变。',
        f"旧352上下文的{result['DEV_endpoint_records_reused']}端点记录仅作DEV，完整actual末状态提供有符号Y；STEP26/27缺失全primal不补造。固定新36上下文 × 3中间γ处理记录{result['DEV_middle_records']}，不重新求解历史C/B。TRAIN/CAL按整episode冻结，新TEST从不参与调参。",
        '23维为命令条件化当前16维、原生独立20ms prefix六维和γ。当前加速度为MuJoCo当前模型forward，不是QP代数qdd、传感器或未来实际值；期望ax使用同γ端点参考。在线不计算PID prior。尺度由TRAIN-only均值/std及原physical-floor决定，γ floor=.25。',
        f"两个预声明全局六输出二次Ridge(alpha=1)配置；真实fit {models.get('actual_multioutput_estimator_fit_calls')}次，等价标量输出{models.get('scalar_output_regression_equivalents')}个。主配置CAPACITY_CONDITIONAL按γ×fault role保留有限失败/不完整邻居；NO_EXPLICIT_CAPACITY删除指定五个能力字段，仅按γ分组，仍执行真实受限命令。BINARY_SAME_MODEL不重训。",
        'k=5支持要求邻居完整且原物理通过；CAL每组≥3不同source snapshot且≥2episode；UD=Dhat+max(0,maxCAL(D−Dhat))+1mm，UTj=abs(Yhatj)+maxCAL(abs(Yj−Yhatj))+.05。D投影≥0和prefix位移，Y保留符号。距离为3倍CAL最大最近TRAIN距离；pose门是TRAIN+CAL起点roll/方向pitch范围±1e-9rad，不是新的物理界或概率保证。',
        f"冻结pose域：{models.get('pose_applicability')}。全部组校准状态见models/MODEL_FREEZE.json，所有拒收和故障通道见STEP29_RESULT.json与GROUP_RESULTS.csv。",'',
        '## 配对科学结果','',
        '六条新stance episode；ID36、CHALLENGE18；seed为recipe标识而非随机重复，不称行走。13个gap复用同一五动作实际bank，共同分母为任一实际安全动作；多gap不增加独立实验数。', '',
        '| 组 | 方法 | 安全接受 | 错误接受 | 五动作oracle覆盖 | 二元oracle分母 | ABSTAIN |',
        '|---|---|---:|---:|---:|---:|---:|']
    for group,data in methods.items():
        for method,su in data.items():
            cov=f"{100*su['safe_coverage_common_oracle']:.2f}%"if su['safe_coverage_common_oracle']is not None else'无分母'
            lines.append(f"| {group} | {method} | {su['safe_accepted']} | {su['unsafe_accepted']} | {cov} | {su['oracle_binary_queries']} | {su['ABSTAIN']} |")
    lines +=['',f"ID实际中间任务增益：{gain_summary}。仅计安全中间γ且20ms真实方向进度超过已观察到安全二元基线的配对；binary拒收但B实际安全的比较单列，绝不将ABSTAIN当零命令模拟。明细在TASK_GAIN_PAIRS.json/CSV。",
        f"C/B均无实际安全分支而中间动作安全：{middle_only_summary}；这类动作集扩展不预设存在。解析[0,32]mm上的{len(intervals)}个区间，完整γ真实可行集、二元/五动作最大γ及实际20ms进度在ACTION_CHANGE_INTERVALS.json。",
        f"能力消融：{result['capacity_ablation_extra_benefit']}，两配置选择不同{ablation_differences}个共享查询；不根据TEST选择赢家。STEP28 prior额外收益仍为NOT_ESTABLISHED，本轮没有PID prior或历史重训。",
        f"CHALLENGE主配置：{methods['CHALLENGE'].get('CAPACITY_CONDITIONAL')}。原物理、local、终端、数值未完成错误分别保留且可能重叠；pose拒收按每动作披露：{dict(pose_rejections)}。拒收不计安全命令、不把挑战重新划为ID。",'',
        '## 绝对20ms按需执行','',
        '计时始于输入准备。solver limit=min(6ms,剩余−3ms)，不足1ms不启动solver，prefix前剩余不足3ms不启动。lazy先C，认可及时则不请求B；否则真实B后降序.75/.5/.25/0停止于首个认可动作。BINARY_EAGER/BINARY_LAZY限制{1,0}；工程顺序按ordinal轮换。',
        '所需验证和最小numeric拷贝在出令计时内；JSON/哈希/文件落盘在计时后。每行真实C/B raw变量、共享矩阵、γ变量、sentτ、prefix arrays、门控/邻居/QP身份均保存在online/<context>/<policy>.json。早返回B明确NOT_REQUESTED，不从teacher补入。过期有效命令标COMPUTED_VALID_BUT_LATE，不发送、不模拟；预算截断标NOT_EVALUATED_BUDGET，不推断不可恢复。',
        '| 策略 | 及时认可/54 | 命令可用 | raw有效但过期 | 全部超时 | 未请求B | QP调用 | p99 / max(ms) |',
        '|---|---:|---:|---:|---:|---:|---:|---|']
    for policy in('BINARY_EAGER','BINARY_LAZY','GOVERNOR_LAZY'):
        d=eng[policy];lat=d['all_latency_ms'];lines.append(f"| {policy} | {d['timely_recognized_sent']} | {d['command_available']} | {d['raw_valid_but_late']} | {d['overall_deadline_failure']} | {d['unrequested_B']} | {d['QP_calls']} | {lat['p99']} / {lat['max']} |")
    lines +=['',f"全计划工程明细：{eng['all']}。出令丢弃超时不把输入变成成功；reference命令不替代在线命令。startup：{result['startup']}。",
        f"固定12 fresh反馈：{fr}。仅实际及时认可发送才传播，不替换ABSTAIN/资格失败；全部tick含完整首槽决策耗时和后续6ms solver限，首命令一致性与501原物理/local/terminal评价独立保存。单次决策后feedback backup不是持续shield或全局viability。",'',
        '## 预算、交付与研究定位','',f"最终预算：{finished['budget']}。真实QP/return/prefix/actual/reference/priming全部记同一账本；未回报/步预留不能消失。",
        '首段在35个TEST输入的逐条结果完成后，聚合registry编码发生MemoryError。PERSISTENCE_REPAIR.md与persistence_continuation_01/保存原中断、停止状态和临时文件；只缩小聚合索引，不改数值kernel、冻结模型或输入/动作/阈值。35个已完成输入不重跑，续行只执行19个未启动输入及原定工程/fresh。新进程4次priming同样计账，模型不重训，原2小时起点保持，修复停顿计时。',
        '必要纯测试见TEST_RESULTS.md，数值输出按处理立即持久化；一次当前文件核验见FINAL_FILE_VERIFICATION.json，提交范围见GIT_DELIVERY.json。未push或reset原HEAD，未修改历史结果，未访问隔离项目。',
        '图沿用scipilot规范，展示完整五动作可行集与任务进度、全工程时延，不挑单gap或隐藏慢输入。当前方法定位为执行器能力/反馈恢复条件下有限动作集的任务调节；插值与经验储备本身不主张首创。参照[command governor综述](https://merl.com/publications/docs/TR2016-102.pdf)和[backup CBF比较研究](https://arxiv.org/abs/2104.11332)。本轮固定证据决定是否支持动作集收益，不转写未建立结果。', '',
        '```ini','AUTHORIZE_STEP29_RECOVERABILITY_ACTION_GOVERNOR = TRUE','AUTHORIZE_CHECKED_NONOPTIMAL_CONVEX_COMMANDS = TRUE',
        'GAMMA_GRID = 1,0.75,0.5,0.25,0',f"NUMERICAL_STATUS = {finished['status']}",f"SCIENCE_STATUS = {science}",f"ENGINEERING_STATUS = {engineering}",
        f"GOAL_ID_SAFETY_COVERAGE = {str(safety_coverage).upper()}",f"GOAL_ACTUAL_MIDDLE_TASK_GAIN = {str(task_gain).upper()}",
        'MAX_NEW_QP_CALLS = 24000','MAX_NEW_PHYSICS_STEPS = 240000','MAX_NUMERICAL_WALL_HOURS = 2',
        'MAX_MODEL_CONFIGURATIONS = 2','MAX_DEV_CONTEXT_RECOMPUTATIONS = 5','PLANNED_NEW_TEST_CONTEXTS = 54',
        'MAX_NEW_DEV_INTERMEDIATE_TRAJECTORIES = 108','POST_NEW_TEST_TUNING = FALSE','DEADLINE_MS = 20',
        'SOLVER_TIME_LIMIT_UPPER_S = 0.006','BACKUP_HORIZON_S = 1','DENSE_PHYSICS_DT_S = 0.002',
        'PHYSICAL_AND_TERMINAL_BOUNDS_UNCHANGED = TRUE','HISTORICAL_RESULTS_UNCHANGED = TRUE',
        'MISSING_HISTORICAL_EVIDENCE_REPLAY = FALSE','E3_RL_HARDWARE = NOT_AUTHORIZED','```','']
    (out/'STEP29_REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
    (out/'STEP29_RESEARCH_HANDOFF.md').write_text('\n'.join(['# STEP29研究交接','',f"Run ID：{manifest['run_id']}",
        f"Science：{science}",f"Engineering：{engineering}",'',
        'MODEL_FREEZE.json：2个预声明配置，CAPACITY_CONDITIONAL为主；二元同模型零重训。源26/27/28全部为DEV，历史缺全变量不补造。',
        'TEST_REGISTRY与CASE_RESULTS：先冻结预测、后独立实际五动作；TASK_GAIN_PAIRS保留真实进度和二元比较类型；多gap共享轨迹，不是独立重复。',
        'online/逐行完整numeric才是工程时延与出令证据，reference只作科学配对。fresh/才是实际有界1s反馈；过期命令不发送，拒收不冒充安全。',
        f"目标完成：ID安全覆盖={safety_coverage}；实际中间任务增益={task_gain}。",
        f"ID：{main}",f"CHALLENGE：{methods['CHALLENGE'].get('CAPACITY_CONDITIONAL')}",
        'STEP28 prior额外收益NOT_ESTABLISHED保持不变。若主目标未达，保留新动作可行/实际收益/拒收证据，不通过重训或选择新gap制造通过。',
        '后续研究须新授权并预声明新DEV/CAL/TEST；不改本轮模型、grid、20ms、1s、物理或终端阈值。不重跑历史，不进入E3/RL/硬件，不访问机器人运控算法。','']),encoding='utf-8')
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('out');r=report(p.parse_args().out);print(r['SCIENCE_STATUS'],r['ENGINEERING_STATUS'])
