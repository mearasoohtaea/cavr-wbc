"""Independent compact STEP29 rollouts using one resident feedback kernel.

The resident kernel owns both WBCs, servos and MuJoCo buffers.  A branch resets
its backup buffer exactly once; all later control slots advance the same state
and retain the policy's integral and solver warm-start memory.  Numeric facts
and detailed serialization happen after command-ready, never in its timing.
"""
from __future__ import annotations

from copy import deepcopy
from time import perf_counter

import mujoco
import numpy as np

from cavr_wbc.control.step23_backup_filter import (
    CHECKPOINT_STEPS, CONTROL_DT_S, CONTROL_SLOTS, HOLD_VERSION,
    PHYSICS_DT_S, PHYSICS_STEPS, PHYSICS_STEPS_PER_SLOT, _finite_state,
    _json_safe, state_values,
)
from cavr_wbc.control.step25_capacity_backup import (
    CAPACITY_VERSION, _health_limits, _ledger_wall_s,
    _metadata, capacity_command,
)
from cavr_wbc.experiments import step26_sim as source


VERSION = "STEP29_RESIDENT_DENSE_TRAJECTORIES_V1"
restore_snapshot = source.restore_snapshot
reference_episode = source.reference_episode
preview = source.preview
compact_fact = source.compact_fact
_check = source._check
_observer = source._observer
_budget_call = source._budget_call


def _copy_ledger(response, *, branch_id, kind, slot, bid):
    """Copy only this call's buffered records, not a resident solver's history."""
    return [dict(row, branch_id=branch_id, kind=kind, slot=slot, backup_id=bid)
            for row in response.get("solver_ledger_delta", [])]


def _kernel_counts(kernel):
    controller = getattr(kernel, "backup_controller", None)
    servo = getattr(kernel, "backup_servo", None)
    return {"contact_linearization_calls": int(getattr(controller, "contact_linearization_calls", 0)),
            "svd_calls": int(getattr(controller, "svd_calls", 0)),
            "passive_model_calls": int(getattr(controller, "passive_model_calls", 0)),
            "integral_updates": int(getattr(servo, "integral_update_calls", 0))}


def _control_row(slot, source_name, tau, data, health, interface, response, raw_wb,
                 valid, ready_ms, candidate=None):
    row = source._control_row(slot, source_name, tau, data, health, interface,
                              response, raw_wb, valid, ready_ms)
    row.update(command_ready_ms=float(ready_ms), deadline_ms=20.,
               within_online_deadline=bool(valid and ready_ms <= 20.),
               command_unavailable=not bool(valid),
               ready_command_reused=False)
    if response is not None:
        row["pre_send_validation"] = deepcopy(response.get("pre_send_validation"))
        row["kernel_timing"] = deepcopy(response.get("timing"))
        row["solver_time_limit_s"] = response.get("solver_time_limit_s")
    elif candidate is not None:
        row["pre_send_validation"] = deepcopy(candidate.get("pre_send_validation"))
        row["kernel_timing"] = deepcopy(candidate.get("timing"))
        row["solver_time_limit_s"] = candidate.get("solver_time_limit_s")
    return row


def _empty_branch(model, current, context, kind, mode, metadata, anchor, begin, reason):
    return {"schema": VERSION, "status": "FAILED_NUMERICAL", "reason": {"reason": reason},
            "kind": kind, "branch_id": context.get("branch_id", context["context_id"] + ":" + kind),
            "first_mode": "CANDIDATE" if mode == "C" else "BACKUP", "backup_id": context["backup_id"],
            "fixed_anchor_q_init": anchor.tolist(), **metadata, "initial_fact": None,
            "initial_state": state_values(model, current), "final_state": state_values(model, current),
            "controls": [], "physics_trajectory": [], "checkpoints": [], "solver_ledger": [],
            "elapsed_ms": (perf_counter() - begin) * 1000., "initialization_ms": 0.,
            "first_backup_decision_ms": 0., "skipped_candidate_invalid": mode == "C",
            "counts": {"physical_steps": 0, "backup_qp_calls": 0, "control_qp_calls": 0,
                       "clone_data_calls": 0, "backup_controller_instances": 0,
                       "backup_policy_resets": 0}}


def _validate_ready(response, health, limits):
    """A precomputed first command must retain the raw/status/clip contract."""
    raw_wb = response.get("wbc", response.get("raw_solver_result", {}))
    saved = response["capacity_interface"]
    rebuilt = capacity_command(saved["tau_raw"], health, limits, raw_wb.get("status_val"))
    valid = bool(response["valid_command"])
    if (not np.array_equal(saved["health_vector"], health)
            or valid != bool(saved["command_valid"])
            or not np.array_equal(response["tau_cmd"], saved["tau_sent"])
            or (valid and (not rebuilt["command_valid"]
                          or not np.array_equal(response["tau_cmd"], rebuilt["tau_sent"])))):
        raise ValueError("STEP29 ready first command differs from the frozen capacity contract")
    record = response["integral_record"]
    if not np.array_equal(record["b_used"], np.zeros(6)):
        raise ValueError("STEP29 first backup response must originate from the fixed zero integral")


def actual_branch(model, current, context, candidate, mode, kind, budget, kernel,
                  ready_response=None):
    """Propagate an independent dense C/B actual branch without looking at labels.

    A C branch applies its fresh nominal candidate for its first 20 ms and solves
    49 feedback backups.  B solves 50; if its already-timed first response is
    provided, that exact command and its updated memory are reused once.  All
    control calls inherit the kernel's fixed resident/budgeted solver settings.
    Physical violations remain numeric evidence and do not halt integration.
    """
    if mode not in ("C", "B") or kind not in ("ACTUAL_C", "ACTUAL_B", "PREDICTION_C", "PREDICTION_B"):
        raise ValueError("STEP29 needs explicit matching C/B mode and actual/prediction kind")
    if not kind.endswith("_" + mode):
        raise ValueError("STEP29 branch kind does not match first control mode")
    if ready_response is not None and mode != "B":
        raise ValueError("STEP29 ready backup response may only seed a B branch")
    _check(budget)
    begin = perf_counter()
    bid = context["backup_id"]
    branch_id = context.get("branch_id", context["context_id"] + ":" + kind)
    first_mode = "CANDIDATE" if mode == "C" else "BACKUP"
    limits = np.asarray(kernel.healthy_limits, dtype=float)
    health, _, _ = _health_limits(context["health_vector"], limits)
    if health.shape != (int(model.nu),) or limits.shape != (int(model.nu),):
        raise ValueError("STEP29 branch health/capacity differs from model.nu")
    metadata = _metadata(context, health)
    anchor = np.asarray(context["backup_anchor_q_init"], dtype=float).copy()
    if anchor.shape != (int(model.nq),) or not np.isfinite(anchor).all():
        raise ValueError("STEP29 branch's immutable backup anchor is invalid")
    if mode == "C" and not candidate.get("command_valid"):
        return _empty_branch(model, current, context, kind, mode, metadata, anchor,
                             begin, "INVALID_CANDIDATE_COMMAND")
    interface_c = _candidate_interface(candidate, health, limits) if mode == "C" else None
    counts_before = _kernel_counts(kernel)
    if ready_response is not None:
        _validate_ready(ready_response, health, limits)
    kernel.reset_backup(current, context, preserve_ready=ready_response is not None)
    data = kernel.backup_data
    if abs(float(data.time)) > 1e-12:
        raise ValueError("STEP29 independent branch must restore relative clock zero")
    observer_kind = "PREDICTION" if kind.startswith("PREDICTION") else "ACTUAL"
    observer = _observer(budget, observer_kind, branch_id)
    initial = state_values(model, data)
    initialization_ms = (perf_counter() - begin) * 1000.
    controls, physics, checkpoints, ledger = [], [], [], []
    steps = action_forward = refresh = 0
    failure = None
    first_backup_ms = 0.
    initial_fact = None
    control_ms = integration_s = refresh_s = fact_s = 0.
    for slot in range(CONTROL_SLOTS):
        _, guard_failure = _budget_call(lambda: _check(budget))
        if guard_failure is not None:
            failure = dict(guard_failure, slot=slot, physics_step=steps)
            break
        if not _finite_state(data):
            failure = {"reason": "NONFINITE_STATE_BEFORE_CONTROL", "slot": slot, "physics_step": steps}
            break
        response = None
        if slot == 0 and mode == "C":
            interface = interface_c
            tau = np.asarray(interface["tau_sent"], dtype=float)
            raw_wb = candidate.get("raw_solver_result", {})
            valid = True
            ms = float(candidate.get("command_ready_ms", candidate.get("generation_ms", 0.)))
            action_ref = candidate.get("response", {}).get("a_base_ref", [])
            action = float(action_ref[0]) if len(action_ref) else 0.
            source_name = "FIXED_CANDIDATE_TAU_20MS"
        else:
            if slot == 0 and ready_response is not None:
                response = ready_response
            else:
                response, guard_failure = _budget_call(lambda: kernel.compute_backup(
                    context, slot, budget=budget, kind=kind, owner=branch_id))
                if guard_failure is not None:
                    # The budget object preserves START/RETURN even if the
                    # control interface cannot return a serializable response.
                    failure = dict(guard_failure, slot=slot, physics_step=steps)
                    break
            interface = response["capacity_interface"]
            raw_wb = response.get("wbc", response.get("raw_solver_result", {}))
            tau = np.asarray(response["tau_cmd"], dtype=float)
            valid = bool(response["valid_command"])
            ms = float(response["command_ready_ms"])
            action_ref = response.get("a_base_ref", [])
            action = float(action_ref[0]) if len(action_ref) else 0.
            source_name = "FEEDBACK_BACKUP_QP_TOTAL" if valid else "INVALID_BACKUP_QP"
            control_ms += ms
            if slot == 0:
                first_backup_ms = ms
            ledger.extend(_copy_ledger(response, branch_id=branch_id, kind=kind, slot=slot, bid=bid))
        # The kernel has already validated command-ready; this forward and
        # evidence extraction are execution/persistence, not hidden decision work.
        data.ctrl[:] = tau
        mujoco.mj_forward(model, data)
        action_forward += 1
        row = _control_row(slot, source_name, tau, data, health, interface, response,
                           raw_wb, valid, ms, candidate=candidate if slot == 0 and mode == "C" else None)
        row["ready_command_reused"] = bool(slot == 0 and ready_response is not None)
        row["first_candidate_reused"] = bool(slot == 0 and mode == "C")
        row["kernel_version"] = getattr(kernel, "version", getattr(kernel, "kernel_name", None))
        row["solver_time_limit_s"] = getattr(kernel, "solver_time_limit_s", None)
        controls.append(row)
        if _finite_state(data):
            t = perf_counter()
            fact = compact_fact(model, data, health, limits, tau, action, ms, steps,
                                slot, bid, branch_id, interface, metadata)
            fact_s += perf_counter() - t
            if slot == 0:
                initial_fact = fact
                checkpoints.append(dict(fact, checkpoint_index=0, checkpoint_target_s=0.))
        else:
            failure = {"reason": "NONFINITE_STATE_AFTER_COMMAND_FORWARD", "slot": slot, "physics_step": steps}
        if not valid:
            failure = {"reason": "INVALID_BACKUP_QP", "slot": slot, "physics_step": steps,
                       "solver_status": raw_wb.get("status"), "solver_status_val": raw_wb.get("status_val")}
        if failure:
            break
        for _ in range(PHYSICS_STEPS_PER_SLOT):
            if observer is not None:
                _, guard_failure = _budget_call(observer)
                if guard_failure is not None:
                    failure = dict(guard_failure, slot=slot, physics_step=steps)
                    break
            t = perf_counter()
            mujoco.mj_step(model, data)
            steps += 1
            integration_s += perf_counter() - t
            if not _finite_state(data) or abs(float(data.time) - steps * PHYSICS_DT_S) > 1e-9:
                failure = {"reason": "NONFINITE_STATE_OR_SIMULATOR_RESET_AFTER_STEP", "slot": slot, "physics_step": steps}
            else:
                t = perf_counter()
                mujoco.mj_forward(model, data)
                refresh += 1
                refresh_s += perf_counter() - t
                if not _finite_state(data):
                    failure = {"reason": "NONFINITE_STATE_AFTER_INTEGRATION_REFRESH", "slot": slot, "physics_step": steps}
            if failure:
                physics.append({"time_s": steps * PHYSICS_DT_S, "physics_step": steps,
                                "numerical_failure": failure, "state": state_values(model, data)})
                break
            t = perf_counter()
            fact = compact_fact(model, data, health, limits, tau, action, ms, steps,
                                slot, bid, branch_id, interface, metadata)
            fact_s += perf_counter() - t
            physics.append(fact)
            if steps in CHECKPOINT_STEPS:
                checkpoints.append(dict(fact, checkpoint_index=len(checkpoints),
                                        checkpoint_target_s=steps * PHYSICS_DT_S))
        if failure:
            break
    complete = steps == PHYSICS_STEPS and len(controls) == CONTROL_SLOTS and failure is None
    status = "COMPLETE" if complete else "FAILED_BUDGET" if failure and failure["reason"] == "GLOBAL_BUDGET_EXHAUSTED" else "FAILED_NUMERICAL"
    deltas = {key: value - counts_before[key] for key, value in _kernel_counts(kernel).items()}
    latency = [float(row["command_ready_ms"]) for row in controls]
    return _json_safe({"schema": VERSION, "status": status, "reason": failure,
        "kind": kind, "branch_id": branch_id, "first_mode": first_mode, "backup_id": bid,
        "backup_version": HOLD_VERSION, "capacity_interface_version": CAPACITY_VERSION,
        "kernel_version": getattr(kernel, "version", getattr(kernel, "kernel_name", None)),
        "solver_time_limit_s": getattr(kernel, "solver_time_limit_s", None),
        "fixed_anchor_q_init": anchor.tolist(), **metadata, "initial_state": initial,
        "initial_fact": initial_fact, "final_state": state_values(model, data), "controls": controls,
        "physics_trajectory": physics, "checkpoints": checkpoints, "solver_ledger": ledger,
        "initialization_ms": initialization_ms, "first_backup_decision_ms": first_backup_ms,
        "elapsed_ms": (perf_counter() - begin) * 1000.,
        "feedback_latency_ms": latency, "all_available_ticks_within_20ms": bool(controls and
            all(row["within_online_deadline"] for row in controls)),
        "counts": {"physical_steps": steps, "backup_qp_calls": len(ledger),
                   "control_qp_calls": len(ledger), "clone_data_calls": 0,
                   "backup_controller_instances": 0, "backup_policy_resets": int(ready_response is None),
                   "action_conditioned_forward_calls": action_forward,
                   "integration_refresh_forward_calls": refresh, **deltas},
        "timing": {"control_total_ms": control_ms, "solver_wall_s": _ledger_wall_s(ledger),
                   "integration_s": integration_s, "integration_refresh_s": refresh_s,
                   "physical_fact_extraction_s": fact_s}})


def _candidate_interface(candidate, health, limits):
    """New opt-in validated synthetic sender, without pretending Solved."""
    interface = candidate["capacity_interface"]
    if not candidate.get("command_valid"):
        raise ValueError("STEP29 first action unavailable")
    tau = np.asarray(candidate["tau_raw"], dtype=float)
    sent = np.asarray(candidate["tau_sent"], dtype=float)
    cap = np.asarray(health) * np.asarray(limits)
    if (tau.shape != cap.shape or sent.shape != cap.shape or not np.isfinite(tau).all()
            or not np.isfinite(sent).all() or not np.array_equal(sent, np.clip(tau,-cap,cap))):
        raise ValueError("STEP29 first action capacity identity mismatch")
    if candidate.get("kind") == "SYNTHESIZED_CONVEX_COMMAND":
        if (candidate.get("solver_status_val") is not None
                or not candidate.get("hard_validation_pass")
                or any(candidate.get("source_solver_statuses",{}).get(k) != 1 for k in ("C","B"))):
            raise ValueError("STEP29 synthesized first action lacks checked endpoint proof")
    elif candidate.get("solver_status_val") != 1:
        raise ValueError("STEP29 endpoint first action not exact Solved")
    return interface


def candidate_view(action, context, command_ready_ms=None):
    """A physical first action view with explicit synthetic/source status."""
    health = np.asarray(context["health_vector"],float)
    interface = dict(action.get("capacity_interface") or {})
    limits = np.asarray(interface.get("healthy_torque_limits_nm"),float)
    raw = np.asarray(action.get("tau_raw"),float) if action.get("tau_raw") is not None else None
    sent = np.asarray(action.get("tau_sent"),float) if action.get("tau_sent") is not None else np.zeros_like(health)
    cap = health * limits if limits.shape == health.shape else np.zeros_like(health)
    valid = bool(action.get("command_valid"))
    interface.update(tau_raw=raw,tau_sent=sent,health_vector=health,effective_capacity_nm=cap,
        raw_command_within_capacity_exact=bool(raw is not None and np.all(np.abs(raw)<=cap)),
        sent_command_within_capacity_exact=bool(valid and np.all(np.abs(sent)<=cap)),
        raw_99_percent_active_indices=np.flatnonzero((cap<=0)|(np.abs(raw)>=.99*cap)) if raw is not None else [],
        sent_99_percent_active_indices=np.flatnonzero((cap<=0)|(np.abs(sent)>=.99*cap)))
    return {**action,"tau":sent,"tau_sent":sent,"capacity_interface":interface,"health_vector":health,
        "raw_solver_result":{"status":action.get("kind"),"status_val":action.get("solver_status_val"),
            "qdd":action.get("qdd"),"tau":raw,"contact_force":action.get("contact_lambda"),
            "source_solver_statuses":action.get("source_solver_statuses")},
        "response":{"a_base_ref":action.get("a_base_ref")},
        "command_ready_ms":float(action.get("command_ready_ms",0.) if command_ready_ms is None else command_ready_ms)}


def actual_action_branch(model,current,context,action,kind,budget,kernel,ready_response=None):
    gamma = float(action["gamma"])
    mode = "B" if gamma == 0. else "C"
    branch_context = dict(context,branch_id=context["context_id"]+":G"+format(gamma,"g"))
    result = actual_branch(model,current,branch_context,candidate_view(action,context),
        mode,"ACTUAL_"+mode,budget,kernel,ready_response=ready_response if mode=="B" else None)
    result.update(kind="ACTUAL_"+mode,gamma=gamma,first_action_kind=action.get("kind"),
        action_source_QP_statuses=action.get("source_solver_statuses"),
        synthesized_action_not_optimizer_return=0.<gamma<1.,
        branch_id=context["context_id"]+":G"+format(gamma,"g"))
    return result
