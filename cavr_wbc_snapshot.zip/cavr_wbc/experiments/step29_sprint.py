"""One fixed STEP29 action-set DEV and new reference/online experiment."""
import argparse
from copy import deepcopy
from datetime import datetime,timezone
import gc
import hashlib
import json
import math
import os
from pathlib import Path
from time import perf_counter
import traceback
import numpy as np
from cavr_wbc.experiments import step17_formal_panel as frozen
from cavr_wbc.experiments import step26_sim as reference_sim
from cavr_wbc.experiments import step29_sim as sim
from cavr_wbc.experiments.step29_budget import SprintBudget,SprintLimit
from cavr_wbc.experiments.step29_data import load_sources,fixed_mid_DEV,role,missing
from cavr_wbc.experiments.step26_features_storage import save_bank
from cavr_wbc.control.step29_actions import GAMMA_GRID,make_action,convex_command_property
from cavr_wbc.control.step29_kernel import Kernel
from cavr_wbc.control.step29_margin import labels,fit_fixed,decide,safe,gamma_key,GAPS_M
from cavr_wbc.control.step28_physics_residual import append_prefix_features,load_bundle as load28,decide as decide28
from cavr_wbc.experiments.step28_sprint import home_context
from cavr_wbc.platforms.go2_mujoco import extract_actuator_audit
from cavr_wbc.experiments.step21_report import csv_write

ROOT=Path(__file__).resolve().parents[2]
SOURCE28=ROOT/'artifacts/step28_physics_residual_20261008/step28-physics-residual-20261008-01'
PARENT='651cd5f3c625d70d105dc44462ae941fad4ab538'
PROTOCOL=Path('E:/CAVR-WBC/experiment_handoff_20260921/NEXT_CODEX_INSTRUCTIONS_STEP29_RECOVERABILITY_ACTION_GOVERNOR_20261008.md')
DLL=SOURCE28/'native/step28_prefix.dll'
KINDS=('HEALTHY','THIGH_15','CALF_15')
EPISODES=(('T29_P052',.052,.003,.003,20261176,'ID'),('T29_N052',-.052,.003,.003,20261176,'ID'),
    ('T29_P068',.068,-.003,.003,20261177,'ID'),('T29_N068',-.068,-.003,.003,20261177,'ID'),
    ('T29_P060_C',.06,.0055,.0055,20261178,'CHALLENGE'),('T29_N060_C',-.06,-.0055,.0055,20261178,'CHALLENGE'))


def encode(v):
    if isinstance(v,np.ndarray):return encode(v.tolist())
    if isinstance(v,np.generic):return encode(v.item())
    if isinstance(v,float) and not math.isfinite(v):return {'nonfinite':repr(v)}
    if isinstance(v,dict):return {str(k):encode(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [encode(x) for x in v]
    return v


def write(p,v):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(p.suffix+'.tmp')
    with tmp.open('w',encoding='utf-8',newline='\n') as f:json.dump(encode(v),f,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False);f.write('\n')
    os.replace(tmp,p)


def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def freeze(v):return json.loads(json.dumps(encode(v),allow_nan=False))


def inputs_for_action(kernel,c,action,budget):
    entry={'gamma':action['gamma'],'role':role(c),'features23':None,'first_command_valid':bool(action['command_valid']),
        'prefix':{'complete':False,'available':False,'original_physical_pass':False,'reason':'ACTION_UNAVAILABLE'}}
    if action['command_valid']:
        kernel.condition_action(c,action);entry['prefix']=kernel.prefix_action(c,action,budget)
        try:entry['features23']=kernel.features(c,action,entry['prefix'])
        except (ValueError,TypeError,KeyError) as exc:entry['feature_error']=str(exc)
    return entry


def make_record(item,g,entry,label):
    return {'id':item['id']+':G'+gamma_key(g),'context':item['context'],'ctx':item['context'],
        'source_snapshot':item['source_snapshot'],'episode':item['episode'],'split':item['split'],
        'gamma':g,'role':item['role'],'features23':entry['features23'],'prefix':entry['prefix'],
        'first_command_valid':entry['first_command_valid'],'labels':label}


def dev(out,kernel,items,budget):
    records=[];index=[]
    for item in items:
        c=item['context'];mats=kernel.assemble_saved_matrices(c)
        for g in (1.,0.):
            action=make_action(c,item['endpoints']['C'],item['endpoints']['B'],g,mats)
            entry=inputs_for_action(kernel,c,action,budget)
            record=freeze(make_record(item,g,entry,item['labels'][gamma_key(g)]))
            path=out/'DEV'/item['id']/('G'+gamma_key(g)+'_endpoint.json')
            write(path,{'record':record,'action':action,'source_paths':item['source_paths'],
                'old_actual_trajectory_reused':True,'old_endpoint_QP_not_recomputed':True})
            records.append(record);index.append({'id':record['id'],'path':str(path.relative_to(out)),
                'gamma':g,'split':item['split'],'role':item['role'],'reused_endpoint':True})
        budget.persist(phase='OLD_ENDPOINT_FEATURES',records=len(records),last_context=item['id'])
    selected=fixed_mid_DEV(items)
    write(out/'DEV_MID_FIXED_REGISTRY.json',[{'id':i['id'],'split':i['split']}for i in selected])
    for item in selected:
        c=item['context'];mats=kernel.assemble_saved_matrices(c)
        for g in (.75,.5,.25):
            action=make_action(c,item['endpoints']['C'],item['endpoints']['B'],g,mats)
            entry=inputs_for_action(kernel,c,action,budget);lab=missing('MIXED_ACTION_UNAVAILABLE')
            directory=out/'DEV'/item['id']/('G'+gamma_key(g))/'attempt01'
            write(directory/'CURRENT_INPUT.json',{'context':c,'action':action,'entry':entry,'labels_not_read_for_features':True})
            artifact=None
            if action['execution_eligible']:
                branch=sim.actual_action_branch(kernel.model,kernel.data,c,action,'ACTUAL_GAMMA',budget,kernel)
                artifact=save_bank(directory/'actual.npz',branch);lab=labels(branch,c)
                write(directory/'CONTROL_RESULTS.json',{'controls':branch['controls'],'status':branch['status'],'reason':branch.get('reason')})
                if branch['status']=='FAILED_BUDGET':write(directory/'RESULT.json',{'action':action,'labels':lab,'artifact':artifact});raise SprintLimit('DEV partial saved')
            record=freeze(make_record(item,g,entry,lab));write(directory/'RESULT.json',{'record':record,'artifact':artifact,
                'action_available':action['available'],'unavailable_reason':action.get('unavailable_reason'),'endpoint_labels_reused_not_recomputed':True})
            records.append(record);index.append({'id':record['id'],'path':str((directory/'RESULT.json').relative_to(out)),
                'gamma':g,'split':item['split'],'role':item['role'],'reused_endpoint':False,'artifact':artifact})
            write(out/'DEV_SPLIT_REGISTRY.json',index)
            budget.persist(phase='NEW_DEV_MIDDLE_ACTION',records=len(records),last_context=item['id'],gamma=g)
    write(out/'DEV_SPLIT_REGISTRY.json',index)
    return records


def source_context(snapshot,kind,mapping,ordinal,group):
    c=deepcopy(snapshot);side='FR' if c.get('direction',0)>0 else 'RR';cid=c['snapshot_id']+'_'+kind
    hv=[1.]*12;name='NONE';ix=None;h=1.
    if kind!='HEALTHY':
        joint,number=kind.split('_');name=side+'_'+joint.lower();ix=next(r['actuator_index'] for r in mapping if r['actuator_name']==name);h=int(number)/100.;hv[ix]=h
    c.update(context_id=cid,case_id=cid,backup_id='STEP29-'+cid,health_vector=hv,health_kind=kind,
        faulted_actuator_name=name,faulted_actuator_index=ix,faulted_health=h,ordinal=ordinal,group=group)
    return c


def legacy_direct_choice(bundle,c,C,entries,gap):
    if C.get('features16') is None:return {'choice':'ABSTAIN','reason':'OLD_CURRENT_FEATURES_UNAVAILABLE'}
    branches={}
    for g,mode in ((1.,'C'),(0.,'B')):
        inp=entries.get(gamma_key(g),{});p=inp.get('prefix')
        try:features=append_prefix_features(C['features16'],p,inp['action'],context=c)
        except (ValueError,KeyError,TypeError):features=None
        # Generic frozen direct API asks for an unused prior slot. No PID
        # prior is computed or used by kind='direct'; never feed new23 here.
        branches[mode]={'features':features,'prefix':p,'first_command_valid':inp.get('first_command_valid',False),
            'prior':{'D':0.,'T':[0.]*5,'unused_direct_API_slot_not_a_physics_prediction':True}}
    d=decide28(bundle,branches,gap)
    return {'choice':1. if d['choice']=='C' else 0. if d['choice']=='B' else 'ABSTAIN',
        'decision':d,'old22_feature_definitions_retained':True,'PID_prior_calls':0}


def produce(out,kernel,c,fitted,old_direct,budget):
    directory=out/'reference'/c['context_id']/'attempt01'
    e={'context_id':c['context_id'],'context':c,'ordinal':c['ordinal'],'group':c['group'],'episode':c['episode_id'],
        'snapshot_eligible':bool(c.get('eligible')),'actions':{},'inputs':{},'labels':{},'artifacts':{},'predictions':{}}
    if not c.get('eligible'):
        e['labels']={gamma_key(g):missing('SOURCE_INELIGIBLE')for g in GAMMA_GRID};write(directory/'RESULT.json',e);return e
    kernel.reset(c);C=kernel.nominal(c,budget,kind='REFERENCE_C',owner=c['context_id'])
    B=kernel.first_backup(c,budget,kind='REFERENCE_B',owner=c['context_id'])
    for g in GAMMA_GRID:
        action=make_action(c,C,B,g);entry=inputs_for_action(kernel,c,action,budget)
        e['actions'][gamma_key(g)]=freeze(action);e['inputs'][gamma_key(g)]=freeze({**entry,'action':action})
    for gap in GAPS_M:
        e['predictions'][str(gap)]={'GOVERNOR':decide(fitted['selected_main'],e['inputs'],gap),
            'BINARY':decide(fitted['selected_main'],e['inputs'],gap,allowed=(1.,0.)),
            'NO_CAPACITY':decide(fitted['nocapacity'],e['inputs'],gap),
            'OLD_DIRECT':legacy_direct_choice(old_direct,c,e['actions']['1'],e['inputs'],gap)}
    write(directory/'CURRENT_INPUT.json',{'context':c,'C':C,'B':B,'actions':e['actions'],'inputs':e['inputs'],
        'predictions':e['predictions'],'all_selections_frozen_before_actual_labels':True})
    for g in (0.,1.,.75,.5,.25):
        key=gamma_key(g);action=e['actions'][key];lab=missing('ACTION_UNAVAILABLE')
        if action['execution_eligible']:
            branch=sim.actual_action_branch(kernel.model,kernel.data,c,action,'ACTUAL_GAMMA',budget,kernel,ready_response=B if g==0. else None)
            e['artifacts'][key]=save_bank(directory/('G'+key+'.npz'),branch);lab=labels(branch,c)
            write(directory/('G'+key+'_CONTROL_RESULTS.json'),{'controls':branch['controls'],'status':branch['status'],'reason':branch.get('reason')})
            if branch['status']=='FAILED_BUDGET':e['labels'][key]=lab;write(directory/'RESULT.json',e);raise SprintLimit('new reference partial saved')
        e['labels'][key]=lab;write(directory/'RESULT.json',e)
        budget.persist(phase='REFERENCE_ACTION_SAVED',owner=c['context_id'],gamma=g)
    return freeze(e)


def batch(out,kernel,m,fitted,old_direct,budget):
    budget.event('NEW_TEST_OPEN',model_freeze_sha256=sha(out/'models/MODEL_FREEZE.json'));registry=[]
    for eid,d,r,p,seed,group in EPISODES:
        scenario=deepcopy(m['scenario']);scenario.update(seed=seed,initial_roll=scenario['initial_roll']+r,initial_pitch=scenario['initial_pitch']+p)
        episode=reference_sim.reference_episode(kernel.model,scenario,d,eid,(25,35,55),budget)
        write(out/'episodes'/(eid+'.json'),episode);found={s['source_tick']:s for s in episode['snapshots']}
        for tick in (25,35,55):
            snap=found.get(tick,{'snapshot_id':eid+f'_T{tick:03d}','episode_id':eid,'source_tick':tick,
                'direction':1 if d>0 else -1,'eligible':False,'eligibility_reason':'REFERENCE_INCOMPLETE'})
            for kind in KINDS:
                c=source_context(snap,kind,m['mapping'],len(registry),group)
                try:e=produce(out,kernel,c,fitted,old_direct,budget)
                except BaseException as exc:
                    write(out/'reference'/c['context_id']/'attempt01'/'EXCEPTION.json',{'error':str(exc),'type':type(exc).__name__,
                        'traceback':traceback.format_exc(),'budget':budget.snapshot()});raise
                registry.append(e);write(out/'TEST_REGISTRY.json',registry)
                budget.persist(phase='NEW_REFERENCE',contexts=len(registry),last_context=c['context_id'])
                if len(registry)%3==0:print(json.dumps({'phase':'REFERENCE','contexts':len(registry),'budget':budget.snapshot()}),flush=True)
                gc.collect()
    return registry


def choice_truth(e,choice,gap):return choice!='ABSTAIN' and safe(e['labels'].get(gamma_key(choice),{}),gap)


def evaluate(out,registry):
    rows=[];intervals=[]
    for e in registry:
        if not e['snapshot_eligible']:
            allinputs={};preds={};pass
        points=set([0.,.032])
        for lab in e['labels'].values():
            if lab.get('D') is not None and 0<=lab['D']<=.032:points.add(lab['D'])
        for d in e['predictions'].values():
            for p in d.get('GOVERNOR',{}).get('predictions',{}).values():
                u=p.get('U_D')
                if u is not None and 0<=u<=.032:points.add(u)
        ordered=sorted(points)
        for left,right in zip(ordered,ordered[1:]):
            gap=(left+right)/2;feasible=[g for g in GAMMA_GRID if safe(e['labels'].get(gamma_key(g),{}),gap)]
            intervals.append({'context_id':e['context_id'],'group':e['group'],'left_m':left,'right_m':right,
                'actual_feasible_gamma':feasible,'binary_safe_available':any(g in (1.,0.)for g in feasible),
                'middle_only_safe':bool(feasible and not any(g in (1.,0.)for g in feasible))})
        for gap in GAPS_M:
            feasible=[g for g in GAMMA_GRID if safe(e['labels'].get(gamma_key(g),{}),gap)]
            p=e['predictions'].get(str(gap),{})
            one=next((g for g in GAMMA_GRID if e['inputs'].get(gamma_key(g),{}).get('first_command_valid') and
                e['inputs'][gamma_key(g)].get('prefix',{}).get('original_physical_pass') and
                e['inputs'][gamma_key(g)]['prefix'].get('D_prefix_m',float('inf'))<=gap),'ABSTAIN')
            methods={'M0':'1' if e['actions'].get('1',{}).get('command_valid') else 'ABSTAIN',
                'M1_PREFIX':one,'OLD_DIRECT':p.get('OLD_DIRECT',{}).get('choice','ABSTAIN'),
                'BINARY_SAME_MODEL':p.get('BINARY',{}).get('choice','ABSTAIN'),
                'NO_EXPLICIT_CAPACITY':p.get('NO_CAPACITY',{}).get('choice','ABSTAIN'),
                'CAPACITY_CONDITIONAL':p.get('GOVERNOR',{}).get('choice','ABSTAIN'),
                'ORACLE_ALL_GAMMA':max(feasible) if feasible else 'ABSTAIN'}
            for name,choice in methods.items():
                choice=float(choice) if choice!='ABSTAIN' else choice;accepted=choice!='ABSTAIN'
                lab=e['labels'].get(gamma_key(choice),{}) if accepted else {}
                good=choice_truth(e,choice,gap)
                rows.append({'context_id':e['context_id'],'source_snapshot':e['context'].get('snapshot_id'),
                    'episode':e['episode'],'group':e['group'],'role':role(e['context']),'health':e['context']['faulted_health'],
                    'gap_m':gap,'method':name,'choice':choice,'accepted':accepted,'safe_accepted':bool(good),
                    'unsafe_accepted':bool(accepted and not good),'oracle_any_gamma':bool(feasible),
                    'oracle_binary':any(g in (1.,0.)for g in feasible),'middle_only_actual_safe':bool(feasible and not any(g in (1.,0.)for g in feasible)),
                    'physical_error':bool(accepted and lab.get('original_failure')),
                    'local_error':bool(accepted and lab.get('complete') and lab.get('D') is not None and lab['D']>gap),
                    'terminal_error':bool(accepted and lab.get('complete') and not lab.get('terminal_pass')),
                    'numerical_incomplete':bool(accepted and not lab.get('complete')),
                    'progress20_m':lab.get('progress20_m'),'D':lab.get('D'),'Y':lab.get('Y'),
                    'actual_feasible_gamma':feasible,'shared_trajectory_not_independent_query':True})
    write(out/'CASE_RESULTS.json',rows);csv_write(out/'CASE_RESULTS.csv',rows);write(out/'ACTION_CHANGE_INTERVALS.json',intervals)
    return rows


def engineering(out,kernel,registry,bundle,budget):
    policies=('BINARY_EAGER','BINARY_LAZY','GOVERNOR_LAZY');records=[];gap_cycle=(.0015,.0025,.004,.008,.016,.032)
    for e in registry:
        ordinal=e['ordinal'];gap=gap_cycle[ordinal%6];order=policies[ordinal%3:]+policies[:ordinal%3]
        for policy in order:
            if not e['snapshot_eligible']:
                record={'context_id':e['context_id'],'policy':policy,'status':'SOURCE_INELIGIBLE','selected_command_sent':False}
            else:
                record=kernel.governor(e['context'],bundle,gap,policy,budget)
            record.update(ordinal=ordinal,group=e['group'],engineering_order=list(order))
            # The entire raw C/B, synthetic z, prefix numeric and gate payload is
            # saved after its timer. NOT_REQUESTED fields are never filled later.
            write(out/'online'/e['context_id']/(policy+'.json'),record)
            records.append(freeze(record));budget.persist(phase='ONLINE',online_records=len(records))
    write(out/'ONLINE_RESULTS.json',records)
    return records


def fresh(out,kernel,registry,bundle,budget):
    byord={e['ordinal']:e for e in registry};records=[]
    for index,gap in zip((0,4,8,13,17,21,26,30,34,39,43,53),(.0015,.0025,.004,.008,.016,.032)*2):
        e=byord.get(index)
        if not e or not e['snapshot_eligible']:
            result={'index':index,'gap_m':gap,'status':'SOURCE_INELIGIBLE'}
        else:
            c=e['context'];ready=kernel.governor(c,bundle,gap,'GOVERNOR_LAZY',budget)
            result={'index':index,'gap_m':gap,'context_id':c['context_id'],'group':c['group'],'online':ready,'status':'NO_RECOGNIZED_COMMAND_SENT'}
            write(out/'fresh'/c['context_id']/'ONLINE_NUMERIC.json',ready)
            if ready['selected_command_sent']:
                action=ready['selected_action'];action['command_ready_ms']=ready['command_ready_ms'];g=action['gamma'];kernel.set_next_call_limit(.006)
                B=ready['B'] if g==0 else None
                if B is not None:B['command_ready_ms']=B['latency_ms']=ready['command_ready_ms']
                branch=sim.actual_action_branch(kernel.model,kernel.data,c,action,'ACTUAL_GAMMA',budget,kernel,ready_response=B)
                result.update(status=branch['status'],gamma=g,labels=labels(branch,c),
                    artifact=save_bank(out/'fresh'/c['context_id']/'actual.npz',branch),
                    first_command_matches=bool(branch['controls'] and np.array_equal(branch['controls'][0]['tau_sent'],action['tau_sent'])),
                    tick_latency_ms=[r['latency_ms'] for r in branch['controls']],reason=branch.get('reason'))
                write(out/'fresh'/c['context_id']/'CONTROL_RESULTS.json',{'controls':branch['controls'],'status':branch['status']})
                if branch['status']=='FAILED_BUDGET':write(out/'fresh'/c['context_id']/'RESULT.json',result);raise SprintLimit('fresh partial saved')
        records.append(freeze(result));write(out/'FRESH_RESULTS.json',records);budget.persist(phase='FRESH',fresh_records=len(records))
    return records


def run(run_id):
    out=ROOT/'artifacts/step29_action_governor_20261008'/run_id
    if (out/'RUN_STARTED.json').exists():raise FileExistsError('unique STEP29 run required')
    out.mkdir(parents=True,exist_ok=True)
    for name in ('DEV','models','episodes','reference','online','fresh','figures'): (out/name).mkdir(exist_ok=True)
    write(out/'RUN_STARTED.json',{'run_id':run_id,'pid':os.getpid(),'start_utc':datetime.now(timezone.utc).isoformat()})
    budget=SprintBudget(out);budget.start();status='COMPLETED'
    try:
        t=perf_counter();model=frozen.load_model();old=read(SOURCE28/'STEP28_PROTOCOL_AND_MANIFEST.json')
        m={'run_id':run_id,'date':'2026-10-08','timezone':'Asia/Seoul','source_commit':PARENT,'scenario':old['scenario'],
            'mapping':extract_actuator_audit(model),'frozen_physical':old['frozen_physical'],'episodes':EPISODES,
            'gamma_grid':GAMMA_GRID,'gaps_m':GAPS_M,'max_QP':24000,'max_steps':240000,'max_wall_s':7200,
            'deadline_ms':20,'max_configs':2,'max_DEV_recompute':5,'planned_test_contexts':54,
            'ordinal_order':[eid+f'_T{tick:03d}_'+kind for eid,*_ in EPISODES for tick in (25,35,55) for kind in KINDS],
            'protocol_sha256':sha(PROTOCOL),'DLL_sha256':sha(DLL),'post_new_test_tuning':False,'old_solver_or_actual_replays':False}
        files=[*ROOT.glob('cavr_wbc/control/step29*.py'),*ROOT.glob('cavr_wbc/experiments/step29*.py'),*ROOT.glob('tests/test_step29*.py')]
        m['source_sha256']={str(p.relative_to(ROOT)).replace('\\','/'):sha(p)for p in files};write(out/'MANIFEST.json',m)
        with (out/'PROTOCOL_SOURCE.md').open('w',encoding='utf-8',newline='\n') as f:f.write(PROTOCOL.read_text(encoding='utf-8'))
        with (out/'CONVEX_COMMAND_PROPERTY.md').open('w',encoding='utf-8',newline='\n') as f:f.write(convex_command_property()+'\n')
        home=home_context(model,m['scenario']);home.update(context_id='STEP29_HOME_PRIMING',backup_id='STEP29-HOME')
        reference=Kernel(model,'REFERENCE',str(DLL),budget);bounded=Kernel(model,'BOUNDED',str(DLL),budget)
        write(out/'STARTUP.json',{'reference':reference.startup(home,budget),'bounded':bounded.startup(home,budget),'total_ms':(perf_counter()-t)*1000})
        budget.persist(phase='STARTUP')
        items=load_sources(ROOT,m['mapping']);records=dev(out,reference,items,budget)
        fitted=fit_fixed(records,out/'models');budget.fit_count=fitted['actual_multioutput_estimator_fit_calls']
        budget.event('MODELS_FROZEN',fit_calls=budget.fit_count);budget.persist(phase='MODELS_FROZEN')
        oldfreeze=read(SOURCE28/'models/MODEL_FREEZE.json');old_direct=load28(oldfreeze['assets'][oldfreeze['selected_direct_configuration_id']]['npz'])
        registry=batch(out,reference,m,fitted,old_direct,budget);evaluate(out,registry)
        engineering(out,bounded,registry,fitted['selected_main'],budget);fresh(out,bounded,registry,fitted['selected_main'],budget)
    except SprintLimit as exc:
        status='INCOMPLETE_BUDGET';write(out/'INTERRUPTION.json',{'type':'BUDGET','error':str(exc),'budget':budget.snapshot()})
    except BaseException as exc:
        status='STOPPED_IMPLEMENTATION_OR_RESOURCE';write(out/'INTERRUPTION.json',{'type':type(exc).__name__,'error':str(exc),
            'traceback':traceback.format_exc(),'budget':budget.snapshot()});raise
    finally:
        budget.event('NUMERICAL_FINISHED',status=status,**budget.snapshot());budget.close()
        write(out/'RUN_FINISHED.json',{'run_id':run_id,'status':status,'budget':budget.snapshot(),'finish_utc':datetime.now(timezone.utc).isoformat()})
        print(json.dumps({'status':status,'budget':budget.snapshot()}),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('run_id');run(p.parse_args().run_id)
