"""One final current-file/numeric identity closure, without historical replay."""
import argparse
from collections import Counter
import json
from pathlib import Path
import numpy as np
from cavr_wbc.experiments.step29_sprint import ROOT,read,write,sha
from cavr_wbc.control.step29_margin import gamma_key,GAMMA_GRID


def verify(out):
    out=Path(out)
    if(out/'FINAL_FILE_VERIFICATION.json').exists():raise FileExistsError('one final closure only')
    failures=[];checks={};counts=Counter()
    def check(name,condition,detail=None):
        checks[name]={'pass':bool(condition),'detail':detail}
        if not condition:failures.append(name)
    manifest=read(out/'MANIFEST.json');finish=read(out/'RUN_FINISHED.json');budget=finish['budget']
    check('source_numerical_code_unchanged',all(sha(ROOT/p)==h for p,h in manifest['source_sha256'].items()))
    check('budget_caps',budget['total_QP_calls']<=24000 and budget['total_physics_steps']<=240000 and budget['numerical_elapsed_s']<=7200.)
    check('no_hidden_returns_or_reservations',budget['unknown_native_returns']==0 and budget['uncompleted_native_step_reservations']==0)
    ledger=[json.loads(line)for line in(out/'STEP29_LEDGER.jsonl').read_text(encoding='utf-8').splitlines()]
    starts=[r for r in ledger if r['event']=='QP_START'];returns=[r for r in ledger if r['event']=='QP_RETURN']
    check('one_QP_ledger_contiguous', [r['global_qp_index']for r in starts]==list(range(1,budget['total_QP_calls']+1)))
    check('one_QP_ledger_returns',[r['global_qp_index']for r in returns]==[r['global_qp_index']for r in starts])
    check('all_QP_calls_real',all(r.get('real_optimizer_called')is True for r in returns))
    check('bounded_solver_limits',all(.001<=r['osqp_time_limit_s']<=.006 for r in returns if r.get('kernel_variant')=='K_BUDGETED'))
    native_start=[r for r in ledger if r['event']=='PREFIX_NATIVE_START'];native_return=[r for r in ledger if r['event']=='PREFIX_NATIVE_RETURN']
    check('prefix_reservation_identity',[r['reservation_id']for r in native_start]==[r['reservation_id']for r in native_return])
    check('prefix_ledger_counts',sum(r['actual_steps']for r in native_return)==budget['physics_by_kind'].get('PREFIX_PREDICTION',0))
    models=read(out/'models/MODEL_FREEZE.json');check('two_fixed_fits',models['actual_multioutput_estimator_fit_calls']==2 and budget['multioutput_estimator_fits']==2)
    check('no_TEST_model_selection',models['new_TEST_model_selection']is False and models['split_summary']['new_TEST_consumed']is False)
    for configuration,asset in models['assets'].items():
        check('frozen_model_'+configuration,sha(asset['npz'])==asset['npz_sha256']and sha(asset['json'])==asset['json_sha256'])
    dev=read(out/'DEV_SPLIT_REGISTRY.json');registry=read(out/'TEST_REGISTRY.json');online=read(out/'ONLINE_RESULTS.json');fresh=read(out/'FRESH_RESULTS.json')
    check('54_fixed_TEST_identities',[e['context_id']for e in registry]==manifest['ordinal_order'])
    check('54x3_online_distinct',len(online)==162 and len({(r['context_id'],r['policy'])for r in online})==162)
    check('12_fixed_fresh_indices',[r['index']for r in fresh]==[0,4,8,13,17,21,26,30,34,39,43,53])
    check('no_DEV_context_recompute',budget['DEV_context_recomputations']==0)
    snapshot_splits={};episode_splits={};split_ok=True
    for r in models['split_registry']:
        for value,d in((r['source_snapshot'],snapshot_splits),(r['episode'],episode_splits)):
            if value in d and d[value]!=r['split']:split_ok=False
            d[value]=r['split']
    check('whole_episode_and_snapshot_splits',split_ok)
    check('DEV_704_endpoints_108_fixed_middle',sum(d['reused_endpoint']for d in dev)==704 and sum(not d['reused_endpoint']for d in dev)==108)
    artifacts=[];prefix_steps=0
    def prefix(p,owner):
        nonlocal prefix_steps
        if not p:return
        prefix_steps+=p.get('actual_steps',0)
        if p.get('complete'):
            n=p['numeric'];q=np.asarray(n['qpos']);v=np.asarray(n['qvel'])
            counts['complete_saved_prefix']+=1
            if q.shape!=(11,19)or v.shape!=(11,18)or not np.isfinite(q).all()or not np.isfinite(v).all():failures.append('prefix_shape_or_finite:'+owner)
    def artifact(asset):
        if not asset:return
        path=Path(asset['path']);artifacts.append(path)
        if not path.is_file()or sha(path)!=asset['sha256']:failures.append('bank_hash:'+str(path));return
        with np.load(path,allow_pickle=False)as n:
            doc=json.loads(n['metadata_json_utf8'].tobytes().decode('utf-8'));h=doc['header']
            counts['new_bank_physics_steps']+=h['counts']['physical_steps'];counts['new_banks']+=1
            if h['status']=='COMPLETE':
                counts['complete_new_banks']+=1
                if doc['row_count']!=501 or len(h['controls'])!=50:failures.append('501_grid_bank:'+str(path))
    for d in dev:
        payload=read(out/d['path'])
        if d['reused_endpoint']:prefix(payload['record'].get('prefix'),d['id'])
        else:
            ci=read((out/d['path']).parent/'CURRENT_INPUT.json');prefix(ci['entry'].get('prefix'),d['id']);artifact(payload.get('artifact'))
    for e in registry:
        if not e['snapshot_eligible']:continue
        current=read(out/'reference'/e['context_id']/'attempt01/CURRENT_INPUT.json')
        if not current['all_selections_frozen_before_actual_labels']:failures.append('prediction_freeze:'+e['context_id'])
        for key,entry in current['inputs'].items():prefix(entry.get('prefix'),e['context_id']+':'+key)
        for asset in e['artifacts'].values():artifact(asset)
    full_online=[out/'online'/r['context_id']/(r['policy']+'.json')for r in online]
    full_online += [out/'fresh'/f['context_id']/'ONLINE_NUMERIC.json'for f in fresh if 'online'in f]
    for online_path in full_online:
        r=read(online_path)
        context=r['context_id']
        if r.get('selected_command_sent')and(r['command_ready_ms']>20. or r['status']!='RECOGNIZED_SENT'):failures.append('late_or_unrecognized_sent:'+context)
        for key,entry in r.get('actions',{}).items():
            prefix(entry.get('prefix'),context+':'+key)
            action=entry.get('action');p=entry.get('prefix')
            if not action or not action.get('command_valid'):continue
            gamma=action['gamma'];raw=np.asarray(action['tau_raw']);sent=np.asarray(action['tau_sent']);interface=action['capacity_interface']
            cap=np.asarray(interface['health_vector'])*np.asarray(interface['healthy_torque_limits_nm'])
            if not np.array_equal(sent,np.clip(raw,-cap,cap)):failures.append('online_capacity_clip:'+context)
            if 0.<gamma<1.:
                counts['online_synthetic_evaluations']+=1
                if(action['solver_status_val']is not None or action['kind']!='SYNTHESIZED_CONVEX_COMMAND'
                    or action['source_solver_statuses']!={'C':1,'B':1}or not action['sent_hard_check']['pass']):failures.append('synthetic_source_identity:'+context)
                z=gamma*np.asarray(action['source_primal_variables']['C'])+(1-gamma)*np.asarray(action['source_primal_variables']['B'])
                if not np.array_equal(z,action['z_raw']):failures.append('synthetic_z_identity:'+context)
            if p and p.get('complete'):
                if not np.array_equal(p['numeric']['tau_sent'],sent):failures.append('prefix_command_identity:'+context)
            if r['B'].get('status')=='NOT_REQUESTED'and gamma!=1.:failures.append('hidden_B_fill:'+context)
        for mode in('C','B'):
            ep=r[mode]
            if ep.get('command_valid',ep.get('valid_command',False)):
                raw=ep.get('raw_solver_variables',{})
                if not raw:raw=ep.get('raw_solver_result',ep.get('wbc',{}))
                if any(v not in raw for v in('qdd','tau','contact_force')):failures.append('online_endpoint_missing_full_raw:'+context+':'+mode)
    for f in fresh:
        artifact(f.get('artifact'))
        if f.get('online',{}).get('selected_command_sent'):
            if not f.get('first_command_matches'):failures.append('fresh_first_command:'+str(f['index']))
            if f.get('tick_latency_ms')and f['tick_latency_ms'][0]!=f['online']['command_ready_ms']:failures.append('fresh_first_latency:'+str(f['index']))
    check('saved_prefix_steps_match_ledger',prefix_steps==budget['physics_by_kind'].get('PREFIX_PREDICTION',0),{'saved':prefix_steps,'ledger':budget['physics_by_kind'].get('PREFIX_PREDICTION',0)})
    reference_steps=sum(read(p)['counts']['physical_steps']for p in(out/'episodes').glob('*.json'))
    check('saved_actual_reference_steps',counts['new_bank_physics_steps']+reference_steps+prefix_steps==budget['total_physics_steps'],
        {'new_actual':counts['new_bank_physics_steps'],'reference':reference_steps,'prefix':prefix_steps})
    check('no_duplicate_trajectory_paths',len(artifacts)==len(set(artifacts)))
    files=[p for p in out.rglob('*')if p.is_file()and p.name!='FINAL_FILE_VERIFICATION.json']
    file_index=[{'path':str(p.relative_to(out)).replace('\\','/'),'bytes':p.stat().st_size,'sha256':sha(p)}for p in files]
    result={'status':'PASS'if not failures else'FAIL','checks':checks,'failure_names':failures,'counts':dict(counts),
        'current_files':file_index,'current_file_count':len(files),'numerical_replay':False,'historical_audit_or_replay':False,
        'verification_scope':'one final STEP29 current-file, ledger, identity, frozen-asset closure; scientific and timing failures remain results'}
    write(out/'FINAL_FILE_VERIFICATION.json',result)
    print(json.dumps({'verification_status':result['status'],'failure_names':failures,'counts':dict(counts),'files':len(files)}))
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('out');verify(p.parse_args().out)
