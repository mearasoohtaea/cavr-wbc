"""Stream existing saved DEV inputs; no historical integration or QP replay."""
from pathlib import Path
import hashlib
import json
import numpy as np
from cavr_wbc.experiments.step30_io import ROOT,SOURCE29,read,sha,write,relative,small_label,small_prefix
from cavr_wbc.control.step30_actions import geometry_features
from cavr_wbc.control.step29_margin import gamma_key,labels
from cavr_wbc.experiments.step26_features_storage import load_bank

CAL_EPISODES=frozenset(('T27_N050','T27_P070','T28_N055','T28_P065','T28_N060_C',
    'T29_N052','T29_P068','T29_N060_C','D30_N048','D30_P064'))


def source_stage(episode):
    if episode.startswith('T27_'):return 'STEP27'
    if episode.startswith('T28_'):return 'STEP28'
    if episode.startswith('T29_'):return 'STEP29'
    if episode.startswith('D30_'):return 'STEP30_DEV'
    return 'STEP26'


def split(episode):return 'CAL'if episode in CAL_EPISODES else'TRAIN'


def record(identifier,context,gamma,features23,prefix,action,label,source_path,trajectory_path=None):
    episode=context['episode_id'];stage=source_stage(episode);snapshot=context.get('snapshot_id',episode+':'+str(context['source_tick']))
    geometry=None;error=None;features=None
    if features23 is not None:
        f=np.asarray(features23,float)
        try:
            if f.shape!=(23,)or not np.isfinite(f).all():raise ValueError('missing/nonfinite saved23 features')
            geometry=geometry_features(context,action,_MAPPING);features=np.r_[f,geometry]
        except(ValueError,TypeError,KeyError)as exc:error=str(exc)
    else:error='SAVED_CURRENT_PREFIX_INPUT_UNAVAILABLE'
    key='|'.join((stage,str(trajectory_path or source_path),episode,context['context_id'],gamma_key(gamma),str(label.get('trajectory_id'))))
    return {'id':identifier,'split':split(episode),'stage':stage,'episode':stage+'::'+episode,
        'source_snapshot':stage+'::'+snapshot,'context_id':context['context_id'],'gamma':gamma,
        'role':context['health_kind'].split('_')[0].lower(),'features26':features,'prefix':small_prefix(prefix),
        'first_command_valid':bool(action.get('command_valid')),'labels':small_label(label),'input_error':error,
        'geometry3':geometry,'source_path':str(source_path),'trajectory_path':str(trajectory_path)if trajectory_path else None,
        'actual_identity':hashlib.sha256(key.encode()).hexdigest(),'source_future_labels_not_used_as_inputs':True,
        'source_solver_or_trajectory_replay':False}


_MAPPING=None


def old_DEV(out,mapping):
    global _MAPPING
    _MAPPING=mapping;records=[];index=[];seen=set();contexts={}
    def emit(r):
        if r['actual_identity']in seen:return
        seen.add(r['actual_identity']);path=out/'DEV_REUSED'/(r['id'].replace(':','_')+'.json')
        if not path.exists():write(path,r)
        records.append({k:v for k,v in r.items()if k not in('geometry3','source_path','trajectory_path')})
        index.append({'id':r['id'],'stage':r['stage'],'episode':r['episode'],'source_snapshot':r['source_snapshot'],
            'split':r['split'],'gamma':r['gamma'],'role':r['role'],'record_path':relative(path,out),
            'status':'FINITE_INPUT'if r['features26']is not None else'MISSING_SAVED_INPUT','complete':bool(r['labels'].get('complete')),
            'source_path':r['source_path'],'trajectory_path':r['trajectory_path'],'actual_identity':r['actual_identity']})
    for d in read(SOURCE29/'DEV_SPLIT_REGISTRY.json'):
        p=SOURCE29/d['path'];saved=read(p);old=saved['record'];ctx=old['context'];contexts[ctx['context_id']]=ctx
        if d['reused_endpoint']:
            action=saved['action'];traj=saved['source_paths'][gamma_key(d['gamma'])]
        else:
            cur=read(p.parent/'CURRENT_INPUT.json');action=cur['action'];traj=(saved.get('artifact')or{}).get('path')
        r=record('OLDDEV:'+d['id'],ctx,d['gamma'],old['features23'],old['prefix'],action,old['labels'],p,traj);emit(r)
    for d in read(SOURCE29/'TEST_REGISTRY.json'):
        p=SOURCE29/d['full_numeric_attempt_path'];saved=read(p);ctx=saved['context'];contexts[ctx['context_id']]=ctx
        current=read(p.parent/'CURRENT_INPUT.json')if ctx['eligible']else None
        for g in(1.,.75,.5,.25,0.):
            key=gamma_key(g);entry=current['inputs'][key]if current else{};action=current['actions'][key]if current else{}
            emit(record('OLD29TEST:'+ctx['context_id']+':G'+key,ctx,g,entry.get('features23'),entry.get('prefix'),action,
                saved['labels'][key],p,(saved['artifacts'].get(key)or{}).get('path')))
    # STEP29 fresh actual commands have their own full numeric ready snapshot.
    for d in read(SOURCE29/'FRESH_RESULTS.json'):
        if 'artifact'not in d:continue
        ctx=contexts[d['context_id']];p=SOURCE29/'fresh'/ctx['context_id']/'ONLINE_NUMERIC.json';online=read(p)
        g=d['gamma'];entry=online['actions'][str(g)];action=online['selected_action']
        emit(record('OLD29FRESH:'+ctx['context_id']+':G'+gamma_key(g),ctx,g,entry.get('features23'),entry.get('prefix'),action,
            d['labels'],p,d['artifact']['path']))
    # Earlier fresh ACTUAL archives are also retained as DEV. They did not
    # save the action-conditional23 input or online prefix arrays. Do not
    # substitute teacher features, reconstruct a missing raw command, or replay.
    directories=(ROOT/'artifacts/step26_fast_margin_20261008/step26-fast-margin-20261008-01',
        ROOT/'artifacts/step27_structured_margin_20261008/step27-structured-margin-20261008-01',
        ROOT/'artifacts/step28_physics_residual_20261008/step28-physics-residual-20261008-01')
    for directory in directories:
        for p in(directory/'fresh').rglob('*.npz'):
            with np.load(p,allow_pickle=False)as archive:
                h=json.loads(archive['metadata_json_utf8'].tobytes().decode('utf-8'))['header']
            if not h['kind'].startswith('ACTUAL_'):continue
            cid=h['branch_id'].split(':')[0]
            if cid not in contexts:
                index.append({'id':'OLD_FRESH_UNMAPPED:'+str(p),'source_path':str(p),'status':'MISSING_SAVED_CONTEXT','complete':h['status']=='COMPLETE'})
                continue
            ctx=contexts[cid];g=1. if h['kind']=='ACTUAL_C'else 0.;lab=labels(load_bank(p),ctx)
            emit(record('OLDFRESH:'+directory.name+':'+cid+':'+p.stem,ctx,g,None,None,{},lab,p,p))
    write(out/'DEV_SPLIT_REGISTRY.json',index)
    return records,index
