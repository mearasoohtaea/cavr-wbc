"""Exactly two STEP30 evidence figures, drawn from saved numeric results only.

The preview phase precedes vector export so the calling agent can inspect both
colour and grayscale PNGs. No selected-gap subpopulation is used to draw the
actual-action figure; online fixed and prediction-window probe remain separate.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

from cavr_wbc.experiments.step30_report import (
    GAMMAS, POLICIES, csv_write, entries, finite, gamma_key, read, resolve, write,
)

SCRIPTS = Path("C:/Users/ZhuanZ（无密码）/.codex/skills/scipilot-figure/scripts")
sys.path.insert(0, str(SCRIPTS))
from setup_style import setup_style
from profile_data import profile_data, render_report
from visual_qa import audit_layout, render_preview
from export_figure import export_figure
from layout_tools import finalize_figure, add_panel_labels

ORDERED = (0., .25, .5, .75, 1.)
COLORS = {0.: "#000000", .25: "#E69F00", .5: "#0072B2", .75: "#CC79A7", 1.: "#56B4E9"}
ROLE_MARKERS = {"healthy": "o", "thigh": "^", "calf": "s"}
GAMMA_MARKERS = {0.: "o", .25: "s", .5: "^", .75: "D", 1.: "v"}
ROLE_COLORS = {"healthy": "#777777", "thigh": "#0072B2", "calf": "#E69F00"}
POLICY_NAMES = {"GOVERNOR_LOCAL_FIXED": "Governor fixed", "BINARY_LOCAL_FIXED": "Binary fixed", "GOVERNOR_LOCAL_PROBE": "Governor probe"}


def data(out):
    out = Path(out); directory = out / "figures"; directory.mkdir(exist_ok=True)
    action_rows = read(out / "ACTION_RESULTS.json", [])
    registry = entries(read(out / "TEST_REGISTRY.json", []))
    meta = {entry["context_id"]: entry for entry in registry}
    actions = []
    for row in action_rows:
        status = "PHYSICAL_TERMINAL_SAFE" if row["physical_terminal_safe"] else "COMPLETE_FAILURE" if row["complete_501"] else "INCOMPLETE_OR_UNAVAILABLE"
        actions.append({"ordinal": row["ordinal"], "context_id": row["context_id"], "episode": row["episode"],
            "role": row["role"], "front_or_rear": row["front_or_rear"], "gamma": row["gamma"], "status": status,
            "complete": row["complete_501"], "capacity_event": row["capacity_event_observed"],
            "required_gap_mm": 1000. * row["D_m"] if finite(row.get("D_m")) else None,
            "progress20_mm": 1000. * row["progress20_m"] if finite(row.get("progress20_m")) else None})
    timing = []
    for entry in entries(read(out / "ENGINEERING_REGISTRY.json", [])):
        numeric = read(resolve(out, entry["numeric_path"]), {})
        item = meta.get(entry["context_id"], {})
        timing.append({"ordinal": entry["ordinal"], "context_id": entry["context_id"], "policy": entry["policy"],
            "role": item.get("role", "UNKNOWN"), "command_ready_ms": numeric.get("command_ready_ms"),
            "recognized_sent": bool(numeric.get("selected_command_sent")), "actual_gamma": numeric.get("selected_gamma") if numeric.get("selected_command_sent") else None,
            "intention_gamma": entry.get("intention_gamma", numeric.get("intention_gamma")) if (numeric.get("probe")or{}).get("status")=="PROBE_MIDDLE_WINDOW" else None,
            "candidate_gamma_raw": numeric.get("intention_gamma"),
            "probe_status": (numeric.get("probe")or{}).get("status"),
            "status": numeric.get("status", entry.get("status", "MISSING_STATUS")), "numeric_path": entry["numeric_path"]})
    csv_write(directory / "ACTION_FIGURE_DATA.csv", actions)
    csv_write(directory / "ONLINE_FIGURE_DATA.csv", timing)
    for name, groups in (("ACTION_FIGURE_DATA", ["gamma", "role"]), ("ONLINE_FIGURE_DATA", ["policy"])):
        path = directory / (name + ".csv")
        if path.stat().st_size and (actions if name == "ACTION_FIGURE_DATA" else timing):
            profile = profile_data(str(path), group_cols=groups)
            (directory / (name + "_PROFILE.md")).write_text(render_report(profile), encoding="utf-8", newline="\n")
    write(directory / "FIGURE_SELECTION.json", {
        "target": "IEEE double-column, 7.16 inch, 8-point primary text",
        "figure_1_argument": "All five observed actions jointly expose feasibility, actual motion, and capacity activation; no selected-gap cherry-pick.",
        "figure_1_choice": "48 by 5 complete-action matrix plus all safe actual branch scatter",
        "figure_1_alternatives": ["Per-role small multiples", "Full context point table"],
        "figure_2_argument": "All planned online latency and intended-versus-actually-sent actions decide deadline closure; probe stays separate.",
        "figure_2_choice": "All-row point latency by policy plus probe gamma point pairs",
        "figure_2_alternatives": ["ECDF with full planned denominator", "Policy-by-context latency matrix"],
        "numeric_ordinal_is_ID_not_continuous_time": True, "queries_not_independent_replicates": True,
        "all_planned_contexts": 48, "all_planned_engineering_rows": 144,
        "statistical_error_bars_or_significance_tests": "NONE; fixed deterministic recipe panel"})
    return actions, timing


def _style():
    setup_style(journal="ieee", lang="en", use_sciplots=False)
    plt.rcParams.update({"font.size": 8, "axes.labelsize": 8, "axes.titlesize": 8,
        "xtick.labelsize": 8, "ytick.labelsize": 8, "legend.fontsize": 8,
        "axes.spines.top": False, "axes.spines.right": False,
        "pdf.fonttype": 42, "ps.fonttype": 42, "axes.unicode_minus": False,
        "figure.constrained_layout.use": True})


def _action_figure(actions):
    fig, axes = plt.subplots(1, 2, figsize=(7.16, 4.65), layout="constrained", gridspec_kw={"width_ratios": [1.04, 1.]})
    grid = np.full((48, 5), np.nan)
    failures, missing, active = [], [], []
    for row in actions:
        i = ORDERED.index(float(row["gamma"])); j = int(row["ordinal"])
        if row["status"] == "PHYSICAL_TERMINAL_SAFE" and finite(row["required_gap_mm"]):
            grid[j, i] = row["required_gap_mm"]
        elif row["complete"]:
            failures.append((i, j))
        else:
            missing.append((i, j))
        if row["capacity_event"]:
            active.append((i, j))
    ax = axes[0]
    maximum = max(1., float(np.ceil(np.nanmax(grid)))) if np.isfinite(grid).any() else 1.
    image = ax.imshow(np.ma.masked_invalid(grid), cmap="cividis", vmin=0., vmax=maximum,
                      origin="lower", aspect="auto", interpolation="none")
    for points, marker, size in ((failures, "x", 13), (missing, ".", 8)):
        if points:
            x, y = np.asarray(points).T; ax.scatter(x, y, c="black", marker=marker, s=size, linewidths=.6)
    if active:
        x, y = np.asarray(active).T
        ax.scatter(x, y, edgecolors="black", facecolors="none", marker="o", s=25, linewidths=.6)
    ax.set_xticks(range(5), ["0", ".25", ".5", ".75", "1"])
    ax.set_xlabel("First-command retention gamma")
    ax.set_yticks([5.5, 17.5, 29.5, 41.5], ["P054", "N054", "P066", "N066"])
    ax.set_ylabel("Episode (12 fixed contexts each)")
    for position in (11.5, 23.5, 35.5):
        ax.axhline(position, color="white", lw=.8)
    ax.set_title("All actual actions and binding events", pad=12)
    colorbar = fig.colorbar(image, ax=ax, shrink=.8, pad=.02)
    colorbar.set_label("Required local gap D (mm)")
    ax.legend(handles=[Line2D([], [], marker="x", color="black", linestyle="none", label="Complete failure"),
                       Line2D([], [], marker=".", color="black", linestyle="none", label="Incomplete / unavailable"),
                       Line2D([], [], marker="o", markerfacecolor="none", color="black", linestyle="none", label="Capacity / 99% event")],
              loc="upper left", bbox_to_anchor=(-.02, -.15), frameon=False, fontsize=7)
    ax = axes[1]
    for gamma in ORDERED:
        for role in ROLE_MARKERS:
            points = [row for row in actions if row["status"] == "PHYSICAL_TERMINAL_SAFE" and row["gamma"] == gamma
                      and row["role"] == role and finite(row["required_gap_mm"]) and finite(row["progress20_mm"])]
            if points:
                ax.scatter([row["required_gap_mm"] for row in points], [row["progress20_mm"] for row in points],
                           facecolors="none" if role=="healthy" else ROLE_COLORS[role], marker=GAMMA_MARKERS[gamma],
                           s=19, alpha=.85, edgecolors=ROLE_COLORS[role], linewidths=.65)
    ax.axhline(0., color="gray", lw=.6, ls=":")
    ax.set_xlabel("Actual 1 s maximum excursion (mm)")
    ax.set_ylabel("Actual first-20 ms progress (mm)")
    ax.set_title("All physically and terminally safe branches", pad=12)
    ax.margins(.08)
    handles = [Line2D([], [], marker=GAMMA_MARKERS[gamma], color="black", linestyle="none", label="gamma=" + gamma_key(gamma)) for gamma in ORDERED]
    handles += [Line2D([], [], marker="o", color=ROLE_COLORS[role],markerfacecolor="none" if role=="healthy" else ROLE_COLORS[role],
        linestyle="none", label=role.title()) for role in ROLE_MARKERS]
    ax.legend(handles=handles, loc="upper left", bbox_to_anchor=(-.01, -.15), frameon=False, ncol=2, fontsize=7)
    return fig


def _online_figure(timing):
    fig, axes = plt.subplots(1, 2, figsize=(7.16, 4.), layout="constrained", gridspec_kw={"width_ratios": [1.12, 1.]})
    colors = ("#0072B2", "#E69F00", "#000000"); markers = ("^", "s", "o")
    ax = axes[0]
    for policy, color, marker in zip(POLICIES, colors, markers):
        for sent in (False, True):
            points = [row for row in timing if row["policy"] == policy and row["recognized_sent"] == sent and finite(row["command_ready_ms"])]
            if points:
                ax.scatter([row["ordinal"] for row in points], [row["command_ready_ms"] for row in points],
                           edgecolors=color, facecolors=color if sent else "none", marker=marker, s=20,
                           linewidths=.65, label=POLICY_NAMES[policy] if sent else None)
    ax.axhline(20., color="gray", lw=.8, ls=":")
    ax.set_xlim(-1, 48); ax.set_ylim(bottom=0.)
    ax.set_xlabel("Fixed input ordinal (not elapsed time)")
    ax.set_ylabel("Complete command-ready time (ms)")
    ax.set_title("All 144 planned ready windows", pad=12)
    handles = [Line2D([], [], marker=marker, color=color, linestyle="none", label=POLICY_NAMES[policy]) for policy, color, marker in zip(POLICIES, colors, markers)]
    handles += [Line2D([], [], marker="o", color="black", markerfacecolor="none", linestyle="none", label="Hollow = not sent")]
    ax.legend(handles=handles, loc="upper left", bbox_to_anchor=(-.01, -.20), frameon=False, fontsize=7)
    missing_times = sum(not finite(row["command_ready_ms"]) for row in timing)
    if missing_times or len(timing) < 144:
        ax.text(.01, .98, f"Missing / non-finite timing: {missing_times}; absent rows: {max(0, 144-len(timing))}",
                transform=ax.transAxes, ha="left", va="top", fontsize=7)
    ax = axes[1]
    probe = [row for row in timing if row["policy"] == "GOVERNOR_LOCAL_PROBE"]
    for role, marker in ROLE_MARKERS.items():
        for kind, field, offset, color, filled in (("intended", "intention_gamma", -.13, "#E69F00", False),
                                                 ("sent", "actual_gamma", .13, "#0072B2", True)):
            points = [row for row in probe if row["role"] == role and finite(row[field])]
            if points:
                ax.scatter([row["ordinal"] + offset for row in points], [row[field] for row in points], marker=marker,
                           facecolors=color if filled else "none", edgecolors=color, s=22, linewidths=.7)
    rejected = [row for row in probe if not row["recognized_sent"]]
    if rejected:
        ax.scatter([row["ordinal"] for row in rejected], [-.18] * len(rejected), color="black", marker="x", s=16, linewidths=.6)
    ax.set_xlim(-1, 48); ax.set_ylim(-.3, 1.08)
    ax.set_yticks([-.18, 0., .25, .5, .75, 1.], ["not sent", "0", ".25", ".5", ".75", "1"])
    ax.set_xlabel("Fixed probe input ordinal")
    ax.set_ylabel("Intended versus actually sent gamma")
    ax.set_title("Prediction-window probe kept separate", pad=12)
    handles = [Line2D([], [], marker="o", color="#E69F00", markerfacecolor="none", linestyle="none", label="Frozen intention"),
               Line2D([], [], marker="o", color="#0072B2", linestyle="none", label="Actually sent"),
               Line2D([], [], marker="x", color="black", linestyle="none", label="Rejected / late")]
    handles += [Line2D([], [], marker=marker, color="black", linestyle="none", label=role.title()) for role, marker in ROLE_MARKERS.items()]
    ax.legend(handles=handles, loc="upper left", bbox_to_anchor=(-.01, -.20), frameon=False, ncol=2, fontsize=7)
    return fig


def _finish(fig, base, phase):
    finalize_figure(fig); add_panel_labels(fig, style="ieee")
    issues = audit_layout(fig)
    if any(severity == "FAIL" for severity, _ in issues):
        raise RuntimeError("STEP30 figure missing-glyph/layout failure")
    from PIL import Image
    if phase == "preview":
        render_preview(fig, str(base) + "_preview.png", dpi=180)
        Image.open(str(base) + "_preview.png").convert("L").save(str(base) + "_preview_grayscale.png")
    else:
        export_figure(fig, str(base), formats=["pdf", "svg", "png"], size_inches=tuple(fig.get_size_inches()),
                      dpi=600, tight=False, grayscale_preview=False)
        Image.open(str(base) + ".png").convert("L").save(str(base) + "_grayscale.png")
    return {"figure": base.name, "phase": phase, "issues": issues, "dimensions_inches": list(fig.get_size_inches()),
            "visual_review_required": True, "vector_export_after_preview_review": phase == "export"}


def build(out, phase="preview"):
    if phase not in ("preview", "export"):
        raise ValueError("STEP30 figure phase must be preview or export")
    out = Path(out); actions, timing = data(out); _style()
    qa = []
    for fig, basename in ((_action_figure(actions), "step30_injured_action_set"),
                          (_online_figure(timing), "step30_online_closure")):
        qa.append(_finish(fig, out / "figures" / basename, phase)); plt.close(fig)
    write(out / "figures/FIGURE_MACHINE_QA.json", qa)
    (out / "figures/FIGURE_CAPTIONS.md").write_text("\n".join([
        "# STEP30 evidence figures", "",
        "Figure 1. All 48 planned test contexts by all five first-command retention values. Each episode contains four fixed snapshot ticks, with healthy/thigh/calf in manifest order. Panel (a) encodes minimum local gap D only for complete original-physical/terminal-safe branches; crosses show complete failure and dots show incomplete/unavailable. A hollow ring marks an observed capacity/99% event on that branch, not health-label inference. The continuous cividis color scale starts at zero and includes the maximum of all plotted values without truncation. Panel (b) shows actual first-20 ms direction progress against full-1 s excursion for every physically and terminally safe branch, independently of chosen query gap. Marker shape codes gamma, color codes fault role, and healthy points are hollow while injured points are filled. Each point is one actual branch; 13 gap queries are not plotted as replicates. Gamma interpolation does not imply monotonic future safety.", "",
        "Figure 2. All 48 planned inputs timed once under each of three policies (144 ready windows), with policy order rotated. Panel (a) plots every finite measured ready time, retains the late tail and the unchanged 20 ms line, and uses filled marks only for recognized-and-actually-sent commands; hollow marks are rejected/unavailable/late. Missing/non-finite timing and absent planned rows are stated, not set to zero. Inputs are unordered IDs, so points are not connected. Panel (b) separately displays the frozen prediction-window probe intention and the actually sent gamma on all probe inputs; intention never forces sending, and rejected/late rows occupy a distinct categorical 'not sent' level. Probe gaps are frozen without actual D/Y and this mechanism subpanel is not a population success-rate estimate.", "",
        "Both figures use IEEE double-column 7.16-inch dimensions, 8-point primary text, colorblind-safe palette and redundant symbols, 600 dpi PNG plus PDF/SVG with embedded TrueType. No mean bars, uncertainty bands, p-values, or random-repeat claim. SciPilot EDA and figure selection are saved; colour and grayscale previews require explicit visual review before vector export.", ""
    ]), encoding="utf-8", newline="\n")
    return qa


def figures(out, finalize=False):
    return build(out, "export" if finalize else "preview")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(); parser.add_argument("out"); parser.add_argument("phase", choices=("preview", "export"), nargs="?", default="preview")
    args = parser.parse_args(); build(args.out, args.phase)
