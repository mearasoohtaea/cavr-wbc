"""Incremental STEP30 persistence: only small indexes aggregate in memory."""
import hashlib
import json
import math
import os
from pathlib import Path
import numpy as np


ROOT=Path(__file__).resolve().parents[2]
SOURCE29=ROOT/'artifacts/step29_action_governor_20261008/step29-action-governor-20261008-01'
RUN_ID='step30-injured-governor-20261008-01'
PARENT='e5073e634224b090e7fb059fcc4d394443d7780d'
PROTOCOL=Path('E:/CAVR-WBC/experiment_handoff_20260921/NEXT_CODEX_INSTRUCTIONS_STEP30_INJURED_GOVERNOR_CLOSURE_20261008.md')


def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def encode(value):
    if isinstance(value,np.ndarray):return encode(value.tolist())
    if isinstance(value,np.generic):return encode(value.item())
    if isinstance(value,float)and not math.isfinite(value):return {'nonfinite':repr(value)}
    if isinstance(value,dict):return {str(k):encode(v)for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [encode(v)for v in value]
    return value


def write(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);pending=path.with_suffix(path.suffix+'.tmp')
    with pending.open('w',encoding='utf-8',newline='\n')as f:
        json.dump(encode(value),f,sort_keys=True,separators=(',',':'),allow_nan=False,ensure_ascii=False);f.write('\n');f.flush()
    os.replace(pending,path)


def append(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('a',encoding='utf-8',newline='\n')as f:json.dump(encode(value),f,sort_keys=True,separators=(',',':'),allow_nan=False);f.write('\n');f.flush()


def relative(path,out):return str(Path(path).relative_to(out)).replace('\\','/')


def small_prefix(prefix):return {k:v for k,v in(prefix or{}).items()if k not in('numeric','identity')}


def small_label(label):
    keys=('complete','D','Y','original_physical_safe','terminal_pass','command_valid_all','valid','original_failure',
        'reason','status','trajectory_id','progress20_m','endpoint_progress_m','full_501_grid')
    return {key:label.get(key)for key in keys}


def index_entry(context,path,out,status,**extra):
    vx=context.get('state',{}).get('qvel',[context.get('direction',0)])[0]
    return {'context_id':context['context_id'],'ordinal':context.get('ordinal'),'role':context['health_kind'].split('_')[0].lower(),
        'front_or_rear':'front'if vx>0 else'rear','eligible':bool(context.get('eligible')),
        'attempt_path':relative(path,out),'status':status,**extra}
