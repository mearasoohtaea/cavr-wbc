"""STEP30 saved-evidence analysis, streaming report, and research handoff.

This module imports no controller, simulator, model fitter, or evaluator.
Registries remain identity-only; individual numeric attempt files are read one
at a time. Missing or non-finite observations are never replaced with zeros.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
import json
import math
from pathlib import Path

import numpy as np

GAMMAS = (1., .75, .5, .25, 0.)
GAPS_M = (.0005, .001, .0015, .002, .0025, .003, .004,
          .006, .008, .012, .016, .024, .032)
METHODS = ("LOCAL_GEOMETRY", "GLOBAL_CAL_SAME_MODEL", "NO_GEOMETRY",
           "BINARY_LOCAL", "STEP29_FROZEN", "M0", "M1", "ORACLE")
POLICIES = ("GOVERNOR_LOCAL_FIXED", "BINARY_LOCAL_FIXED", "GOVERNOR_LOCAL_PROBE")
ROLES = ("healthy", "thigh", "calf")
STATIC_GATES = ("current_command_gate", "prefix_available_gate", "prefix_physical_gate",
                "pose_gate", "support_gate", "distance_gate", "calibration_gate", "terminal_gate")


def gamma_key(value):
    return format(float(value), "g")


def _restore(value):
    if isinstance(value, dict):
        if len(value) == 1:
            key = next(iter(value))
            if key in ("__step26_nonfinite_float__", "__step29_nonfinite_float__", "__step30_nonfinite_float__"):
                return float(value[key])
        return {key: _restore(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_restore(item) for item in value]
    return value


def _encode(value):
    if isinstance(value, np.ndarray):
        return _encode(value.tolist())
    if isinstance(value, np.generic):
        return _encode(value.item())
    if isinstance(value, float) and not math.isfinite(value):
        return {"__step30_nonfinite_float__": repr(value)}
    if isinstance(value, dict):
        return {str(key): _encode(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_encode(item) for item in value]
    return value


def read(path, default=None):
    path = Path(path)
    return _restore(json.loads(path.read_text(encoding="utf-8"))) if path.exists() else default


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(_encode(value), ensure_ascii=False, allow_nan=False, separators=(",", ":")) + "\n"
    pending = path.with_name(path.name + ".step30-report.pending")
    pending.write_text(text, encoding="utf-8", newline="\n")
    pending.replace(path)


def rows(path):
    path = Path(path)
    if path.exists():
        with path.open(encoding="utf-8") as stream:
            for line in stream:
                if line.strip():
                    yield _restore(json.loads(line))


def entries(document):
    """Two explicitly supported registry encodings: list or {'entries': list}."""
    if document is None:
        return []
    if isinstance(document, list):
        return document
    if isinstance(document, dict) and isinstance(document.get("entries"), list):
        return document["entries"]
    raise ValueError("STEP30 registry must be an identity list or entries document")


def resolve(out, path):
    value = Path(path)
    return value if value.is_absolute() else Path(out) / value


def finite(value):
    return isinstance(value, (int, float, np.integer, np.floating)) and not isinstance(value, bool) and math.isfinite(float(value))


def stats(values):
    values = list(values)
    a = np.asarray([float(value) for value in values if finite(value)])
    return {"recorded": len(values), "finite": len(a), "nonfinite_or_missing": len(values) - len(a),
            "p50": float(np.percentile(a, 50)) if len(a) else None,
            "p95": float(np.percentile(a, 95)) if len(a) else None,
            "p99": float(np.percentile(a, 99)) if len(a) else None,
            "max": float(a.max()) if len(a) else None,
            "min": float(a.min()) if len(a) else None}


def csv_write(path, data):
    data = list(data)
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(dict.fromkeys(key for row in data for key in row))
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for row in data:
            writer.writerow({key: json.dumps(_encode(value), ensure_ascii=False) if isinstance(value, (dict, list, tuple)) else value for key, value in row.items()})


def safe(label, gap):
    return bool(label.get("complete") and label.get("original_physical_safe") and label.get("terminal_pass")
                and label.get("command_valid_all") and finite(label.get("D")) and 0. <= label["D"] <= gap)


def physical_terminal_safe(label):
    return bool(label.get("complete") and label.get("original_physical_safe") and label.get("terminal_pass")
                and label.get("command_valid_all") and finite(label.get("D")))


def context_metadata(entry, attempt):
    ctx = attempt.get("context", {})
    return {"context_id": entry["context_id"], "ordinal": entry.get("ordinal", attempt.get("ordinal")),
            "role": entry.get("role", ctx.get("role", str(ctx.get("health_kind", "UNKNOWN")).lower().split("_")[0])),
            "front_or_rear": entry.get("front_or_rear", ctx.get("front_or_rear", "UNKNOWN")),
            "source_snapshot": ctx.get("source_snapshot", attempt.get("source_snapshot", entry.get("source_snapshot"))),
            "episode": ctx.get("episode", attempt.get("episode", entry.get("episode"))),
            "eligible": bool(entry.get("eligible", ctx.get("eligible", False))),
            "attempt_path": str(entry["attempt_path"])}


def iter_attempts(out):
    for entry in entries(read(Path(out) / "TEST_REGISTRY.json", [])):
        attempt = read(resolve(out, entry["attempt_path"]))
        yield entry, attempt or {}, context_metadata(entry, attempt or {})


def event_is_active(event):
    return bool(event and (event.get("first_capacity_event") or event.get("first_active_indices")
                          or any(int(count) > 0 for count in event.get("capacity99_count_by_channel", []))))


def _query_view(row):
    # The runner's established STEP29 vocabulary is retained. The explicit
    # shorter aliases cover STEP30's registry design without target inference.
    row = dict(row)
    row.setdefault("safe_accepted", bool(row.get("accepted") and row.get("safe")))
    row.setdefault("unsafe_accepted", bool(row.get("accepted") and not row.get("safe_accepted")))
    row.setdefault("oracle_any_gamma", bool(row.get("common_oracle", False)))
    row.setdefault("oracle_binary", False)
    return row


def query_summary(data):
    data = [_query_view(row) for row in data]
    denominator = sum(bool(row["oracle_any_gamma"]) for row in data)
    binary_denominator = sum(bool(row["oracle_binary"]) for row in data)
    successful = sum(bool(row["safe_accepted"]) for row in data)
    return {"queries": len(data), "oracle_any_gamma_queries": denominator, "oracle_binary_queries": binary_denominator,
            "accepted": sum(bool(row.get("accepted")) for row in data), "safe_accepted": successful,
            "unsafe_accepted": sum(bool(row["unsafe_accepted"]) for row in data),
            "ABSTAIN": sum(not bool(row.get("accepted")) for row in data),
            "safe_coverage_common_oracle": successful / denominator if denominator else None,
            "safe_coverage_binary_oracle": sum(bool(row["safe_accepted"] and row["oracle_binary"]) for row in data) / binary_denominator if binary_denominator else None,
            "safe_middle_accepted": sum(bool(row["safe_accepted"] and row.get("choice") in (.75, .5, .25)) for row in data),
            **{key: sum(bool(row.get(key)) for row in data) for key in ("physical_error", "local_error", "terminal_error", "numerical_incomplete")}}


def _query_counter_add(counter, row):
    counter["queries"] += 1
    for output, source in (("oracle_any_gamma_queries", "oracle_any_gamma"), ("oracle_binary_queries", "oracle_binary"),
                           ("accepted", "accepted"), ("safe_accepted", "safe_accepted"), ("unsafe_accepted", "unsafe_accepted"),
                           ("physical_error", "physical_error"), ("local_error", "local_error"),
                           ("terminal_error", "terminal_error"), ("numerical_incomplete", "numerical_incomplete")):
        counter[output] += bool(row.get(source))
    counter["ABSTAIN"] += not bool(row.get("accepted"))
    counter["safe_middle_accepted"] += bool(row["safe_accepted"] and row.get("choice") in (.75, .5, .25))
    counter["safe_on_binary_denominator"] += bool(row["safe_accepted"] and row["oracle_binary"])


def _query_counter_finish(counter):
    keys = ("queries", "oracle_any_gamma_queries", "oracle_binary_queries", "accepted", "safe_accepted", "unsafe_accepted",
            "ABSTAIN", "safe_middle_accepted", "physical_error", "local_error", "terminal_error", "numerical_incomplete")
    result = {key: int(counter[key]) for key in keys}
    denominator = counter["oracle_any_gamma_queries"]; binary = counter["oracle_binary_queries"]
    result.update(safe_coverage_common_oracle=counter["safe_accepted"] / denominator if denominator else None,
                  safe_coverage_binary_oracle=counter["safe_on_binary_denominator"] / binary if binary else None)
    return result


def engineering_summary(data, planned):
    sent = [row for row in data if row.get("selected_command_sent")]
    late_sent = sum(not finite(row.get("command_ready_ms")) or row["command_ready_ms"] > 20. for row in sent)
    qp_count = sum(endpoint.get("QP_call_count", len(endpoint.get("solver_ledger_delta", endpoint.get("solver_ledger", []))))
                   for row in data for endpoint in (row.get("C", {}), row.get("B", {})))
    return {"planned": planned, "recorded": len(data), "missing_planned": max(0, planned - len(data)),
            "timely_recognized_sent": len(sent) - late_sent,
            "timely_recognized_rate_planned": (len(sent) - late_sent) / planned,
            "timely_middle_sent": sum(row.get("selected_gamma") in (.75, .5, .25) and finite(row.get("command_ready_ms")) and row["command_ready_ms"] <= 20. for row in sent),
            "timely_injured_middle_contexts": sorted({row["context_id"] for row in sent if row.get("role") in ("thigh", "calf") and row.get("selected_gamma") in (.75, .5, .25) and finite(row.get("command_ready_ms")) and row["command_ready_ms"] <= 20.}),
            "late_sent": late_sent, "command_available": sum(bool(row.get("command_available")) for row in data),
            "raw_valid_but_late": sum(bool(row.get("raw_valid_but_late")) for row in data),
            "overall_deadline_failure": sum(bool(row.get("overall_deadline_failure")) or (finite(row.get("command_ready_ms")) and row["command_ready_ms"] > 20.) for row in data),
            "budget_cutoff_actions": sum(action.get("evaluation_status") == "NOT_EVALUATED_BUDGET" for row in data for action in row.get("actions", {}).values()),
            "unrequested_B": sum(row.get("B", {}).get("status") == "NOT_REQUESTED" for row in data),
            "runtime_setup_events": sum(endpoint.get("runtime_setup_events", 0) for row in data for endpoint in (row.get("C", {}), row.get("B", {}))),
            "QP_calls": qp_count, "all_latency_ms": stats(row.get("command_ready_ms") for row in data),
            "selected_gamma_counts": dict(Counter(str(row.get("selected_gamma")) for row in sent)),
            "statuses": dict(Counter(row.get("status", "MISSING_STATUS") for row in data))}


def _engineering_projection(numeric):
    """Keep scalar analysis facts, never accumulate 144 full numeric windows."""
    result = {key: numeric.get(key) for key in ("status", "selected_command_sent", "selected_gamma", "command_ready_ms",
              "command_available", "raw_valid_but_late", "overall_deadline_failure", "intention_gamma")}
    result["actions"] = {key: {"evaluation_status": action.get("evaluation_status")} for key, action in numeric.get("actions", {}).items()}
    for name in ("C", "B"):
        endpoint = numeric.get(name, {})
        result[name] = {"status": endpoint.get("status"), "runtime_setup_events": endpoint.get("runtime_setup_events", 0),
                        "QP_call_count": len(endpoint.get("solver_ledger_delta", endpoint.get("solver_ledger", [])))}
    return result


def action_recognition_counts(labels, points, role, side, method):
    """Action-level recall, separate from descending policy selection.

    A safe lower-gamma action which is not selected after a larger safe action
    is still a recognized candidate, not a policy error. This table therefore
    checks every gamma's frozen static gates/U_D at all 13 shared gaps.
    """
    for gamma in GAMMAS:
        if method == "BINARY_LOCAL" and gamma not in (0., 1.):
            continue
        key = gamma_key(gamma); label = labels.get(key, {}); point = points.get(key, {})
        actual_safe = [safe(label, gap) for gap in GAPS_M]
        known = bool(point)
        recognized = [bool(known and all(point.get(gate) for gate in STATIC_GATES)
                           and finite(point.get("U_D")) and point["U_D"] <= gap) for gap in GAPS_M]
        yield {"method": method, "gamma": gamma, "role": role, "front_or_rear": side,
               "recorded_action_predictions": int(known), "shared_gap_queries": len(GAPS_M),
               "actual_safe_action_queries": sum(actual_safe),
               "recognized_safe_action_queries": sum(a and p for a, p in zip(actual_safe, recognized)),
               "safe_action_rejected_queries": sum(a and not p for a, p in zip(actual_safe, recognized)),
               "unsafe_action_accepted_queries": sum(not a and p for a, p in zip(actual_safe, recognized)),
               "action_rejected_queries": sum(not value for value in recognized),
               "physical_error": sum(not bool(label.get("original_physical_safe")) and p for p in recognized),
               "local_error": sum(bool(label.get("complete") and finite(label.get("D")) and label["D"] > gap and p) for gap, p in zip(GAPS_M, recognized)),
               "terminal_error": sum(not bool(label.get("terminal_pass")) and p for p in recognized),
               "numerical_incomplete": sum(not bool(label.get("complete")) and p for p in recognized)}


def _prediction_methods(attempt, out):
    document = read(resolve(out, attempt["predictions_path"]), {}) if attempt.get("predictions_path") else attempt.get("predictions", {})
    return document.get("queries", document.get("predictions", document))


def _points(methods, method):
    if not methods:
        return {}
    first = next(iter(methods.values()))
    return first.get(method, {}).get("predictions", {}) if isinstance(first, dict) else {}


def intervals_for(attempt, metadata, out):
    labels = attempt.get("labels", {})
    points = _points(_prediction_methods(attempt, out), "LOCAL_GEOMETRY")
    cuts = {0., .032}
    for label in labels.values():
        if finite(label.get("D")) and 0. <= label["D"] <= .032:
            cuts.add(float(label["D"]))
    for point in points.values():
        if finite(point.get("U_D")) and 0. <= point["U_D"] <= .032:
            cuts.add(float(point["U_D"]))
    for left, right in zip(sorted(cuts)[:-1], sorted(cuts)[1:]):
        gap = (left + right) / 2.
        feasible = [gamma for gamma in GAMMAS if safe(labels.get(gamma_key(gamma), {}), gap)]
        approved = [gamma for gamma in GAMMAS if gamma_key(gamma) in points
                    and all(points[gamma_key(gamma)].get(gate) for gate in STATIC_GATES)
                    and finite(points[gamma_key(gamma)].get("U_D")) and points[gamma_key(gamma)]["U_D"] <= gap]
        binary = [gamma for gamma in feasible if gamma in (0., 1.)]
        yield {**metadata, "left_m": left, "right_m": right, "endpoint_equalities_in_query_table": True,
               "actual_feasible_gamma": feasible, "actual_binary_gamma": binary,
               "predicted_gamma": max(approved) if approved else "ABSTAIN",
               "predicted_binary_gamma": max([gamma for gamma in approved if gamma in (0., 1.)], default="ABSTAIN"),
               "middle_only_safe": bool(feasible and not binary),
               "actual_progress20_m": {gamma_key(gamma): labels[gamma_key(gamma)].get("progress20_m") for gamma in feasible}}


def report(out):
    out = Path(out)
    manifest = read(out / "MANIFEST.json", {})
    finished = read(out / "RUN_FINISHED.json", {})
    model = read(out / "models/MODEL_FREEZE.json", {})
    method_counts, group_counts = defaultdict(Counter), defaultdict(Counter)
    paired = defaultdict(dict); query_count = 0
    for raw in rows(out / "QUERY_RESULTS.jsonl"):
        row = _query_view(raw); method = row["method"]; query_count += 1
        _query_counter_add(method_counts[method], row)
        for field in ("role", "front_or_rear", "episode", "gap_m"):
            _query_counter_add(group_counts[(field, str(row.get(field, "UNKNOWN")), method)], row)
        if method in ("LOCAL_GEOMETRY", "BINARY_LOCAL"):
            # Retain only a compact paired choice, never each query's full
            # numeric prediction, matrix, prefix, or event dictionaries.
            paired[(row["context_id"], row["gap_m"])][method] = {key: row.get(key) for key in
                ("choice", "safe_accepted", "accepted", "progress20_m")}
    methods = {method: _query_counter_finish(method_counts[method]) for method in METHODS}
    csv_write(out / "METHOD_RESULTS.csv", [{"method": method, **summary} for method, summary in methods.items()])
    grouped = []
    for (field, value, method), counter in sorted(group_counts.items()):
        grouped.append({"field": field, "value": value, "method": method, **_query_counter_finish(counter)})
    csv_write(out / "GROUP_RESULTS.csv", grouped)
    gains, action_rows, interval_count, metadata_by_id = [], [], 0, {}
    missing_attempts = []
    gates, gamma_groups, recognition = Counter(), defaultdict(list), defaultdict(Counter)
    with (out / "ACTION_CHANGE_INTERVALS.jsonl").open("w", encoding="utf-8", newline="\n") as stream:
        for entry, attempt, meta in iter_attempts(out):
            metadata_by_id[entry["context_id"]] = meta
            if not attempt:
                missing_attempts.append(entry["context_id"])
            labels = attempt.get("labels", {})
            events = attempt.get("events", {})
            prediction_methods = _prediction_methods(attempt, out)
            for method in METHODS[:5]:
                points = _points(prediction_methods, method)
                for counts in action_recognition_counts(labels, points, meta["role"], meta["front_or_rear"], method):
                    key = (method, counts["gamma"], meta["role"], meta["front_or_rear"])
                    recognition[key].update({name: value for name, value in counts.items() if name not in ("method", "gamma", "role", "front_or_rear")})
            for gamma in GAMMAS:
                key = gamma_key(gamma); lab = labels.get(key, {}); event = events.get(key) or {}
                action = attempt.get("actions", {}).get(key, {})
                action_rows.append({**meta, "gamma": gamma, "recorded": key in labels,
                    "command_available": bool(action.get("available", action.get("command_valid", False))),
                    "complete_501": bool(lab.get("complete")), "physical_terminal_safe": physical_terminal_safe(lab),
                    "physical_failure": bool(lab.get("original_failure") or lab.get("observed_original_physical_failure")),
                    "terminal_failure_complete": bool(lab.get("complete") and not lab.get("terminal_pass")),
                    "numerical_incomplete": not bool(lab.get("complete")), "D_m": lab.get("D"), "Y": lab.get("Y"),
                    "progress20_m": lab.get("progress20_m"), "capacity_event_observed": event_is_active(event),
                    "first_capacity_event": event.get("first_capacity_event"), "first_active_indices": event.get("first_active_indices"),
                    "raw_min_margin_nm": event.get("raw_min_margin_nm"), "sent_min_margin_nm": event.get("sent_min_margin_nm"),
                    "applied_min_margin_nm": event.get("applied_min_margin_nm"), "capacity99_count_by_channel": event.get("capacity99_count_by_channel"),
                    "integral_updated_slots": event.get("integral_updated_slots"), "integral_frozen_slots": event.get("integral_frozen_slots"),
                    "controls_path": attempt.get("controls_paths", {}).get(key), "actual_artifact": attempt.get("actual_artifacts", attempt.get("artifacts", {})).get(key),
                    "unavailable_reason": action.get("unavailable_reason")})
                gamma_groups[(gamma, meta["role"], meta["front_or_rear"])].append(action_rows[-1])
            for interval in intervals_for(attempt, meta, out):
                stream.write(json.dumps(_encode(interval), ensure_ascii=False, allow_nan=False, separators=(",", ":")) + "\n")
                interval_count += 1
            for gap in GAPS_M:
                pair = paired.get((meta["context_id"], gap), {})
                main = pair.get("LOCAL_GEOMETRY", {})
                if not main.get("safe_accepted") or main.get("choice") not in (.75, .5, .25):
                    continue
                gamma = float(main["choice"]); key = gamma_key(gamma); label = labels.get(key, {})
                event = events.get(key) or {}; b = labels.get("0", {}); binary = pair.get("BINARY_LOCAL", {})
                comparisons = []
                if safe(b, gap) and finite(label.get("progress20_m")) and finite(b.get("progress20_m")) and label["progress20_m"] - b["progress20_m"] > 1e-12:
                    comparisons.append(("OBSERVED_SAFE_B", 0., b["progress20_m"], label["progress20_m"] - b["progress20_m"]))
                if binary.get("safe_accepted") and finite(binary.get("progress20_m")) and finite(label.get("progress20_m")) and label["progress20_m"] - binary["progress20_m"] > 1e-12:
                    comparisons.append(("BINARY_LOCAL_ACTUALLY_SELECTED", binary["choice"], binary["progress20_m"], label["progress20_m"] - binary["progress20_m"]))
                if not safe(labels.get("0", {}), gap) and not safe(labels.get("1", {}), gap):
                    comparisons.append(("MIDDLE_ONLY_ACTION_SET_EXTENSION", None, None, None))
                for comparison, baseline, baseline_progress, gain in comparisons:
                    gains.append({**meta, "gap_m": gap, "gamma": gamma, "comparison": comparison,
                        "binary_choice": binary.get("choice", "MISSING_QUERY"), "baseline_gamma": baseline,
                        "progress20_m": label.get("progress20_m"), "baseline_progress20_m": baseline_progress,
                        "actual_progress_gain_m": gain, "capacity_event_observed": event_is_active(event),
                        "first_capacity_event": event.get("first_capacity_event"), "first_active_indices": event.get("first_active_indices"),
                        "controls_path": attempt.get("controls_paths", {}).get(key), "attempt_path": meta["attempt_path"]})
            points = _points(_prediction_methods(attempt, out), "LOCAL_GEOMETRY")
            for key, point in points.items():
                for gate in STATIC_GATES:
                    gates[key + ":" + meta["role"] + ":" + gate] += not bool(point.get(gate))
    csv_write(out / "ACTION_RESULTS.csv", action_rows)
    write(out / "ACTION_RESULTS.json", action_rows)
    csv_write(out / "TASK_GAIN_PAIRS.csv", gains); write(out / "TASK_GAIN_PAIRS.json", gains)
    action_group_rows = []
    for (gamma, role, side), data in sorted(gamma_groups.items()):
        action_group_rows.append({"gamma": gamma, "role": role, "front_or_rear": side, "planned": 8,
            "recorded": sum(row["recorded"] for row in data), "command_available": sum(row["command_available"] for row in data),
            "complete_501": sum(row["complete_501"] for row in data), "physical_terminal_safe": sum(row["physical_terminal_safe"] for row in data),
            "physical_failure": sum(row["physical_failure"] for row in data), "terminal_failure_complete": sum(row["terminal_failure_complete"] for row in data),
            "numerical_incomplete": sum(row["numerical_incomplete"] for row in data),
            "capacity_event_observed": sum(row["capacity_event_observed"] for row in data)})
    csv_write(out / "GAMMA_ROLE_SIDE_RESULTS.csv", action_group_rows)
    recognition_rows = []
    for (method, gamma, role, side), counts in sorted(recognition.items()):
        denominator = counts["actual_safe_action_queries"]
        recognition_rows.append({"method": method, "gamma": gamma, "role": role, "front_or_rear": side, **dict(counts),
                                 "action_recall": counts["recognized_safe_action_queries"] / denominator if denominator else None})
    csv_write(out / "GAMMA_ROLE_SIDE_RECOGNITION.csv", recognition_rows)
    model_group_rows = []
    for configuration, groups in model.get("groups", {}).items():
        for group, values in groups.items():
            model_group_rows.append({"configuration": configuration, "gamma_role": group, **values})
    csv_write(out / "MODEL_GROUP_COVERAGE.csv", model_group_rows)
    engineering_data = []
    for entry in entries(read(out / "ENGINEERING_REGISTRY.json", [])):
        numeric = read(resolve(out, entry["numeric_path"]), {})
        meta = metadata_by_id.get(entry["context_id"], {})
        engineering_data.append({**_engineering_projection(numeric), **meta, "policy": entry["policy"], "gap_m": entry.get("gap_m", entry.get("gap")),
                                 "numeric_path": entry["numeric_path"], "intention_gamma": entry.get("intention_gamma", numeric.get("intention_gamma"))})
    engineering = {policy: engineering_summary([row for row in engineering_data if row["policy"] == policy], 48) for policy in POLICIES}
    engineering["all"] = engineering_summary(engineering_data, 144)
    csv_write(out / "ENGINEERING_RESULTS.csv", [{key: row.get(key) for key in ("context_id", "ordinal", "role", "front_or_rear", "policy", "gap_m", "status", "selected_command_sent", "selected_gamma", "intention_gamma", "command_ready_ms", "numeric_path")} for row in engineering_data])
    fresh_data = []
    for entry in entries(read(out / "FRESH_REGISTRY.json", [])):
        result = read(resolve(out, entry["result_path"]), {})
        meta = metadata_by_id.get(entry["context_id"], {})
        online = read(resolve(out, result["online_path"]), {}) if result.get("online_path") else {}
        ticks = result.get("tick_latency_ms", [])
        gap = result.get("gap_m", online.get("gap_m"))
        full_ticks = bool(len(ticks) == 50 and all(finite(value) and value <= 20. for value in ticks))
        actual_safe = safe(result.get("labels", {}), gap) if finite(gap) else False
        fresh_data.append({**meta, "status": result.get("status", entry.get("status", "MISSING_STATUS")),
            "gamma": result.get("gamma"), "gap_m": gap, "sent": bool(online.get("selected_command_sent")),
            "complete_501": bool(result.get("labels", {}).get("complete")), "actual_safe_at_own_gap": actual_safe,
            "all_50_ticks_20ms": full_ticks, "first_command_matches": result.get("first_command_matches"),
            "tick_latency_ms": ticks, "result_path": entry["result_path"], "online_path": result.get("online_path")})
    csv_write(out / "FRESH_RESULTS.csv", fresh_data)
    fresh_ok = [row for row in fresh_data if row["role"] in ("thigh", "calf") and row["gamma"] in (.75, .5, .25)
                and row["sent"] and row["complete_501"] and row["actual_safe_at_own_gap"] and row["all_50_ticks_20ms"] and row["first_command_matches"]]
    injured_gains = [row for row in gains if row["role"] in ("thigh", "calf")]
    gain_summary = {"comparison_counts": dict(Counter(row["comparison"] for row in gains)),
        "injured_source_snapshots": sorted({row["source_snapshot"] for row in injured_gains if row["source_snapshot"] is not None}),
        "injured_contexts": sorted({row["context_id"] for row in injured_gains}),
        "injured_episodes": sorted({row["episode"] for row in injured_gains if row["episode"] is not None}),
        "gain_comparisons_missing_source_identity": sum(row["source_snapshot"] is None or row["episode"] is None for row in injured_gains),
        "injured_gain_with_capacity_event": sum(row["capacity_event_observed"] for row in injured_gains),
        "observed_progress_gains_m": stats(row["actual_progress_gain_m"] for row in gains if row["comparison"] != "MIDDLE_ONLY_ACTION_SET_EXTENSION"),
        "ABSTAIN_baseline_imputed_as_zero": False}
    main = methods["LOCAL_GEOMETRY"]
    coverage_goal = bool(main["queries"] == 48 * 13 and main["unsafe_accepted"] == 0 and (main["safe_coverage_common_oracle"] or 0.) >= .40)
    gain_goal = bool(len(gain_summary["injured_source_snapshots"]) >= 4 and len(gain_summary["injured_episodes"]) >= 2 and gain_summary["injured_gain_with_capacity_event"] > 0)
    sent_injured = set().union(*(set(value["timely_injured_middle_contexts"]) for key, value in engineering.items() if key != "all"))
    deployment_goal = bool(len(sent_injured) >= 3 and len({row["context_id"] for row in fresh_ok}) >= 2 and engineering["all"]["late_sent"] == 0)
    numerical_complete = bool(finished.get("status") == "COMPLETED" and len(metadata_by_id) == 48 and not missing_attempts
                              and len(engineering_data) == 144 and len(fresh_data) == 12 and query_count == 48 * 13 * 8)
    science_status = "INJURED_ACTION_MECHANISM_SUPPORTED" if numerical_complete and coverage_goal and gain_goal else "NOT_ESTABLISHED"
    deployment_status = "INJURED_TIMELY_MIDDLE_DEPLOYMENT_CLOSED" if numerical_complete and deployment_goal else "NOT_ESTABLISHED"
    result = {"run_id": manifest.get("run_id"), "NUMERICAL_STATUS": finished.get("status", "INCOMPLETE"),
        "SCIENCE_STATUS": science_status, "DEPLOYMENT_STATUS": deployment_status,
        "GOAL_ZERO_ERRORS_40_PERCENT_COVERAGE": coverage_goal, "GOAL_INJURED_ACTUAL_MIDDLE_GAIN": gain_goal,
        "GOAL_INJURED_TIMELY_DEPLOYMENT": deployment_goal, "numerical_plan_complete": numerical_complete,
        "planned_test_contexts": 48, "recorded_test_contexts": len(metadata_by_id), "qualified_test_contexts": sum(meta["eligible"] for meta in metadata_by_id.values()),
        "missing_attempt_files": missing_attempts, "planned_query_rows": 48 * 13 * 8, "recorded_query_rows": query_count,
        "methods": methods, "task_gain": gain_summary, "gamma_role_side": action_group_rows,
        "gamma_role_side_recognition": recognition_rows, "model_groups": model_group_rows,
        "engineering": engineering, "fresh": {"planned": 12, "recorded": len(fresh_data), "safe_timely_injured_middle_contexts": sorted({row["context_id"] for row in fresh_ok}),
            "all_tick_latency_ms": stats(value for row in fresh_data for value in row["tick_latency_ms"]),
            "late_feedback_ticks": sum(finite(value) and value > 20. for row in fresh_data for value in row["tick_latency_ms"]),
            "statuses": dict(Counter(row["status"] for row in fresh_data))},
        "gate_rejections": dict(gates), "continuous_interval_count": interval_count, "model_freeze_path": "models/MODEL_FREEZE.json",
        "budget": finished.get("budget"), "historical_STEP29_extra_benefit": "NOT_ESTABLISHED_RETAINED",
        "post_new_TEST_tuning": False, "PID_prior_online_calls": 0, "E3_RL_hardware_authorized": False,
        "probe_population_success_rate_claim": False, "gap_queries_are_independent_experiments": False}
    write(out / "STEP30_RESULT.json", result)
    text = _report_text(result, manifest, model)
    (out / "STEP30_REPORT.md").write_text(text, encoding="utf-8", newline="\n")
    (out / "STEP30_RESEARCH_HANDOFF.md").write_text(_handoff_text(result, manifest), encoding="utf-8", newline="\n")
    return result


def _percent(value):
    return f"{100 * value:.2f}%" if value is not None else "无共同oracle分母"


def _report_text(result, manifest, model):
    lines = ["# STEP30：受损中间动作识别与在线出令", "",
        "日期：2026-10-08（Asia/Seoul）。Material Passport：experiment-agent / run / ANALYZED；图表：scipilot-figure-skill。", "",
        f"Run ID：{manifest.get('run_id')}；源提交：{manifest.get('source_commit', 'e5073e634224b090e7fb059fcc4d394443d7780d')}。",
        f"科学结论：**{result['SCIENCE_STATUS']}**；部署闭合：**{result['DEPLOYMENT_STATUS']}**。",
        f"固定48个TEST上下文记录{result['recorded_test_contexts']}，资格合格{result['qualified_test_contexts']}。共同五动作oracle上的主配置安全覆盖 {_percent(result['methods']['LOCAL_GEOMETRY']['safe_coverage_common_oracle'])}，错误接受{result['methods']['LOCAL_GEOMETRY']['unsafe_accepted']}。", "",
        "## 冻结设计与证据", "",
        "本轮保留STEP29动作调节器：同一当前状态、health和共享A/l/u下，严格Solved且有限的C/B端点构造γ={1,.75,.5,.25,0}。中间全primal凸组合是SYNTHESIZED_CONVEX_COMMAND，不是新的Solved优化结果。原clip、动力学/接触残差与零额外不等式slack不放宽。当前仿射命令检查不推出未来恢复安全或γ单调可行性。",
        "每个γ>0在首20ms执行一次动作，随后49个控制槽使用同一backup、anchor及积分语义；γ=0复用真实B0及b_after。各实际分支保留501状态、2ms dense采样和原1s物理/local/终端评价。首槽的实际方向进度由第10积分步与anchor之差得到。",
        "旧STEP26–29及STEP29中间动作只作为DEV，按完整stage/run/episode/context/γ/trajectory身份去重。新四条D30 reference生成24个固定受损上下文；TRAIN/CAL按整episode划分，失败或不完整邻居不删除、缺失末状态不填0。新TEST只确认冻结后设计，不参与模型、尺度、动作或阈值修改。",
        "主GEOMETRY_FULL_26保留命令条件化23维并加入方向侧前/后腿、故障关节q(rad)及sent归一化headroom；healthy使用方向侧calf作为机械参考及全通道最小headroom，是明确约定。NO_GEOMETRY_23仅删除新增三维。均为固定二次Ridge(alpha=1)，D及五个终端Y保持符号，不计算PID prior。",
        "k=5支持包括有限失败/未完成输入。主局部CAL在同γ×role中按冻结标准化距离取最近4个不同source snapshot，至少2episode；必要时用最近其它episode替换最远同episode项，不剔除失败CAL。UD=Dhat+max(0,maxLOCAL(D−Dhat))+1mm；UTj=abs(Yhatj)+maxLOCAL(abs(Yj−Yhatj))+.05。未校准组拒收并继续其它固定输入。局部储备是经验筛选，不是概率覆盖保证。",
        f"同一26维权重全组maxCAL、23维局部CAL、{{1,0}}同模型及冻结STEP29模型分别作为消融；总收益不能归因于单一模块。本轮实际多输出fit {model.get('actual_multioutput_estimator_fit_calls')} 次，等价标量输出 {model.get('scalar_output_regression_equivalents')}。模型组有限TRAIN数、完整CAL snapshot/episode与资格见[MODEL_GROUP_COVERAGE](MODEL_GROUP_COVERAGE.csv)及[MODEL_FREEZE](models/MODEL_FREEZE.json)；TRAIN/CAL身份见[DEV_SPLIT_REGISTRY](DEV_SPLIT_REGISTRY.json)。", "",
        "## 固定配对科学结果", "",
        "T30_P054/N054/P066/N066各四个snapshot×healthy/thigh/calf，共48；recipe seed只作标识，不算随机重复。每个可用γ有独立实际1s轨迹；13个gap共享这五动作bank，多gap不是独立实验。全部计划输入及不可用/失败保留。", "",
        "| 方法 | 安全接受 | 错误接受 | 五动作oracle覆盖 | ABSTAIN |",
        "|---|---:|---:|---:|---:|"]
    for method, value in result["methods"].items():
        lines.append(f"| {method} | {value['safe_accepted']} | {value['unsafe_accepted']} | {_percent(value['safe_coverage_common_oracle'])} | {value['ABSTAIN']} |")
    gain = result["task_gain"]
    lines += ["", f"实际受损中间动作增益/扩展涉及{len(gain['injured_source_snapshots'])}个不同source snapshot、{len(gain['injured_episodes'])}条TEST episode；其中有能力或99%事件的增益比较{gain['injured_gain_with_capacity_event']}条。",
        f"比较类型分别为：{gain['comparison_counts']}。OBSERVED_SAFE_B比较实际安全B的首20ms进度；BINARY_LOCAL_ACTUALLY_SELECTED比较二元策略实际选择；MIDDLE_ONLY_ACTION_SET_EXTENSION要求C/B均不安全而认可中间动作安全。ABSTAIN没有被当作零运动。各gap不是独立重复，同一snapshot计数去重。",
        "逐比较明细见[TASK_GAIN_PAIRS](TASK_GAIN_PAIRS.csv)；全部γ×role×前/后腿实际结果见[GAMMA_ROLE_SIDE_RESULTS](GAMMA_ROLE_SIDE_RESULTS.csv)，包括原物理、完整终端、数值未完成。[GAMMA_ROLE_SIDE_RECOGNITION](GAMMA_ROLE_SIDE_RECOGNITION.csv)逐候选动作统计13个共享gap上的召回、拒收、错误：更大γ先被选择时，安全低γ仍按自身门控统计，不错误算成策略失败。降序最终选择另按方法、role、side、episode及gap分列于[GROUP_RESULTS](GROUP_RESULTS.csv)。失败类型可能重叠，不互相抵消。",
        "各12通道raw/sent/applied最小余量、capacity99计数、首激活通道及feedback积分更新/冻结槽见[ACTION_RESULTS](ACTION_RESULTS.json)，完整numeric由attempt/controls/artifact路径引用。未激活受损不凭health名称称能力绑定；缺少证据保持缺失。",
        f"[0,32]mm解析区间记录{result['continuous_interval_count']}条，见[ACTION_CHANGE_INTERVALS](ACTION_CHANGE_INTERVALS.jsonl)：同时保存真实五动作可行集、二元集合、预测选择和实际20ms进度，不假设γ健康单调性。", "",
        "## 20ms实际出令与fresh闭合", "",
        "计时始于准备；共用矩阵/state/health只验证一次，批量native前缀各从同初态恢复并实际推进10步。CAL根本不合格组先排除，不把未模拟γ标通过。矩阵检查、实际prefix、推断及必要numeric拷贝计入command-ready；JSON与文件写入在之后。动态solver限仍≤6ms，absolute deadline仍20ms。过期有效结果不发送、不传播；NOT_EVALUATED_BUDGET与不可恢复分开。",
        "固定gap按ordinal循环1.5/2.5/4/8/16/32mm，三策略顺序轮换；所有current QP重算，不读取teacher命令。probe gap仅用ACTUAL标签打开前的冻结预测窗口；无中间窗口保留原输入fixed fallback，不强制发送意图γ。probe是机制测试，不能合并为总体成功率。", "",
        "| 策略 | 及时认可发送/48 | 中间γ发送 | raw有效但过期 | 全部超时 | p99 / max(ms) |",
        "|---|---:|---:|---:|---:|---|"]
    for policy in POLICIES:
        data = result["engineering"][policy]; latency = data["all_latency_ms"]
        lines.append(f"| {policy} | {data['timely_recognized_sent']} | {data['timely_middle_sent']} | {data['raw_valid_but_late']} | {data['overall_deadline_failure']} | {latency['p99']} / {latency['max']} |")
    lines += ["", f"全部144计划工程行记录{result['engineering']['all']['recorded']}；late发送{result['engineering']['all']['late_sent']}；runtime setup事件{result['engineering']['all']['runtime_setup_events']}。固定与probe分别列报，不删除不可用、cutoff或慢输入。startup完整耗时见STARTUP.json。",
        f"固定12个fresh索引记录{result['fresh']['recorded']}；完整、安全、local/终端通过且全部50tick≤20ms的受损中间fresh context为{result['fresh']['safe_timely_injured_middle_contexts']}。首命令一致性、实际501状态和全部tick时延见[FRESH_RESULTS](FRESH_RESULTS.csv)。未及时认可不模拟，也不换点。",
        f"fresh超时tick总数{result['fresh']['late_feedback_ticks']}；实际全部tick时延统计{result['fresh']['all_tick_latency_ms']}。单次调节+反馈恢复不是连续shield、硬件实时或全局viability证据。", "",
        "## 交付与研究交接", "",
        f"预算事实：{result['budget']}。同一增量账本记全部启动、DEV、reference、prefix、online、fresh与失败真实QP/积分步；达到预算仍交付，不追加模型或挑TEST。",
        "纯mock必要测试、单次当前身份/文件核验及scoped Git diff检查由主线保存；不将Git收尾作为数值门。历史结果只读，STEP29额外收益NOT_ESTABLISHED原结论保留，不重跑历史端点、不补缺失raw、不访问机器人运控算法。",
        "两张证据图展示全部48×5实际动作及完整144工程计时/意图与实发γ，使用SciPilot EDA、色盲/marker冗余、IEEE双栏、PNG视觉复核与矢量导出。不以选择gap或隐藏慢输入制造机制闭合。", "",
        "```ini", "AUTHORIZE_STEP30_INJURED_GOVERNOR_CLOSURE = TRUE", "GAMMA_GRID_UNCHANGED = TRUE",
        f"NUMERICAL_STATUS = {result['NUMERICAL_STATUS']}", f"SCIENCE_STATUS = {result['SCIENCE_STATUS']}", f"DEPLOYMENT_STATUS = {result['DEPLOYMENT_STATUS']}",
        f"GOAL_ZERO_ERRORS_40_PERCENT_COVERAGE = {str(result['GOAL_ZERO_ERRORS_40_PERCENT_COVERAGE']).upper()}",
        f"GOAL_INJURED_ACTUAL_MIDDLE_GAIN = {str(result['GOAL_INJURED_ACTUAL_MIDDLE_GAIN']).upper()}",
        f"GOAL_INJURED_TIMELY_DEPLOYMENT = {str(result['GOAL_INJURED_TIMELY_DEPLOYMENT']).upper()}",
        "MAX_NEW_QP_CALLS = 24000", "MAX_NEW_PHYSICS_STEPS = 240000", "MAX_NUMERICAL_WALL_HOURS = 2",
        "MAX_MODEL_CONFIGURATIONS = 2", "MAX_DEV_CONTEXT_RECOMPUTATIONS = 5", "NEW_INJURED_DEV_CONTEXTS = 24",
        "NEW_TEST_CONTEXTS = 48", "MAX_ENGINEERING_ROWS = 144", "MAX_FRESH_INDICES = 12",
        "LOCAL_CAL_SNAPSHOTS = 4", "LOCAL_CAL_MIN_EPISODES = 2", "POST_NEW_TEST_TUNING = FALSE",
        "DEADLINE_MS = 20", "SOLVER_TIME_LIMIT_UPPER_S = 0.006", "BACKUP_HORIZON_S = 1", "DENSE_PHYSICS_DT_S = 0.002",
        "PHYSICAL_AND_TERMINAL_BOUNDS_UNCHANGED = TRUE", "HISTORICAL_RESULTS_UNCHANGED = TRUE",
        "MISSING_HISTORICAL_EVIDENCE_REPLAY = FALSE", "E3_RL_HARDWARE = NOT_AUTHORIZED", "```", ""]
    return "\n".join(lines)


def _handoff_text(result, manifest):
    return "\n".join(["# STEP30研究交接", "", f"Run ID：{manifest.get('run_id')}",
        f"科学结论：{result['SCIENCE_STATUS']}", f"部署闭合：{result['DEPLOYMENT_STATUS']}", "",
        "冻结主配置GEOMETRY_FULL_26；NO_GEOMETRY_23为唯一另一配置。全组CAL、binary局部均复用主权重；STEP29模型保持历史冻结。",
        "全部身份索引与逐attempt numeric分离；QUERY_RESULTS/13gap复用实际bank，不作独立重复。TASK_GAIN_PAIRS区分安全B、二元真实选择和中间-only扩展；ABSTAIN无零运动基线。",
        f"零错/40%覆盖目标：{result['GOAL_ZERO_ERRORS_40_PERCENT_COVERAGE']}；受损任务收益/扩展与真实能力事件目标：{result['GOAL_INJURED_ACTUAL_MIDDLE_GAIN']}；及时中间出令+fresh闭合目标：{result['GOAL_INJURED_TIMELY_DEPLOYMENT']}。",
        "固定gap工程与预测窗口probe保留各48分母，probe不称总体成功率；所有late有效结果不发送，fresh拒收/过期不传播、不换索引。",
        "ACTUAL完整501状态、原physical/local/terminal、首τ匹配和全50tick事实决定部署结论。热力图/进度/时延图展示所有计划输入，没有选择gap案例。",
        "后续只根据新授权开展研究；本轮模型、尺度、输入、动作、阈值及历史证据不可回写。无E3/RL/硬件授权；不访问机器人运控算法。", ""])


if __name__ == "__main__":
    parser = argparse.ArgumentParser(); parser.add_argument("out")
    value = report(parser.parse_args().out)
    print(value["SCIENCE_STATUS"], value["DEPLOYMENT_STATUS"])
