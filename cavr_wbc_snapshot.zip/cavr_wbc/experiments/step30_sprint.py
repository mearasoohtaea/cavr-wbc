"""One fixed incremental STEP30 DEV/confirmation/online/fresh plan."""
import argparse
from copy import deepcopy
from datetime import datetime,timezone
import gc
import json
import os
import shutil
from time import perf_counter
import traceback
import numpy as np
from cavr_wbc.experiments import step17_formal_panel as frozen,step26_sim as reference_sim,step29_sim as sim
from cavr_wbc.experiments.step26_features_storage import save_bank,load_bank
from cavr_wbc.experiments.step28_sprint import home_context
from cavr_wbc.experiments.step29_sprint import source_context
from cavr_wbc.experiments.step30_io import ROOT,SOURCE29,RUN_ID,PARENT,PROTOCOL,read,write,append,sha,relative,small_prefix,index_entry
from cavr_wbc.experiments.step30_budget import SprintBudget,SprintLimit
from cavr_wbc.experiments import step30_data as devdata
from cavr_wbc.control.step30_actions import GAMMA_GRID,prepare_shared,make_action,GeometryMapping,convex_command_property
from cavr_wbc.control.step30_kernel import Kernel
from cavr_wbc.control.step30_margin import fit_fixed,decide,labels,safe,gamma_key,GAPS_M
from cavr_wbc.control.step29_margin import load_bundle as load29,decide as decide29
from cavr_wbc.platforms.go2_mujoco import extract_actuator_audit,extract_healthy_torque_limits

DEV_EPISODES=(('D30_P048',.048,.0025,.0025,20261179),('D30_N048',-.048,.0025,.0025,20261179),
    ('D30_P064',.064,.0025,.0025,20261180),('D30_N064',-.064,.0025,.0025,20261180))
TEST_EPISODES=(('T30_P054',.054,.002,.002,20261181),('T30_N054',-.054,.002,.002,20261181),
    ('T30_P066',.066,-.002,.002,20261182),('T30_N066',-.066,-.002,.002,20261182))
DEV_TICKS=(25,33,41);TEST_TICKS=(27,32,37,42);FIXED_GAPS=(.0015,.0025,.004,.008,.016,.032)
FRESH_INDICES=(0,4,8,13,17,21,26,30,34,39,43,47)


def missing(reason):return {'complete':False,'D':None,'Y':None,'valid':False,'original_physical_safe':False,
    'terminal_pass':False,'command_valid_all':False,'original_failure':None,'progress20_m':None,'reason':reason,'trajectory_id':None}


def equivalent(a,b):
    if isinstance(a,dict)and isinstance(b,dict):return a.keys()==b.keys()and all(equivalent(a[k],b[k])for k in a)
    if isinstance(a,(list,tuple,np.ndarray))or isinstance(b,(list,tuple,np.ndarray)):
        try:return bool(np.array_equal(a,b,equal_nan=True))
        except(TypeError,ValueError):return a==b
    return a==b


def current(kernel,c,budget,out,directory):
    """Two current QPs; independent prefix batch plus same-input single proof."""
    kernel.reset(c);C=kernel.nominal(c,budget,'CURRENT_C',c['context_id']);B=kernel.first_backup(c,budget,'CURRENT_B',c['context_id'])
    workspace=prepare_shared(c,C,B);actions={gamma_key(g):make_action(c,C,B,g,workspace=workspace)for g in GAMMA_GRID}
    inputs={};prefixes={};valid={}
    for key,action in actions.items():
        if action['command_valid']:
            kernel.condition_action(c,action);valid[float(key)]=action
    if 1. in valid:prefixes['1']=kernel.prefix_action(c,valid[1.],budget)
    tail={g:action for g,action in valid.items()if g!=1.}
    if tail:
        batch=kernel.prefix_actions(c,tail,budget)
        for key,p in batch.items():prefixes[gamma_key(float(key))]=p
    if any((p.get('identity')or{}).get('native_return_code',0)<0 for p in prefixes.values()):
        write(directory/'PREFIX_NATIVE_CONTRACT_ERROR.json',{'context':c,'prefixes':prefixes})
        raise ValueError('negative native member return is a structural error')
    comparisons={}
    for g,action in tail.items():
        # The reference batch and this single dispatch use exactly the same
        # independently restored input and command. Both integrals count.
        kernel.condition_action(c,action);single=kernel.prefix_action(c,action,budget)
        batch=prefixes[gamma_key(g)]
        keys=('complete','original_physical_pass','D_prefix_m','endpoint','actual_steps','state_count','numeric')
        match=all(equivalent(single.get(k),batch.get(k))for k in keys)
        comparisons[gamma_key(g)]={'single_batch_exact_numeric':match,'single':single,'batch_identity':batch.get('identity')}
        if not match:
            write(directory/'PREFIX_EQUIVALENCE_FAILURE.json',comparisons)
            raise ValueError('single/batch prefix numerical contract differs')
    for key,action in actions.items():
        p=prefixes.get(key,{'complete':False,'available':False,'original_physical_pass':False,'reason':'CURRENT_COMMAND_UNAVAILABLE'})
        f=None;error=None
        if action['command_valid']:
            try:f=kernel.features(c,action,p)
            except(ValueError,TypeError,KeyError)as exc:error=str(exc)
        inputs[key]={'gamma':float(key),'role':c['health_kind'].split('_')[0].lower(),'features26':f,
            'prefix':p,'first_command_valid':bool(action['command_valid']),'input_error':error}
    write(directory/'CURRENT_INPUT.json',{'context':c,'C':C,'B':B,'actions':actions,'inputs':inputs,
        'shared_identity_checks':workspace.shared_identity_checks,'prefix_equivalence':comparisons,'no_future_actual_read':True})
    return C,B,actions,inputs


def events(branch,action):
    controls=branch['controls'];raw=[];sent=[];applied=[];active=np.zeros(12,int);updated=frozen_count=0
    for control in controls:
        cap=np.asarray(control['capacity_interface']['effective_capacity_nm'],float)
        r=np.asarray(control['tau_raw'],float);s=np.asarray(control['tau_sent'],float);p=np.asarray(control['tau_applied'],float)
        if all(v.shape==(12,)and np.isfinite(v).all()for v in(r,s,p,cap)):
            raw.append(cap-np.abs(r));sent.append(cap-np.abs(s));applied.append(cap-np.abs(p));active+=(np.abs(s)>=.99*cap)
        integral=control.get('integral_record')
        if integral is not None:updated+=bool(integral['updated']);frozen_count+=not integral['updated']
    minimum=lambda rows:np.min(rows,axis=0).tolist()if rows else None
    return {'first_capacity_event':bool(action.get('first_capacity_event')),
        'first_active_indices':action['capacity_interface'].get('sent_99_percent_active_indices',[]),
        'raw_min_margin_nm':minimum(raw),'sent_min_margin_nm':minimum(sent),'applied_min_margin_nm':minimum(applied),
        'capacity99_count_by_channel':active.tolist(),'any_actual_capacity99_event':bool(np.any(active)),
        'integral_updated_slots':updated,'integral_frozen_slots':frozen_count,'control_rows':len(controls)}


def probe(inputs,bundle,ordinal):
    # Predicate and gap selection consume current predicted margins only.
    d=decide(bundle,inputs,.032);points=d['predictions'];static=('support_gate','distance_gate','calibration_gate',
        'pose_gate','current_command_gate','prefix_available_gate','prefix_physical_gate','terminal_gate')
    passing=[g for g in GAMMA_GRID if all(points[gamma_key(g)].get(k,False)for k in static)and points[gamma_key(g)].get('U_D')is not None]
    middle=next((g for g in passing if 0.<g<1.),None);fallback=FIXED_GAPS[ordinal%6]
    if middle is None:return {'status':'PROBE_NO_MIDDLE_WINDOW','gap_m':fallback,'intention_gamma':None,'source':'CURRENT_REFERENCE_PREDICTION_ONLY','actual_labels_opened':False}
    low=points[gamma_key(middle)]['U_D'];larger=[points[gamma_key(g)]['U_D']for g in passing if g>middle]
    high=min(larger)if larger else min(.032,low+.001)
    gap=(low+high)/2 if larger else min(.032,low+.0005)
    if not(0<=low<high and 0<gap<=.032):return {'status':'PROBE_NO_MIDDLE_WINDOW','gap_m':fallback,'intention_gamma':middle,
        'U_D_middle':low,'upper_U_D':high,'source':'CURRENT_REFERENCE_PREDICTION_ONLY','actual_labels_opened':False}
    return {'status':'PROBE_MIDDLE_WINDOW','gap_m':gap,'intention_gamma':middle,'U_D_middle':low,'upper_U_D':high,
        'source':'CURRENT_REFERENCE_PREDICTION_ONLY','actual_labels_opened':False,'higher_passing_gamma': [g for g in passing if g>middle]}


def predictions(inputs,fitted,previous,ordinal):
    old={k:{'gamma':v['gamma'],'role':v['role'],'features23':None if v['features26']is None else np.asarray(v['features26'])[:23],
        'prefix':v['prefix'],'first_command_valid':v['first_command_valid']}for k,v in inputs.items()}
    queries={}
    for gap in GAPS_M:
        queries[str(gap)]={'LOCAL_GEOMETRY':decide(fitted['selected_main'],inputs,gap),
            'GLOBAL_CAL_SAME_MODEL':decide(fitted['selected_main'],inputs,gap,calibration='GLOBAL'),
            'NO_GEOMETRY':decide(fitted['nogeometry'],inputs,gap),
            'BINARY_LOCAL':decide(fitted['selected_main'],inputs,gap,allowed=(1.,0.)),
            'STEP29_FROZEN':decide29(previous,old,gap)}
    return {'queries':queries,'probe':probe(inputs,fitted['selected_main'],ordinal),'selections_frozen_before_actual':True}


def propagate(out,directory,kernel,c,actions,B,budget,result,reuse_completed=None):
    for g in(0.,1.,.75,.5,.25):
        key=gamma_key(g);a=actions[key];lab=missing('CURRENT_COMMAND_UNAVAILABLE');asset=None;event=None
        if reuse_completed and key in reuse_completed:
            prior_path=reuse_completed[key];branch=load_bank(prior_path);lab=labels(branch,c);event=events(branch,a)
            asset={'path':str(prior_path),'sha256':sha(prior_path),'row_count':len(branch['physics_trajectory'])+(branch.get('initial_fact')is not None),
                'source_id':branch['branch_id'],'size_bytes':prior_path.stat().st_size,'reused_completed_attempt01':True}
            write(directory/('G'+key+'_CONTROL_RESULTS.json'),{'controls':branch['controls'],'status':branch['status'],
                'recovered_from_saved_compact_bank':True,'new_QP_calls':0,'new_physics_steps':0})
            exhausted=False;del branch
        elif a['execution_eligible']:
            branch=sim.actual_action_branch(kernel.model,kernel.data,c,a,'ACTUAL_GAMMA',budget,kernel,ready_response=B if g==0. else None)
            asset=save_bank(directory/('G'+key+'.npz'),branch);lab=labels(branch,c);event=events(branch,a)
            write(directory/('G'+key+'_CONTROL_RESULTS.json'),{'controls':branch['controls'],'status':branch['status'],'reason':branch.get('reason')})
            exhausted=branch['status']=='FAILED_BUDGET';del branch
        else:exhausted=False
        result['labels'][key]=lab;result['actual_artifacts'][key]=asset;result['events'][key]=event
        result['controls_paths'][key]=relative(directory/('G'+key+'_CONTROL_RESULTS.json'),out)if asset else None
        write(directory/'RESULT.json',result);budget.persist(phase='ACTUAL_SAVED',context=c['context_id'],gamma=g)
        if exhausted:raise SprintLimit('partial actual saved at hard cap')


def episodes(out,kernel,manifest,budget,definition,ticks,kinds,phase):
    ordinal=0
    for eid,d,r,p,seed in definition:
        scenario=deepcopy(manifest['scenario']);scenario.update(seed=seed,initial_roll=scenario['initial_roll']+r,initial_pitch=scenario['initial_pitch']+p)
        episode_path=out/'episodes'/(eid+'.json')
        if episode_path.exists():e=read(episode_path)
        else:
            e=reference_sim.reference_episode(kernel.model,scenario,d,eid,ticks,budget);write(episode_path,e)
        found={s['source_tick']:s for s in e['snapshots']}
        for tick in ticks:
            snapshot=found.get(tick,{'snapshot_id':eid+f'_T{tick:03d}','episode_id':eid,'source_tick':tick,
                'direction':1 if d>0 else -1,'eligible':False,'eligibility_reason':'REFERENCE_INCOMPLETE'})
            for kind in kinds:
                c=source_context(snapshot,kind,manifest['mapping'],ordinal,'ID');c['backup_id']='STEP30-'+c['context_id'];ordinal+=1
                yield c


def case(out,kernel,c,budget,phase,fitted=None,previous=None,attempt=1):
    directory=out/phase/c['context_id']/f'attempt{attempt:02d}';directory.mkdir(parents=True,exist_ok=False)
    result={'context':c,'context_id':c['context_id'],'source_snapshot':c.get('snapshot_id'),'episode':c['episode_id'],
        'ordinal':c['ordinal'],'phase':phase,'labels':{},'actual_artifacts':{},'controls_paths':{},'events':{},
        'actions':{},'current_path':relative(directory/'CURRENT_INPUT.json',out),'predictions_path':None,'probe':None}
    if not c['eligible']:
        result['labels']={gamma_key(g):missing('SOURCE_INELIGIBLE')for g in GAMMA_GRID};write(directory/'RESULT.json',result);return result
    reused=None
    if attempt>1:
        old_directory=directory.parent/'attempt01';saved=read(old_directory/'CURRENT_INPUT.json')
        def restore(value):
            if isinstance(value,dict):
                if set(value)=={'nonfinite'}:return float(value['nonfinite'])
                return {k:restore(v)for k,v in value.items()}
            if isinstance(value,list):return [restore(v)for v in value]
            return value
        saved=restore(saved);C,B,actions,inputs=(saved[k]for k in('C','B','actions','inputs'))
        kernel.reset(c);reused={gamma_key(g):old_directory/('G'+gamma_key(g)+'.npz')for g in GAMMA_GRID
            if(old_directory/('G'+gamma_key(g)+'.npz')).exists()}
        write(directory/'CURRENT_INPUT.json',{**saved,'current_numeric_reused_from_attempt01':True,
            'source_sha256':sha(old_directory/'CURRENT_INPUT.json'),'new_current_QPs':0,'new_prefix_steps':0})
    else:C,B,actions,inputs=current(kernel,c,budget,out,directory)
    result['actions']={k:{name:a.get(name)for name in('gamma','kind','command_valid','available','execution_eligible','unavailable_reason','first_capacity_event')}for k,a in actions.items()}
    if fitted is not None:
        p=predictions(inputs,fitted,previous,c['ordinal']);write(directory/'PREDICTIONS_BEFORE_ACTUAL.json',p)
        result.update(predictions_path=relative(directory/'PREDICTIONS_BEFORE_ACTUAL.json',out),probe=p['probe'])
    propagate(out,directory,kernel,c,actions,B,budget,result,reused)
    return result


def query_rows(out,result):
    c=result['context'];current_data=read(out/result['current_path'])if c['eligible']else None
    allpred=read(out/result['predictions_path'])['queries']if result['predictions_path']else{}
    for gap in GAPS_M:
        feasible=[g for g in GAMMA_GRID if safe(result['labels'][gamma_key(g)],gap)]
        p=allpred.get(str(gap),{});prefixchoice='ABSTAIN'
        if current_data:
            prefixchoice=next((g for g in GAMMA_GRID if current_data['inputs'][gamma_key(g)]['first_command_valid']and
                current_data['inputs'][gamma_key(g)]['prefix'].get('original_physical_pass')and
                current_data['inputs'][gamma_key(g)]['prefix'].get('D_prefix_m',float('inf'))<=gap),'ABSTAIN')
        choices={name:d['choice']for name,d in p.items()}
        choices.update(M0=1. if result['actions'].get('1',{}).get('command_valid')else'ABSTAIN',M1=prefixchoice,ORACLE=max(feasible)if feasible else'ABSTAIN')
        for name,choice in choices.items():
            accepted=choice!='ABSTAIN';key=gamma_key(choice)if accepted else None;lab=result['labels'].get(key,{})
            good=bool(accepted and safe(lab,gap))
            append(out/'QUERY_RESULTS.jsonl',{'context_id':c['context_id'],'source_snapshot':c.get('snapshot_id'),'episode':c['episode_id'],
                'ordinal':c['ordinal'],'role':c['health_kind'].split('_')[0].lower(),'front_or_rear':'front'if c['direction']>0 else'rear',
                'health':c['faulted_health'],'gap_m':gap,'method':name,'choice':choice,'accepted':accepted,'safe_accepted':good,
                'unsafe_accepted':bool(accepted and not good),'oracle_any_gamma':bool(feasible),'oracle_binary':any(g in(0.,1.)for g in feasible),
                'middle_only_actual_safe':bool(feasible and not any(g in(0.,1.)for g in feasible)),
                'physical_error':bool(accepted and lab.get('original_failure')),
                'local_error':bool(accepted and lab.get('complete')and lab.get('D')is not None and lab['D']>gap),
                'terminal_error':bool(accepted and lab.get('complete')and not lab.get('terminal_pass')),
                'numerical_incomplete':bool(accepted and not lab.get('complete')),'D':lab.get('D'),'Y':lab.get('Y'),
                'progress20_m':lab.get('progress20_m'),'events':result['events'].get(key),'actual_feasible_gamma':feasible,
                'result_path':relative(out/'reference'/c['context_id']/'attempt01/RESULT.json',out),
                'controls_path':relative(out/'reference'/c['context_id']/'attempt01'/('G'+key+'_CONTROL_RESULTS.json'),out)if accepted else None})


def engineering(out,kernel,test,bundle,budget):
    policies=('GOVERNOR_LOCAL_FIXED','BINARY_LOCAL_FIXED','GOVERNOR_LOCAL_PROBE');registry=[]
    for entry in test:
        saved=read(out/entry['attempt_path']);c=saved['context'];ordinal=c['ordinal'];order=policies[ordinal%3:]+policies[:ordinal%3]
        for policy in order:
            gap=saved['probe']['gap_m']if policy.endswith('PROBE')and saved.get('probe')else FIXED_GAPS[ordinal%6]
            r=kernel.governor(c,bundle,gap,'BINARY_LOCAL'if policy.startswith('BINARY')else'GOVERNOR_LOCAL',budget)if c['eligible']else{
                'context_id':c['context_id'],'status':'SOURCE_INELIGIBLE','selected_command_sent':False}
            r.update(policy=policy,ordinal=ordinal,context=c,gap_m=gap,probe=saved.get('probe')if policy.endswith('PROBE')else None,
                intention_gamma=saved.get('probe',{}).get('intention_gamma')if saved.get('probe')and policy.endswith('PROBE')else None)
            path=out/'online'/c['context_id']/(policy+'.json');write(path,r)
            registry.append({'context_id':c['context_id'],'ordinal':ordinal,'role':entry['role'],'front_or_rear':entry['front_or_rear'],
                'policy':policy,'gap_m':gap,'numeric_path':relative(path,out),'status':r['status']})
            write(out/'ENGINEERING_REGISTRY.json',registry);budget.persist(phase='ONLINE',engineering_rows=len(registry));del r
        gc.collect()


def fresh(out,kernel,test,bundle,budget):
    byord={e['ordinal']:e for e in test};registry=[]
    for ordinal in FRESH_INDICES:
        e=byord[ordinal];teacher=read(out/e['attempt_path']);c=teacher['context'];gap=teacher['probe']['gap_m']if teacher.get('probe')else FIXED_GAPS[ordinal%6]
        directory=out/'fresh'/c['context_id'];path=directory/'RESULT.json'
        result={'index':ordinal,'context':c,'context_id':c['context_id'],'gap_m':gap,'probe':teacher.get('probe'),'status':'SOURCE_INELIGIBLE'}
        if c['eligible']:
            ready=kernel.governor(c,bundle,gap,'GOVERNOR_LOCAL',budget);online_path=directory/'ONLINE_NUMERIC.json';write(online_path,ready)
            result.update(online_path=relative(online_path,out),status='NO_RECOGNIZED_COMMAND_SENT')
            if ready['selected_command_sent']:
                action=ready['selected_action'];action['command_ready_ms']=ready['command_ready_ms'];g=action['gamma'];kernel.set_next_call_limit(.006)
                B=ready['B']if g==0. else None
                if B is not None:B['command_ready_ms']=B['latency_ms']=ready['command_ready_ms']
                branch=sim.actual_action_branch(kernel.model,kernel.data,c,action,'ACTUAL_GAMMA',budget,kernel,ready_response=B)
                result.update(status=branch['status'],gamma=g,labels=labels(branch,c),events=events(branch,action),
                    actual_artifact=save_bank(directory/'actual.npz',branch),
                    first_command_matches=bool(branch['controls']and np.array_equal(branch['controls'][0]['tau_sent'],action['tau_sent'])),
                    tick_latency_ms=[r['latency_ms']for r in branch['controls']],reason=branch.get('reason'))
                write(directory/'CONTROL_RESULTS.json',{'controls':branch['controls'],'status':branch['status']})
                if branch['status']=='FAILED_BUDGET':write(path,result);raise SprintLimit('fresh partial saved')
                del branch
            del ready
        write(path,result);registry.append({'context_id':c['context_id'],'ordinal':ordinal,'result_path':relative(path,out),'status':result['status']})
        write(out/'FRESH_REGISTRY.json',registry);budget.persist(phase='FRESH',fresh_rows=len(registry));gc.collect()


def run(run_id=RUN_ID,resume_dev=False):
    out=ROOT/'artifacts/step30_injured_governor_20261008'/run_id
    if(out/'RUN_STARTED.json').exists()and not resume_dev:raise FileExistsError('one unique STEP30 run')
    repair=None;recompute_context=None
    if resume_dev:
        if(out/'models/MODEL_FREEZE.json').exists()or(out/'TEST_REGISTRY.json').exists():raise ValueError('DEV-only repair cannot change frozen/newTEST work')
        prior=read(out/'RUN_FINISHED.json');started_cases=[p.parent for p in(out/'DEV').glob('*/attempt01/CURRENT_INPUT.json')]
        if len(started_cases)!=1:raise ValueError('repair scoped to exactly the one interrupted DEV context')
        recompute_context=started_cases[0].parent.name;repair=out/'dev_repair_01';repair.mkdir(exist_ok=False)
        for name in('RUN_STARTED.json','RUN_FINISHED.json','INTERRUPTION.json','MANIFEST.json','STEP30_PROGRESS.json'):
            if(out/name).exists():shutil.copyfile(out/name,repair/('before_'+name))
    out.mkdir(parents=True,exist_ok=True)
    for name in('DEV_REUSED','DEV','reference','online','fresh','episodes','models','figures'): (out/name).mkdir(exist_ok=True)
    write((repair or out)/'RUN_STARTED.json',{'run_id':run_id,'pid':os.getpid(),'start_utc':datetime.now(timezone.utc).isoformat(),'DEV_repair':resume_dev})
    budget=SprintBudget.resume(out)if resume_dev else SprintBudget(out);budget.start();status='COMPLETED'
    if resume_dev:
        budget.event('DEV_ENGINEERING_REPAIR',context_id=recompute_context,attempt01_preserved=True,budget_reset=False,
            already_completed_branches_recomputed=False,DEV_context_recomputations=budget.dev_recomputations)
    try:
        model=frozen.load_model();source=read(SOURCE29/'MANIFEST.json');limits=extract_healthy_torque_limits(model)
        mapping=[dict(e,healthy_limit_nm=float(limits[e['actuator_index']]))for e in extract_actuator_audit(model)]
        manifest={'run_id':run_id,'source_commit':PARENT,'scenario':source['scenario'],'frozen_physical':source['frozen_physical'],
            'mapping':mapping,'DEV_episodes':DEV_EPISODES,'TEST_episodes':TEST_EPISODES,'DEV_ticks':DEV_TICKS,'TEST_ticks':TEST_TICKS,
            'gamma_grid':GAMMA_GRID,'gaps_m':GAPS_M,'DEV_planned':24,'TEST_planned':48,'engineering_planned':144,'fresh_indices':FRESH_INDICES,
            'max_QP':24000,'max_steps':240000,'max_wall_s':7200,'max_model_configurations':2,'protocol_sha256':sha(PROTOCOL),
            'post_new_TEST_tuning':False,'date':'2026-10-08','timezone':'Asia/Seoul','geometry':GeometryMapping(mapping,limits).specification}
        files=[*ROOT.glob('cavr_wbc/control/step30*.py'),*ROOT.glob('cavr_wbc/experiments/step30*.py'),*ROOT.glob('native_backend/step30*'),*ROOT.glob('tools/step30*'),*ROOT.glob('tests/test_step30*.py')]
        manifest['source_sha256']={relative(p,ROOT):sha(p)for p in files};write(out/'MANIFEST.json',manifest)
        (out/'PROTOCOL_SOURCE.md').write_text(PROTOCOL.read_text(encoding='utf-8'),encoding='utf-8')
        (out/'CONVEX_COMMAND_PROPERTY.md').write_text(convex_command_property()+'\n',encoding='utf-8')
        dll=out/'native/step30_prefix.dll';manifest['native_dll_sha256']=sha(dll);write(out/'MANIFEST.json',manifest)
        home=home_context(model,manifest['scenario']);home.update(context_id='STEP30_HOME',backup_id='STEP30-HOME')
        t=perf_counter();ref=Kernel(model,'REFERENCE',str(dll),budget);bounded=Kernel(model,'BOUNDED',str(dll),budget)
        write(out/'STARTUP.json',{'reference':ref.startup(home,budget),'bounded':bounded.startup(home,budget),'total_ms':(perf_counter()-t)*1000})
        records,devindex=devdata.old_DEV(out,mapping);budget.persist(phase='REUSED_DEV',records=len(records))
        for c in episodes(out,ref,manifest,budget,DEV_EPISODES,DEV_TICKS,('THIGH_15','CALF_15'),'DEV'):
            attempt=2 if c['context_id']==recompute_context else 1
            result=case(out,ref,c,budget,'DEV',attempt=attempt);directory=out/'DEV'/c['context_id']/f'attempt{attempt:02d}'
            cur=read(directory/'CURRENT_INPUT.json')if c['eligible']else None
            for g in GAMMA_GRID:
                key=gamma_key(g);inp=cur['inputs'][key]if cur else{};action=cur['actions'][key]if cur else{}
                record=devdata.record('NEWDEV:'+c['context_id']+':G'+key,c,g,None if inp.get('features26')is None else inp['features26'][:23],
                    inp.get('prefix'),action,result['labels'][key],directory/'CURRENT_INPUT.json',(result['actual_artifacts'].get(key)or{}).get('path'))
                path=directory/('G'+key+'_MODEL_RECORD.json');write(path,record);records.append(record)
                devindex.append({'id':record['id'],'role':record['role'],'gamma':g,'episode':record['episode'],'source_snapshot':record['source_snapshot'],
                    'split':record['split'],'record_path':relative(path,out),'complete':record['labels']['complete'],'status':'NEW_DEV'})
            write(out/'DEV_SPLIT_REGISTRY.json',devindex);budget.persist(phase='NEW_DEV',contexts=c['ordinal']+1)
            print(json.dumps({'phase':'DEV','contexts':c['ordinal']+1,'budget':budget.snapshot()}),flush=True);gc.collect()
        fitted=fit_fixed(records,out/'models');budget.fit_count=fitted['actual_multioutput_estimator_fit_calls'];del records
        budget.event('MODELS_FROZEN',model_freeze_sha256=sha(out/'models/MODEL_FREEZE.json'),fit_calls=budget.fit_count);budget.persist(phase='MODELS_FROZEN')
        previous=load29(SOURCE29/'models');budget.event('NEW_TEST_OPEN',model_freeze_sha256=sha(out/'models/MODEL_FREEZE.json'))
        test=[]
        for c in episodes(out,ref,manifest,budget,TEST_EPISODES,TEST_TICKS,('HEALTHY','THIGH_15','CALF_15'),'reference'):
            result=case(out,ref,c,budget,'reference',fitted,previous);path=out/'reference'/c['context_id']/'attempt01/RESULT.json';query_rows(out,result)
            test.append(index_entry(c,path,out,'COMPLETE_PROCESSING'));write(out/'TEST_REGISTRY.json',test)
            budget.persist(phase='TEST',contexts=len(test));print(json.dumps({'phase':'TEST','contexts':len(test),'budget':budget.snapshot()}),flush=True);gc.collect()
        engineering(out,bounded,test,fitted['selected_main'],budget);fresh(out,bounded,test,fitted['selected_main'],budget)
    except SprintLimit as exc:
        status='INCOMPLETE_BUDGET';write(out/'INTERRUPTION.json',{'type':'BUDGET','error':str(exc),'budget':budget.snapshot()})
    except BaseException as exc:
        status='STOPPED_IMPLEMENTATION_OR_RESOURCE';write(out/'INTERRUPTION.json',{'type':type(exc).__name__,'error':str(exc),'traceback':traceback.format_exc(),'budget':budget.snapshot()});raise
    finally:
        budget.event('NUMERICAL_FINISHED',status=status,**budget.snapshot());budget.close()
        write(out/'RUN_FINISHED.json',{'run_id':run_id,'status':status,'budget':budget.snapshot(),'finish_utc':datetime.now(timezone.utc).isoformat()})
        if repair:write(repair/'RUN_FINISHED.json',read(out/'RUN_FINISHED.json'))
        print(json.dumps({'status':status,'budget':budget.snapshot()}),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('run_id',nargs='?',default=RUN_ID);p.add_argument('--resume-dev',action='store_true');args=p.parse_args();run(args.run_id,args.resume_dev)
