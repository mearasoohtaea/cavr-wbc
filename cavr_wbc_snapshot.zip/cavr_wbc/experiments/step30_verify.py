"""One STEP30 current-file/identity closure without physical or solver replay."""
import argparse
from collections import Counter
import json
from pathlib import Path
import numpy as np
from cavr_wbc.experiments.step30_io import ROOT,read,write,sha


def verify(out):
    out=Path(out)
    if(out/'FINAL_FILE_VERIFICATION.json').exists():raise FileExistsError('one final current closure only')
    failures=[];checks={};counts=Counter()
    def check(name,condition,details=None):
        checks[name]={'pass':bool(condition),'details':details}
        if not condition:failures.append(name)
    m=read(out/'MANIFEST.json');finished=read(out/'RUN_FINISHED.json');b=finished['budget']
    presentation_files=('cavr_wbc/experiments/step30_figures.py',)
    check('frozen_runtime_source_unchanged',all(sha(ROOT/p)==h for p,h in m['source_sha256'].items()if p not in presentation_files))
    checks['post_numerical_visual_QA_changes']={'pass':True,'details':{p:{'run_start_sha256':m['source_sha256'].get(p),
        'delivery_sha256':sha(ROOT/p),'scope':'marker/color redundancy only; no numerical input or result change'}for p in presentation_files}}
    check('fixed_caps',b['total_QP_calls']<=24000 and b['total_physics_steps']<=240000 and b['numerical_elapsed_s']<=7200.)
    check('no_hidden_work',b['unknown_native_returns']==0 and b['uncompleted_native_step_reservations']==0)
    ledger=[json.loads(line)for line in(out/'STEP30_LEDGER.jsonl').read_text(encoding='utf-8').splitlines()]
    starts=[r for r in ledger if r['event']=='QP_START'];returns=[r for r in ledger if r['event']=='QP_RETURN']
    check('contiguous_QP_starts',[r['global_qp_index']for r in starts]==list(range(1,b['total_QP_calls']+1)))
    check('all_QP_returns',[r['global_qp_index']for r in returns]==[r['global_qp_index']for r in starts])
    check('real_solver_calls',all(r['real_optimizer_called']is True for r in returns))
    check('dynamic_online_solver_limit',all(.001<=r['osqp_time_limit_s']<=.006 for r in returns if r.get('kernel_variant')=='K_BUDGETED'))
    ns=[r for r in ledger if r['event']=='PREFIX_NATIVE_START'];nr=[r for r in ledger if r['event']=='PREFIX_NATIVE_RETURN']
    check('native_reservations_return',[r['reservation_id']for r in ns]==[r['reservation_id']for r in nr])
    check('prefix_ledger_steps',sum(r['actual_steps']for r in nr)==b['physics_by_kind'].get('PREFIX_PREDICTION',0))
    check('native_DLL_hash',sha(out/'native/step30_prefix.dll')==m['native_dll_sha256'])
    model=read(out/'models/MODEL_FREEZE.json')
    check('exactly_two_models_fits',model['actual_multioutput_estimator_fit_calls']==b['multioutput_estimator_fits']==2)
    check('no_TEST_fit_or_selection',model['split_summary']['new_TEST_consumed']is False and model['new_TEST_model_selection']is False)
    for config,asset in model['assets'].items():check('model_asset_'+config,sha(asset['npz'])==asset['npz_sha256']and sha(asset['json'])==asset['json_sha256'])
    main_asset=model['assets']['GEOMETRY_FULL_26'];main_metadata=read(main_asset['json'])
    local_identity={}
    with np.load(main_asset['npz'],allow_pickle=False)as arrays:
        for group_id,metadata in main_metadata['groups'].items():
            prefix=metadata['array_prefix'];local_identity[group_id]=(arrays[prefix+'cal_snapshot_index'].copy(),arrays[prefix+'cal_episode_index'].copy())
    splits={};split_valid=True
    for r in model['split_registry']:
        for identity in(r['episode'],r['source_snapshot']):
            if identity in splits and splits[identity]!=r['split']:split_valid=False
            splits[identity]=r['split']
    check('whole_source_episode_splits',split_valid)
    test=read(out/'TEST_REGISTRY.json');eng=read(out/'ENGINEERING_REGISTRY.json');fresh=read(out/'FRESH_REGISTRY.json')
    expected=[eid+f'_T{tick:03d}_'+kind for eid,*_ in m['TEST_episodes']for tick in m['TEST_ticks']for kind in('HEALTHY','THIGH_15','CALF_15')]
    check('48_exact_TEST_order',[e['context_id']for e in test]==expected)
    check('144_engineering_rows',len(eng)==144 and len({(r['context_id'],r['policy'])for r in eng})==144)
    check('12_exact_fresh',[e['ordinal']for e in fresh]==m['fresh_indices'])
    for reg in(test,eng,fresh):check('index_only_'+str(len(reg)),all(not any(k in e for k in('raw','numeric','context','predictions','labels','actions'))for e in reg))
    # NPZ/header counts include every old failed attempt in this STEP30 output,
    # but reused path references are counted once. No source-stage bank replay.
    for p in out.rglob('*.npz'):
        if p.parent.name=='models':continue
        with np.load(p,allow_pickle=False)as archive:
            document=json.loads(archive['metadata_json_utf8'].tobytes().decode('utf-8'));h=document['header']
            counts['new_bank_steps']+=h['counts']['physical_steps'];counts['new_banks']+=1
            if h['status']=='COMPLETE':
                counts['complete_banks']+=1
                if document['row_count']!=501 or len(h['controls'])!=50:failures.append('501_grid:'+str(p))
    counts['reference_steps']=sum(read(p)['counts']['physical_steps']for p in(out/'episodes').glob('*.json'))
    check('all_integrations_reconcile',counts['new_bank_steps']+counts['reference_steps']+sum(r['actual_steps']for r in nr)==b['total_physics_steps'])
    for current in list((out/'DEV').glob('*/attempt*/CURRENT_INPUT.json'))+list((out/'reference').glob('*/attempt*/CURRENT_INPUT.json')):
        data=read(current)
        for gamma,comparison in data.get('prefix_equivalence',{}).items():
            counts['single_batch_equivalence_records']+=1
            if comparison['single_batch_exact_numeric']is not True:failures.append('batch_single_equivalence:'+str(current)+':'+gamma)
    for e in test:
        result=read(out/e['attempt_path'])
        if result['context']['eligible']:
            prediction=read(out/result['predictions_path'])
            if not prediction['selections_frozen_before_actual']or prediction['probe']['actual_labels_opened']:failures.append('future_probe_label_leak:'+e['context_id'])
        for gamma,asset in result['actual_artifacts'].items():
            if asset and sha(asset['path'])!=asset['sha256']:failures.append('actual_archive_hash:'+e['context_id']+':'+gamma)
    online_paths=[out/r['numeric_path']for r in eng]
    for e in fresh:
        result=read(out/e['result_path'])
        if result.get('online_path'):online_paths.append(out/result['online_path'])
        if result.get('actual_artifact'):
            if sha(result['actual_artifact']['path'])!=result['actual_artifact']['sha256']:failures.append('fresh_archive_hash:'+e['context_id'])
            if not result['first_command_matches']:failures.append('fresh_first_command:'+e['context_id'])
    for p in online_paths:
        r=read(p)
        if r.get('selected_command_sent')and(r['command_ready_ms']>20. or r['status']!='RECOGNIZED_SENT'):failures.append('late_sent:'+str(p))
        for key,entry in r.get('actions',{}).items():
            a=entry.get('action');pref=entry.get('prefix');d=(entry.get('decision')or{}).get('numeric')
            if not a or not a.get('command_valid'):continue
            raw=np.asarray(a['tau_raw']);sent=np.asarray(a['tau_sent']);cap=np.asarray(a['capacity_interface']['effective_capacity_nm'])
            if not np.array_equal(sent,np.clip(raw,-cap,cap)):failures.append('send_capacity:'+str(p)+':'+key)
            if 0.<a['gamma']<1.:
                counts['online_middle_numeric']+=1
                z=a['gamma']*np.asarray(a['source_primal_variables']['C'])+(1-a['gamma'])*np.asarray(a['source_primal_variables']['B'])
                if not np.array_equal(z,a['z_raw'])or a['solver_status_val']is not None or not a['sent_hard_check']['pass']:failures.append('middle_primal_proof:'+str(p)+':'+key)
            if pref and pref.get('complete'):
                counts['online_complete_prefixes']+=1
                if np.asarray(pref['numeric']['qpos']).shape!=(11,19)or not np.array_equal(pref['numeric']['tau_sent'],sent):failures.append('prefix_numeric_identity:'+str(p)+':'+key)
            if d and d.get('calibration_gate'):
                indices=np.asarray(d['local_cal_indices']);counts['online_local_indices']+=1
                group_id=format(float(key),'g')+':'+entry['role']
                snapshots,episodes=local_identity[group_id]
                if indices.shape!=(4,)or np.any(indices<0)or np.any(indices>=len(snapshots)):
                    failures.append('local_CAL_indices:'+str(p)+':'+key)
                elif len(set(snapshots[indices]))!=4 or len(set(episodes[indices]))<2:
                    failures.append('local_CAL_distinct_identity:'+str(p)+':'+key)
    file_index=[{'path':str(p.relative_to(out)).replace('\\','/'),'bytes':p.stat().st_size,'sha256':sha(p)}for p in out.rglob('*')if p.is_file()]
    result={'status':'PASS'if not failures else'FAIL','failure_names':failures,'checks':checks,'counts':dict(counts),
        'files':file_index,'file_count':len(file_index),'optimizer_or_physics_replay':False,'scope':'one final current STEP30 identity/file closure'}
    write(out/'FINAL_FILE_VERIFICATION.json',result);print(json.dumps({'status':result['status'],'failures':failures,'counts':dict(counts),'files':len(file_index)}));return result


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('out');verify(p.parse_args().out)
