"""Single STEP31 immutable90-minute/10000QP/120000step numerical ledger."""
from collections import Counter
from datetime import datetime,timezone
import json
import os
from pathlib import Path
from time import perf_counter
from cavr_wbc.experiments.step30_budget import SprintBudget as PreviousBudget,SprintLimit
from cavr_wbc.experiments.step31_io import write


class SprintBudget(PreviousBudget):
    def __init__(self,out):
        self.out=Path(out);self.path=self.out/'STEP31_LEDGER.jsonl';self.stream=self.path.open('x',encoding='utf-8',newline='\n')
        self.buffer=[];self.qp_calls=self.returned=self.physics_steps=self.reserved=0;self.started=self.start_utc=None
        self.qp_kinds=Counter();self.step_kinds=Counter();self.fit_count=0;self.dev_recomputations=0
        self.reservation_id=0;self.tokens={};self.persisted_qp_calls=self.persisted_returns=0
    def start(self):
        if self.started is None:
            self.started=perf_counter();self.start_utc=datetime.now(timezone.utc).isoformat()
            self.event('NUMERICAL_STARTED',hard_wall_s=5400,QP_limit=10000,step_limit=120000,model_fit_limit=0)
    def check(self):
        if self.started is not None and perf_counter()-self.started>=5400:raise SprintLimit('90-minute numerical hard cap')
        if self.qp_calls>=10000:raise SprintLimit('10000 real QP hard cap')
        if self.physics_steps+self.reserved>=120000:raise SprintLimit('120000 integration hard cap including reservations')
    def reserve_steps(self,kind,owner,n):
        self.start();self.check()
        if int(n)!=n or n<0 or self.physics_steps+self.reserved+n>120000:raise SprintLimit('native prefix reservation exceeds hard cap')
        self.reservation_id+=1;token=self.reservation_id;self.tokens[token]=(kind,owner,int(n));self.reserved+=int(n)
        self.event('PREFIX_NATIVE_START',reservation_id=token,kind=kind,owner=owner,reserved_steps=int(n));return token
    def persist(self,**extra):
        for row in self.buffer:self.stream.write(json.dumps(row,sort_keys=True,allow_nan=False)+'\n')
        self.stream.flush();os.fsync(self.stream.fileno());self.buffer.clear()
        self.persisted_qp_calls=self.qp_calls;self.persisted_returns=self.returned
        write(self.out/'STEP31_PROGRESS.json',{**self.snapshot(),**extra})
