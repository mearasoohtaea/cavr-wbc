"""Two saved-only STEP31 figures with full-input and full-trigger evidence.

Preview and grayscale review precede vector export. Plotting reads one actual
NPZ at a time and never fits, solves, integrates, or opens a five-action bank.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

from cavr_wbc.experiments.step31_report import BRANCHES, csv_write, finite, read, resolve, write
from cavr_wbc.experiments.step26_features_storage import load_bank

SCRIPTS = Path("C:/Users/ZhuanZ（无密码）/.codex/skills/scipilot-figure/scripts")
sys.path.insert(0, str(SCRIPTS))
from setup_style import setup_style
from profile_data import profile_data, render_report
from visual_qa import audit_layout, render_preview
from export_figure import export_figure
from layout_tools import finalize_figure, add_panel_labels

COLORS = {"IMMEDIATE": "#0072B2", "DELAY20": "#E69F00", "COUNTERFACTUAL_C": "#CC79A7", "COUNTERFACTUAL_B": "#000000"}
MARKERS = {"IMMEDIATE": "o", "DELAY20": "s", "COUNTERFACTUAL_C": "^", "COUNTERFACTUAL_B": "v"}
SHORT = {"IMMEDIATE": "Immediate", "DELAY20": "Delay 20 ms", "COUNTERFACTUAL_C": "CF C", "COUNTERFACTUAL_B": "CF B"}


def data(out):
    out = Path(out); directory = out / "figures"; directory.mkdir(exist_ok=True)
    queue = read(out / "QUEUE_RESULTS.json", []); branches = read(out / "BRANCH_RESULTS.json", [])
    ticks = []
    for branch in branches:
        for slot, value in enumerate(branch["tick_latency_ms"]):
            ticks.append({"context_id": branch["context_id"], "ordinal": branch["ordinal"], "role": branch["role"],
                          "episode": branch["episode"], "branch": branch["branch"], "slot": slot,
                          "control_time_from_sample_s": slot * .02, "command_ready_ms": value,
                          "branch_execution_confirmed": branch["execution_confirmed"], "branch_status": branch["status"]})
    csv_write(directory / "QUEUE_FIGURE_DATA.csv", queue)
    csv_write(directory / "BRANCH_FIGURE_DATA.csv", [{key: row.get(key) for key in
        ("context_id", "ordinal", "role", "episode", "front_or_rear", "branch", "status", "executed", "complete_501",
         "actual_safe_at_frozen_gap", "full_50_ticks_20ms", "execution_confirmed", "progress20_m", "D_m", "gap_m", "gamma", "capacity_event")} for row in branches])
    csv_write(directory / "ALL_TICK_FIGURE_DATA.csv", ticks)
    for name, groups, nonempty in (("QUEUE_FIGURE_DATA", ["role"], queue),
                                   ("BRANCH_FIGURE_DATA", ["branch", "role"], branches),
                                   ("ALL_TICK_FIGURE_DATA", ["branch"], ticks)):
        if nonempty:
            result = profile_data(str(directory / (name + ".csv")), group_cols=groups)
            (directory / (name + "_PROFILE.md")).write_text(render_report(result), encoding="utf-8", newline="\n")
    write(directory / "FIGURE_SELECTION.json", {
        "target": "IEEE T-RO, double-column 7.16 inch, 8-point primary text, vector and 600 dpi PNG",
        "figure_1_question": "What happens to every one of the 44 planned inputs, and how much actual motion do the executed branches produce?",
        "figure_1_choice": "Full queue categorical status matrix and every executed branch point, no connection across case IDs",
        "figure_1_alternatives": ["All-input dot table", "Grouped trigger/completion count table"],
        "figure_2_question": "Does the same packet survive one-cycle delay, and are all actual control windows within the unchanged 20 ms deadline?",
        "figure_2_choice": "Every injured-middle IMMEDIATE/DELAY20 actual trajectory pair and all available actual tick latencies, including failures",
        "figure_2_alternatives": ["All paired endpoints", "Per-context trajectory small multiples"],
        "planned_denominator": 44, "conditional_trigger_denominator_replaces_plan": False,
        "all_immediate_delay_pairs_not_positive_selection": True, "no_new_five_gamma_bank": True,
        "error_bars_or_significance": "NONE; fixed opportunity-triggered deployment queue, not independent randomized repeats"})
    return queue, branches, ticks


def _style():
    setup_style(journal="ieee", lang="en", use_sciplots=False)
    plt.rcParams.update({"font.size": 8, "axes.labelsize": 8, "axes.titlesize": 8, "xtick.labelsize": 8,
        "ytick.labelsize": 8, "legend.fontsize": 8, "pdf.fonttype": 42, "ps.fonttype": 42,
        "axes.spines.top": False, "axes.spines.right": False, "axes.unicode_minus": False,
        "figure.constrained_layout.use": True})


def _category(branch):
    if not branch["expected_by_trigger"]:
        return "No trigger"
    if not branch["executed"]:
        return "Triggered, not run"
    if branch["execution_confirmed"]:
        return "Confirmed"
    if branch["late_ticks"] or branch["nonfinite_ticks"]:
        return "Tick deadline / non-finite"
    if branch["complete_501"]:
        return "Complete, failed predicate"
    return "Numerically incomplete"


def _queue_figure(queue, branches):
    fig, axes = plt.subplots(1, 2, figsize=(7.16, 4.9), layout="constrained", gridspec_kw={"width_ratios": [1.1, 1.]})
    categories = {
        "No trigger": ("#B0B0B0", "."), "Triggered, not run": ("#000000", "+"),
        "Confirmed": ("#0072B2", "o"), "Tick deadline / non-finite": ("#000000", "s"),
        "Complete, failed predicate": ("#D55E00", "x"), "Numerically incomplete": ("#E69F00", "^")}
    ax = axes[0]
    for row in queue:
        category = "Confirmed" if row["timely_recognized_sent"] else "No trigger"
        if row["late_sent"] or row["raw_valid_but_late"]:
            category = "Tick deadline / non-finite"
        color, marker = categories[category]
        ax.scatter([0], [row["ordinal"]], color=color, marker=marker, s=20, linewidths=.7)
    for row in branches:
        color, marker = categories[_category(row)]
        ax.scatter([1 + BRANCHES.index(row["branch"])], [row["ordinal"]], color=color, marker=marker, s=20, linewidths=.7)
    ax.set_xlim(-.6, 4.6); ax.set_ylim(-1, 44)
    ax.set_xticks(range(5), ["Sent", "Immediate", "CF C", "CF B", "Delay"])
    ax.tick_params(axis="x", rotation=35)
    ax.set_yticks([5., 16., 27., 38.], ["P065", "N065", "P067", "N067"])
    ax.set_ylabel("Episode (11 planned inputs each)")
    ax.set_title("All 44 planned inputs and trigger outcomes", pad=12)
    for y in (10.5, 21.5, 32.5):
        ax.axhline(y, color="gray", lw=.5, ls=":")
    ax.legend(handles=[Line2D([], [], color=color, marker=marker, linestyle="none", label=name) for name, (color, marker) in categories.items()],
              loc="upper left", bbox_to_anchor=(-.03, -.21), frameon=False, fontsize=7)
    ax = axes[1]
    for name in BRANCHES:
        for confirmed in (False, True):
            selected = [row for row in branches if row["branch"] == name and row["executed"]
                        and finite(row["progress20_m"]) and row["execution_confirmed"] == confirmed]
            if selected:
                offset = (BRANCHES.index(name) - 1.5) * .12
                ax.scatter([row["ordinal"] + offset for row in selected], [1000. * row["progress20_m"] for row in selected],
                           edgecolors=COLORS[name], facecolors=COLORS[name] if confirmed else "none", marker=MARKERS[name],
                           s=21, linewidths=.6)
    ax.axhline(0., color="gray", lw=.6, ls=":")
    ax.set_xlim(-1, 44); ax.set_xlabel("Fixed input ordinal (not time)")
    ax.set_ylabel("Actual sample-to-20 ms progress (mm)")
    ax.set_title("All available complete-branch progress", pad=12)
    ax.margins(y=.12)
    handles = [Line2D([], [], color=COLORS[name], marker=MARKERS[name], linestyle="none", label=SHORT[name]) for name in BRANCHES]
    handles.append(Line2D([], [], color="black", marker="o", markerfacecolor="none", linestyle="none", label="Hollow = not execution-confirmed"))
    ax.legend(handles=handles, loc="upper left", bbox_to_anchor=(-.03, -.21), frameon=False, fontsize=7)
    missing_progress = sum(row["executed"] and not finite(row["progress20_m"]) for row in branches)
    if missing_progress:
        ax.text(.03, .98, f"Missing complete progress labels: {missing_progress}", transform=ax.transAxes, ha="left", va="top", fontsize=7)
    return fig


def _trajectory_figure(out, branches, ticks):
    fig, axes = plt.subplots(1, 2, figsize=(7.16, 3.8), layout="constrained")
    trace_index = []; ax = axes[0]
    for row in branches:
        if row["branch"] not in ("IMMEDIATE", "DELAY20") or not row["injured_middle_event"] or not row["executed"]:
            continue
        artifact = row.get("artifact") or {}
        if not artifact.get("path") or not resolve(out, artifact["path"]).exists():
            trace_index.append({"context_id": row["context_id"], "branch": row["branch"], "status": "MISSING_SAVED_ARTIFACT", "artifact_path": artifact.get("path")})
            continue
        bank = load_bank(resolve(out, artifact["path"]))
        initial = bank.get("initial_fact")
        facts = ([initial] if initial is not None else []) + list(bank.get("physics_trajectory", []))
        regular = [fact for fact in facts if "qpos" in fact and "qvel" in fact and "physics_step" in fact and not fact.get("numerical_failure")]
        anchor = bank.get("fixed_anchor_q_init")
        if not regular or anchor is None or not finite(regular[0]["qvel"][0]):
            trace_index.append({"context_id": row["context_id"], "branch": row["branch"], "status": "MISSING_SAVED_INITIAL_OR_ANCHOR", "artifact_path": artifact["path"]})
            continue
        direction = 1. if regular[0]["qvel"][0] > 0. else -1.
        time = np.asarray([fact["physics_step"] * .002 for fact in regular])
        position = np.asarray([1000. * direction * (fact["qpos"][0] - anchor[0]) for fact in regular])
        name = row["branch"]; style = "-" if name == "IMMEDIATE" else "--"
        ax.plot(time, position, color=COLORS[name], ls=style, lw=.65, alpha=.7)
        if not row["execution_confirmed"]:
            ax.scatter([time[-1]], [position[-1]], color="black", marker="x", s=15, linewidths=.6)
        trace_index.append({"context_id": row["context_id"], "ordinal": row["ordinal"], "role": row["role"], "episode": row["episode"],
            "branch": name, "status": row["status"], "execution_confirmed": row["execution_confirmed"],
            "observed_state_count": len(regular), "last_time_s": float(time[-1]), "artifact_path": str(resolve(out, artifact["path"])),
            "direction_sign_from_actual_initial_vx": direction, "anchor_x_m": anchor[0]})
    ax.axhline(0., color="gray", lw=.5, ls=":")
    ax.axvline(.02, color="gray", lw=.6, ls=":")
    ax.set_xlabel("Time from sample (s)"); ax.set_ylabel("Actual direction displacement from anchor (mm)")
    ax.set_title("Every triggered injured-middle trace pair", pad=12)
    if not trace_index:
        ax.text(.5, .5, "No injured-middle trajectory trigger", transform=ax.transAxes, ha="center", va="center", fontsize=8)
    ax.margins(.06)
    ax.legend(handles=[Line2D([], [], color=COLORS["IMMEDIATE"], ls="-", label="Immediate"),
                       Line2D([], [], color=COLORS["DELAY20"], ls="--", label="Delay 20 ms"),
                       Line2D([], [], color="black", marker="x", linestyle="none", label="Unconfirmed branch endpoint")],
              loc="upper left", bbox_to_anchor=(-.03, -.23), frameon=False, fontsize=7)
    ax = axes[1]
    for name in BRANCHES:
        selected = [row for row in ticks if row["branch"] == name and finite(row["command_ready_ms"])]
        if selected:
            ax.scatter([row["control_time_from_sample_s"] for row in selected], [row["command_ready_ms"] for row in selected],
                       color=COLORS[name], marker=MARKERS[name], s=8, alpha=.45, linewidths=.25)
    ax.axhline(20., color="gray", lw=.8, ls=":")
    ax.set_ylim(bottom=0.); ax.set_xlim(-.025, 1.015)
    ax.set_xlabel("Actual control time from sample (s)"); ax.set_ylabel("Complete actual tick command-ready time (ms)")
    ax.set_title("Every available actual tick, failures retained", pad=12)
    ax.legend(handles=[Line2D([], [], color=COLORS[name], marker=MARKERS[name], linestyle="none", label=SHORT[name]) for name in BRANCHES],
              loc="upper left", bbox_to_anchor=(-.03, -.23), frameon=False, ncol=2, fontsize=7)
    missing = sum(not finite(row["command_ready_ms"]) for row in ticks)
    if missing:
        ax.text(.02, .98, f"Non-finite/missing observed tick times: {missing}", transform=ax.transAxes, ha="left", va="top", fontsize=7)
    csv_write(Path(out) / "figures/PAIRED_TRACE_INDEX.csv", trace_index)
    return fig


def _finish(fig, base, phase):
    finalize_figure(fig); add_panel_labels(fig, style="ieee")
    issues = audit_layout(fig)
    if any(severity == "FAIL" for severity, _ in issues):
        raise RuntimeError("STEP31 figure missing-glyph/layout failure")
    from PIL import Image
    if phase == "preview":
        render_preview(fig, str(base) + "_preview.png", dpi=180)
        Image.open(str(base) + "_preview.png").convert("L").save(str(base) + "_preview_grayscale.png")
    else:
        export_figure(fig, str(base), formats=["pdf", "svg", "png"], size_inches=tuple(fig.get_size_inches()), dpi=600,
                      tight=False, grayscale_preview=False)
        Image.open(str(base) + ".png").convert("L").save(str(base) + "_grayscale.png")
    return {"figure": base.name, "phase": phase, "issues": issues, "dimensions_inches": list(fig.get_size_inches()),
            "visual_review_required": True}


def buildfig(out, phase="preview"):
    if phase not in ("preview", "export"):
        raise ValueError("STEP31 figure phase must be preview or export")
    out = Path(out); queue, branches, ticks = data(out); _style()
    qa = []
    for figure, name in ((_queue_figure(queue, branches), "step31_all_trigger_execution"),
                         (_trajectory_figure(out, branches, ticks), "step31_immediate_delay_ticks")):
        qa.append(_finish(figure, out / "figures" / name, phase)); plt.close(figure)
    write(out / "figures/FIGURE_MACHINE_QA.json", qa)
    (out / "figures/FIGURE_CAPTIONS.md").write_text("\n".join([
        "# STEP31 evidence figure captions", "",
        "Figure 1. Every one of the 44 planned inputs and every associated trigger/outcome. Each episode has five snapshot ticks with two injured roles plus one healthy control at the middle tick, in manifest ordinal order. Panel (a) distinguishes timely sending, no trigger, triggered-but-not-run, execution-confirmed, complete predicate failure, numerical incomplete, and actual tick deadline/non-finite failure using both color and marker. Confirmation requires complete 501-state original physical/local/terminal safety, matching first packet and all 50 actual tick times within 20 ms. Panel (b) displays every available complete-branch sample-to-20 ms actual direction progress; hollow marks are not execution-confirmed. DELAY20's first-20 ms value is prehold motion, not the original selected packet's post-application progress. Missing complete labels are stated, not zero-imputed. Case IDs are categorical, so no lines connect them. Counterfactual endpoints share the original packet first-decision cost.", "",
        "Figure 2. All actual IMMEDIATE and DELAY20 trace pairs from every injured-middle event, including partial/numerical and complete failed branches; no selection by success or progress gain. Displacement uses the saved fixed sample anchor and actual initial velocity direction; time is the saved physics-step index multiplied by the unchanged 2 ms step. A black endpoint cross denotes an unconfirmed branch. The dotted 20 ms vertical line shows selected-packet application after the DELAY20 prehold; trajectories retain their observed length, never padded to 1 s. Panel (b) shows every finite observed actual control-window timing across IMMEDIATE, COUNTERFACTUAL_C/B and DELAY20, retains all failures and the full late tail, and marks the unchanged 20 ms deadline. Non-finite observed times are stated. Counterfactual first-slot times are shared packet cost, not independently timed baseline decisions. Paired artifacts and all tick CSVs provide trace-to-context identities.", "",
        "The planned 44-input timely-recognition denominator and opportunity-triggered rollout denominator remain distinct. This fixed deployment confirmation queue and injected first-packet delay are not independent random replicates, a population success-rate survey, completed delay compensation, continuous shielding, or hardware-real-time evidence. No mean bars, p-values or confidence intervals. Both figures follow SciPilot EDA and IEEE double-column 7.16-inch formatting, 8-point primary text, colorblind-safe and grayscale-redundant encodings, 600 dpi PNG plus PDF/SVG TrueType vectors after explicit preview review.", ""
    ]), encoding="utf-8", newline="\n")
    return qa


build = buildfig


if __name__ == "__main__":
    parser = argparse.ArgumentParser(); parser.add_argument("out"); parser.add_argument("phase", choices=("preview", "export"), nargs="?", default="preview")
    args = parser.parse_args(); buildfig(args.out, args.phase)
