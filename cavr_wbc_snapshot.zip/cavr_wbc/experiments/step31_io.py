"""Small indexes and per-packet STEP31 evidence, with explicit nonfinite data."""
from pathlib import Path
from cavr_wbc.experiments.step30_io import read,write,append,sha,encode,relative,small_prefix

ROOT=Path(__file__).resolve().parents[2]
SOURCE30=ROOT/'artifacts/step30_injured_governor_20261008/step30-injured-governor-20261008-01'
RUN_ID='step31-frozen-event-validation-20261009-01'
PARENT='dc9a2cdfc33e2abba2d581ac4cc3eed1456b5fde'
PROTOCOL=Path('E:/CAVR-WBC/experiment_handoff_20260921/NEXT_CODEX_INSTRUCTIONS_STEP31_FROZEN_GOVERNOR_EVENT_VALIDATION_20261009.md')
