"""Saved-only STEP31 full-trigger execution report; no fitting or simulation.

Identity registries are read separately from each packet and actual branch.
All planned inputs remain in the recognition denominator; conditional rollout
completion never replaces that denominator. IMMEDIATE and DELAY20 conclusions
are independent. Historical files are only read, never revised.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
import json
import math
from pathlib import Path

import numpy as np

BRANCHES = ("IMMEDIATE", "COUNTERFACTUAL_C", "COUNTERFACTUAL_B", "DELAY20")
MIDDLE = (.75, .5, .25)
PLANNED = 44


def finite(value):
    return isinstance(value, (int, float, np.integer, np.floating)) and not isinstance(value, bool) and math.isfinite(float(value))


def _restore(value):
    if isinstance(value, dict):
        if len(value) == 1:
            key = next(iter(value))
            if key in ("__step26_nonfinite_float__", "__step29_nonfinite_float__", "__step30_nonfinite_float__", "__step31_nonfinite_float__"):
                return float(value[key])
        return {key: _restore(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_restore(item) for item in value]
    return value


def _encode(value):
    if isinstance(value, np.ndarray):
        return _encode(value.tolist())
    if isinstance(value, np.generic):
        return _encode(value.item())
    if isinstance(value, float) and not math.isfinite(value):
        return {"__step31_nonfinite_float__": repr(value)}
    if isinstance(value, dict):
        return {str(key): _encode(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_encode(item) for item in value]
    return value


def read(path, default=None):
    path = Path(path)
    return _restore(json.loads(path.read_text(encoding="utf-8"))) if path.exists() else default


def write(path, document):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    pending = path.with_name(path.name + ".step31-report.pending")
    pending.write_text(json.dumps(_encode(document), ensure_ascii=False, allow_nan=False, separators=(",", ":")) + "\n", encoding="utf-8", newline="\n")
    pending.replace(path)


def resolve(out, path):
    value = Path(path)
    return value if value.is_absolute() else Path(out) / value


def entries(document):
    if document is None:
        return []
    if isinstance(document, list):
        return document
    if isinstance(document, dict) and isinstance(document.get("entries"), list):
        return document["entries"]
    raise ValueError("STEP31 registry must be a list or an entries document")


def jsonl_rows(path):
    path = Path(path)
    if path.exists():
        with path.open(encoding="utf-8") as stream:
            for line in stream:
                if line.strip():
                    yield _restore(json.loads(line))


def csv_write(path, rows):
    rows = list(rows); path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields); writer.writeheader()
        for row in rows:
            writer.writerow({key: json.dumps(_encode(value), ensure_ascii=False) if isinstance(value, (dict, list, tuple)) else value for key, value in row.items()})


def stats(values):
    values = list(values); a = np.asarray([float(value) for value in values if finite(value)])
    return {"recorded": len(values), "finite": len(a), "nonfinite_or_missing": len(values) - len(a),
            **{name: float(np.percentile(a, percentile)) if len(a) else None for name, percentile in (("p50", 50), ("p95", 95), ("p99", 99))},
            "min": float(a.min()) if len(a) else None, "max": float(a.max()) if len(a) else None}


def safe(label, gap):
    return bool(label.get("complete") and label.get("original_physical_safe") and label.get("terminal_pass")
                and label.get("command_valid_all") and finite(label.get("D")) and finite(gap) and 0. <= label["D"] <= gap)


def capacity_event(events):
    events = events or {}
    return bool(events.get("first_capacity_event") or events.get("first_active_indices")
                or any(int(value) > 0 for value in events.get("capacity99_count_by_channel", [])))


def branch_facts(record, gap):
    record = record or {}; label = record.get("label") or {}; ticks = record.get("tick_latency_ms") or []
    status = record.get("status", "NOT_RUN")
    executed = bool(record.get("artifact") or ticks or label)
    complete = bool(label.get("complete"))
    tick_pass = bool(complete and len(ticks) == 50 and all(finite(value) and value <= 20. for value in ticks)
                     and record.get("all_tick_deadline_pass") is True)
    first_match = record.get("first_command_matches")
    return {"status": status, "executed": executed, "complete_501": complete,
        "actual_safe_at_frozen_gap": safe(label, gap), "full_50_ticks_20ms": tick_pass,
        "first_command_matches": first_match, "execution_confirmed": bool(safe(label, gap) and tick_pass and first_match is True),
        "physical_failure": bool(label.get("original_failure") or label.get("observed_original_physical_failure") or (complete and not label.get("original_physical_safe"))),
        "local_failure": bool(complete and finite(label.get("D")) and finite(gap) and label["D"] > gap),
        "terminal_failure": bool(complete and not label.get("terminal_pass")),
        "command_failure": bool(complete and not label.get("command_valid_all")),
        "numerical_incomplete": bool(executed and not complete),
        "late_ticks": sum(finite(value) and value > 20. for value in ticks),
        "nonfinite_ticks": sum(not finite(value) for value in ticks),
        "first_packet_mismatch": first_match is False,
        "capacity_event": capacity_event(record.get("events")), "D_m": label.get("D"), "Y": label.get("Y"),
        "progress20_m": label.get("progress20_m"), "tick_latency_ms": ticks,
        "events": record.get("events"), "artifact": record.get("artifact"), "controls_path": record.get("controls_path"),
        "original_witness_time_s": record.get("original_witness_time_s"),
        "selected_application_time_s": record.get("selected_application_time_s"), "horizon_s": record.get("horizon_s"),
        "previous_command_matches": record.get("previous_command_matches"),
        "first_previous_command_identity": record.get("first_previous_command_identity"), "counts": record.get("counts")}


def iter_cases(out):
    out = Path(out)
    for entry in entries(read(out / "QUEUE_REGISTRY.json", [])):
        result = read(resolve(out, entry["result_path"]), {}) if entry.get("result_path") else {}
        ctx = result.get("context") or {}
        online = read(resolve(out, result["online_path"]), {}) if result.get("online_path") else {}
        gamma = online.get("selected_gamma")
        gap = ctx.get("gap_m", online.get("gap_m"))
        role = ctx.get("role", entry.get("role", "UNKNOWN"))
        sent = bool(result.get("selected_sent") and online.get("selected_command_sent"))
        ready = online.get("command_ready_ms")
        timely = bool(sent and finite(ready) and ready <= 20.)
        injured = role in ("thigh", "calf")
        metadata = {"context_id": entry["context_id"], "ordinal": entry["ordinal"], "role": role,
            "episode": ctx.get("episode", entry.get("episode")),
            "source_snapshot": ctx.get("source_snapshot", entry.get("snapshot_id")),
            "front_or_rear": ctx.get("front_or_rear", entry.get("front_or_rear", "UNKNOWN")),
            "eligible": bool(ctx.get("eligible", entry.get("eligible", False))), "injured": injured,
            "gap_m": gap, "gamma": gamma, "selected_sent": sent, "timely_recognized_sent": timely,
            "injured_middle_event": bool(timely and injured and gamma in MIDDLE),
            "command_ready_ms": ready, "status": result.get("status", entry.get("status", "NOT_RUN")),
            "online_status": online.get("status", "NOT_RUN"), "result_path": str(resolve(out, entry["result_path"])) if entry.get("result_path") else None,
            "online_path": str(resolve(out, result["online_path"])) if result.get("online_path") else None,
            "proposal_path": str(resolve(out, result["proposal_path"])) if result.get("proposal_path") else None,
            "B_not_requested": online.get("B", {}).get("status") == "NOT_REQUESTED",
            "raw_valid_but_late": bool(online.get("raw_valid_but_late")),
            "cutoff_action_count": sum(action.get("evaluation_status") == "NOT_EVALUATED_BUDGET" for action in online.get("actions", {}).values()),
            "late_sent": bool(sent and (not finite(ready) or ready > 20.)),
            "packet_sent_metadata_disagreement": bool(result.get("selected_sent")) != bool(online.get("selected_command_sent")),
            "runtime_setup_events": sum(endpoint.get("runtime_setup_events", 0) for endpoint in (online.get("C", {}), online.get("B", {})))}
        yield metadata, result, online


def summarize_queue(rows, planned):
    triggered = sum(row["timely_recognized_sent"] for row in rows)
    return {"planned": planned, "recorded": len(rows), "missing_planned": max(0, planned - len(rows)),
            "eligible": sum(row["eligible"] for row in rows), "timely_recognized_sent": triggered,
            "timely_recognition_rate_planned": triggered / planned if planned else None,
            "injured_middle_events": sum(row["injured_middle_event"] for row in rows),
            "IMMEDIATE_executed": sum(row.get("IMMEDIATE_executed", False) for row in rows),
            "IMMEDIATE_confirmed": sum(row.get("IMMEDIATE_execution_confirmed", False) for row in rows),
            "conditional_IMMEDIATE_confirmation_rate": sum(row.get("IMMEDIATE_execution_confirmed", False) for row in rows) / triggered if triggered else None,
            "raw_valid_but_late": sum(row["raw_valid_but_late"] for row in rows), "late_sent": sum(row["late_sent"] for row in rows),
            "cutoff_action_count": sum(row["cutoff_action_count"] for row in rows), "B_not_requested": sum(row["B_not_requested"] for row in rows),
            "runtime_setup_events": sum(row["runtime_setup_events"] for row in rows),
            "online_ready_ms": stats(row["command_ready_ms"] for row in rows),
            "statuses": dict(Counter(row["status"] for row in rows)), "online_statuses": dict(Counter(row["online_status"] for row in rows)),
            "packet_sent_metadata_disagreement": sum(row["packet_sent_metadata_disagreement"] for row in rows)}


def summarize_branches(rows, expected):
    executed = sum(row["executed"] for row in rows)
    return {"expected_by_trigger": expected, "recorded": len(rows), "executed": executed,
            "NOT_RUN": sum(not row["executed"] for row in rows),
            "complete_501": sum(row["complete_501"] for row in rows),
            "actual_safe_at_frozen_gap": sum(row["actual_safe_at_frozen_gap"] for row in rows),
            "full_50_ticks_20ms": sum(row["full_50_ticks_20ms"] for row in rows),
            "execution_confirmed": sum(row["execution_confirmed"] for row in rows),
            "confirmation_rate_expected_trigger": sum(row["execution_confirmed"] for row in rows) / expected if expected else None,
            **{name: sum(row[name] for row in rows) for name in ("physical_failure", "local_failure", "terminal_failure", "command_failure", "numerical_incomplete", "late_ticks", "nonfinite_ticks", "first_packet_mismatch", "capacity_event")},
            "all_tick_ms": stats(value for row in rows for value in row["tick_latency_ms"]),
            "statuses": dict(Counter(row["status"] for row in rows))}


def criterion(rows):
    successful = [row for row in rows if row["injured_middle_event"] and row["execution_confirmed"]]
    contexts = sorted({row["context_id"] for row in successful})
    episodes = sorted({row["episode"] for row in successful if row["episode"] is not None})
    event_contexts = sorted({row["context_id"] for row in successful if row["capacity_event"]})
    return {"supported": len(contexts) >= 2 and len(episodes) >= 2 and bool(event_contexts),
            "successful_injured_middle_contexts": contexts, "successful_episodes": episodes,
            "capacity_event_contexts": event_contexts}


def report(out):
    out = Path(out).resolve(); manifest = read(out / "MANIFEST.json", {}); finished = read(out / "RUN_FINISHED.json", {})
    queue_rows, branch_rows, comparisons = [], [], []
    by_branch = defaultdict(list)
    for metadata, result, online in iter_cases(out):
        facts = {}
        for name in BRANCHES:
            record = result.get("branches", {}).get(name) or {}
            fact = branch_facts(record, metadata["gap_m"])
            fact = {**metadata, **fact, "queue_status": metadata["status"], "branch": name,
                    "expected_by_trigger": metadata["timely_recognized_sent"] if name == "IMMEDIATE" else metadata["injured_middle_event"]}
            artifact = fact.get("artifact")
            if artifact:
                fact["artifact"] = {**artifact, "path": str(resolve(out, artifact["path"]))}
            if fact.get("controls_path"):
                fact["controls_path"] = str(resolve(out, fact["controls_path"]))
            facts[name] = fact
            branch_rows.append(fact)
            if fact["expected_by_trigger"]:
                by_branch[name].append(fact)
        queue = dict(metadata)
        for name, fact in facts.items():
            queue.update({name + "_" + key: fact[key] for key in ("status", "executed", "complete_501", "actual_safe_at_frozen_gap", "full_50_ticks_20ms", "execution_confirmed", "progress20_m", "capacity_event")})
        queue_rows.append(queue)
        main = facts["IMMEDIATE"]
        if metadata["injured_middle_event"]:
            for name in ("COUNTERFACTUAL_C", "COUNTERFACTUAL_B"):
                baseline = facts[name]
                observable = bool(main["actual_safe_at_frozen_gap"] and baseline["actual_safe_at_frozen_gap"]
                                  and finite(main["progress20_m"]) and finite(baseline["progress20_m"]))
                comparisons.append({**metadata, "comparison": name, "comparison_available": observable,
                    "immediate_actual_safe": main["actual_safe_at_frozen_gap"], "baseline_actual_safe": baseline["actual_safe_at_frozen_gap"],
                    "immediate_progress20_m": main["progress20_m"], "baseline_progress20_m": baseline["progress20_m"],
                    "actual_progress_delta_m": main["progress20_m"] - baseline["progress20_m"] if observable else None,
                    "baseline_decision_cost": "SHARED_ORIGINAL_PACKET_NOT_INDEPENDENTLY_MEASURED",
                    "baseline_controls_path": baseline["controls_path"], "immediate_controls_path": main["controls_path"]})
            endpoint_records_available = bool(facts["COUNTERFACTUAL_C"]["complete_501"] and facts["COUNTERFACTUAL_B"]["complete_501"])
            comparisons.append({**metadata, "comparison": "MIDDLE_ONLY_ACTION_SET_EXTENSION",
                "comparison_available": endpoint_records_available,
                "extension": bool(endpoint_records_available and main["actual_safe_at_frozen_gap"]
                                  and not facts["COUNTERFACTUAL_C"]["actual_safe_at_frozen_gap"] and not facts["COUNTERFACTUAL_B"]["actual_safe_at_frozen_gap"]),
                "unavailable_or_incomplete_endpoint_not_treated_as_proven_unsafe": True})
    queue_summary = summarize_queue(queue_rows, PLANNED)
    branch_summary = {name: summarize_branches(by_branch[name], sum(row["timely_recognized_sent"] if name == "IMMEDIATE" else row["injured_middle_event"] for row in queue_rows)) for name in BRANCHES}
    immediate = criterion(by_branch["IMMEDIATE"]); delay = criterion(by_branch["DELAY20"])
    immediate_status = "FROZEN_POLICY_EXECUTION_SUPPORTED" if immediate["supported"] else "NOT_ESTABLISHED"
    delay_status = "FIRST_PACKET_DELAY_SUPPORTED" if delay["supported"] else "NOT_ESTABLISHED"
    groups = []
    planned_by_role = {"healthy": 4, "thigh": 20, "calf": 20}
    for field in ("role", "injured", "front_or_rear", "episode", "gamma"):
        for value in sorted({str(row[field]) for row in queue_rows}):
            selected = [row for row in queue_rows if str(row[field]) == value]
            planned = planned_by_role.get(value, len(selected)) if field == "role" else 40 if field == "injured" and value == "True" else 4 if field == "injured" else 22 if field == "front_or_rear" and value in ("FR", "RR", "front", "rear") else 11 if field == "episode" else len(selected)
            groups.append({"field": field, "value": value, **summarize_queue(selected, planned)})
    csv_write(out / "QUEUE_RESULTS.csv", queue_rows); write(out / "QUEUE_RESULTS.json", queue_rows)
    csv_write(out / "BRANCH_RESULTS.csv", branch_rows); write(out / "BRANCH_RESULTS.json", branch_rows)
    csv_write(out / "GROUP_RESULTS.csv", groups)
    csv_write(out / "COUNTERFACTUAL_COMPARISONS.csv", comparisons); write(out / "COUNTERFACTUAL_COMPARISONS.json", comparisons)
    logical = Counter(); event_ledger_count = 0
    for event in jsonl_rows(out / "EVENT_LEDGER.jsonl"):
        logical[str(event.get("event", event.get("phase", "UNCLASSIFIED_EVENT")))] += 1
        event_ledger_count += 1
    result = {"run_id": manifest.get("run_id"), "NUMERICAL_STATUS": finished.get("status", "INCOMPLETE"),
        "IMMEDIATE_STATUS": immediate_status, "DELAY20_STATUS": delay_status,
        "immediate_criterion": immediate, "delay20_criterion": delay, "queue": queue_summary,
        "branches": branch_summary, "groups": groups, "budget": finished.get("budget"),
        "all_sent_packets_IMMEDIATE_recorded": sum(row["IMMEDIATE_executed"] for row in queue_rows) == queue_summary["timely_recognized_sent"],
        "unexpected_rejected_packet_rollouts": sum(row["IMMEDIATE_executed"] and not row["timely_recognized_sent"] for row in queue_rows),
        "task_progress_comparisons_safe_baselines": sum(bool(row.get("comparison_available")) for row in comparisons if row["comparison"] != "MIDDLE_ONLY_ACTION_SET_EXTENSION"),
        "task_progress_positive_deltas": sum(finite(row.get("actual_progress_delta_m")) and row["actual_progress_delta_m"] > 1e-12 for row in comparisons),
        "middle_only_extension_contexts": sorted({row["context_id"] for row in comparisons if row.get("extension")}),
        "model_hash_reference": manifest.get("model_hash_reference", manifest.get("model_source_assets")),
        "logical_event_count": event_ledger_count, "logical_event_types": dict(logical),
        "NEW_MODEL_FITS": 0, "historical_STEP30_safety_coverage": .2746,
        "historical_STEP30_science_status": "NOT_ESTABLISHED", "historical_STEP30_deployment_status": "NOT_ESTABLISHED",
        "conditional_completion_replaces_44_recognition_rate": False, "ABSTAIN_zero_motion_imputed": False,
        "fixed_queue_random_population_success_claim": False, "DELAY_failure_overwrites_IMMEDIATE": False,
        "E3_RL_hardware_authorized": False}
    write(out / "STEP31_RESULT.json", result)
    (out / "STEP31_REPORT.md").write_text(_report_text(result, manifest), encoding="utf-8", newline="\n")
    (out / "STEP31_RESEARCH_HANDOFF.md").write_text(_handoff_text(result), encoding="utf-8", newline="\n")
    return result


def _report_text(result, manifest):
    queue = result["queue"]; immediate = result["immediate_criterion"]; delay = result["delay20_criterion"]
    lines = ["# STEP31：冻结调节器的全触发受损执行确认", "",
        "日期：2026-10-09（Asia/Seoul）。Material Passport：experiment-agent / run / ANALYZED；证据图：scipilot-figure-skill。", "",
        f"Run ID：{manifest.get('run_id')}；源提交：{manifest.get('source_commit', 'dc9a2cdfc33e2abba2d581ac4cc3eed1456b5fde')}。",
        f"即时执行结论：**{result['IMMEDIATE_STATUS']}**；一周期延迟诊断：**{result['DELAY20_STATUS']}**。",
        f"44个计划输入中，及时认可且发送{queue['timely_recognized_sent']}（{100*queue['timely_recognition_rate_planned']:.2f}%）；触发后完整执行确认{queue['IMMEDIATE_confirmed']}。这两个分母分别保留，后者不替代计划队列及时认可率。", "",
        f"主目标分项：新受损中间context完整通过{len(immediate['successful_injured_middle_contexts'])}个、覆盖{len(immediate['successful_episodes'])}条episode；其中真实capacity/99%事件{len(immediate['capacity_event_contexts'])}个。数量与episode条件和capacity事件条件分别判断，不能将未满足的事件条件省略。",
        "## 冻结方法与新队列", "",
        "本轮原样加载STEP30 GEOMETRY_FULL_26/LOCAL权重、scaler、support、pose域及CAL身份，新增fit=0。Gamma、Solved有限端点、混合残差、clip、PID/积分、backup anchor、绝对20ms deadline、6ms solver上限、1s/2ms dense以及原physical/local/终端界均保持。只改变队列与验证编排，不增加新CAL、预测器、canary或完整五动作新bank。模型/决策代码hash引用见MANIFEST.json；当前身份/文件核验由主线一次完成。",
        "T31_P065/N065/P067/N067四条固定stance reference，各取tick28/31/34/37/40的thigh .15/calf .15，另在tick34加入healthy对照，共40受损+4healthy。正vx为FR、负vx为RR。recipe seed为标识，不是随机重复；这是围绕识别窗口的预声明部署确认，不称总体随机成功率或广泛泛化。资格失败保留、不换点。",
        "proposal仅生成当前参考端点/prefix及model-only probe gap，不能做1s teacher，也不充作在线命令。gap在任何ACTUAL标签前冻结；无中间窗口保留ordinal循环fixed fallback并标PROBE_NO_MIDDLE_WINDOW。每例online只真实决策一次，使用这次同一selected_action立即传播；不重新决策、不另挑fresh索引。", "",
        "## 所有触发与全部失败", "",
        "及时认可selected_command_sent=True时，无论γ是否中间，都触发IMMEDIATE。reject/unavailable/late/cutoff保留在44分母而不模拟为成功。第一τ逐值匹配发送packet；γ=0复用真实B0/b_after。独立分支均从同source state和明确恢复的控制记忆开始，反事实互不污染。", "",
        "| 分支 | 条件触发数 | 实际运行 | 完整501 | physical/local/terminal安全 | 全50tick≤20ms | 执行确认 | 数值未完成 |",
        "|---|---:|---:|---:|---:|---:|---:|---:|"]
    for branch in BRANCHES:
        data = result["branches"][branch]
        lines.append(f"| {branch} | {data['expected_by_trigger']} | {data['executed']} | {data['complete_501']} | {data['actual_safe_at_frozen_gap']} | {data['full_50_ticks_20ms']} | {data['execution_confirmed']} | {data['numerical_incomplete']} |")
    lines += ["", f"及时受损中间事件共{queue['injured_middle_events']}。即时主目标成功context：{immediate['successful_injured_middle_contexts']}，episode：{immediate['successful_episodes']}，其中有真实capacity/99%事件：{immediate['capacity_event_contexts']}。",
        "主目标仅按预声明数量确认，不隐藏其它认可动作失败。全部原物理、local、完整终端、command、numerical incomplete、late tick及首packet不匹配见[BRANCH_RESULTS](BRANCH_RESULTS.csv)，各类可能重叠；逐计划输入见[QUEUE_RESULTS](QUEUE_RESULTS.csv)，healthy/受损、前/后腿、γ和episode分列见[GROUP_RESULTS](GROUP_RESULTS.csv)。",
        f"在线raw有效但过期{queue['raw_valid_but_late']}；late发送{queue['late_sent']}；动作budget cutoff {queue['cutoff_action_count']}；runtime setup事件{queue['runtime_setup_events']}。全部准备/QP/prefix/推断/必要拷贝计时，文件写入在command-ready之后；startup另列。",
        f"IMMEDIATE是否覆盖所有及时发送：{result['all_sent_packets_IMMEDIATE_recorded']}；拒收后异常传播数{result['unexpected_rejected_packet_rollouts']}；packet发送元数据不一致数{queue['packet_sent_metadata_disagreement']}。NOT_RUN与已运行数值失败分开，缺失时延不填0。", "",
        "## 同packet反事实与实际任务进度", "",
        "每个及时发送的受损中间事件，COUNTERFACTUAL_C/B只使用该真实packet已算端点，不重新求解、不从proposal补入。端点未必被模型认可，显式是COUNTERFACTUAL_ENDPOINT；首槽成本共享原packet，不声称独立baseline决策计时。",
        f"相对实际安全端点的可比较进度配对{result['task_progress_comparisons_safe_baselines']}条，其中正实际20ms进度差{result['task_progress_positive_deltas']}。C/B两端点均实际不安全而即时中间安全的扩展context：{result['middle_only_extension_contexts']}。",
        "[COUNTERFACTUAL_COMPARISONS](COUNTERFACTUAL_COMPARISONS.csv)仅在baseline实际安全时给数值进度差；缺失/NOT_RUN端点不当作不安全，ABSTAIN不当零运动。每12通道raw/sent/applied余量、capacity99事件及积分更新/冻结随branch events与完整controls路径保存，不仅用health标签代替激活。", "",
        "## 一周期首packet延迟诊断", "",
        "DELAY20独立从sample初态开始：前20ms保持有source身份的previous command，经新health统一clip，标LAST_COMMAND_HEALTH_CLIPPED而不是新受损SolvedQP；20–40ms施加原selected packet；.04/.06/…/.98s执行48个feedback槽。总500积分步/501状态，horizon仍从sample到1.000s，不延长至1.02s，anchor和终端宽度保持。",
        "first_command_matches在DELAY20指第2槽原packet；previous_command_matches另查prehold。sample点混合witness不被当成延后施加点可行证书。原witness/application时间、healthy source命令身份与prehold实际轨迹均独立保存；身份或previous command缺失则NOT_RUN，不补造。",
        f"延迟成功context：{delay['successful_injured_middle_contexts']}，episode：{delay['successful_episodes']}，真实capacity事件：{delay['capacity_event_contexts']}。DELAY20_STATUS独立于IMMEDIATE_STATUS，不回写即时结论。",
        "此分支只注入复杂governor首packet的固定20ms延迟；后续反馈计算时延如实报告，并不模拟全部通信/传感延迟。若即时确认已建立但延迟未建立，证据范围是理想施加时序，后续方向是时序补偿而非凑新模型或健康样本。", "",
        "## 预算、历史与交接", "", f"本轮预算：{result['budget']}。reference/prefix/ACTUAL独立计数，startup、proposal、online、触发分支及失败QP/积分步都属于同一90分钟/10,000QP/120,000步预算。新增模型fit=0；正式队列无结果驱动重试。",
        "STEP30历史安全覆盖27.46%及科学/部署NOT_ESTABLISHED原样保留，本轮不重新判40%目标PASS。历史positive不重跑、旧fresh不补跑、不新增五动作teacher bank；未访问机器人运控算法。",
        "交付身份registry、event/solve ledger、逐处理packet/轨迹/controls及CSV/JSON，聚合只含短事实和路径。两张SciPilot证据图展示全部44计划触发/完成/进度、所有即时/延迟配对轨迹和全tick时延，包含失败，不选择positive案例。必要纯测试与一次当前文件/身份核验、scoped Git diff检查由主线保存；独立分支提交、不push、不reset原HEAD。",
        "当前事实是固定队列的单次调节+feedback恢复与首packet延迟诊断，不称连续shield、硬件实时、已完成延迟补偿或全局viability。", "",
        "```ini", "AUTHORIZE_STEP31_FROZEN_EVENT_VALIDATION = TRUE",
        f"NUMERICAL_STATUS = {result['NUMERICAL_STATUS']}", f"IMMEDIATE_STATUS = {result['IMMEDIATE_STATUS']}", f"DELAY20_STATUS = {result['DELAY20_STATUS']}",
        "MAX_NEW_QP_CALLS = 10000", "MAX_NEW_PHYSICS_STEPS = 120000", "MAX_NUMERICAL_WALL_MINUTES = 90", "NEW_MODEL_FITS = 0",
        "MODEL_CALIBRATION_GAMMA_UNCHANGED = TRUE", "PLANNED_DAMAGED_CONTEXTS = 40", "PLANNED_HEALTHY_CONTROLS = 4",
        "ROLLOUT_EVERY_TIMELY_RECOGNIZED_PACKET = TRUE", "REDECIDE_BEFORE_ROLLOUT = FALSE", "POST_OUTCOME_CASE_REPLACEMENT = FALSE",
        "DELAY_DIAGNOSTIC_MS = 20", "HORIZON_FROM_SAMPLE_S = 1", "DENSE_PHYSICS_DT_S = 0.002", "DEADLINE_MS = 20",
        "SOLVER_TIME_LIMIT_UPPER_S = 0.006", "PHYSICAL_AND_TERMINAL_BOUNDS_UNCHANGED = TRUE", "HISTORICAL_RESULTS_UNCHANGED = TRUE",
        "E3_RL_HARDWARE = NOT_AUTHORIZED", "```", ""]
    return "\n".join(lines)


def _handoff_text(result):
    return "\n".join(["# STEP31研究交接", "", f"Run ID：{result['run_id']}",
        f"即时执行：{result['IMMEDIATE_STATUS']}", f"首packet延迟：{result['DELAY20_STATUS']}", "",
        "GEOMETRY_FULL_26/LOCAL/scaler/support/pose/CAL身份保持STEP30冻结；fit=0。STEP30覆盖27.46%与原NOT_ESTABLISHED不改。",
        "44计划输入及时认可率与trigger后条件执行率分开。所有及时发送packet立即同τ实际推进，不另决策；每个受损中间事件有同packet C/B反事实与独立DELAY20机会，所有失败和NOT_RUN保留。",
        "反事实首槽成本来自共享packet；只对实际安全baseline给进度差；未执行或ABSTAIN不当零运动/不安全。DELAY20前20ms previous-health-clip，后20ms原packet，48feedback，horizon sample到1.000s，不将sample witness外推为延后状态证书。",
        f"IMMEDIATE成功：{result['immediate_criterion']}", f"DELAY20成功：{result['delay20_criterion']}",
        f"计划及时认可{result['queue']['timely_recognized_sent']}/44；IMMEDIATE完整确认{result['branches']['IMMEDIATE']['execution_confirmed']}，数值未完成{result['branches']['IMMEDIATE']['numerical_incomplete']}；DELAY20完整确认{result['branches']['DELAY20']['execution_confirmed']}，local失败{result['branches']['DELAY20']['local_failure']}，数值未完成{result['branches']['DELAY20']['numerical_incomplete']}。",
        "若即时支持但延迟不支持，下项应针对首packet施加时序补偿；不通过新增CAL/模型/health/positive挑点改写本轮。",
        "当前证据不是随机总体成功率、连续安全、硬件实时或全局viability。后续工作须新授权；历史positive/旧fresh不补跑，无E3/RL/硬件授权，不访问机器人运控算法。", ""])


if __name__ == "__main__":
    parser = argparse.ArgumentParser(); parser.add_argument("out")
    value = report(parser.parse_args().out)
    print(value["IMMEDIATE_STATUS"], value["DELAY20_STATUS"])
