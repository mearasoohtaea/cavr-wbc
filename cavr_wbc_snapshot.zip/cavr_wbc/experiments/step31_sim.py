"""Frozen STEP31 same-packet execution and sample-clock delay diagnostic.

No function in this module calls a governor, nominal endpoint generator or
first-backup solver.  Only feedback calls after the already-sent command are
new QPs.  Existing STEP29 propagation/evaluation semantics are read-only.
"""
from __future__ import annotations
from copy import deepcopy
import hashlib
from time import perf_counter
import mujoco
import numpy as np
from cavr_wbc.experiments import step29_sim as source
from cavr_wbc.control.step30_actions import GAMMA_GRID,make_action

VERSION='STEP31_SAME_PACKET_ACTUAL_V1'
FIELDS=('qpos','qvel','act','ctrl','qacc_warmstart','qfrc_applied','xfrc_applied',
        'mocap_pos','mocap_quat','userdata','plugin_state')


def _workspace_id(key):
    """Post-ready structural identity, avoiding non-JSON binary CSC keys."""
    digest=hashlib.sha256()
    for value in key:
        digest.update(value if isinstance(value,bytes) else repr(value).encode('ascii'))
        digest.update(b'\0')
    return digest.hexdigest()


def capture_packet_memory(kernel,packet):
    """Post-ready diagnostic copy of actual B0 logical and primal/dual memory.

    The decision timestamp and all frozen model/command code remain untouched.
    This permits the later independent B counterfactual to seed exactly the
    original B0 warm-start instead of the state left by an earlier branch.
    """
    if 'step31_backup_memory' in packet:return packet
    begin=perf_counter();B=packet.get('B') or {}
    if not B.get('valid_command',B.get('command_valid',False)):
        packet['step31_backup_memory']={'status':'B0_NOT_AVAILABLE','workspaces':[],
            'post_ready_diagnostic':True,'new_QP_calls':0}
        return packet
    record=B.get('integral_record') or {}
    used=np.asarray(record.get('b_used'),dtype=float);after=np.asarray(record.get('b_after'),dtype=float)
    if (used.shape!=(6,) or not np.array_equal(used,np.zeros(6)) or after.shape!=(6,) or
        not np.isfinite(after).all()):raise ValueError('STEP31 packet B0 integral witness invalid')
    servo=getattr(kernel,'backup_servo',None)
    if servo is None or not np.array_equal(servo.b_integral,after):
        raise ValueError('STEP31 post-ready B0 logical memory does not match packet')
    if getattr(kernel,'_last_backup_slot',0)!=0:
        raise ValueError('STEP31 packet memory must be captured before any feedback branch')
    workspaces=[]
    for key,cache in getattr(getattr(kernel,'backup_controller',None),'_solver_cache',{}).items():
        workspaces.append({'workspace_id':_workspace_id(key),
            'last_x':None if cache.get('last_x') is None else np.asarray(cache['last_x']).copy(),
            'last_y':None if cache.get('last_y') is None else np.asarray(cache['last_y']).copy()})
    packet['step31_backup_memory']={'status':'CAPTURED_B0','context_id':packet['context_id'],
        'backup_id':B.get('backup_id',getattr(getattr(kernel,'policy',None),'backup_id',None)),
        'logical_last_slot':0,'integral_b_used':used.copy(),'integral_b_after':after.copy(),
        'workspaces':workspaces,'primal_dual_workspace_count':len(workspaces),
        'post_ready_diagnostic':True,'decision_command_ready_ms_unchanged':packet.get('command_ready_ms'),
        'diagnostic_copy_ms':(perf_counter()-begin)*1000.,'new_QP_calls':0}
    return packet


def _trigger_reason(context,packet):
    if context.get('eligible') is False:return 'CONTEXT_NOT_ELIGIBLE'
    if not packet.get('selected_command_sent'):return 'PACKET_NOT_TIMELY_RECOGNIZED_SENT'
    if packet.get('context_id')!=context['context_id']:raise ValueError('STEP31 packet/current context identity mismatch')
    action=packet.get('selected_action') or {}
    latency=float(packet.get('command_ready_ms',float('nan')))
    gamma=float(packet.get('selected_gamma',float('nan')))
    if (not action.get('command_valid') or gamma not in GAMMA_GRID or float(action.get('gamma',-1.))!=gamma or
        not np.isfinite(latency) or latency<0. or latency>20.):
        raise ValueError('STEP31 sent packet lost command/gamma/deadline contract')
    return None


def _middle_event(context,packet):
    gamma=float(packet['selected_gamma'])
    return bool(0.<gamma<1. and np.any(np.asarray(context['health_vector'])<1.))


def _not_run(context,packet,purpose,reason,gamma=None):
    state=deepcopy(context.get('state',{}))
    return {'schema':VERSION,'kind':'ACTUAL_C','branch_id':context['context_id']+':'+purpose,
        'branch_purpose':purpose,'status':'NOT_RUN','reason':{'reason':reason},
        'gamma':gamma,'backup_id':context['backup_id'],'fixed_anchor_q_init':deepcopy(context['backup_anchor_q_init']),
        'health_vector':deepcopy(context['health_vector']),'initial_state':state,'final_state':deepcopy(state),
        'initial_fact':None,'controls':[],'physics_trajectory':[],'checkpoints':[],'solver_ledger':[],
        'packet_context_id':packet.get('context_id'),'same_packet_used':True,'new_governor_calls':0,
        'new_endpoint_QP_calls':0,'horizon_s':1.,'all_available_ticks_within_20ms':False,
        'counts':{'physical_steps':0,'control_qp_calls':0,'backup_qp_calls':0,'feedback_QP_calls':0,
            'new_feedback_QP_calls':0,'packet_B0_reused_count':0,'clone_data_calls':0},'elapsed_ms':0.}


class _FeedbackKernel:
    """Execution-only adapter: retain frozen kernel, set unchanged 6 ms limit."""
    def __init__(self,kernel):self.kernel=kernel
    def __getattr__(self,name):return getattr(self.kernel,name)
    def compute_backup(self,context,slot,**kwargs):
        self.kernel.set_next_call_limit(.006)
        return self.kernel.compute_backup(context,slot,**kwargs)


def _ready_backup(kernel,context,packet):
    B=packet.get('B') or {}
    required=('capacity_interface','tau_cmd','integral_record','valid_command')
    if any(key not in B for key in required):return None,None
    ready=dict(B,command_ready_ms=float(packet['command_ready_ms']),latency_ms=float(packet['command_ready_ms']))
    source._validate_ready(ready,np.asarray(context['health_vector']),np.asarray(kernel.healthy_limits))
    memory=packet.get('step31_backup_memory') or {}
    if memory.get('status')!='CAPTURED_B0':return None,None
    if memory['context_id']!=context['context_id'] or not np.array_equal(
        memory['integral_b_after'],ready['integral_record']['b_after']):
        raise ValueError('STEP31 B0 packet/memory witness mismatch')
    # Restore full integration state, fixed anchor, b0 and zeroed independent
    # workspace first, then the exact saved B0 post-update memory.
    kernel.reset_backup(kernel.data,context,preserve_ready=False)
    kernel.backup_servo.b_integral[:]=memory['integral_b_after']
    kernel._backup_context_id=str(context['context_id'])
    kernel._last_backup_slot=0;kernel._last_backup_response=ready
    if hasattr(kernel,'identity'):kernel.identity=(context['context_id'],context['backup_id'])
    caches=getattr(getattr(kernel,'backup_controller',None),'_solver_cache',{})
    by_id={_workspace_id(key):cache for key,cache in caches.items()};restored=0
    for saved in memory['workspaces']:
        if saved['workspace_id'] not in by_id:raise ValueError('STEP31 captured B0 solver workspace missing')
        cache=by_id[saved['workspace_id']]
        x=None if saved['last_x'] is None else np.asarray(saved['last_x'],dtype=float).copy()
        y=None if saved['last_y'] is None else np.asarray(saved['last_y'],dtype=float).copy()
        cache['last_x']=x;cache['last_y']=y;cache['independent_case_zeroed']=False
        if x is not None or y is not None:cache['solver'].warm_start(x=x,y=y)
        restored+=1
    return ready,{'status':'RESTORED_PACKET_B0','integral_b_after':np.asarray(memory['integral_b_after']).copy(),
        'logical_last_slot':0,'primal_dual_workspaces_restored':restored,
        'independent_integration_state_restored':True,'new_QP_calls':0}


def _packet_proof(packet,action,purpose):
    return {'packet_context_id':packet['context_id'],'packet_selected_gamma':float(packet['selected_gamma']),
        'executed_gamma':float(action['gamma']),'shared_packet_command_ready_ms':float(packet['command_ready_ms']),
        'first_latency_is_shared_packet_cost':True,'independent_baseline_decision_latency_measured':False,
        'first_tau_packet':np.asarray(action['tau_sent']).copy(),'same_packet_used':True,
        'new_governor_calls':0,'new_endpoint_QP_calls':0,'branch_purpose':purpose,
        'counterfactual_endpoint':purpose.startswith('COUNTERFACTUAL'),
        'counterfactual_model_approval_claim':False,'original_witness_time_s':0.,
        'selected_application_time_s':0.,'horizon_s':1.}


def _immediate_action(kernel,context,packet,action,budget,purpose):
    gamma=float(action['gamma']);mode='B' if gamma==0. else 'C'
    branch_context=dict(context,branch_id=context['context_id']+':'+purpose)
    ready=None;memory=None
    if mode=='B':
        ready,memory=_ready_backup(kernel,context,packet)
        if ready is None:
            if purpose=='IMMEDIATE':raise ValueError('STEP31 sent B0 packet lost required response or memory')
            return _not_run(context,packet,purpose,'PACKET_B0_RESPONSE_OR_MEMORY_UNAVAILABLE',gamma)
        if not np.array_equal(ready['tau_cmd'],action['tau_sent']):
            raise ValueError('STEP31 B0 selected tau differs from packet source')
    view=source.candidate_view(action,context,command_ready_ms=float(packet['command_ready_ms']))
    result=source.actual_branch(kernel.model,kernel.data,branch_context,view,mode,'ACTUAL_'+mode,
        budget,_FeedbackKernel(kernel),ready_response=ready)
    first=result.get('controls',[None])[0] if result.get('controls') else None
    result.update(schema=VERSION,gamma=gamma,first_action_kind=action.get('kind'),
        synthesized_action_not_optimizer_return=0.<gamma<1.,**_packet_proof(packet,action,purpose),
        first_tau_matches_packet=bool(first is not None and np.array_equal(first['tau_sent'],action['tau_sent'])),
        backup_memory_restore=memory or {'status':'INDEPENDENT_ZERO_INTEGRAL_RESET','new_QP_calls':0})
    ledger=result.get('solver_ledger',[])
    new_count=sum(int(row.get('slot',0))>=1 for row in ledger)
    result['counts'].update(feedback_QP_calls=int(new_count),new_feedback_QP_calls=int(new_count),
        packet_B0_reused_count=int(mode=='B' and bool(first)),
        backup_policy_resets=1,
        endpoint_QP_calls_new=0,governor_calls_new=0)
    result['protocol_role']='COUNTERFACTUAL_ENDPOINT' if purpose.startswith('COUNTERFACTUAL') else purpose
    return result


def immediate(kernel,context,packet,budget):
    reason=_trigger_reason(context,packet)
    if reason:return _not_run(context,packet,'IMMEDIATE',reason)
    capture_packet_memory(kernel,packet)
    return _immediate_action(kernel,context,packet,packet['selected_action'],budget,'IMMEDIATE')


def endpoint(kernel,context,packet,mode,budget):
    if mode not in ('C','B'):raise ValueError('STEP31 endpoint requires C or B')
    purpose='COUNTERFACTUAL_'+mode
    reason=_trigger_reason(context,packet)
    if reason:return _not_run(context,packet,purpose,reason)
    if not _middle_event(context,packet):return _not_run(context,packet,purpose,'NOT_INJURED_MIDDLE_EVENT')
    end=packet.get(mode) or {}
    if end.get('status')=='NOT_REQUESTED' or not end.get('command_valid',end.get('valid_command',False)):
        return _not_run(context,packet,purpose,'PACKET_ENDPOINT_UNAVAILABLE')
    gamma=1. if mode=='C' else 0.
    action=make_action(context,packet.get('C'),packet.get('B'),gamma)
    if not action['command_valid'] or action.get('z_raw') is None:
        return _not_run(context,packet,purpose,'PACKET_ENDPOINT_FULL_PRIMAL_UNAVAILABLE',gamma)
    if 'step31_backup_memory' not in packet:
        raise ValueError('STEP31 counterfactual needs post-ready packet memory captured before IMMEDIATE')
    return _immediate_action(kernel,context,packet,action,budget,purpose)


def _previous_command(context,limits):
    begin=perf_counter();state=context.get('state') or {};identity=context.get('previous_command_identity') or {}
    fact=context.get('healthy_fact') or {};health=np.asarray(context['health_vector'],dtype=float)
    ctrl=np.asarray(state.get('ctrl'),dtype=float);saved=np.asarray(identity.get('tau_sent'),dtype=float)
    witness=np.asarray(fact.get('tau_sent'),dtype=float)
    if (not context.get('source_integration_state_complete') or
        identity.get('available') is not True or identity.get('source_solver_status_val')!=1 or
        identity.get('actual_state_ctrl_matches_healthy_fact_and_control') is not True or
        state.get('integration_state_signature')!=int(mujoco.mjtState.mjSTATE_INTEGRATION) or
        'integration_state' not in state or not np.isfinite(np.asarray(state['integration_state'],dtype=float)).all() or
        identity.get('source')!='NEW_HEALTHY_REFERENCE_SAVED_STATE' or
        not isinstance(identity.get('episode_id'),str) or not isinstance(identity.get('snapshot_id'),str) or
        identity.get('source_tick')!=context.get('source_tick') or
        identity.get('source_time_s')!=context.get('source_time_s') or
        not isinstance(identity.get('source_time_s'),(int,float,np.number)) or
        not np.isfinite(identity.get('source_time_s',float('nan'))) or
        identity.get('applied_previous_reference_tick')!=int(context.get('source_tick',0))-1 or
        not np.array_equal(identity.get('source_health_vector'),np.ones(len(health))) or
        not np.array_equal(fact.get('health_vector'),np.ones(len(health))) or
        any(v.shape!=health.shape or not np.isfinite(v).all() for v in (ctrl,saved,witness)) or
        not np.array_equal(ctrl,saved) or not np.array_equal(ctrl,witness)):
        return None,None,None,'KNOWN_PREVIOUS_HEALTHY_COMMAND_IDENTITY_UNAVAILABLE'
    cap=health*limits;sent=np.clip(ctrl,-cap,cap)
    raw_idx=np.flatnonzero((cap<=0.)|(np.abs(ctrl)>=.99*cap))
    sent_idx=np.flatnonzero((cap<=0.)|(np.abs(sent)>=.99*cap))
    interface={'command_valid':True,'solver_exact_solved':False,'solver_status_val':None,
        'health_vector':health.copy(),'healthy_torque_limits_nm':limits.copy(),'effective_capacity_nm':cap,
        'tau_raw':ctrl.copy(),'tau_sent':sent,'saturation_mask':sent!=ctrl,'correction_nm':sent-ctrl,
        'raw_command_within_capacity_exact':bool(np.all(np.abs(ctrl)<=cap)),
        'sent_command_within_capacity_exact':bool(np.all(np.abs(sent)<=cap)),
        'raw_99_percent_active_indices':raw_idx,'sent_99_percent_active_indices':sent_idx,
        'version':'STEP31_LAST_COMMAND_HEALTH_CLIPPED','new_QP_calls':0,
        'source_healthy_command_identity':deepcopy(identity)}
    return interface,deepcopy(identity),(perf_counter()-begin)*1000.,None


def delay20(kernel,context,packet,budget):
    """Hold previous clipped command, selected packet, then 48 feedback QPs.

    Actual slots 0/1 are 0/.02 seconds.  Backup logical slots 1..48 occur at
    sample-clock .04.. .98 with the original sample anchor and zero integral.
    The sample witness is never relabelled a current witness at delayed apply.
    """
    purpose='DELAY20';reason=_trigger_reason(context,packet)
    if reason:return _not_run(context,packet,purpose,reason)
    if not _middle_event(context,packet):return _not_run(context,packet,purpose,'NOT_INJURED_MIDDLE_EVENT')
    limits=np.asarray(kernel.healthy_limits,dtype=float)
    hold,previous_identity,clip_ms,reason=_previous_command(context,limits)
    if reason:return _not_run(context,packet,purpose,reason,float(packet['selected_gamma']))
    action=packet['selected_action'];view=source.candidate_view(action,context,command_ready_ms=packet['command_ready_ms'])
    health=np.asarray(context['health_vector'],dtype=float)
    selected_interface=source._candidate_interface(view,health,limits)
    begin=perf_counter();source._check(budget)
    bid=context['backup_id'];branch_id=context['context_id']+':'+purpose
    branch_context=dict(context,branch_id=branch_id);metadata=source._metadata(branch_context,health)
    anchor=np.asarray(context['backup_anchor_q_init'],dtype=float).copy()
    counts_before=source._kernel_counts(kernel)
    kernel.reset_backup(kernel.data,branch_context,preserve_ready=False)
    data=kernel.backup_data;initial=source.state_values(kernel.model,data)
    if abs(float(data.time))>1e-12:raise ValueError('STEP31 delay branch must start relative clock zero')
    observer=source._observer(budget,'ACTUAL',branch_id)
    controls=[];physics=[];checkpoints=[];ledger=[];steps=0;failure=None;initial_fact=None
    first_feedback_ms=0.;control_ms=0.;integration_s=0.;refresh_s=0.;fact_s=0.;action_forward=0;refresh=0
    for slot in range(50):
        _,guard=source._budget_call(lambda:source._check(budget))
        if guard is not None:failure=dict(guard,slot=slot,physics_step=steps);break
        if not source._finite_state(data):failure={'reason':'NONFINITE_STATE_BEFORE_CONTROL','slot':slot,'physics_step':steps};break
        response=None;logical_slot=None
        if slot==0:
            interface=hold;tau=np.asarray(hold['tau_sent']);raw_wb={'status':'LAST_COMMAND_HEALTH_CLIPPED','status_val':None}
            valid=True;ms=clip_ms;ref=0.;source_name='LAST_COMMAND_HEALTH_CLIPPED'
        elif slot==1:
            interface=selected_interface;tau=np.asarray(action['tau_sent']);raw_wb=view['raw_solver_result']
            valid=True;ms=float(packet['command_ready_ms']);ref=float(action['a_base_ref'][0]) if action.get('a_base_ref') is not None else 0.
            source_name='DELAYED_SAME_PACKET_TAU_20MS'
        else:
            logical_slot=slot-1;kernel.set_next_call_limit(.006)
            response,guard=source._budget_call(lambda:kernel.compute_backup(branch_context,logical_slot,
                budget=budget,kind='ACTUAL_C',owner=branch_id))
            if guard is not None:failure=dict(guard,slot=slot,physics_step=steps);break
            interface=response['capacity_interface'];raw_wb=response.get('wbc',response.get('raw_solver_result',{}))
            tau=np.asarray(response['tau_cmd']);valid=bool(response['valid_command']);ms=float(response['command_ready_ms'])
            ref=float(response['a_base_ref'][0]) if len(response.get('a_base_ref',[])) else 0.
            source_name='FEEDBACK_BACKUP_QP_TOTAL' if valid else 'INVALID_BACKUP_QP'
            control_ms+=ms
            if slot==2:first_feedback_ms=ms
            ledger.extend(source._copy_ledger(response,branch_id=branch_id,kind='ACTUAL_C',slot=slot,bid=bid))
        data.ctrl[:]=tau;mujoco.mj_forward(kernel.model,data);action_forward+=1
        row=source._control_row(slot,source_name,tau,data,health,interface,response,raw_wb,valid,ms,
            candidate=view if slot==1 else None)
        row.update(backup_feedback_logical_slot=logical_slot,actual_application_time_s=slot*.020,
            original_witness_time_s=0. if slot==1 else None,
            delayed_sample_witness_not_current_application_certificate=slot==1,
            reused_packet_first=slot==1,previous_command_not_new_solved_QP=slot==0)
        controls.append(row)
        if source._finite_state(data):
            t=perf_counter();fact=source.compact_fact(kernel.model,data,health,limits,tau,ref,ms,steps,slot,bid,branch_id,interface,metadata)
            fact_s+=perf_counter()-t
            if slot==0:initial_fact=fact;checkpoints.append(dict(fact,checkpoint_index=0,checkpoint_target_s=0.))
        else:failure={'reason':'NONFINITE_STATE_AFTER_COMMAND_FORWARD','slot':slot,'physics_step':steps}
        if not valid:failure={'reason':'INVALID_BACKUP_QP','slot':slot,'physics_step':steps,'solver_status_val':raw_wb.get('status_val')}
        if failure:break
        for _ in range(10):
            if observer is not None:
                _,guard=source._budget_call(observer)
                if guard is not None:failure=dict(guard,slot=slot,physics_step=steps);break
            t=perf_counter();mujoco.mj_step(kernel.model,data);steps+=1;integration_s+=perf_counter()-t
            if not source._finite_state(data) or abs(float(data.time)-steps*.002)>1e-9:
                failure={'reason':'NONFINITE_STATE_OR_SIMULATOR_RESET_AFTER_STEP','slot':slot,'physics_step':steps}
            else:
                t=perf_counter();mujoco.mj_forward(kernel.model,data);refresh+=1;refresh_s+=perf_counter()-t
                if not source._finite_state(data):failure={'reason':'NONFINITE_STATE_AFTER_INTEGRATION_REFRESH','slot':slot,'physics_step':steps}
            if failure:
                physics.append({'time_s':steps*.002,'physics_step':steps,'numerical_failure':failure,
                    'state':source.state_values(kernel.model,data)});break
            t=perf_counter();fact=source.compact_fact(kernel.model,data,health,limits,tau,ref,ms,steps,slot,bid,branch_id,interface,metadata)
            fact_s+=perf_counter()-t;physics.append(fact)
            if steps in source.CHECKPOINT_STEPS:checkpoints.append(dict(fact,checkpoint_index=len(checkpoints),checkpoint_target_s=steps*.002))
        if failure:break
    complete=steps==500 and len(controls)==50 and failure is None
    deltas={key:value-counts_before[key] for key,value in source._kernel_counts(kernel).items()}
    first_selected=controls[1] if len(controls)>1 else None
    result={'schema':VERSION,'kind':'ACTUAL_C','branch_id':branch_id,'branch_purpose':purpose,
        'status':'COMPLETE' if complete else 'FAILED_BUDGET' if failure and failure['reason']=='GLOBAL_BUDGET_EXHAUSTED' else 'FAILED_NUMERICAL',
        'reason':failure,'gamma':float(action['gamma']),'backup_id':bid,'fixed_anchor_q_init':anchor.tolist(),
        'backup_version':source.HOLD_VERSION,'capacity_interface_version':source.CAPACITY_VERSION,**metadata,
        'initial_state':initial,'initial_fact':initial_fact,'final_state':source.state_values(kernel.model,data),
        'controls':controls,'physics_trajectory':physics,'checkpoints':checkpoints,'solver_ledger':ledger,
        'original_witness_time_s':0.,'selected_application_time_s':.020,'horizon_s':1.,
        'previous_command_identity':previous_identity,'previous_command_raw':hold['tau_raw'],
        'previous_command_health_clipped':hold['tau_sent'],'previous_command_not_new_solved_QP':True,
        'sample_witness_not_delayed_current_feasibility_certificate':True,
        'same_packet_used':True,'new_governor_calls':0,'new_endpoint_QP_calls':0,
        'first_tau_packet':np.asarray(action['tau_sent']).copy(),
        'first_tau_matches_packet':bool(first_selected and np.array_equal(first_selected['tau_sent'],action['tau_sent'])),
        'shared_packet_command_ready_ms':float(packet['command_ready_ms']),
        'first_latency_is_shared_packet_cost':True,'independent_baseline_decision_latency_measured':False,
        'prehold_physics_steps':min(steps,10),'selected_hold_physics_steps':min(max(0,steps-10),10),
        'backup_memory_restore':{'status':'INDEPENDENT_ZERO_INTEGRAL_RESET','logical_first_feedback_slot':1,
            'first_feedback_application_time_s':.04,'new_QP_calls':0},
        'counts':{'physical_steps':steps,'control_qp_calls':len(ledger),'backup_qp_calls':len(ledger),
            'feedback_QP_calls':len(ledger),'new_feedback_QP_calls':len(ledger),'packet_B0_reused_count':0,
            'endpoint_QP_calls_new':0,'governor_calls_new':0,'clone_data_calls':0,
            'backup_controller_instances':0,'backup_policy_resets':1,
            'action_conditioned_forward_calls':action_forward,'integration_refresh_forward_calls':refresh,**deltas},
        'first_backup_decision_ms':first_feedback_ms,'elapsed_ms':(perf_counter()-begin)*1000.,
        'feedback_latency_ms':[float(row['command_ready_ms']) for row in controls],
        'all_available_ticks_within_20ms':bool(controls and all(row['within_online_deadline'] for row in controls)),
        'timing':{'control_total_ms':control_ms,'integration_s':integration_s,'integration_refresh_s':refresh_s,
            'physical_fact_extraction_s':fact_s,'solver_wall_s':source._ledger_wall_s(ledger)}}
    rows=([initial_fact] if initial_fact is not None else [])+physics
    direction=1. if float(context['state']['qvel'][0])>0. else -1.
    if len(rows)>10 and 'qpos' in rows[10]:
        result['prehold_progress20_m']=float(direction*(rows[10]['qpos'][0]-anchor[0]))
    else:result['prehold_progress20_m']=None
    if len(rows)>20 and all('qpos' in rows[index] for index in (10,20)):
        result['selected_action_progress20_m']=float(direction*(rows[20]['qpos'][0]-rows[10]['qpos'][0]))
    else:result['selected_action_progress20_m']=None
    result['prehold_state_indices']=list(range(min(len(rows),11)))
    result['selected_action_state_interval_indices']=[10,20] if len(rows)>20 else None
    return source._json_safe(result)
