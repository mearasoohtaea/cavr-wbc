"""Frozen STEP30 policy, new fixed44queue, everytimelypacket actualvalidation."""
import argparse
from copy import deepcopy
from datetime import datetime,timezone
import gc
import json
import os
from time import perf_counter
import traceback
import numpy as np
from cavr_wbc.experiments import step17_formal_panel as frozen,step26_sim as reference_sim
from cavr_wbc.experiments.step26_features_storage import save_bank
from cavr_wbc.experiments.step28_sprint import home_context
from cavr_wbc.experiments.step29_sprint import source_context
from cavr_wbc.experiments.step30_sprint import probe,events
from cavr_wbc.experiments.step31_budget import SprintBudget,SprintLimit
from cavr_wbc.experiments.step31_io import ROOT,SOURCE30,RUN_ID,PARENT,PROTOCOL,read,write,append,sha,relative
from cavr_wbc.experiments import step31_sim as sim
from cavr_wbc.control.step30_actions import GAMMA_GRID,prepare_shared,make_action
from cavr_wbc.control.step30_kernel import Kernel
from cavr_wbc.control.step30_margin import load_bundle,labels,safe,gamma_key
from cavr_wbc.platforms.go2_mujoco import extract_actuator_audit,extract_healthy_torque_limits

EPISODES=(('T31_P065',.065,20261183),('T31_N065',-.065,20261183),
    ('T31_P067',.067,20261184),('T31_N067',-.067,20261184))
TICKS=(28,31,34,37,40)


def plans():
    plan=[]
    for episode,_,_ in EPISODES:
        for tick in TICKS:
            for kind in(('THIGH_15','CALF_15','HEALTHY')if tick==34 else('THIGH_15','CALF_15')):
                plan.append({'context_id':episode+f'_T{tick:03d}_'+kind,'ordinal':len(plan),'role':kind.split('_')[0].lower(),
                    'health_kind':kind,'episode':episode,'snapshot_id':episode+f'_T{tick:03d}','tick':tick})
    return plan


def logical_event(out,event,**fields):
    append(out/'EVENT_LEDGER.jsonl',{'event':event,'timestamp_utc':datetime.now(timezone.utc).isoformat(),**fields})


def proposal(kernel,c,bundle,budget):
    """Current reference endpoints/prefix only; no actualhorizon or fit."""
    kernel.reset(c);C=kernel.nominal(c,budget,'PROPOSAL_C',c['context_id']);B=kernel.first_backup(c,budget,'PROPOSAL_B',c['context_id'])
    workspace=prepare_shared(c,C,B);actions={gamma_key(g):make_action(c,C,B,g,workspace=workspace)for g in GAMMA_GRID}
    prefixes={};inputs={}
    if actions['1']['command_valid']:prefixes['1']=kernel.prefix_action(c,actions['1'],budget)
    tail={g:actions[gamma_key(g)]for g in(.75,.5,.25,0.)if actions[gamma_key(g)]['command_valid']}
    if tail:prefixes.update({gamma_key(g):p for g,p in kernel.prefix_actions(c,tail,budget).items()})
    for key,action in actions.items():
        p=prefixes.get(key,{'complete':False,'available':False,'original_physical_pass':False,'reason':'CURRENT_COMMAND_UNAVAILABLE'})
        if(p.get('identity')or{}).get('native_return_code',0)<0:raise ValueError('proposal native contract failure')
        f=None;error=None
        if action['command_valid']:
            try:f=kernel.features(c,action,p)
            except(KeyError,ValueError,TypeError)as exc:error=str(exc)
        inputs[key]={'gamma':float(key),'role':c['role'],'features26':f,'prefix':p,'first_command_valid':action['command_valid'],'input_error':error}
    p=probe(inputs,bundle,c['ordinal'])
    return {'context':c,'C':C,'B':B,'actions':actions,'inputs':inputs,'probe':p,'actual_horizon_run':False,
        'proposal_command_never_used_for_online_or_actual':True,'new_model_fits':0,'gap_frozen_before_actual':True}


def branch_record(out,directory,name,branch,c,packet):
    path=directory/name;path.mkdir(parents=True,exist_ok=True)
    if branch.get('status')=='NOT_RUN':
        r={k:v for k,v in branch.items()if k not in('controls','physics_trajectory')};write(path/'RESULT.json',r);return r
    artifact=save_bank(path/'actual.npz',branch);label=labels(branch,c)
    write(path/'CONTROL_RESULTS.json',{'controls':branch['controls'],'status':branch['status'],'reason':branch.get('reason'),
        'command_kind':branch.get('first_action_kind'),'shared_packet_latency_not_independent_baseline_measurement':name.startswith('COUNTERFACTUAL')})
    first_index=1 if name=='DELAY20'else 0
    first_interface=branch['controls'][first_index]['capacity_interface']if len(branch['controls'])>first_index else{}
    source_action={'first_capacity_event':bool(first_interface.get('sent_99_percent_active_indices')),
        'capacity_interface':first_interface}
    record={'status':branch['status'],'artifact':artifact,'controls_path':relative(path/'CONTROL_RESULTS.json',out),
        'label':label,'events':events(branch,source_action),'first_command_matches':branch.get('first_tau_matches_packet'),
        'all_tick_deadline_pass':bool(branch['controls']and all(r['valid_command']and r['latency_ms']<=20. for r in branch['controls'])),
        'tick_latency_ms':[r['latency_ms']for r in branch['controls']],
        'counts':branch['counts'],'reason':branch.get('reason'),'gamma':branch.get('gamma'),
        'packet_context_id':c['context_id'],'original_witness_time_s':branch.get('original_witness_time_s',0.),
        'selected_application_time_s':branch.get('selected_application_time_s',0.),'horizon_s':1.,
        'first_previous_command_identity':branch.get('previous_command_identity'),
        'previous_command_matches':bool(name=='DELAY20'and branch['controls']and np.array_equal(branch['controls'][0]['tau_sent'],branch.get('previous_command_health_clipped'))),
        'first_latency_shared_packet':name.startswith('COUNTERFACTUAL'),
        'feedback_qp_calls':branch['counts'].get('new_feedback_QP_calls'),
        'packet_memory':branch.get('backup_memory_restore'),
        'result_path':relative(path/'RESULT.json',out)}
    write(path/'RESULT.json',record);return record


def execute_triggered_packet(kernel,c,packet,budget,out,result,event_callback=None):
    """Everytrue send triggersonce; no governor/proposal function in thispath."""
    emit=event_callback if event_callback else lambda event,**fields:logical_event(out,event,**fields)
    directory=out/'queue'/c['context_id'];online_path=directory/'ONLINE_NUMERIC.json'
    if packet.get('selected_command_sent'):
        sim.capture_packet_memory(kernel,packet)
    write(online_path,packet);result['online_path']=relative(online_path,out);result['selected_sent']=bool(packet.get('selected_command_sent'))
    result['selected_gamma']=packet.get('selected_gamma');result['online_status']=packet['status'];result['command_ready_ms']=packet.get('command_ready_ms')
    emit('ONLINE_RETURN',context_id=c['context_id'],ordinal=c['ordinal'],selected_sent=result['selected_sent'],gamma=result['selected_gamma'],status=packet['status'])
    write(directory/'RESULT.json',result)
    if not result['selected_sent']:return result
    callables=[('IMMEDIATE',lambda:sim.immediate(kernel,c,packet,budget))]
    if c['role']!='healthy'and 0.<float(packet['selected_gamma'])<1.:
        callables += [('COUNTERFACTUAL_C',lambda:sim.endpoint(kernel,c,packet,'C',budget)),
            ('COUNTERFACTUAL_B',lambda:sim.endpoint(kernel,c,packet,'B',budget)),('DELAY20',lambda:sim.delay20(kernel,c,packet,budget))]
    for name,operation in callables:
        emit('BRANCH_BEGIN',context_id=c['context_id'],branch=name,gamma=packet['selected_gamma'])
        try:branch=operation()
        except BaseException as exc:
            write(directory/name/'EXCEPTION.json',{'type':type(exc).__name__,'error':str(exc),'traceback':traceback.format_exc(),
                'budget':budget.snapshot(),'already_sent_packet_not_redecided':True});raise
        record=branch_record(out,directory,name,branch,c,packet)
        result['branches'][name]=record;write(directory/'RESULT.json',result)
        emit('BRANCH_RETURN',context_id=c['context_id'],branch=name,status=record['status'],artifact=record.get('artifact'),
            new_model_fits=0,same_packet_used=True)
        budget.persist(phase='TRIGGERED_BRANCH_SAVED',context_id=c['context_id'],branch=name)
        if branch.get('status')=='FAILED_BUDGET':raise SprintLimit('triggered branchpartial savedatcap')
        del branch
    return result


def add_previous_command_identity(c,episode):
    state=c.get('state');fact=c.get('healthy_fact');control=next((r for r in episode['controls']if r['tick']==c['source_tick']-1),None)
    if not state or not fact or not control:
        c['previous_command_identity']={'available':False,'reason':'SOURCE_PREVIOUS_CONTROL_RECORD_MISSING'};return
    previous=np.asarray(state['ctrl'],float);fact_sent=np.asarray(fact['tau_sent'],float);recorded=np.asarray(control['tau_sent'],float)
    valid=bool(control['valid_command']and control['solver_status_val']==1 and previous.shape==(12,)
        and np.isfinite(previous).all()and np.array_equal(previous,fact_sent)and np.array_equal(previous,recorded))
    c['previous_command_identity']={'available':valid,'source':'NEW_HEALTHY_REFERENCE_SAVED_STATE',
        'episode_id':c['episode_id'],'snapshot_id':c['snapshot_id'],'source_tick':c['source_tick'],
        'applied_previous_reference_tick':c['source_tick']-1,'source_time_s':c['source_time_s'],
        'source_health_vector':[1.]*12,'source_solver_status_val':control['solver_status_val'],'tau_sent':previous,
        'actual_state_ctrl_matches_healthy_fact_and_control':valid,'source_record_not_new_damaged_QP':True}


def run(run_id=RUN_ID):
    out=ROOT/'artifacts/step31_frozen_event_validation_20261009'/run_id
    if(out/'RUN_STARTED.json').exists():raise FileExistsError('oneuniqueSTEP31run')
    out.mkdir(parents=True,exist_ok=True)
    for d in('queue','episodes','figures'): (out/d).mkdir(exist_ok=True)
    write(out/'RUN_STARTED.json',{'pid':os.getpid(),'run_id':run_id,'start_utc':datetime.now(timezone.utc).isoformat()})
    budget=SprintBudget(out);budget.start();status='COMPLETED'
    try:
        t=perf_counter();model=frozen.load_model();source=read(SOURCE30/'MANIFEST.json');assets=read(SOURCE30/'models/MODEL_FREEZE.json')['assets']
        files=('cavr_wbc/control/step30_actions.py','cavr_wbc/control/step30_kernel.py','cavr_wbc/control/step30_margin.py')
        hashes={p:source['source_sha256'][p]for p in files}
        if any(sha(ROOT/p)!=h for p,h in hashes.items()):raise ValueError('frozen decisionnumeric code hash changed')
        if any(sha(a['npz'])!=a['npz_sha256']or sha(a['json'])!=a['json_sha256']for a in assets.values()):raise ValueError('frozen modelasset hash changed')
        bundle=load_bundle(SOURCE30/'models');limits=extract_healthy_torque_limits(model)
        mapping=[dict(e,healthy_limit_nm=float(limits[e['actuator_index']]))for e in extract_actuator_audit(model)]
        dll=SOURCE30/'native/step30_prefix.dll'
        manifest={'run_id':run_id,'source_commit':PARENT,'source_model':'GEOMETRY_FULL_26/LOCAL','model_source_assets':assets,
            'frozen_code_hashes':hashes,'native_dll_path':str(dll),'native_dll_sha256':sha(dll),
            'scenario':source['scenario'],'frozen_physical':source['frozen_physical'],'mapping':mapping,
            'planned_queue':plans(),'episodes':EPISODES,'ticks':TICKS,'planned_damaged':40,'planned_healthy':4,
            'max_QP':10000,'max_steps':120000,'max_wall_s':5400,'new_model_fits':0,
            'protocol_sha256':sha(PROTOCOL),'date':'2026-10-09','timezone':'Asia/Seoul','no_historical_replay':True}
        manifest['new_code_sha256']={relative(p,ROOT):sha(p)for p in(*ROOT.glob('cavr_wbc/experiments/step31*.py'),*ROOT.glob('tests/test_step31*.py'))}
        write(out/'MANIFEST.json',manifest)
        (out/'PROTOCOL_SOURCE.md').write_text(PROTOCOL.read_text(encoding='utf-8'),encoding='utf-8')
        home=home_context(model,manifest['scenario']);home.update(context_id='STEP31_HOME',backup_id='STEP31-HOME')
        ref=Kernel(model,'REFERENCE',str(dll),budget);online=Kernel(model,'BOUNDED',str(dll),budget)
        write(out/'STARTUP.json',{'reference':ref.startup(home,budget),'bounded':online.startup(home,budget),'full_startup_wall_ms':(perf_counter()-t)*1000})
        queue=[{**p,'status':'NOT_RUN','eligible':None,'result_path':relative(out/'queue'/p['context_id']/'RESULT.json',out)}for p in manifest['planned_queue']]
        write(out/'QUEUE_REGISTRY.json',queue);ordinal=0
        for eid,displacement,seed in EPISODES:
            scenario=deepcopy(manifest['scenario']);scenario.update(seed=seed,initial_roll=scenario['initial_roll']-.002,initial_pitch=scenario['initial_pitch']+.002)
            episode=reference_sim.reference_episode(model,scenario,displacement,eid,TICKS,budget);write(out/'episodes'/(eid+'.json'),episode)
            snapshots={s['source_tick']:s for s in episode['snapshots']}
            for plan in manifest['planned_queue']:
                if plan['episode']!=eid:continue
                snapshot=snapshots.get(plan['tick'],{'snapshot_id':plan['snapshot_id'],'episode_id':eid,'source_tick':plan['tick'],
                    'direction':1 if displacement>0 else -1,'eligible':False,'eligibility_reason':'REFERENCE_INCOMPLETE'})
                c=source_context(snapshot,plan['health_kind'],mapping,ordinal,'ID');ordinal+=1
                c.update(backup_id='STEP31-'+c['context_id'],role=plan['role'],episode=eid,source_snapshot=plan['snapshot_id'],front_or_rear='front'if displacement>0 else'rear')
                directory=out/'queue'/c['context_id'];directory.mkdir(exist_ok=False);logical_event(out,'QUEUE_BEGIN',context_id=c['context_id'],ordinal=c['ordinal'])
                result={'context':c,'context_id':c['context_id'],'ordinal':c['ordinal'],'status':'SOURCE_INELIGIBLE','selected_sent':False,
                    'branches':{},'proposal_path':None,'online_path':None}
                if c['eligible']:
                    add_previous_command_identity(c,episode)
                    p=proposal(ref,c,bundle,budget);c['gap_m']=p['probe']['gap_m'];write(directory/'PROPOSAL_NUMERIC.json',p)
                    result['proposal_path']=relative(directory/'PROPOSAL_NUMERIC.json',out);result['probe']=p['probe']
                    packet=online.governor(c,bundle,c['gap_m'],'GOVERNOR_LOCAL',budget)
                    execute_triggered_packet(online,c,packet,budget,out,result)
                    result['status']='TRIGGERED'if result['selected_sent']else packet['status'];del packet,p
                write(directory/'RESULT.json',result)
                row={**plan,'status':result['status'],'eligible':bool(c['eligible']),'result_path':relative(directory/'RESULT.json',out)}
                queue[c['ordinal']]=row;write(out/'QUEUE_REGISTRY.json',queue);logical_event(out,'QUEUE_RETURN',context_id=c['context_id'],ordinal=c['ordinal'],status=result['status'])
                budget.persist(phase='QUEUE',processed=ordinal,last_context=c['context_id'])
                print(json.dumps({'processed':ordinal,'triggered':result['selected_sent'],'budget':budget.snapshot()}),flush=True);gc.collect()
    except SprintLimit as exc:
        status='INCOMPLETE_BUDGET';write(out/'INTERRUPTION.json',{'type':'BUDGET','error':str(exc),'budget':budget.snapshot()})
    except BaseException as exc:
        status='STOPPED_IMPLEMENTATION_OR_RESOURCE';write(out/'INTERRUPTION.json',{'type':type(exc).__name__,'error':str(exc),'traceback':traceback.format_exc(),'budget':budget.snapshot()});raise
    finally:
        budget.event('NUMERICAL_FINISHED',status=status,**budget.snapshot());budget.close()
        write(out/'RUN_FINISHED.json',{'run_id':run_id,'status':status,'budget':budget.snapshot(),'finish_utc':datetime.now(timezone.utc).isoformat()})
        print(json.dumps({'status':status,'budget':budget.snapshot()}),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('run_id',nargs='?',default=RUN_ID);run(p.parse_args().run_id)
