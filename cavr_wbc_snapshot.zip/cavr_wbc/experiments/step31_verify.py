"""One final STEP31 current-file and execution-identity closure.

This module never calls a model, optimizer, simulator, or historical replay.  It
reads this run's ledger/artifacts and the explicitly referenced frozen assets.
Scientific failures remain outcomes; missing/corrupted execution evidence does
not become a normal or successful return.
"""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path
import re

import numpy as np

from cavr_wbc.experiments.step30_io import ROOT, read, sha, write
from cavr_wbc.experiments.step26_features_storage import load_bank


PARENT = "dc9a2cdfc33e2abba2d581ac4cc3eed1456b5fde"
EPISODES = ("T31_P065", "T31_N065", "T31_P067", "T31_N067")
TICKS = (28, 31, 34, 37, 40)
EXTRA_BRANCHES = ("COUNTERFACTUAL_C", "COUNTERFACTUAL_B", "DELAY20")
BRANCHES = ("IMMEDIATE", *EXTRA_BRANCHES)
NOT_RUN_PREFIX = "NOT_RUN"


def _lines(path):
    with Path(path).open(encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, 1):
            if line.strip():
                try: yield json.loads(line)
                except json.JSONDecodeError as exc:
                    raise ValueError(f"malformed incremental ledger {path}:{line_number}") from exc


def _path(out, value, local=True):
    path = Path(value)
    if not path.is_absolute(): path = Path(out) / path
    path = path.resolve()
    if local and not path.is_relative_to(Path(out).resolve()):
        raise ValueError("new execution evidence must remain in this STEP31 output: " + str(path))
    return path


def _asset(out, asset):
    if isinstance(asset, str): return _path(out, asset), None
    if not isinstance(asset, dict) or not asset.get("path"):
        raise ValueError("explicit current artifact path required")
    return _path(out, asset["path"]), asset.get("sha256")


def _same(first, second, size=None):
    try:
        a = np.asarray(first, dtype=float); b = np.asarray(second, dtype=float)
        return bool(a.shape == b.shape and (size is None or a.shape == (size,))
                    and np.isfinite(a).all() and np.isfinite(b).all() and np.array_equal(a, b))
    except (TypeError, ValueError): return False


def _number(value):
    try: return float(value)
    except (TypeError, ValueError): return float("nan")


def _role(context, fallback=None):
    value = context.get("role", context.get("health_kind", fallback or ""))
    return str(value).lower().split("_")[0]


def _control_tau(control):
    return control.get("tau_sent", control.get("tau_cmd"))


def _numeric_entry(online, gamma):
    keys = (format(float(gamma), "g"), str(float(gamma)))
    entries = online.get("actions", {})
    return next((entries[key] for key in keys if key in entries), {})


def _memory_record(control):
    return control.get("integral_record", control.get("servo_response", {}).get("integral_record"))


def _first_match(branch, action, delay=False):
    controls = branch.get("controls", [])
    index = 1 if delay else 0
    return bool(len(controls) > index and _same(_control_tau(controls[index]), action.get("tau_sent"), 12))


def _memory_continuity(branch, online, gamma, delay=False):
    """Check recorded b0/b_after, not reconstructed or guessed controller state."""
    controls = branch.get("controls", [])
    feedback_begin = 2 if delay else 1
    records = [_memory_record(control) for control in controls[feedback_begin:]]
    records = [record for record in records if record is not None]
    expected_count = max(0, len(controls) - feedback_begin)
    if len(records) != expected_count: return False, "MISSING_RECORDED_FEEDBACK_MEMORY"
    if not records: return True, "NO_FEEDBACK_CALL_REACHED"
    first_expected = np.zeros(6)
    if gamma == 0. and not delay:
        response = online.get("B_response")
        if not isinstance(response, dict):
            backup = online.get("B", {})
            response = backup.get("response", backup)
        initial = response.get("integral_record", {}) if isinstance(response, dict) else {}
        if initial.get("b_after") is None: return False, "MISSING_PACKET_B_AFTER"
        first_expected = initial["b_after"]
    if not _same(records[0].get("b_used"), first_expected, 6): return False, "FIRST_FEEDBACK_MEMORY_MISMATCH"
    for previous, current in zip(records, records[1:]):
        if not _same(previous.get("b_after"), current.get("b_used"), 6): return False, "FEEDBACK_MEMORY_CHAIN_MISMATCH"
    return True, "RECORDED_B0_AND_MEMORY_CHAIN_IDENTICAL"


def _branch_check(out, context, online, branch_name, record, qp_owners, check, counts):
    context_id = context["context_id"]
    prefix = context_id + ":" + branch_name + ":"
    status = str(record.get("status", ""))
    if status.startswith(NOT_RUN_PREFIX):
        check(prefix + "explicit_not_run", bool(record.get("reason") or record.get("events")), status)
        counts[branch_name + "_NOT_RUN"] += 1
        return 0
    asset = record.get("artifact", record.get("actual_artifact"))
    path, digest = _asset(out, asset)
    check(prefix + "artifact_hash", digest is not None and path.is_file() and sha(path) == digest, str(path))
    branch = load_bank(path)
    controls_path = record.get("controls_path", record.get("pathcontrols"))
    if controls_path:
        serialized = read(_path(out, controls_path))
        full_controls = serialized.get("controls", serialized) if isinstance(serialized, dict) else serialized
        check(prefix + "full_controls_count", isinstance(full_controls, list) and len(full_controls) == len(branch["controls"]))
        if isinstance(full_controls, list): branch["controls"] = full_controls
    controls = branch.get("controls", [])
    physics = ([branch["initial_fact"]] if branch.get("initial_fact") is not None else []) + list(branch.get("physics_trajectory", []))
    steps = int(branch.get("counts", {}).get("physical_steps", -1))
    complete = branch.get("status") == "COMPLETE"
    check(prefix + "unfabricated_status", branch.get("status") == record.get("status"), branch.get("status"))
    check(prefix + "at_most_500_dense_steps", 0 <= steps <= 500, steps)
    check(prefix + "fixed_backup_anchor", _same(branch.get("fixed_anchor_q_init"), context.get("backup_anchor_q_init")), None)
    check(prefix + "sample_relative_time_grid", all("physics_step" in row and abs(_number(row.get("time_s")) - .002 * int(row["physics_step"])) <= 1e-9
                                                    for row in physics), None)
    if complete:
        check(prefix + "complete_501_states_50_controls", steps == 500 and len(physics) == 501 and len(controls) == 50
              and [row.get("physics_step") for row in physics] == list(range(501)))
        check(prefix + "control_slots_0_to_49", [row.get("slot") for row in controls] == list(range(50)))
        check(prefix + "control_time_sample_1s", all(abs(_number(row.get("time_s")) - .02 * index) <= 1e-9
                                                    for index, row in enumerate(controls)))
    gamma = float(online["selected_action"]["gamma"])
    action = online["selected_action"]
    if branch_name == "COUNTERFACTUAL_C":
        action = _numeric_entry(online, 1.).get("action", online.get("C", {})); gamma = 1.
    elif branch_name == "COUNTERFACTUAL_B":
        action = _numeric_entry(online, 0.).get("action", online.get("B", {})); gamma = 0.
    application_index = 1 if branch_name == "DELAY20" else 0
    if len(controls) <= application_index:
        check(prefix + "first_not_reached_recorded", bool(branch.get("reason")), branch.get("reason"))
    else:
        check(prefix + "exact_first_tau_from_packet", _first_match(branch, action, branch_name == "DELAY20"), None)
        claimed_first = record.get("first_command_matches", record.get("firstmatches"))
        if claimed_first is not None:
            check(prefix + "first_tau_claim_matches_facts", bool(claimed_first) == _first_match(branch, action, branch_name == "DELAY20"))
    memory, reason = _memory_continuity(branch, online, gamma, branch_name == "DELAY20")
    check(prefix + "independent_recorded_backup_memory", memory, reason)
    branch_id = branch.get("branch_id")
    new_qps = qp_owners.get(branch_id, 0)
    expected_qps = 48 if branch_name == "DELAY20" else 49
    check(prefix + "actual_feedback_QP_cap", new_qps <= expected_qps, {"observed": new_qps, "expected_complete": expected_qps})
    if "feedback_QP_calls" in branch.get("counts", {}):
        check(prefix + "feedback_call_header_matches_ledger", branch["counts"]["feedback_QP_calls"] == new_qps)
    if complete: check(prefix + "complete_feedback_QP_count", new_qps == expected_qps, new_qps)
    if branch_name == "DELAY20":
        events = record.get("events", {})
        if not isinstance(events, dict): events = {}
        evidence = {**branch, **events}
        check(prefix + "unchanged_sample_horizon", _number(evidence.get("horizon_s", evidence.get("horizon_from_sample_s"))) == 1.)
        check(prefix + "delayed_witness_not_current_certificate", _number(evidence.get("original_witness_time_s")) == 0.
              and _number(evidence.get("selected_application_time_s")) == .02)
        identity = evidence.get("previous_command_identity", evidence.get("first_previous_command_identity"))
        check(prefix + "previous_command_identity_recorded", bool(identity), identity)
        if controls:
            check(prefix + "prehold_type_not_new_solved", controls[0].get("action_source", controls[0].get("source")) == "LAST_COMMAND_HEALTH_CLIPPED")
            identity_record = context.get("previous_command_identity", {})
            identity_tau = identity_record.get("tau_sent") if isinstance(identity_record, dict) else None
            previous = context.get("previous_tau_sent", identity_tau if identity_tau is not None else context.get("state", {}).get("ctrl"))
            health = np.asarray(context["health_vector"], dtype=float)
            interface = action.get("capacity_interface", {})
            cap = np.asarray(interface.get("effective_capacity_nm", []), dtype=float)
            if cap.shape != (12,):
                limits = np.asarray(interface.get("healthy_torque_limits_nm", []), dtype=float); cap = health * limits
            check(prefix + "prehold_uniform_health_clip", cap.shape == (12,) and previous is not None
                  and _same(_control_tau(controls[0]), np.clip(np.asarray(previous, dtype=float), -cap, cap), 12))
    all_tick = bool(controls and all(_number(row.get("command_ready_ms", row.get("latency_ms"))) <= 20.
                                    and row.get("valid_command") is True for row in controls))
    claimed_tick = record.get("all_tick_deadline_pass", record.get("ticks", {}).get("all_within_20ms") if isinstance(record.get("ticks"), dict) else None)
    if claimed_tick is not None: check(prefix + "all_tick_claim_matches_facts", bool(claimed_tick) == all_tick)
    if not all_tick: counts[branch_name + "_tick_over_or_unavailable"] += 1
    counts[branch_name + "_" + str(branch.get("status"))] += 1
    counts["actual_banks"] += 1; counts["actual_bank_steps"] += steps
    return steps


def verify(out):
    out = Path(out).resolve()
    target = out / "FINAL_FILE_VERIFICATION.json"
    if target.exists(): raise FileExistsError("one final STEP31 current-file closure only")
    checks = {}; failures = []; counts = Counter()
    def check(name, condition, details=None):
        checks[name] = {"pass": bool(condition), "details": details}
        if not condition: failures.append(name)
    manifest = read(out / "MANIFEST.json")
    finished = read(out / "RUN_FINISHED.json"); budget = finished["budget"]
    check("source_commit_exact", manifest.get("source_commit", manifest.get("parent")) == PARENT)
    check("fixed_numerical_caps", budget["total_QP_calls"] <= 10000 and budget["total_physics_steps"] <= 120000
          and budget["numerical_elapsed_s"] <= 5400.)
    check("new_model_fits_zero", budget.get("multioutput_estimator_fits", budget.get("model_fits", -1)) == 0)
    code_hashes = manifest.get("frozen_code_hashes", {})
    check("frozen_model_and_decision_code_hashes_present", bool(code_hashes))
    for relative, digest in code_hashes.items():
        path = ROOT / relative if not Path(relative).is_absolute() else Path(relative)
        check("frozen_source:" + relative, path.is_file() and sha(path) == digest, str(path))
    assets = manifest.get("model_source_assets", {})
    check("frozen_model_assets_present", bool(assets))
    for name, asset in assets.items():
        if "path" in asset:
            check("frozen_model_asset:" + name, sha(asset["path"]) == asset["sha256"])
        else:
            for suffix in ("npz", "json"):
                check("frozen_model_asset:" + name + ":" + suffix,
                      Path(asset[suffix]).is_file() and sha(asset[suffix]) == asset[suffix + "_sha256"])
    local_identity = {}
    main_asset = assets.get("GEOMETRY_FULL_26")
    if main_asset:
        metadata = read(main_asset["json"])
        with np.load(main_asset["npz"], allow_pickle=False) as arrays:
            for group_id, group in metadata["groups"].items():
                prefix = group["array_prefix"]
                local_identity[group_id] = (arrays[prefix + "cal_snapshot_index"].copy(), arrays[prefix + "cal_episode_index"].copy())
    qp_starts = []; qp_returns = []; prefix_starts = []; prefix_returns = []; qp_owners = Counter()
    for row in _lines(out / "STEP31_LEDGER.jsonl"):
        event = row["event"]
        if event == "QP_START": qp_starts.append(row["global_qp_index"]); qp_owners[row.get("owner")] += 1
        elif event == "QP_RETURN":
            qp_returns.append(row["global_qp_index"])
            check("real_optimizer_call:" + str(row["global_qp_index"]), row.get("real_optimizer_called") is True)
            if row.get("kernel_variant") == "K_BUDGETED":
                check("bounded_solver_limit:" + str(row["global_qp_index"]), .001 <= row.get("osqp_time_limit_s", np.nan) <= .006)
        elif event == "PREFIX_NATIVE_START": prefix_starts.append(row)
        elif event == "PREFIX_NATIVE_RETURN": prefix_returns.append(row)
        elif "FIT" in str(event): check("no_fit_ledger_event:" + str(event), False)
    check("contiguous_real_QP_starts", qp_starts == list(range(1, budget["total_QP_calls"] + 1)))
    check("all_QP_returns_accounted", qp_returns == qp_starts and len(qp_returns) == budget["QP_returns"]
          and budget.get("unknown_native_returns", -1) == 0)
    check("native_reservations_return", [row["reservation_id"] for row in prefix_starts] == [row["reservation_id"] for row in prefix_returns]
          and budget.get("uncompleted_native_step_reservations", -1) == 0)
    native_steps = sum(int(row["actual_steps"]) for row in prefix_returns)
    check("native_prefix_ledger_steps", native_steps == budget["physics_by_kind"].get("PREFIX_PREDICTION", 0))
    counts["native_prefix_steps"] = native_steps
    native_path = manifest.get("native_dll_path")
    if native_path:
        check("frozen_native_DLL_hash", sha(_path(out, native_path, local=False)) == manifest["native_dll_sha256"])
    registry = read(out / "QUEUE_REGISTRY.json")
    if isinstance(registry, dict): registry = registry.get("entries", registry.get("queue"))
    check("44_planned_queue_rows", isinstance(registry, list) and len(registry) == 44)
    check("short_queue_identity_index", all(not any(key in row for key in ("context", "numeric", "actions", "predictions", "labels", "raw")) for row in registry))
    check("unique_queue_identities", len({row["context_id"] for row in registry}) == len(registry))
    check("queue_ordinals_exact", [row["ordinal"] for row in registry] == list(range(44)))
    planned = manifest.get("planned_queue")
    if planned:
        check("exact_predeclared_queue_order", [row["context_id"] for row in registry] == [row["context_id"] for row in planned])
    roles = Counter(row.get("role") for row in registry)
    check("40_injured_4_healthy_denominator", roles == {"thigh": 20, "calf": 20, "healthy": 4}, dict(roles))
    check("four_exact_new_episodes", set(row.get("episode") for row in registry) == set(EPISODES))
    fixed_pairs = set()
    for row in registry:
        match = re.search(r"(?:_T|:T)(\d+)", row.get("snapshot_id", row["context_id"]))
        tick = row.get("tick", int(match.group(1)) if match else None)
        fixed_pairs.add((row.get("episode"), tick, row.get("role")))
    expected_pairs = {(episode, tick, role) for episode in EPISODES for tick in TICKS for role in ("thigh", "calf")}
    expected_pairs |= {(episode, 34, "healthy") for episode in EPISODES}
    check("fixed_tick_role_plan_no_replacements", fixed_pairs == expected_pairs)
    logical = Counter(); online_events = Counter(); branch_starts = Counter(); branch_returns = Counter()
    for event in _lines(out / "EVENT_LEDGER.jsonl"):
        name = str(event.get("event", "")).upper(); logical[name] += 1
        if name in ("ONLINE", "ONLINE_RETURN", "ONLINE_RETURNED"): online_events[event.get("context_id")] += 1
        if name in ("BRANCH_BEGIN", "BRANCH_START"): branch_starts[(event.get("context_id"), event.get("branch"))] += 1
        if name in ("BRANCH_RETURN", "BRANCH_RETURNED"): branch_returns[(event.get("context_id"), event.get("branch"))] += 1
    for row in registry:
        context_id = row["context_id"]
        result_path = row.get("result_path")
        check(context_id + ":incremental_result_exists", bool(result_path) and _path(out, result_path).is_file(), result_path)
        if not result_path or not _path(out, result_path).is_file(): continue
        result = read(_path(out, result_path)); context = result["context"]
        check(context_id + ":result_identity", context["context_id"] == context_id and context.get("ordinal") == row["ordinal"])
        online_path = result.get("online_path")
        if not online_path:
            check(context_id + ":explicit_no_online", str(result.get("status", "")).startswith("NOT_RUN") or not context.get("eligible", True))
            continue
        online = read(_path(out, online_path))
        check(context_id + ":online_current_context_identity", online.get("context_id") == context_id)
        check(context_id + ":one_online_only", online_events[context_id] == 1, online_events[context_id])
        sent = bool(online.get("selected_command_sent"))
        check(context_id + ":sent_summary_matches_packet", bool(result.get("selected_sent")) == sent)
        for gamma_key, entry in online.get("actions", {}).items():
            action_entry = entry.get("action") or {}
            prefix_entry = entry.get("prefix") or {}
            if prefix_entry.get("complete"):
                numeric = prefix_entry.get("numeric") or {}
                check(context_id + ":saved_native_prefix:" + gamma_key,
                      np.asarray(numeric.get("qpos")).shape == (11, 19)
                      and np.asarray(numeric.get("qvel")).shape == (11, 18)
                      and _same(numeric.get("tau_sent"), action_entry.get("tau_sent"), 12))
                counts["online_saved_complete_prefixes"] += 1
            decision = (entry.get("decision") or {}).get("numeric") or {}
            if decision.get("calibration_gate") and local_identity:
                group_id = format(float(gamma_key), "g") + ":" + _role(context, row["role"])
                snapshots, episodes = local_identity[group_id]
                selected = np.asarray(decision.get("local_cal_indices"), dtype=np.int64)
                valid_indices = bool(selected.shape == (4,) and np.all(selected >= 0) and np.all(selected < len(snapshots)))
                check(context_id + ":frozen_local_CAL_identity:" + gamma_key,
                      valid_indices and len(set(snapshots[selected])) == 4 and len(set(episodes[selected])) >= 2)
                counts["online_local_CAL_identity_records"] += 1
        proposal_path = result.get("proposal_path")
        if proposal_path:
            proposal = read(_path(out, proposal_path)); probe = proposal.get("probe", proposal)
            check(context_id + ":proposal_before_actual_no_truth", probe.get("actual_labels_opened") is False
                  and bool(proposal.get("predictions_frozen_before_actual", proposal.get("selections_frozen_before_actual", True))))
        branches = result.get("branches", {})
        if not sent:
            check(context_id + ":rejected_late_never_propagated", all(str(branch.get("status", "")).startswith("NOT_RUN") for branch in branches.values()))
            counts["not_sent"] += 1
            continue
        counts["timely_sent"] += 1
        check(context_id + ":timely_recognized_sent", online.get("status") == "RECOGNIZED_SENT" and float(online.get("command_ready_ms", np.inf)) <= 20.)
        action = online.get("selected_action", {})
        try:
            raw = np.asarray(action.get("tau_raw"), dtype=float)
            sent_tau = np.asarray(action.get("tau_sent"), dtype=float)
            capacity = np.asarray(action.get("capacity_interface", {}).get("effective_capacity_nm"), dtype=float)
            check(context_id + ":packet_uniform_capacity_clip", raw.shape == sent_tau.shape == capacity.shape == (12,)
                  and np.isfinite(raw).all() and np.isfinite(capacity).all() and np.all(capacity >= 0.)
                  and _same(sent_tau, np.clip(raw, -capacity, capacity), 12))
            if 0. < float(action["gamma"]) < 1.:
                witness = action.get("source_primal_variables", {})
                blend = float(action["gamma"]) * np.asarray(witness.get("C"), dtype=float) + (1. - float(action["gamma"])) * np.asarray(witness.get("B"), dtype=float)
                check(context_id + ":sample_mixed_primal_witness", action.get("solver_status_val") is None
                      and action.get("hard_validation_pass") is True and action.get("sent_hard_check", {}).get("pass") is True
                      and _same(blend, action.get("z_raw"), 42))
        except (KeyError, ValueError, TypeError) as exc:
            check(context_id + ":packet_numeric_proof_readable", False, repr(exc))
        check(context_id + ":every_sent_IMMEDIATE_accounted", "IMMEDIATE" in branches)
        role = _role(context, row["role"]); gamma = float(online["selected_action"]["gamma"])
        middle = role != "healthy" and 0. < gamma < 1.
        if middle:
            counts["injured_middle_sent"] += 1
            check(context_id + ":every_middle_CF_and_DELAY_accounted", all(name in branches for name in EXTRA_BRANCHES))
        for name, branch in branches.items():
            check(context_id + ":known_branch:" + name, name in BRANCHES)
            if name in BRANCHES:
                try: _branch_check(out, context, online, name, branch, qp_owners, check, counts)
                except Exception as exc: check(context_id + ":branch_evidence_read:" + name, False, repr(exc))
                if not str(branch.get("status", "")).startswith("NOT_RUN"):
                    check(context_id + ":branch_event_pair:" + name, branch_starts[(context_id, name)] == branch_returns[(context_id, name)] == 1)
    reference_steps = 0
    for path in (out / "episodes").glob("*.json"):
        episode = read(path); reference_steps += int(episode.get("counts", {}).get("physical_steps", 0))
    counts["healthy_reference_steps"] = reference_steps
    check("all_new_integrations_reconcile", counts["actual_bank_steps"] + reference_steps + native_steps == budget["total_physics_steps"],
          {"actual": counts["actual_bank_steps"], "reference": reference_steps, "prefix": native_steps, "ledger": budget["total_physics_steps"]})
    files = [{"path": str(path.relative_to(out)).replace("\\", "/"), "bytes": path.stat().st_size, "sha256": sha(path)}
             for path in out.rglob("*") if path.is_file()]
    result = {"status": "PASS" if not failures else "FAIL", "failure_names": failures, "checks": checks,
              "counts": dict(counts), "event_counts": dict(logical), "files": files, "file_count": len(files),
              "new_model_fits": 0, "optimizer_or_physics_replay": False,
              "scope": "one final current STEP31 identity/file/execution closure; no historical audit"}
    write(target, result)
    print(json.dumps({"status": result["status"], "failures": failures, "counts": dict(counts), "files": len(files)}))
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(); parser.add_argument("out"); verify(parser.parse_args().out)
