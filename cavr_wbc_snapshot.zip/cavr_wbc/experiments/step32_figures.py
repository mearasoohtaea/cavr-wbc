"""Exactly two STEP32 figures from saved evidence only.

No solver, simulator, fit, or evaluator is imported. Missing ACTUAL endpoints
remain missing; DEV diagnostic propagation is never relabeled as TEST evidence.
"""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from PIL import Image

from cavr_wbc.experiments.step26_features_storage import load_bank
from cavr_wbc.experiments.step32_report import read, resolve

SKILL = Path("C:/Users/ZhuanZ（无密码）/.codex/skills/scipilot-figure")
sys.path.insert(0, str(SKILL / "scripts"))
from profile_data import profile_data, render_report
from setup_style import setup_style
from layout_tools import finalize_figure, add_panel_labels
from visual_qa import render_preview, audit_layout
from export_figure import export_figure
from check_figure import check_figure

METHODS = ("STALE_RECAL", "ALIGNED_RECAL")
METHOD_LABELS = {"STALE_RECAL": "STALE", "ALIGNED_RECAL": "ALIGNED"}
COLORS = {"STALE_RECAL": "#0072B2", "ALIGNED_RECAL": "#D55E00"}
GAMMAS = (.75, .5, .25)
GAMMA_COLORS = {.75: "#0072B2", .5: "#D55E00", .25: "#009E73"}
GAMMA_STYLES = {.75: "-", .5: "--", .25: ":"}
INVALID = "Scientific comparison INVALID: added whole-group missing-feature gate"


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str,
                               allow_nan=False) + "\n", encoding="utf-8")


def finite(value):
    return value is not None and np.isfinite(value)


def load_points(out):
    """Read all current-run records, including every missing middle branch."""
    queue = read(out / "QUEUE_RESULTS.json")
    assert len(queue) == 72 and len({r["context_id"] for r in queue}) == 36
    assert Counter(r["method"] for r in queue) == Counter({m: 36 for m in METHODS})
    dev = []
    curves = {}
    for item in read(out / "DEV_REGISTRY.json"):
        if item["gamma"] not in GAMMAS or "HEALTHY" in item["context_id"]:
            continue
        cal = read(resolve(out, item["path"]))
        branch = read(resolve(out, item["branch_result"])) if item["branch_result"] else {}
        label = branch.get("label") or {}
        row = {
            "id": item["id"], "context_id": item["context_id"],
            "source_snapshot": item["source_snapshot"], "episode": item["episode"],
            "split": "DEV", "method": item["method"], "gamma": item["gamma"],
            "role": cal.get("role", cal.get("context", {}).get("role")),
            "status": item["status"], "complete": bool(item["complete"]),
            "physical_pass": label.get("original_physical"),
            "terminal_pass": label.get("original_terminal"),
            "all_tick_deadline_pass": branch.get("all_tick_deadline_pass"),
            "progress0_04_m": branch.get("progress0_04_m"),
            "progress02_04_m": branch.get("progress02_04_m"),
            "D_m": label.get("D_m"), "cal_record": item["path"],
            "branch_result": item["branch_result"],
            "artifact": (branch.get("artifact") or {}).get("path"),
        }
        artifact = branch.get("artifact")
        if artifact:
            raw = load_bank(resolve(out, artifact["path"]))
            facts = ([raw["initial_fact"]] if raw.get("initial_fact") else []) + raw.get("physics_trajectory", [])
            # Read observed states only: never pad, extrapolate, or smooth.
            observed = [f for f in facts if "qpos" in f and "time_s" in f and
                        not f.get("numerical_failure")]
            time = np.array([f["time_s"] for f in observed], dtype=float)
            qx = np.array([f["qpos"][0] for f in observed], dtype=float)
            anchor = float(raw["fixed_anchor_q_init"][0])
            direction = float(raw["original_direction"])
            curves[item["id"]] = (time, direction * (qx - anchor) * 1000.)
            row["observed_states"] = len(observed)
            row["last_observed_s"] = float(time[-1]) if len(time) else None
        else:
            row.update(observed_states=0, last_observed_s=None)
        dev.append(row)
    assert len(dev) == 96 and len({r["context_id"] for r in dev}) == 16
    return queue, dev, curves


def profile(out, queue, dev):
    destination = out / "figures"
    qfields = ("ordinal", "context_id", "method", "role", "injured", "online_status",
               "command_ready_ms", "status", "executed", "D_m", "progress02_04_m")
    qdf = pd.DataFrame([{k: row.get(k) for k in qfields} for row in queue])
    ddf = pd.DataFrame(dev)
    qdf.to_csv(destination / "FIGURE1_POINT_DATA.csv", index=False)
    ddf.to_csv(destination / "FIGURE2_DEV_POINT_DATA.csv", index=False)
    injured = [r for r in queue if r["injured"]]
    pd.DataFrame([{k: r.get(k) for k in ("ordinal", "context_id", "method", "eligible",
                  "injured_middle_event", "online_status", "status")} for r in injured]).to_csv(
        destination / "FIGURE2_TEST_QUALIFICATION_DATA.csv", index=False)
    profiles = {"TEST": profile_data(qdf, group_cols=["method", "role"]),
                "DEV_middle": profile_data(ddf, group_cols=["method", "gamma"])}
    write_json(destination / "DATA_PROFILE.json", profiles)
    (destination / "DATA_PROFILE.md").write_text(
        "# STEP32 saved-data profile\n\n" + render_report(profiles["TEST"]) + "\n\n" +
        render_report(profiles["DEV_middle"]) +
        "\n\nOrdinal is a fixed display identifier, not a continuous scientific predictor. "
        "Repeated gammas and paired methods are not independent repeats. Missing endpoints "
        "are NOT_RUN, not zero displacement. No fitting or inferential statistics are used.\n",
        encoding="utf-8")
    plan = {
        "skill": "scipilot-figure-skill", "journal": "IEEE T-RO", "width_inches": 7.16,
        "exactly_two_figures": True,
        "scientific_classification": "INVALID_PROTOCOL_CALIBRATION_GATE",
        "invalid_reason": "Added whole-group missing-feature gate exceeded protocol LOCAL nearest rules.",
        "figure1": {"chosen": "All-input categorical status strip + paired raw timing points + explicit empty ACTUAL endpoint panel",
                    "reason": "Every queued input and missing endpoint remains visible; observed decision time is not execution success.",
                    "alternatives": ["Paired endpoint scatter: impossible because no ACTUAL endpoints exist.",
                                     "Aggregate success bars: obscure the 36 paired input identities and unavailable endpoints."]},
        "figure2": {"chosen": "All 32 injured TEST qualification strip + all 96 DEV middle status cells + all observed DEV progress/trajectories",
                    "reason": "Separates the empty TEST event population from saved DEV diagnostics, retaining deadline failures and NOT_RUN denominators.",
                    "alternatives": ["TEST middle trajectory panel: empty and cannot be synthesized.",
                                     "Successful-only representative traces: omit the required failures and planned denominator."]},
        "anti_pitfalls": ["No fake endpoint zeros", "No cherry-picked trajectories", "No fitted curves or mean bars",
                          "No inferential confidence intervals", "No dual axes", "No categorical connecting lines"],
        "new_QP_calls": 0, "new_physics_steps": 0, "new_fits": 0,
    }
    write_json(destination / "FIGURE_PLAN.json", plan)


def style():
    setup_style(journal="ieee", lang="en", use_sciplots=False)
    plt.rcParams.update({"font.size": 8, "axes.labelsize": 8, "axes.titlesize": 8.5,
                         "xtick.labelsize": 7.5, "ytick.labelsize": 7.5,
                         "legend.fontsize": 7.5, "savefig.bbox": None})


def figure1(queue):
    size = (7.16, 4.55)
    fig = plt.figure(figsize=size, constrained_layout=True)
    gs = fig.add_gridspec(2, 2, height_ratios=(1, 1.35), width_ratios=(1.35, 1))
    status = fig.add_subplot(gs[0, :]); timing = fig.add_subplot(gs[1, 0]); endpoints = fig.add_subplot(gs[1, 1])
    fig.suptitle("STEP32: all fixed-queue paired decisions\n" + INVALID, fontsize=9)
    unique = {r["ordinal"]: r for r in queue if r["method"] == METHODS[0]}
    for j, method in enumerate(METHODS):
        rows = sorted([r for r in queue if r["method"] == method], key=lambda r: r["ordinal"])
        x = np.array([r["ordinal"] + 1 for r in rows])
        for y, key, wanted, marker in ((3-j, "online_status", "ABSTAIN", "x"),
                                      (1-j, "status", "NOT_RUN", "|")):
            match = np.array([r[key] == wanted for r in rows])
            status.scatter(x[match], np.full(sum(match), y), color=COLORS[method],
                           marker=marker, s=24, linewidths=.8)
            status.scatter(x[~match], np.full(sum(~match), y), color="black", marker="o", s=24)
        timing.scatter(x, [r["command_ready_ms"] for r in rows], s=18, marker=("o", "s")[j],
                       facecolors="none", edgecolors=COLORS[method], linewidths=.8, label=METHOD_LABELS[method])
    for ax in (status, timing):
        for border in (9.5, 18.5, 27.5):
            ax.axvline(border, color=".85", linewidth=.6, zorder=0)
        ax.set_xlim(.3, 36.7); ax.set_xticks([1, 9, 18, 27, 36])
        ax.set_xlabel("Fixed TEST input ordinal (1–36; paired methods)")
    status.set_yticks([3, 2, 1, 0], ["STALE: ABSTAIN", "ALIGNED: ABSTAIN", "STALE: ACTUAL NOT_RUN", "ALIGNED: ACTUAL NOT_RUN"])
    status.set_ylim(-.45, 3.55)
    status.set_title("All 36 inputs / method: no command sent, no ACTUAL endpoint")
    timing.axhline(20, color=".2", linewidth=.8, linestyle="--")
    timing.text(1, 20.5, "20 ms decision deadline", fontsize=7.5)
    timing.set(ylim=(0, 22), ylabel="Command-ready elapsed time (ms)", title="72 observed decision timings")
    timing.legend(loc="upper right", frameon=False, ncol=2, bbox_to_anchor=(1., .85))
    endpoints.set(xlim=(0, 1), ylim=(0, 1), title="ACTUAL endpoints / failure evaluation")
    endpoints.set_xticks([]); endpoints.set_yticks([])
    endpoints.text(.5, .82, "No ACTUAL trajectory exists", ha="center", fontsize=9)
    endpoints.text(.5, .57, "STALE: 0/36 executed; 36 NOT_RUN\nALIGNED: 0/36 executed; 36 NOT_RUN",
                   ha="center", va="center", linespacing=1.5, fontsize=8)
    endpoints.text(.5, .27, "D and terminal Y unavailable\nPhysical / terminal outcomes not observed\nTimely decisions ≠ safe execution",
                   ha="center", va="center", linespacing=1.45, fontsize=8)
    axes = [status, timing, endpoints]
    finalize_figure(fig); add_panel_labels(fig, axes=axes, style="ieee", fontsize=9, x_offset_pt=-12)
    return fig, size


def dev_symbol(row):
    if row["status"] == "NOT_RUN":
        return "x", ".65", 16
    if not row["complete"] or not row["physical_pass"] or not row["terminal_pass"]:
        return "X", "#111111", 24
    if not row["all_tick_deadline_pass"]:
        return "^", "#111111", 24
    return "o", "#111111", 20


def figure2(queue, dev, curves):
    size = (7.16, 6.25)
    fig = plt.figure(figsize=size, constrained_layout=True)
    gs = fig.add_gridspec(3, 2, height_ratios=(.55, 1.65, 1.3), width_ratios=(1.05, 1))
    test = fig.add_subplot(gs[0, :]); cells = fig.add_subplot(gs[1, 0]); progress = fig.add_subplot(gs[1, 1])
    traces = [fig.add_subplot(gs[2, j]) for j in range(2)]
    fig.suptitle("STEP32: empty TEST middle population and all DEV diagnostics\n" + INVALID, fontsize=9)
    injured = sorted({r["ordinal"]: r for r in queue if r["injured"]}.values(), key=lambda r: r["ordinal"])
    assert len(injured) == 32
    for j, method in enumerate(METHODS):
        rows = {r["context_id"]: r for r in queue if r["injured"] and r["method"] == method}
        event = np.array([bool(rows[r["context_id"]]["injured_middle_event"]) for r in injured])
        test.scatter(np.arange(1, 33)[~event], np.full(sum(~event), 1-j), marker="x",
                     s=17, linewidths=.75, color=COLORS[method])
        test.scatter(np.arange(1, 33)[event], np.full(sum(event), 1-j), marker="o", s=17, color=COLORS[method])
    test.set(xlim=(.3, 32.7), ylim=(-.35, 1.35), xlabel="All 32 injured TEST inputs (ordinal mapping saved with figure)",
             title="TEST: 32/32 eligible per method; 0 sent middle actions; 0 ACTUAL middle trajectories")
    test.set_xticks([1, 8, 16, 24, 32]); test.set_yticks([1, 0], ["STALE: empty", "ALIGNED: empty"])
    contexts = list(dict.fromkeys(r["context_id"] for r in dev))
    index = {c: i for i, c in enumerate(contexts)}
    for row in dev:
        j = METHODS.index(row["method"]); k = GAMMAS.index(row["gamma"])
        marker, color, area = dev_symbol(row)
        cells.scatter([3*j+k], [index[row["context_id"]]], marker=marker, color=color, s=area, linewidths=.7)
        if finite(row["progress02_04_m"]):
            # Deterministic offsets separate identities without changing values.
            offset = (index[row["context_id"]] - 7.5) * .008
            px = row["gamma"] + (-.037 if j == 0 else .037) + offset
            progress.scatter(px, row["progress02_04_m"]*1000., marker=("o", "s")[j],
                             edgecolors=COLORS[row["method"]], facecolors="none", s=24, linewidths=.8)
            if not row["all_tick_deadline_pass"]:
                progress.scatter(px, row["progress02_04_m"]*1000., marker="x", color="black", s=12, linewidths=.65)
    short = [f"{c.split('_')[1]} / {c.split('_')[2][1:]} " +
             ("T" if "THIGH" in c else "C") for c in contexts]
    cells.set(xlim=(-.5, 5.5), ylim=(15.5, -.5), title="DEV only: all 96 planned middle branches")
    cells.set_xticks(range(6), [".75", ".50", ".25", ".75", ".50", ".25"])
    cells.set_yticks(range(16), short); cells.tick_params(axis="y", labelsize=7)
    cells.set_xlabel("STALE γ                         ALIGNED γ")
    cells.axvline(2.5, color=".8", linewidth=.7)
    for k in range(15):
        cells.axhline(k+.5, color=".93", linewidth=.4, zorder=0)
    progress.set(xlim=(.08, .93), xticks=[.25, .5, .75], xlabel="DEV middle γ (display offsets only)",
                 ylabel="Observed progress, 0.02–0.04 s (mm)", title="DEV only: all 21 observed progress values")
    progress.text(.04, .97, "21/96 propagated; 75 NOT_RUN\n15/21 feedback deadline failures\nCross = at least one tick >20 ms", transform=progress.transAxes,
                  va="top", fontsize=7.5, linespacing=1.35)
    progress.set_ylim(0, max(r["progress02_04_m"]*1000. for r in dev if finite(r["progress02_04_m"]))*1.55)
    progress.legend(handles=[Line2D([], [], marker=("o", "s")[j], color=COLORS[m], markerfacecolor="none", linestyle="none", label=METHOD_LABELS[m])
                              for j, m in enumerate(METHODS)], frameon=False, loc="lower right", ncol=2)
    all_y = [p[1] for p in curves.values() if len(p[1])]
    ymin = min(0., min(np.min(y) for y in all_y)); ymax = max(np.max(y) for y in all_y)
    pad = max(.3, (ymax-ymin)*.08)
    for ax, method in zip(traces, METHODS):
        count = 0
        for row in dev:
            if row["method"] != method or row["id"] not in curves:
                continue
            time, displacement = curves[row["id"]]; gamma = row["gamma"]
            ax.plot(time, displacement, color=GAMMA_COLORS[gamma], linestyle=GAMMA_STYLES[gamma],
                    linewidth=.85, alpha=.78)
            if len(time):
                marker = "o" if row["all_tick_deadline_pass"] else "x"
                ax.scatter(time[-1], displacement[-1], marker=marker, color="black", s=14, linewidths=.7)
            count += 1
        unavailable = sum(r["method"] == method and r["status"] == "NOT_RUN" for r in dev)
        ax.axvline(.02, color=".55", linestyle=":", linewidth=.7)
        ax.axhline(0, color=".75", linewidth=.6)
        ax.set(xlim=(0, 1.04), ylim=(ymin-pad, ymax+pad), xlabel="Time from original sample (s)",
               ylabel="Directional displacement (mm)", title=f"DEV {METHOD_LABELS[method]}: {count}/48 curves; {unavailable} NOT_RUN")
        ax.set_xticks([0, .25, .5, .75, 1.])
        ax.text(.97, .96, "Dotted vertical: prehold end (0.02 s)", transform=ax.transAxes,
                ha="right", va="top", fontsize=7.5)
    handles = [Line2D([], [], color=GAMMA_COLORS[g], linestyle=GAMMA_STYLES[g], label=f"γ = {g:g}") for g in GAMMAS]
    handles += [Line2D([], [], color="black", marker="^", linestyle="none", label="Complete; >20 ms tick"),
                Line2D([], [], color="black", marker="o", linestyle="none", label="Complete; all ticks ≤20 ms"),
                Line2D([], [], color=".65", marker="x", linestyle="none", label="NOT_RUN")]
    fig.legend(handles=handles, loc="outside lower center", ncol=3, frameon=False)
    axes = [test, cells, progress, *traces]
    finalize_figure(fig); add_panel_labels(fig, axes=axes, style="ieee", fontsize=9,
                                          x_offset_pt=-12, y_offset_pt=5)
    return fig, size


def gray(source, destination, dpi):
    # Use exact saved figure pixels for the proof. SciPilot's optional grayscale
    # helper re-saves the main PNG with a tight bbox, losing its exact dimensions.
    with Image.open(source) as img:
        img.convert("L").save(destination, dpi=(dpi, dpi))


def embedded_pdf_fonts(path):
    """Check descendant font descriptors missed by the generic helper."""
    from pypdf import PdfReader
    fonts = []
    for page in PdfReader(str(path)).pages:
        for value in page["/Resources"].get("/Font", {}).values():
            obj = value.get_object()
            descendants = obj.get("/DescendantFonts", [obj])
            for descendant in descendants:
                font = descendant.get_object()
                descriptor = font.get("/FontDescriptor")
                descriptor = descriptor.get_object() if descriptor else {}
                fonts.append({"subtype": str(font.get("/Subtype")), "basefont": str(font.get("/BaseFont")),
                              "embedded": any(k in descriptor for k in ("/FontFile", "/FontFile2", "/FontFile3"))})
    return {"fonts": fonts, "all_embedded_no_type3": bool(fonts) and all(f["embedded"] and f["subtype"] != "/Type3" for f in fonts)}


def figures(out, finalize=False):
    out = Path(out).resolve(); destination = out / "figures"; destination.mkdir(exist_ok=True)
    queue, dev, curves = load_points(out)
    profile(out, queue, dev)
    style()
    specs = (("STEP32_paired_queue", figure1, (queue,)),
             ("STEP32_middle_diagnostics", figure2, (queue, dev, curves)))
    qa = {"skill": "scipilot-figure-skill", "phase": "FINAL" if finalize else "PREVIEW",
          "scientific_classification": "INVALID_PROTOCOL_CALIBRATION_GATE", "invalid_annotation": INVALID,
          "new_QP_calls": 0, "new_physics_steps": 0, "new_fits": 0,
          "exactly_two_logical_figures": True, "TEST_rows": 72, "TEST_injured_contexts": 32,
          "TEST_middle_actual_curves": 0, "DEV_middle_planned": 96, "DEV_observed_curves": len(curves),
          "DEV_NOT_RUN": sum(r["status"] == "NOT_RUN" for r in dev),
          "DEV_observed_deadline_failures": sum(r["status"] != "NOT_RUN" and not r["all_tick_deadline_pass"] for r in dev),
          "endpoint_missing_not_imputed": True, "no_inferential_statistics": True, "figures": {}}
    if finalize:
        review = read(destination / "VISUAL_REVIEW.json")
        if not review or not review.get("PASS"):
            raise RuntimeError("Preview color/grayscale visual review required before final export.")
        qa["visual_review"] = review
    for name, build, args in specs:
        fig, size = build(*args)
        preview = destination / (name + "_preview.png")
        render_preview(fig, str(preview), dpi=150)
        gray(preview, destination / (name + "_preview_grayscale.png"), 150)
        layout = audit_layout(fig)
        info = {"layout_issues": layout, "size_inches": size, "preview_dpi": 150}
        if any(issue[0] == "FAIL" for issue in layout):
            raise RuntimeError("Figure layout FAIL: " + str(layout))
        if finalize:
            paths = export_figure(fig, str(destination / name), formats=["pdf", "svg", "png"],
                                  dpi=600, size_inches=size, grayscale_preview=False, tight=False)
            gray(destination / (name+".png"), destination / (name+"_grayscale.png"), 600)
            paths.append(str(destination / (name+"_grayscale.png")))
            info["file_checks"] = {Path(path).name: check_figure(path, min_dpi=600, target_inches=size) for path in paths}
            info["pdf_descendant_font_check"] = embedded_pdf_fonts(destination / (name+".pdf"))
            if not info["pdf_descendant_font_check"]["all_embedded_no_type3"]:
                raise RuntimeError("Embedded PDF font check failed.")
            if any(level == "FAIL" for issues, _ in info["file_checks"].values() for level, _ in issues):
                raise RuntimeError("Publication file check failed.")
        qa["figures"][name] = info
        plt.close(fig)
    write_json(destination / "FIGURE_QA.json", qa)
    print(json.dumps(qa, ensure_ascii=False, default=str))
    return qa


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--finalize", action="store_true")
    args = parser.parse_args()
    figures(args.output, args.finalize)
