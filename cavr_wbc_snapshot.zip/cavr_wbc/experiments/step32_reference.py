"""Unchanged healthy reference recipe with the mandatory 6 ms resident solver.

The original reference helper's module binding is restored even on exception.
This process is single-threaded; no old source file or historical data is edited.
"""
from cavr_wbc.experiments import step26_sim as source
from cavr_wbc.control.step27_resident_kernel import ResidentWBC


def reference_episode(model, scenario, displacement, episode_id, ticks, budget):
    original_factory = source.Step22WBC

    def bounded_factory(model, solve_callback=None):
        return ResidentWBC(model, solve_callback=solve_callback, variant='K_BUDGETED')

    source.Step22WBC = bounded_factory
    try:
        result = source.reference_episode(model, scenario, displacement, episode_id, ticks, budget)
    finally:
        source.Step22WBC = original_factory
    result['reference_solver_variant'] = 'K_BUDGETED'
    result['max_single_QP_time_s'] = .006
    result['original_recipe_unchanged'] = True
    return result
