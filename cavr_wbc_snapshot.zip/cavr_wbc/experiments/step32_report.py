"""Saved-only STEP32 paired application-time analysis; no numerical execution."""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
import json
import math
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
RUN_ID = 'step32-application-time-20261009-01'
METHODS = ('STALE_RECAL', 'ALIGNED_RECAL')
MIDDLE = (.75, .5, .25)
BRANCHES = ('ACTUAL', 'COUNTERFACTUAL_C', 'COUNTERFACTUAL_B')
FAILURE_FIELDS = ('physical_failure', 'local_failure', 'terminal_failure', 'command_failure',
                  'numerical_incomplete', 'deadline_failure', 'application_identity_failure')


def finite(value):
    return isinstance(value, (int, float, np.integer, np.floating)) and not isinstance(value, (bool, np.bool_)) and math.isfinite(float(value))


def _restore(value):
    if isinstance(value, dict):
        if set(value) == {'nonfinite'}:
            return float(value['nonfinite'])
        return {key: _restore(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_restore(item) for item in value]
    return value


def _encode(value):
    if isinstance(value, np.ndarray):
        return _encode(value.tolist())
    if isinstance(value, np.generic):
        return _encode(value.item())
    if isinstance(value, float) and not math.isfinite(value):
        return {'nonfinite': repr(value)}
    if isinstance(value, dict):
        return {str(key): _encode(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_encode(item) for item in value]
    return value


def read(path, default=None):
    path = Path(path)
    return _restore(json.loads(path.read_text(encoding='utf-8'))) if path.exists() else default


def write(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    pending = path.with_name(path.name + '.step32-report.pending')
    pending.write_text(json.dumps(_encode(value), ensure_ascii=False, allow_nan=False, separators=(',', ':')) + '\n', encoding='utf-8', newline='\n')
    pending.replace(path)


def resolve(out, path):
    value = Path(path)
    return value if value.is_absolute() else Path(out) / value


def jsonl_rows(path):
    path = Path(path)
    if path.exists():
        with path.open(encoding='utf-8') as stream:
            for line in stream:
                if line.strip():
                    yield _restore(json.loads(line))


def csv_write(path, rows):
    rows = list(rows); path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with path.open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields); writer.writeheader()
        for row in rows:
            writer.writerow({key: json.dumps(_encode(value), ensure_ascii=False) if isinstance(value, (dict, list, tuple, np.ndarray)) else value for key, value in row.items()})


def numeric_record(path):
    """Restore saved numeric witnesses only; sparse problems remain mappings."""
    path = Path(path)
    document = read(path, {})
    if not document or not document.get('numeric_npz'):
        return {}
    with np.load(resolve(path.parent, document['numeric_npz']), allow_pickle=False) as archive:
        def restore(item):
            if isinstance(item, dict) and 'npz_key' in item:
                return archive[item['npz_key']].copy()
            if isinstance(item, dict):
                return {key: restore(value) for key, value in item.items()}
            if isinstance(item, list):
                return [restore(value) for value in item]
            return item
        return restore(document.get('record', {}))


def statistics(values):
    values = list(values); a = np.asarray([float(value) for value in values if finite(value)])
    return {'recorded': len(values), 'finite': len(a), 'missing_or_nonfinite': len(values) - len(a),
            **{name: float(np.percentile(a, percentile)) if len(a) else None for name, percentile in (('p50', 50), ('p95', 95), ('p99', 99))},
            'min': float(a.min()) if len(a) else None, 'max': float(a.max()) if len(a) else None}


def _fixed_plans():
    """Fallback preserves the full predeclared denominator after interruption."""
    gaps = {29: .004, 33: .0045, 35: .005, 37: .005, 41: .006}
    result = []
    for episode in ('T32_P063', 'T32_N063', 'T32_P069', 'T32_N069'):
        for tick in (29, 33, 35, 37, 41):
            for kind in (('HEALTHY',) if tick == 35 else ('THIGH_15', 'CALF_15')):
                result.append({'context_id': episode + f'_T{tick:03d}_' + kind, 'ordinal': len(result),
                    'episode': episode, 'snapshot_id': episode + f'_T{tick:03d}', 'tick': tick,
                    'role': kind.split('_')[0].lower(), 'health_kind': kind,
                    'direction': 1 if '_P' in episode else -1, 'gap_m': gaps[tick], 'split': 'TEST'})
    return result


def safe(label, gap):
    return bool(label.get('complete') and label.get('full_501_grid') is True and
                label.get('original_physical_safe') and label.get('terminal_pass') and label.get('command_valid_all') and
                finite(label.get('D')) and finite(gap) and 0. <= label['D'] <= gap)


def capacity_event(events):
    events = events or {}
    return bool(events.get('first_capacity_event') or events.get('first_active_indices') or
                events.get('any_actual_capacity99_event') or any(int(value) > 0 for value in events.get('capacity99_count_by_channel', [])))


def branch_facts(record, gap):
    record = record or {}; label = record.get('label') or {}; ticks = record.get('tick_latency_ms') or []
    status = record.get('status', 'NOT_RUN')
    counts = record.get('counts') or {}
    executed = bool(status != 'NOT_RUN' and (record.get('artifact') or ticks or counts.get('physical_steps', 0) or
                                           status in ('COMPLETE', 'FAILED_NUMERICAL', 'FAILED_BUDGET')))
    complete = bool(label.get('complete') and label.get('full_501_grid') is True)
    tick_pass = bool(complete and len(ticks) == 50 and all(finite(value) and 0. <= value <= 20. for value in ticks)
                     and record.get('all_tick_deadline_pass') is True)
    first_match = record.get('first_tau_matches_packet')
    identity = record.get('application_identity_pass')
    physical_failure = bool(executed and (label.get('original_failure') or label.get('observed_original_physical_failure') or
                                         (complete and not label.get('original_physical_safe'))))
    local_failure = bool(complete and finite(label.get('D')) and finite(gap) and label['D'] > gap)
    terminal_failure = bool(complete and not label.get('terminal_pass'))
    actual_safe = safe(label, gap)
    confirmed = bool(actual_safe and tick_pass and identity is True and first_match is True and
                     record.get('actual_horizon_origin') == 'SAMPLE' and record.get('actual_horizon_s') == 1.)
    return {'status': status, 'executed': executed, 'complete_501': complete,
        'physical_pass': bool(complete and label.get('original_physical_safe')), 'terminal_pass': bool(complete and label.get('terminal_pass')),
        'local_pass': bool(complete and finite(label.get('D')) and finite(gap) and 0. <= label['D'] <= gap),
        'actual_safe_at_fixed_gap': actual_safe, 'full_50_ticks_20ms': tick_pass, 'execution_confirmed': confirmed,
        'physical_failure': physical_failure, 'local_failure': local_failure, 'terminal_failure': terminal_failure,
        'command_failure': bool(complete and not label.get('command_valid_all')),
        'numerical_incomplete': bool(executed and not complete),
        'deadline_failure': bool(executed and (any(finite(value) and value > 20. for value in ticks) or
                                             (complete and not tick_pass))),
        'application_identity_pass': identity, 'application_identity_failure': bool(executed and identity is False),
        'first_tau_matches_packet': first_match,
        'observed_unsafe': bool(physical_failure or local_failure or terminal_failure),
        'known_complete_failure': bool(complete and (not actual_safe or not tick_pass or identity is not True or first_match is not True)),
        'late_ticks': sum(finite(value) and value > 20. for value in ticks), 'missing_or_nonfinite_ticks': sum(not finite(value) for value in ticks),
        'D_m': label.get('D'), 'Y': label.get('Y'), 'progress0_04_m': record.get('progress0_04_m'),
        'progress02_04_m': record.get('progress02_04_m'), 'tick_latency_ms': ticks,
        'capacity99_event': capacity_event(record.get('events')), 'first_packet_capacity99_event': bool((record.get('events') or {}).get('first_capacity_event')),
        'events': record.get('events'), 'counts': counts, 'artifact': record.get('artifact'),
        'controls_path': record.get('controls_path'), 'result_path': record.get('result_path'),
        'application_state_comparison': record.get('application_state_comparison'), 'reason': record.get('reason')}


def _shadow_endpoint(item, summary, context, limits):
    item = item or {}; summary = summary or {}
    status = item.get('status', summary.get('status', 'NOT_RUN'))
    tau = np.asarray(item.get('tau_shadow_raw', []), dtype=float)
    health = np.asarray(context.get('health_vector', []), dtype=float)
    limits = np.asarray(limits, dtype=float)
    changed_value = item.get('changed_channel_indices', summary.get('changed_channel_indices', []))
    rows_value = item.get('changed_row_indices', summary.get('changed_row_indices', []))
    changed = np.asarray([] if changed_value is None else changed_value, dtype=np.int64)
    rows = np.asarray([] if rows_value is None else rows_value, dtype=np.int64)
    z = np.asarray(item.get('z_shadow', []), dtype=float)
    dimensions = bool(tau.shape == health.shape == limits.shape == (12,) and np.isfinite(tau).all() and
                      np.isfinite(health).all() and np.isfinite(limits).all() and changed.ndim == 1 and rows.ndim == 1 and
                      len(changed) > 0 and len(changed) == len(rows) and np.all((changed >= 0) & (changed < 12)))
    violation = roundoff = None
    substantive = original_row_violation = False
    if dimensions:
        capacity = health * limits
        violation = np.maximum(np.abs(tau) - capacity, 0.)
        roundoff = 100. * np.finfo(float).eps * np.maximum.reduce([np.ones(12), np.abs(limits), np.abs(tau)])
        substantive = bool(np.any(violation[changed] > roundoff[changed]))
        row_pass = np.asarray((item.get('original_rows_check') or {}).get('row_pass', []), dtype=bool)
        original_row_violation = bool(len(rows) and row_pass.ndim == 1 and np.all((rows >= 0) & (rows < len(row_pass))) and np.any(~row_pass[rows]))
    strict = bool(item.get('strict_solved_finite', summary.get('strict_solved_finite')) is True and
                  item.get('solver_status_val', summary.get('solver_status_val')) == 1 and z.ndim == 1 and len(z) and np.isfinite(z).all())
    bounded = bool(item.get('original_bounded_feasible', summary.get('original_bounded_feasible')) is True)
    same = bool(item.get('same_except_injured_torque_bounds', summary.get('same_except_injured_torque_bounds')) is True)
    injured_rows = bool(dimensions and np.all(health[changed] < 1.))
    effect = bool(strict and bounded and same and injured_rows and substantive and original_row_violation)
    return {'status': status, 'reason': item.get('reason', summary.get('reason')),
        'strict_solved_finite': strict, 'solver_status_val': item.get('solver_status_val', summary.get('solver_status_val')),
        'original_bounded_feasible': bounded, 'same_except_injured_torque_bounds': same,
        'changed_channel_indices': changed.tolist(), 'changed_row_indices': rows.tolist(),
        'capacity_bound_effect': effect, 'saved_capacity_bound_effect': item.get('capacity_bound_effect', summary.get('capacity_bound_effect')),
        'substantive_capacity_violation': substantive, 'original_capacity_row_violation': original_row_violation,
        'capacity_violation_nm': None if violation is None else violation.tolist(),
        'floating_roundoff_bound_nm': None if roundoff is None else roundoff.tolist(),
        'raw_margin_original_capacity_nm': item.get('raw_margin_original_capacity_nm', summary.get('raw_margin_original_capacity_nm')),
        'original_raw_margin_nm': item.get('original_raw_margin_nm', summary.get('original_raw_margin_nm')),
        'shadow_minus_original_tau_nm': item.get('shadow_minus_original_tau_nm'),
        'original_dual_available': item.get('original_dual') is not None,
        'new_QP_calls': item.get('new_QP_calls', summary.get('new_QP_calls', 0)), 'actuated': False}


def _summary(rows, denominator):
    sent = sum(row['timely_recognized_sent'] for row in rows)
    passed = sum(row['execution_confirmed'] for row in rows)
    return {'planned': denominator, 'recorded_method_results': sum(row['method_result_recorded'] for row in rows),
        'eligible': sum(row['eligible'] for row in rows), 'timely_recognized_sent': sent,
        'recognition_rate_planned': sent / denominator if denominator else None,
        'ACTUAL_executed': sum(row['executed'] for row in rows), 'complete_501': sum(row['complete_501'] for row in rows),
        'actual_safe_at_fixed_gap': sum(row['actual_safe_at_fixed_gap'] for row in rows),
        'terminal_pass': sum(row['terminal_pass'] for row in rows), 'full_50_ticks_20ms': sum(row['full_50_ticks_20ms'] for row in rows),
        'execution_confirmed': passed, 'success_rate_planned': passed / denominator if denominator else None,
        'conditional_success_rate_sent': passed / sent if sent else None,
        'injured_middle_sent': sum(row['injured_middle_event'] for row in rows),
        'incorrect_recognition_count': sum(row['timely_recognized_sent'] and not row['execution_confirmed'] for row in rows),
        'known_observed_unsafe_accepts': sum(row['timely_recognized_sent'] and row['observed_unsafe'] for row in rows),
        'sent_actual_NOT_RUN_or_missing': sum(row['timely_recognized_sent'] and not row['executed'] for row in rows),
        'not_sent': sum(not row['timely_recognized_sent'] for row in rows),
        'online_late_or_missing_time_sent': sum(row['selected_sent'] and not row['timely_recognized_sent'] for row in rows),
        'online_deadline_exceeded': sum(finite(row['command_ready_ms']) and row['command_ready_ms'] > 20. for row in rows),
        'statuses': dict(Counter(row['online_status'] for row in rows)),
        'actual_statuses': dict(Counter(row['status'] for row in rows)),
        **{name: sum(row[name] for row in rows) for name in FAILURE_FIELDS},
        'capacity99_actual_contexts': sum(row['capacity99_event'] for row in rows),
        'first_packet_capacity99_contexts': sum(row['first_packet_capacity99_event'] for row in rows),
        'command_ready_ms': statistics(row['command_ready_ms'] for row in rows),
        'all_actual_tick_ms': statistics(value for row in rows for value in row['tick_latency_ms'])}


def _branch_from(method_result, out, name):
    record = (method_result.get('branches') or {}).get(name) or {}
    # Streamed context result is authoritative; standalone file supplements an
    # interruption occurring after branch persistence but before index update.
    if not record and method_result.get('online_numeric_path'):
        path = resolve(out, method_result['online_numeric_path']).parent / name / 'RESULT.json'
        record = read(path, {})
    return record


def _packet_metadata(path):
    """JSON scalar metadata; no online inference or numeric witness replay."""
    return (read(path, {}) or {}).get('record', {})


def _saved_length(value):
    if isinstance(value, dict) and 'npz_key' in value:
        return int(value.get('shape', [0])[0]) if value.get('shape') else 0
    return len(value) if isinstance(value, (list, tuple, np.ndarray)) else 0


def _reason_code(value):
    if isinstance(value, dict):
        return value.get('reason') or value.get('status') or 'SAVED_REASON_MAPPING'
    return str(value) if value is not None else None


def _calibration_diagnostics(out, plans):
    rows, affected = [], []
    for method in METHODS:
        path = out / 'calibration' / method / ('step32_delay_cal_' + method.lower() + '.json')
        document = read(path, {})
        rule = document.get('local_cal_rule') or {}
        for group_id, group in (document.get('groups') or {}).items():
            gamma, role = group_id.split(':', 1)
            snapshots = group.get('cal_distinct_source_snapshots', 0)
            episodes = group.get('cal_episode_count', 0)
            missing = group.get('cal_missing_input_count', 0)
            minimum = bool(document.get('trained') and snapshots >= 4 and episodes >= 2)
            additional_guard = bool(rule.get('missing_feature_group_rejects') and missing > 0)
            only_additional = bool(minimum and additional_guard and not group.get('local_calibrated'))
            matching = [p['context_id'] for p in plans if p['role'] == role]
            row = {'method': method, 'group_id': group_id, 'gamma': float(gamma), 'role': role,
                'planned_CAL': group.get('cal_planned_count', 0), 'finite_CAL': group.get('cal_finite_count', 0),
                'complete_CAL': group.get('cal_complete_count', 0), 'complete_distinct_snapshots': snapshots,
                'complete_episodes': episodes, 'missing_features': missing,
                'incomplete_finite_labels': len(group.get('cal_incomplete_ids', [])),
                'complete_physical_failures': group.get('cal_failed_physical_count', 0),
                'complete_terminal_failures': group.get('cal_failed_terminal_count', 0),
                'local_calibrated_saved': bool(group.get('local_calibrated')),
                'original_static_minimum_met': minimum,
                'original_static_minimum_failed': not minimum,
                'additional_global_missing_feature_guard': additional_guard,
                'disabled_solely_by_additional_group_guard_at_static_stage': only_additional,
                'matched_TEST_contexts': matching,
                'saved_CAL_path': str(path),
                'input_missing_ids': group.get('cal_missing_input_ids', [])}
            rows.append(row)
            if only_additional:
                affected.append(row)
    context_ids = sorted({cid for row in affected for cid in row['matched_TEST_contexts']})
    deviation = {'status': 'INVALID_PROTOCOL_CALIBRATION_GATE',
        'code_path': 'cavr_wbc/control/step32_margin.py:141',
        'saved_rule_field': 'local_cal_rule.missing_feature_group_rejects = true',
        'implemented_expression': 'bundle[trained] and not missing and complete snapshots >= 4 and complete episodes >= 2',
        'protocol_rule': 'LOCAL stable nearest four distinct snapshots, >=2 episodes; selected incomplete neighbors reject',
        'deviation': 'Any missing feature disables the entire method/gamma/role CAL group, beyond selected-neighbor rejection',
        'affected_static_groups': [row['method'] + ':' + row['group_id'] for row in affected],
        'affected_TEST_contexts': context_ids, 'affected_TEST_context_count': len(context_ids),
        'affected_planned_method_gamma_actions': sum(len(row['matched_TEST_contexts']) for row in affected),
        'original_static_minimum_failed_groups': {method: sum(row['method'] == method and row['original_static_minimum_failed'] for row in rows) for method in METHODS},
        'additional_guard_only_disabled_groups': {method: sum(row['method'] == method and row['disabled_solely_by_additional_group_guard_at_static_stage'] for row in rows) for method in METHODS},
        'removing_guard_would_send': 'NOT_EVALUATED_NO_COUNTERFACTUAL_DECISION',
        'numeric_code_or_CAL_modified_after_TEST': False, 'TEST_retry': False}
    return rows, deviation


def _online_diagnostics(out, method_rows):
    rows, action_rows, summaries = [], [], {}
    for method in METHODS:
        selected = method_rows[method]
        for row in selected:
            packet_path = resolve(out, row['online_numeric_path']) if row.get('online_numeric_path') else out / 'queue' / row['context_id'] / method / 'ONLINE_NUMERIC.json'
            packet = _packet_metadata(packet_path)
            qualified = _saved_length(packet.get('qualified_gammas'))
            C = packet.get('C') or {}; B = packet.get('B') or {}
            lookup_count = sum(item.get('evaluation_status') == 'EVALUATED' for item in (packet.get('actions') or {}).values())
            detail = {'context_id': row['context_id'], 'method': method, 'role': row['role'], 'episode': row['episode'],
                'planned_gamma_actions': 5, 'status': row['online_status'], 'eligible': row['eligible'],
                'command_ready_ms': row['command_ready_ms'], 'selected_sent': row['selected_sent'],
                'sent_gamma': row['selected_gamma'] if row['selected_sent'] else None,
                'diagnostic_last_gamma': row['selected_gamma'],
                'qualified_gamma_count': qualified,
                'primary_saved_path_reason': 'NO_QUALIFIED_DELAY_CAL_ACTION' if qualified == 0 else packet.get('reason'),
                'C_solver_status_val': C.get('solver_status_val'), 'C_solver_status': C.get('solver_status'),
                'C_command_valid': bool(C.get('command_valid')), 'B_saved_status': B.get('status'),
                'B_solver_status_val': B.get('solver_status_val'),
                'prehold_complete': (packet.get('prehold') or {}).get('complete'),
                'application_prediction_complete': (packet.get('application_prediction') or {}).get('complete'),
                'numeric_lookup_evaluated_actions': lookup_count,
                'support_pose_distance_local_terminal_lookup_status': 'NOT_EVALUATED' if lookup_count == 0 else 'SEE_SAVED_ACTION_DECISIONS',
                'online_packet_path': str(packet_path)}
            rows.append(detail)
            for gamma in (1., .75, .5, .25, 0.):
                entry = (packet.get('actions') or {}).get(str(float(gamma)), {})
                action = entry.get('action') or {}
                action_rows.append({'context_id': row['context_id'], 'method': method, 'gamma': gamma,
                    'evaluation_status': entry.get('evaluation_status', 'NOT_RECORDED'),
                    'command_valid_saved': action.get('command_valid'),
                    'unavailable_reason': action.get('unavailable_reason'),
                    'lookup_evaluated': entry.get('evaluation_status') == 'EVALUATED',
                    'features_recorded': entry.get('features26') is not None,
                    'online_packet_path': str(packet_path)})
        details = [item for item in rows if item['method'] == method]
        actions = [item for item in action_rows if item['method'] == method]
        summaries[method] = {'planned': 36, 'recorded': len(details), 'planned_gamma_actions': 180,
            'zero_qualified_gammas': sum(item['qualified_gamma_count'] == 0 for item in details),
            'B_NOT_CALIBRATED_not_requested': sum(item['B_saved_status'] == 'NOT_CALIBRATED' for item in details),
            'numeric_lookup_not_evaluated_contexts': sum(item['numeric_lookup_evaluated_actions'] == 0 for item in details),
            'C_solver_statuses': dict(Counter(str(item['C_solver_status_val']) for item in details)),
            'C_valid_commands': sum(item['C_command_valid'] for item in details),
            'prehold_complete': sum(item['prehold_complete'] is True for item in details),
            'prediction_complete': sum(item['application_prediction_complete'] is True for item in details),
            'action_evaluation_statuses': dict(Counter(item['evaluation_status'] for item in actions)),
            'qualified_empty_is_prior_to_model_support_lookup': True,
            'gamma1_COMMAND_UNAVAILABLE_may_mean_no_prefix_requested_not_C_QP_failed': True,
            'no_send_is_not_physical_safe_or_unsafe': True}
    return rows, action_rows, summaries


def _dev_diagnostics(out, records):
    rows, summaries, packets = [], {}, {}
    for entry in records:
        cal = read(resolve(out, entry['path']), {}) if entry.get('path') else {}
        branch = read(resolve(out, entry['branch_result']), {}) if entry.get('branch_result') else {}
        label = branch.get('label') or cal.get('labels') or {}
        packet_path = resolve(out, entry['packet_path']) if entry.get('packet_path') else None
        if packet_path is not None and str(packet_path) not in packets:
            packets[str(packet_path)] = _packet_metadata(packet_path)
        packet = packets.get(str(packet_path), {})
        action_entry = (packet.get('actions') or {}).get(str(float(entry['gamma'])), {})
        action = action_entry.get('action') or {}
        reason = branch.get('reason') or label.get('reason')
        complete = bool(label.get('complete') and label.get('full_501_grid') is True)
        observed = bool(label.get('observed_original_physical_failure') or label.get('original_failure') or (complete and not label.get('original_physical_safe')))
        physical_reason = label.get('original_failure') or {}
        physical_types = physical_reason.get('reasons', []) if isinstance(physical_reason, dict) else [str(physical_reason)]
        features = cal.get('features26')
        rows.append({'id': entry.get('id'), 'context_id': entry.get('context_id'), 'method': entry.get('method'),
            'gamma': entry.get('gamma'), 'episode': entry.get('episode'), 'source_snapshot': entry.get('source_snapshot'),
            'status': entry.get('status', 'NOT_RUN'), 'propagated': bool(branch and entry.get('status') != 'NOT_RUN'),
            'complete_501': complete, 'feature26_available': bool(isinstance(features, list) and len(features) == 26 and all(finite(x) for x in features)),
            'packet_action_status': action_entry.get('evaluation_status'),
            'unavailable_reason': action.get('unavailable_reason'), 'reason': _reason_code(reason),
            'failed_solver_status_val': reason.get('solver_status_val') if isinstance(reason, dict) else None,
            'failed_solver_status': reason.get('solver_status') if isinstance(reason, dict) else None,
            'C_solver_status_val': (packet.get('C') or {}).get('solver_status_val'),
            'B_solver_status_val': (packet.get('B') or {}).get('solver_status_val'),
            'physical_pass_if_complete': bool(complete and label.get('original_physical_safe')),
            'observed_physical_failure': observed, 'physical_failure_if_complete': bool(complete and not label.get('original_physical_safe')),
            'terminal_pass_if_complete': bool(complete and label.get('terminal_pass')),
            'terminal_failure_if_complete': bool(complete and not label.get('terminal_pass')),
            'partial_terminal_false_is_not_known_terminal_failure': bool(not complete),
            'original_physical_failure': label.get('original_failure'),
            'observed_physical_failure_types': physical_types,
            'physical_steps_recorded': (branch.get('counts') or {}).get('physical_steps', 0),
            'CAL_record_path': entry.get('path'), 'branch_result_path': entry.get('branch_result'),
            'packet_path': entry.get('packet_path')})
    for method in METHODS:
        selected = [row for row in rows if row['method'] == method]
        missing = [row for row in selected if row['status'] == 'NOT_RUN']
        partial = [row for row in selected if row['propagated'] and not row['complete_501']]
        summaries[method] = {'planned': 100, 'recorded': len(selected),
            'propagated': sum(row['propagated'] for row in selected),
            'complete_501': sum(row['complete_501'] for row in selected), 'partial': len(partial),
            'statuses': dict(Counter(row['status'] for row in selected)),
            'NOT_RUN_reasons': dict(Counter(row['unavailable_reason'] or row['reason'] or row['packet_action_status'] or 'NOT_RECORDED' for row in missing)),
            'NOT_RUN_packet_action_statuses': dict(Counter(row['packet_action_status'] or 'NOT_RECORDED' for row in missing)),
            'partial_raw_solver_statuses': dict(Counter(str(row['failed_solver_status_val']) for row in partial)),
            'partial_raw_solver_status_names': dict(Counter(row['failed_solver_status'] or 'NOT_RECORDED' for row in partial)),
            'physical_pass_complete': sum(row['physical_pass_if_complete'] for row in selected),
            'physical_failure_complete': sum(row['physical_failure_if_complete'] for row in selected),
            'observed_physical_failure_in_partial': sum(row['observed_physical_failure'] for row in partial),
            'first_observed_physical_reason_counts': dict(Counter(reason for row in selected for reason in row['observed_physical_failure_types'])),
            'terminal_pass_complete': sum(row['terminal_pass_if_complete'] for row in selected),
            'terminal_failure_complete': sum(row['terminal_failure_if_complete'] for row in selected),
            'missing_or_partial_labels_not_zero_filled': True}
    return rows, summaries


def _shadow_diagnostics(rows):
    result = {}
    for endpoint in ('C', 'B'):
        result[endpoint] = {'planned_injured_contexts': 32,
            'statuses': dict(Counter(row[endpoint + '_status'] for row in rows)),
            'strict_solved_finite': sum(row[endpoint + '_strict_solved_finite'] for row in rows),
            'capacity_bound_effect': sum(row[endpoint + '_capacity_bound_effect'] for row in rows),
            'original_bounded_feasible': sum(row[endpoint + '_original_bounded_feasible'] for row in rows),
            'original_feasible_no_substantive_capacity_violation': sum(row[endpoint + '_strict_solved_finite'] and row[endpoint + '_original_bounded_feasible'] and not row[endpoint + '_substantive_capacity_violation'] for row in rows),
            'substantive_violation_but_original_not_confirmed_feasible': sum(row[endpoint + '_substantive_capacity_violation'] and not row[endpoint + '_original_bounded_feasible'] for row in rows),
            'NOT_RUN_reasons': dict(Counter(row[endpoint + '_reason'] or 'NOT_RECORDED' for row in rows if row[endpoint + '_status'] == 'NOT_RUN')),
            'new_shadow_QP_calls': sum(row[endpoint + '_new_QP_calls'] or 0 for row in rows)}
    return result


def report(out):
    out = Path(out).resolve(); manifest = read(out / 'MANIFEST.json', {})
    finished = read(out / 'RUN_FINISHED.json', {})
    plans = manifest.get('TEST') or _fixed_plans()
    rows, branches, paired, extension_rows, shadow_rows = [], [], [], [], []
    method_rows = defaultdict(list)
    successful_middle, paired_improvement, extension_contexts, capacity_contexts = [], [], [], []
    limits = np.zeros(12)
    mapping = manifest.get('mapping') or []
    for item in mapping:
        index = item.get('actuator_index')
        if isinstance(index, int) and 0 <= index < 12 and finite(item.get('healthy_limit_nm')):
            limits[index] = float(item['healthy_limit_nm'])
    limits_available = bool(len(mapping) == 12 and np.all(limits > 0.))
    for plan in plans:
        result_path = out / 'queue' / plan['context_id'] / 'RESULT.json'
        result = read(result_path, {}); context = result.get('context') or {}
        gap = plan['gap_m']; facts, per_method = {}, {}
        metadata = {'context_id': plan['context_id'], 'ordinal': plan['ordinal'], 'episode': plan['episode'],
            'source_snapshot': plan.get('snapshot_id'), 'tick': plan['tick'], 'role': plan['role'],
            'health_kind': plan.get('health_kind'), 'direction': plan['direction'],
            'front_or_rear': 'front' if plan['direction'] > 0 else 'rear', 'injured': plan['role'] != 'healthy',
            'gap_m': gap, 'eligible': bool(context.get('eligible', result.get('eligible', False))),
            'result_path': str(result_path)}
        for method in METHODS:
            m = (result.get('methods') or {}).get(method) or {}
            actual = _branch_from(m, out, 'ACTUAL'); fact = branch_facts(actual, gap)
            ready = m.get('command_ready_ms'); sent = bool(m.get('selected_sent'))
            timely = bool(sent and finite(ready) and 0. <= ready <= 20.)
            gamma = m.get('selected_gamma')
            middle = bool(timely and metadata['injured'] and gamma in MIDDLE)
            row = {**metadata, 'method': method, 'method_result_recorded': bool(m),
                'online_status': m.get('status', 'NOT_RUN'), 'selected_sent': sent, 'timely_recognized_sent': timely,
                'selected_gamma': gamma, 'gamma': gamma, 'command_ready_ms': ready,
                'sent_gamma': gamma if sent else None, 'diagnostic_last_gamma': gamma,
                'selected_gamma_semantics': 'SENT_PACKET' if sent else 'LAST_DIAGNOSTIC_ACTION_NOT_APPROVED',
                'injured_middle_event': middle, 'online_numeric_path': m.get('online_numeric_path'), **fact}
            # A physical rollout alone cannot validate a packet that was not
            # timely recognized and sent by this method's actual decision.
            row['execution_confirmed'] = bool(timely and row['execution_confirmed'])
            rows.append(row); method_rows[method].append(row); per_method[method] = row
            facts[method] = {}
            for name in BRANCHES:
                f = branch_facts(_branch_from(m, out, name), gap)
                facts[method][name] = f
                branches.append({**metadata, 'method': method, 'branch': name,
                    'expected_by_trigger': timely if name == 'ACTUAL' else method == 'ALIGNED_RECAL' and middle,
                    'selected_gamma': gamma, **f})
        stale = per_method['STALE_RECAL']; aligned = per_method['ALIGNED_RECAL']
        pair_improvement = bool(aligned['injured_middle_event'] and aligned['execution_confirmed'] and stale['timely_recognized_sent'] and stale['executed'] and
                                not stale['execution_confirmed'] and
                                any(stale[name] for name in FAILURE_FIELDS))
        if aligned['injured_middle_event'] and aligned['execution_confirmed']:
            successful_middle.append(metadata)
        if pair_improvement:
            paired_improvement.append(metadata)
        pair = dict(metadata)
        for method, row in per_method.items():
            for name in ('online_status', 'selected_sent', 'timely_recognized_sent', 'selected_gamma', 'command_ready_ms',
                         'status', 'executed', 'complete_501', 'physical_pass', 'terminal_pass', 'actual_safe_at_fixed_gap',
                         'execution_confirmed', 'full_50_ticks_20ms', 'D_m', 'Y', 'progress0_04_m', 'progress02_04_m',
                         'application_identity_pass', *FAILURE_FIELDS):
                pair[method + '_' + name] = row[name]
        pair.update(application_alignment_paired_improvement=pair_improvement,
                    both_actual_executed=bool(stale['executed'] and aligned['executed']),
                    stale_abstain_or_NOT_RUN=bool(not stale['selected_sent'] and not stale['executed']),
                    aligned_actual_safe_without_paired_improvement=bool(aligned['execution_confirmed'] and not pair_improvement))
        paired.append(pair)
        if not metadata['injured']:
            continue
        actual = facts['ALIGNED_RECAL']['ACTUAL']; c = facts['ALIGNED_RECAL']['COUNTERFACTUAL_C']; b = facts['ALIGNED_RECAL']['COUNTERFACTUAL_B']
        comparison = bool(aligned['injured_middle_event'] and aligned['execution_confirmed'] and b['execution_confirmed'] and
                          finite(actual['progress02_04_m']) and finite(b['progress02_04_m']))
        gain = actual['progress02_04_m'] - b['progress02_04_m'] if comparison else None
        extension = bool(comparison and gain > 0. and c['executed'] and c['observed_unsafe'])
        if extension:
            extension_contexts.append(metadata)
        erow = {**metadata, 'ALIGNED_timely_middle_sent': aligned['injured_middle_event'],
            'ALIGNED_actual_confirmed': aligned['execution_confirmed'], 'comparison_available_safe_B': comparison,
            'actual_progress0_04_m': actual['progress0_04_m'], 'actual_progress02_04_m': actual['progress02_04_m'],
            'B_progress0_04_m': b['progress0_04_m'], 'B_progress02_04_m': b['progress02_04_m'],
            'progress02_04_gain_m': gain, 'strict_progress_gain': bool(comparison and gain > 0.),
            'C_status': c['status'], 'C_executed': c['executed'], 'C_complete_501': c['complete_501'],
            'C_observed_unsafe': c['observed_unsafe'], 'C_numerical_incomplete': c['numerical_incomplete'],
            'C_physical_failure': c['physical_failure'], 'C_local_failure': c['local_failure'], 'C_terminal_failure': c['terminal_failure'],
            'B_status': b['status'], 'B_executed': b['executed'], 'B_complete_501': b['complete_501'],
            'B_complete_actual_safe': b['execution_confirmed'], 'safe_action_extension': extension,
            'safe_utility_tradeoff_only': bool(comparison and gain > 0. and c['execution_confirmed']),
            'counterfactual_role': 'COUNTERFACTUAL_ENDPOINT', 'first_packet_cost': 'SHARED_ORIGINAL_PACKET_NOT_INDEPENDENT_BASELINE',
            'missing_or_numerical_C_not_imputed_unsafe': True, 'no_sent_or_ABSTAIN_not_imputed_zero_motion': True}
        extension_rows.append(erow)
        shadow_path = result.get('shadow_path')
        shadow_summary = read(resolve(out, shadow_path), {}) if shadow_path else {}
        numeric_path = out / 'queue' / plan['context_id'] / 'ALIGNED_RECAL' / 'CAPACITY_SHADOW_NUMERIC.json'
        shadow_numeric = numeric_record(numeric_path) if numeric_path.exists() else {}
        srow = {**metadata, 'status': shadow_summary.get('status', shadow_numeric.get('status', 'NOT_RUN')),
            'shadow_path': shadow_path, 'numeric_path': str(numeric_path) if numeric_path.exists() else None,
            'healthy_capacity_available': limits_available}
        effects = {}
        for endpoint in ('C', 'B'):
            effect = _shadow_endpoint(shadow_numeric.get(endpoint), shadow_summary.get(endpoint), context,
                                      limits if limits_available else [])
            effects[endpoint] = effect
            srow.update({endpoint + '_' + name: value for name, value in effect.items()})
        bound_effect = any(effect['capacity_bound_effect'] for effect in effects.values())
        if bound_effect:
            capacity_contexts.append(metadata)
        srow.update(capacity_bound_effect=bound_effect, ALIGNED_actual_confirmed=aligned['execution_confirmed'],
                    ALIGNED_injured_middle_confirmed=bool(aligned['injured_middle_event'] and aligned['execution_confirmed']),
                    application_alignment_paired_improvement=pair_improvement, safe_action_extension=extension,
                    actual_capacity99_event=aligned['capacity99_event'], first_packet_capacity99_event=aligned['first_packet_capacity99_event'])
        shadow_rows.append(srow)
    middle_contexts = sorted({row['context_id'] for row in successful_middle})
    middle_episodes = sorted({row['episode'] for row in successful_middle})
    improvement_contexts = sorted({row['context_id'] for row in paired_improvement})
    extension_ids = sorted({row['context_id'] for row in extension_contexts})
    extension_episodes = sorted({row['episode'] for row in extension_contexts})
    capacity_ids = sorted({row['context_id'] for row in capacity_contexts})
    a_supported = len(middle_contexts) >= 2 and len(middle_episodes) >= 2 and bool(improvement_contexts)
    b_supported = len(extension_ids) >= 2 and len(extension_episodes) >= 2
    c_supported = len(capacity_ids) >= 2
    A = 'APPLICATION_ALIGNMENT_EFFECT_OBSERVED' if a_supported else 'NOT_ESTABLISHED'
    B = 'SAFE_ACTION_EXTENSION_OBSERVED' if b_supported else 'NOT_ESTABLISHED'
    C = 'CAPACITY_BOUND_EFFECT_OBSERVED' if c_supported else 'NOT_ESTABLISHED'
    groups = []
    for method in METHODS:
        for field in ('episode', 'direction', 'role', 'gamma'):
            values = sorted({str(row[field]) for row in method_rows[method]})
            for value in values:
                selected = [row for row in method_rows[method] if str(row[field]) == value]
                groups.append({'method': method, 'field': field, 'value': value, **_summary(selected, len(selected))})
    summary = {method: _summary(method_rows[method], 36) for method in METHODS}
    calibration_rows, calibration_deviation = _calibration_diagnostics(out, plans)
    online_rows, online_actions, online_summary = _online_diagnostics(out, method_rows)
    dev_rows, dev_summary = _dev_diagnostics(out, read(out / 'DEV_REGISTRY.json', []))
    shadow_summary = _shadow_diagnostics(shadow_rows)
    ledger_events = Counter(row.get('event', 'UNKNOWN') for row in jsonl_rows(out / 'STEP32_LEDGER.jsonl'))
    attempts = Counter((row.get('event', 'UNKNOWN'), row.get('kind', 'UNKNOWN')) for row in jsonl_rows(out / 'ATTEMPT_LEDGER.jsonl'))
    budget = finished.get('budget') or read(out / 'STEP32_PROGRESS.json', {})
    result = {'run_id': manifest.get('run_id', out.name), 'NUMERICAL_STATUS': finished.get('status', 'INCOMPLETE'),
        'SCIENTIFIC_RUN_STATUS': 'INVALID_PROTOCOL_CALIBRATION_GATE',
        'FOLLOWUP_NUMERICAL_EXECUTION': 'REQUIRES_NEW_AUTHORIZATION',
        'LOCAL_CALIBRATION_PROTOCOL_DEVIATION': calibration_deviation,
        'ONLINE_rejection_summary': online_summary,
        'DEV_outcome_reason_summary': dev_summary,
        'CAPACITY_SHADOW_reason_summary': shadow_summary,
        'saved_only_analysis_status': 'ANALYZED_NO_NUMERICAL_REPLAY',
        'APPLICATION_ALIGNMENT_STATUS': A, 'SAFE_ACTION_EXTENSION_STATUS': B, 'CAPACITY_BOUND_STATUS': C,
        'A_STATUS': A, 'B_STATUS': B, 'C_STATUS': C,
        'planned_TEST_contexts': 36, 'planned_method_rows': 72, 'planned_injured_contexts': 32,
        'methods': summary, 'groups': groups,
        'application_alignment': {'supported': a_supported, 'successful_injured_middle_contexts': middle_contexts,
            'successful_episodes': middle_episodes, 'paired_STALE_failed_ALIGNED_passed_contexts': improvement_contexts,
            'paired_improvement_episodes': sorted({row['episode'] for row in paired_improvement}),
            'abstain_or_late_STALE_count_not_treated_as_paired_failure': sum(row['stale_abstain_or_NOT_RUN'] for row in paired),
            'both_actual_executed_contexts': sum(row['both_actual_executed'] for row in paired)},
        'action_extension': {'supported': b_supported, 'contexts': extension_ids, 'episodes': extension_episodes,
            'safe_B_comparisons': sum(row['comparison_available_safe_B'] for row in extension_rows),
            'positive_progress_gain_contexts': sum(row['strict_progress_gain'] for row in extension_rows),
            'safe_utility_tradeoff_only_contexts': sum(row['safe_utility_tradeoff_only'] for row in extension_rows)},
        'capacity_bound': {'supported': c_supported, 'contexts': capacity_ids,
            'episodes': sorted({row['episode'] for row in capacity_contexts}),
            'endpoint_evidence_counts': {endpoint: sum(row[endpoint + '_capacity_bound_effect'] for row in shadow_rows) for endpoint in ('C', 'B')},
            'actual_safe_overlap_contexts': sorted(set(capacity_ids) & {row['context_id'] for row in method_rows['ALIGNED_RECAL'] if row['execution_confirmed']})},
        'overlap': {'A_paired_improvement_and_C': sorted(set(improvement_contexts) & set(capacity_ids)),
                    'A_injured_middle_pass_and_C': sorted(set(middle_contexts) & set(capacity_ids)),
                    'B_and_C': sorted(set(extension_ids) & set(capacity_ids)),
                    'A_paired_improvement_and_B_and_C': sorted(set(improvement_contexts) & set(extension_ids) & set(capacity_ids))},
        'budget': budget, 'ledger_event_counts': dict(ledger_events),
        'attempt_event_kind_counts': {event + ':' + kind: count for (event, kind), count in attempts.items()},
        'NEW_REGRESSION_MODEL_FITS': 0, 'calibration_freeze': read(out / 'STEP32_FREEZE.json', {}),
        'implementation_repair_evidence_paths': [str(path.relative_to(out)).replace('\\', '/') for path in sorted((out / 'repairs').glob('*')) if path.is_file()],
        'DEV_registry_summary': _dev_summary(read(out / 'DEV_REGISTRY.json', [])),
        'deadline_semantics': {'command_ready_threshold_ms': 20,
            'feedback_each_tick_measured': True, 'extra_feedback_network_wait_simulated': False,
            'physical_local_terminal_safety_excludes_latency': True,
            'execution_confirmation_additionally_requires_all_50_ticks_20ms': True,
            'TEST_actual_tick_observations': sum(len(row['tick_latency_ms']) for row in rows)},
        'historical_STEP31_IMMEDIATE_STATUS': 'NOT_ESTABLISHED', 'historical_STEP31_DELAY20_STATUS': 'NOT_ESTABLISHED',
        'historical_STEP30_safety_coverage': .2746, 'historical_results_unchanged': True,
        'fixed_queue_random_population_claim': False, 'probability_coverage_claim': False,
        'continuous_safety_certificate_claim': False, 'asynchronous_network_closed_loop_claim': False,
        'first_packet_wait_only': True, 'E3_RL_hardware_authorized': False,
        'row_counts': {'QUEUE_RESULTS': len(rows), 'PAIRED_TIMING_RESULTS': len(paired),
                       'ACTION_EXTENSION_RESULTS': len(extension_rows), 'CAPACITY_SHADOW_RESULTS': len(shadow_rows)}}
    for stem, data in (('QUEUE_RESULTS', rows), ('PAIRED_TIMING_RESULTS', paired),
                       ('ACTION_EXTENSION_RESULTS', extension_rows), ('CAPACITY_SHADOW_RESULTS', shadow_rows),
                       ('BRANCH_RESULTS', branches), ('GROUP_RESULTS', groups),
                       ('ONLINE_REJECTION_REASONS', online_rows), ('ONLINE_ACTION_STATUS', online_actions),
                       ('DEV_OUTCOME_REASONS', dev_rows), ('DELAY_CAL_GROUP_STATUS', calibration_rows)):
        csv_write(out / (stem + '.csv'), data); write(out / (stem + '.json'), data)
    write(out / 'CAPACITY_SHADOW_REASON_SUMMARY.json', shadow_summary)
    write(out / 'STEP32_RESULT.json', result)
    (out / 'STEP32_REPORT.md').write_text(_report_text(result, manifest), encoding='utf-8', newline='\n')
    (out / 'STEP32_RESEARCH_HANDOFF.md').write_text(_handoff_text(result), encoding='utf-8', newline='\n')
    return result


def _dev_summary(records):
    result = {}
    for method in METHODS:
        selected = [row for row in records if row.get('method') == method]
        result[method] = {'planned': 100, 'recorded': len(selected),
            'complete': sum(bool(row.get('complete')) for row in selected),
            'statuses': dict(Counter(row.get('status', 'NOT_RUN') for row in selected))}
    return result


def _report_text(result, manifest):
    summaries = result['methods']; a = result['application_alignment']; b = result['action_extension']; c = result['capacity_bound']
    lines = ['# STEP32：施加时刻对齐的能力感知动作调节器', '',
        f"Run ID：{result['run_id']}。日期：2026-10-09（Asia/Seoul）。源交付：{manifest.get('source_commit', '0bf4b96e14820db86301dc66a09d78862e5667ae')}。", '',
        f"科学状态：**{result['SCIENTIFIC_RUN_STATUS']}**。数值批次状态仍为 {result['NUMERICAL_STATUS']}；本轮机制比较无效，不能声称按原LOCAL规则完成科学验证。", '',
        f"A 施加时序：{result['A_STATUS']}；B 动作集合扩展：{result['B_STATUS']}；C 能力约束：{result['C_STATUS']}。三个问题分别判定。", '',
        '## 未发送的直接原因与协议偏差', '',
        '两方法各36/36个计划输入、全部72个决策为ABSTAIN，ACTUAL轨迹为0。直接路径是所有method/gamma/role校准组的local_calibrated=False，qualified_gammas为空；模型support、pose、distance、近邻及终端上界查找均未执行，不能把这些未执行检查列为失败原因。', '',
        '冻结step32_margin.py:141增加了`not missing`：组内任一CAL特征缺失便禁用整组。这不是协议§3规定的“四个不同snapshot且至少两个episode的稳定近邻，选中未完成近邻不认可”，而是额外的全组门。原代码与CAL冻结原样保留，TEST后没有修改或重算。', '',
        f"额外全组门单独禁用的静态合格组：{result['LOCAL_CALIBRATION_PROTOCOL_DEVIATION']['affected_static_groups']}。这五个STALE calf组均有4个完整不同snapshot、2条episode，但分别有2–4个缺失特征。影响STALE的{result['LOCAL_CALIBRATION_PROTOCOL_DEVIATION']['affected_TEST_context_count']}个calf TEST context（正向8、反向8）／{result['LOCAL_CALIBRATION_PROTOCOL_DEVIATION']['affected_planned_method_gamma_actions']}个计划gamma动作。", '',
        f"受影响TEST context：{result['LOCAL_CALIBRATION_PROTOCOL_DEVIATION']['affected_TEST_contexts']}。", '',
        'STALE其余10组、ALIGNED全部15组未满足原静态完整snapshot／episode最低数，与额外全组门分别列出。静态最低数成立不代表当前TEST近邻、支持域、local或terminal会通过；本报告未移除门再决策，也未推断去门后会发送。见[DELAY_CAL_GROUP_STATUS](DELAY_CAL_GROUP_STATUS.csv)。后续修复和数值执行需要新授权。', '',
        '## 全队列配对结果', '',
        '| 方法 | 计划输入 | 及时发送 | 完整501状态 | physical/local/terminal安全 | 全tick≤20ms | 完整执行通过 | 发送后未通过 |',
        '|---|---:|---:|---:|---:|---:|---:|---:|']
    for method in METHODS:
        s = summaries[method]
        lines.append(f"| {method} | 36 | {s['timely_recognized_sent']} | {s['complete_501']} | {s['actual_safe_at_fixed_gap']} | {s['full_50_ticks_20ms']} | {s['execution_confirmed']} | {s['incorrect_recognition_count']} |")
    lines += ['', 'physical/local/terminal安全与实时执行确认分列。20 ms绝对command-ready截止不变，后续反馈按原契约逐tick计时；完整执行确认另列全部tick≤20 ms和施加状态／首τ身份，不把tick逾期改写为物理失败。本轮没有TEST ACTUAL，因此没有实际反馈deadline观测，也没有安全恢复证据。NOT_RUN、ABSTAIN和逾期未发送不作为零运动或已知物理不安全；零错误接受不等于安全。', '']
    for method in METHODS:
        s = summaries[method]
        conditional = '未定义（未发送）' if s['conditional_success_rate_sent'] is None else f"{100*s['conditional_success_rate_sent']:.2f}%"
        lines.append(f"{method}：完整发送成功{s['execution_confirmed']}/36（{100*s['success_rate_planned']:.2f}%）；条件成功{s['execution_confirmed']}/{s['timely_recognized_sent']}（{conditional}）。physical失败{s['physical_failure']}、local失败{s['local_failure']}、terminal失败{s['terminal_failure']}、数值未完成{s['numerical_incomplete']}、deadline失败{s['deadline_failure']}、application identity失败{s['application_identity_failure']}。")
        q = result['ONLINE_rejection_summary'][method]
        lines.append(f"{method}在线原始C QP状态：{q['C_solver_statuses']}；有效C命令{q['C_valid_commands']}/36。B有{q['B_NOT_CALIBRATED_not_requested']}/36个NOT_CALIBRATED未请求；180个计划gamma动作状态为{q['action_evaluation_statuses']}。gamma=1的COMMAND_UNAVAILABLE可表示未请求prefix／特征，并不表示所有C QP失败；selected_gamma=1仅为最后诊断动作，实际sent_gamma为空。最大ready={s['command_ready_ms']['max']:.3f} ms，在线逾期{s['online_deadline_exceeded']}/36。")
    lines += ['', '在线逐context原因见[ONLINE_REJECTION_REASONS](ONLINE_REJECTION_REASONS.csv)，全部360个计划动作状态见[ONLINE_ACTION_STATUS](ONLINE_ACTION_STATUS.csv)。', '',
        '## DEV标签与未传播动作', '',
        '| 方法 | 计划动作 | 真实传播 | 完整501 | 数值partial | NOT_RUN | 完整物理失败 | 完整terminal失败 |',
        '|---|---:|---:|---:|---:|---:|---:|---:|']
    for method in METHODS:
        d = result['DEV_outcome_reason_summary'][method]
        lines.append(f"| {method} | 100 | {d['propagated']} | {d['complete_501']} | {d['partial']} | {d['statuses'].get('NOT_RUN', 0)} | {d['physical_failure_complete']} | {d['terminal_failure_complete']} |")
    lines.append('')
    for method in METHODS:
        d = result['DEV_outcome_reason_summary'][method]
        lines.append(f"{method}数值partial原始状态{d['partial_raw_solver_statuses']}（{d['partial_raw_solver_status_names']}）；NOT_RUN原因{d['NOT_RUN_reasons']}。完整物理通过{d['physical_pass_complete']}、完整terminal通过{d['terminal_pass_complete']}；partial中已观察物理失败{d['observed_physical_failure_in_partial']}，与数值未完成可重叠。首个已观察物理失败reason计数为{d['first_observed_physical_reason_counts']}，同一分支可含多个contact reason。")
    lines += ['', 'status 2保留为solved inaccurate，status 8保留为run time limit reached，均不当严格Solved完整标签。混合动作缺少两个精确Solved端点时未传播；端点无效同样占计划分母。partial的terminal=false不等于已观察终端失败，D/Y缺失不填0。首个STALE G1 status 8／20步前缀仍在原DEV证据中；一次空mocap持久化形状修复没有重算该分支。逐动作、源C/B状态、数值原始状态及物理失败字段见[DEV_OUTCOME_REASONS](DEV_OUTCOME_REASONS.csv)。', '']
    lines += ['', '逐输入的两方法事实见[QUEUE_RESULTS](QUEUE_RESULTS.csv)和[PAIRED_TIMING_RESULTS](PAIRED_TIMING_RESULTS.csv)；episode、方向、thigh/calf/healthy及gamma分组见[GROUP_RESULTS](GROUP_RESULTS.csv)。这是固定局部机制队列，同episode快照不当独立随机重复。', '',
        '## A：施加时序', '',
        f"ALIGNED完整通过的新受损中间context {len(a['successful_injured_middle_contexts'])}个，来自{len(a['successful_episodes'])}条episode；其中同context已运行STALE失败而ALIGNED通过{len(a['paired_STALE_failed_ALIGNED_passed_contexts'])}个。STALE未发送/未运行{a['abstain_or_late_STALE_count_not_treated_as_paired_failure']}个不充作配对改善。",
        f"受损中间通过context：{a['successful_injured_middle_contexts']}。配对改善context：{a['paired_STALE_failed_ALIGNED_passed_contexts']}。", '',
        '预定比较针对“施加状态对齐及其语义匹配校准”的整体设计。原回归系数、scaler、TRAIN支持、pose域和距离阈值不动，新增回归fit=0；本轮CAL增加全组门，因而没有有效的原协议机制比较，不能据此推断状态对齐无效或模型精度变化。', '',
        '## B：动作集合扩展', '',
        f"安全B端点可比较{b['safe_B_comparisons']}个context；中间动作.02–.04s进度严格高于安全B {b['positive_progress_gain_contexts']}个；满足中间安全、B安全、实际观察C的physical/local/terminal违背及严格进度增益的扩展context {len(b['contexts'])}个，覆盖{len(b['episodes'])}条episode。C/B均安全而有增益的安全效用折中{b['safe_utility_tradeoff_only_contexts']}个。",
        f"扩展context：{b['contexts']}。", '',
        '同packet C/B端点不新增首端点求解，使用独立状态和控制记忆；未被模型认可的端点标COUNTERFACTUAL_ENDPOINT。首槽成本共享原packet，不是独立baseline计时。0–.04s进度与扣除共同prehold后的.02–.04s进度分别保存，只在完整实际安全B上计算增益。数值缺失不能成为C不安全证据。见[ACTION_EXTENSION_RESULTS](ACTION_EXTENSION_RESULTS.csv)。', '',
        '## C：能力约束', '',
        f"真实有界解可行且bounds-only shadow精确Solved、超出原受损容量并超过浮点roundoff的context {len(c['contexts'])}个；C端点证据{c['endpoint_evidence_counts']['C']}个、B端点证据{c['endpoint_evidence_counts']['B']}个。", f"约束作用context：{c['contexts']}。",
        f"与A配对改善重合：{result['overlap']['A_paired_improvement_and_C']}；与A受损中间通过重合：{result['overlap']['A_injured_middle_pass_and_C']}；与B扩展重合：{result['overlap']['B_and_C']}。", '',
        f"32个C shadow均精确Solved：其中{result['CAPACITY_SHADOW_reason_summary']['C']['original_feasible_no_substantive_capacity_violation']}个原有界解已确认可行，但shadow raw没有实质超出原受损容量；另{result['CAPACITY_SHADOW_reason_summary']['C']['substantive_violation_but_original_not_confirmed_feasible']}个shadow raw超出容量，但对应真实有界C为status 8，缺乏原解可行证据。因此不能计为能力约束作用。B shadow有32个NOT_RUN，原因ORIGINAL_SAME_CALL_PROBLEM_UNAVAILABLE，源于B未被请求；不是32次B求解失败。", '',
        'shadow仅恢复受损通道QP torque bounds，状态、任务、anchor、servo health/积分、接触、目标和solver设置保持。它不施加到物理系统、不参与选择或CAL。原始raw差值、原容量余量、改变row、dual是否可用及roundoff排除尺度见[CAPACITY_SHADOW_RESULTS](CAPACITY_SHADOW_RESULTS.csv)。非零dual或health标签不自动构成实质约束作用。', '',
        f"ALIGNED真实轨迹99%事件context {summaries['ALIGNED_RECAL']['capacity99_actual_contexts']}个，其中首packet99%事件{summaries['ALIGNED_RECAL']['first_packet_capacity99_contexts']}个；99%事件、QP容量干预与实际恢复分开列出。无交集时不把容量干预解释为恢复收益。", '',
        '## 时间轴与范围', '',
        '完整分支的评价要求为sample t=0到1.000s、500步／501状态：0–.02s保持带source身份并按新health clip的previous command，标LAST_COMMAND_HEALTH_CLIPPED；.02–.04s施加原packet；.04/.06/…/.98s共48个反馈槽。原sample anchor不移到application，局部D包含prehold。DEV有未完成数值分支，只保留真实推进到的前缀，不冒充完整500步；TEST没有ACTUAL传播。',
        'ALIGNED在独立预测data中用相同prehold预测10个2ms步到application，其C/B、混合witness、raw/sent检查、prefix及26维特征来自同一预测状态。后验ACTUAL prehold终点与完整integration state/anchor/首τ核对，只用于结果，不重新求解。STALE使用sample点计算而同样延后施加。',
        '每方法只有一个sample开始的20ms窗口，真实故障相关prehold、状态预测、QP、检查、prefix、推断与必要拷贝均计入；startup构造另列。这里只建模首packet的一周期等待，后续反馈逐tick计时而不再叠加通信等待，不称完整异步网络闭环。DELAY_CAL target是sample t=1.000s，不是application+1s。', '',
        '## 预算与交接', '', f"数值状态：{result['NUMERICAL_STATUS']}。预算记录：{result['budget']}。",
        f"新DEV记录：{result['DEV_registry_summary']}。同一上限120分钟、25,000真实QP、250,000积分步包含reference、DEV、预测、实际、shadow、startup及失败；新增回归fit=0。START/RETURN/DONE短账本见ATTEMPT_LEDGER.jsonl，QP与预测/实际积分见STEP32_LEDGER.jsonl。",
        f"DEV工程修复证据路径：{result['implementation_repair_evidence_paths']}。工程中断与普通求解/物理失败分开；已保存普通数值失败仍计入DEV计划分母和CAL完整性，不能通过工程继续将其消失。",
        '两套新CAL及代码在DEV后一次冻结，TEST不按结果重试、替换或扩样。原STEP31两项NOT_ESTABLISHED及STEP30覆盖27.46%保持，本轮不重判历史40%门。不进入E3/RL/硬件，未访问机器人运控算法。',
        '本轮残差校准是经验筛选，固定队列观察不等于概率覆盖、连续安全证书或严格viability。所有计划输入、失败和未发送保留。', '',
        'SciPilot图：[全队列配对决策、计时与缺失终点](figures/STEP32_paired_queue.pdf)；[全部受损TEST空事件及全部DEV中间动作诊断](figures/STEP32_middle_diagnostics.pdf)。TEST没有认可发送的中间动作，图中不补造TEST曲线；DEV诊断独立标注，包含全部96个计划中间动作、21条真实曲线、15条feedback deadline失败及75条NOT_RUN。两图均注明科学比较INVALID，不仅画positive。PDF/SVG/600 dpi PNG、灰度预览和数据表保留在figures/。', '',
        '```ini', 'AUTHORIZE_STEP32_APPLICATION_TIME_GOVERNOR = TRUE', 'AUTHORIZE_NEW_DELAY_CALIBRATION = TRUE',
        f"NUMERICAL_STATUS = {result['NUMERICAL_STATUS']}", f"SCIENTIFIC_RUN_STATUS = {result['SCIENTIFIC_RUN_STATUS']}",
        'FOLLOWUP_NUMERICAL_EXECUTION = REQUIRES_NEW_AUTHORIZATION', f"APPLICATION_ALIGNMENT_STATUS = {result['A_STATUS']}",
        f"SAFE_ACTION_EXTENSION_STATUS = {result['B_STATUS']}", f"CAPACITY_BOUND_STATUS = {result['C_STATUS']}",
        'NEW_REGRESSION_MODEL_FITS = 0', 'DEV_CONTEXTS = 20', 'DEV_MAX_ACTION_TRAJECTORIES = 200', 'TEST_CONTEXTS = 36',
        'ONLINE_METHODS = STALE_RECAL,ALIGNED_RECAL', 'PREHOLD_AND_APPLICATION_DELAY_MS = 20',
        'ORIGINAL_SAMPLE_HORIZON_S = 1', 'PHYSICS_DT_S = 0.002', 'DEADLINE_MS = 20', 'MAX_SOLVER_TIME_S = 0.006',
        'MAX_NEW_QP_CALLS = 25000', 'MAX_NEW_PHYSICS_STEPS = 250000', 'MAX_NUMERICAL_WALL_MINUTES = 120',
        'MAX_DEV_IMPLEMENTATION_REPAIRS = 2', 'TEST_RESULT_BASED_RETRY = FALSE', 'HISTORICAL_RESULTS_UNCHANGED = TRUE',
        'E3_RL_HARDWARE = NOT_AUTHORIZED', '```', '',
        '## Material Passport', '',
        'experiment-agent／validate／2026-10-09；Verification Status: ANALYZED。仅解释当前保存结果，不做数值重现。固定计划分母及失败全部保留；未作显著性、随机总体、独立snapshot或去门反事实发送推断。', '']
    return '\n'.join(lines)


def _handoff_text(result):
    a = result['application_alignment']; b = result['action_extension']; c = result['capacity_bound']
    lines = ['# STEP32研究交接', '', f"Run ID：{result['run_id']}。数值状态：{result['NUMERICAL_STATUS']}。", '',
        f"SCIENTIFIC_RUN_STATUS = {result['SCIENTIFIC_RUN_STATUS']}；FOLLOWUP_NUMERICAL_EXECUTION = REQUIRES_NEW_AUTHORIZATION。本轮机制比较无效，不能交付为满足原LOCAL规则的科学验证。", '',
        f"A：{result['A_STATUS']}；B：{result['B_STATUS']}；C：{result['C_STATUS']}。", '',
        '本轮实现sample-clock的一周期prehold与application-state对齐，GEOMETRY_FULL_26的回归/scaler/TRAIN支持/pose/distance不变、fit=0。但step32_margin.py:141的`not missing`额外全组门偏离协议§3选中未完成近邻拒绝规则；两方法CAL虽同新DEV清单，却不能声称遵守原LOCAL规则。', '',
        f"额外门单独禁用的五个静态合格STALE calf组：{result['LOCAL_CALIBRATION_PROTOCOL_DEVIATION']['affected_static_groups']}。影响16个TEST calf context（正／反各8）／80个计划gamma动作，逐条身份见STEP32_RESULT及DELAY_CAL_GROUP_STATUS。STALE其余10组与ALIGNED15组未满足原静态最低完整数。没有重新决策去门后是否发送。", '',
        f"ALIGNED受损中间通过{len(a['successful_injured_middle_contexts'])}个context/{len(a['successful_episodes'])}条episode；同context已运行STALE失败而ALIGNED通过{len(a['paired_STALE_failed_ALIGNED_passed_contexts'])}个。",
        f"动作扩展{len(b['contexts'])}个context/{len(b['episodes'])}条episode；能力QP干预证据{len(c['contexts'])}个context。重合：{result['overlap']}。", '']
    for method in METHODS:
        s = result['methods'][method]
        lines.append(f"{method}完整执行成功{s['execution_confirmed']}/36；及时发送{s['timely_recognized_sent']}/36，条件成功{s['execution_confirmed']}/{s['timely_recognized_sent']}。发送后未通过{s['incorrect_recognition_count']}。")
    lines += ['', '全部72决策ABSTAIN、qualified_gammas为空；support/pose/distance/local/terminal数值查找未执行。没有TEST ACTUAL，不能称已恢复或安全。selected_gamma=1是最后诊断动作，sent_gamma为空。逐context和每gamma原因已单独保存。',
        'DEV两方法分别100个计划动作：STALE传播47、完整31、partial16、NOT_RUN53；ALIGNED传播39、完整22、partial17、NOT_RUN61。raw status 2与8、源端点不可用及完整物理／终端评价分别列出；partial终端缺失不计终端失败。',
        'C shadow32次严格Solved：24个真实有界解可行但无实质受损容量违反，另8个容量违反却对应真实有界C status 8，故作用证据0。B shadow32个NOT_RUN因原B问题未请求，不是32次B求解失败。',
        '完整ACTUAL与同packet端点反事实要求sample到1.000s的500步/501状态、原anchor和独立控制记忆；partial仅保存真实前缀。本轮未触发TEST轨迹及进度比较。只有安全B参与增益，C数值缺失不当已知不安全。shadow只改受损torque bounds，不用于控制、CAL或选择。',
        '仅首packet固定等待20ms，后续feedback逐tick计时但未模拟每tick网络等待；经验LOCAL残差筛选不称概率保证或连续证书。下一步依据A/B/C及交集分别判断，不以单项成功自动进入E3。',
        'STEP31即时/延迟两项NOT_ESTABLISHED、STEP30覆盖27.46%和所有旧结果保留。未做历史数值复跑；不访问机器人运控算法。任何后续实验需新授权。', '',
        '数值代码、DEV／TEST records及freeze全部原样保留；TEST后无数值修正、重试或扩样。后续修复需要新授权及独立新实验身份，不能把现有证据改写成原协议成功。',
        '读取顺序：STEP32_REPORT.md → STEP32_RESULT.json → DELAY_CAL_GROUP_STATUS.csv → ONLINE_REJECTION_REASONS.csv → DEV_OUTCOME_REASONS.csv → PAIRED_TIMING_RESULTS.csv → ACTION_EXTENSION_RESULTS.csv → CAPACITY_SHADOW_RESULTS.csv；原始packet、轨迹、controls及ledger路径保留在对应索引。', '']
    return '\n'.join(lines)


def summarize(run_id=RUN_ID):
    return report(ROOT / 'artifacts/step32_application_time_20261009' / run_id)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('run_id', nargs='?', default=RUN_ID)
    argument = parser.parse_args().run_id
    result = report(argument) if Path(argument).is_absolute() else summarize(argument)
    print(result['SCIENTIFIC_RUN_STATUS'], result['A_STATUS'], result['B_STATUS'], result['C_STATUS'])
