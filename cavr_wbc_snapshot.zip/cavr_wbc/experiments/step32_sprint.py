"""One streaming fixed STEP32 DEV20 / paired TEST36 application-clock batch."""
import argparse
from copy import deepcopy
from datetime import datetime, timezone
import gc
import os
from time import perf_counter
import traceback
import numpy as np

from cavr_wbc.experiments import step17_formal_panel as frozen
from cavr_wbc.experiments import step32_sim as sim
from cavr_wbc.experiments.step32_reference import reference_episode
from cavr_wbc.experiments.step26_features_storage import save_bank
from cavr_wbc.experiments.step28_sprint import home_context
from cavr_wbc.experiments.step29_sprint import source_context
from cavr_wbc.experiments.step30_sprint import missing, events
from cavr_wbc.experiments.step31_sprint import add_previous_command_identity
from cavr_wbc.experiments.step32_io import (ROOT, SOURCE30, RUN_ID, PARENT, MODEL_PARENT,
    PROTOCOL, METHODS, output, read, write, append, sha, relative, save_numeric, load_numeric)
from cavr_wbc.experiments.step32_budget import SprintBudget, SprintLimit
from cavr_wbc.control.step30_actions import GAMMA_GRID, make_action, prepare_shared
from cavr_wbc.control.step30_margin import load_bundle, labels, gamma_key
from cavr_wbc.control.step32_margin import build_delay_calibration, save_delay_calibration
from cavr_wbc.control.step32_kernel import Kernel
from cavr_wbc.platforms.go2_mujoco import extract_actuator_audit, extract_healthy_torque_limits

DEV_EPISODES = (('D32_P064', .064, 20261201), ('D32_N064', -.064, 20261201),
                ('D32_P068', .068, 20261202), ('D32_N068', -.068, 20261202))
TEST_EPISODES = (('T32_P063', .063, 20261211), ('T32_N063', -.063, 20261211),
                 ('T32_P069', .069, 20261212), ('T32_N069', -.069, 20261212))
DEV_TICKS = (30, 34, 38)
TEST_TICKS = (29, 33, 35, 37, 41)
GAPS = {29: .004, 33: .0045, 35: .005, 37: .005, 41: .006}


def plans(split):
    if split not in ('DEV', 'TEST'):
        raise ValueError('fixed DEV or TEST only')
    episodes, ticks, healthy = (DEV_EPISODES, DEV_TICKS, 34) if split == 'DEV' else (TEST_EPISODES, TEST_TICKS, 35)
    result = []
    snapshot_ordinal = 0
    for episode, displacement, seed in episodes:
        for tick in ticks:
            kinds = ('HEALTHY',) if tick == healthy else ('THIGH_15', 'CALF_15')
            order = METHODS if snapshot_ordinal % 2 == 0 else METHODS[::-1]
            for kind in kinds:
                result.append({'context_id': episode + f'_T{tick:03d}_' + kind,
                    'ordinal': len(result), 'snapshot_ordinal': snapshot_ordinal,
                    'method_order': list(order), 'role': kind.split('_')[0].lower(),
                    'health_kind': kind, 'episode': episode, 'split': split,
                    'snapshot_id': episode + f'_T{tick:03d}', 'tick': tick,
                    'direction': 1 if displacement > 0 else -1, 'seed': seed,
                    'gap_m': GAPS[tick] if split == 'TEST' else None})
            snapshot_ordinal += 1
    return result


def event(out, name, **fields):
    append(out / 'ATTEMPT_LEDGER.jsonl', {'event': name,
        'timestamp_utc': datetime.now(timezone.utc).isoformat(), **fields})


def attach_previous(c, episode):
    add_previous_command_identity(c, episode)
    identity = c['previous_command_identity']
    identity.update(previous_reference_tick=identity.get('applied_previous_reference_tick'),
                    source_snapshot=c['snapshot_id'],
                    health_vector=identity.get('source_health_vector'))
    c['previous_tau_sent'] = identity.get('tau_sent')


def save_branch(out, directory, name, branch, c):
    path = directory / name
    path.mkdir(parents=True, exist_ok=True)
    if branch.get('status') == 'NOT_RUN':
        lab = missing(branch.get('reason', 'NOT_RUN'))
        record = {**branch, 'label': lab, 'result_path': relative(path / 'RESULT.json', out)}
        write(path / 'RESULT.json', record)
        return record
    bank = save_bank(path / 'actual.npz', branch)
    lab = labels(branch, c)
    controls = branch['controls']
    write(path / 'CONTROL_RESULTS.json', {'controls': controls, 'status': branch['status'], 'reason': branch.get('reason')})
    first = controls[1]['capacity_interface'] if len(controls) > 1 else {}
    evt = events(branch, {'capacity_interface': first,
        'first_capacity_event': bool(first.get('sent_99_percent_active_indices'))})
    # First prehold is an identified prior command, not a new solved QP.
    timely = bool(len(controls) == 50 and all(row.get('valid_command') and float(row.get('latency_ms', 0.)) <= 20.
                                           for row in controls[1:]))
    record = {'status': branch['status'], 'reason': branch.get('reason'), 'label': lab,
        'artifact': bank, 'controls_path': relative(path / 'CONTROL_RESULTS.json', out),
        'result_path': relative(path / 'RESULT.json', out), 'gamma': branch.get('gamma'),
        'counts': branch['counts'], 'events': evt, 'all_tick_deadline_pass': timely,
        'tick_latency_ms': [row.get('latency_ms') for row in controls],
        'progress0_04_m': branch.get('progress0_04_m'), 'progress02_04_m': branch.get('progress02_04_m'),
        'first_tau_matches_packet': branch.get('first_tau_matches_packet'),
        'application_state_match': branch.get('application_state_match'),
        'application_identity_pass': branch.get('application_identity_pass', True),
        'application_identity_error': branch.get('application_identity_error', branch.get('identity_error')),
        'application_state_comparison': branch.get('application_state_check'),
        'application_state_actual': branch.get('application_state_actual'),
        'application_state_prediction': branch.get('application_state_prediction'),
        'backup_memory_restore': branch.get('backup_memory_restore'),
        'same_packet_cost_not_independent_baseline': name.startswith('COUNTERFACTUAL'),
        'actual_horizon_origin': 'SAMPLE', 'actual_horizon_s': 1.}
    write(path / 'RESULT.json', record)
    return record


def branch_once(out, directory, name, kernel, c, packet, budget, action=None, require_sent=True):
    event(out, 'START', kind=name, context_id=c['context_id'], method=packet['method'],
          gamma=packet.get('selected_gamma') if action is None else action['gamma'])
    branch = sim.propagate(kernel, c, packet, budget, purpose=name,
                           action=action, require_sent=require_sent)
    record = save_branch(out, directory, name, branch, c)
    event(out, 'RETURN', kind=name, context_id=c['context_id'], method=packet['method'],
          status=record['status'], counts=record.get('counts'), result_path=record['result_path'])
    budget.persist(phase='BRANCH_SAVED', context_id=c['context_id'], method=packet['method'], branch=name)
    if record['status'] == 'FAILED_BUDGET':
        raise SprintLimit('partial branch saved at numerical cap')
    if record.get('application_identity_error'):
        raise ValueError('saved application prediction/ACTUAL state identity mismatch')
    return record


def context_for(plan, snapshots, episode, mapping):
    source = snapshots.get(plan['tick'], {'snapshot_id': plan['snapshot_id'], 'episode_id': plan['episode'],
        'source_tick': plan['tick'], 'direction': plan['direction'], 'eligible': False,
        'eligibility_reason': 'REFERENCE_INCOMPLETE'})
    c = source_context(source, plan['health_kind'], mapping, plan['ordinal'], 'ID')
    c.update(backup_id='STEP32-' + c['context_id'], role=plan['role'], episode=plan['episode'],
             source_snapshot=plan['snapshot_id'], split=plan['split'], gap_m=plan['gap_m'],
             front_or_rear='front' if plan['direction'] > 0 else 'rear')
    if c['eligible']:
        attach_previous(c, episode)
    return c


def run_dev(out, model, manifest, kernels, budget):
    records = {method: [] for method in METHODS}
    registry = []
    for eid, displacement, seed in DEV_EPISODES:
        scenario = deepcopy(manifest['scenario'])
        scenario.update(seed=seed, initial_roll=scenario['initial_roll'] - .002,
                        initial_pitch=scenario['initial_pitch'] + .002)
        episode_path = out / 'episodes' / (eid + '.json')
        if episode_path.exists():
            episode = read(episode_path)
        else:
            episode = reference_episode(model, scenario, displacement, eid, DEV_TICKS, budget)
            write(episode_path, episode)
        snapshots = {s['source_tick']: s for s in episode['snapshots']}
        for plan in [p for p in plans('DEV') if p['episode'] == eid]:
            c = context_for(plan, snapshots, episode, manifest['mapping'])
            for method in plan['method_order']:
                directory = out / 'DEV' / c['context_id'] / method
                directory.mkdir(parents=True, exist_ok=True)
                packet_path = directory / 'PACKET.json'
                if packet_path.exists():
                    packet = load_numeric(packet_path)
                    event(out, 'REUSED_SAVED_PACKET', kind='DEV_COLLECTION', context_id=c['context_id'], method=method,
                          additional_QP_calls=0, additional_prediction_steps=0)
                else:
                    event(out, 'START', kind='DEV_COLLECTION', context_id=c['context_id'], method=method)
                    packet = kernels[method].collect_actions(c, budget, method) if c['eligible'] else {
                        'status': 'SOURCE_INELIGIBLE', 'method': method, 'actions': {}, 'prehold': {}}
                    numeric = save_numeric(packet_path, packet)
                    event(out, 'RETURN', kind='DEV_COLLECTION', context_id=c['context_id'], method=method,
                          status=packet['status'], numeric=numeric)
                for gamma in GAMMA_GRID:
                    entry = packet['actions'].get(str(gamma), {})
                    action = entry.get('action')
                    name = 'G' + gamma_key(gamma)
                    record = {'status': 'NOT_RUN', 'label': missing('SOURCE_OR_ACTION_UNAVAILABLE')}
                    if (directory / name / 'RESULT.json').exists():
                        record = read(directory / name / 'RESULT.json')
                    elif action and action.get('command_valid') and action.get('execution_eligible'):
                        record = branch_once(out, directory, name, kernels[method], c, packet, budget,
                                             action=action, require_sent=False)
                    item = {'id': c['context_id'] + ':' + method + ':G' + gamma_key(gamma),
                        'context': c, 'method': method, 'split': 'DEV', 'gamma': gamma, 'role': c['role'],
                        'episode': eid, 'source_snapshot': c['source_snapshot'],
                        'features26': entry.get('features26'), 'prefix': entry.get('prefix'),
                        'prehold': packet.get('prehold'), 'labels': record['label'],
                        'first_command_valid': bool(action and action.get('command_valid')),
                        'target_horizon_origin': 'SAMPLE', 'target_horizon_s': 1.}
                    cal_path = directory / (name + '_CAL_RECORD.json')
                    if cal_path.exists():
                        item = read(cal_path)
                    else:
                        write(cal_path, item)
                    records[method].append(item)
                    registry.append({'id': item['id'], 'context_id': c['context_id'], 'method': method,
                        'split': 'DEV', 'gamma': gamma, 'episode': eid, 'source_snapshot': c['source_snapshot'],
                        'status': record['status'], 'complete': record['label'].get('complete', False),
                        'path': relative(directory / (name + '_CAL_RECORD.json'), out),
                        'branch_result': record.get('result_path'), 'packet_path': relative(directory / 'PACKET.json', out)})
                    write(out / 'DEV_REGISTRY.json', registry)
                event(out, 'DONE', kind='DEV_CONTEXT_METHOD', context_id=c['context_id'], method=method)
                budget.persist(phase='DEV', context_id=c['context_id'], method=method, planned_actions_processed=len(registry))
                print({'phase': 'DEV', 'context': c['context_id'], 'method': method,
                       'actions_processed': len(registry), 'budget': budget.snapshot()}, flush=True)
            gc.collect()
    return records


def run_test(out, model, manifest, kernels, bundles, budget):
    registry = [{**p, 'status': 'NOT_RUN', 'eligible': None,
        'result_path': relative(out / 'queue' / p['context_id'] / 'RESULT.json', out)} for p in plans('TEST')]
    write(out / 'QUEUE_REGISTRY.json', registry)
    for eid, displacement, seed in TEST_EPISODES:
        scenario = deepcopy(manifest['scenario'])
        scenario.update(seed=seed, initial_roll=scenario['initial_roll'] - .002,
                        initial_pitch=scenario['initial_pitch'] + .002)
        episode = reference_episode(model, scenario, displacement, eid, TEST_TICKS, budget)
        write(out / 'episodes' / (eid + '.json'), episode)
        snapshots = {s['source_tick']: s for s in episode['snapshots']}
        for plan in [p for p in plans('TEST') if p['episode'] == eid]:
            c = context_for(plan, snapshots, episode, manifest['mapping'])
            directory = out / 'queue' / c['context_id']
            directory.mkdir(parents=True, exist_ok=True)
            result = {'context': c, 'plan': plan, 'context_id': c['context_id'],
                      'eligible': bool(c['eligible']), 'methods': {}, 'shadow_path': None}
            write(directory / 'RESULT.json', result)
            for method in plan['method_order']:
                d = directory / method
                d.mkdir(exist_ok=True)
                event(out, 'START', kind='ONLINE', context_id=c['context_id'], method=method,
                      ordinal=plan['ordinal'], snapshot_ordinal=plan['snapshot_ordinal'])
                packet = kernels[method].governor(c, bundles[method], c['gap_m'], budget, method) if c['eligible'] else {
                    'status': 'SOURCE_INELIGIBLE', 'selected_command_sent': False,
                    'method': method, 'selected_gamma': None, 'actions': {}}
                numeric = save_numeric(d / 'ONLINE_NUMERIC.json', packet)
                method_result = {'status': packet['status'], 'selected_sent': bool(packet.get('selected_command_sent')),
                    'selected_gamma': packet.get('selected_gamma'), 'command_ready_ms': packet.get('command_ready_ms'),
                    'online_numeric_path': relative(d / 'ONLINE_NUMERIC.json', out), 'online_numeric': numeric,
                    'branches': {}}
                result['methods'][method] = method_result
                write(directory / 'RESULT.json', result)
                event(out, 'RETURN', kind='ONLINE', context_id=c['context_id'], method=method,
                      status=packet['status'], sent=method_result['selected_sent'], command_ready_ms=method_result['command_ready_ms'])
                if method_result['selected_sent']:
                    method_result['branches']['ACTUAL'] = branch_once(out, d, 'ACTUAL', kernels[method], c, packet, budget)
                    write(directory / 'RESULT.json', result)
                    gamma = float(packet['selected_gamma'])
                    if method == 'ALIGNED_RECAL' and c['role'] != 'healthy' and 0. < gamma < 1.:
                        context = packet['context_used']
                        shared = prepare_shared(context, packet.get('C'), packet.get('B'))
                        for endpoint, g in (('C', 1.), ('B', 0.)):
                            action = make_action(context, packet.get('C'), packet.get('B'), g, workspace=shared)
                            name = 'COUNTERFACTUAL_' + endpoint
                            if action.get('command_valid') and action.get('execution_eligible'):
                                branch = branch_once(out, d, name, kernels[method], c, packet, budget, action=action)
                            else:
                                branch = {'status': 'NOT_RUN', 'reason': 'SAME_PACKET_ENDPOINT_UNAVAILABLE',
                                          'label': missing('SAME_PACKET_ENDPOINT_UNAVAILABLE')}
                                write(d / name / 'RESULT.json', branch)
                            method_result['branches'][name] = branch
                            write(directory / 'RESULT.json', result)
                if method == 'ALIGNED_RECAL' and c['role'] != 'healthy':
                    event(out, 'START', kind='CAPACITY_SHADOW', context_id=c['context_id'], method=method)
                    shadow = kernels[method].shadow(c, packet, budget) if c['eligible'] else {
                        'status': 'NOT_RUN', 'reason': 'SOURCE_INELIGIBLE', 'C': None, 'B': None}
                    asset = save_numeric(d / 'CAPACITY_SHADOW_NUMERIC.json', shadow)
                    summary = {'status': shadow['status'], 'reason': shadow.get('reason'),
                        'context_id': c['context_id'], 'episode': eid, 'numeric': asset,
                        'C': shadow_summary(shadow.get('C')), 'B': shadow_summary(shadow.get('B'))}
                    write(d / 'CAPACITY_SHADOW_RESULT.json', summary)
                    result['shadow_path'] = relative(d / 'CAPACITY_SHADOW_RESULT.json', out)
                    event(out, 'RETURN', kind='CAPACITY_SHADOW', context_id=c['context_id'], method=method, status=summary['status'])
                event(out, 'DONE', kind='TEST_CONTEXT_METHOD', context_id=c['context_id'], method=method)
                write(directory / 'RESULT.json', result)
                budget.persist(phase='TEST_METHOD', context_id=c['context_id'], method=method)
            registry[plan['ordinal']].update(status='DONE', eligible=bool(c['eligible']))
            write(out / 'QUEUE_REGISTRY.json', registry)
            event(out, 'DONE', kind='TEST_CONTEXT', context_id=c['context_id'], ordinal=plan['ordinal'])
            budget.persist(phase='TEST', processed=plan['ordinal'] + 1, last_context=c['context_id'])
            print({'phase': 'TEST', 'processed': plan['ordinal'] + 1, 'methods':
                {m: r['status'] for m, r in result['methods'].items()}, 'budget': budget.snapshot()}, flush=True)
            gc.collect()


def shadow_summary(item):
    if not item:
        return {'status': 'NOT_RUN', 'capacity_bound_effect': False}
    names = ('status', 'reason', 'solver_status_val', 'strict_solved_finite', 'original_bounded_feasible',
             'capacity_bound_effect', 'changed_row_indices', 'changed_channel_indices',
             'capacity_violation_nm', 'raw_margin_original_capacity_nm', 'original_raw_margin_nm',
             'same_except_injured_torque_bounds', 'new_QP_calls')
    return {k: item.get(k) for k in names}


def run(run_id=RUN_ID, repair=False):
    out = output(run_id)
    if (out / 'RUN_STARTED.json').exists() and not repair:
        raise FileExistsError('unique STEP32 numerical batch already started')
    for name in ('episodes', 'DEV', 'queue', 'calibration', 'figures'):
        (out / name).mkdir(parents=True, exist_ok=True)
    if not repair:
        write(out / 'RUN_STARTED.json', {'pid': os.getpid(), 'run_id': run_id,
            'start_utc': datetime.now(timezone.utc).isoformat(), 'immutable_limits': [7200, 25000, 250000]})
    budget = SprintBudget.resume_dev_repair(out) if repair else SprintBudget(out)
    budget.start()
    status = 'COMPLETED'
    try:
        t = perf_counter()
        source = read(SOURCE30 / 'MANIFEST.json')
        assets = read(SOURCE30 / 'models/MODEL_FREEZE.json')['assets']
        model = frozen.load_model()
        limits = extract_healthy_torque_limits(model)
        mapping = [dict(row, healthy_limit_nm=float(limits[row['actuator_index']])) for row in extract_actuator_audit(model)]
        manifest = {'run_id': run_id, 'source_commit': PARENT, 'model_source_commit': MODEL_PARENT,
            'protocol_sha256': sha(PROTOCOL), 'source_predictor': 'GEOMETRY_FULL_26/LOCAL',
            'model_assets': assets, 'new_regression_model_fits': 0, 'scenario': source['scenario'],
            'frozen_physical': source['frozen_physical'], 'mapping': mapping,
            'DEV': plans('DEV'), 'TEST': plans('TEST'), 'methods': METHODS,
            'DEV_max_action_trajectories': 200, 'TEST_contexts': 36, 'TEST_methods': 72,
            'max_QP': 25000, 'max_steps': 250000, 'max_wall_s': 7200,
            'deadline_ms': 20., 'max_single_QP_s': .006, 'horizon_origin': 'SAMPLE',
            'horizon_s': 1., 'prehold_s': .020, 'physics_dt_s': .002,
            'reference_roll_offset_rad': -.002, 'reference_pitch_offset_rad': .002,
            'no_E3_RL_hardware': True, 'historical_results_unchanged': True,
            'date': '2026-10-09', 'timezone': 'Asia/Seoul'}
        if not repair:
            write(out / 'MANIFEST.json', manifest)
            (out / 'PROTOCOL_SOURCE.md').write_bytes(PROTOCOL.read_bytes())
        original = load_bundle(SOURCE30 / 'models')
        dll = SOURCE30 / 'native/step30_prefix.dll'
        manifest.update(native_dll_path=str(dll), native_dll_sha256=sha(dll))
        kernels = {method: Kernel(model, 'BOUNDED', str(dll), budget) for method in METHODS}
        home = home_context(model, manifest['scenario'])
        home.update(context_id='STEP32_HOME', backup_id='STEP32_HOME')
        startup = {method: kernels[method].startup(home, budget) for method in METHODS}
        startup_name = 'repairs/STARTUP_REPAIR.json' if repair else 'STARTUP.json'
        write(out / startup_name, {'methods': startup, 'full_startup_ms': (perf_counter() - t) * 1000.})
        if not repair:
            write(out / 'MANIFEST.json', manifest)
        budget.persist(phase='STARTUP')
        dev = run_dev(out, model, manifest, kernels, budget)
        bundles = {method: build_delay_calibration(original, dev[method], method) for method in METHODS}
        cal_assets = {method: save_delay_calibration(bundles[method], out / 'calibration' / method) for method in METHODS}
        # Freeze numerical runtime, not later saved-only reporting/rendering.
        new_sources = [ROOT / name for name in (
            'cavr_wbc/control/step32_kernel.py', 'cavr_wbc/control/step32_margin.py',
            'cavr_wbc/experiments/step32_io.py', 'cavr_wbc/experiments/step32_budget.py',
            'cavr_wbc/experiments/step32_reference.py', 'cavr_wbc/experiments/step32_sprint.py',
            'cavr_wbc/experiments/step32_sim.py')]
        new_sources += sorted(ROOT.glob('tests/test_step32*.py'))
        write(out / 'STEP32_FREEZE.json', {'frozen_utc': datetime.now(timezone.utc).isoformat(),
            'config': manifest, 'calibration_assets': cal_assets,
            'new_runtime_code_sha256': {relative(p, ROOT): sha(p) for p in new_sources},
            'calibration_ids': {method: bundles[method]['calibration_id'] for method in METHODS},
            'DEV_ids': {method: [r['id'] for r in dev[method]] for method in METHODS},
            'freeze_count': 1, 'regression_model_fits': 0, 'TEST_read_for_CAL': False})
        del dev
        budget.persist(phase='DEV_AND_CODE_FROZEN')
        run_test(out, model, manifest, kernels, bundles, budget)
    except SprintLimit as exc:
        status = 'INCOMPLETE_BUDGET'
        write(out / 'INTERRUPTION.json', {'type': 'BUDGET', 'error': str(exc), 'budget': budget.snapshot()})
    except BaseException as exc:
        status = 'STOPPED_IMPLEMENTATION_OR_RESOURCE'
        write(out / 'INTERRUPTION.json', {'type': type(exc).__name__, 'error': str(exc),
            'traceback': traceback.format_exc(), 'budget': budget.snapshot()})
        raise
    finally:
        budget.event('NUMERICAL_FINISHED', status=status, **budget.snapshot())
        budget.close()
        write(out / 'RUN_FINISHED.json', {'run_id': run_id, 'status': status,
            'budget': budget.snapshot(), 'finish_utc': datetime.now(timezone.utc).isoformat()})
        print({'status': status, 'budget': budget.snapshot()}, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('run_id', nargs='?', default=RUN_ID)
    parser.add_argument('--dev-engineering-repair', action='store_true')
    args = parser.parse_args()
    run(args.run_id, args.dev_engineering_repair)
