"""One current-STEP32 delivery identity check; no solver or simulation imports."""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
RUN_ID = 'step32-application-time-20261009-01'
METHODS = ('STALE_RECAL', 'ALIGNED_RECAL')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + '\n', encoding='utf-8')


def verify(out):
    out = Path(out).resolve()
    expected = (ROOT / 'artifacts/step32_application_time_20261009').resolve()
    if out.parent != expected:
        raise ValueError('verification is scoped to one current STEP32 output directory')
    manifest = read(out / 'MANIFEST.json')
    freeze = read(out / 'STEP32_FREEZE.json')
    finish = read(out / 'RUN_FINISHED.json')
    result = read(out / 'STEP32_RESULT.json')
    checks = {}
    details = {}

    def check(name, condition):
        checks[name] = bool(condition)

    check('numeric_batch_completed', finish['status'] == 'COMPLETED')
    check('single_DEV_freeze_no_TEST_read', freeze['freeze_count'] == 1 and freeze['TEST_read_for_CAL'] is False)
    check('copied_protocol_bytes', sha(out / 'PROTOCOL_SOURCE.md') == manifest['protocol_sha256'])
    code = freeze['new_runtime_code_sha256']
    check('current_new_runtime_and_test_bytes_frozen', all(sha(ROOT / name) == digest for name, digest in code.items()))
    cal_assets = freeze['calibration_assets']
    check('distinct_method_CAL_ids', len(set(freeze['calibration_ids'].values())) == 2)
    check('new_CAL_bytes_frozen', all(sha(asset[kind]) == asset[kind + '_sha256']
          for asset in cal_assets.values() for kind in ('json', 'npz')))
    check('model_fits_zero', freeze['regression_model_fits'] == result['NEW_REGRESSION_MODEL_FITS'] == 0)
    cal = {method: read(cal_assets[method]['json']) for method in METHODS}
    check('matching_DEV20_CAL_population', all(len(cal[method]['cal_ids_all']) == 100 and
          set(cal[method]['cal_ids_all']) == set(freeze['DEV_ids'][method]) for method in METHODS))
    check('both_CAL_DEV_only', all(row['split'] == 'DEV' for asset in cal.values() for row in asset['delay_dev_registry']))
    check('frozen_applicability_identity_same_between_methods',
          cal[METHODS[0]]['source_predictor_identity'] == cal[METHODS[1]]['source_predictor_identity'])
    check('all_budget_constants_unchanged', (manifest['max_QP'], manifest['max_steps'], manifest['max_wall_s'],
          manifest['deadline_ms'], manifest['max_single_QP_s'], manifest['physics_dt_s'], manifest['prehold_s'],
          manifest['horizon_s']) == (25000, 250000, 7200, 20., .006, .002, .020, 1.))

    rows = [json.loads(line) for line in (out / 'STEP32_LEDGER.jsonl').read_text(encoding='utf-8').splitlines() if line.strip()]
    starts = [row for row in rows if row['event'] == 'QP_START']
    returns = [row for row in rows if row['event'] == 'QP_RETURN']
    native_starts = [row for row in rows if row['event'] == 'PREFIX_NATIVE_START']
    native_returns = [row for row in rows if row['event'] == 'PREFIX_NATIVE_RETURN']
    budget = finish['budget']
    check('QP_START_RETURN_contiguous_complete', [row['global_qp_index'] for row in starts] ==
          [row['global_qp_index'] for row in returns] == list(range(1, budget['total_QP_calls'] + 1)))
    check('QP_kind_counts_match', dict(Counter(row['kind'] for row in starts)) == budget['QP_by_kind'])
    check('all_QP_settings_at_most_6ms', all(row['osqp_time_limit_s'] <= .006 for row in returns))
    check('native_prediction_START_RETURN_identity', [row['reservation_id'] for row in native_starts] ==
          [row['reservation_id'] for row in native_returns])
    predicted = Counter()
    for row in native_returns:
        predicted[row['kind']] += row['actual_steps']
    check('native_steps_match_kind_totals', all(budget['physics_by_kind'][kind] == n for kind, n in predicted.items()))
    reference_steps = sum(read(path)['counts']['physical_steps'] for path in (out / 'episodes').glob('*.json'))
    actual_steps = sum(read(path).get('counts', {}).get('physical_steps', 0)
                       for path in (out / 'DEV').glob('*/*/*/RESULT.json'))
    actual_steps += sum(read(path).get('counts', {}).get('physical_steps', 0)
                        for path in (out / 'queue').glob('*/*/*/RESULT.json'))
    check('direct_and_prediction_physics_counts_match', reference_steps == budget['physics_by_kind']['REFERENCE'] and
          actual_steps == budget['physics_by_kind']['ACTUAL'] and reference_steps + actual_steps + sum(predicted.values()) == budget['total_physics_steps'])
    check('same_budget_under_caps_no_unknown', budget['total_QP_calls'] <= 25000 and budget['total_physics_steps'] <= 250000 and
          budget['numerical_elapsed_s'] <= 7200 and budget['unknown_native_returns'] == 0 and
          budget['uncompleted_native_step_reservations'] == 0 and budget['DEV_context_recomputations'] == 0)
    details['short_ledger'] = {'event_counts': dict(Counter(row['event'] for row in rows)),
          'QP_status_values': {str(status): n for status, n in Counter(row['status_val'] for row in returns).items()},
          'QP_by_kind': budget['QP_by_kind'], 'physics_by_kind': budget['physics_by_kind'],
          'QP_calls': len(starts), 'QP_returns': len(returns), 'physics_steps': budget['total_physics_steps']}

    registry = read(out / 'DEV_REGISTRY.json')
    check('DEV_200_fixed_action_denominator_preserved', len(registry) == 200 and
          all(sum(row['method'] == method for row in registry) == 100 for method in METHODS))
    queue = read(out / 'QUEUE_REGISTRY.json')
    check('TEST_36_fixed_queue_DONE', len(queue) == 36 and all(row['status'] == 'DONE' for row in queue))
    check('TEST_fixed_context_identity', [row['context_id'] for row in queue] == [row['context_id'] for row in manifest['TEST']])
    check('two_methods_per_context_once', all(set(read(out / 'queue' / plan['context_id'] / 'RESULT.json')['methods']) == set(METHODS)
          for plan in manifest['TEST']))
    attempts = [json.loads(line) for line in (out / 'ATTEMPT_LEDGER.jsonl').read_text(encoding='utf-8').splitlines() if line.strip()]
    online = [row for row in attempts if row['event'] == 'START' and row['kind'] == 'ONLINE']
    check('TEST_72_online_attempts_unique_no_retry', len(online) == len({(row['context_id'], row['method']) for row in online}) == 72)
    check('required_result_denominators', result['row_counts'] == {
          'QUEUE_RESULTS': 72, 'PAIRED_TIMING_RESULTS': 36, 'ACTION_EXTENSION_RESULTS': 32, 'CAPACITY_SHADOW_RESULTS': 32})
    check('one_DEV_repair_no_clock_reset', len(list((out / 'repairs').glob('REPAIR_*_STARTED.json'))) == 1 and
          read(out / 'repairs/REPAIR_01_STARTED.json')['budget_before']['numerical_started_utc'] == budget['numerical_started_utc'])
    original_failure = read(out / 'DEV/D32_P064_T030_THIGH_15/STALE_RECAL/G1/RESULT.json')
    check('initial_failed_DEV_prefix_retained', original_failure['status'] == 'FAILED_NUMERICAL' and original_failure['counts']['physical_steps'] == 20)
    check('necessary_fixture_tests_36_no_numerical_work', read(out / 'FINAL_NECESSARY_TESTS.json')['unique_final_test_cases'] == 36 and
          read(out / 'FINAL_NECESSARY_TESTS.json')['real_QP_calls'] == read(out / 'FINAL_NECESSARY_TESTS.json')['real_physics_steps'] == 0)

    write(out / 'SHORT_LEDGER_SUMMARY.json', details['short_ledger'])
    excluded = {'CURRENT_FILE_IDENTITY.json', 'DELIVERY_CHECK.json', 'DELIVERY_GIT_STATE.json'}
    files = sorted(path for path in out.rglob('*') if path.is_file() and path.name not in excluded)
    sources = sorted([*ROOT.glob('cavr_wbc/control/step32_*.py'), *ROOT.glob('cavr_wbc/experiments/step32_*.py'), *ROOT.glob('tests/test_step32*.py')])
    identities = {path.relative_to(ROOT).as_posix(): {'sha256': sha(path), 'size_bytes': path.stat().st_size} for path in files + sources}
    numeric_links = 0
    bank_links = 0
    errors = []
    for path in files:
        if path.suffix != '.json':
            continue
        document = read(path)
        if not isinstance(document, dict):
            continue
        if 'numeric_npz' in document:
            target = path.parent / document['numeric_npz']
            numeric_links += 1
            if sha(target) != document['numeric_sha256']:
                errors.append(path.relative_to(out).as_posix())
        artifact = document.get('artifact', {})
        if isinstance(artifact, dict) and artifact.get('path') and artifact.get('sha256'):
            target = Path(artifact['path'])
            # Never turn delivery into a historical evidence sweep.
            if out in target.resolve().parents:
                bank_links += 1
                if sha(target) != artifact['sha256']:
                    errors.append(path.relative_to(out).as_posix())
    check('current_saved_numeric_bank_hash_links', not errors)
    details['new_numeric_metadata_links'] = numeric_links
    details['new_trajectory_bank_links'] = bank_links
    details['declared_hash_errors'] = errors
    details['budget'] = budget
    details['scientific_statuses'] = {key: result[key] for key in ('A_STATUS', 'B_STATUS', 'C_STATUS')}
    details['scientific_run_status'] = result.get('SCIENTIFIC_RUN_STATUS')
    details['protocol_conformance'] = 'FAIL' if result.get('SCIENTIFIC_RUN_STATUS') == 'INVALID_PROTOCOL_CALIBRATION_GATE' else 'SEE_SCIENTIFIC_REPORT'
    identity = {'scope': 'Only current STEP32 new source/tests/output bytes; no old history hash sweep',
                'files': identities, 'excluded_self_or_postcommit_records': sorted(excluded)}
    write(out / 'CURRENT_FILE_IDENTITY.json', identity)
    delivery = {'status': 'PASS' if all(checks.values()) else 'FAIL',
                'scope': 'Saved evidence completeness/identity, not scientific acceptance or universal safety',
                'checked_utc': datetime.now(timezone.utc).isoformat(), 'checks': checks, 'details': details,
                'identity_manifest_sha256': sha(out / 'CURRENT_FILE_IDENTITY.json'),
                'numerical_calls_during_delivery': 0, 'historical_hash_sweep': False,
                'command': 'E:/CAVR-WBC/_runtime_step30/python311/python.exe -B -X utf8 -m cavr_wbc.experiments.step32_verify ' + out.name}
    write(out / 'DELIVERY_CHECK.json', delivery)
    return delivery


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('run_id', nargs='?', default=RUN_ID)
    argument = parser.parse_args().run_id
    out = Path(argument) if Path(argument).is_absolute() else ROOT / 'artifacts/step32_application_time_20261009' / argument
    check_result = verify(out)
    print(check_result['status'], {key: value for key, value in check_result['checks'].items() if not value})
    raise SystemExit(0 if check_result['status'] == 'PASS' else 1)
