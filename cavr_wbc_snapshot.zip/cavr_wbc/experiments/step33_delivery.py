"""Record scoped STEP33 Git state and deliver on a new ref, never reset HEAD."""
from datetime import datetime, timezone
import os
import subprocess
import sys
from cavr_wbc.experiments.step33_io import ROOT, PARENT, output, write, read, sha, relative

BRANCH = 'codex/step33-calibration-repair-20261009'
ORIGINAL_HEAD = '263a643c2cccfdc2d6a4fd5d3aa59bb29dd271d1'


def git(*args, stdin=None):
    process = subprocess.run(['git', '-c', 'core.autocrlf=false', *args], cwd=ROOT,
        input=stdin, text=True, encoding='utf-8', capture_output=True)
    if process.returncode:
        raise RuntimeError({'command': list(args), 'code': process.returncode, 'stdout': process.stdout, 'stderr': process.stderr})
    return process.stdout.strip()


def sources():
    return sorted([*ROOT.glob('cavr_wbc/control/step33_*.py'),
                   *ROOT.glob('cavr_wbc/experiments/step33_*.py'),
                   *ROOT.glob('tests/test_step33*.py')])


def record():
    out = output(); paths = [relative(path, ROOT) for path in sources()]
    root = relative(out.parent, ROOT)
    head = git('rev-parse', 'HEAD')
    if head != ORIGINAL_HEAD:
        raise ValueError('original HEAD changed; refuse expansive Git mutation')
    info = {'worktree': str(ROOT), 'source_parent': PARENT, 'delivery_branch': BRANCH,
        'original_HEAD': head, 'original_branch': git('symbolic-ref', '--short', 'HEAD'),
        'scope': [*paths, root], 'source_files': paths,
        'source_sha256': {relative(path, ROOT): sha(path) for path in sources()},
        'scoped_status_command': ['git', 'status', '--short', '--untracked-files=normal', '--', *paths, root],
        'scoped_status': git('status', '--short', '--untracked-files=normal', '--', *paths, root),
        'numeric_run_count': 1, 'necessary_test_suite_count': 1, 'delivery_check_count_planned': 1,
        'numerical_repairs': 0, 'regression_model_fits': 0,
        'commands': ['python -B -X utf8 -m cavr_wbc.experiments.step33_tests',
            'python -B -X utf8 -m cavr_wbc.experiments.step33_sprint step33-calibration-repair-20261009-01',
            'python -B -X utf8 -m cavr_wbc.experiments.step33_report',
            'python -B -X utf8 -m cavr_wbc.experiments.step33_figures',
            'python -B -X utf8 -m cavr_wbc.experiments.step33_verify'],
        'runtime': 'E:/CAVR-WBC/_runtime_step30/python311/python.exe',
        'PYTHONPATH': os.environ.get('PYTHONPATH'), 'temp_and_cache': 'E:/CAVR-WBC/_tmp_step33',
        'original_HEAD_reset': False, 'push': False, 'older_sources_or_results_staged': False,
        'new_branch_update_ref_option': 'git -c core.logAllRefUpdates=false update-ref',
        'repository_config_modified': False,
        'saved_utc': datetime.now(timezone.utc).isoformat()}
    write(out / 'STEP33_DELIVERY_METADATA.json', info)
    (out / 'STEP33_MODIFIED_FILES.md').write_text('# STEP33新增文件\n\n' + '\n'.join('- ' + p for p in paths) +
        '\n\n新增工件根：' + root + '。旧文件没有纳入提交范围。\n', encoding='utf-8')
    print({'recorded': len(paths), 'original_HEAD': head})


def commit():
    out = output(); check = read(out / 'tests/DELIVERY_CHECK.json')
    if check['status'] != 'PASS':
        raise ValueError('delivery check failed; no commit pretending verified')
    record()
    metadata = read(out / 'STEP33_DELIVERY_METADATA.json')
    ref = 'refs/heads/' + BRANCH
    if git('for-each-ref', '--format=%(objectname)', ref):
        raise FileExistsError('STEP33 delivery branch already exists')
    git('read-tree', PARENT)
    git('add', '--', *metadata['scope'])
    changed = git('diff', '--cached', '--name-only', PARENT).splitlines()
    allowed_sources = set(metadata['source_files']); prefix = relative(out.parent, ROOT) + '/'
    if any(path not in allowed_sources and not path.startswith(prefix) for path in changed):
        raise ValueError('scoped STEP33 index contains older or unrelated file')
    # Current diff only, no historical audit. All files are additions.
    # Preserve exactly the fixture bytes tested and hashed at DEV freeze.
    # One final empty line is disclosed, not an experimental/code repair.
    git('-c', 'core.whitespace=blank-at-eol,space-before-tab,cr-at-eol,-blank-at-eof', 'diff', '--cached', '--check', PARENT)
    evidence = {'parent': PARENT, 'branch': BRANCH, 'changed_files': changed,
        'file_count': len(changed), 'old_files_changed': [], 'scope_verified': True,
        'git_diff_check': 'PASS', 'original_HEAD': git('rev-parse', 'HEAD'),
        'whitespace_rule': 'blank-at-eol,space-before-tab,cr-at-eol,-blank-at-eof',
        'preserved_frozen_fixture_final_empty_line': 'tests/test_step33_kernel.py:383',
        'commit_strategy': 'read-tree isolated E-drive index; commit-tree parent; update-ref new branch',
        'push': False, 'original_HEAD_reset': False}
    write(out / 'STEP33_GIT_SCOPED_DIFF.json', evidence)
    git('add', '--', relative(out / 'STEP33_GIT_SCOPED_DIFF.json', ROOT))
    tree = git('write-tree')
    message = 'STEP33: repair per-query calibration, separate 100ms teacher, complete fixed online panel\n\n' + \
        'DEV 200 slots; TEST 36 paired inputs / 72 decisions; 0 timely sends and ACTUAL.\n' + \
        'A/B/C NOT_ESTABLISHED; preserve all numerical and physical failures.\n'
    commit_id = git('commit-tree', tree, '-p', PARENT, stdin=message)
    git('-c', 'core.logAllRefUpdates=false', 'update-ref', ref, commit_id, '0' * 40)
    if git('rev-parse', 'HEAD') != ORIGINAL_HEAD:
        raise ValueError('original HEAD unexpectedly moved')
    print({'commit': commit_id, 'branch': BRANCH, 'parent': PARENT, 'tree': tree,
        'files': len(git('diff-tree', '--no-commit-id', '--name-only', '-r', commit_id).splitlines()),
        'original_HEAD_unchanged': True, 'pushed': False})


if __name__ == '__main__':
    mode = sys.argv[1] if len(sys.argv) > 1 else 'record'
    if mode not in ('record', 'commit'):
        raise ValueError('record or commit only')
    (record if mode == 'record' else commit)()
