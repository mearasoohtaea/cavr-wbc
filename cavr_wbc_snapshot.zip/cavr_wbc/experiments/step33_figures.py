"""Exactly two SciPilot saved-data figures; no QP, physics, or fitting."""
from pathlib import Path
import importlib.util
import json
import warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from PIL import Image
from cavr_wbc.experiments.step33_io import output
from cavr_wbc.experiments.step33_report import read, write, csv_write, resolve, finite
from cavr_wbc.experiments.step26_features_storage import load_bank

SKILL = Path('C:/Users/ZhuanZ（无密码）/.codex/skills/scipilot-figure')
METHODS = ('STALE_RECAL', 'ALIGNED_RECAL')
NAMES = {'STALE_RECAL': 'STALE', 'ALIGNED_RECAL': 'ALIGNED'}
COLORS = {'STALE_RECAL': '#0072B2', 'ALIGNED_RECAL': '#D55E00'}
MARKERS = {'STALE_RECAL': 'o', 'ALIGNED_RECAL': 's'}
GAMMAS = (1., .75, .5, .25, 0.)
ROLE_COLORS = {'thigh': '#009E73', 'calf': '#CC79A7', 'healthy': '#555555'}
ROLE_MARKERS = {'thigh': '^', 'calf': 'o', 'healthy': 's'}


def helper(name):
    spec = importlib.util.spec_from_file_location('step33_' + name, SKILL / 'scripts' / (name + '.py'))
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod


def profile(out, queue, teacher, middle):
    module = helper('profile_data')
    for name, data in (('queue', queue), ('teacher', teacher), ('actual_middle', middle)):
        if data:
            scalar_data = [{key: value for key, value in row.items() if not isinstance(value, (dict, list, tuple, np.ndarray))} for row in data]
            info = module.profile_data(pd.DataFrame(scalar_data), group_cols=['method'])
            (out / ('EDA_' + name + '.md')).write_text(module.render_report(info), encoding='utf-8')
        else:
            (out / ('EDA_' + name + '.md')).write_text('No observed events. Missing is not a zero-valued trajectory.\n', encoding='utf-8')
    write(out / 'FIGURE_PLAN.json', {
        'skill': 'scipilot-figure-skill', 'publication': 'IEEE T-RO', 'figure_count': 2,
        'width_in': 7.16, 'raster_dpi': 600, 'minimum_font_pt': 8,
        'queue_n': len(queue), 'teacher_n': len(teacher), 'actual_middle_n': len(middle),
        'figure1': 'Full fixed-queue status matrix, paired timing dots, observed ACTUAL D/gap dots.',
        'figure2': 'Every actual injured-middle trajectory and safe-B comparison; all teacher D/Y points.',
        'rationale': 'Categorical identities remain separate; show distributions and missingness, not averages.',
        'alternatives': ['A mean bar would hide failures and missing trajectories.',
                         'A line between queue identities would imply continuity.',
                         'Selecting only successful middle events would change the denominator.'],
        'missing_policy': 'NOT_RUN/ABSTAIN/partial are retained; absent measurements never plotted as zero.',
        'numerical_calls': 0, 'fits': 0})


def style():
    helper('setup_style').setup_style(journal='ieee', lang='en', use_sciplots=False, constrained_layout=False)
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8,
        'axes.labelsize': 8, 'axes.titlesize': 9, 'xtick.labelsize': 8, 'ytick.labelsize': 8,
        'legend.fontsize': 8, 'pdf.fonttype': 42, 'svg.fonttype': 'none'})


def save(fig, out, stem):
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer(); bounds = fig.bbox
    outside = []
    from matplotlib.text import Text
    for text in fig.findobj(Text):
        if not text.get_visible() or not text.get_text():
            continue
        box = text.get_window_extent(renderer)
        if box.x0 < bounds.x0 - 2 or box.y0 < bounds.y0 - 2 or box.x1 > bounds.x1 + 2 or box.y1 > bounds.y1 + 2:
            outside.append(text.get_text())
    overlaps = []
    for i, ax in enumerate(fig.axes):
        for axis in (ax.xaxis, ax.yaxis):
            boxes = [(t.get_text(), t.get_window_extent(renderer)) for t in axis.get_ticklabels() if t.get_visible() and t.get_text()]
            for (a, x), (b, y) in zip(boxes, boxes[1:]):
                if x.overlaps(y):
                    overlaps.append({'axis': i, 'ticks': [a, b]})
    for ext in ('pdf', 'svg', 'png'):
        fig.savefig(out / (stem + '.' + ext), dpi=600, facecolor='white')
    fig.savefig(out / (stem + '_preview.png'), dpi=160, facecolor='white')
    with Image.open(out / (stem + '.png')) as src:
        src.convert('L').save(out / (stem + '_gray.png'), dpi=(600, 600))
    with Image.open(out / (stem + '_preview.png')) as src:
        src.convert('L').save(out / (stem + '_gray_preview.png'), dpi=(160, 160))
    checker = helper('check_figure')
    checks = {}
    for ext in ('pdf', 'svg', 'png'):
        issues, info = checker.check_figure(str(out / (stem + '.' + ext)), min_dpi=600)
        checks[ext] = {'issues': issues, 'info': info}
    result = {'text_outside_canvas': outside, 'adjacent_tick_overlaps': overlaps,
              'formats': checks, 'minimum_visible_font_pt': min(t.get_fontsize() for t in fig.findobj(Text) if t.get_visible() and t.get_text())}
    plt.close(fig)
    return result


def category(row):
    if not row['method_result_recorded']:
        return 'Not run', 'x', '#777777'
    if not row['timely_recognized_sent']:
        return 'No timely send', 'o', '#777777'
    if row['execution_confirmed']:
        return 'ACTUAL full pass', 's', '#0072B2'
    return 'ACTUAL failed / partial', '^', '#D55E00'


def queue_figure(out, queue, result):
    fig, axes = plt.subplots(3, 1, figsize=(7.16, 6.2), gridspec_kw={'height_ratios': [1.0, 1.5, 1.5]})
    fig.subplots_adjust(left=.105, right=.98, bottom=.115, top=.845, hspace=.7)
    fig.suptitle('STEP33 | full fixed repair queue', y=.975, fontsize=11)
    axes[0].set_title('a  All 36 inputs × two method slots', loc='left', pad=17)
    seen = {}
    for row in queue:
        label, marker, color = category(row); seen[label] = (marker, color)
        axes[0].scatter(row['ordinal'] + 1, METHODS.index(row['method']), marker=marker, s=26,
            facecolors='none' if marker in ('o', 's') else color, edgecolors=color, linewidths=.9)
    axes[0].set(ylim=(-.7, 1.7), yticks=(0, 1), yticklabels=['STALE', 'ALIGNED'])
    handles = [Line2D([], [], marker=m, color=c, markerfacecolor='none', linestyle='none', label=l) for l, (m, c) in seen.items()]
    fig.legend(handles=handles, loc='upper left', bbox_to_anchor=(.105, .942), ncol=2, frameon=False)
    axes[1].set_title('b  Observed command-ready time (startup excluded)', loc='left', pad=9)
    for j, method in enumerate(METHODS):
        rows = [r for r in queue if r['method'] == method and finite(r['command_ready_ms'])]
        axes[1].scatter([r['ordinal'] + 1 + (j - .5) * .18 for r in rows], [r['command_ready_ms'] for r in rows],
            marker=MARKERS[method], facecolors='none', edgecolors=COLORS[method], s=22, label=NAMES[method])
    axes[1].axhline(20, color='#222222', linestyle='--', linewidth=.8)
    axes[1].set(ylabel='Time (ms)', ylim=(0, max([23.] + [float(r['command_ready_ms']) * 1.18 for r in queue if finite(r['command_ready_ms'])])))
    axes[1].legend(loc='upper left', ncol=2, frameon=False)
    measured = sum(finite(r['command_ready_ms']) for r in queue)
    if not measured:
        axes[1].text(.5, .5, '0 formal decisions observed\nEndpoint diagnostics are reported separately', transform=axes[1].transAxes, ha='center')
    axes[2].set_title('c  Observed ACTUAL displacement / frozen local gap', loc='left', pad=9)
    actual = [r for r in queue if r['executed'] and finite(r['D_m'])]
    for j, method in enumerate(METHODS):
        rows = [r for r in actual if r['method'] == method]
        axes[2].scatter([r['ordinal'] + 1 + (j - .5) * .18 for r in rows], [r['D_m'] / r['gap_m'] for r in rows],
            marker=MARKERS[method], facecolors='none', edgecolors=COLORS[method], s=26)
    axes[2].axhline(1, color='#222222', linestyle='--', linewidth=.8)
    axes[2].set(ylabel='D / gap', xlabel='Source TEST ordinal + 1', ylim=(0, max([1.5] + [r['D_m'] / r['gap_m'] * 1.1 for r in actual])))
    if not actual:
        axes[2].text(.5, .46, 'No ACTUAL displacement exists\nMissing trajectories are not zero displacement', transform=axes[2].transAxes, ha='center')
    for ax in axes:
        ax.set_xlim(.4, 36.6); ax.set_xticks((1, 6, 12, 18, 24, 30, 36)); ax.grid(axis='y', color='#EEEEEE', linewidth=.5)
        for x in (9.5, 18.5, 27.5):
            ax.axvline(x, color='#DDDDDD', linewidth=.6, zorder=0)
    fig.text(.105, .02, f"Formal decisions {result['observed_formal_online_decisions']}/72; paired inputs {result['formal_panel_inputs_DONE']}/36; ACTUAL {sum(r['executed'] for r in queue)}", fontsize=8)
    return save(fig, out, 'STEP33_paired_queue')


def teacher_points(out, records):
    points = []
    for row in records:
        label = read(resolve(out, row['CAL_record_path']), {}).get('labels') or {}
        y = label.get('Y')
        points.append({**{key: row[key] for key in ('id', 'context_id', 'method', 'gamma', 'episode', 'complete_501', 'status')},
            'role': 'healthy' if row['context_id'].endswith('_HEALTHY') else 'thigh' if '_THIGH_' in row['context_id'] else 'calf',
            'D_mm': 1000. * label['D'] if finite(label.get('D')) else None,
            'max_abs_Y': max(abs(v) for v in y) if isinstance(y, list) and y and all(finite(v) for v in y) else None,
            'terminal_pass': row['terminal_pass_if_complete'], 'physical_pass': row['physical_pass_if_complete'],
            'source_snapshot': row['source_snapshot'], 'missing_label': not row['complete_501']})
    return points


def middle_figure(out, root, queue, teacher, extension, result):
    middle = [r for r in queue if r['injured_middle_event'] and r['executed']]
    fig, axes = plt.subplots(2, 2, figsize=(7.16, 6.0))
    fig.subplots_adjust(left=.10, right=.975, bottom=.195, top=.875, hspace=.85, wspace=.4)
    fig.suptitle('STEP33 | all injured-middle events and offline teacher targets', y=.973, fontsize=10)
    curves = []
    a, b, c, d = axes.flat
    a.set_title('a  Every ACTUAL middle trajectory', loc='left', pad=8)
    for row in middle:
        artifact = row.get('artifact') or {}
        if not artifact.get('path'):
            continue
        bank = load_bank(resolve(root, artifact['path']))
        facts = ([bank['initial_fact']] if bank.get('initial_fact') else []) + bank.get('physics_trajectory', [])
        facts = [f for f in facts if 'qpos' in f and 'time_s' in f]
        times = np.asarray([f['time_s'] for f in facts]); anchor = float(bank['fixed_anchor_q_init'][0])
        disp = np.asarray([row['direction'] * (f['qpos'][0] - anchor) * 1000. for f in facts])
        a.plot(times, disp, color=COLORS[row['method']], linestyle='-' if row['complete_501'] else '--', linewidth=.75, alpha=.8)
        curves.extend({'context_id': row['context_id'], 'method': row['method'], 'time_s': float(t), 'directional_x_mm': float(x), 'complete': row['complete_501']} for t, x in zip(times, disp))
    a.set(xlabel='Sample-relative time (s)', ylabel='Directional x (mm)', xlim=(0, 1))
    a.axvline(.02, color='#777777', linestyle=':', linewidth=.8); a.axvline(.04, color='#777777', linestyle=':', linewidth=.8)
    if not middle:
        a.text(.5, .53, '0 ACTUAL injured-middle events\nNo trajectory can be drawn', transform=a.transAxes, ha='center')
        a.set_ylim(-1, 1)
    else:
        a.legend(handles=[Line2D([], [], color=COLORS[m], label=NAMES[m]) for m in METHODS], frameon=False)
    b.set_title('b  Same-packet safe-B comparisons', loc='left', pad=8)
    available = [r for r in extension if r['comparison_available_safe_B']]
    for row in available:
        x = row['ordinal'] + 1
        gain = row['progress02_04_gain_m']
        b.scatter(x, gain * 1000., color='#0072B2' if row['strict_progress_gain'] else '#D55E00', marker='o', s=25)
    b.axhline(0, color='#777777', linestyle='--', linewidth=.8)
    b.set(xlabel='Source TEST ordinal + 1', ylabel='Middle − B progress (mm)', xlim=(.4, 36.6), xticks=(1, 12, 24, 36))
    if not available:
        b.text(.5, .53, '0 complete safe-B comparisons\nNo action-extension gain inferred', transform=b.transAxes, ha='center')
        b.set_ylim(-1, 1)
    c.set_title('c  All DEV teacher displacement targets', loc='left', pad=8)
    d.set_title('d  All DEV teacher terminal targets', loc='left', pad=8)
    for i, row in enumerate(teacher):
        x = GAMMAS.index(row['gamma']) + (METHODS.index(row['method']) - .5) * .36 + (i % 10 - 4.5) * .01
        for ax, key in ((c, 'D_mm'), (d, 'max_abs_Y')):
            if finite(row[key]):
                ax.scatter(x, row[key], color=ROLE_COLORS[row['role']], marker=ROLE_MARKERS[row['role']], s=13, alpha=.75,
                           facecolors='none' if row['physical_pass'] and row['terminal_pass'] else ROLE_COLORS[row['role']], linewidths=.55)
    for ax in (c, d):
        ax.set(xlim=(-.45, 4.45), xticks=range(5), xticklabels=('1', '.75', '.50', '.25', '0'), xlabel='Gamma (categorical)')
        ax.grid(axis='y', color='#EEEEEE', linewidth=.5)
    c.set_ylabel('D from original anchor (mm)'); c.set_ylim(bottom=0)
    d.set_ylabel('max |normalized terminal Y|'); d.set_ylim(0, 1.08)
    d.axhline(1, color='#777777', linestyle='--', linewidth=.8)
    finite_n = sum(finite(r['D_mm']) for r in teacher)
    fig.text(.10, .092, f"Teacher: {len(teacher)}/200 recorded; {finite_n} complete labels; {len(teacher)-finite_n} partial / unavailable (not zero).", fontsize=8)
    fig.text(.10, .063, 'Each Gamma: STALE left, ALIGNED right. Open = physical + terminal pass; filled = complete failure.', fontsize=8)
    handles = [Line2D([], [], marker=ROLE_MARKERS[role], linestyle='none', color=color, label=role.capitalize()) for role, color in ROLE_COLORS.items()]
    fig.legend(handles=handles, loc='lower center', bbox_to_anchor=(.53, .004), ncol=3, frameon=False)
    csv_write(out / 'ACTUAL_MIDDLE_TRAJECTORY_POINTS.csv', curves)
    return save(fig, out, 'STEP33_middle_events')


def run():
    root = output(); out = root / 'figures'; out.mkdir(exist_ok=True)
    queue = read(root / 'QUEUE_RESULTS.json', [])
    dev = read(root / 'DEV_OUTCOME_REASONS.json', [])
    extension = read(root / 'ACTION_EXTENSION_RESULTS.json', [])
    result = read(root / 'STEP33_RESULT.json')
    teacher = teacher_points(root, dev)
    middle = [r for r in queue if r['injured_middle_event'] and r['executed']]
    csv_write(out / 'QUEUE_POINT_DATA.csv', queue); csv_write(out / 'TEACHER_POINT_DATA.csv', teacher)
    csv_write(out / 'ACTUAL_MIDDLE_POINT_DATA.csv', middle)
    profile(out, queue, teacher, middle); style()
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        checks = {'paired_queue': queue_figure(out, queue, result),
                  'middle_events': middle_figure(out, root, queue, teacher, extension, result)}
    glyphs = [str(w.message) for w in caught if 'Glyph' in str(w.message) or 'missing from font' in str(w.message)]
    write(out / 'FIGURE_QA.json', {'figure_count': 2, 'missing_glyph_warnings': glyphs, 'programmatic': checks,
                                  'AI_visual_review': 'PENDING_PREVIEW_REVIEW', 'saved_only': True})
    print({'figures': 2, 'actual_middle_events': len(middle), 'teacher_rows': len(teacher), 'QA': checks})


if __name__ == '__main__':
    run()
