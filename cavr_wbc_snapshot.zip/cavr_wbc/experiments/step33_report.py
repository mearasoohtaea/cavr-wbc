"""Saved-only STEP33 paired application-time analysis; no numerical execution."""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
import json
import math
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
RUN_ID = 'step33-calibration-repair-20261009-01'
METHODS = ('STALE_RECAL', 'ALIGNED_RECAL')
MIDDLE = (.75, .5, .25)
BRANCHES = ('ACTUAL', 'COUNTERFACTUAL_C', 'COUNTERFACTUAL_B')
FAILURE_FIELDS = ('physical_failure', 'local_failure', 'terminal_failure', 'command_failure',
                  'numerical_incomplete', 'deadline_failure', 'application_identity_failure')


def finite(value):
    return isinstance(value, (int, float, np.integer, np.floating)) and not isinstance(value, (bool, np.bool_)) and math.isfinite(float(value))


def _restore(value):
    if isinstance(value, dict):
        if set(value) == {'nonfinite'}:
            return float(value['nonfinite'])
        return {key: _restore(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_restore(item) for item in value]
    return value


def _encode(value):
    if isinstance(value, np.ndarray):
        return _encode(value.tolist())
    if isinstance(value, np.generic):
        return _encode(value.item())
    if isinstance(value, float) and not math.isfinite(value):
        return {'nonfinite': repr(value)}
    if isinstance(value, dict):
        return {str(key): _encode(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_encode(item) for item in value]
    return value


def read(path, default=None):
    path = Path(path)
    return _restore(json.loads(path.read_text(encoding='utf-8'))) if path.exists() else default


def write(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    pending = path.with_name(path.name + '.step33-report.pending')
    pending.write_text(json.dumps(_encode(value), ensure_ascii=False, allow_nan=False, separators=(',', ':')) + '\n', encoding='utf-8', newline='\n')
    pending.replace(path)


def resolve(out, path):
    value = Path(path)
    return value if value.is_absolute() else Path(out) / value


def jsonl_rows(path):
    path = Path(path)
    if path.exists():
        with path.open(encoding='utf-8') as stream:
            for line in stream:
                if line.strip():
                    yield _restore(json.loads(line))


def csv_write(path, rows):
    rows = list(rows); path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with path.open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields); writer.writeheader()
        for row in rows:
            writer.writerow({key: json.dumps(_encode(value), ensure_ascii=False) if isinstance(value, (dict, list, tuple, np.ndarray)) else value for key, value in row.items()})


def numeric_record(path):
    """Restore saved numeric witnesses only; sparse problems remain mappings."""
    path = Path(path)
    document = read(path, {})
    if not document or not document.get('numeric_npz'):
        return {}
    with np.load(resolve(path.parent, document['numeric_npz']), allow_pickle=False) as archive:
        def restore(item):
            if isinstance(item, dict) and 'npz_key' in item:
                return archive[item['npz_key']].copy()
            if isinstance(item, dict):
                return {key: restore(value) for key, value in item.items()}
            if isinstance(item, list):
                return [restore(value) for value in item]
            return item
        return restore(document.get('record', {}))


def statistics(values):
    values = list(values); a = np.asarray([float(value) for value in values if finite(value)])
    return {'recorded': len(values), 'finite': len(a), 'missing_or_nonfinite': len(values) - len(a),
            **{name: float(np.percentile(a, percentile)) if len(a) else None for name, percentile in (('p50', 50), ('p95', 95), ('p99', 99))},
            'min': float(a.min()) if len(a) else None, 'max': float(a.max()) if len(a) else None}


def _fixed_plans():
    """Fallback preserves the full predeclared denominator after interruption."""
    gaps = {29: .004, 33: .0045, 35: .005, 37: .005, 41: .006}
    result = []
    for episode in ('T32_P063', 'T32_N063', 'T32_P069', 'T32_N069'):
        for tick in (29, 33, 35, 37, 41):
            for kind in (('HEALTHY',) if tick == 35 else ('THIGH_15', 'CALF_15')):
                result.append({'context_id': episode + f'_T{tick:03d}_' + kind, 'ordinal': len(result),
                    'episode': episode, 'snapshot_id': episode + f'_T{tick:03d}', 'tick': tick,
                    'role': kind.split('_')[0].lower(), 'health_kind': kind,
                    'direction': 1 if '_P' in episode else -1, 'gap_m': gaps[tick], 'split': 'TEST'})
    return result


def safe(label, gap):
    return bool(label.get('complete') and label.get('full_501_grid') is True and
                label.get('original_physical_safe') and label.get('terminal_pass') and label.get('command_valid_all') and
                finite(label.get('D')) and finite(gap) and 0. <= label['D'] <= gap)


def capacity_event(events):
    events = events or {}
    return bool(events.get('first_capacity_event') or events.get('first_active_indices') or
                events.get('any_actual_capacity99_event') or any(int(value) > 0 for value in events.get('capacity99_count_by_channel', [])))


def branch_facts(record, gap):
    record = record or {}; label = record.get('label') or {}; ticks = record.get('tick_latency_ms') or []
    status = record.get('status', 'NOT_RUN')
    counts = record.get('counts') or {}
    executed = bool(status != 'NOT_RUN' and (record.get('artifact') or ticks or counts.get('physical_steps', 0) or
                                           status in ('COMPLETE', 'FAILED_NUMERICAL', 'FAILED_BUDGET')))
    complete = bool(label.get('complete') and label.get('full_501_grid') is True)
    tick_pass = bool(complete and len(ticks) == 50 and all(finite(value) and 0. <= value <= 20. for value in ticks)
                     and record.get('all_tick_deadline_pass') is True)
    first_match = record.get('first_tau_matches_packet')
    identity = record.get('application_identity_pass')
    physical_failure = bool(executed and (label.get('original_failure') or label.get('observed_original_physical_failure') or
                                         (complete and not label.get('original_physical_safe'))))
    local_failure = bool(complete and finite(label.get('D')) and finite(gap) and label['D'] > gap)
    terminal_failure = bool(complete and not label.get('terminal_pass'))
    actual_safe = safe(label, gap)
    confirmed = bool(actual_safe and tick_pass and identity is True and first_match is True and
                     record.get('actual_horizon_origin') == 'SAMPLE' and record.get('actual_horizon_s') == 1.)
    return {'status': status, 'executed': executed, 'complete_501': complete,
        'physical_pass': bool(complete and label.get('original_physical_safe')), 'terminal_pass': bool(complete and label.get('terminal_pass')),
        'local_pass': bool(complete and finite(label.get('D')) and finite(gap) and 0. <= label['D'] <= gap),
        'actual_safe_at_fixed_gap': actual_safe, 'full_50_ticks_20ms': tick_pass, 'execution_confirmed': confirmed,
        'physical_failure': physical_failure, 'local_failure': local_failure, 'terminal_failure': terminal_failure,
        'command_failure': bool(complete and not label.get('command_valid_all')),
        'numerical_incomplete': bool(executed and not complete),
        'deadline_failure': bool(executed and (any(finite(value) and value > 20. for value in ticks) or
                                             (complete and not tick_pass))),
        'application_identity_pass': identity, 'application_identity_failure': bool(executed and identity is False),
        'first_tau_matches_packet': first_match,
        'observed_unsafe': bool(physical_failure or local_failure or terminal_failure),
        'known_complete_failure': bool(complete and (not actual_safe or not tick_pass or identity is not True or first_match is not True)),
        'late_ticks': sum(finite(value) and value > 20. for value in ticks), 'missing_or_nonfinite_ticks': sum(not finite(value) for value in ticks),
        'D_m': label.get('D'), 'Y': label.get('Y'), 'progress0_04_m': record.get('progress0_04_m'),
        'progress02_04_m': record.get('progress02_04_m'), 'tick_latency_ms': ticks,
        'capacity99_event': capacity_event(record.get('events')), 'first_packet_capacity99_event': bool((record.get('events') or {}).get('first_capacity_event')),
        'events': record.get('events'), 'counts': counts, 'artifact': record.get('artifact'),
        'controls_path': record.get('controls_path'), 'result_path': record.get('result_path'),
        'application_state_comparison': record.get('application_state_comparison'), 'reason': record.get('reason')}


def _shadow_endpoint(item, summary, context, limits):
    item = item or {}; summary = summary or {}
    status = item.get('status', summary.get('status', 'NOT_RUN'))
    tau = np.asarray(item.get('tau_shadow_raw', []), dtype=float)
    health = np.asarray(context.get('health_vector', []), dtype=float)
    limits = np.asarray(limits, dtype=float)
    changed_value = item.get('changed_channel_indices', summary.get('changed_channel_indices', []))
    rows_value = item.get('changed_row_indices', summary.get('changed_row_indices', []))
    changed = np.asarray([] if changed_value is None else changed_value, dtype=np.int64)
    rows = np.asarray([] if rows_value is None else rows_value, dtype=np.int64)
    z = np.asarray(item.get('z_shadow', []), dtype=float)
    dimensions = bool(tau.shape == health.shape == limits.shape == (12,) and np.isfinite(tau).all() and
                      np.isfinite(health).all() and np.isfinite(limits).all() and changed.ndim == 1 and rows.ndim == 1 and
                      len(changed) > 0 and len(changed) == len(rows) and np.all((changed >= 0) & (changed < 12)))
    violation = roundoff = None
    substantive = original_row_violation = False
    if dimensions:
        capacity = health * limits
        violation = np.maximum(np.abs(tau) - capacity, 0.)
        roundoff = 100. * np.finfo(float).eps * np.maximum.reduce([np.ones(12), np.abs(limits), np.abs(tau)])
        substantive = bool(np.any(violation[changed] > roundoff[changed]))
        row_pass = np.asarray((item.get('original_rows_check') or {}).get('row_pass', []), dtype=bool)
        original_row_violation = bool(len(rows) and row_pass.ndim == 1 and np.all((rows >= 0) & (rows < len(row_pass))) and np.any(~row_pass[rows]))
    strict = bool(item.get('strict_solved_finite', summary.get('strict_solved_finite')) is True and
                  item.get('solver_status_val', summary.get('solver_status_val')) == 1 and z.ndim == 1 and len(z) and np.isfinite(z).all())
    bounded = bool(item.get('original_bounded_feasible', summary.get('original_bounded_feasible')) is True)
    same = bool(item.get('same_except_injured_torque_bounds', summary.get('same_except_injured_torque_bounds')) is True)
    injured_rows = bool(dimensions and np.all(health[changed] < 1.))
    effect = bool(strict and bounded and same and injured_rows and substantive and original_row_violation)
    return {'status': status, 'reason': item.get('reason', summary.get('reason')),
        'strict_solved_finite': strict, 'solver_status_val': item.get('solver_status_val', summary.get('solver_status_val')),
        'original_bounded_feasible': bounded, 'same_except_injured_torque_bounds': same,
        'changed_channel_indices': changed.tolist(), 'changed_row_indices': rows.tolist(),
        'capacity_bound_effect': effect, 'saved_capacity_bound_effect': item.get('capacity_bound_effect', summary.get('capacity_bound_effect')),
        'substantive_capacity_violation': substantive, 'original_capacity_row_violation': original_row_violation,
        'capacity_violation_nm': None if violation is None else violation.tolist(),
        'floating_roundoff_bound_nm': None if roundoff is None else roundoff.tolist(),
        'raw_margin_original_capacity_nm': item.get('raw_margin_original_capacity_nm', summary.get('raw_margin_original_capacity_nm')),
        'original_raw_margin_nm': item.get('original_raw_margin_nm', summary.get('original_raw_margin_nm')),
        'shadow_minus_original_tau_nm': item.get('shadow_minus_original_tau_nm'),
        'original_dual_available': item.get('original_dual') is not None,
        'new_QP_calls': item.get('new_QP_calls', summary.get('new_QP_calls', 0)), 'actuated': False}


def _summary(rows, denominator):
    sent = sum(row['timely_recognized_sent'] for row in rows)
    passed = sum(row['execution_confirmed'] for row in rows)
    return {'planned': denominator, 'recorded_method_results': sum(row['method_result_recorded'] for row in rows),
        'eligible': sum(row['eligible'] for row in rows), 'timely_recognized_sent': sent,
        'recognition_rate_planned': sent / denominator if denominator else None,
        'ACTUAL_executed': sum(row['executed'] for row in rows), 'complete_501': sum(row['complete_501'] for row in rows),
        'actual_safe_at_fixed_gap': sum(row['actual_safe_at_fixed_gap'] for row in rows),
        'terminal_pass': sum(row['terminal_pass'] for row in rows), 'full_50_ticks_20ms': sum(row['full_50_ticks_20ms'] for row in rows),
        'execution_confirmed': passed, 'success_rate_planned': passed / denominator if denominator else None,
        'conditional_success_rate_sent': passed / sent if sent else None,
        'injured_middle_sent': sum(row['injured_middle_event'] for row in rows),
        'incorrect_recognition_count': sum(row['timely_recognized_sent'] and not row['execution_confirmed'] for row in rows),
        'known_observed_unsafe_accepts': sum(row['timely_recognized_sent'] and row['observed_unsafe'] for row in rows),
        'sent_actual_NOT_RUN_or_missing': sum(row['timely_recognized_sent'] and not row['executed'] for row in rows),
        'not_sent': sum(not row['timely_recognized_sent'] for row in rows),
        'online_late_or_missing_time_sent': sum(row['selected_sent'] and not row['timely_recognized_sent'] for row in rows),
        'online_deadline_exceeded': sum(finite(row['command_ready_ms']) and row['command_ready_ms'] > 20. for row in rows),
        'statuses': dict(Counter(row['online_status'] for row in rows)),
        'actual_statuses': dict(Counter(row['status'] for row in rows)),
        **{name: sum(row[name] for row in rows) for name in FAILURE_FIELDS},
        'capacity99_actual_contexts': sum(row['capacity99_event'] for row in rows),
        'first_packet_capacity99_contexts': sum(row['first_packet_capacity99_event'] for row in rows),
        'command_ready_ms': statistics(row['command_ready_ms'] for row in rows),
        'all_actual_tick_ms': statistics(value for row in rows for value in row['tick_latency_ms'])}


def _branch_from(method_result, out, name):
    record = (method_result.get('branches') or {}).get(name) or {}
    # Streamed context result is authoritative; standalone file supplements an
    # interruption occurring after branch persistence but before index update.
    if not record and method_result.get('online_numeric_path'):
        path = resolve(out, method_result['online_numeric_path']).parent / name / 'RESULT.json'
        record = read(path, {})
    return record


def _packet_metadata(path):
    """JSON scalar metadata; no online inference or numeric witness replay."""
    return (read(path, {}) or {}).get('record', {})


def _saved_length(value):
    if isinstance(value, dict) and 'npz_key' in value:
        return int(value.get('shape', [0])[0]) if value.get('shape') else 0
    return len(value) if isinstance(value, (list, tuple, np.ndarray)) else 0


def _reason_code(value):
    if isinstance(value, dict):
        return value.get('reason') or value.get('status') or 'SAVED_REASON_MAPPING'
    return str(value) if value is not None else None


def _calibration_diagnostics(out, plans):
    rows, affected = [], []
    for method in METHODS:
        path = out / 'calibration' / method / ('step33_delay_cal_' + method.lower() + '.json')
        document = read(path, {})
        rule = document.get('local_cal_rule') or {}
        for group_id, group in (document.get('groups') or {}).items():
            gamma, role = group_id.split(':', 1)
            snapshots = group.get('cal_distinct_source_snapshots', 0)
            episodes = group.get('cal_episode_count', 0)
            missing = group.get('cal_missing_input_count', 0)
            minimum = bool(document.get('trained') and snapshots >= 4 and episodes >= 2)
            additional_guard = bool(rule.get('missing_feature_group_rejects') and missing > 0)
            only_additional = bool(minimum and additional_guard and not group.get('local_calibrated'))
            matching = [p['context_id'] for p in plans if p['role'] == role]
            row = {'method': method, 'group_id': group_id, 'gamma': float(gamma), 'role': role,
                'planned_CAL': group.get('cal_planned_count', 0), 'finite_CAL': group.get('cal_finite_count', 0),
                'complete_CAL': group.get('cal_complete_count', 0), 'complete_distinct_snapshots': snapshots,
                'complete_episodes': episodes, 'missing_features': missing,
                'incomplete_finite_labels': len(group.get('cal_incomplete_ids', [])),
                'complete_physical_failures': group.get('cal_failed_physical_count', 0),
                'complete_terminal_failures': group.get('cal_failed_terminal_count', 0),
                'local_calibrated_saved': bool(group.get('local_calibrated')),
                'original_static_minimum_met': minimum,
                'original_static_minimum_failed': not minimum,
                'additional_global_missing_feature_guard': additional_guard,
                'disabled_solely_by_additional_group_guard_at_static_stage': only_additional,
                'matched_TEST_contexts': matching,
                'saved_CAL_path': str(path),
                'input_missing_ids': group.get('cal_missing_input_ids', [])}
            rows.append(row)
            if only_additional:
                affected.append(row)
    return rows, {'status': 'CORRECTED_PER_QUERY_LOCAL',
        'extra_missing_feature_group_gate_removed': True,
        'selected_incomplete_neighbors_reject': True,
        'new_regression_fits': 0, 'old_STEP32_status': 'INVALID_PROTOCOL_CALIBRATION_GATE'}


def _online_diagnostics(out, method_rows):
    rows, action_rows, summaries = [], [], {}
    for method in METHODS:
        selected = method_rows[method]
        cal_path = out / 'calibration' / method / ('step33_delay_cal_' + method.lower() + '.npz')
        cal_meta = read(cal_path.with_suffix('.json'), {})
        cal_arrays = {}
        if cal_path.exists():
            with np.load(cal_path, allow_pickle=False) as archive:
                for key, group in (cal_meta.get('groups') or {}).items():
                    prefix = group['array_prefix']
                    cal_arrays[key] = (archive[prefix + 'cal_complete'].copy(),
                                       archive[prefix + 'cal_residual'].copy())
        for row in selected:
            packet_path = resolve(out, row['online_numeric_path']) if row.get('online_numeric_path') else out / 'queue' / row['context_id'] / method / 'ONLINE_NUMERIC.json'
            packet = numeric_record(packet_path)
            qualified = _saved_length(packet.get('qualified_gammas'))
            C = packet.get('C') or {}; B = packet.get('B') or {}
            lookup_count = sum(item.get('evaluation_status') == 'EVALUATED' for item in (packet.get('actions') or {}).values())
            detail = {'context_id': row['context_id'], 'method': method, 'role': row['role'], 'episode': row['episode'],
                'planned_gamma_actions': 5, 'status': row['online_status'], 'eligible': row['eligible'],
                'command_ready_ms': row['command_ready_ms'], 'selected_sent': row['selected_sent'],
                'sent_gamma': row['selected_gamma'] if row['selected_sent'] else None,
                'diagnostic_last_gamma': row['selected_gamma'],
                'qualified_gamma_count': qualified,
                'primary_saved_path_reason': 'NO_QUALIFIED_DELAY_CAL_ACTION' if qualified == 0 else packet.get('reason'),
                'C_solver_status_val': C.get('solver_status_val'), 'C_solver_status': C.get('solver_status'),
                'C_command_valid': bool(C.get('command_valid')), 'B_saved_status': B.get('status'),
                'B_solver_status_val': B.get('solver_status_val'),
                'prehold_complete': (packet.get('prehold') or {}).get('complete'),
                'application_prediction_complete': (packet.get('application_prediction') or {}).get('complete'),
                'numeric_lookup_evaluated_actions': lookup_count,
                'support_pose_distance_local_terminal_lookup_status': 'NOT_EVALUATED' if lookup_count == 0 else 'SEE_SAVED_ACTION_DECISIONS',
                'online_packet_path': str(packet_path)}
            rows.append(detail)
            for gamma in (1., .75, .5, .25, 0.):
                entry = (packet.get('actions') or {}).get(str(float(gamma)), {})
                action = entry.get('action') or {}
                decision = entry.get('decision') or {}
                numeric = decision.get('numeric') or {}
                local = np.asarray(numeric.get('local_cal_indices', []), dtype=int)
                local = local[local >= 0]
                group_key = str(float(gamma)).rstrip('0').rstrip('.') + ':' + row['role']
                complete, residual = cal_arrays.get(group_key, (np.empty(0, dtype=bool), np.empty((0, 6))))
                local_valid = bool(len(local) and np.all(local < len(complete)))
                incomplete = bool(local_valid and not np.all(complete[local]))
                nonfinite = bool(local_valid and not np.isfinite(residual[local]).all())
                action_rows.append({'context_id': row['context_id'], 'method': method, 'gamma': gamma,
                    'evaluation_status': entry.get('evaluation_status', 'NOT_RECORDED'),
                    'command_valid_saved': action.get('command_valid'),
                    'unavailable_reason': action.get('unavailable_reason'),
                    'lookup_evaluated': entry.get('evaluation_status') == 'EVALUATED',
                    'features_recorded': entry.get('features26') is not None,
                    'local_cal_indices': local.tolist(), 'selected_incomplete_local_neighbor': incomplete,
                    'selected_nonfinite_local_residual': nonfinite,
                    'query_rejected': not bool(decision.get('accepted')),
                    'U_D_m': numeric.get('U_D'), 'U_T': numeric.get('U_T'),
                    **{gate: numeric.get(gate) for gate in ('finite_input', 'support_gate', 'pose_gate', 'distance_gate', 'calibration_gate')},
                    'local_margin_pass': bool(finite(numeric.get('U_D')) and numeric['U_D'] <= row['gap_m']),
                    'terminal_margin_pass': bool(numeric.get('U_T') is not None and np.isfinite(numeric['U_T']).all() and np.all(np.asarray(numeric['U_T']) <= 1.)),
                    'online_packet_path': str(packet_path)})
        details = [item for item in rows if item['method'] == method]
        actions = [item for item in action_rows if item['method'] == method]
        summaries[method] = {'planned': 36, 'recorded': len(details), 'planned_gamma_actions': 180,
            'zero_qualified_gammas': sum(item['qualified_gamma_count'] == 0 for item in details),
            'B_NOT_CALIBRATED_not_requested': sum(item['B_saved_status'] == 'NOT_CALIBRATED' for item in details),
            'numeric_lookup_not_evaluated_contexts': sum(item['numeric_lookup_evaluated_actions'] == 0 for item in details),
            'C_solver_statuses': dict(Counter(str(item['C_solver_status_val']) for item in details)),
            'C_valid_commands': sum(item['C_command_valid'] for item in details),
            'prehold_complete': sum(item['prehold_complete'] is True for item in details),
            'prediction_complete': sum(item['application_prediction_complete'] is True for item in details),
            'action_evaluation_statuses': dict(Counter(item['evaluation_status'] for item in actions)),
            'selected_incomplete_LOCAL_queries': sum(item['selected_incomplete_local_neighbor'] for item in actions),
            'selected_nonfinite_residual_LOCAL_queries': sum(item['selected_nonfinite_local_residual'] for item in actions),
            'evaluated_query_rejection_gates': {gate: sum(item['lookup_evaluated'] and not item.get(gate) for item in actions)
                for gate in ('finite_input', 'support_gate', 'pose_gate', 'distance_gate', 'calibration_gate', 'local_margin_pass', 'terminal_margin_pass')},
            'qualified_empty_is_prior_to_model_support_lookup': True,
            'gamma1_COMMAND_UNAVAILABLE_may_mean_no_prefix_requested_not_C_QP_failed': True,
            'no_send_is_not_physical_safe_or_unsafe': True}
    return rows, action_rows, summaries


def _dev_diagnostics(out, records):
    rows, summaries, packets = [], {}, {}
    for entry in records:
        cal = read(resolve(out, entry['path']), {}) if entry.get('path') else {}
        branch = read(resolve(out, entry['branch_result']), {}) if entry.get('branch_result') else {}
        label = branch.get('label') or cal.get('labels') or {}
        packet_path = resolve(out, entry['packet_path']) if entry.get('packet_path') else None
        if packet_path is not None and str(packet_path) not in packets:
            packets[str(packet_path)] = _packet_metadata(packet_path)
        packet = packets.get(str(packet_path), {})
        action_entry = (packet.get('actions') or {}).get(str(float(entry['gamma'])), {})
        action = action_entry.get('action') or {}
        reason = branch.get('reason') or label.get('reason')
        complete = bool(label.get('complete') and label.get('full_501_grid') is True)
        observed = bool(label.get('observed_original_physical_failure') or label.get('original_failure') or (complete and not label.get('original_physical_safe')))
        physical_reason = label.get('original_failure') or {}
        physical_types = physical_reason.get('reasons', []) if isinstance(physical_reason, dict) else [str(physical_reason)]
        features = cal.get('features26')
        rows.append({'id': entry.get('id'), 'context_id': entry.get('context_id'), 'method': entry.get('method'),
            'gamma': entry.get('gamma'), 'episode': entry.get('episode'), 'source_snapshot': entry.get('source_snapshot'),
            'status': entry.get('status', 'NOT_RUN'), 'propagated': bool(branch and entry.get('status') != 'NOT_RUN'),
            'complete_501': complete, 'feature26_available': bool(isinstance(features, list) and len(features) == 26 and all(finite(x) for x in features)),
            'packet_action_status': action_entry.get('evaluation_status'),
            'unavailable_reason': action.get('unavailable_reason'), 'reason': _reason_code(reason),
            'failed_solver_status_val': reason.get('solver_status_val') if isinstance(reason, dict) else None,
            'failed_solver_status': reason.get('solver_status') if isinstance(reason, dict) else None,
            'C_solver_status_val': (packet.get('C') or {}).get('solver_status_val'),
            'B_solver_status_val': (packet.get('B') or {}).get('solver_status_val'),
            'physical_pass_if_complete': bool(complete and label.get('original_physical_safe')),
            'observed_physical_failure': observed, 'physical_failure_if_complete': bool(complete and not label.get('original_physical_safe')),
            'terminal_pass_if_complete': bool(complete and label.get('terminal_pass')),
            'terminal_failure_if_complete': bool(complete and not label.get('terminal_pass')),
            'partial_terminal_false_is_not_known_terminal_failure': bool(not complete),
            'original_physical_failure': label.get('original_failure'),
            'observed_physical_failure_types': physical_types,
            'physical_steps_recorded': (branch.get('counts') or {}).get('physical_steps', 0),
            'teacher_tick_latency_ms': branch.get('tick_latency_ms', []),
            'teacher_ticks_over_20ms': sum(finite(value) and value > 20 for value in branch.get('tick_latency_ms', [])),
            'CAL_record_path': entry.get('path'), 'branch_result_path': entry.get('branch_result'),
            'packet_path': entry.get('packet_path')})
    for method in METHODS:
        selected = [row for row in rows if row['method'] == method]
        missing = [row for row in selected if row['status'] == 'NOT_RUN']
        partial = [row for row in selected if row['propagated'] and not row['complete_501']]
        summaries[method] = {'planned': 100, 'recorded': len(selected),
            'propagated': sum(row['propagated'] for row in selected),
            'complete_501': sum(row['complete_501'] for row in selected), 'partial': len(partial),
            'finite_feature_rows': sum(row['feature26_available'] for row in selected),
            'missing_feature_rows': sum(not row['feature26_available'] for row in selected),
            'teacher_ticks_over_20ms': sum(row['teacher_ticks_over_20ms'] for row in selected),
            'teacher_tick_latency_ms': statistics(value for row in selected for value in row['teacher_tick_latency_ms']),
            'statuses': dict(Counter(row['status'] for row in selected)),
            'NOT_RUN_reasons': dict(Counter(row['unavailable_reason'] or row['reason'] or row['packet_action_status'] or 'NOT_RECORDED' for row in missing)),
            'NOT_RUN_packet_action_statuses': dict(Counter(row['packet_action_status'] or 'NOT_RECORDED' for row in missing)),
            'partial_raw_solver_statuses': dict(Counter(str(row['failed_solver_status_val']) for row in partial)),
            'partial_raw_solver_status_names': dict(Counter(row['failed_solver_status'] or 'NOT_RECORDED' for row in partial)),
            'physical_pass_complete': sum(row['physical_pass_if_complete'] for row in selected),
            'physical_failure_complete': sum(row['physical_failure_if_complete'] for row in selected),
            'observed_physical_failure_in_partial': sum(row['observed_physical_failure'] for row in partial),
            'first_observed_physical_reason_counts': dict(Counter(reason for row in selected for reason in row['observed_physical_failure_types'])),
            'terminal_pass_complete': sum(row['terminal_pass_if_complete'] for row in selected),
            'terminal_failure_complete': sum(row['terminal_failure_if_complete'] for row in selected),
            'missing_or_partial_labels_not_zero_filled': True}
    return rows, summaries


def _shadow_diagnostics(rows):
    result = {}
    for endpoint in ('C', 'B'):
        result[endpoint] = {'planned_injured_contexts': 32,
            'statuses': dict(Counter(row[endpoint + '_status'] for row in rows)),
            'strict_solved_finite': sum(row[endpoint + '_strict_solved_finite'] for row in rows),
            'capacity_bound_effect': sum(row[endpoint + '_capacity_bound_effect'] for row in rows),
            'original_bounded_feasible': sum(row[endpoint + '_original_bounded_feasible'] for row in rows),
            'original_feasible_no_substantive_capacity_violation': sum(row[endpoint + '_strict_solved_finite'] and row[endpoint + '_original_bounded_feasible'] and not row[endpoint + '_substantive_capacity_violation'] for row in rows),
            'substantive_violation_but_original_not_confirmed_feasible': sum(row[endpoint + '_substantive_capacity_violation'] and not row[endpoint + '_original_bounded_feasible'] for row in rows),
            'NOT_RUN_reasons': dict(Counter(row[endpoint + '_reason'] or 'NOT_RECORDED' for row in rows if row[endpoint + '_status'] == 'NOT_RUN')),
            'new_shadow_QP_calls': sum(row[endpoint + '_new_QP_calls'] or 0 for row in rows)}
    return result


def report(out):
    out = Path(out).resolve(); manifest = read(out / 'MANIFEST.json', {})
    finished = read(out / 'RUN_FINISHED.json', {})
    plans = manifest.get('TEST') or _fixed_plans()
    rows, branches, paired, extension_rows, shadow_rows = [], [], [], [], []
    method_rows = defaultdict(list)
    successful_middle, paired_improvement, extension_contexts, capacity_contexts = [], [], [], []
    limits = np.zeros(12)
    mapping = manifest.get('mapping') or []
    for item in mapping:
        index = item.get('actuator_index')
        if isinstance(index, int) and 0 <= index < 12 and finite(item.get('healthy_limit_nm')):
            limits[index] = float(item['healthy_limit_nm'])
    limits_available = bool(len(mapping) == 12 and np.all(limits > 0.))
    for plan in plans:
        result_path = out / 'queue' / plan['context_id'] / 'RESULT.json'
        result = read(result_path, {}); context = result.get('context') or {}
        gap = plan['gap_m']; facts, per_method = {}, {}
        metadata = {'context_id': plan['context_id'], 'ordinal': plan['ordinal'], 'episode': plan['episode'],
            'source_snapshot': plan.get('snapshot_id'), 'tick': plan['tick'], 'role': plan['role'],
            'health_kind': plan.get('health_kind'), 'direction': plan['direction'],
            'front_or_rear': 'front' if plan['direction'] > 0 else 'rear', 'injured': plan['role'] != 'healthy',
            'gap_m': gap, 'eligible': bool(context.get('eligible', result.get('eligible', False))),
            'result_path': str(result_path)}
        for method in METHODS:
            m = (result.get('methods') or {}).get(method) or {}
            actual = _branch_from(m, out, 'ACTUAL'); fact = branch_facts(actual, gap)
            ready = m.get('command_ready_ms'); sent = bool(m.get('selected_sent'))
            timely = bool(sent and finite(ready) and 0. <= ready <= 20.)
            gamma = m.get('selected_gamma')
            middle = bool(timely and metadata['injured'] and gamma in MIDDLE)
            row = {**metadata, 'method': method, 'method_result_recorded': bool(m),
                'online_status': m.get('status', 'NOT_RUN'), 'selected_sent': sent, 'timely_recognized_sent': timely,
                'selected_gamma': gamma, 'gamma': gamma, 'command_ready_ms': ready,
                'sent_gamma': gamma if sent else None, 'diagnostic_last_gamma': gamma,
                'selected_gamma_semantics': 'SENT_PACKET' if sent else 'LAST_DIAGNOSTIC_ACTION_NOT_APPROVED',
                'injured_middle_event': middle, 'online_numeric_path': m.get('online_numeric_path'), **fact}
            # A physical rollout alone cannot validate a packet that was not
            # timely recognized and sent by this method's actual decision.
            row['execution_confirmed'] = bool(timely and row['execution_confirmed'])
            rows.append(row); method_rows[method].append(row); per_method[method] = row
            facts[method] = {}
            for name in BRANCHES:
                f = branch_facts(_branch_from(m, out, name), gap)
                facts[method][name] = f
                branches.append({**metadata, 'method': method, 'branch': name,
                    'expected_by_trigger': timely if name == 'ACTUAL' else method == 'ALIGNED_RECAL' and middle,
                    'selected_gamma': gamma, **f})
        stale = per_method['STALE_RECAL']; aligned = per_method['ALIGNED_RECAL']
        pair_improvement = bool(aligned['injured_middle_event'] and aligned['execution_confirmed'] and stale['timely_recognized_sent'] and stale['executed'] and
                                not stale['execution_confirmed'] and
                                any(stale[name] for name in FAILURE_FIELDS))
        if aligned['injured_middle_event'] and aligned['execution_confirmed']:
            successful_middle.append(metadata)
        if pair_improvement:
            paired_improvement.append(metadata)
        pair = dict(metadata)
        for method, row in per_method.items():
            for name in ('online_status', 'selected_sent', 'timely_recognized_sent', 'selected_gamma', 'command_ready_ms',
                         'status', 'executed', 'complete_501', 'physical_pass', 'terminal_pass', 'actual_safe_at_fixed_gap',
                         'execution_confirmed', 'full_50_ticks_20ms', 'D_m', 'Y', 'progress0_04_m', 'progress02_04_m',
                         'application_identity_pass', *FAILURE_FIELDS):
                pair[method + '_' + name] = row[name]
        pair.update(application_alignment_paired_improvement=pair_improvement,
                    both_actual_executed=bool(stale['executed'] and aligned['executed']),
                    stale_abstain_or_NOT_RUN=bool(not stale['selected_sent'] and not stale['executed']),
                    aligned_actual_safe_without_paired_improvement=bool(aligned['execution_confirmed'] and not pair_improvement))
        paired.append(pair)
        if not metadata['injured']:
            continue
        actual = facts['ALIGNED_RECAL']['ACTUAL']; c = facts['ALIGNED_RECAL']['COUNTERFACTUAL_C']; b = facts['ALIGNED_RECAL']['COUNTERFACTUAL_B']
        comparison = bool(aligned['injured_middle_event'] and aligned['execution_confirmed'] and b['execution_confirmed'] and
                          finite(actual['progress02_04_m']) and finite(b['progress02_04_m']))
        gain = actual['progress02_04_m'] - b['progress02_04_m'] if comparison else None
        extension = bool(comparison and gain > 0. and c['executed'] and c['observed_unsafe'])
        if extension:
            extension_contexts.append(metadata)
        erow = {**metadata, 'ALIGNED_timely_middle_sent': aligned['injured_middle_event'],
            'ALIGNED_actual_confirmed': aligned['execution_confirmed'], 'comparison_available_safe_B': comparison,
            'actual_progress0_04_m': actual['progress0_04_m'], 'actual_progress02_04_m': actual['progress02_04_m'],
            'B_progress0_04_m': b['progress0_04_m'], 'B_progress02_04_m': b['progress02_04_m'],
            'progress02_04_gain_m': gain, 'strict_progress_gain': bool(comparison and gain > 0.),
            'C_status': c['status'], 'C_executed': c['executed'], 'C_complete_501': c['complete_501'],
            'C_observed_unsafe': c['observed_unsafe'], 'C_numerical_incomplete': c['numerical_incomplete'],
            'C_physical_failure': c['physical_failure'], 'C_local_failure': c['local_failure'], 'C_terminal_failure': c['terminal_failure'],
            'B_status': b['status'], 'B_executed': b['executed'], 'B_complete_501': b['complete_501'],
            'B_complete_actual_safe': b['execution_confirmed'], 'safe_action_extension': extension,
            'safe_utility_tradeoff_only': bool(comparison and gain > 0. and c['execution_confirmed']),
            'counterfactual_role': 'COUNTERFACTUAL_ENDPOINT', 'first_packet_cost': 'SHARED_ORIGINAL_PACKET_NOT_INDEPENDENT_BASELINE',
            'missing_or_numerical_C_not_imputed_unsafe': True, 'no_sent_or_ABSTAIN_not_imputed_zero_motion': True}
        extension_rows.append(erow)
        shadow_path = result.get('shadow_path')
        shadow_summary = read(resolve(out, shadow_path), {}) if shadow_path else {}
        numeric_path = out / 'queue' / plan['context_id'] / 'ALIGNED_RECAL' / 'CAPACITY_SHADOW_NUMERIC.json'
        shadow_numeric = numeric_record(numeric_path) if numeric_path.exists() else {}
        srow = {**metadata, 'status': shadow_summary.get('status', shadow_numeric.get('status', 'NOT_RUN')),
            'shadow_path': shadow_path, 'numeric_path': str(numeric_path) if numeric_path.exists() else None,
            'healthy_capacity_available': limits_available}
        effects = {}
        for endpoint in ('C', 'B'):
            effect = _shadow_endpoint(shadow_numeric.get(endpoint), shadow_summary.get(endpoint), context,
                                      limits if limits_available else [])
            effects[endpoint] = effect
            srow.update({endpoint + '_' + name: value for name, value in effect.items()})
        bound_effect = any(effect['capacity_bound_effect'] for effect in effects.values())
        if bound_effect:
            capacity_contexts.append(metadata)
        srow.update(capacity_bound_effect=bound_effect, ALIGNED_actual_confirmed=aligned['execution_confirmed'],
                    ALIGNED_injured_middle_confirmed=bool(aligned['injured_middle_event'] and aligned['execution_confirmed']),
                    application_alignment_paired_improvement=pair_improvement, safe_action_extension=extension,
                    actual_capacity99_event=aligned['capacity99_event'], first_packet_capacity99_event=aligned['first_packet_capacity99_event'])
        shadow_rows.append(srow)
    middle_contexts = sorted({row['context_id'] for row in successful_middle})
    middle_episodes = sorted({row['episode'] for row in successful_middle})
    improvement_contexts = sorted({row['context_id'] for row in paired_improvement})
    extension_ids = sorted({row['context_id'] for row in extension_contexts})
    extension_episodes = sorted({row['episode'] for row in extension_contexts})
    capacity_ids = sorted({row['context_id'] for row in capacity_contexts})
    a_supported = len(middle_contexts) >= 2 and len(middle_episodes) >= 2 and bool(improvement_contexts)
    b_supported = len(extension_ids) >= 2 and len(extension_episodes) >= 2
    c_supported = len(capacity_ids) >= 2
    A = 'APPLICATION_ALIGNMENT_EFFECT_OBSERVED' if a_supported else 'NOT_ESTABLISHED'
    B = 'SAFE_ACTION_EXTENSION_OBSERVED' if b_supported else 'NOT_ESTABLISHED'
    C = 'CAPACITY_BOUND_EFFECT_OBSERVED' if c_supported else 'NOT_ESTABLISHED'
    groups = []
    for method in METHODS:
        for field in ('episode', 'direction', 'role', 'gamma'):
            values = sorted({str(row[field]) for row in method_rows[method]})
            for value in values:
                selected = [row for row in method_rows[method] if str(row[field]) == value]
                groups.append({'method': method, 'field': field, 'value': value, **_summary(selected, len(selected))})
    summary = {method: _summary(method_rows[method], 36) for method in METHODS}
    calibration_rows, calibration_deviation = _calibration_diagnostics(out, plans)
    online_rows, online_actions, online_summary = _online_diagnostics(out, method_rows)
    dev_rows, dev_summary = _dev_diagnostics(out, read(out / 'DEV_REGISTRY.json', []))
    shadow_summary = _shadow_diagnostics(shadow_rows)
    ledger_rows = list(jsonl_rows(out / 'STEP33_LEDGER.jsonl'))
    ledger_events = Counter(row.get('event', 'UNKNOWN') for row in ledger_rows)
    qp_summary = {}
    for scope in ('OFFLINE_DELAY_TEACHER_DEV_ONLY', 'ONLINE_6MS_20MS_WINDOW'):
        calls = [row for row in ledger_rows if row.get('event') == 'QP_RETURN' and row.get('solver_owner_scope') == scope]
        qp_summary[scope] = {'real_calls': len(calls),
            'raw_status_values': dict(Counter(str(row.get('status_val')) for row in calls)),
            'native_time_limits_s': sorted({row['osqp_time_limit_s'] for row in calls}),
            'solve_wall_time_ms': statistics(1000. * row['solve_wall_time_s'] for row in calls),
            'invoke_total_wall_time_ms': statistics(1000. * row['invoke_total_wall_time_s'] for row in calls),
            'invoke_over_20ms': sum(row['invoke_total_wall_time_s'] > .020 for row in calls),
            'setup_calls': sum(row['setup_time_s'] > 0 for row in calls),
            'workspace_reused_calls': sum(row['workspace_reused'] for row in calls)}
    attempts = Counter((row.get('event', 'UNKNOWN'), row.get('kind', 'UNKNOWN')) for row in jsonl_rows(out / 'ATTEMPT_LEDGER.jsonl'))
    budget = finished.get('budget') or read(out / 'STEP33_PROGRESS.json', {})
    result = {'run_id': manifest.get('run_id', out.name), 'NUMERICAL_STATUS': finished.get('status', 'INCOMPLETE'),
        'SCIENTIFIC_RUN_STATUS': ('TEACHER_CALIBRATION_NOT_READY' if read(out / 'STEP33_FREEZE.json', {}).get('readiness_branch') == 'TEACHER_CALIBRATION_NOT_READY' else 'FIXED_PANEL_COMPLETED' if finished.get('status') == 'COMPLETED' else 'INCOMPLETE'),
        'FOLLOWUP_NUMERICAL_EXECUTION': 'NONE_REMAINING_IN_STEP33',
        'OLD_STEP32_SCIENTIFIC_STATUS': 'INVALID_PROTOCOL_CALIBRATION_GATE',
        'ENDPOINT_DIAGNOSTICS': read(out / 'ENDPOINT_DIAGNOSTICS.json', []),
        'LOCAL_CALIBRATION_PROTOCOL_DEVIATION': calibration_deviation,
        'ONLINE_rejection_summary': online_summary,
        'DEV_outcome_reason_summary': dev_summary,
        'QP_owner_scope_summary': qp_summary,
        'saved_gate_diagnostic_summary': {key: value for key, value in read(out / 'SAVED_GATE_DIAGNOSTIC.json', {}).items() if key != 'sources'},
        'CAPACITY_SHADOW_reason_summary': shadow_summary,
        'saved_only_analysis_status': 'ANALYZED_NO_NUMERICAL_REPLAY',
        'APPLICATION_ALIGNMENT_STATUS': A, 'SAFE_ACTION_EXTENSION_STATUS': B, 'CAPACITY_BOUND_STATUS': C,
        'A_STATUS': A, 'B_STATUS': B, 'C_STATUS': C,
        'planned_TEST_contexts': 36, 'planned_method_rows': 72, 'planned_injured_contexts': 32,
        'methods': summary, 'groups': groups,
        'application_alignment': {'supported': a_supported, 'successful_injured_middle_contexts': middle_contexts,
            'successful_episodes': middle_episodes, 'paired_STALE_failed_ALIGNED_passed_contexts': improvement_contexts,
            'paired_improvement_episodes': sorted({row['episode'] for row in paired_improvement}),
            'abstain_or_late_STALE_count_not_treated_as_paired_failure': sum(row['stale_abstain_or_NOT_RUN'] for row in paired),
            'both_actual_executed_contexts': sum(row['both_actual_executed'] for row in paired)},
        'action_extension': {'supported': b_supported, 'contexts': extension_ids, 'episodes': extension_episodes,
            'safe_B_comparisons': sum(row['comparison_available_safe_B'] for row in extension_rows),
            'positive_progress_gain_contexts': sum(row['strict_progress_gain'] for row in extension_rows),
            'safe_utility_tradeoff_only_contexts': sum(row['safe_utility_tradeoff_only'] for row in extension_rows)},
        'capacity_bound': {'supported': c_supported, 'contexts': capacity_ids,
            'episodes': sorted({row['episode'] for row in capacity_contexts}),
            'endpoint_evidence_counts': {endpoint: sum(row[endpoint + '_capacity_bound_effect'] for row in shadow_rows) for endpoint in ('C', 'B')},
            'actual_safe_overlap_contexts': sorted(set(capacity_ids) & {row['context_id'] for row in method_rows['ALIGNED_RECAL'] if row['execution_confirmed']})},
        'overlap': {'A_paired_improvement_and_C': sorted(set(improvement_contexts) & set(capacity_ids)),
                    'A_injured_middle_pass_and_C': sorted(set(middle_contexts) & set(capacity_ids)),
                    'B_and_C': sorted(set(extension_ids) & set(capacity_ids)),
                    'A_paired_improvement_and_B_and_C': sorted(set(improvement_contexts) & set(extension_ids) & set(capacity_ids))},
        'budget': budget, 'ledger_event_counts': dict(ledger_events),
        'attempt_event_kind_counts': {event + ':' + kind: count for (event, kind), count in attempts.items()},
        'NEW_REGRESSION_MODEL_FITS': 0, 'calibration_freeze': read(out / 'STEP33_FREEZE.json', {}),
        'implementation_repair_evidence_paths': [str(path.relative_to(out)).replace('\\', '/') for path in sorted((out / 'repairs').glob('*')) if path.is_file()],
        'DEV_registry_summary': _dev_summary(read(out / 'DEV_REGISTRY.json', [])),
        'necessary_tests': read(out / 'tests/NECESSARY_TESTS.json', {}),
        'delivery_check': read(out / 'tests/DELIVERY_CHECK.json', {}),
        'deadline_semantics': {'command_ready_threshold_ms': 20,
            'feedback_each_tick_measured': True, 'extra_feedback_network_wait_simulated': False,
            'physical_local_terminal_safety_excludes_latency': True,
            'execution_confirmation_additionally_requires_all_50_ticks_20ms': True,
            'TEST_actual_tick_observations': sum(len(row['tick_latency_ms']) for row in rows)},
        'historical_results_unchanged': True,
        'fixed_queue_random_population_claim': False, 'probability_coverage_claim': False,
        'continuous_safety_certificate_claim': False, 'asynchronous_network_closed_loop_claim': False,
        'first_packet_wait_only': True, 'E3_RL_hardware_authorized': False,
        'row_counts': {'QUEUE_RESULTS': len(rows), 'PAIRED_TIMING_RESULTS': len(paired),
                       'ACTION_EXTENSION_RESULTS': len(extension_rows), 'CAPACITY_SHADOW_RESULTS': len(shadow_rows)}}
    for stem, data in (('QUEUE_RESULTS', rows), ('PAIRED_TIMING_RESULTS', paired),
                       ('ACTION_EXTENSION_RESULTS', extension_rows), ('CAPACITY_SHADOW_RESULTS', shadow_rows),
                       ('BRANCH_RESULTS', branches), ('GROUP_RESULTS', groups),
                       ('ONLINE_REJECTION_REASONS', online_rows), ('ONLINE_ACTION_STATUS', online_actions),
                       ('DEV_OUTCOME_REASONS', dev_rows), ('DELAY_CAL_GROUP_STATUS', calibration_rows)):
        csv_write(out / (stem + '.csv'), data); write(out / (stem + '.json'), data)
    write(out / 'CAPACITY_SHADOW_REASON_SUMMARY.json', shadow_summary)
    result['observed_formal_online_decisions'] = sum(s['recorded_method_results'] for s in summary.values())
    result['formal_panel_inputs_DONE'] = sum(r.get('status') == 'DONE' for r in read(out / 'QUEUE_REGISTRY.json', []))
    write(out / 'DEV_TEACHER_SUMMARY.json', dev_summary)
    write(out / 'QP_OWNER_SCOPE_SUMMARY.json', qp_summary)
    write(out / 'STEP33_RESULT.json', result)
    (out / 'STEP33_REPORT.md').write_text(_report_text(result, manifest), encoding='utf-8', newline='\n')
    (out / 'STEP33_RESEARCH_HANDOFF.md').write_text(_handoff_text(result), encoding='utf-8', newline='\n')
    return result


def _dev_summary(records):
    result = {}
    for method in METHODS:
        selected = [row for row in records if row.get('method') == method]
        result[method] = {'planned': 100, 'recorded': len(selected),
            'complete': sum(bool(row.get('complete')) for row in selected),
            'statuses': dict(Counter(row.get('status', 'NOT_RUN') for row in selected))}
    return result



PROTOCOL_STATUS_LINES = """AUTHORIZE_STEP33_CALIBRATION_REPAIR = TRUE
AUTHORIZE_OFFLINE_TEACHER_RELABELING = TRUE
AUTHORIZE_CORRECTED_FIXED_PANEL_EXECUTION = TRUE
OLD_STEP32_SCIENTIFIC_STATUS = INVALID_PROTOCOL_CALIBRATION_GATE
EXTRA_GROUP_MISSING_FEATURE_GATE = REMOVED
SELECTED_INCOMPLETE_LOCAL_NEIGHBOR = REJECT
NEW_REGRESSION_MODEL_FITS = 0
DEV_CONTEXTS = 20
DEV_MAX_TEACHER_TRAJECTORIES = 200
OFFLINE_TEACHER_QP_LIMIT_S = 0.100
ONLINE_QP_LIMIT_UPPER_S = 0.006
ONLINE_DEADLINE_MS = 20
ORIGINAL_SAMPLE_HORIZON_S = 1
PHYSICS_DT_S = 0.002
TEST_CONTEXTS = 36
MAX_NEW_QP_CALLS = 20000
MAX_NEW_PHYSICS_STEPS = 200000
MAX_NUMERICAL_WALL_MINUTES = 90
MAX_DEV_IMPLEMENTATION_REPAIRS = 2
TEST_RESULT_BASED_RETRY = FALSE
HISTORICAL_RESULTS_UNCHANGED = TRUE
E3_RL_HARDWARE = NOT_AUTHORIZED"""


def _report_text(r, manifest):
    lines = ['# STEP33：校准门修复与100 ms离线teacher配对执行', '',
        '## Material Passport', '',
        'experiment-agent / bounded implementation + simulation / 2026-10-09 / Asia/Seoul / ANALYZED / STEP33_v1。',
        '', f"Run：{r['run_id']}；源交付：{manifest['source_commit']}。",
        '', f"数值状态：{r['NUMERICAL_STATUS']}；科学状态：{r['SCIENTIFIC_RUN_STATUS']}。",
        f"A = {r['A_STATUS']}；B = {r['B_STATUS']}；C = {r['C_STATUS']}。分别判定，不合并为全PASS。",
        '', '## 修复和目标语义', '',
        '移除额外全组缺特征门，保留四个完整snapshot、两个episode静态最低数及原逐查询LOCAL排序。有限特征的未完成标签仍参与近邻；选中未完成或非有限残差则拒收。完整物理/terminal失败不删除。原TRAIN、系数、scaler、pose域、distance、reserve与独立评价器未改，fit=0。',
        '保存的200条旧CAL重建为独立诊断CAL；它不是正式teacher CAL，未据此推断发送。旧STEP32科学状态保持INVALID_PROTOCOL_CALIBRATION_GATE。',
        '新teacher在全部20个原DEV初始输入上用100 ms原生QP重新生成C/B和48 feedback槽；在线/ACTUAL/CF仍最大6 ms原生求解、每tick20 ms。teacher晚于20 ms单独记录，不改写D/Y或物理事实；teacher不是实时部署或A/B/C证据。每次QP只调用一次，真实setup/update/solve/polish成本均保留。',
        '时间轴sample0→prehold0–.02→原packet.02–.04→48 backup槽.04/.06/…/.98→终点1.000 s；完整500步/501状态/21检查点，原anchor与方向不变，D含prehold。所有轨迹只读取真实推进状态。',
        '', '## DEV teacher与CAL', '',
        '| 方法 | 计划动作 | 完整标签 | partial | NOT_RUN | 完整物理失败 | 完整terminal失败 |',
        '|---|---:|---:|---:|---:|---:|---:|']
    dev_details = []
    for method in METHODS:
        d = r['DEV_outcome_reason_summary'][method]
        lines.append(f"| {method} | 100 | {d['complete_501']} | {d['partial']} | {d['statuses'].get('NOT_RUN',0)} | {d['physical_failure_complete']} | {d['terminal_failure_complete']} |")
        dev_details.extend(['', f"{method}：partial原始状态 {d['partial_raw_solver_statuses']}；未运行原因 {d['NOT_RUN_reasons']}。",
            f"有限特征{d['finite_feature_rows']}，缺失特征{d['missing_feature_rows']}；teacher晚于20 ms的tick为{d['teacher_ticks_over_20ms']}，真实tick时延统计{d['teacher_tick_latency_ms']}。"])
    lines += dev_details
    lines += ['', '有限/缺失/完整输入、snapshot与episode数见[DELAY_CAL_GROUP_STATUS](DELAY_CAL_GROUP_STATUS.csv)；全部200个动作见[DEV_OUTCOME_REASONS](DEV_OUTCOME_REASONS.csv)。所有完整失败与有限partial保留。',
        '', '## 固定TEST配对', '',
        f"正式计划36输入/72方法位；实际新在线决策{r['observed_formal_online_decisions']}个，完成配对输入{r['formal_panel_inputs_DONE']}/36。分支：{r['calibration_freeze'].get('readiness_branch')}。端点诊断另有{len(r['ENDPOINT_DIAGNOSTICS'])}行，不计为正式面板。",
        '| 方法 | 观测决策/36 | 及时发送 | ACTUAL | 完整501 | 物理/local/terminal安全 | 全tick20 ms | 完整通过 | 条件成功率 |',
        '|---|---:|---:|---:|---:|---:|---:|---:|---|']
    test_details = []
    for method in METHODS:
        s = r['methods'][method]
        conditional = '未定义（0发送）' if s['conditional_success_rate_sent'] is None else f"{s['conditional_success_rate_sent']:.3f}"
        lines.append(f"| {method} | {s['recorded_method_results']} | {s['timely_recognized_sent']} | {s['ACTUAL_executed']} | {s['complete_501']} | {s['actual_safe_at_fixed_gap']} | {s['full_50_ticks_20ms']} | {s['execution_confirmed']} | {conditional} |")
        test_details.extend(['', f"{method}状态{s['statuses']}；ACTUAL数值未完成{s['numerical_incomplete']}，physical/local/terminal失败{s['physical_failure']}/{s['local_failure']}/{s['terminal_failure']}，ACTUAL deadline失败{s['deadline_failure']}；command-ready {s['command_ready_ms']}。",
            f"在线超过20 ms窗口{s['online_deadline_exceeded']}；被选中未完成LOCAL近邻查询{r['ONLINE_rejection_summary'][method]['selected_incomplete_LOCAL_queries']}。逐查询拒收门计数（可重叠）：{r['ONLINE_rejection_summary'][method]['evaluated_query_rejection_gates']}。"])
    lines += test_details
    lines += ['', '正式输入是原36个固定修复输入，不是新盲测或随机总体泛化。gap和snapshot奇偶顺序原样保持，同snapshot两fault role共用方法顺序；teacher与在线workspace、PID/config owner独立。计时含prehold、application prediction、C/B、混合检查、prefix、推断和必要拷贝。',
        '及时认可发送后仅执行同packet ACTUAL，ALIGNED受损中间动作再做同packet C/B独立记忆反事实；缺端点不另求首QP。未运行/未发送/数值失败/物理失败分列，不填0运动或将数值缺失当C不安全。',
        '若ALIGNED没有受损中间静态合格组，则36正式输入全部NOT_RUN，只运行预设ordinal1/10/19/28 × 两方法端点可用性诊断、0 ACTUAL。不作为正式配对结果。',
        '', '## A/B/C事实', '',
        f"A：{r['application_alignment']}。",
        f"B：{r['action_extension']}。",
        f"C：{r['capacity_bound']}。",
        f"相交事实：{r['overlap']}。",
        'A要求跨至少两episode的受损中间完整执行通过及同context STALE已运行失败/ALIGNED通过；STALE未发送不充作失败。B要求中间/B实际安全、C实际physical/local/terminal违反及.02–.04严格进度增益。C要求真实有界解可行、同问题bounds-restored shadow严格Solved且实质违反受损容量；shadow不施加，不参与CAL。',
        '', '## 预算和证据', '', f"累计预算：{r['budget']}。",
        f"真实QP严格状态与时延：[QP_OWNER_SCOPE_SUMMARY](QP_OWNER_SCOPE_SUMMARY.json)。{r['QP_owner_scope_summary']}。",
        '真实QP及积分短账本：[STEP33_LEDGER](STEP33_LEDGER.jsonl)；逐项attempt：[ATTEMPT_LEDGER](ATTEMPT_LEDGER.jsonl)。总上限90分钟/20,000 QP/200,000积分步包含startup、teacher、prediction、online、ACTUAL/CF、shadow及失败，不重置。没有reference重跑或回归fit。',
        f"必要测试一次：[46项fixture全部通过](tests/NECESSARY_TESTS.log)。交付检查一次：[22/22项通过](tests/DELIVERY_CHECK.json)。两者无新增真实QP、积分或fit；工程检查通过不等于A/B/C机制建立。",
        '仅核对当前输入/模型、新源码/工件和scoped diff，没有历史求解/证书审计。命令和Git状态见[交付记录](STEP33_DELIVERY_METADATA.json)；新增源码清单见[修改文件](STEP33_MODIFIED_FILES.md)。',
        '', 'SciPilot仅两图：[全队列配对](figures/STEP33_paired_queue.pdf)；[全部实际中间事件及teacher诊断](figures/STEP33_middle_events.pdf)。全体身份、未运行和失败保留；无事件时不补造轨迹。矢量、600 dpi PNG和灰度证据保留。',
        '', '~~~ini', PROTOCOL_STATUS_LINES,
        f"NUMERICAL_STATUS = {r['NUMERICAL_STATUS']}", f"SCIENTIFIC_RUN_STATUS = {r['SCIENTIFIC_RUN_STATUS']}",
        f"A_STATUS = {r['A_STATUS']}", f"B_STATUS = {r['B_STATUS']}", f"C_STATUS = {r['C_STATUS']}", '~~~', '']
    return '\n'.join(lines)


def _handoff_text(r):
    return '\n'.join(['# STEP33研究交接', '',
        f"数值：{r['NUMERICAL_STATUS']}；科学：{r['SCIENTIFIC_RUN_STATUS']}。",
        f"A/B/C：{r['A_STATUS']} / {r['B_STATUS']} / {r['C_STATUS']}。",
        '旧STEP32仍INVALID_PROTOCOL_CALIBRATION_GATE，原6 ms失败不因teacher结果撤回。',
        '本轮100 ms teacher是离线数学策略标签；在线6 ms/20 ms真实执行证据单独评价。',
        '全20 DEV及原36 TEST输入身份保留，fit=0。固定修复面板不宣称随机总体或新的盲测。',
        '如无ALIGNED中间CAL静态合格组，正式面板未运行，只有预设8次端点诊断。',
        '后续设计变化或新增数值批次需要新的明确授权；E3/RL/硬件未授权。',
        '', '~~~ini', PROTOCOL_STATUS_LINES, '~~~', ''])


def summarize(run_id=RUN_ID):
    return report(ROOT / 'artifacts/step33_calibration_repair_20261009' / run_id)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('run_id', nargs='?', default=RUN_ID)
    r = summarize(parser.parse_args().run_id)
    print({k:r[k] for k in ('NUMERICAL_STATUS', 'SCIENTIFIC_RUN_STATUS', 'A_STATUS', 'B_STATUS', 'C_STATUS')})
