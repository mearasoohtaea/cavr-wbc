"""One streaming fixed STEP33 DEV20 / paired TEST36 application-clock batch."""
import argparse
from copy import deepcopy
from datetime import datetime, timezone
import gc
import os
from time import perf_counter
import traceback
import numpy as np

from cavr_wbc.experiments import step17_formal_panel as frozen
from cavr_wbc.experiments import step33_sim as sim
from cavr_wbc.experiments.step26_features_storage import save_bank
from cavr_wbc.experiments.step28_sprint import home_context
from cavr_wbc.experiments.step29_sprint import source_context
from cavr_wbc.experiments.step30_sprint import missing, events
from cavr_wbc.experiments.step31_sprint import add_previous_command_identity
from cavr_wbc.experiments.step33_io import (ROOT, SOURCE30, RUN_ID, PARENT, MODEL_PARENT,
    PROTOCOL, METHODS, SOURCE32, output, read, write, append, sha, relative, save_numeric, load_numeric)
from cavr_wbc.experiments.step33_budget import SprintBudget, SprintLimit
from cavr_wbc.control.step30_actions import GAMMA_GRID, make_action, prepare_shared
from cavr_wbc.control.step30_margin import load_bundle, labels, gamma_key
from cavr_wbc.control.step33_margin import build_delay_calibration, save_delay_calibration
from cavr_wbc.control.step33_kernel import Kernel
from cavr_wbc.platforms.go2_mujoco import extract_actuator_audit, extract_healthy_torque_limits

DEV_EPISODES = (('D32_P064', .064, 20261201), ('D32_N064', -.064, 20261201),
                ('D32_P068', .068, 20261202), ('D32_N068', -.068, 20261202))
TEST_EPISODES = (('T32_P063', .063, 20261211), ('T32_N063', -.063, 20261211),
                 ('T32_P069', .069, 20261212), ('T32_N069', -.069, 20261212))
DEV_TICKS = (30, 34, 38)
TEST_TICKS = (29, 33, 35, 37, 41)
GAPS = {29: .004, 33: .0045, 35: .005, 37: .005, 41: .006}


def plans(split):
    if split not in ('DEV', 'TEST'):
        raise ValueError('fixed DEV or TEST only')
    episodes, ticks, healthy = (DEV_EPISODES, DEV_TICKS, 34) if split == 'DEV' else (TEST_EPISODES, TEST_TICKS, 35)
    result = []
    snapshot_ordinal = 0
    for episode, displacement, seed in episodes:
        for tick in ticks:
            kinds = ('HEALTHY',) if tick == healthy else ('THIGH_15', 'CALF_15')
            order = METHODS if snapshot_ordinal % 2 == 0 else METHODS[::-1]
            for kind in kinds:
                result.append({'context_id': episode + f'_T{tick:03d}_' + kind,
                    'ordinal': len(result), 'snapshot_ordinal': snapshot_ordinal,
                    'method_order': list(order), 'role': kind.split('_')[0].lower(),
                    'health_kind': kind, 'episode': episode, 'split': split,
                    'snapshot_id': episode + f'_T{tick:03d}', 'tick': tick,
                    'direction': 1 if displacement > 0 else -1, 'seed': seed,
                    'gap_m': GAPS[tick] if split == 'TEST' else None})
            snapshot_ordinal += 1
    return result


def event(out, name, **fields):
    append(out / 'ATTEMPT_LEDGER.jsonl', {'event': name,
        'timestamp_utc': datetime.now(timezone.utc).isoformat(), **fields})


def attach_previous(c, episode):
    add_previous_command_identity(c, episode)
    identity = c['previous_command_identity']
    identity.update(previous_reference_tick=identity.get('applied_previous_reference_tick'),
                    source_snapshot=c['snapshot_id'],
                    health_vector=identity.get('source_health_vector'))
    c['previous_tau_sent'] = identity.get('tau_sent')


def save_branch(out, directory, name, branch, c):
    path = directory / name
    path.mkdir(parents=True, exist_ok=True)
    if branch.get('status') == 'NOT_RUN':
        lab = missing(branch.get('reason', 'NOT_RUN'))
        record = {**branch, 'label': lab, 'result_path': relative(path / 'RESULT.json', out)}
        write(path / 'RESULT.json', record)
        return record
    bank = save_bank(path / 'actual.npz', branch)
    lab = labels(branch, c)
    controls = branch['controls']
    write(path / 'CONTROL_RESULTS.json', {'controls': controls, 'status': branch['status'], 'reason': branch.get('reason')})
    first = controls[1]['capacity_interface'] if len(controls) > 1 else {}
    evt = events(branch, {'capacity_interface': first,
        'first_capacity_event': bool(first.get('sent_99_percent_active_indices'))})
    # First prehold is an identified prior command, not a new solved QP.
    timely = bool(len(controls) == 50 and all(row.get('valid_command') and float(row.get('latency_ms', 0.)) <= 20.
                                           for row in controls[1:]))
    record = {'status': branch['status'], 'reason': branch.get('reason'), 'label': lab,
        'artifact': bank, 'controls_path': relative(path / 'CONTROL_RESULTS.json', out),
        'result_path': relative(path / 'RESULT.json', out), 'gamma': branch.get('gamma'),
        'counts': branch['counts'], 'events': evt, 'all_tick_deadline_pass': timely,
        'tick_latency_ms': [row.get('latency_ms') for row in controls],
        'progress0_04_m': branch.get('progress0_04_m'), 'progress02_04_m': branch.get('progress02_04_m'),
        'first_tau_matches_packet': branch.get('first_tau_matches_packet'),
        'application_state_match': branch.get('application_state_match'),
        'application_identity_pass': branch.get('application_identity_pass', True),
        'application_identity_error': branch.get('application_identity_error', branch.get('identity_error')),
        'application_state_comparison': branch.get('application_state_check'),
        'application_state_actual': branch.get('application_state_actual'),
        'application_state_prediction': branch.get('application_state_prediction'),
        'backup_memory_restore': branch.get('backup_memory_restore'),
        'same_packet_cost_not_independent_baseline': name.startswith('COUNTERFACTUAL'),
        'actual_horizon_origin': 'SAMPLE', 'actual_horizon_s': 1.}
    write(path / 'RESULT.json', record)
    return record


def branch_once(out, directory, name, kernel, c, packet, budget, action=None, require_sent=True):
    event(out, 'START', kind=name, context_id=c['context_id'], method=packet['method'],
          gamma=packet.get('selected_gamma') if action is None else action['gamma'])
    branch = sim.propagate(kernel, c, packet, budget, purpose=name,
                           action=action, require_sent=require_sent)
    record = save_branch(out, directory, name, branch, c)
    event(out, 'RETURN', kind=name, context_id=c['context_id'], method=packet['method'],
          status=record['status'], counts=record.get('counts'), result_path=record['result_path'])
    budget.persist(phase='BRANCH_SAVED', context_id=c['context_id'], method=packet['method'], branch=name)
    if record['status'] == 'FAILED_BUDGET':
        raise SprintLimit('partial branch saved at numerical cap')
    if record.get('application_identity_error'):
        raise ValueError('saved application prediction/ACTUAL state identity mismatch')
    return record


def context_for(plan, snapshots, episode, mapping):
    source = snapshots.get(plan['tick'], {'snapshot_id': plan['snapshot_id'], 'episode_id': plan['episode'],
        'source_tick': plan['tick'], 'direction': plan['direction'], 'eligible': False,
        'eligibility_reason': 'REFERENCE_INCOMPLETE'})
    c = source_context(source, plan['health_kind'], mapping, plan['ordinal'], 'ID')
    c.update(backup_id='STEP33-' + c['context_id'], role=plan['role'], episode=plan['episode'],
             source_snapshot=plan['snapshot_id'], split=plan['split'], gap_m=plan['gap_m'],
             front_or_rear='front' if plan['direction'] > 0 else 'rear')
    if c['eligible']:
        attach_previous(c, episode)
    return c


def reuse_context(plan):
    """Read only the original sample input, never its old command/labels."""
    if plan['split'] == 'DEV':
        path = SOURCE32 / 'DEV' / plan['context_id'] / METHODS[0] / 'G1_CAL_RECORD.json'
    else:
        path = SOURCE32 / 'queue' / plan['context_id'] / 'RESULT.json'
    saved = read(path)
    context = deepcopy(saved['context'])
    if (context['context_id'] != plan['context_id'] or context['source_snapshot'] != plan['snapshot_id']
            or context['source_tick'] != plan['tick'] or context['role'] != plan['role']
            or context['gap_m'] != plan['gap_m']):
        raise ValueError('fixed sample context identity differs from source plan')
    context['teacher_input_reused_only'] = True
    return context, {'source_path': str(path), 'source_sha256': sha(path),
                     'split': plan['split'], 'context_id': plan['context_id'],
                     'integration_state_sha256': __import__('hashlib').sha256(
                         np.asarray(context['state']['integration_state'], dtype=np.float64).tobytes()).hexdigest(),
                     'previous_command_identity': context['previous_command_identity'],
                     'new_reference_QP_calls': 0, 'new_reference_steps': 0}


def saved_gate_diagnostic(out, original):
    records = {method: [] for method in METHODS}
    source_registry = read(SOURCE32 / 'DEV_REGISTRY.json')
    sources = []
    for item in source_registry:
        path = SOURCE32 / item['path']
        entry = read(path)
        records[item['method']].append(entry)
        sources.append({'path': str(path), 'sha256': sha(path), 'id': entry['id']})
    if len(sources) != 200:
        raise ValueError('saved calibration repair diagnostic requires all 200 records')
    bundles = {m: build_delay_calibration(original, records[m], m) for m in METHODS}
    assets = {m: save_delay_calibration(bundles[m], out / 'saved_gate_diagnostic' / m) for m in METHODS}
    restored = [key for key, group in bundles['STALE_RECAL']['groups'].items() if group['local_calibrated']]
    aligned = [key for key, group in bundles['ALIGNED_RECAL']['groups'].items() if group['local_calibrated']]
    write(out / 'SAVED_GATE_DIAGNOSTIC.json', {'old_scientific_status': 'INVALID_PROTOCOL_CALIBRATION_GATE',
        'restored_STALE_static_groups': restored, 'ALIGNED_static_groups': aligned,
        'expected_five_STALE_calf_restored': set(restored) == {str(g).rstrip('0').rstrip('.') + ':calf' for g in GAMMA_GRID},
        'new_QP_calls': 0, 'new_physics_steps': 0, 'not_formal_teacher_CAL': True,
        'TEST_send_inference': 'NOT_EVALUATED', 'assets': assets, 'sources': sources})
    return bundles


def run_dev(out, model, manifest, kernels, budget):
    records = {method: [] for method in METHODS}
    registry = []
    for plan in plans('DEV'):
        c, source = reuse_context(plan)
        for method in plan['method_order']:
            directory = out / 'DEV' / c['context_id'] / method
            directory.mkdir(parents=True, exist_ok=True)
            packet_path = directory / 'PACKET.json'
            if packet_path.exists():
                packet = load_numeric(packet_path)
                event(out, 'REUSED_SAVED_PACKET', kind='DEV_COLLECTION', context_id=c['context_id'], method=method,
                      additional_QP_calls=0, additional_prediction_steps=0)
            else:
                event(out, 'START', kind='DEV_COLLECTION', context_id=c['context_id'], method=method)
                packet = kernels[method].collect_actions(c, budget, method) if c['eligible'] else {
                    'status': 'SOURCE_INELIGIBLE', 'method': method, 'actions': {}, 'prehold': {}}
                numeric = save_numeric(packet_path, packet)
                event(out, 'RETURN', kind='DEV_COLLECTION', context_id=c['context_id'], method=method,
                      status=packet['status'], numeric=numeric)
            for gamma in GAMMA_GRID:
                entry = packet['actions'].get(str(gamma), {})
                action = entry.get('action')
                name = 'G' + gamma_key(gamma)
                record = {'status': 'NOT_RUN', 'label': missing('SOURCE_OR_ACTION_UNAVAILABLE')}
                if (directory / name / 'RESULT.json').exists():
                    record = read(directory / name / 'RESULT.json')
                elif action and action.get('command_valid') and action.get('execution_eligible'):
                    record = branch_once(out, directory, name, kernels[method], c, packet, budget,
                                         action=action, require_sent=False)
                if not (directory / name / 'RESULT.json').exists():
                    record = save_branch(out, directory, name, record, c)
                item = {'schema': 'STEP33_OFFLINE_TEACHER_LABEL_V1', 'teacher_native_time_limit_s': .100, 'id': c['context_id'] + ':' + method + ':G' + gamma_key(gamma),
                    'context': c, 'method': method, 'split': 'DEV', 'gamma': gamma, 'role': c['role'],
                    'episode': plan['episode'], 'source_snapshot': c['source_snapshot'],
                    'features26': entry.get('features26'), 'prefix': entry.get('prefix'),
                    'prehold': packet.get('prehold'), 'labels': record['label'],
                    'first_command_valid': bool(action and action.get('command_valid')),
                    'target_horizon_origin': 'SAMPLE', 'target_horizon_s': 1.}
                cal_path = directory / (name + '_CAL_RECORD.json')
                if cal_path.exists():
                    item = read(cal_path)
                else:
                    write(cal_path, item)
                records[method].append(item)
                registry.append({'id': item['id'], 'context_id': c['context_id'], 'method': method,
                    'split': 'DEV', 'gamma': gamma, 'episode': plan['episode'], 'source_snapshot': c['source_snapshot'],
                    'status': record['status'], 'complete': record['label'].get('complete', False),
                    'path': relative(directory / (name + '_CAL_RECORD.json'), out),
                    'branch_result': record.get('result_path'), 'packet_path': relative(directory / 'PACKET.json', out)})
                write(out / 'DEV_REGISTRY.json', registry)
            event(out, 'DONE', kind='DEV_CONTEXT_METHOD', context_id=c['context_id'], method=method)
            budget.persist(phase='DEV', context_id=c['context_id'], method=method, planned_actions_processed=len(registry))
            print({'phase': 'DEV', 'context': c['context_id'], 'method': method,
                   'actions_processed': len(registry), 'budget': budget.snapshot()}, flush=True)
        gc.collect()
    return records


def run_test(out, model, manifest, kernels, bundles, budget):
    registry = [{**p, 'status': 'NOT_RUN', 'eligible': None,
        'result_path': relative(out / 'queue' / p['context_id'] / 'RESULT.json', out)} for p in plans('TEST')]
    write(out / 'QUEUE_REGISTRY.json', registry)
    for plan in plans('TEST'):
        c, source = reuse_context(plan)
        directory = out / 'queue' / c['context_id']
        directory.mkdir(parents=True, exist_ok=True)
        result = {'context': c, 'plan': plan, 'context_id': c['context_id'],
                  'eligible': bool(c['eligible']), 'methods': {}, 'shadow_path': None}
        write(directory / 'RESULT.json', result)
        for method in plan['method_order']:
            d = directory / method
            d.mkdir(exist_ok=True)
            event(out, 'START', kind='ONLINE', context_id=c['context_id'], method=method,
                  ordinal=plan['ordinal'], snapshot_ordinal=plan['snapshot_ordinal'])
            packet = kernels[method].governor(c, bundles[method], c['gap_m'], budget, method) if c['eligible'] else {
                'status': 'SOURCE_INELIGIBLE', 'selected_command_sent': False,
                'method': method, 'selected_gamma': None, 'actions': {}}
            numeric = save_numeric(d / 'ONLINE_NUMERIC.json', packet)
            method_result = {'status': packet['status'], 'selected_sent': bool(packet.get('selected_command_sent')),
                'selected_gamma': packet.get('selected_gamma'), 'command_ready_ms': packet.get('command_ready_ms'),
                'online_numeric_path': relative(d / 'ONLINE_NUMERIC.json', out), 'online_numeric': numeric,
                'branches': {}}
            result['methods'][method] = method_result
            write(directory / 'RESULT.json', result)
            event(out, 'RETURN', kind='ONLINE', context_id=c['context_id'], method=method,
                  status=packet['status'], sent=method_result['selected_sent'], command_ready_ms=method_result['command_ready_ms'])
            if method_result['selected_sent']:
                method_result['branches']['ACTUAL'] = branch_once(out, d, 'ACTUAL', kernels[method], c, packet, budget)
                write(directory / 'RESULT.json', result)
                gamma = float(packet['selected_gamma'])
                if method == 'ALIGNED_RECAL' and c['role'] != 'healthy' and 0. < gamma < 1.:
                    context = packet['context_used']
                    shared = prepare_shared(context, packet.get('C'), packet.get('B'))
                    for endpoint, g in (('C', 1.), ('B', 0.)):
                        action = make_action(context, packet.get('C'), packet.get('B'), g, workspace=shared)
                        name = 'COUNTERFACTUAL_' + endpoint
                        if action.get('command_valid') and action.get('execution_eligible'):
                            branch = branch_once(out, d, name, kernels[method], c, packet, budget, action=action)
                        else:
                            branch = {'status': 'NOT_RUN', 'reason': 'SAME_PACKET_ENDPOINT_UNAVAILABLE',
                                      'label': missing('SAME_PACKET_ENDPOINT_UNAVAILABLE')}
                            write(d / name / 'RESULT.json', branch)
                        method_result['branches'][name] = branch
                        write(directory / 'RESULT.json', result)
            if method == 'ALIGNED_RECAL' and c['role'] != 'healthy':
                event(out, 'START', kind='CAPACITY_SHADOW', context_id=c['context_id'], method=method)
                shadow = kernels[method].shadow(c, packet, budget) if c['eligible'] else {
                    'status': 'NOT_RUN', 'reason': 'SOURCE_INELIGIBLE', 'C': None, 'B': None}
                asset = save_numeric(d / 'CAPACITY_SHADOW_NUMERIC.json', shadow)
                summary = {'status': shadow['status'], 'reason': shadow.get('reason'),
                    'context_id': c['context_id'], 'episode': plan['episode'], 'numeric': asset,
                    'C': shadow_summary(shadow.get('C')), 'B': shadow_summary(shadow.get('B'))}
                write(d / 'CAPACITY_SHADOW_RESULT.json', summary)
                result['shadow_path'] = relative(d / 'CAPACITY_SHADOW_RESULT.json', out)
                event(out, 'RETURN', kind='CAPACITY_SHADOW', context_id=c['context_id'], method=method, status=summary['status'])
            event(out, 'DONE', kind='TEST_CONTEXT_METHOD', context_id=c['context_id'], method=method)
            write(directory / 'RESULT.json', result)
            budget.persist(phase='TEST_METHOD', context_id=c['context_id'], method=method)
        registry[plan['ordinal']].update(status='DONE', eligible=bool(c['eligible']))
        write(out / 'QUEUE_REGISTRY.json', registry)
        event(out, 'DONE', kind='TEST_CONTEXT', context_id=c['context_id'], ordinal=plan['ordinal'])
        budget.persist(phase='TEST', processed=plan['ordinal'] + 1, last_context=c['context_id'])
        print({'phase': 'TEST', 'processed': plan['ordinal'] + 1, 'methods':
            {m: r['status'] for m, r in result['methods'].items()}, 'budget': budget.snapshot()}, flush=True)
        gc.collect()


def shadow_summary(item):
    if not item:
        return {'status': 'NOT_RUN', 'capacity_bound_effect': False}
    names = ('status', 'reason', 'solver_status_val', 'strict_solved_finite', 'original_bounded_feasible',
             'capacity_bound_effect', 'changed_row_indices', 'changed_channel_indices',
             'capacity_violation_nm', 'raw_margin_original_capacity_nm', 'original_raw_margin_nm',
             'same_except_injured_torque_bounds', 'new_QP_calls')
    return {k: item.get(k) for k in names}



def endpoint_diagnostics(out, kernels, budget):
    """Predetermined 4x2 availability checks, never CAL-approved/actuated."""
    results = []
    for ordinal in (1, 10, 19, 28):
        plan = plans('TEST')[ordinal]
        c, source = reuse_context(plan)
        for method in plan['method_order']:
            event(out, 'START', kind='ENDPOINT_DIAGNOSTIC', context_id=c['context_id'], method=method)
            packet = kernels[method].endpoint_diagnostic(c, budget, method)
            d = out / 'endpoint_diagnostics' / c['context_id'] / method
            asset = save_numeric(d / 'PACKET.json', packet)
            row = {'context_id': c['context_id'], 'source_ordinal': ordinal, 'method': method,
                   'selected_command_sent': False, 'ACTUAL_runs': 0,
                   'command_ready_ms': packet['command_ready_ms'], 'numeric': asset,
                   'C': endpoint_summary(packet['C']), 'B': endpoint_summary(packet['B'])}
            results.append(row)
            write(out / 'ENDPOINT_DIAGNOSTICS.json', results)
            event(out, 'RETURN', kind='ENDPOINT_DIAGNOSTIC', **row)
            budget.persist(phase='ENDPOINT_DIAGNOSTIC', processed=len(results))
            print({'phase': 'ENDPOINT_DIAGNOSTIC', 'processed': len(results), 'row': row}, flush=True)


def endpoint_summary(answer):
    raw = answer.get('raw_solver_result', answer.get('wbc', answer)) or {}
    fields = ('status', 'status_val', 'solver_status_val', 'primal_residual', 'dual_residual',
              'iterations', 'setup_time_s', 'update_time_s', 'solve_wall_time_s', 'osqp_time_limit_s')
    return {**{key: raw.get(key, answer.get(key)) for key in fields},
            'valid_command': answer.get('command_valid', answer.get('valid_command', False)),
            'hard_residual': answer.get('capacity_interface'), 'command_ready_ms': answer.get('command_ready_ms')}


def run(run_id=RUN_ID, repair=False):
    out = output(run_id)
    if (out / 'RUN_STARTED.json').exists() and not repair:
        raise FileExistsError('unique STEP33 numerical batch already started')
    for name in ('DEV', 'queue', 'calibration', 'figures'):
        (out / name).mkdir(parents=True, exist_ok=True)
    source = read(SOURCE32 / 'MANIFEST.json')
    original = load_bundle(SOURCE30 / 'models')
    if not repair:
        saved_gate_diagnostic(out, original)  # saved-only; outside numerical clock
    model = frozen.load_model()
    limits = extract_healthy_torque_limits(model)
    mapping = [dict(row, healthy_limit_nm=float(limits[row['actuator_index']])) for row in extract_actuator_audit(model)]
    contexts = [reuse_context(p)[1] for p in plans('DEV') + plans('TEST')]
    dll = SOURCE30 / 'native/step30_prefix.dll'
    # Current input/model identity only; no replay or historical solve audit.
    identity_files = {str(ROOT / path): expected for path, expected in
                      source['frozen_physical']['model_files_sha256'].items()}
    model_asset = source['model_assets']['GEOMETRY_FULL_26']
    identity_files.update({model_asset['json']: model_asset['json_sha256'],
                           model_asset['npz']: model_asset['npz_sha256'],
                           str(dll): source['native_dll_sha256']})
    actual_hashes = {path: sha(path) for path in identity_files}
    if actual_hashes != identity_files:
        raise ValueError('current STEP33 input/model identity mismatch')
    manifest = {**{k: source[k] for k in ('scenario', 'frozen_physical', 'model_assets')},
        'run_id': run_id, 'source_commit': PARENT, 'model_source_commit': MODEL_PARENT,
        'protocol_sha256': sha(PROTOCOL), 'source_predictor': 'GEOMETRY_FULL_26/LOCAL',
        'new_regression_model_fits': 0, 'mapping': mapping,
        'DEV': plans('DEV'), 'TEST': plans('TEST'), 'methods': METHODS,
        'DEV_max_action_trajectories': 200, 'TEST_contexts': 36, 'TEST_methods': 72,
        'max_QP': 20000, 'max_steps': 200000, 'max_wall_s': 5400,
        'deadline_ms': 20., 'max_single_QP_s': .006, 'offline_teacher_QP_limit_s': .100,
        'horizon_origin': 'SAMPLE', 'horizon_s': 1., 'prehold_s': .020, 'physics_dt_s': .002,
        'source_contexts': contexts, 'old_STEP32_scientific_status': 'INVALID_PROTOCOL_CALIBRATION_GATE',
        'current_input_model_sha256': actual_hashes,
        'old_6ms_CAL_mixed_with_teacher': False, 'reference_replayed': False,
        'no_E3_RL_hardware': True, 'historical_results_unchanged': True,
        'native_dll_path': str(dll), 'native_dll_sha256': sha(dll),
        'date': '2026-10-09', 'timezone': 'Asia/Seoul'}
    if not repair:
        write(out / 'MANIFEST.json', manifest)
        write(out / 'RUN_STARTED.json', {'pid': os.getpid(), 'run_id': run_id,
            'start_utc': datetime.now(timezone.utc).isoformat(), 'immutable_limits': [5400, 20000, 200000]})
    budget = SprintBudget.resume_dev_repair(out) if repair else SprintBudget(out)
    budget.start()
    status = 'COMPLETED'
    try:
        t = perf_counter()
        teachers = {m: Kernel(model, 'BOUNDED', str(dll), budget, teacher=True) for m in METHODS}
        online = {m: Kernel(model, 'BOUNDED', str(dll), budget, teacher=False) for m in METHODS}
        home = home_context(model, manifest['scenario'])
        home.update(context_id='STEP33_HOME', backup_id='STEP33_HOME')
        startup = {'TEACHER': {m: teachers[m].startup(home, budget) for m in METHODS},
                   'ONLINE': {m: online[m].startup(home, budget) for m in METHODS}}
        write(out / ('repairs/STARTUP_REPAIR.json' if repair else 'STARTUP.json'),
              {'owners': startup, 'full_startup_ms': (perf_counter() - t) * 1000.,
               'teacher_and_online_independent': all(teachers[m].nominal_controller is not online[m].nominal_controller
                     and teachers[m].backup_controller is not online[m].backup_controller for m in METHODS)})
        budget.persist(phase='STARTUP')
        dev = run_dev(out, model, manifest, teachers, budget)
        bundles = {m: build_delay_calibration(original, dev[m], m) for m in METHODS}
        assets = {m: save_delay_calibration(bundles[m], out / 'calibration' / m) for m in METHODS}
        paths = [*ROOT.glob('cavr_wbc/control/step33_*.py'),
                 *ROOT.glob('cavr_wbc/experiments/step33_*.py'),
                 *ROOT.glob('tests/test_step33*.py')]
        runtime = [p for p in paths if not any(word in p.name for word in ('report', 'figures', 'verify'))]
        readiness = any(group['local_calibrated'] for key, group in bundles['ALIGNED_RECAL']['groups'].items()
                        if float(key.split(':')[0]) in (.75, .5, .25) and key.split(':')[1] != 'healthy')
        branch = 'FULL_FIXED_PANEL' if readiness else 'TEACHER_CALIBRATION_NOT_READY'
        write(out / 'STEP33_FREEZE.json', {'frozen_utc': datetime.now(timezone.utc).isoformat(),
            'config': manifest, 'calibration_assets': assets,
            'new_runtime_code_sha256': {relative(p, ROOT): sha(p) for p in runtime},
            'calibration_ids': {m: bundles[m]['calibration_id'] for m in METHODS},
            'DEV_ids': {m: [r['id'] for r in dev[m]] for m in METHODS},
            'freeze_count': 1, 'regression_model_fits': 0, 'TEST_read_for_CAL': False,
            'readiness_branch': branch, 'only_one_preTEST_check': True})
        del dev
        budget.persist(phase='DEV_AND_CODE_FROZEN', readiness_branch=branch)
        if readiness:
            run_test(out, model, manifest, online, bundles, budget)
        else:
            write(out / 'QUEUE_REGISTRY.json', [{**p, 'status': 'NOT_RUN', 'reason': branch} for p in plans('TEST')])
            endpoint_diagnostics(out, online, budget)
    except SprintLimit as exc:
        status = 'INCOMPLETE_BUDGET'
        write(out / 'INTERRUPTION.json', {'type': 'BUDGET', 'error': str(exc), 'budget': budget.snapshot()})
    except BaseException as exc:
        status = 'STOPPED_IMPLEMENTATION_OR_RESOURCE'
        write(out / 'INTERRUPTION.json', {'type': type(exc).__name__, 'error': str(exc),
            'traceback': traceback.format_exc(), 'budget': budget.snapshot()})
        raise
    finally:
        budget.event('NUMERICAL_FINISHED', status=status, **budget.snapshot())
        budget.close()
        write(out / 'RUN_FINISHED.json', {'run_id': run_id, 'status': status,
            'budget': budget.snapshot(), 'finish_utc': datetime.now(timezone.utc).isoformat()})
        print({'status': status, 'budget': budget.snapshot()}, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('run_id', nargs='?', default=RUN_ID)
    parser.add_argument('--dev-engineering-repair', action='store_true')
    args = parser.parse_args()
    run(args.run_id, args.dev_engineering_repair)
