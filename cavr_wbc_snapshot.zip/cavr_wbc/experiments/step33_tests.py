"""The single necessary fixture suite for STEP33, not a numerical experiment."""
from datetime import datetime, timezone
import sys
import unittest
from cavr_wbc.experiments.step33_io import ROOT, output, write


def run():
    out = output() / 'tests'
    out.mkdir(parents=True, exist_ok=True)
    log = out / 'NECESSARY_TESTS.log'
    if log.exists():
        raise FileExistsError('STEP33 necessary suite already attempted')
    started = datetime.now(timezone.utc).isoformat()
    suite = unittest.defaultTestLoader.discover(str(ROOT / 'tests'), pattern='test_step33*.py')
    with log.open('x', encoding='utf-8') as stream:
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    write(out / 'NECESSARY_TESTS.json', {
        'command': 'python -B -X utf8 -m cavr_wbc.experiments.step33_tests',
        'start_utc': started, 'finish_utc': datetime.now(timezone.utc).isoformat(),
        'tests_run': result.testsRun, 'failures': len(result.failures),
        'errors': len(result.errors), 'skipped': len(result.skipped),
        'successful': result.wasSuccessful(), 'fixture_only': True,
        'real_QP_calls': 0, 'real_physics_steps': 0, 'new_regression_model_fits': 0})
    print(log.read_text(encoding='utf-8'), flush=True)
    return 0 if result.wasSuccessful() else 1


if __name__ == '__main__':
    sys.exit(run())
