"""One current-batch delivery check, without solves, propagation or historical audit."""
from collections import Counter
from datetime import datetime, timezone
import math
from pathlib import Path
from cavr_wbc.experiments.step33_io import ROOT, output, read, write, sha
from cavr_wbc.experiments.step33_report import jsonl_rows


def run():
    out = output(); path = out / 'tests/DELIVERY_CHECK.json'
    if path.exists():
        raise FileExistsError('STEP33 delivery check already attempted')
    checks = []
    def check(name, condition, detail=None):
        checks.append({'name': name, 'pass': bool(condition), 'detail': detail})
    manifest = read(out / 'MANIFEST.json'); finished = read(out / 'RUN_FINISHED.json')
    result = read(out / 'STEP33_RESULT.json'); freeze = read(out / 'STEP33_FREEZE.json')
    budget = finished['budget']; diagnostic = read(out / 'SAVED_GATE_DIAGNOSTIC.json')
    pure = read(out / 'tests/NECESSARY_TESTS.json')
    check('necessary_fixture_suite_once', pure['successful'] and pure['tests_run'] == 46 and pure['real_QP_calls'] == pure['real_physics_steps'] == 0, pure)
    check('current_input_and_model_identity', all(sha(path) == digest for path, digest in manifest['current_input_model_sha256'].items()))
    check('fixed_20_DEV_36_TEST_source_identity', len(manifest['source_contexts']) == 56 and
          all(sha(row['source_path']) == row['source_sha256'] and row['new_reference_QP_calls'] == row['new_reference_steps'] == 0 for row in manifest['source_contexts']))
    check('saved_diagnostic_all_200_no_numerical_calls', len(diagnostic['sources']) == 200 and
          diagnostic['new_QP_calls'] == diagnostic['new_physics_steps'] == 0 and diagnostic['not_formal_teacher_CAL'])
    check('saved_STALE_five_calf_restored_ALIGNED_none', diagnostic['expected_five_STALE_calf_restored'] and not diagnostic['ALIGNED_static_groups'])
    check('new_runtime_frozen_hashes', all(sha(ROOT / path) == digest for path, digest in freeze['new_runtime_code_sha256'].items()))
    check('exactly_one_DEV_CAL_freeze_no_fit', freeze['freeze_count'] == 1 and freeze['regression_model_fits'] == 0 and not freeze['TEST_read_for_CAL'] and freeze['only_one_preTEST_check'])
    check('same_clock_and_cumulative_caps', budget['numerical_elapsed_s'] <= 5400 and budget['total_QP_calls'] <= 20000 and budget['total_physics_steps'] <= 200000 and budget['multioutput_estimator_fits'] == 0, budget)
    rows = list(jsonl_rows(out / 'STEP33_LEDGER.jsonl'))
    starts = [r for r in rows if r['event'] == 'QP_START']; returns = [r for r in rows if r['event'] == 'QP_RETURN']
    si = Counter(r['global_qp_index'] for r in starts); ri = Counter(r['global_qp_index'] for r in returns)
    check('every_real_QP_one_START_RETURN', si == ri and len(starts) == len(returns) == budget['total_QP_calls'] and all(v == 1 for v in si.values()) and all(r['real_optimizer_called'] for r in returns))
    timing = ('setup_time_s', 'update_time_s', 'update_settings_time_s', 'warm_start_wall_time_s',
              'solve_wall_time_s', 'solve_time_s', 'polish_time_s', 'invoke_total_wall_time_s')
    check('complete_setup_update_warm_solve_polish_ledger', all(all(isinstance(r.get(k), (int, float)) and math.isfinite(r[k]) and r[k] >= 0 for k in timing) and r['solve_wall_includes_polish'] and not r['end_to_end_hard_wall_cap_claim'] for r in returns))
    teacher = [r for r in returns if r['solver_owner_scope'] == 'OFFLINE_DELAY_TEACHER_DEV_ONLY']
    online = [r for r in returns if r['solver_owner_scope'] == 'ONLINE_6MS_20MS_WINDOW']
    check('teacher_exact_100ms_online_max6ms', len(teacher) + len(online) == len(returns) and all(r['osqp_time_limit_s'] == .100 for r in teacher) and all(.001 <= r['osqp_time_limit_s'] <= .006 for r in online))
    check('teacher_online_config_owners_disjoint', not ({r['solver_owner_id'] for r in teacher} & {r['solver_owner_id'] for r in online}))
    check('no_unknown_returns_or_step_reservations', budget['unknown_native_returns'] == budget['uncompleted_native_step_reservations'] == 0)
    queue = read(out / 'QUEUE_REGISTRY.json'); dev = read(out / 'DEV_REGISTRY.json')
    check('all_200_teacher_action_slots_retained', len(dev) == len({r['id'] for r in dev}) == 200)
    cal_groups = []
    for method in ('STALE_RECAL', 'ALIGNED_RECAL'):
        document = read(out / 'calibration' / method / ('step33_delay_cal_' + method.lower() + '.json'))
        check(method + '_original_static_rule_no_extra_missing_gate', not document['local_cal_rule']['missing_feature_group_rejects'] and
            all(bool(group['local_calibrated']) == bool(document['trained'] and group['cal_distinct_source_snapshots'] >= 4 and group['cal_episode_count'] >= 2) for group in document['groups'].values()))
        if method == 'ALIGNED_RECAL':
            cal_groups = [key for key, group in document['groups'].items() if group['local_calibrated'] and float(key.split(':')[0]) in (.75, .5, .25) and key.split(':')[1] != 'healthy']
    if freeze['readiness_branch'] == 'FULL_FIXED_PANEL':
        check('single_readiness_full_fixed_queue', bool(cal_groups) and len(queue) == 36 and all(r['status'] == 'DONE' for r in queue) and result['observed_formal_online_decisions'] == 72)
    else:
        diag = read(out / 'ENDPOINT_DIAGNOSTICS.json')
        check('single_readiness_exact_4x2_diagnostics', not cal_groups and len(diag) == 8 and {r['source_ordinal'] for r in diag} == {1, 10, 19, 28} and all(not r['selected_command_sent'] and r['ACTUAL_runs'] == 0 for r in diag))
        check('formal_queue_NOT_RUN_not_72_observations', len(queue) == 36 and all(r['status'] == 'NOT_RUN' for r in queue) and result['observed_formal_online_decisions'] == 0)
    actions = read(out / 'ONLINE_ACTION_STATUS.json')
    invalid_local = [r for r in actions if r['selected_incomplete_local_neighbor'] or r['selected_nonfinite_local_residual']]
    def nonfinite(value):
        return isinstance(value, dict) and 'nonfinite' in value or isinstance(value, float) and not math.isfinite(value)
    check('selected_incomplete_query_reject_nonfinite_targets', all(r['query_rejected'] and nonfinite(r['U_D_m']) and (nonfinite(r['U_T']) or all(nonfinite(v) for v in r['U_T'])) for r in invalid_local), len(invalid_local))
    check('72_planned_36_paired_32_extension_shadow_rows', result['row_counts'] == {'QUEUE_RESULTS': 72, 'PAIRED_TIMING_RESULTS': 36, 'ACTION_EXTENSION_RESULTS': 32, 'CAPACITY_SHADOW_RESULTS': 32})
    check('A_B_C_separate_old_invalid_no_E3', result['OLD_STEP32_SCIENTIFIC_STATUS'] == 'INVALID_PROTOCOL_CALIBRATION_GATE' and not result['E3_RL_hardware_authorized'] and
        result['A_STATUS'] in ('APPLICATION_ALIGNMENT_EFFECT_OBSERVED', 'NOT_ESTABLISHED') and
        result['B_STATUS'] in ('SAFE_ACTION_EXTENSION_OBSERVED', 'NOT_ESTABLISHED') and
        result['C_STATUS'] in ('CAPACITY_BOUND_EFFECT_OBSERVED', 'NOT_ESTABLISHED'))
    qa = read(out / 'figures/FIGURE_QA.json')
    check('exactly_two_SciPilot_figures_color_grayscale_review', qa['figure_count'] == 2 and qa['AI_visual_review'] == 'REVIEWED' and not qa['missing_glyph_warnings'] and
        all(not item['text_outside_canvas'] and not item['adjacent_tick_overlaps'] and item['minimum_visible_font_pt'] >= 8 and all(not any(issue[0] == 'FAIL' for issue in f['issues']) for f in item['formats'].values()) for item in qa['programmatic'].values()))
    # Matplotlib Type-0 parent fonts embed TrueType data in DescendantFonts.
    # The SciPilot generic checker warns on the parent without following them.
    try:
        from pypdf import PdfReader
    except ImportError:
        from PyPDF2 import PdfReader
    fonts = []
    for stem in ('STEP33_paired_queue', 'STEP33_middle_events'):
        pdf = PdfReader(str(out / 'figures' / (stem + '.pdf')))
        for page in pdf.pages:
            for font_ref in page['/Resources']['/Font'].values():
                font = font_ref.get_object()
                children = font.get('/DescendantFonts') or [font]
                for child_ref in children:
                    child = child_ref.get_object()
                    descriptor = child.get('/FontDescriptor')
                    descriptor = descriptor.get_object() if descriptor else {}
                    stream = descriptor.get('/FontFile2')
                    fonts.append({'figure': stem, 'font': str(child.get('/BaseFont')),
                        'subtype': str(child.get('/Subtype')), 'embedded_TrueType': bool(stream),
                        'embedded_bytes': len(stream.get_object().get_data()) if stream else 0})
    check('PDF_descendant_TrueType_fonts_embedded', bool(fonts) and all(font['embedded_TrueType'] and font['embedded_bytes'] > 0 for font in fonts), fonts)
    document = {'command': 'python -B -X utf8 -m cavr_wbc.experiments.step33_verify', 'check_count': len(checks),
        'completed_utc': datetime.now(timezone.utc).isoformat(), 'checks': checks,
        'status': 'PASS' if all(row['pass'] for row in checks) else 'FAIL',
        'scope': 'CURRENT_INPUTS_MODELS_NEW_EVIDENCE_ONLY_NOT_A_HISTORICAL_SOLVE_AUDIT',
        'new_QP_calls': 0, 'new_physics_steps': 0, 'new_regression_fits': 0}
    write(path, document)
    print(document)
    return document


if __name__ == '__main__':
    run()
