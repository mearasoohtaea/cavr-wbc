"""One immutable 90-minute / 25,000 QP / 250,000 integration budget."""
from collections import Counter
from datetime import datetime, timezone
import json
import os
from pathlib import Path
from time import perf_counter
from cavr_wbc.experiments.step30_budget import SprintBudget as BaseBudget, SprintLimit
from cavr_wbc.experiments.step34_io import write, read


class SprintBudget(BaseBudget):
    @classmethod
    def resume_dev_repair(cls, out):
        """Explicit protocol-allowed DEV repair; no budget/time reset."""
        out = Path(out)
        if (out / 'STEP34_FREEZE.json').exists():
            raise ValueError('TEST/frozen numerical batch cannot be repaired/retried')
        saved = read(out / 'RUN_FINISHED.json')['budget']
        if saved['unknown_native_returns'] or saved['uncompleted_native_step_reservations']:
            raise ValueError('cannot resume while numerical work has unknown identity')
        attempt = len(list((out / 'repairs').glob('REPAIR_*_STARTED.json'))) + 1
        if attempt > 2:
            raise ValueError('two DEV engineering repairs exhausted')
        self = cls.__new__(cls)
        self.out = out
        self.path = out / 'STEP34_LEDGER.jsonl'
        self.stream = self.path.open('a', encoding='utf-8', newline='\n')
        self.buffer = []
        self.qp_calls = saved['total_QP_calls']
        self.returned = saved['QP_returns']
        self.physics_steps = saved['total_physics_steps']
        self.reserved = 0
        self.start_utc = saved['numerical_started_utc']
        elapsed = (datetime.now(timezone.utc) - datetime.fromisoformat(self.start_utc)).total_seconds()
        self.started = perf_counter() - elapsed
        self.qp_kinds = Counter(saved['QP_by_kind'])
        self.step_kinds = Counter(saved['physics_by_kind'])
        self.fit_count = saved['multioutput_estimator_fits']
        self.risk_fit_count = saved.get('physical_risk_head_fits', 0)
        self.dev_recomputations = saved['DEV_context_recomputations']
        self.tokens = {}
        self.reservation_id = max((json.loads(line).get('reservation_id', 0)
            for line in self.path.read_text(encoding='utf-8').splitlines()), default=0)
        self.persisted_qp_calls = self.qp_calls
        self.persisted_returns = self.returned
        write(out / 'repairs' / f'REPAIR_{attempt:02d}_PREVIOUS_FINISH.json', read(out / 'RUN_FINISHED.json'))
        if (out / 'INTERRUPTION.json').exists():
            write(out / 'repairs' / f'REPAIR_{attempt:02d}_PREVIOUS_INTERRUPTION.json', read(out / 'INTERRUPTION.json'))
        write(out / 'repairs' / f'REPAIR_{attempt:02d}_STARTED.json', {'pid': os.getpid(),
            'repair_ordinal': attempt, 'start_utc': datetime.now(timezone.utc).isoformat(),
            'budget_before': saved, 'numerical_clock_not_reset': True,
            'existing_scientific_artifacts_not_overwritten': True,
            'completed_results_not_recomputed': True})
        self.event('DEV_ENGINEERING_REPAIR_CONTINUATION', repair_ordinal=attempt,
                   original_start_utc=self.start_utc, completed_results_not_recomputed=True)
        self.check()
        return self

    def __init__(self, out):
        self.out = Path(out)
        self.path = self.out / 'STEP34_LEDGER.jsonl'
        self.stream = self.path.open('x', encoding='utf-8', newline='\n')
        self.buffer = []
        self.qp_calls = self.returned = self.physics_steps = self.reserved = 0
        self.started = self.start_utc = None
        self.qp_kinds = Counter()
        self.step_kinds = Counter()
        self.fit_count = self.dev_recomputations = self.reservation_id = 0
        self.risk_fit_count = 0
        self.tokens = {}
        self.persisted_qp_calls = self.persisted_returns = 0

    def start(self):
        if self.started is None:
            self.started = perf_counter()
            self.start_utc = datetime.now(timezone.utc).isoformat()
            self.event('NUMERICAL_STARTED', hard_wall_s=5400, QP_limit=25000,
                       step_limit=250000, regression_fit_limit=1, physical_risk_fit_limit=1)

    def check(self):
        if self.started is not None and perf_counter() - self.started >= 5400:
            raise SprintLimit('90-minute numerical hard cap')
        if self.qp_calls >= 25000:
            raise SprintLimit('25000 real QP hard cap')
        if self.physics_steps + self.reserved >= 250000:
            raise SprintLimit('250000 integration step hard cap including reservations')

    def reserve_steps(self, kind, owner, n):
        self.start()
        self.check()
        if int(n) != n or n < 0 or self.physics_steps + self.reserved + n > 250000:
            raise SprintLimit('prediction reservation exceeds integration budget')
        self.reservation_id += 1
        token = self.reservation_id
        self.tokens[token] = (kind, owner, int(n))
        self.reserved += int(n)
        self.event('PREFIX_NATIVE_START', reservation_id=token, kind=kind,
                   owner=owner, reserved_steps=int(n))
        return token

    def persist(self, **extra):
        for row in self.buffer:
            self.stream.write(json.dumps(row, sort_keys=True, allow_nan=False) + '\n')
        self.stream.flush()
        os.fsync(self.stream.fileno())
        self.buffer.clear()
        self.persisted_qp_calls = self.qp_calls
        self.persisted_returns = self.returned
        write(self.out / 'STEP34_PROGRESS.json', {**self.snapshot(), **extra})

    def qp_callback(self, kind, owner, first_mode=None):
        """Every real call has one START/RETURN, including teacher setup/polish."""
        active = {}
        def call(stage, payload, solve):
            if stage == 'before':
                self.start(); self.check()
                self.qp_calls += 1; self.qp_kinds[kind] += 1
                active.clear()
                active.update(global_qp_index=self.qp_calls, kind=kind, owner=owner,
                              first_mode=first_mode, local_qp_index=payload['solver_call_index'])
                self.event('QP_START', **active)
                return solve()
            result = payload['result']; self.returned += 1
            fields = ('status', 'status_val', 'iterations', 'real_optimizer_called',
                'primal_residual', 'dual_residual', 'setup_time_s', 'update_time_s',
                'update_settings_time_s', 'warm_start_wall_time_s', 'solve_time_s',
                'solve_wall_time_s', 'polish_time_s', 'polish_status', 'invoke_total_wall_time_s',
                'warm_started', 'workspace_reused', 'kernel_variant', 'osqp_time_limit_s',
                'configured_native_time_limit_s', 'solver_owner_id', 'solver_owner_scope',
                'owner_pid', 'solve_wall_includes_polish', 'end_to_end_hard_wall_cap_claim',
                'candidate_valid', 'strict_candidate_mask', 'optimizer_converged', 'candidate_certificate')
            self.event('QP_RETURN', **active, **{key: result.get(key) for key in fields})
        return call


    def snapshot(self):
        return {**super().snapshot(), 'physical_risk_head_fits': self.risk_fit_count}

    def register_fit(self, kind):
        self.start(); self.check()
        if kind == 'REGRESSION' and self.fit_count == 0:
            self.fit_count = 1
        elif kind == 'PHYSICAL_RISK' and self.risk_fit_count == 0:
            self.risk_fit_count = 1
        else:
            raise ValueError('STEP34 permits exactly one fit per fixed head')
        self.event('MODEL_FIT_START', kind=kind)
