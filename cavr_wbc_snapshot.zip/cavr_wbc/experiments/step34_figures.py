"""Two SciPilot full-result saved-only figures; no optimizer/integration/fit."""
from pathlib import Path
import importlib.util
import warnings
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from PIL import Image
from cavr_wbc.experiments.step34_io import output, read, write
from cavr_wbc.experiments.step33_report import csv_write
SKILL = Path('C:/Users/ZhuanZ（无密码）/.codex/skills/scipilot-figure')
FINAL_EXPORT = '--final-export-after-review' in sys.argv

def helper(name):
    spec = importlib.util.spec_from_file_location('step33_' + name, SKILL / 'scripts' / (name + '.py'))
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod


def profile(out, queue, cal, candidates):
    module = helper('profile_data')
    for name, data in (('queue', queue), ('cal', cal), ('candidates', candidates)):
        if data:
            scalar_data = [{key: value for key, value in row.items() if not isinstance(value, (dict, list, tuple, np.ndarray))} for row in data]
            info = module.profile_data(pd.DataFrame(scalar_data), group_cols=['method'] if 'method' in data[0] else [])
            (out / ('EDA_' + name + '.md')).write_text(module.render_report(info), encoding='utf-8')
        else:
            (out / ('EDA_' + name + '.md')).write_text('No observed events. Missing is not a zero-valued trajectory.\n', encoding='utf-8')
    write(out / 'FIGURE_PLAN.json', {
        'skill': 'scipilot-figure-skill', 'publication': 'IEEE T-RO', 'figure_count': 2,
        'width_in': 7.16, 'raster_dpi': 600, 'minimum_font_pt': 8,
        'queue_n': len(queue), 'CAL_n': len(cal), 'reference_candidate_n': len(candidates),
        'figure1': 'All96 method slots and all120 CAL slots remain NOT_RUN, not zero trajectories.',
        'figure2': 'All24 corrected reference candidates in eight episode panels; raw1 still requires original contact rows.',
        'rationale': 'Categorical identities remain separate; show distributions and missingness, not averages.',
        'alternatives': ['A mean bar would hide failures and missing trajectories.',
                         'A line between queue identities would imply continuity.',
                         'Selecting only successful middle events would change the denominator.'],
        'missing_policy': 'NOT_RUN/ABSTAIN/partial are retained; absent measurements never plotted as zero.',
        'numerical_calls': 0, 'fits': 0})


def style():
    helper('setup_style').setup_style(journal='ieee', lang='en', use_sciplots=False, constrained_layout=False)
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8,
        'axes.labelsize': 8, 'axes.titlesize': 9, 'xtick.labelsize': 8, 'ytick.labelsize': 8,
        'legend.fontsize': 8, 'pdf.fonttype': 42, 'svg.fonttype': 'none'})


def save(fig, out, stem):
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer(); bounds = fig.bbox
    outside = []
    from matplotlib.text import Text
    for text in fig.findobj(Text):
        if not text.get_visible() or not text.get_text():
            continue
        box = text.get_window_extent(renderer)
        if box.x0 < bounds.x0 - 2 or box.y0 < bounds.y0 - 2 or box.x1 > bounds.x1 + 2 or box.y1 > bounds.y1 + 2:
            outside.append(text.get_text())
    overlaps = []
    for i, ax in enumerate(fig.axes):
        for axis in (ax.xaxis, ax.yaxis):
            boxes = [(t.get_text(), t.get_window_extent(renderer)) for t in axis.get_ticklabels() if t.get_visible() and t.get_text()]
            for (a, x), (b, y) in zip(boxes, boxes[1:]):
                if x.overlaps(y):
                    overlaps.append({'axis': i, 'ticks': [a, b]})
    formats = ('pdf', 'svg', 'png') if FINAL_EXPORT else ('png',)
    for ext in formats:
        fig.savefig(out / (stem + '.' + ext), dpi=600, facecolor='white')
    fig.savefig(out / (stem + '_preview.png'), dpi=160, facecolor='white')
    with Image.open(out / (stem + '.png')) as src:
        src.convert('L').save(out / (stem + '_gray.png'), dpi=(600, 600))
    with Image.open(out / (stem + '_preview.png')) as src:
        src.convert('L').save(out / (stem + '_gray_preview.png'), dpi=(160, 160))
    checker = helper('check_figure')
    checks = {}
    for ext in formats:
        issues, info = checker.check_figure(str(out / (stem + '.' + ext)), min_dpi=600)
        checks[ext] = {'issues': issues, 'info': info}
    result = {'text_outside_canvas': outside, 'adjacent_tick_overlaps': overlaps,
              'formats': checks, 'minimum_visible_font_pt': min(t.get_fontsize() for t in fig.findobj(Text) if t.get_visible() and t.get_text())}
    plt.close(fig)
    return result


def missing_queue(out, queue, cal):
    fig, axes = plt.subplots(2, 1, figsize=(7.16, 5.3), gridspec_kw={'height_ratios': [1.2, 1.]})
    fig.subplots_adjust(left=.145, right=.975, bottom=.13, top=.81, hspace=.75)
    fig.suptitle('STEP34 | full fixed plan and missing executions', y=.965, fontsize=11)
    fig.text(.145, .905, '× NOT_RUN / reference state unavailable — not a zero-valued trajectory', fontsize=8)
    axes[0].set_title('(a)  All 16 TEST source states × three gaps × two policies', loc='left', fontsize=9, pad=12)
    policies = ('APPLICATION_FEAS_GOV', 'APPLICATION_FEAS_BINARY')
    for row in queue:
        x = row['source_state_ordinal'] + 1
        y = (int(row['gap_m'] * 1000) - 4) + policies.index(row['method'])
        axes[0].scatter(x, y, marker='x', s=23, color='#666666', linewidths=.8)
    axes[0].set(xlim=(.4, 16.6), ylim=(-.6, 5.6), yticks=range(6),
        yticklabels=('GOV · 4 mm', 'Binary · 4 mm', 'GOV · 6 mm', 'Binary · 6 mm', 'GOV · 8 mm', 'Binary · 8 mm'),
        xlabel='Planned TEST source state index', xticks=(1, 4, 8, 12, 16))
    for x in (4.5, 8.5, 12.5):
        axes[0].axvline(x, color='#DDDDDD', linewidth=.6, zorder=0)
    axes[1].set_title('(b)  All 24 CAL inputs × five Gamma action slots', loc='left', fontsize=9, pad=12)
    gammas = (1., .75, .5, .25, 0.)
    context_ids = list(dict.fromkeys(r['context_id'] for r in cal))
    for row in cal:
        axes[1].scatter(context_ids.index(row['context_id']) + 1, gammas.index(row['gamma']),
                        marker='x', color='#666666', s=23, linewidths=.8)
    axes[1].set(xlim=(.4, 24.6), ylim=(-.6, 4.6), yticks=range(5), yticklabels=('1', '.75', '.50', '.25', '0'),
        ylabel='Gamma (categorical)', xlabel='Planned CAL context index', xticks=(1, 6, 12, 18, 24))
    for x in (6.5, 12.5, 18.5):
        axes[1].axvline(x, color='#DDDDDD', linewidth=.6, zorder=0)
    for ax in axes:
        ax.grid(axis='y', color='#EEEEEE', linewidth=.5, zorder=0)
    axes[0].invert_yaxis(); axes[1].invert_yaxis()
    fig.text(.145, .035, '0/96 decisions; 0/120 complete CAL; 0 ACTUAL. Gap repeats are not independent states.', fontsize=8)
    return save(fig, out, 'STEP34_all_results')


def reference_candidates(out, rows):
    episodes = list(dict.fromkeys(r['episode'] for r in rows))
    fig, axes = plt.subplots(4, 2, figsize=(7.16, 7.2), sharex=True, sharey=True)
    fig.subplots_adjust(left=.09, right=.975, bottom=.14, top=.84, hspace=.85, wspace=.4)
    fig.suptitle('STEP34 | every corrected reference candidate', y=.967, fontsize=11)
    handles = [Line2D([], [], marker='o', linestyle='none', color='#0072B2', markerfacecolor='none', label='Current contract accepted'),
               Line2D([], [], marker='x', linestyle='none', color='#D55E00', label='Current contract rejected'),
               Line2D([], [], color='#222222', linestyle='--', label='Original tolerance')]
    fig.legend(handles=handles, loc='upper center', bbox_to_anchor=(.53, .94), ncol=2, frameon=False, fontsize=8)
    for i, (ax, episode) in enumerate(zip(axes.flat, episodes)):
        selected = [r for r in rows if r['episode'] == episode]
        for row in selected:
            accepted = bool(row['candidate_valid']); ratio = row['contact_residual_inf_m_s2'] / 1e-5
            ax.scatter(row['reference_time_s'], ratio, color='#0072B2' if accepted else '#D55E00',
                marker='o' if accepted else 'x', facecolors='none' if accepted else '#D55E00', s=28, linewidths=.9)
        ax.axhline(1, color='#222222', linestyle='--', linewidth=.7)
        ax.set_title('(' + chr(97 + i) + ')  ' + episode + ' · all raw status 1', loc='left', fontsize=8, pad=8)
        ax.set(xlim=(-.003, .043), ylim=(0, 1.18), xticks=(0, .02, .04), yticks=(0, .5, 1))
        if i % 2 == 0:
            ax.set_ylabel('Contact residual / tol.', fontsize=8)
        if i >= 6:
            ax.set_xlabel('Reference time (s)', fontsize=8)
        ax.grid(axis='y', color='#EEEEEE', linewidth=.5)
        ax.tick_params(labelbottom=True)
    fig.text(.09, .067, 'All 24 candidates from eight corrected reference episodes; 16 accepted, 8 rejected before invalid actuation.', fontsize=8)
    fig.text(.09, .039, 'Original contact tolerance = 1e−5 m/s². Tick 2 rejects stop each episode at 20 integration steps.', fontsize=8)
    fig.text(.09, .011, 'Startup and first interrupted reference lack complete raw shards; not substituted into this figure.', fontsize=8)
    return save(fig, out, 'STEP34_candidate_bottleneck')


def run():
    root = output(); out = root / 'figures'; out.mkdir(exist_ok=True)
    queue = read(root / 'QUEUE_RESULTS.json'); cal = read(root / 'CAL_RESULTS.json')
    candidates = read(root / 'CURRENT_CANDIDATE_MASK.json')
    profile(out, queue, cal, candidates); style()
    csv_write(out / 'ALL_QUEUE_POINT_DATA.csv', queue); csv_write(out / 'ALL_CAL_POINT_DATA.csv', cal)
    csv_write(out / 'ALL_REFERENCE_CANDIDATE_POINT_DATA.csv', candidates)
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        checks = {'all_results': missing_queue(out, queue, cal), 'candidate_bottleneck': reference_candidates(out, candidates)}
    write(out / 'FIGURE_QA.json', {'figure_count': 2, 'saved_only': True, 'programmatic': checks,
        'missing_glyph_warnings': [str(w.message) for w in caught if 'Glyph' in str(w.message) or 'missing from font' in str(w.message)],
        'AI_visual_review': 'PENDING_PREVIEW_REVIEW', 'no_actual_or_prefix_events_invented': True})
    print({'figures': 2, 'queue_slots': len(queue), 'CAL_slots': len(cal), 'current_candidates': len(candidates), 'QA': checks})


if __name__ == '__main__':
    run()
