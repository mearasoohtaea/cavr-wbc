"""New fixed STEP34 reference recipe using the same candidate contract."""
from types import SimpleNamespace
from collections.abc import Mapping
from time import perf_counter
import mujoco
import numpy as np
from cavr_wbc.experiments import step26_sim as source
from cavr_wbc.experiments import step17_formal_panel as frozen
from cavr_wbc.control.step34_candidate import CandidateWBC
from cavr_wbc.control.step34_servo import CapacityPoseServo
from cavr_wbc.control.step20_task_reference import reference
from cavr_wbc.control.step23_backup_filter import (CONTROL_DT_S, PHYSICS_DT_S, PHYSICS_STEPS_PER_SLOT,
    state_values, predicted_physical_check)
from cavr_wbc.platforms.go2_mujoco import extract_healthy_torque_limits
from cavr_wbc.experiments.step34_io import encode as _json_safe
_check = source._check
_callback = source._callback
_observer = source._observer
_finite_state = source._finite_state
compact_fact = source.compact_fact
REFERENCE_TICKS = 110
REFERENCE_STEPS = 1100
VERSION = 'STEP34_CANDIDATE_HEALTHY_REFERENCE_V1'

def reference_episode(model, scenario, d_m, episode_id, snapshot_ticks, budget):
    """Generate the fixed healthy 2.2 s stance reference and pre-control snapshots."""
    _check(budget)
    begin = perf_counter()
    ticks = tuple(int(t) for t in snapshot_ticks)
    if len(set(ticks)) != len(ticks) or any(t < 0 or t >= REFERENCE_TICKS for t in ticks):
        raise ValueError("STEP34 snapshot ticks must be unique reference control ticks")
    data = mujoco.MjData(model)
    reset_scenario = SimpleNamespace(**scenario) if isinstance(scenario, Mapping) else scenario
    frozen._reset(model, data, reset_scenario)
    if np.any(data.qfrc_applied) or np.any(data.xfrc_applied):
        raise ValueError("STEP34 healthy reference requires the original zero external forces")
    initial = state_values(model, data)
    q_init = data.qpos.copy()
    health = np.ones(int(model.nu))
    limits = extract_healthy_torque_limits(model)
    controller = CandidateWBC(model, solve_callback=_callback(budget, "REFERENCE", episode_id))
    # Continuous healthy reference control is feedback, not a C/B first packet.
    controller.solver_time_limit_s = .006
    servo = CapacityPoseServo(model)
    servo.reset(q_init, d_m)
    observer = _observer(budget, "REFERENCE", episode_id)
    previous = {'tau_raw': data.ctrl.copy(), 'effective_capacity_nm': health * limits, 'command_valid': True}
    snapshots = []
    steps = 0
    forward_calls = 0
    controls = []
    failure = None
    vmin = vmax = float(data.qvel[0])
    for tick in range(REFERENCE_TICKS):
        _check(budget)
        if not _finite_state(data):
            failure = {"reason": "NONFINITE_REFERENCE_BEFORE_CONTROL", "tick": tick, "physics_step": steps}
            break
        if tick in ticks:
            fact = compact_fact(model, data, health, limits, data.ctrl.copy(), 0., 0., steps,
                                tick, "STEP34-REFERENCE-" + episode_id, episode_id,
                                previous, {"health_vector": health.tolist()})
            physical = predicted_physical_check(fact)
            vx = float(data.qvel[0])
            state = state_values(model, data)
            ref = reference(float(q_init[0]), float(d_m), tick * CONTROL_DT_S)
            snapshots.append({"snapshot_id": f"{episode_id}_T{tick:03d}", "episode_id": episode_id,
                "source_tick": tick, "source_time_s": tick * CONTROL_DT_S,
                "state": state, "nominal_q_init": q_init.tolist(), "nominal_d_m": float(d_m),
                "nominal_b_used": servo.b_integral.copy().tolist(),
                "current_reference": ref, "source_external_reference": ref,
                "x0_m": float(data.qpos[0]), "vx_m_s": vx, "vx": vx,
                "direction": 1 if vx > 0. else -1 if vx < 0. else 0,
                "sign": 1 if vx > 0. else -1 if vx < 0. else 0,
                "healthy_fact": fact, "healthy_physical_check": physical,
                "eligible": bool(physical["pass"] and abs(vx) >= .01),
                "eligibility_reason": None if physical["pass"] and abs(vx) >= .01 else
                    "ORIGINAL_PHYSICAL_UNQUALIFIED" if not physical["pass"] else "ABS_VX_LT_0P01_M_S",
                "backup_anchor_q_init": data.qpos.copy().tolist(),
                "source_integration_state_complete": True})
        response = servo.compute(controller, data, health, tick)
        interface = response["capacity_interface"]
        raw = response.get("wbc", response.get("raw_solver_result", {}))
        controls.append({"tick": tick, "time_s": tick * CONTROL_DT_S,
                         "valid_command": bool(response["valid_command"]),
                         "solver_status": response["wbc"].get("status"),
                         "solver_status_val": response["wbc"].get("status_val"),
                         "tau_raw": interface["tau_raw"], "tau_sent": response["tau_cmd"],
                         "latency_ms": response["latency_ms"],
                         "integral_record": response["integral_record"],
                         "candidate_valid": bool(response["valid_command"]),
                         "candidate_certificate": raw.get("candidate_certificate"),
                         "raw_solver_result": raw,
                         "candidate_schema": interface.get("version", interface.get("schema"))})
        if not response["valid_command"]:
            failure = {"reason": "INVALID_REFERENCE_QP", "tick": tick, "physics_step": steps,
                       "solver_status_val": response["wbc"].get("status_val")}
            break
        data.ctrl[:] = response["tau_cmd"]
        mujoco.mj_forward(model, data)
        forward_calls += 1
        previous = interface
        for _ in range(PHYSICS_STEPS_PER_SLOT):
            if observer is not None:
                observer()
            mujoco.mj_step(model, data)
            steps += 1
            if not _finite_state(data) or abs(float(data.time) - steps * PHYSICS_DT_S) > 1e-9:
                failure = {"reason": "NONFINITE_REFERENCE_OR_SIMULATOR_RESET", "tick": tick, "physics_step": steps}
                break
            mujoco.mj_forward(model, data)
            forward_calls += 1
            if not _finite_state(data):
                failure = {"reason": "NONFINITE_REFERENCE_REFRESH", "tick": tick, "physics_step": steps}
                break
            vx = float(data.qvel[0])
            vmin, vmax = min(vmin, vx), max(vmax, vx)
        if failure:
            break
    complete = steps == REFERENCE_STEPS and len(controls) == REFERENCE_TICKS and failure is None
    return ({"schema": VERSION, "episode_id": episode_id, "d_ref_m": float(d_m),
        "status": "COMPLETE" if complete else "FAILED_NUMERICAL", "reason": failure,
        "initial_state": initial, "q_init": q_init.tolist(), "snapshots": snapshots,
        "requested_snapshot_ticks": list(ticks), "controls": controls,
        "missing_snapshot_ticks": [tick for tick in ticks if tick not in {s["source_tick"] for s in snapshots}],
        "actual_vx_range_m_s": [vmin, vmax], "max_abs_vx_m_s": max(abs(vmin), abs(vmax)),
        "motion_excitation_reaches_0p08_m_s": max(abs(vmin), abs(vmax)) >= .08,
        "final_state": state_values(model, data), "solver_ledger": controller.solver_ledger,
        "elapsed_ms": (perf_counter() - begin) * 1000.,
        "counts": {"physical_steps": steps, "control_qp_calls": len(controller.solver_ledger),
                   "reference_controller_instances": 1, "initialization_forward_calls": 1,
                   "forward_calls": forward_calls + 1, "clone_data_calls": 0,
                   "contact_linearization_calls": controller.contact_linearization_calls,
                   "svd_calls": controller.svd_calls, "passive_model_calls": controller.passive_model_calls}})
