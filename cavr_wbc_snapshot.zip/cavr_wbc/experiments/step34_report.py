"""STEP34 saved-only analysis. Missing state/action evidence is not a zero result."""
from collections import Counter
from pathlib import Path
import math
import numpy as np
from cavr_wbc.experiments.step34_io import output, ROOT, METHODS, read, write, load_numeric, relative
from cavr_wbc.experiments.step33_report import csv_write, statistics, finite, jsonl_rows, resolve, numeric_record
from cavr_wbc.control.step34_margin import load_bundle, GAMMA_GRID

def safe(label, gap):
    return bool(label.get('complete') and label.get('full_501_grid') is True and
                label.get('original_physical_safe') and label.get('terminal_pass') and label.get('command_valid_all') and
                finite(label.get('D')) and finite(gap) and 0. <= label['D'] <= gap)


def capacity_event(events):
    events = events or {}
    return bool(events.get('first_capacity_event') or events.get('first_active_indices') or
                events.get('any_actual_capacity99_event') or any(int(value) > 0 for value in events.get('capacity99_count_by_channel', [])))


def branch_facts(record, gap):
    record = record or {}; label = record.get('label') or {}; ticks = record.get('tick_latency_ms') or []
    status = record.get('status', 'NOT_RUN')
    counts = record.get('counts') or {}
    executed = bool(status != 'NOT_RUN' and (record.get('artifact') or ticks or counts.get('physical_steps', 0) or
                                           status in ('COMPLETE', 'FAILED_NUMERICAL', 'FAILED_BUDGET')))
    complete = bool(label.get('complete') and label.get('full_501_grid') is True)
    tick_pass = bool(complete and len(ticks) == 50 and all(finite(value) and 0. <= value <= 20. for value in ticks)
                     and record.get('all_tick_deadline_pass') is True)
    first_match = record.get('first_tau_matches_packet')
    identity = record.get('application_identity_pass')
    physical_failure = bool(executed and (label.get('original_failure') or label.get('observed_original_physical_failure') or
                                         (complete and not label.get('original_physical_safe'))))
    local_failure = bool(complete and finite(label.get('D')) and finite(gap) and label['D'] > gap)
    terminal_failure = bool(complete and not label.get('terminal_pass'))
    actual_safe = safe(label, gap)
    confirmed = bool(actual_safe and tick_pass and identity is True and first_match is True and
                     record.get('actual_horizon_origin') == 'SAMPLE' and record.get('actual_horizon_s') == 1.)
    return {'status': status, 'executed': executed, 'complete_501': complete,
        'physical_pass': bool(complete and label.get('original_physical_safe')), 'terminal_pass': bool(complete and label.get('terminal_pass')),
        'local_pass': bool(complete and finite(label.get('D')) and finite(gap) and 0. <= label['D'] <= gap),
        'actual_safe_at_fixed_gap': actual_safe, 'full_50_ticks_20ms': tick_pass, 'execution_confirmed': confirmed,
        'physical_failure': physical_failure, 'local_failure': local_failure, 'terminal_failure': terminal_failure,
        'command_failure': bool(complete and not label.get('command_valid_all')),
        'numerical_incomplete': bool(executed and not complete),
        'deadline_failure': bool(executed and (any(finite(value) and value > 20. for value in ticks) or
                                             (complete and not tick_pass))),
        'application_identity_pass': identity, 'application_identity_failure': bool(executed and identity is False),
        'first_tau_matches_packet': first_match,
        'observed_unsafe': bool(physical_failure or local_failure or terminal_failure),
        'known_complete_failure': bool(complete and (not actual_safe or not tick_pass or identity is not True or first_match is not True)),
        'late_ticks': sum(finite(value) and value > 20. for value in ticks), 'missing_or_nonfinite_ticks': sum(not finite(value) for value in ticks),
        'D_m': label.get('D'), 'Y': label.get('Y'), 'progress0_04_m': record.get('progress0_04_m'),
        'progress02_04_m': record.get('progress02_04_m'), 'tick_latency_ms': ticks,
        'capacity99_event': capacity_event(record.get('events')), 'first_packet_capacity99_event': bool((record.get('events') or {}).get('first_capacity_event')),
        'events': record.get('events'), 'counts': counts, 'artifact': record.get('artifact'),
        'controls_path': record.get('controls_path'), 'result_path': record.get('result_path'),
        'application_state_comparison': record.get('application_state_comparison'), 'reason': record.get('reason')}


def dump(out, name, rows):
    write(out / (name + '.json'), rows); csv_write(out / (name + '.csv'), rows)


def candidate_row(raw, metadata):
    proof = raw.get('candidate_certificate') or {}
    hard = proof.get('raw_hard_check') or {}
    sent = proof.get('sent_hard_check') or {}
    return {**metadata, 'raw_status': raw.get('status_val'), 'raw_status_text': raw.get('status'),
        'optimizer_converged': proof.get('optimizer_converged'), 'candidate_valid': proof.get('candidate_valid'),
        'strict_candidate_mask': proof.get('strict_candidate_mask'), 'rejection_reason': proof.get('rejection_reason'),
        'raw_full_primal_recorded': raw.get('full_current_raw_x') is not None,
        'full_same_call_CSC_recorded': raw.get('step34_problem') is not None,
        'raw_state_health_identity': proof.get('current_state_health_identity'),
        'failed_raw_rows': np.asarray(hard.get('failed_row_indices', [])).tolist(),
        'failed_sent_rows': np.asarray(sent.get('failed_row_indices', [])).tolist(),
        'contact_residual_inf_m_s2': hard.get('contact_residual_inf'),
        'dynamics_residual_inf_SI': hard.get('dynamics_residual_inf'),
        'native_limit_s': raw.get('osqp_time_limit_s'),
        'solve_wall_ms': raw.get('solve_wall_time_s', 0.) * 1000.,
        'invoke_wall_ms': raw.get('invoke_total_wall_time_s', 0.) * 1000.}


def references(out):
    rows = []; candidates = []; failed_rows = []
    for path in sorted((out / 'episodes').glob('*.json')):
        episode = load_numeric(path)
        rows.append({'episode': episode['episode_id'], 'split': 'CAL' if episode['episode_id'].startswith('C') else 'TEST',
            'status': episode['status'], 'reason': episode.get('reason'), 'physical_steps': episode['counts']['physical_steps'],
            'control_calls': episode['counts']['control_qp_calls'], 'snapshots_saved': len(episode['snapshots']),
            'requested_ticks': episode['requested_snapshot_ticks'], 'missing_ticks': episode['missing_snapshot_ticks'],
            'path': relative(path, out), 'elapsed_ms': episode['elapsed_ms']})
        for control in episode['controls']:
            raw = control['raw_solver_result']
            meta = {'kind': 'REFERENCE', 'episode': episode['episode_id'], 'tick': control['tick'],
                'reference_time_s': control['time_s'], 'source_path': relative(path, out)}
            candidates.append(candidate_row(raw, meta))
            proof = raw.get('candidate_certificate') or {}; hard = proof.get('raw_hard_check') or {}
            matrix = raw.get('source_matrices') or {}
            for index in hard.get('failed_row_indices', []):
                index = int(index)
                failed_rows.append({**meta, 'raw_status': raw['status_val'], 'candidate_valid': proof['candidate_valid'],
                    'row': index, 'row_unit': matrix['row_units'][index], 'A_z': float(hard['A_z'][index]),
                    'lower': float(matrix['l'][index]), 'upper': float(matrix['u'][index]),
                    'original_tolerance': float(matrix['row_abs_tolerance'][index]),
                    'violation': float(hard['row_violation'][index]),
                    'violation_to_tolerance': float(hard['row_violation'][index] / matrix['row_abs_tolerance'][index]) if matrix['row_abs_tolerance'][index] else None})
    return rows, candidates, failed_rows


def online_contrasts(packet, context, old_model):
    """Only saved/evaluated prefixes; no missing action is evaluated for free."""
    from cavr_wbc.control.step33_margin import batch_numeric as old_numeric
    rows = []
    for gamma in GAMMA_GRID:
        entry = packet.get('actions', {}).get(str(gamma), {})
        decision = entry.get('decision') or {}; action = entry.get('action') or {}
        features = entry.get('features26'); prefix = entry.get('prefix') or {}
        strict = bool(action.get('strict_candidate_mask'))
        evaluated = entry.get('evaluation_status') == 'EVALUATED' and features is not None
        old_accept = None
        if evaluated:
            before = packet.get('prehold') or {}
            numeric = old_numeric(old_model, np.asarray([features]), [gamma], [context['role']],
                [prefix.get('D_prefix_m')], prehold_d=[before.get('D_prehold_m')])
            old_accept = bool(action.get('command_valid') and before.get('complete') and before.get('original_physical_pass')
                and prefix.get('complete') and prefix.get('original_physical_pass')
                and all(numeric[g][0] for g in ('finite_input', 'support_gate', 'pose_gate', 'distance_gate', 'calibration_gate'))
                and numeric['U_D'][0] <= context['gap_m'] and np.all(numeric['U_T'][0] <= 1.))
        rows.append({'gamma': gamma, 'evaluated': evaluated, 'action_status': entry.get('evaluation_status', 'NOT_RECORDED'),
            'new_candidate_valid': action.get('command_valid'), 'strict_current_mask': strict,
            'new_model_query_accepted': decision.get('accepted') if evaluated else None,
            'strict_new_model_query_accepted': bool(strict and decision.get('accepted')) if evaluated else None,
            'old_STEP33_query_accepted_same_saved_input': old_accept,
            'alternative_strategy_choice': 'NOT_EVALUATED' if not evaluated else 'PER_SAVED_ACTION_ONLY',
            'not_an_independent_timed_closed_loop_ablation': True})
    return rows


def report(out=None):
    out = output() if out is None else Path(out)
    manifest = read(out / 'MANIFEST.json'); finished = read(out / 'RUN_FINISHED.json')
    freeze = read(out / 'STEP34_FREEZE.json', {})
    model = load_bundle(out / 'models/step34_application_model_cal.npz')
    training = read(out / 'TRAINING_SUMMARY.json')
    ref_rows, candidate_rows, row_failures = references(out)
    cal_rows = []
    for item in read(out / 'CAL_REGISTRY.json', []):
        record = read(out / item['path']); label = record['labels']; branch = read(out / item['branch_result'])
        features = record.get('features26')
        cal_rows.append({**item, 'features_finite': bool(features is not None and np.isfinite(features).all()),
            'D_m': label.get('D'), 'Y': label.get('Y'), 'physical_pass_if_complete': bool(label.get('complete') and label.get('original_physical_safe')),
            'terminal_pass_if_complete': bool(label.get('complete') and label.get('terminal_pass')),
            'reason': branch.get('reason'), 'steps': branch.get('counts', {}).get('physical_steps', 0),
            'all_tick_deadline_pass': branch.get('all_tick_deadline_pass')})
    group_rows = [{**{k: g.get(k) for k in ('TRAIN_finite_count', 'TRAIN_distinct_snapshots', 'CAL_planned', 'CAL_finite',
        'CAL_complete', 'CAL_complete_distinct_snapshots', 'CAL_complete_episodes', 'CAL_complete_physical_failures',
        'CAL_physical_unknown', 'local_calibrated', 'cal_max_nearest_distance', 'distance_threshold')}, 'group': key}
        for key, g in model['groups'].items()]
    queue = []; branches = []; phases = []; action_status = []; contrasts = []; extension = []; shadows = []
    old_model = None
    for plan in manifest['TEST']:
        directory = out / 'queue' / plan['context_id']; result = read(directory / 'RESULT.json', {})
        context = result.get('context') or {}; per_method = {}
        for method in METHODS:
            response = (result.get('methods') or {}).get(method) or {}
            actual = (response.get('branches') or {}).get('ACTUAL') or {}
            fact = branch_facts(actual, plan['gap_m'])
            sent = bool(response.get('selected_sent')); ready = response.get('command_ready_ms')
            timely = sent and finite(ready) and ready <= 20.
            gamma = response.get('selected_gamma')
            row = {**plan, 'method': method, 'source_eligible': bool(context.get('eligible')),
                'method_result_recorded': bool(response), 'online_status': response.get('status', 'NOT_RUN'),
                'selected_sent': sent, 'timely_recognized_sent': timely, 'selected_gamma': gamma,
                'injured_middle_event': bool(timely and gamma in (.75, .5, .25)), 'command_ready_ms': ready,
                'online_numeric_path': response.get('online_numeric_path'), **fact}
            row['execution_confirmed'] = bool(timely and fact['execution_confirmed'])
            queue.append(row); per_method[method] = row
            for branch_name in ('ACTUAL', 'COUNTERFACTUAL_C', 'COUNTERFACTUAL_B'):
                evidence = (response.get('branches') or {}).get(branch_name) or {}
                branches.append({**plan, 'method': method, 'branch': branch_name, **branch_facts(evidence, plan['gap_m'])})
            if response.get('online_numeric_path'):
                packet = load_numeric(out / response['online_numeric_path'])
                phases.extend({**plan, 'method': method, 'phase': key, 'duration_ms': value} for key, value in packet.get('phase_latency_ms', {}).items())
                if old_model is None:
                    from cavr_wbc.control.step33_margin import load_delay_calibration
                    from cavr_wbc.experiments.step34_io import SOURCE33
                    old_model = load_delay_calibration(SOURCE33 / 'calibration/ALIGNED_RECAL/step33_delay_cal_aligned_recal.npz')
                contrasts.extend({**plan, 'method': method, **item} for item in online_contrasts(packet, context, old_model))
                for endpoint in ('C', 'B'):
                    ep = packet.get(endpoint) or {}; raw = ep.get('raw_solver_result', ep.get('wbc', {})) or {}
                    if raw:
                        candidate_rows.append(candidate_row(raw, {**plan, 'method': method, 'kind': 'FIRST_' + endpoint}))
                action_status.extend({**plan, 'method': method, 'gamma': float(key),
                    'evaluation_status': entry.get('evaluation_status'), 'new_command_valid': (entry.get('action') or {}).get('command_valid'),
                    'new_model_accepted': (entry.get('decision') or {}).get('accepted'),
                    'query_numeric': (entry.get('decision') or {}).get('numeric')} for key, entry in packet.get('actions', {}).items())
            else:
                phases.append({**plan, 'method': method, 'phase': 'NOT_RUN', 'duration_ms': None,
                               'reason': 'SOURCE_REFERENCE_UNAVAILABLE_OR_CAL_NOT_READY'})
        gov = per_method[METHODS[0]]
        g_response = (result.get('methods') or {}).get(METHODS[0]) or {}
        endpoints = {name: branch_facts((g_response.get('branches') or {}).get('COUNTERFACTUAL_' + name), plan['gap_m']) for name in ('C', 'B')}
        comparison = bool(gov['injured_middle_event'] and gov['execution_confirmed'] and endpoints['B']['execution_confirmed'])
        gain = gov['progress02_04_m'] - endpoints['B']['progress02_04_m'] if comparison else None
        ext = bool(comparison and gain > 0 and endpoints['C']['observed_unsafe'])
        extension.append({**plan, 'middle_sent': gov['injured_middle_event'], 'comparison_available_safe_B': comparison,
            'progress02_04_gain_m': gain, 'safe_action_extension': ext,
            'C_status': endpoints['C']['status'], 'C_observed_unsafe': endpoints['C']['observed_unsafe'],
            'C_numerical_incomplete': endpoints['C']['numerical_incomplete'], 'B_status': endpoints['B']['status'],
            'both_endpoints_safe_utility_tradeoff': bool(comparison and gain > 0 and endpoints['C']['execution_confirmed']),
            'shared_packet_first_cost_not_independent_baseline': True})
        shadow_path = directory / METHODS[0] / 'CAPACITY_SHADOW_NUMERIC.json'
        shadow = load_numeric(shadow_path) if shadow_path.exists() else {}
        for name in ('C', 'B'):
            item = shadow.get(name) or {}
            shadows.append({**plan, 'endpoint': name, 'status': item.get('status', 'NOT_RUN'),
                'candidate_valid': item.get('candidate_valid'), 'raw_status': item.get('raw_optimizer_status'),
                'nonoptimal_excluded_action_exists': bool(item.get('nonoptimal_excluded_action_exists')),
                'bounded_candidate_valid': item.get('bounded_candidate_valid'), 'new_QP_calls': item.get('new_QP_calls', 0),
                'actual_middle_executed': gov['injured_middle_event'] and gov['executed'],
                'actual_capacity99_event': gov['capacity99_event'], 'optimality_or_recovery_benefit_claim': False})
    by_method = {}
    grouped = []
    for method in METHODS:
        rows = [r for r in queue if r['method'] == method]
        by_method[method] = summary(rows)
        for gap in (.004, .006, .008):
            for role in ('thigh', 'calf'):
                selected = [r for r in rows if r['gap_m'] == gap and r['role'] == role]
                grouped.append({'method': method, 'gap_mm': int(gap * 1000), 'role': role, **summary(selected)})
    successful = [r for r in queue if r['method'] == METHODS[0] and r['injured_middle_event'] and r['execution_confirmed']]
    source_ids = {r['source_state_id'] for r in successful}; episodes = {r['episode'] for r in successful}
    extension_good = [r for r in extension if r['safe_action_extension']]
    extension_states = {r['source_state_id'] for r in extension_good}; extension_eps = {r['episode'] for r in extension_good}
    capacity_states = {r['source_state_id'] for r in shadows if r['nonoptimal_excluded_action_exists'] and r['bounded_candidate_valid'] and r['actual_middle_executed'] and r['actual_capacity99_event']}
    scientific = 'CALIBRATION_NOT_READY' if freeze.get('readiness_branch') == 'CALIBRATION_NOT_READY' else 'FIXED_PANEL_COMPLETED' if finished['status'] == 'COMPLETED' else 'INCOMPLETE'
    ledger = list(jsonl_rows(out / 'STEP34_LEDGER.jsonl')); returns = [r for r in ledger if r['event'] == 'QP_RETURN']
    current_reference_lookup = {(r['episode'], int(r['tick']) + 1): r for r in candidate_rows if r['kind'] == 'REFERENCE'}
    last_reference_return = {}
    for call in returns:
        if call['kind'] == 'REFERENCE':
            last_reference_return[(call['owner'], call['local_qp_index'])] = call['global_qp_index']
    scalar_masks = {}
    for event in ledger:
        if event['event'] == 'CURRENT_CANDIDATE_CHECK':
            call = next((r for r in reversed(returns) if r['kind'] == event['kind'] and r['owner'] == event['owner'] and r['timestamp_utc'] <= event['timestamp_utc']), None)
            if call is not None:
                scalar_masks[call['global_qp_index']] = event
    all_call_masks = []
    for call in returns:
        key = (call['owner'], call['local_qp_index']); index = call['global_qp_index']
        full = current_reference_lookup.get(key) if call['kind'] == 'REFERENCE' and last_reference_return.get(key) == index else None
        mask = full or scalar_masks.get(index) or {}
        all_call_masks.append({'global_qp_index': index, 'kind': call['kind'], 'owner': call['owner'],
            'raw_status': call['status_val'], 'raw_status_text': call['status'],
            'candidate_mask': mask.get('candidate_valid'), 'strict_candidate_mask': mask.get('strict_candidate_mask'),
            'mask_evidence_status': 'FULL_CURRENT_RAW_CSC' if full else 'MASK_SCALAR_ONLY' if mask else 'UNKNOWN_PARTIAL_FIRST_ATTEMPT',
            'full_raw_CSC_materialized': bool(full), 'native_time_limit_s': call['osqp_time_limit_s'],
            'solve_wall_ms': 1000. * call['solve_wall_time_s'], 'invoke_wall_ms': 1000. * call['invoke_total_wall_time_s'],
            'setup_wall_ms': 1000. * call['setup_time_s'], 'update_wall_ms': 1000. * call['update_time_s'],
            'polish_wall_ms': 1000. * call['polish_time_s']})
    diagnostics = read(out / 'ENDPOINT_DIAGNOSTICS.json', [])
    result = {'run_id': manifest['run_id'], 'NUMERICAL_STATUS': finished['status'], 'SCIENTIFIC_RUN_STATUS': scientific,
        'RESEARCH_STATUS': 'BLOCKED_REFERENCE_CANDIDATE_REJECTION' if not any(r['snapshots_saved'] for r in ref_rows) else scientific,
        'A_STATUS': 'INJURED_MIDDLE_EXECUTION_OBSERVED' if len(source_ids) >= 2 and len(episodes) >= 2 else 'NOT_ESTABLISHED',
        'B_STATUS': 'SAFE_ACTION_EXTENSION_OBSERVED' if len(extension_states) >= 2 and len(extension_eps) >= 2 else 'NOT_ESTABLISHED',
        'C_STATUS': 'CAPACITY_EXCLUSION_EVIDENCE_OBSERVED' if len(capacity_states) >= 2 else 'NOT_ESTABLISHED',
        'planned_TEST_inputs': 48, 'planned_source_states': 16, 'planned_episodes': 4, 'planned_method_slots': 96,
        'observed_formal_online_decisions': sum(r['method_result_recorded'] for r in queue),
        'observed_TEST_source_states': len({r['source_state_id'] for r in queue if r['source_eligible']}),
        'actual_runs': sum(r['executed'] for r in queue), 'actual_middle_runs': sum(r['injured_middle_event'] and r['executed'] for r in queue),
        'methods': by_method, 'gap_role_groups': grouped,
        'training': {'planned': len(training['TRAIN_ids_all']), 'finite': len(training['TRAIN_finite_ids']),
            'complete_D_Y': len(training['TRAIN_regression_ids']), 'risk_known': len(training['TRAIN_risk_ids']),
            'risk_pass': training['TRAIN_risk_pass_count'], 'risk_fail': training['TRAIN_risk_fail_count'],
            'unknown_risk': len(training['TRAIN_unknown_risk_ids']), 'complete_physical_failures': training['TRAIN_complete_failures_retained'],
            'partial_physical_failures': training['TRAIN_partial_observed_physical_failures_retained'],
            'risk_converged': training['risk_converged'], 'risk_iterations': training['risk_iterations'],
            'regression_fits': 1, 'risk_fits': 1, 'source': 'STEP33_ALIGNED_DEV_ONLY'},
        'CAL': {'contexts_planned': 24, 'action_slots_planned': 120, 'recorded': len(cal_rows),
            'finite_features': sum(r['features_finite'] for r in cal_rows), 'complete': sum(r['complete'] for r in cal_rows),
            'statuses': dict(Counter(r['status'] for r in cal_rows)), 'groups': group_rows,
            '100ms_teacher_used': False},
        'reference_summary': ref_rows, 'reference_failure_rows': row_failures,
        'current_reference_candidates': len(candidate_rows), 'complete_current_witnesses': sum(r['raw_full_primal_recorded'] and r['full_same_call_CSC_recorded'] for r in candidate_rows),
        'QP_raw_status_counts_all_attempts': dict(Counter(str(r['status_val']) for r in returns)),
        'QP_by_kind_all_attempts': finished['budget']['QP_by_kind'], 'candidate_valid_rows_saved': sum(bool(r['candidate_valid']) for r in candidate_rows),
        'candidate_rejected_rows_saved': sum(r['candidate_valid'] is False for r in candidate_rows),
        'diags': {'planned_input_count': 4, 'recorded_method_slots': len(diagnostics),
            'status_counts': dict(Counter(r['status'] for r in diagnostics)), 'real_C_B_attempts': sum(bool(load_numeric(r['numeric']['json']).get('C')) for r in diagnostics),
            'ACTUAL_runs': 0, 'diagnostics_are_not_formal_TEST': True},
        'timing_summary': {'formal_command_ready_ms': statistics(r['command_ready_ms'] for r in queue if r['method_result_recorded']),
            'QP_solve_wall_ms_all_attempts': statistics(1000 * r['solve_wall_time_s'] for r in returns),
            'on_demand_native_prefix_real_calls': sum(r['event'] == 'PREFIX_NATIVE_START' and r.get('kind') == 'PREFIX_PREDICTION' for r in ledger),
            'no_online_timing_evidence_if_zero_calls': True},
        'same_packet_contrasts': {'evaluated_action_rows': len(contrasts), 'new_vs_strict_candidate_changed': sum(r['new_candidate_valid'] and not r['strict_current_mask'] for r in contrasts),
            'new_model_vs_old_gate_changed_evaluated': sum(r['evaluated'] and r['new_model_query_accepted'] != r['old_STEP33_query_accepted_same_saved_input'] for r in contrasts),
            'full_alternative_strategy_not_filled_from_missing_prefixes': True, 'closed_loop_causal_ablation_claim': False},
        'mechanism_counts': {'A_distinct_source_states': len(source_ids), 'A_episodes': len(episodes),
            'B_distinct_source_states': len(extension_states), 'B_episodes': len(extension_eps), 'C_distinct_source_states': len(capacity_states)},
        'budget': finished['budget'], 'implementation_repairs_used': 2,
        'failed_first_numerical_attempt_preserved': True, 'startup_and_first_failed_reference_full_raw_witness_not_materialized': True,
        'raw_evidence_gap_disclosure': '12 startup calls have masks/timing but not materialized full CSC; first3 reference calls only ledger plus partial JSON. Current8 corrected reference shards fully preserve24 raw/CSC.',
        'numerical_calls_after_finish': 0, 'E3_RL_HARDWARE': 'NOT_AUTHORIZED',
        'historical_results_unchanged': True, 'historical_STEP33_A_B_C': 'NOT_ESTABLISHED_UNCHANGED',
        'necessary_tests_initial': read(out / 'tests/NECESSARY_TESTS.json'), 'necessary_tests_targeted_repair': read(out / 'tests/TARGETED_STORAGE_REPAIR_01.json'),
        'current_delivery_check': read(out / 'tests/CURRENT_DELIVERY_CHECK.json', {}),
        'row_counts': {'QUEUE_RESULTS': len(queue), 'ACTION_EXTENSION_RESULTS': len(extension), 'CAPACITY_RESULTS': len(shadows)}}
    for name, data in (('QUEUE_RESULTS', queue), ('GAP_ROLE_RESULTS', grouped), ('BRANCH_RESULTS', branches),
        ('CAL_RESULTS', cal_rows), ('CAL_GROUP_SUMMARY', group_rows), ('REFERENCE_RESULTS', ref_rows),
        ('CURRENT_CANDIDATE_MASK', candidate_rows), ('REFERENCE_FAILED_ROWS', row_failures),
        ('ALL_QP_RAW_STATUS_AND_MASK', all_call_masks),
        ('ON_DEMAND_PHASE_LATENCY', phases), ('ONLINE_ACTION_STATUS', action_status),
        ('SAME_PACKET_DIAGNOSTIC_CONTRASTS', contrasts), ('ACTION_EXTENSION_RESULTS', extension), ('CAPACITY_RESULTS', shadows)):
        dump(out, name, data)
    write(out / 'STEP34_RESULT.json', result)
    (out / 'STEP34_REPORT.md').write_text(report_text(result, manifest), encoding='utf-8', newline='\n')
    (out / 'STEP34_RESEARCH_HANDOFF.md').write_text(handoff_text(result), encoding='utf-8', newline='\n')
    print({k: result[k] for k in ('NUMERICAL_STATUS', 'SCIENTIFIC_RUN_STATUS', 'RESEARCH_STATUS', 'A_STATUS', 'B_STATUS', 'C_STATUS')})
    return result


def summary(rows):
    sent = sum(r['timely_recognized_sent'] for r in rows); passed = sum(r['execution_confirmed'] for r in rows)
    return {'planned': len(rows), 'recorded_decisions': sum(r['method_result_recorded'] for r in rows),
        'source_eligible': sum(r['source_eligible'] for r in rows), 'timely_sent': sent,
        'ACTUAL': sum(r['executed'] for r in rows), 'complete_501': sum(r['complete_501'] for r in rows),
        'full_pass': passed, 'conditional_success': passed / sent if sent else None,
        'recognition_coverage_planned': sent / len(rows) if rows else None,
        'error_recognition': sum(r['timely_recognized_sent'] and not r['execution_confirmed'] for r in rows),
        'numerical_incomplete': sum(r['numerical_incomplete'] for r in rows),
        'actual_physical_failure': sum(r['physical_failure'] for r in rows),
        'actual_local_failure': sum(r['local_failure'] for r in rows), 'actual_terminal_failure': sum(r['terminal_failure'] for r in rows),
        'statuses': dict(Counter(r['online_status'] for r in rows))}


PROTOCOL_LINES = '''AUTHORIZE_STEP34_METHOD_REDESIGN_AND_RUN = TRUE
RAW_SOLVER_STATUS_PRESERVED = TRUE
INDEPENDENT_CURRENT_CONTRACT_CHECK_REQUIRED = TRUE
ELIGIBLE_RAW_STATUSES = 1,2,7,8
ORIGINAL_ROW_TOLERANCES_AND_PHYSICAL_BOUNDS_UNCHANGED = TRUE
NEW_REGRESSION_FITS = 1
NEW_PHYSICAL_RISK_HEAD_FITS = 1
TRAIN_SOURCE = STEP33_ALIGNED_DEV_ONLY
NEW_CAL_CONTEXTS = 24
CAL_MAX_ACTION_TRAJECTORIES = 120
TEST_SOURCE_STATES = 16
TEST_GAPS_MM = 4,6,8
TEST_PLANNED_INPUTS = 48
ACTUAL_ONLINE_POLICIES = APPLICATION_FEAS_GOV,APPLICATION_FEAS_BINARY
FIRST_C_B_QP_LIMIT_S = 0.003
FEEDBACK_QP_LIMIT_UPPER_S = 0.006
DEADLINE_MS = 20
SAMPLE_HORIZON_S = 1
PHYSICS_DT_S = 0.002
MAX_NEW_QP_CALLS = 25000
MAX_NEW_PHYSICS_STEPS = 250000
MAX_NUMERICAL_WALL_MINUTES = 90
MAX_DEV_IMPLEMENTATION_REPAIRS = 2
TEST_RESULT_BASED_RETRY = FALSE
HISTORICAL_RESULTS_UNCHANGED = TRUE
E3_RL_HARDWARE = NOT_AUTHORIZED'''


def report_text(r, manifest):
    lines = ['# STEP34：当前可行候选与施加时序学习', '', '## Material Passport', '',
        'experiment-agent / research implementation + bounded simulation / 2026-10-09 / Asia/Seoul / ANALYZED / STEP34_v1。',
        '', f"Run：{r['run_id']}；源提交：{manifest['source_commit']}。", '',
        f"研究状态：{r['RESEARCH_STATUS']}；预设分支：{r['SCIENTIFIC_RUN_STATUS']}；调度器状态：{r['NUMERICAL_STATUS']}。",
        '调度器结束不代表完成正式面板，更不代表机制成功。', '',
        f"A = {r['A_STATUS']}；B = {r['B_STATUS']}；C = {r['C_STATUS']}。", '',
        '## 主要观测', '',
        '新接口区分收敛状态和当前契约可行性。八条修复后reference均在tick2、20步积分后被原接触等式拒收，raw status均为1；未到达任何请求的CAL或TEST采样tick。',
        f"CAL保存120计划动作位，完整标签{r['CAL']['complete']}，有限特征{r['CAL']['finite_features']}；正式48×2方法位均NOT_RUN，实际在线决策{r['observed_formal_online_decisions']}，ACTUAL={r['actual_runs']}。",
        '预设四个calf输入共有8条诊断位，但均SOURCE_INELIGIBLE，真实C/B及按需prefix未执行。诊断记录不能计成8次候选QP或真实在线计时。', '',
        '| Reference | 停止tick | 积分步 | 缺失采样tick | 状态 |', '|---|---:|---:|---|---|']
    for row in r['reference_summary']:
        lines.append(f"| {row['episode']} | {(row['reason'] or {}).get('tick')} | {row['physical_steps']} | {row['missing_ticks']} | {row['status']} |")
    lines += ['', '原行拒收证据：[REFERENCE_FAILED_ROWS](REFERENCE_FAILED_ROWS.csv)。每条记录带A·z、l/u、原SI容差和原raw status，不加slack、不修正status。',
        '| Episode | row | 单位 | violation | 原tolerance | violation/tolerance |', '|---|---:|---|---:|---:|---:|']
    for row in r['reference_failure_rows']:
        lines.append(f"| {row['episode']} | {row['row']} | {row['row_unit']} | {row['violation']:.12g} | {row['original_tolerance']:.12g} | {row['violation_to_tolerance']:.6f} |")
    lines += ['', '## 新方法与有限容差凸性', '',
        '在strict decoder丢弃变量前捕获本次raw.x、完整qdd/τ/λ、同一次CSC问题与原行容差。raw状态1/2/7/8只是候选检查入口，均需原动力学/接触等式、零额外slack不等式、raw容量及health-clipped sent完整witness通过。当前可行性不等同最优性或未来安全。',
        '有限容差命题：对相同仿射行a、上下界l/u和固定非负ε，集合{z: l−ε≤a·z≤u+ε}为凸集；两个合格当前witness的Γ凸组合仍满足这些行。原不等式ε=0。clip改变witness，必须重新核验；浮点实现仍重新检查raw/sent。本命题不涉及未来非线性MuJoCo轨迹、连续安全或最优性。',
        'PID仍用原增益、anchor、积分界和99%规则；只有可行候选才可更新。反馈候选拒收时在ctrl/forward/积分前保存当前state与拒收证据并停止该分支。',
        '按需路径：独立10步application预测；B先、C后且各一次3ms；各自恢复相同完整施加state，nominal与backup owner独立；依1/.75/.5/.25/0只传播当前待判10步prefix，首个认可动作后停止。未查询不冒充安全或不安全。',
        '本批次没有进入受损C/B或prefix路径；上述路径目前只有fixture证据，没有真实在线性能或受损恢复证据。', '',
        '## 固定训练与匹配CAL', '',
        f"TRAIN：{r['training']}。Ridge α=1六输出fit一次，L2 logistic α=1 fit一次；标准化和姿态域只来自89个有限TRAIN输入。70个完整D/Y目标含11个完整物理失败；风险目标59pass/18fail，其中7个partial已观测失败，12个partial目标unknown。风险头40次lbfgs迭代收敛；没有模型/分类阈值搜索。",
        '源只有STEP33 ALIGNED DEV。输入为原26个动作/施加点特征；本轮改变训练时钟、预测器和适用域，不声称首次动作条件化。K=5个不同finite TRAIN snapshot仅判密度，不要求五个都安全；fail和partial保留。',
        '新CAL保留原四snapshot/两episode和LOCAL稳定排序；selected incomplete目标拒收。D及signedY残差、D_RESERVE=1mm、terminal reserve=.05不变；风险阈值为max(.5,同四个CAL已知fail的最大Ppass)，unknown拒收，当前Ppass须严格更大。这是经验筛选，不是形式安全概率。',
        '新CAL不使用100ms teacher补标签；本轮全部source不可用，所有组不满足完整目标最低数。模型/CAL冻结：[STEP34_FREEZE](STEP34_FREEZE.json)，训练材料/标签计数：[TRAINING_SUMMARY](TRAINING_SUMMARY.json)，组摘要：[CAL_GROUP_SUMMARY](CAL_GROUP_SUMMARY.csv)。', '',
        '## 全计划结果与独立分母', '',
        '三个gap是预冻结新任务设计，不把旧4–6mm结果改判成功。48输入只有16source state、四episode；机制门按distinct source state和episode计数，不重复计三个gap或反事实。',
        '| 方法 | gap(mm) | role | 计划 | 观测决策 | 发送 | ACTUAL | 完整通过 | 条件成功 |',
        '|---|---:|---|---:|---:|---:|---:|---:|---|']
    for row in r['gap_role_groups']:
        lines.append(f"| {row['method']} | {row['gap_mm']} | {row['role']} | {row['planned']} | {row['recorded_decisions']} | {row['timely_sent']} | {row['ACTUAL']} | {row['full_pass']} | {'未定义' if row['conditional_success'] is None else row['conditional_success']} |")
    lines += ['', '完整表：[QUEUE_RESULTS](QUEUE_RESULTS.csv)；[动作集合](ACTION_EXTENSION_RESULTS.csv)；[容量](CAPACITY_RESULTS.csv)。无ACTUAL则没有错误认可、容量恢复效应、端点效用或1s恢复的可观测结论。',
        '同packet strict mask与STEP33门对照只评价保存过的动作。当前没有新在线packet，表为空；不补prefix、不填ABSTAIN、不称独立闭环消融。阶段时延表把NOT_RUN保留为空，不写0ms。', '',
        '## 修复、预算与证据完整性', '',
        '必要suite初始29项：28通过、1存储错误；独立STEP34 controls/CSC shard修复后，仅失败项定点复测通过。整套没有重跑；旧测试和源码未改。随后首次数值attempt持久化CSC失败，并且健康reference误路由到首包3ms；第二次集中修复改lossless reference shard并恢复健康连续反馈6ms。两次实现修复已用完，不再自动新增。',
        '首次数值attempt的9QP/20steps、异常、partial JSON及初次3ms reference均保留计数。修复接续使用原run_id和原起点；两模型从已保存资产加载，未重fit。没有TEST结果驱动重试。',
        f"累计预算：{r['budget']}。", f"全attempt QP raw状态：{r['QP_raw_status_counts_all_attempts']}。",
        '证据缺口需明确保留：12个startup调用只有mask/时延汇总，没有持久化full raw/CSC；首3个reference调用只有短账本与截断partial JSON。修复后八条reference的24个调用具有完整raw/CSC。不能声称39次全部有完整候选witness，也不能追加求解补证。',
        '当前完整参考候选表：[CURRENT_CANDIDATE_MASK](CURRENT_CANDIDATE_MASK.csv)；全部39调用的状态/mask/缺口表：[ALL_QP_RAW_STATUS_AND_MASK](ALL_QP_RAW_STATUS_AND_MASK.csv)；短账本：[STEP34_LEDGER](STEP34_LEDGER.jsonl)；逐attempt：[ATTEMPT_LEDGER](ATTEMPT_LEDGER.jsonl)。',
        '当前交付一致性核验14/14满足：[CURRENT_DELIVERY_CHECK](tests/CURRENT_DELIVERY_CHECK.json)，并明确标注完整raw证据不足；它不是科学PASS。新源码/命令/Git状态见[STEP34_DELIVERY_METADATA](STEP34_DELIVERY_METADATA.json)，只有当前输入/模型及scoped diff，不增加历史证书审计。',
        'SciPilot两图：[全计划与缺失](figures/STEP34_all_results.pdf)，[全部当前reference候选/拒收行](figures/STEP34_candidate_bottleneck.pdf)。PDF/SVG/600dpi PNG、原始点和灰度预览一并保存。', '',
        '参考语义：[OSQP原始状态](https://osqp.org/docs/interfaces/status_values.html)将状态2视为放大容差的判断；7/8不保证约束可行，本轮独立行检查是额外必要条件。[预测安全过滤器](https://arxiv.org/abs/1812.05506v4)的未来状态/输入约束动机不构成本轮未来安全证明。', '',
        '~~~ini', PROTOCOL_LINES, f"NUMERICAL_STATUS = {r['NUMERICAL_STATUS']}",
        f"SCIENTIFIC_RUN_STATUS = {r['SCIENTIFIC_RUN_STATUS']}", f"RESEARCH_STATUS = {r['RESEARCH_STATUS']}",
        f"A_STATUS = {r['A_STATUS']}", f"B_STATUS = {r['B_STATUS']}", f"C_STATUS = {r['C_STATUS']}",
        'FORMAL_ONLINE_DECISIONS_OBSERVED = 0', 'ACTUAL_RUNS = 0', 'IMPLEMENTATION_REPAIRS_USED = 2',
        'COMPLETE_RAW_WITNESS_ALL_39_CALLS = FALSE', '~~~', '']
    return '\n'.join(lines)


def handoff_text(r):
    return '\n'.join(['# STEP34研究交接', '', f"研究：{r['RESEARCH_STATUS']}；分支：{r['SCIENTIFIC_RUN_STATUS']}。",
        f"A/B/C：{r['A_STATUS']} / {r['B_STATUS']} / {r['C_STATUS']}。",
        '主要瓶颈是reference原contact等式拒收（row22、约1.053e−5m/s²>1e−5）；不是已观察的受损动作恢复失败。8条新reference未到请求采样tick，CAL120位NOT_RUN、TEST96位NOT_RUN，8个预设诊断位也是SOURCE_INELIGIBLE。',
        '两固定头各fit一次并冻结；候选/按需内核已实现，只有fixture而无真实受损C/B/在线prefix证据。对新模型、新可行候选或按需性能不作部署结论。',
        '两次实现修复已耗尽，所有异常、旧attempt、预算与raw证据缺口保留；不得继续优化/改变容差/重跑本轮，后续新设计需新授权。',
        'STEP33及历史NOT_ESTABLISHED不撤销；未进入E3/RL/硬件，未触碰机器人运控算法。',
        '', '~~~ini', PROTOCOL_LINES, '~~~', ''])


if __name__ == '__main__':
    report()
