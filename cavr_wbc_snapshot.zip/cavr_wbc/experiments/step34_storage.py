"""Lossless STEP34 controls plus original bit-exact physical-state bank.

The old compact bank intentionally omits new solver fields. A separate typed
numeric shard now retains complete controls, current raw primals, CSC rows and
candidate masks without changing any older storage source or old artifacts.
"""
from pathlib import Path
from cavr_wbc.experiments.step26_features_storage import save_bank as _save_bank, load_bank as _load_bank
from cavr_wbc.experiments.step34_io import save_numeric, load_numeric


def save_bank(path, branch, metadata=None):
    path = Path(path)
    controls = path.with_suffix('.controls.json')
    if path.exists() or controls.exists() or controls.with_suffix('.npz').exists():
        raise FileExistsError('STEP34 current attempt shards cannot be overwritten')
    asset = _save_bank(path, branch, metadata)
    control_asset = save_numeric(controls, {'schema': 'STEP34_LOSSLESS_CURRENT_CONTROLS_V1',
        'branch_id': branch.get('branch_id'), 'controls': branch.get('controls', []),
        'solver_ledger': branch.get('solver_ledger', [])})
    return {**asset, 'step34_control_evidence': control_asset, 'full_current_candidate_fields_preserved': True}


def load_bank(path):
    path = Path(path); branch = _load_bank(path)
    controls = path.with_suffix('.controls.json')
    evidence = load_numeric(controls)
    if evidence['branch_id'] != branch.get('branch_id'):
        raise ValueError('STEP34 physical/control shard identity mismatch')
    branch['controls'] = evidence['controls']; branch['solver_ledger'] = evidence['solver_ledger']
    return branch
