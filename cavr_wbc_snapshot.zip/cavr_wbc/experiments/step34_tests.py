"""The single current necessary fixture suite; no historical suites/replays."""
from datetime import datetime, timezone
import sys
import unittest
from cavr_wbc.experiments.step34_io import ROOT, output, write


def run(targeted=False):
    out = output() / 'tests'; out.mkdir(parents=True, exist_ok=True)
    stem = 'TARGETED_STORAGE_REPAIR_01' if targeted else 'NECESSARY_TESTS'
    path = out / (stem + '.log')
    if path.exists():
        raise FileExistsError('STEP34 necessary test suite already attempted')
    start = datetime.now(timezone.utc).isoformat()
    if targeted:
        suite = unittest.defaultTestLoader.loadTestsFromName('tests.test_step34_sim.SamePacketTests.test_nonconverged_packet_bank_persists_status_identity_501_and_no_overwrite')
    else:
        suite = unittest.defaultTestLoader.discover(str(ROOT / 'tests'), pattern='test_step34*.py')
    with path.open('x', encoding='utf-8') as stream:
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    write(out / (stem + '.json'), {'command': 'python -B -X utf8 -m cavr_wbc.experiments.step34_tests' + (' --targeted-storage-repair' if targeted else ''),
        'start_utc': start, 'finish_utc': datetime.now(timezone.utc).isoformat(),
        'tests_run': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
        'successful': result.wasSuccessful(), 'fixture_only': True,
        'real_QP_calls': 0, 'real_physics_steps': 0, 'new_regression_fits': 0, 'new_risk_fits': 0})
    print(path.read_text(encoding='utf-8'), flush=True)
    return 0 if result.wasSuccessful() else 1


if __name__ == '__main__':
    sys.exit(run('--targeted-storage-repair' in sys.argv))
