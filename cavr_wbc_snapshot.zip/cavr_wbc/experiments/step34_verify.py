"""One current-delivery check with explicit raw-evidence gaps, not scientific PASS."""
from collections import Counter
from datetime import datetime, timezone
import numpy as np
from cavr_wbc.experiments.step34_io import ROOT, SOURCE33, output, read, write, sha, load_numeric
from cavr_wbc.experiments.step33_report import jsonl_rows
from cavr_wbc.control.step34_margin import load_bundle, identity


def run():
    out = output(); target = out / 'tests/CURRENT_DELIVERY_CHECK.json'
    if target.exists():
        raise FileExistsError('one current STEP34 identity/file check already attempted')
    checks = []
    def check(name, condition, detail=None):
        checks.append({'name': name, 'condition_met': bool(condition), 'detail': detail})
    result = read(out / 'STEP34_RESULT.json'); freeze = read(out / 'STEP34_FREEZE.json')
    finished = read(out / 'RUN_FINISHED.json'); budget = finished['budget']; manifest = read(out / 'MANIFEST.json')
    suite = read(out / 'tests/NECESSARY_TESTS.json'); repair = read(out / 'tests/TARGETED_STORAGE_REPAIR_01.json')
    check('necessary_fixture_failure_retained_and_only_failed_storage_case_retested', suite['tests_run'] == 29 and suite['errors'] == 1 and suite['failures'] == 0 and
        repair['tests_run'] == 1 and repair['successful'] and suite['real_QP_calls'] == repair['real_QP_calls'] == 0)
    train = read(out / 'TRAIN_REGISTRY.json')
    check('only_all_100_STEP33_ALIGNED_DEV_training_sources', len(train) == 100 and all(r['source_method'] == 'ALIGNED_RECAL' and r['source_split'] == 'DEV' and sha(r['source_path']) == r['source_sha256'] for r in train))
    source = read(SOURCE33 / 'MANIFEST.json')
    check('current_compiled_model_and_native_identity', all(sha(ROOT / path) == digest for path, digest in source['frozen_physical']['model_files_sha256'].items()) and
        sha(manifest['native_dll_path']) == manifest['native_dll_sha256'])
    check('runtime_and_fixture_bytes_frozen_no_after_TEST_change', all(sha(ROOT / path) == digest for path, digest in freeze['new_runtime_sha256'].items()))
    model = load_bundle(out / 'models/step34_application_model_cal.npz'); asset = freeze['model_CAL_assets']
    check('one_freeze_one_fit_each_training_only_scaler_predictor_identical_after_CAL', freeze['freeze_count'] == 1 and not freeze['TEST_read_for_fit_or_CAL'] and
        identity(model) == freeze['predictor_identity_before_CAL'] == freeze['predictor_identity_after_CAL'] and
        sha(asset['npz']) == asset['npz_sha256'] and sha(asset['json']) == asset['json_sha256'] and
        budget['multioutput_estimator_fits'] == budget['physical_risk_head_fits'] == 1)
    check('cumulative_same_clock_caps_and_repairs_not_reset', budget['total_QP_calls'] <= 25000 and budget['total_physics_steps'] <= 250000 and budget['numerical_elapsed_s'] <= 5400 and
        budget['numerical_started_utc'] == '2026-10-09T06:16:51.288808+00:00' and result['implementation_repairs_used'] == 2 and
        budget['unknown_native_returns'] == budget['uncompleted_native_step_reservations'] == 0, budget)
    ledger = list(jsonl_rows(out / 'STEP34_LEDGER.jsonl'))
    starts = Counter(r['global_qp_index'] for r in ledger if r['event'] == 'QP_START')
    returns = [r for r in ledger if r['event'] == 'QP_RETURN']
    check('all_39_real_QP_one_START_RETURN_original_status_and_native_caps', starts == Counter(r['global_qp_index'] for r in returns) and
        len(returns) == budget['total_QP_calls'] == 39 and all(v == 1 for v in starts.values()) and
        all(r['real_optimizer_called'] and r['status_val'] == 1 and r['osqp_time_limit_s'] in (.003, .006) for r in returns))
    cal = read(out / 'CAL_REGISTRY.json'); queue = read(out / 'QUEUE_REGISTRY.json')
    check('120_planned_CAL_labels_not_zero_imputed', len(cal) == 120 and all(r['status'] == 'NOT_RUN' and read(out / r['path'])['labels']['D'] is None and read(out / r['path'])['labels']['Y'] is None for r in cal))
    check('one_readiness_48_inputs_96_NOT_RUN_zero_actual', freeze['readiness_branch'] == 'CALIBRATION_NOT_READY' and len(queue) == 48 and
        len({r['source_state_id'] for r in queue}) == 16 and all(r['status'] == 'NOT_RUN' for r in queue) and
        result['observed_formal_online_decisions'] == result['actual_runs'] == 0 and result['row_counts']['QUEUE_RESULTS'] == 96)
    diagnostics = read(out / 'ENDPOINT_DIAGNOSTICS.json')
    check('fixed_first_four_calf_inputs_diagnostics_not_real_QP_attempts', len(diagnostics) == 8 and
        {r['context_id'] for r in diagnostics} == set(manifest['first_four_calf_diagnostic_ids']) and
        all(r['status'] == 'SOURCE_INELIGIBLE' and r['ACTUAL_runs'] == 0 for r in diagnostics) and result['diags']['real_C_B_attempts'] == 0)
    candidates = read(out / 'CURRENT_CANDIDATE_MASK.json')
    failed = read(out / 'REFERENCE_FAILED_ROWS.json')
    check('all24_corrected_reference_full_raw_CSC_and_raw1_not_unconditionally_accepted', len(candidates) == 24 and
        sum(r['candidate_valid'] for r in candidates) == 16 and sum(r['candidate_valid'] is False for r in candidates) == 8 and
        all(r['raw_full_primal_recorded'] and r['full_same_call_CSC_recorded'] and r['raw_status'] == 1 for r in candidates) and
        len(failed) == 8 and all(r['row'] == 22 and r['original_tolerance'] == 1e-5 and r['violation'] > r['original_tolerance'] for r in failed))
    check('scientific_BLOCKED_no_false_A_B_C_PASS_and_evidence_gaps_disclosed', result['RESEARCH_STATUS'] == 'BLOCKED_REFERENCE_CANDIDATE_REJECTION' and
        all(result[key] == 'NOT_ESTABLISHED' for key in ('A_STATUS', 'B_STATUS', 'C_STATUS')) and
        result['startup_and_first_failed_reference_full_raw_witness_not_materialized'] and result['E3_RL_HARDWARE'] == 'NOT_AUTHORIZED')
    qa = read(out / 'figures/FIGURE_QA.json')
    check('exactly_two_SciPilot_color_gray_reviewed_final_figures', qa['figure_count'] == 2 and qa['AI_visual_review'] == 'REVIEWED' and not qa['missing_glyph_warnings'] and
        all(not row['text_outside_canvas'] and not row['adjacent_tick_overlaps'] and row['minimum_visible_font_pt'] >= 8 and
            all(not any(i[0] == 'FAIL' for i in data['issues']) for data in row['formats'].values()) for row in qa['programmatic'].values()))
    try:
        from pypdf import PdfReader
    except ImportError:
        from PyPDF2 import PdfReader
    fonts = []
    for stem in ('STEP34_all_results', 'STEP34_candidate_bottleneck'):
        for page in PdfReader(str(out / 'figures' / (stem + '.pdf'))).pages:
            for ref in page['/Resources']['/Font'].values():
                font = ref.get_object()
                for child_ref in font.get('/DescendantFonts') or [font]:
                    child = child_ref.get_object(); descriptor = child.get('/FontDescriptor')
                    descriptor = descriptor.get_object() if descriptor else {}
                    stream = descriptor.get('/FontFile2')
                    fonts.append({'figure': stem, 'font': str(child.get('/BaseFont')), 'TrueType_bytes': len(stream.get_object().get_data()) if stream else 0})
    check('PDF_descendant_trueType_embedded_generic_warning_resolved', all(r['TrueType_bytes'] > 0 for r in fonts) and bool(fonts), fonts)
    document = {'command': 'python -B -X utf8 -m cavr_wbc.experiments.step34_verify', 'checks': checks,
        'check_count': len(checks), 'conditions_met': sum(r['condition_met'] for r in checks),
        'current_delivery_consistent': all(r['condition_met'] for r in checks),
        'evidence_completeness': 'INCOMPLETE_FIRST_ATTEMPT_AND_STARTUP_RAW_WITNESSES_DISCLOSED',
        'scientific_status': result['RESEARCH_STATUS'], 'not_a_scientific_PASS': True,
        'new_QP_calls': 0, 'new_physics_steps': 0, 'new_regression_fits': 0, 'new_risk_fits': 0,
        'checked_utc': datetime.now(timezone.utc).isoformat(),
        'scope': 'CURRENT_INPUT_MODEL_NEW_FILES_ONLY_NO_HISTORICAL_SOLVE_AUDIT'}
    write(target, document); print(document)
    return document


if __name__ == '__main__':
    run()
