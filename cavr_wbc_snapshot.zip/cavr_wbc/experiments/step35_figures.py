"""One SciPilot full-data summary; no empty ACTUAL event decorations."""
from pathlib import Path
import importlib.util
import warnings
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from PIL import Image
from cavr_wbc.experiments.step35_io import output, read, write
from cavr_wbc.experiments.step33_report import csv_write
SKILL=Path('C:/Users/ZhuanZ（无密码）/.codex/skills/scipilot-figure')
FINAL_EXPORT='--final-export-after-review' in sys.argv

def helper(name):
    spec = importlib.util.spec_from_file_location('step33_' + name, SKILL / 'scripts' / (name + '.py'))
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod


def profile(out, queue, cal, candidates):
    module = helper('profile_data')
    for name, data in (('queue', queue), ('cal', cal), ('candidates', candidates)):
        if data:
            scalar_data = [{key: value for key, value in row.items() if not isinstance(value, (dict, list, tuple, np.ndarray))} for row in data]
            info = module.profile_data(pd.DataFrame(scalar_data), group_cols=['method'] if 'method' in data[0] else [])
            (out / ('EDA_' + name + '.md')).write_text(module.render_report(info), encoding='utf-8')
        else:
            (out / ('EDA_' + name + '.md')).write_text('No observed events. Missing is not a zero-valued trajectory.\n', encoding='utf-8')
    write(out / 'FIGURE_PLAN.json', {
        'skill': 'scipilot-figure-skill', 'publication': 'IEEE T-RO', 'figure_count': 2,
        'width_in': 7.16, 'raster_dpi': 600, 'minimum_font_pt': 8,
        'queue_n': len(queue), 'CAL_n': len(cal), 'reference_candidate_n': len(candidates),
        'figure1': 'All96 method slots and all120 CAL slots remain NOT_RUN, not zero trajectories.',
        'figure2': 'All24 corrected reference candidates in eight episode panels; raw1 still requires original contact rows.',
        'rationale': 'Categorical identities remain separate; show distributions and missingness, not averages.',
        'alternatives': ['A mean bar would hide failures and missing trajectories.',
                         'A line between queue identities would imply continuity.',
                         'Selecting only successful middle events would change the denominator.'],
        'missing_policy': 'NOT_RUN/ABSTAIN/partial are retained; absent measurements never plotted as zero.',
        'numerical_calls': 0, 'fits': 0})


def style():
    helper('setup_style').setup_style(journal='ieee', lang='en', use_sciplots=False, constrained_layout=False)
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8,
        'axes.labelsize': 8, 'axes.titlesize': 9, 'xtick.labelsize': 8, 'ytick.labelsize': 8,
        'legend.fontsize': 8, 'pdf.fonttype': 42, 'svg.fonttype': 'none'})


def save(fig, out, stem):
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer(); bounds = fig.bbox
    outside = []
    from matplotlib.text import Text
    for text in fig.findobj(Text):
        if not text.get_visible() or not text.get_text():
            continue
        box = text.get_window_extent(renderer)
        if box.x0 < bounds.x0 - 2 or box.y0 < bounds.y0 - 2 or box.x1 > bounds.x1 + 2 or box.y1 > bounds.y1 + 2:
            outside.append(text.get_text())
    overlaps = []
    for i, ax in enumerate(fig.axes):
        for axis in (ax.xaxis, ax.yaxis):
            boxes = [(t.get_text(), t.get_window_extent(renderer)) for t in axis.get_ticklabels() if t.get_visible() and t.get_text()]
            for (a, x), (b, y) in zip(boxes, boxes[1:]):
                if x.overlaps(y):
                    overlaps.append({'axis': i, 'ticks': [a, b]})
    formats = ('pdf', 'svg', 'png') if FINAL_EXPORT else ('png',)
    for ext in formats:
        fig.savefig(out / (stem + '.' + ext), dpi=600, facecolor='white')
    fig.savefig(out / (stem + '_preview.png'), dpi=160, facecolor='white')
    with Image.open(out / (stem + '.png')) as src:
        src.convert('L').save(out / (stem + '_gray.png'), dpi=(600, 600))
    with Image.open(out / (stem + '_preview.png')) as src:
        src.convert('L').save(out / (stem + '_gray_preview.png'), dpi=(160, 160))
    checker = helper('check_figure')
    checks = {}
    for ext in formats:
        issues, info = checker.check_figure(str(out / (stem + '.' + ext)), min_dpi=600)
        checks[ext] = {'issues': issues, 'info': info}
    result = {'text_outside_canvas': outside, 'adjacent_tick_overlaps': overlaps,
              'formats': checks, 'minimum_visible_font_pt': min(t.get_fontsize() for t in fig.findobj(Text) if t.get_visible() and t.get_text())}
    plt.close(fig)
    return result


def run():
    root=output();out=root/'figures';out.mkdir(exist_ok=True)
    refs=read(root/'CURRENT_CANDIDATE_MASK.json')
    cal=read(root/'CAL_RESULTS.json');diag=read(root/'ENDPOINT_DIAGNOSTIC_SUMMARY.json')
    profiler=helper('profile_data')
    for name,rows in (('reference',refs),('CAL',cal),('diagnostic',diag)):
        data=[{key:value for key,value in row.items() if not isinstance(value,(dict,list,tuple,np.ndarray))} for row in rows]
        info=profiler.profile_data(pd.DataFrame(data),group_cols=['method'] if name=='diagnostic' else [])
        (out/('EDA_'+name+'.md')).write_text(profiler.render_report(info),encoding='utf-8')
    write(out/'FIGURE_PLAN.json',{'skill':'scipilot-figure-skill','figure_count':1,'publication':'IEEE T-RO',
        'width_in':7.16,'DPI':600,'reference_points':len(refs),'CAL_slots':len(cal),'diagnostic_slots':len(diag),
        'question':'What improved in input generation, and which CAL/diagnostic bottleneck remains?',
        'recommended':'All reference time tracks, categorical CAL matrix and all diagnostic timing dots.',
        'alternatives':['A mean bar would hide the failed/unavailable CAL denominator.','An empty ACTUAL trajectory panel would add no observed evidence.'],
        'no_statistical_error_bar_or_inferential_claim':True,'no_new_solver_or_physics_or_fit':True})
    style();fig,axes=plt.subplots(3,1,figsize=(7.16,7.2),gridspec_kw={'height_ratios':[1.15,1.15,1.]})
    fig.subplots_adjust(left=.125,right=.975,bottom=.13,top=.87,hspace=.7)
    fig.suptitle('STEP35 | reference precision established; CAL still limited',y=.971,fontsize=11)
    for i,episode in enumerate(dict.fromkeys(r['episode'] for r in refs)):
        rows=[r for r in refs if r['episode']==episode]
        axes[0].plot([r['reference_time_s'] for r in rows],[r['contact_residual_inf_m_s2']/1e-5 for r in rows],
            color='#0072B2' if episode.startswith('C') else '#D55E00',linestyle='-' if episode.startswith('C') else '--',
            linewidth=.6,alpha=.6)
    axes[0].axhline(1,color='#333333',linestyle=':',linewidth=.8)
    axes[0].set(title='(a) All eight complete references, 880 current QP returns',xlabel='Reference time (s)',
        ylabel='Contact residual / tol.',xlim=(0,2.2),ylim=(0,1.1),xticks=(0,.5,1.,1.5,2.))
    axes[0].legend(handles=[Line2D([],[],color='#0072B2',label='CAL reference'),
        Line2D([],[],color='#D55E00',linestyle='--',label='TEST reference'),
        Line2D([],[],color='#333333',linestyle=':',label='Original tolerance')],frameon=False,ncol=3,loc='upper center',bbox_to_anchor=(.5,.84))
    gammas=(1.,.75,.5,.25,0.)
    ids=list(dict.fromkeys(r['context_id'] for r in cal))
    categories={'COMPLETE':('o','#0072B2'),'FAILED_NUMERICAL':('^','#D55E00'),'NOT_RUN':('x','#777777')}
    for row in cal:
        marker,color=categories[row['status']]
        axes[1].scatter(ids.index(row['context_id'])+1,gammas.index(row['gamma']),marker=marker,color=color,s=22,
            facecolors='none' if marker in ('o','^') else color,linewidths=.8)
    axes[1].set(title='(b) All 120 CAL slots: 18 complete, 37 partial, 65 unavailable',ylabel='Gamma (categorical)',
        xlabel='CAL context index',xlim=(.4,24.6),ylim=(4.6,-.6),xticks=(1,6,12,18,24),yticks=range(5),yticklabels=('1','.75','.50','.25','0'))
    fig.legend(handles=[Line2D([],[],marker=m,color=c,markerfacecolor='none',linestyle='none',label=name)
        for name,(m,c) in categories.items()],frameon=False,ncol=3,loc='center',bbox_to_anchor=(.56,.326))
    for x in (6.5,12.5,18.5):
        axes[1].axvline(x,color='#DDDDDD',linewidth=.5,zorder=0)
    for i,row in enumerate(diag):
        gov=row['method']=='APPLICATION_FEAS_GOV'
        axes[2].scatter(i+1,row['command_ready_ms'],marker='o' if gov else 's',facecolors='none',
            edgecolors='#0072B2' if gov else '#D55E00',s=30,linewidths=.9)
    axes[2].axhline(20,color='#333333',linestyle='--',linewidth=.8)
    axes[2].set(title='(c) Every predeclared endpoint / on-demand diagnostic',xlabel='Diagnostic method slot index',
        ylabel='Ready time (ms)',xlim=(.4,8.6),ylim=(0,max(24,max(r['command_ready_ms'] for r in diag)*1.15)),xticks=range(1,9))
    axes[2].legend(handles=[Line2D([],[],marker='o',markerfacecolor='none',color='#0072B2',linestyle='none',label='GOV'),
        Line2D([],[],marker='s',markerfacecolor='none',color='#D55E00',linestyle='none',label='Binary')],frameon=False,ncol=2,loc='lower left',bbox_to_anchor=(.01,.28))
    for ax in axes:
        ax.grid(axis='y',color='#EEEEEE',linewidth=.5)
        ax.title.set_fontsize(9)
    fig.text(.125,.061,'CAL middle groups: at most 3/4 complete snapshots. Formal TEST NOT_RUN; formal ACTUAL 0.',fontsize=8)
    fig.text(.125,.030,'CAL propagation and diagnostic timing are not formal paired execution or A/B/C evidence.',fontsize=8)
    csv_write(out/'ALL_REFERENCE_POINT_DATA.csv',refs);csv_write(out/'ALL_CAL_POINT_DATA.csv',cal);csv_write(out/'ALL_DIAGNOSTIC_POINT_DATA.csv',diag)
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always');qa=save(fig,out,'STEP35_full_results')
    write(out/'FIGURE_QA.json',{'figure_count':1,'programmatic':{'full_results':qa},
        'missing_glyph_warnings':[str(w.message) for w in caught if 'Glyph' in str(w.message)],
        'AI_visual_review':'PENDING_PREVIEW_REVIEW','saved_only':True})
    print({'figure_count':1,'QA':qa})


if __name__=='__main__':
    run()
