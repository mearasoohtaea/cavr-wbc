"""New fixed STEP35 reference recipe using the same candidate contract."""
from types import SimpleNamespace
from collections.abc import Mapping
from time import perf_counter
from copy import deepcopy
from pathlib import Path
import mujoco
import numpy as np
from cavr_wbc.experiments import step26_sim as source
from cavr_wbc.experiments import step17_formal_panel as frozen
from cavr_wbc.control.step35_reference_owner import PreciseReferenceWBC, ReferenceServo
from cavr_wbc.experiments.step31_sim import _workspace_id
from cavr_wbc.control.step20_task_reference import reference
from cavr_wbc.control.step23_backup_filter import (CONTROL_DT_S, PHYSICS_DT_S, PHYSICS_STEPS_PER_SLOT,
    state_values, predicted_physical_check)
from cavr_wbc.platforms.go2_mujoco import extract_healthy_torque_limits
from cavr_wbc.experiments.step35_io import write
_check = source._check
_callback = source._callback
_observer = source._observer
_finite_state = source._finite_state
compact_fact = source.compact_fact
REFERENCE_TICKS = 110
REFERENCE_STEPS = 1100
VERSION = 'STEP35_PRECISE_HEALTHY_REFERENCE_AND_PREFIX_V1'

def reference_episode(model, scenario, d_m, episode_id, snapshot_ticks, budget, evidence_callback=None):
    """Generate the fixed healthy 2.2 s stance reference and pre-control snapshots."""
    _check(budget)
    begin = perf_counter()
    ticks = tuple(int(t) for t in snapshot_ticks)
    if len(set(ticks)) != len(ticks) or any(t < 0 or t >= REFERENCE_TICKS for t in ticks):
        raise ValueError("STEP35 snapshot ticks must be unique reference control ticks")
    data = mujoco.MjData(model)
    reset_scenario = SimpleNamespace(**scenario) if isinstance(scenario, Mapping) else scenario
    frozen._reset(model, data, reset_scenario)
    if np.any(data.qfrc_applied) or np.any(data.xfrc_applied):
        raise ValueError("STEP35 healthy reference requires the original zero external forces")
    initial = state_values(model, data)
    q_init = data.qpos.copy()
    health = np.ones(int(model.nu))
    limits = extract_healthy_torque_limits(model)
    controller = PreciseReferenceWBC(model, solve_callback=_callback(budget, "REFERENCE", episode_id))
    controller.current_context_id = str(episode_id)
    # Continuous healthy reference control is feedback, not a C/B first packet.
    controller.solver_time_limit_s = .006
    servo = ReferenceServo(model)
    servo.reset(q_init, d_m)
    observer = _observer(budget, "REFERENCE", episode_id)
    previous = {'tau_raw': data.ctrl.copy(), 'effective_capacity_nm': health * limits, 'command_valid': True}
    snapshots = []
    steps = 0
    forward_calls = 0
    controls = []
    failure = None
    vmin = vmax = float(data.qvel[0])
    formal_prefix = episode_id == 'C35_P062'
    prefix_gate = {'required': formal_prefix, 'passed': None, 'prefix_is_formal_reference': True,
        'checked_after_tick': 3, 'expected_physics_steps': 40, 'expected_time_s': .08,
        'prefix_restarted': False, 'same_data_controller_PID_and_solver_memory_continue': True}
    owner_before = {'data_id': id(data), 'controller_id': id(controller), 'servo_id': id(servo),
        'solver_owner_id': controller.solver_owner_id}
    prefix_saved = False

    def save_prefix():
        nonlocal prefix_saved
        if not formal_prefix or prefix_saved:
            return
        prefix_gate['owner_identity'] = deepcopy(owner_before)
        prefix_gate['reference_ID'] = episode_id
        if budget is not None and hasattr(budget, 'out'):
            destination = Path(budget.out) / 'REFERENCE_PREFIX.json'
            write(destination, prefix_gate)
            prefix_gate['persisted_path'] = str(destination)
        if budget is not None and hasattr(budget, 'persist'):
            budget.persist(phase='REFERENCE_PREFIX_BOUNDARY', episode=episode_id,
                prefix_passed=prefix_gate.get('passed'), reference_physics_steps=steps,
                reference_time_s=float(data.time))
        prefix_saved = True

    def checkpoint():
        return {'state': state_values(model, data), 'b_integral': servo.b_integral.copy(),
            'q_init': servo.q_init.copy(), 'q_reference': servo.q_reference.copy(),
            'reference_d_m': servo.d, 'servo_configuration': servo.configuration,
            'servo_gain_identity': dict(servo.gains), 'ctrl': data.ctrl.copy(),
            'qacc_warmstart': data.qacc_warmstart.copy(),
            'qfrc_applied': data.qfrc_applied.copy(), 'xfrc_applied': data.xfrc_applied.copy(),
            'solver_owner_id': controller.solver_owner_id,
            'solver_workspaces': [{'workspace_id': _workspace_id(key),
                'last_x': None if cache.get('last_x') is None else cache['last_x'].copy(),
                'last_y': None if cache.get('last_y') is None else cache['last_y'].copy(),
                'actual_setup_eps_abs': cache.get('actual_setup_eps_abs'),
                'actual_setup_eps_rel': cache.get('actual_setup_eps_rel'),
                'actual_setup_native_time_limit_s': cache.get('actual_setup_native_time_limit_s'),
                'independent_case_zeroed': cache.get('independent_case_zeroed')}
                for key, cache in controller._solver_cache.items()],
            'counts': {'reference_QP_calls': len(controller.solver_ledger), 'reference_physics_steps': steps},
            'no_integration_restore_or_solver_reset_at_boundary': True}

    for tick in range(REFERENCE_TICKS):
        _check(budget)
        if not _finite_state(data):
            failure = {"reason": "NONFINITE_REFERENCE_BEFORE_CONTROL", "tick": tick, "physics_step": steps}
            break
        if tick in ticks:
            fact = compact_fact(model, data, health, limits, data.ctrl.copy(), 0., 0., steps,
                                tick, "STEP35-REFERENCE-" + episode_id, episode_id,
                                previous, {"health_vector": health.tolist()})
            physical = predicted_physical_check(fact)
            vx = float(data.qvel[0])
            state = state_values(model, data)
            ref = reference(float(q_init[0]), float(d_m), tick * CONTROL_DT_S)
            snapshots.append({"snapshot_id": f"{episode_id}_T{tick:03d}", "episode_id": episode_id,
                "source_tick": tick, "source_time_s": tick * CONTROL_DT_S,
                "state": state, "nominal_q_init": q_init.tolist(), "nominal_d_m": float(d_m),
                "nominal_b_used": servo.b_integral.copy().tolist(),
                "current_reference": ref, "source_external_reference": ref,
                "x0_m": float(data.qpos[0]), "vx_m_s": vx, "vx": vx,
                "direction": 1 if vx > 0. else -1 if vx < 0. else 0,
                "sign": 1 if vx > 0. else -1 if vx < 0. else 0,
                "healthy_fact": fact, "healthy_physical_check": physical,
                "eligible": bool(physical["pass"] and abs(vx) >= .01),
                "eligibility_reason": None if physical["pass"] and abs(vx) >= .01 else
                    "ORIGINAL_PHYSICAL_UNQUALIFIED" if not physical["pass"] else "ABS_VX_LT_0P01_M_S",
                "backup_anchor_q_init": data.qpos.copy().tolist(),
                "source_integration_state_complete": True})
        response = servo.compute(controller, data, health, tick)
        interface = response["capacity_interface"]
        raw = response.get("wbc", response.get("raw_solver_result", {}))
        raw_evidence = evidence_callback(raw, 'REFERENCE', episode_id) if evidence_callback is not None else None
        controls.append({"tick": tick, "time_s": tick * CONTROL_DT_S,
                         "valid_command": bool(response["valid_command"]),
                         "solver_status": response["wbc"].get("status"),
                         "solver_status_val": response["wbc"].get("status_val"),
                         "tau_raw": interface["tau_raw"], "tau_sent": response["tau_cmd"],
                         "latency_ms": response["latency_ms"],
                         "integral_record": response["integral_record"],
                         "candidate_valid": bool(raw.get("candidate_valid", False)),
                         "reference_apply_valid": bool(response.get("reference_apply_valid", response["valid_command"])),
                         "reference_raw_status1_gate": bool(response.get("reference_raw_status1_gate", False)),
                         "raw_evidence": raw_evidence,
                         "actual_setup_precision": {name: raw.get(name) for name in
                             ('actual_setup_eps_abs', 'actual_setup_eps_rel', 'actual_setup_max_iter',
                              'actual_setup_polish', 'actual_setup_native_time_limit_s', 'solver_owner_scope')},
                         "candidate_certificate": raw.get("candidate_certificate"),
                         "raw_solver_result": raw,
                         "candidate_schema": interface.get("version", interface.get("schema"))})
        if not response["valid_command"] or not response.get('reference_raw_status1_gate', False):
            failure = {"reason": "INVALID_REFERENCE_QP", "tick": tick, "physics_step": steps,
                       "solver_status_val": response["wbc"].get("status_val"),
                       "reference_apply_valid": False, "invalid_command_not_applied": True,
                       "candidate_rejection_reason": (raw.get('candidate_certificate') or {}).get('rejection_reason')}
            break
        data.ctrl[:] = response["tau_cmd"]
        mujoco.mj_forward(model, data)
        forward_calls += 1
        previous = interface
        for _ in range(PHYSICS_STEPS_PER_SLOT):
            if observer is not None:
                observer()
            mujoco.mj_step(model, data)
            steps += 1
            if not _finite_state(data) or abs(float(data.time) - steps * PHYSICS_DT_S) > 1e-9:
                failure = {"reason": "NONFINITE_REFERENCE_OR_SIMULATOR_RESET", "tick": tick, "physics_step": steps}
                break
            mujoco.mj_forward(model, data)
            forward_calls += 1
            if not _finite_state(data):
                failure = {"reason": "NONFINITE_REFERENCE_REFRESH", "tick": tick, "physics_step": steps}
                break
            vx = float(data.qvel[0])
            vmin, vmax = min(vmin, vx), max(vmax, vx)
        if formal_prefix and tick == 3:
            rows = controls[:4]
            checks = {'exact_four_control_ticks': len(rows) == 4,
                'all_raw_status1': all(row['solver_status_val'] == 1 and not isinstance(row['solver_status_val'], (bool, np.bool_)) for row in rows),
                'all_current_candidate_and_reference_apply_valid': all(row['candidate_valid'] and row['reference_apply_valid'] for row in rows),
                'all_raw_and_sent_original_row_checks': all((row['candidate_certificate'] or {}).get('raw_hard_check', {}).get('pass') and
                    (row['candidate_certificate'] or {}).get('sent_hard_check', {}).get('pass') for row in rows),
                'actual_setup_eps_fixed_1e8': all(row['actual_setup_precision']['actual_setup_eps_abs'] == 1e-8 and
                    row['actual_setup_precision']['actual_setup_eps_rel'] == 1e-8 for row in rows),
                'native_limit6ms': all(row['actual_setup_precision']['actual_setup_native_time_limit_s'] == .006 for row in rows),
                '40_steps_at_008s': steps == 40 and abs(float(data.time) - .08) <= 1e-9,
                'full_state_finite': bool(_finite_state(data)),
                'PID_finite': bool(np.isfinite(servo.b_integral).all()),
                'same_data_controller_servo': id(data) == owner_before['data_id'] and id(controller) == owner_before['controller_id'] and id(servo) == owner_before['servo_id'],
                'no_numerical_failure': failure is None}
            prefix_gate.update(passed=bool(all(checks.values())), checks=checks, checkpoint=checkpoint(),
                actual_physics_steps=steps, actual_time_s=float(data.time))
            save_prefix()
            if not prefix_gate['passed']:
                failure = failure or {'reason': 'REFERENCE_PRECISION_FIX_NOT_ESTABLISHED', 'tick': tick, 'physics_step': steps}
        if failure:
            break
    if formal_prefix and prefix_gate['passed'] is None:
        prefix_gate.update(passed=False, checks={'four_formal_ticks_reached': False},
            checkpoint=checkpoint(), actual_physics_steps=steps, actual_time_s=float(data.time),
            failure=deepcopy(failure))
        save_prefix()
    if formal_prefix and prefix_gate.get('passed'):
        prefix_gate['continued_same_owner_after_pass'] = True
        prefix_gate['final_reference_physics_steps'] = steps
        prefix_gate['final_reference_time_s'] = float(data.time)
    complete = steps == REFERENCE_STEPS and len(controls) == REFERENCE_TICKS and failure is None
    return ({"schema": VERSION, "episode_id": episode_id, "d_ref_m": float(d_m),
        "status": "COMPLETE" if complete else "FAILED_NUMERICAL", "reason": failure,
        "initial_state": initial, "q_init": q_init.tolist(), "snapshots": snapshots,
        "prefix_gate": prefix_gate, "reference_precision_owner": True,
        "reference_settings": {'eps_abs': 1e-8, 'eps_rel': 1e-8, 'native_time_limit_s': .006,
            'scope': controller.solver_owner_scope, 'solver_owner_id': controller.solver_owner_id,
            'owner_config_not_shared_with_injured': True},
        "reference_gate_does_not_promote_raw_status": True,
        "requested_snapshot_ticks": list(ticks), "controls": controls,
        "missing_snapshot_ticks": [tick for tick in ticks if tick not in {s["source_tick"] for s in snapshots}],
        "actual_vx_range_m_s": [vmin, vmax], "max_abs_vx_m_s": max(abs(vmin), abs(vmax)),
        "motion_excitation_reaches_0p08_m_s": max(abs(vmin), abs(vmax)) >= .08,
        "final_state": state_values(model, data), "solver_ledger": controller.solver_ledger,
        "elapsed_ms": (perf_counter() - begin) * 1000.,
        "counts": {"physical_steps": steps, "control_qp_calls": len(controller.solver_ledger),
                   "reference_controller_instances": 1, "initialization_forward_calls": 1,
                   "forward_calls": forward_calls + 1, "clone_data_calls": 0,
                   "contact_linearization_calls": controller.contact_linearization_calls,
                   "svd_calls": controller.svd_calls, "passive_model_calls": controller.passive_model_calls}})
