"""STEP34 saved-only analysis. Missing state/action evidence is not a zero result."""
from collections import Counter
from pathlib import Path
import math
import numpy as np
from cavr_wbc.experiments.step35_io import output, ROOT, METHODS, read, write, load_numeric, relative
from cavr_wbc.experiments.step33_report import csv_write, statistics, finite, jsonl_rows, resolve, numeric_record
from cavr_wbc.control.step34_margin import load_bundle, GAMMA_GRID

def safe(label, gap):
    return bool(label.get('complete') and label.get('full_501_grid') is True and
                label.get('original_physical_safe') and label.get('terminal_pass') and label.get('command_valid_all') and
                finite(label.get('D')) and finite(gap) and 0. <= label['D'] <= gap)


def capacity_event(events):
    events = events or {}
    return bool(events.get('first_capacity_event') or events.get('first_active_indices') or
                events.get('any_actual_capacity99_event') or any(int(value) > 0 for value in events.get('capacity99_count_by_channel', [])))


def branch_facts(record, gap):
    record = record or {}; label = record.get('label') or {}; ticks = record.get('tick_latency_ms') or []
    status = record.get('status', 'NOT_RUN')
    counts = record.get('counts') or {}
    executed = bool(status != 'NOT_RUN' and (record.get('artifact') or ticks or counts.get('physical_steps', 0) or
                                           status in ('COMPLETE', 'FAILED_NUMERICAL', 'FAILED_BUDGET')))
    complete = bool(label.get('complete') and label.get('full_501_grid') is True)
    tick_pass = bool(complete and len(ticks) == 50 and all(finite(value) and 0. <= value <= 20. for value in ticks)
                     and record.get('all_tick_deadline_pass') is True)
    first_match = record.get('first_tau_matches_packet')
    identity = record.get('application_identity_pass')
    physical_failure = bool(executed and (label.get('original_failure') or label.get('observed_original_physical_failure') or
                                         (complete and not label.get('original_physical_safe'))))
    local_failure = bool(complete and finite(label.get('D')) and finite(gap) and label['D'] > gap)
    terminal_failure = bool(complete and not label.get('terminal_pass'))
    actual_safe = safe(label, gap)
    confirmed = bool(actual_safe and tick_pass and identity is True and first_match is True and
                     record.get('actual_horizon_origin') == 'SAMPLE' and record.get('actual_horizon_s') == 1.)
    return {'status': status, 'executed': executed, 'complete_501': complete,
        'physical_pass': bool(complete and label.get('original_physical_safe')), 'terminal_pass': bool(complete and label.get('terminal_pass')),
        'local_pass': bool(complete and finite(label.get('D')) and finite(gap) and 0. <= label['D'] <= gap),
        'actual_safe_at_fixed_gap': actual_safe, 'full_50_ticks_20ms': tick_pass, 'execution_confirmed': confirmed,
        'physical_failure': physical_failure, 'local_failure': local_failure, 'terminal_failure': terminal_failure,
        'command_failure': bool(complete and not label.get('command_valid_all')),
        'numerical_incomplete': bool(executed and not complete),
        'deadline_failure': bool(executed and (any(finite(value) and value > 20. for value in ticks) or
                                             (complete and not tick_pass))),
        'application_identity_pass': identity, 'application_identity_failure': bool(executed and identity is False),
        'first_tau_matches_packet': first_match,
        'observed_unsafe': bool(physical_failure or local_failure or terminal_failure),
        'known_complete_failure': bool(complete and (not actual_safe or not tick_pass or identity is not True or first_match is not True)),
        'late_ticks': sum(finite(value) and value > 20. for value in ticks), 'missing_or_nonfinite_ticks': sum(not finite(value) for value in ticks),
        'D_m': label.get('D'), 'Y': label.get('Y'), 'progress0_04_m': record.get('progress0_04_m'),
        'progress02_04_m': record.get('progress02_04_m'), 'tick_latency_ms': ticks,
        'capacity99_event': capacity_event(record.get('events')), 'first_packet_capacity99_event': bool((record.get('events') or {}).get('first_capacity_event')),
        'events': record.get('events'), 'counts': counts, 'artifact': record.get('artifact'),
        'controls_path': record.get('controls_path'), 'result_path': record.get('result_path'),
        'application_state_comparison': record.get('application_state_comparison'), 'reason': record.get('reason')}


def dump(out, name, rows):
    write(out / (name + '.json'), rows); csv_write(out / (name + '.csv'), rows)


def candidate_row(raw, metadata):
    proof = raw.get('candidate_certificate') or {}
    hard = proof.get('raw_hard_check') or {}
    sent = proof.get('sent_hard_check') or {}
    return {**metadata, 'raw_status': raw.get('status_val'), 'raw_status_text': raw.get('status'),
        'optimizer_converged': proof.get('optimizer_converged'), 'candidate_valid': proof.get('candidate_valid'),
        'strict_candidate_mask': proof.get('strict_candidate_mask'), 'rejection_reason': proof.get('rejection_reason'),
        'raw_full_primal_recorded': raw.get('full_current_raw_x') is not None,
        'full_same_call_CSC_recorded': raw.get('step34_problem') is not None,
        'raw_state_health_identity': proof.get('current_state_health_identity'),
        'failed_raw_rows': np.asarray(hard.get('failed_row_indices', [])).tolist(),
        'failed_sent_rows': np.asarray(sent.get('failed_row_indices', [])).tolist(),
        'contact_residual_inf_m_s2': hard.get('contact_residual_inf'),
        'dynamics_residual_inf_SI': hard.get('dynamics_residual_inf'),
        'native_limit_s': raw.get('osqp_time_limit_s'),
        'solve_wall_ms': raw.get('solve_wall_time_s', 0.) * 1000.,
        'invoke_wall_ms': raw.get('invoke_total_wall_time_s', 0.) * 1000.}


def references(out):
    rows = []; candidates = []; failed_rows = []
    for path in sorted((out / 'episodes').glob('*.json')):
        episode = load_numeric(path)
        rows.append({'episode': episode['episode_id'], 'split': 'CAL' if episode['episode_id'].startswith('C') else 'TEST',
            'status': episode['status'], 'reason': episode.get('reason'), 'physical_steps': episode['counts']['physical_steps'],
            'control_calls': episode['counts']['control_qp_calls'], 'snapshots_saved': len(episode['snapshots']),
            'requested_ticks': episode['requested_snapshot_ticks'], 'missing_ticks': episode['missing_snapshot_ticks'],
            'path': relative(path, out), 'elapsed_ms': episode['elapsed_ms']})
        for control in episode['controls']:
            raw = control['raw_solver_result']
            meta = {'kind': 'REFERENCE', 'episode': episode['episode_id'], 'tick': control['tick'],
                'reference_time_s': control['time_s'], 'source_path': relative(path, out)}
            candidates.append(candidate_row(raw, meta))
            proof = raw.get('candidate_certificate') or {}; hard = proof.get('raw_hard_check') or {}
            matrix = raw.get('source_matrices') or {}
            for index in hard.get('failed_row_indices', []):
                index = int(index)
                failed_rows.append({**meta, 'raw_status': raw['status_val'], 'candidate_valid': proof['candidate_valid'],
                    'row': index, 'row_unit': matrix['row_units'][index], 'A_z': float(hard['A_z'][index]),
                    'lower': float(matrix['l'][index]), 'upper': float(matrix['u'][index]),
                    'original_tolerance': float(matrix['row_abs_tolerance'][index]),
                    'violation': float(hard['row_violation'][index]),
                    'violation_to_tolerance': float(hard['row_violation'][index] / matrix['row_abs_tolerance'][index]) if matrix['row_abs_tolerance'][index] else None})
    return rows, candidates, failed_rows


def online_contrasts(packet, context, old_model):
    """Only saved/evaluated prefixes; no missing action is evaluated for free."""
    from cavr_wbc.control.step33_margin import batch_numeric as old_numeric
    rows = []
    for gamma in GAMMA_GRID:
        entry = packet.get('actions', {}).get(str(gamma), {})
        decision = entry.get('decision') or {}; action = entry.get('action') or {}
        features = entry.get('features26'); prefix = entry.get('prefix') or {}
        strict = bool(action.get('strict_candidate_mask'))
        evaluated = entry.get('evaluation_status') == 'EVALUATED' and features is not None
        old_accept = None
        if evaluated:
            before = packet.get('prehold') or {}
            numeric = old_numeric(old_model, np.asarray([features]), [gamma], [context['role']],
                [prefix.get('D_prefix_m')], prehold_d=[before.get('D_prehold_m')])
            old_accept = bool(action.get('command_valid') and before.get('complete') and before.get('original_physical_pass')
                and prefix.get('complete') and prefix.get('original_physical_pass')
                and all(numeric[g][0] for g in ('finite_input', 'support_gate', 'pose_gate', 'distance_gate', 'calibration_gate'))
                and numeric['U_D'][0] <= context['gap_m'] and np.all(numeric['U_T'][0] <= 1.))
        rows.append({'gamma': gamma, 'evaluated': evaluated, 'action_status': entry.get('evaluation_status', 'NOT_RECORDED'),
            'new_candidate_valid': action.get('command_valid'), 'strict_current_mask': strict,
            'new_model_query_accepted': decision.get('accepted') if evaluated else None,
            'strict_new_model_query_accepted': bool(strict and decision.get('accepted')) if evaluated else None,
            'old_STEP33_query_accepted_same_saved_input': old_accept,
            'alternative_strategy_choice': 'NOT_EVALUATED' if not evaluated else 'PER_SAVED_ACTION_ONLY',
            'not_an_independent_timed_closed_loop_ablation': True})
    return rows


def report(out=None):
    out = output() if out is None else Path(out)
    manifest = read(out / 'MANIFEST.json'); finished = read(out / 'RUN_FINISHED.json')
    freeze = read(out / 'STEP35_FREEZE.json', {})
    model = load_bundle(out / 'models/step35_application_model_cal.npz')
    from cavr_wbc.experiments.step35_io import SOURCE34
    training = read(SOURCE34 / 'TRAINING_SUMMARY.json')
    ref_rows, candidate_rows, row_failures = references(out)
    cal_rows = []
    for item in read(out / 'CAL_REGISTRY.json', []):
        record = read(out / item['path']); label = record['labels']; branch = read(out / item['branch_result'])
        features = record.get('features26')
        cal_rows.append({**item, 'features_finite': bool(features is not None and np.isfinite(features).all()),
            'D_m': label.get('D'), 'Y': label.get('Y'), 'physical_pass_if_complete': bool(label.get('complete') and label.get('original_physical_safe')),
            'terminal_pass_if_complete': bool(label.get('complete') and label.get('terminal_pass')),
            'reason': branch.get('reason'), 'steps': branch.get('counts', {}).get('physical_steps', 0),
            'all_tick_deadline_pass': branch.get('all_tick_deadline_pass')})
    group_rows = [{**{k: g.get(k) for k in ('TRAIN_finite_count', 'TRAIN_distinct_snapshots', 'CAL_planned', 'CAL_finite',
        'CAL_complete', 'CAL_complete_distinct_snapshots', 'CAL_complete_episodes', 'CAL_complete_physical_failures',
        'CAL_physical_unknown', 'local_calibrated', 'cal_max_nearest_distance', 'distance_threshold')}, 'group': key}
        for key, g in model['groups'].items()]
    queue = []; branches = []; phases = []; action_status = []; contrasts = []; extension = []; shadows = []
    old_model = None
    for plan in manifest['TEST']:
        directory = out / 'queue' / plan['context_id']; result = read(directory / 'RESULT.json', {})
        context = result.get('context') or {}; per_method = {}
        for method in METHODS:
            response = (result.get('methods') or {}).get(method) or {}
            actual = (response.get('branches') or {}).get('ACTUAL') or {}
            fact = branch_facts(actual, plan['gap_m'])
            sent = bool(response.get('selected_sent')); ready = response.get('command_ready_ms')
            timely = sent and finite(ready) and ready <= 20.
            gamma = response.get('selected_gamma')
            row = {**plan, 'method': method, 'source_eligible': bool(context.get('eligible')),
                'method_result_recorded': bool(response), 'online_status': response.get('status', 'NOT_RUN'),
                'selected_sent': sent, 'timely_recognized_sent': timely, 'selected_gamma': gamma,
                'injured_middle_event': bool(timely and gamma in (.75, .5, .25)), 'command_ready_ms': ready,
                'online_numeric_path': response.get('online_numeric_path'), **fact}
            row['execution_confirmed'] = bool(timely and fact['execution_confirmed'])
            queue.append(row); per_method[method] = row
            for branch_name in ('ACTUAL', 'COUNTERFACTUAL_C', 'COUNTERFACTUAL_B'):
                evidence = (response.get('branches') or {}).get(branch_name) or {}
                branches.append({**plan, 'method': method, 'branch': branch_name, **branch_facts(evidence, plan['gap_m'])})
            if response.get('online_numeric_path'):
                packet = load_numeric(out / response['online_numeric_path'])
                phases.extend({**plan, 'method': method, 'phase': key, 'duration_ms': value} for key, value in packet.get('phase_latency_ms', {}).items())
                if old_model is None:
                    from cavr_wbc.control.step33_margin import load_delay_calibration
                    from cavr_wbc.experiments.step34_io import SOURCE33
                    old_model = load_delay_calibration(SOURCE33 / 'calibration/ALIGNED_RECAL/step33_delay_cal_aligned_recal.npz')
                contrasts.extend({**plan, 'method': method, **item} for item in online_contrasts(packet, context, old_model))
                for endpoint in ('C', 'B'):
                    ep = packet.get(endpoint) or {}; raw = ep.get('raw_solver_result', ep.get('wbc', {})) or {}
                    if raw:
                        candidate_rows.append(candidate_row(raw, {**plan, 'method': method, 'kind': 'FIRST_' + endpoint}))
                action_status.extend({**plan, 'method': method, 'gamma': float(key),
                    'evaluation_status': entry.get('evaluation_status'), 'new_command_valid': (entry.get('action') or {}).get('command_valid'),
                    'new_model_accepted': (entry.get('decision') or {}).get('accepted'),
                    'query_numeric': (entry.get('decision') or {}).get('numeric')} for key, entry in packet.get('actions', {}).items())
            else:
                phases.append({**plan, 'method': method, 'phase': 'NOT_RUN', 'duration_ms': None,
                               'reason': 'SOURCE_REFERENCE_UNAVAILABLE_OR_CAL_NOT_READY'})
        gov = per_method[METHODS[0]]
        g_response = (result.get('methods') or {}).get(METHODS[0]) or {}
        endpoints = {name: branch_facts((g_response.get('branches') or {}).get('COUNTERFACTUAL_' + name), plan['gap_m']) for name in ('C', 'B')}
        comparison = bool(gov['injured_middle_event'] and gov['execution_confirmed'] and endpoints['B']['execution_confirmed'])
        gain = gov['progress02_04_m'] - endpoints['B']['progress02_04_m'] if comparison else None
        ext = bool(comparison and gain > 0 and endpoints['C']['observed_unsafe'])
        extension.append({**plan, 'middle_sent': gov['injured_middle_event'], 'comparison_available_safe_B': comparison,
            'progress02_04_gain_m': gain, 'safe_action_extension': ext,
            'C_status': endpoints['C']['status'], 'C_observed_unsafe': endpoints['C']['observed_unsafe'],
            'C_numerical_incomplete': endpoints['C']['numerical_incomplete'], 'B_status': endpoints['B']['status'],
            'both_endpoints_safe_utility_tradeoff': bool(comparison and gain > 0 and endpoints['C']['execution_confirmed']),
            'shared_packet_first_cost_not_independent_baseline': True})
        shadow_path = directory / METHODS[0] / 'CAPACITY_SHADOW_NUMERIC.json'
        shadow = load_numeric(shadow_path) if shadow_path.exists() else {}
        for name in ('C', 'B'):
            item = shadow.get(name) or {}
            shadows.append({**plan, 'endpoint': name, 'status': item.get('status', 'NOT_RUN'),
                'candidate_valid': item.get('candidate_valid'), 'raw_status': item.get('raw_optimizer_status'),
                'nonoptimal_excluded_action_exists': bool(item.get('nonoptimal_excluded_action_exists')),
                'bounded_candidate_valid': item.get('bounded_candidate_valid'), 'new_QP_calls': item.get('new_QP_calls', 0),
                'actual_middle_executed': gov['injured_middle_event'] and gov['executed'],
                'actual_capacity99_event': gov['capacity99_event'], 'optimality_or_recovery_benefit_claim': False})
    by_method = {}
    grouped = []
    for method in METHODS:
        rows = [r for r in queue if r['method'] == method]
        by_method[method] = summary(rows)
        for gap in (.004, .006, .008):
            for role in ('thigh', 'calf'):
                selected = [r for r in rows if r['gap_m'] == gap and r['role'] == role]
                grouped.append({'method': method, 'gap_mm': int(gap * 1000), 'role': role, **summary(selected)})
    successful = [r for r in queue if r['method'] == METHODS[0] and r['injured_middle_event'] and r['execution_confirmed']]
    source_ids = {r['source_state_id'] for r in successful}; episodes = {r['episode'] for r in successful}
    extension_good = [r for r in extension if r['safe_action_extension']]
    extension_states = {r['source_state_id'] for r in extension_good}; extension_eps = {r['episode'] for r in extension_good}
    capacity_states = {r['source_state_id'] for r in shadows if r['nonoptimal_excluded_action_exists'] and r['bounded_candidate_valid'] and r['actual_middle_executed'] and r['actual_capacity99_event']}
    prefix=read(out / 'REFERENCE_PREFIX.json', {})
    model_load=read(out / 'MODEL_LOAD.json')
    scientific = 'CALIBRATION_NOT_READY' if freeze.get('readiness_branch') == 'CALIBRATION_NOT_READY' else 'FIXED_PANEL_COMPLETED' if finished['status'] == 'COMPLETED' else 'INCOMPLETE'
    ledger = list(jsonl_rows(out / 'STEP35_LEDGER.jsonl')); returns = [r for r in ledger if r['event'] == 'QP_RETURN']
    current_reference_lookup = {(r['episode'], int(r['tick']) + 1): r for r in candidate_rows if r['kind'] == 'REFERENCE'}
    last_reference_return = {}
    for call in returns:
        if call['kind'] == 'REFERENCE':
            last_reference_return[(call['owner'], call['local_qp_index'])] = call['global_qp_index']
    scalar_masks = {}
    for event in ledger:
        if event['event'] == 'CURRENT_CANDIDATE_CHECK':
            call = next((r for r in reversed(returns) if r['kind'] == event['kind'] and r['owner'] == event['owner'] and r['timestamp_utc'] <= event['timestamp_utc']), None)
            if call is not None:
                scalar_masks[call['global_qp_index']] = event
    all_call_masks = []
    for call in returns:
        key = (call['owner'], call['local_qp_index']); index = call['global_qp_index']
        full = current_reference_lookup.get(key) if call['kind'] == 'REFERENCE' and last_reference_return.get(key) == index else None
        mask = full or scalar_masks.get(index) or {}
        all_call_masks.append({'global_qp_index': index, 'kind': call['kind'], 'owner': call['owner'],
            'raw_status': call['status_val'], 'raw_status_text': call['status'],
            'candidate_mask': mask.get('candidate_valid'), 'strict_candidate_mask': mask.get('strict_candidate_mask'),
            'mask_evidence_status': 'FULL_CURRENT_RAW_CSC' if full else 'MASK_SCALAR_ONLY' if mask else 'UNKNOWN_PARTIAL_FIRST_ATTEMPT',
            'full_raw_CSC_materialized': bool(full), 'native_time_limit_s': call['osqp_time_limit_s'],
            'solve_wall_ms': 1000. * call['solve_wall_time_s'], 'invoke_wall_ms': 1000. * call['invoke_total_wall_time_s'],
            'setup_wall_ms': 1000. * call['setup_time_s'], 'update_wall_ms': 1000. * call['update_time_s'],
            'polish_wall_ms': 1000. * call['polish_time_s']})
    diagnostics = read(out / 'ENDPOINT_DIAGNOSTICS.json', [])
    result = {'run_id': manifest['run_id'], 'NUMERICAL_STATUS': finished['status'], 'SCIENTIFIC_RUN_STATUS': scientific,
        'REFERENCE_PRECISION_STATUS': 'REFERENCE_PREFIX_PRECISION_ESTABLISHED' if prefix.get('passed') else 'REFERENCE_PRECISION_FIX_NOT_ESTABLISHED',
        'REFERENCE_PREFIX': prefix, 'REFERENCE_completed_episodes':sum(r['status']=='COMPLETE' for r in ref_rows),
        'RESEARCH_STATUS': scientific,
        'A_STATUS': 'INJURED_MIDDLE_EXECUTION_OBSERVED' if len(source_ids) >= 2 and len(episodes) >= 2 else 'NOT_ESTABLISHED',
        'B_STATUS': 'SAFE_ACTION_EXTENSION_OBSERVED' if len(extension_states) >= 2 and len(extension_eps) >= 2 else 'NOT_ESTABLISHED',
        'C_STATUS': 'CAPACITY_EXCLUSION_EVIDENCE_OBSERVED' if len(capacity_states) >= 2 else 'NOT_ESTABLISHED',
        'planned_TEST_inputs': 48, 'planned_source_states': 16, 'planned_episodes': 4, 'planned_method_slots': 96,
        'observed_formal_online_decisions': sum(r['method_result_recorded'] for r in queue),
        'observed_TEST_source_states': len({r['source_state_id'] for r in queue if r['source_eligible']}),
        'actual_runs': sum(r['executed'] for r in queue), 'actual_middle_runs': sum(r['injured_middle_event'] and r['executed'] for r in queue),
        'methods': by_method, 'gap_role_groups': grouped,
        'training': {'planned': len(training['TRAIN_ids_all']), 'finite': len(training['TRAIN_finite_ids']),
            'complete_D_Y': len(training['TRAIN_regression_ids']), 'risk_known': len(training['TRAIN_risk_ids']),
            'risk_pass': training['TRAIN_risk_pass_count'], 'risk_fail': training['TRAIN_risk_fail_count'],
            'unknown_risk': len(training['TRAIN_unknown_risk_ids']), 'complete_physical_failures': training['TRAIN_complete_failures_retained'],
            'partial_physical_failures': training['TRAIN_partial_observed_physical_failures_retained'],
            'risk_converged': training['risk_converged'], 'risk_iterations': training['risk_iterations'],
            'regression_fits': 0, 'risk_fits': 0, 'source': 'LOADED_STEP34_TRAINED_ONLY_FROM_STEP33_ALIGNED_DEV'},
        'CAL': {'contexts_planned': 24, 'action_slots_planned': 120, 'recorded': len(cal_rows),
            'finite_features': sum(r['features_finite'] for r in cal_rows), 'complete': sum(r['complete'] for r in cal_rows),
            'statuses': dict(Counter(r['status'] for r in cal_rows)), 'groups': group_rows,
            '100ms_teacher_used': False},
        'reference_summary': ref_rows, 'reference_failure_rows': row_failures,
        'current_reference_candidates': len(candidate_rows), 'complete_current_witnesses': sum(r['raw_full_primal_recorded'] and r['full_same_call_CSC_recorded'] for r in candidate_rows),
        'QP_raw_status_counts_all_attempts': dict(Counter(str(r['status_val']) for r in returns)),
        'QP_by_kind_all_attempts': finished['budget']['QP_by_kind'], 'candidate_valid_rows_saved': sum(bool(r['candidate_valid']) for r in candidate_rows),
        'candidate_rejected_rows_saved': sum(r['candidate_valid'] is False for r in candidate_rows),
        'diags': {'planned_input_count': 4, 'recorded_method_slots': len(diagnostics),
            'status_counts': dict(Counter(r['status'] for r in diagnostics)), 'real_C_B_attempts': sum(bool(load_numeric(r['numeric']['json']).get('C')) for r in diagnostics),
            'ACTUAL_runs': 0, 'diagnostics_are_not_formal_TEST': True},
        'timing_summary': {'formal_command_ready_ms': statistics(r['command_ready_ms'] for r in queue if r['method_result_recorded']),
            'QP_solve_wall_ms_all_attempts': statistics(1000 * r['solve_wall_time_s'] for r in returns),
            'on_demand_native_prefix_real_calls': sum(r['event'] == 'PREFIX_NATIVE_START' and r.get('kind') == 'PREFIX_PREDICTION' for r in ledger),
            'no_online_timing_evidence_if_zero_calls': True},
        'same_packet_contrasts': {'evaluated_action_rows': len(contrasts), 'new_vs_strict_candidate_changed': sum(r['new_candidate_valid'] and not r['strict_current_mask'] for r in contrasts),
            'new_model_vs_old_gate_changed_evaluated': sum(r['evaluated'] and r['new_model_query_accepted'] != r['old_STEP33_query_accepted_same_saved_input'] for r in contrasts),
            'full_alternative_strategy_not_filled_from_missing_prefixes': True, 'closed_loop_causal_ablation_claim': False},
        'mechanism_counts': {'A_distinct_source_states': len(source_ids), 'A_episodes': len(episodes),
            'B_distinct_source_states': len(extension_states), 'B_episodes': len(extension_eps), 'C_distinct_source_states': len(capacity_states)},
        'budget': finished['budget'], 'implementation_repairs_used': 2,
        'failed_first_numerical_attempt_preserved': True, 'startup_and_first_failed_reference_full_raw_witness_not_materialized': False,
        'raw_evidence_gap_disclosure': 'STEP35 stores per-call raw shards from startup and all invocations; old STEP34 gaps unchanged, never replenished',
        'numerical_calls_after_finish': 0, 'E3_RL_HARDWARE': 'NOT_AUTHORIZED',
        'historical_results_unchanged': True, 'historical_STEP33_A_B_C': 'NOT_ESTABLISHED_UNCHANGED',
        'necessary_tests_initial': read(out / 'tests/NECESSARY_TESTS.json'), 'necessary_tests_targeted_repair': read(out / 'tests/TARGETED_PRECISION_FIXTURE.json'), 'state_restore_targeted_test':read(out/'tests/TARGETED_STATE_RESTORE.json'),
        'current_delivery_check': read(out / 'tests/CURRENT_DELIVERY_CHECK.json', {}), 'loaded_source_model':model_load,
        'new_model_fits':0, 'passed_reference_prefix_restarted':False,
        'row_counts': {'QUEUE_RESULTS': len(queue), 'ACTION_EXTENSION_RESULTS': len(extension), 'CAPACITY_RESULTS': len(shadows)}}
    for name, data in (('QUEUE_RESULTS', queue), ('GAP_ROLE_RESULTS', grouped), ('BRANCH_RESULTS', branches),
        ('CAL_RESULTS', cal_rows), ('CAL_GROUP_SUMMARY', group_rows), ('REFERENCE_RESULTS', ref_rows),
        ('CURRENT_CANDIDATE_MASK', candidate_rows), ('REFERENCE_FAILED_ROWS', row_failures),
        ('ALL_QP_RAW_STATUS_AND_MASK', all_call_masks),
        ('ON_DEMAND_PHASE_LATENCY', phases), ('ONLINE_ACTION_STATUS', action_status),
        ('SAME_PACKET_DIAGNOSTIC_CONTRASTS', contrasts), ('ACTION_EXTENSION_RESULTS', extension), ('CAPACITY_RESULTS', shadows)):
        dump(out, name, data)
    raw_rows=[]
    for path in sorted((out/'raw_qp').glob('QP*.json')):
        doc=load_numeric(path); raw=doc['raw_result']
        raw_rows.append({**candidate_row(raw,{'global_qp_index':doc['global_qp_index'],'kind':doc['kind'],'owner':doc['owner']}),
            'actual_setup_eps_abs':raw.get('actual_setup_eps_abs'),'actual_setup_eps_rel':raw.get('actual_setup_eps_rel'),
            'solver_owner_scope':raw.get('solver_owner_scope'),'raw_path':relative(path,out)})
    dump(out,'ALL_CURRENT_RAW_QP_EVIDENCE',raw_rows)
    result['raw_QP_shards']=len(raw_rows)
    result['raw_QP_scope_precision_counts']=dict(Counter(str(r['solver_owner_scope'])+':'+str(r['actual_setup_eps_abs']) for r in raw_rows))
    diagnostic_rows=[]
    for item in diagnostics:
        packet=load_numeric(item['numeric']['json'])
        endpoints={}
        for name in ('C','B'):
            ep=packet.get(name) or {};raw=ep.get('raw_solver_result',ep.get('wbc',{})) or {}
            endpoints[name]={'raw_status':raw.get('status_val'),'feasible':bool(ep.get('command_valid',ep.get('valid_command'))),
                'reason':(raw.get('candidate_certificate') or {}).get('rejection_reason')}
        diagnostic_rows.append({**{k:item[k] for k in ('context_id','source_state_id','method','ordinal','status')},
            'command_ready_ms':packet.get('command_ready_ms'),'prefix_order':packet.get('on_demand_prefix_order',[]),
            'phase_latency_ms':packet.get('phase_latency_ms',{}),'C':endpoints['C'],'B':endpoints['B'],
            'selected_sent':False,'ACTUAL_runs':0})
    dump(out,'ENDPOINT_DIAGNOSTIC_SUMMARY',diagnostic_rows)
    result['endpoint_diagnostics']=diagnostic_rows
    result['CAL']['physical_pass_complete']=sum(r['complete'] and r['physical_pass_if_complete'] for r in cal_rows)
    result['CAL']['terminal_pass_complete']=sum(r['complete'] and r['terminal_pass_if_complete'] for r in cal_rows)
    result['CAL']['physical_fail_complete']=sum(r['complete'] and not r['physical_pass_if_complete'] for r in cal_rows)
    result['CAL']['terminal_fail_complete']=sum(r['complete'] and not r['terminal_pass_if_complete'] for r in cal_rows)
    result['RAW_EVIDENCE_COMPLETE_ALL_CALLS']=len(raw_rows)==budget_count if (budget_count:=finished['budget']['total_QP_calls']) else False
    write(out / 'STEP35_RESULT.json', result)
    (out / 'STEP35_REPORT.md').write_text(report_text(result, manifest), encoding='utf-8', newline='\n')
    (out / 'STEP35_RESEARCH_HANDOFF.md').write_text(handoff_text(result), encoding='utf-8', newline='\n')
    print({k: result[k] for k in ('NUMERICAL_STATUS', 'SCIENTIFIC_RUN_STATUS', 'RESEARCH_STATUS', 'A_STATUS', 'B_STATUS', 'C_STATUS')})
    return result


PROTOCOL_LINES='''AUTHORIZE_STEP35_REFERENCE_PRECISION_REPAIR_AND_PANEL = TRUE
NEW_MODEL_FITS = 0
REFERENCE_EPS_ABS = 1e-8
REFERENCE_EPS_REL = 1e-8
REFERENCE_QP_LIMIT_S = 0.006
REFERENCE_PREFIX_IS_PART_OF_FORMAL_REFERENCE = TRUE
RESTART_PASSED_REFERENCE_PREFIX = FALSE
INJURED_SOLVER_EPS_UNCHANGED = 1e-7
FIRST_C_B_QP_LIMIT_S = 0.003
FEEDBACK_QP_LIMIT_UPPER_S = 0.006
CONTACT_ROW_ACCEPTANCE_M_S2 = 1e-5
ORIGINAL_PHYSICAL_AND_TERMINAL_BOUNDS_UNCHANGED = TRUE
DEADLINE_MS = 20
CAL_CONTEXTS = 24
CAL_MAX_ACTION_TRAJECTORIES = 120
TEST_SOURCE_STATES = 16
TEST_PLANNED_INPUTS = 48
TEST_METHOD_SLOTS = 96
TEST_GAPS_MM = 4,6,8
MAX_NEW_QP_CALLS = 25000
MAX_NEW_PHYSICS_STEPS = 250000
MAX_NUMERICAL_WALL_MINUTES = 90
MAX_DEV_IMPLEMENTATION_REPAIRS = 2
TEST_RESULT_BASED_RETRY = FALSE
HISTORICAL_RESULTS_UNCHANGED = TRUE
E3_RL_HARDWARE = NOT_AUTHORIZED'''


def report_text(r,manifest):
    prefix=r['REFERENCE_PREFIX'];cal=r['CAL']
    lines=['# STEP35：参考精度修复与固定面板接续','','## Material Passport','',
        'experiment-agent / bounded implementation + simulation / 2026-10-09 / Asia/Seoul / ANALYZED / STEP35_v1。','',
        f"Run：{r['run_id']}；源提交：{manifest['source_commit']}。",'',
        f"参考修复：{r['REFERENCE_PRECISION_STATUS']}；完整reference {r['REFERENCE_completed_episodes']}/8。",
        f"研究面板：{r['SCIENTIFIC_RUN_STATUS']}；调度器：{r['NUMERICAL_STATUS']}。A/B/C = {r['A_STATUS']} / {r['B_STATUS']} / {r['C_STATUS']}。",'',
        '## 三项结论','',
        '1. 健康reference数值修复成立。C35_P062的四tick前缀属于正式reference，40步/.08s、raw status1及所有原raw/sent行通过；同data/controller/PID/solver memory直接续行，未重启前缀。全部八条reference完成110ticks/1100steps，后续DEV修复只复用这些已保存输入。',
        f"2. 受损中间执行未建立。新CAL保存{cal['recorded']}/120动作位，完整18、partial37、不可用65；中间组最大只有3个完整snapshot，最低四snapshot门不满足。正式48×2方法位NOT_RUN，{r['observed_formal_online_decisions']}次正式决策、{r['actual_runs']}个正式ACTUAL。",
        '3. 安全动作集合扩展未建立。没有正式中间ACTUAL，也没有相应同packet C/B反事实；不能用CAL传播、数值未完成或缺失结果替代机制证据。容量/99%观察只在实际CAL证据内另列，不构成C成功。','',
        '## 精度与原约束','',
        '仅健康reference新owner在首次workspace setup前复制cfg并固定eps_abs=eps_rel=1e−8，单次6ms，原max_iter/polish不变。受损C/B与feedback owner仍为1e−7、3ms/6ms；20ms截止、数学QP、PID/Gamma、零额外slack、接触1e−5m/s²和其它原SI行容差不变。',
        'reference候选原状态和current-feasible证书不改写；健康命令额外要求raw status1，非status1在PID更新、ctrl/forward/积分前拒绝。记录实际setup精度，而非只记录期望值。',
        'OSQP停止条件含相对全局残差尺度，polish失败时保留ADMM返回；Solved不能自动保证混合单位每条原SI行通过。[官方收敛与polish定义](https://osqp.org/docs/solver/index.html)。本轮独立原行核验仍执行，没有给旧reference补认证。','',
        '## 完整reference与前缀','',
        '| Episode | 状态 | 步数 | 保存snapshot | 请求tick |','|---|---|---:|---:|---|']
    for row in r['reference_summary']:
        lines.append(f"| {row['episode']} | {row['status']} | {row['physical_steps']} | {row['snapshots_saved']} | {row['requested_ticks']} |")
    lines+=['',f"四tick检查：{prefix.get('checks')}。",
        '完整边界checkpoint：[REFERENCE_PREFIX](REFERENCE_PREFIX.json)，包括integration state、ctrl、warmstart、外力、PID及solver last_x/last_y。第一reference文件也记录随后续行事实。','',
        '## 模型加载与新CAL','',
        '直接加载源step34_trained_only.json/npz，Ridge与风险头均未再fit；没有使用STEP34的空CAL作为已校准对象。模型身份：[MODEL_LOAD](MODEL_LOAD.json)；新CAL与代码最终冻结：[STEP35_FREEZE](STEP35_FREEZE.json)。原K=5 density、姿态域、距离规则、四snapshot/两episode LOCAL、风险门、D/terminal reserve均保留。',
        f"CAL：{cal['statuses']}；有限输入{cal['finite_features']}、完整物理通过{cal['physical_pass_complete']}、完整物理失败{cal['physical_fail_complete']}、完整terminal通过{cal['terminal_pass_complete']}、完整terminal失败{cal['terminal_fail_complete']}。失败和finite partial不删除，不用1e−8或100ms teacher补受损标签。",'',
        '| Gamma×role | finite | complete | distinct snapshot | episode | 可查询 |','|---|---:|---:|---:|---:|---|']
    for row in cal['groups']:
        if not row['group'].endswith(':healthy'):
            lines.append(f"| {row['group']} | {row['CAL_finite']} | {row['CAL_complete']} | {row['CAL_complete_distinct_snapshots']} | {row['CAL_complete_episodes']} | {row['local_calibrated']} |")
    lines+=['','全120位：[CAL_RESULTS](CAL_RESULTS.csv)，ordinary numerical/physical/terminal失败与NOT_RUN全部保留。达到最大3/4不降低四snapshot要求；模型系数未改。','',
        '## 预设端点/按需诊断','',
        '因中间组未可查询，按协议只对原首四calf输入进行两方法诊断；这四输入含三个gap复用，只有两个distinct source state，不能计成四个独立机制实例。诊断不认可、不发送、0 ACTUAL；96方法位保留为计划NOT_RUN而非96次观测。','',
        '| 输入 | 方法 | status | ready ms | C raw/feasible | B raw/feasible | prefix顺序 |',
        '|---|---|---|---:|---|---|---|']
    for row in r['endpoint_diagnostics']:
        ms='缺失' if row['command_ready_ms'] is None else f"{row['command_ready_ms']:.3f}"
        lines.append(f"| {row['context_id']} | {row['method']} | {row['status']} | {ms} | {row['C']['raw_status']}/{row['C']['feasible']} | {row['B']['raw_status']}/{row['B']['feasible']} | {row['prefix_order']} |")
    lines+=['','诊断phase：[ENDPOINT_DIAGNOSTIC_SUMMARY](ENDPOINT_DIAGNOSTIC_SUMMARY.json)。超过20ms照常保存，未查询不声称安全/不安全。所有gap/role正式计划分母见[QUEUE_RESULTS](QUEUE_RESULTS.csv)、[GAP_ROLE_RESULTS](GAP_ROLE_RESULTS.csv)。没有正式packet，旧模型/strict mask独立闭环对照不产生观测；不补prefix。','',
        '## DEV接口修复与证据','',
        '五类必要fixture首次4通过/1 mock初始化错误；仅该失败项定点通过，没有重跑STEP34 suite。真实首轮CAL暴露完整integration时间bit不一致：预测.020000000000000004被旧reset改为.02，首轮CAL/诊断标INVALID并保留。第一个DEV修复只恢复预测完整时间位，不改精度/阈值；八条已通过reference不重启、不重算。',
        '随后普通反馈候选拒收的partial行不含已施加τ，旧统计函数报字段错误。第二个DEV文件修复从已保存NPZ/controls恢复结果，拒收行从capacity applied统计分离并保留raw status/冻结事实；没有重算该轨迹或零命令填补。两次DEV修复已用完。',
        '前一数值freeze属于无效实现attempt，保存在repairs/attempt01_invalid_state_restore；最终有效新CAL与代码冻结一次。所有attempt共用原run_id/起点与累计预算；正式TEST未启动，因此没有结果驱动TEST重试。',
        f"预算：{r['budget']}。本轮完整raw分片{r['raw_QP_shards']}/{r['budget']['total_QP_calls']}，每真实QP从startup即保留raw/CSC、原行/health/witness和实际精度。原STEP34缺口不补求解。",
        f"scope/精度数量：{r['raw_QP_scope_precision_counts']}。",
        '逐调用：[ALL_CURRENT_RAW_QP_EVIDENCE](ALL_CURRENT_RAW_QP_EVIDENCE.csv)；短账本：[STEP35_LEDGER](STEP35_LEDGER.jsonl)；attempt：[ATTEMPT_LEDGER](ATTEMPT_LEDGER.jsonl)。saved-only分析和出图无新增QP/积分/fit。',
        '当前读回/scoped diff核验仅一次；工程一致性和reference修复不能写成受损A/B/C PASS。最多两张实数据图，不增加空ACTUAL装饰图。旧STEP34 BLOCKED及其它旧结果保持，未进入E3/RL/硬件，未访问机器人运控算法。','',
        '~~~ini',PROTOCOL_LINES,f"REFERENCE_PRECISION_STATUS = {r['REFERENCE_PRECISION_STATUS']}",
        f"NUMERICAL_STATUS = {r['NUMERICAL_STATUS']}",f"SCIENTIFIC_RUN_STATUS = {r['SCIENTIFIC_RUN_STATUS']}",
        f"A_STATUS = {r['A_STATUS']}",f"B_STATUS = {r['B_STATUS']}",f"C_STATUS = {r['C_STATUS']}",
        f"FULL_RAW_EVIDENCE_ALL_CALLS = {str(r['RAW_EVIDENCE_COMPLETE_ALL_CALLS']).upper()}",'FORMAL_TEST_DECISIONS = 0','FORMAL_ACTUAL_RUNS = 0','~~~','']
    return '\n'.join(lines)


def handoff_text(r):
    return '\n'.join(['# STEP35研究交接','',
        f"参考精度修复：{r['REFERENCE_PRECISION_STATUS']}；八条正式reference完整，首四tick不重启。",
        f"CAL {r['CAL']['statuses']}；中间完整snapshot最多3/4，研究状态{r['SCIENTIFIC_RUN_STATUS']}。",
        f"A/B/C：{r['A_STATUS']} / {r['B_STATUS']} / {r['C_STATUS']}。正式TEST与ACTUAL未运行，不能把CAL或诊断当独立闭环机制证据。",
        'reference eps1e−8建立了初态；受损owner1e−7、3ms/6ms能力不改变。本轮fit0，新CAL及原reserve/域/风险门均保留。',
        '两次DEV接口修复、所有失败和累计预算完整保存；模型只加载。后续新设计/额外数值调用需新授权，当前不继续调参或重试。',
        '旧STEP34 BLOCKED不撤回；E3/RL/硬件未授权，机器人运控算法隔离。','',
        '~~~ini',PROTOCOL_LINES,'~~~',''])


def summary(rows):
    sent = sum(r['timely_recognized_sent'] for r in rows); passed = sum(r['execution_confirmed'] for r in rows)
    return {'planned': len(rows), 'recorded_decisions': sum(r['method_result_recorded'] for r in rows),
        'source_eligible': sum(r['source_eligible'] for r in rows), 'timely_sent': sent,
        'ACTUAL': sum(r['executed'] for r in rows), 'complete_501': sum(r['complete_501'] for r in rows),
        'full_pass': passed, 'conditional_success': passed / sent if sent else None,
        'recognition_coverage_planned': sent / len(rows) if rows else None,
        'error_recognition': sum(r['timely_recognized_sent'] and not r['execution_confirmed'] for r in rows),
        'numerical_incomplete': sum(r['numerical_incomplete'] for r in rows),
        'actual_physical_failure': sum(r['physical_failure'] for r in rows),
        'actual_local_failure': sum(r['local_failure'] for r in rows), 'actual_terminal_failure': sum(r['terminal_failure'] for r in rows),
        'statuses': dict(Counter(r['online_status'] for r in rows))}


if __name__=='__main__':
    report()
