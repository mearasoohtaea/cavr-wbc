"""STEP35 fixed TRAIN transfer, CAL24 and paired TEST48 bounded batch."""
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
import argparse
import gc
import os
from time import perf_counter
import traceback
import numpy as np
from cavr_wbc.experiments import step17_formal_panel as frozen
from cavr_wbc.experiments import step35_sim as sim
from cavr_wbc.experiments.step35_reference import reference_episode
from cavr_wbc.experiments.step34_storage import save_bank, load_bank
from cavr_wbc.experiments.step28_sprint import home_context
from cavr_wbc.experiments.step29_sprint import source_context
from cavr_wbc.experiments.step30_sprint import missing, events
from cavr_wbc.experiments.step35_io import (ROOT, SOURCE30, SOURCE33, SOURCE34, RUN_ID, PARENT, PROTOCOL, METHODS,
    output, read, write, append, sha, relative, save_numeric, load_numeric)
from cavr_wbc.experiments.step35_budget import SprintBudget, SprintLimit
from cavr_wbc.control.step35_kernel import Kernel
from cavr_wbc.control.step34_actions import GAMMA_GRID, prepare_shared, make_action
from cavr_wbc.control.step34_margin import (build_calibration, save_bundle, load_bundle, labels, gamma_key, identity)
from cavr_wbc.platforms.go2_mujoco import extract_actuator_audit, extract_healthy_torque_limits

CAL_EPISODES = (('C35_P062', .062, 20261301), ('C35_N062', -.062, 20261301),
                ('C35_P070', .070, 20261302), ('C35_N070', -.070, 20261302))
TEST_EPISODES = (('T35_P061', .061, 20261311), ('T35_N061', -.061, 20261311),
                 ('T35_P071', .071, 20261312), ('T35_N071', -.071, 20261312))
GAPS = (.004, .006, .008)


def plans(split):
    if split not in ('CAL', 'TEST'):
        raise ValueError('fixed CAL/TEST only')
    episodes, ticks = (CAL_EPISODES, (29, 35, 41)) if split == 'CAL' else (TEST_EPISODES, (31, 39))
    result = []; snapshot_ordinal = 0; state_ordinal = 0
    for episode, displacement, seed in episodes:
        for tick in ticks:
            for kind in ('THIGH_15', 'CALF_15'):
                state_id = episode + f'_T{tick:03d}_' + kind
                for gap in (None,) if split == 'CAL' else GAPS:
                    result.append({'context_id': state_id if gap is None else state_id + f'_GAP{gap*1000:02.0f}',
                        'source_state_id': state_id, 'source_state_ordinal': state_ordinal,
                        'ordinal': len(result), 'snapshot_ordinal': snapshot_ordinal,
                        'snapshot_id': episode + f'_T{tick:03d}', 'tick': tick, 'episode': episode,
                        'seed': seed, 'role': kind.split('_')[0].lower(), 'health_kind': kind,
                        'direction': 1 if displacement > 0 else -1, 'split': split, 'gap_m': gap,
                        'method_order': list(METHODS if snapshot_ordinal % 2 == 0 else METHODS[::-1])})
                state_ordinal += 1
            snapshot_ordinal += 1
    return result


def event(out, name, **fields):
    append(out / 'ATTEMPT_LEDGER.jsonl', {'event': name, 'timestamp_utc': datetime.now(timezone.utc).isoformat(), **fields})

def save_branch(out, directory, name, branch, c):
    path = directory / name
    path.mkdir(parents=True, exist_ok=True)
    if branch.get('status') == 'NOT_RUN':
        lab = missing(branch.get('reason', 'NOT_RUN'))
        record = {**branch, 'label': lab, 'result_path': relative(path / 'RESULT.json', out)}
        write(path / 'RESULT.json', record)
        return record
    if (path / 'actual.npz').exists():
        bank = {'path':str(path / 'actual.npz'),'sha256':sha(path / 'actual.npz'),
            'source_id':branch['branch_id'],'row_count':len(branch['physics_trajectory'])+(branch.get('initial_fact') is not None),
            'recovered_from_saved_evidence':True,'additional_QP_calls':0,'additional_steps':0}
    else:
        bank = save_bank(path / 'actual.npz', branch)
    lab = labels(branch, c)
    controls = branch['controls']
    if not (path / 'CONTROL_RESULTS.json').exists():
        save_numeric(path / 'CONTROL_RESULTS.json', {'controls': controls, 'status': branch['status'], 'reason': branch.get('reason')})
    first = controls[1]['capacity_interface'] if len(controls) > 1 else {}
    evt = current_events(branch, {'capacity_interface': first,
        'first_capacity_event': bool(first.get('sent_99_percent_active_indices'))})
    # First prehold is an identified prior command, not a new solved QP.
    timely = bool(len(controls) == 50 and all(row.get('valid_command') and float(row.get('latency_ms', 0.)) <= 20.
                                           for row in controls[1:]))
    record = {'status': branch['status'], 'reason': branch.get('reason'), 'label': lab,
        'artifact': bank, 'controls_path': relative(path / 'CONTROL_RESULTS.json', out),
        'result_path': relative(path / 'RESULT.json', out), 'gamma': branch.get('gamma'),
        'counts': branch['counts'], 'events': evt, 'all_tick_deadline_pass': timely,
        'tick_latency_ms': [row.get('latency_ms') for row in controls],
        'progress0_04_m': branch.get('progress0_04_m'), 'progress02_04_m': branch.get('progress02_04_m'),
        'first_tau_matches_packet': branch.get('first_tau_matches_packet'),
        'application_state_match': branch.get('application_state_match'),
        'application_identity_pass': branch.get('application_identity_pass', True),
        'application_identity_error': branch.get('application_identity_error', branch.get('identity_error')),
        'application_state_comparison': branch.get('application_state_check'),
        'application_state_actual': branch.get('application_state_actual'),
        'application_state_prediction': branch.get('application_state_prediction'),
        'backup_memory_restore': branch.get('backup_memory_restore'),
        'same_packet_cost_not_independent_baseline': name.startswith('COUNTERFACTUAL'),
        'actual_horizon_origin': 'SAMPLE', 'actual_horizon_s': 1.}
    write(path / 'RESULT.json', record)
    return record


def current_events(branch, action):
    valid_rows=[row for row in branch['controls'] if row.get('valid_command') and
        all(row.get(key) is not None for key in ('tau_raw','tau_sent','tau_applied'))]
    result=events({**branch,'controls':valid_rows},action)
    invalid=[row for row in branch['controls'] if not row.get('valid_command')]
    result.update(control_rows=len(branch['controls']),applied_control_rows=len(valid_rows),
        rejected_unapplied_control_rows=len(invalid),
        rejected_raw_statuses=[row.get('solver_status_val') for row in invalid],
        invalid_commands_not_zero_filled=True)
    result['integral_frozen_slots']+=sum(bool(row.get('integral_record')) and
        not row['integral_record'].get('updated',False) for row in invalid)
    return result


def branch_once(out, directory, name, kernel, c, packet, budget, action=None, require_sent=True):
    event(out, 'START', kind=name, context_id=c['context_id'], method=packet['method'],
          gamma=packet.get('selected_gamma') if action is None else action['gamma'])
    branch = sim.propagate(kernel, c, packet, budget, purpose=name,
                           action=action, require_sent=require_sent)
    record = save_branch(out, directory, name, branch, c)
    event(out, 'RETURN', kind=name, context_id=c['context_id'], method=packet['method'],
          status=record['status'], counts=record.get('counts'), result_path=record['result_path'])
    budget.persist(phase='BRANCH_SAVED', context_id=c['context_id'], method=packet['method'], branch=name)
    if record['status'] == 'FAILED_BUDGET':
        raise SprintLimit('partial branch saved at numerical cap')
    if record.get('application_identity_error'):
        raise ValueError('saved application prediction/ACTUAL state identity mismatch')
    return record


def add_previous_identity(context, episode):
    state = context.get('state'); fact = context.get('healthy_fact')
    previous = next((r for r in episode['controls'] if r['tick'] == context['source_tick'] - 1), None)
    if not state or not fact or not previous:
        context['previous_command_identity'] = {'available': False, 'reason': 'SOURCE_PREVIOUS_CONTROL_MISSING'}
        context['eligible'] = False
        return
    tau = np.asarray(state['ctrl'], dtype=float)
    valid = bool(previous['valid_command'] and previous.get('candidate_valid') and previous['solver_status_val'] == 1 and tau.shape == (12,)
        and np.isfinite(tau).all() and np.array_equal(tau, previous['tau_sent']) and np.array_equal(tau, fact['tau_sent']))
    context['previous_tau_sent'] = tau.copy()
    context['previous_command_identity'] = {'available': valid, 'source': 'NEW_STEP35_REFERENCE_CANDIDATE',
        'episode_id': context['episode_id'], 'snapshot_id': context['snapshot_id'],
        'source_snapshot': context['source_snapshot'], 'source_tick': context['source_tick'],
        'previous_reference_tick': context['source_tick'] - 1, 'applied_previous_reference_tick': context['source_tick'] - 1,
        'source_time_s': context['source_time_s'], 'health_vector': [1.] * 12, 'source_health_vector': [1.] * 12,
        'source_solver_status_val': previous['solver_status_val'], 'source_candidate_valid': valid,
        'source_candidate_schema': previous.get('candidate_schema', (previous.get('candidate_certificate') or {}).get('schema')),
        'candidate_schema': previous.get('candidate_schema', (previous.get('candidate_certificate') or {}).get('schema')),
        'source_candidate_certificate': previous.get('candidate_certificate'),
        'tau_sent': tau, 'actual_state_ctrl_matches_healthy_fact_and_control': valid,
        'source_record_not_new_damaged_QP': True}
    if not valid:
        context['eligible'] = False; context['eligibility_reason'] = 'REFERENCE_CANDIDATE_IDENTITY_UNAVAILABLE'


def context_for(plan, snapshots, episode, mapping):
    snapshot = snapshots.get(plan['tick'], {'snapshot_id': plan['snapshot_id'], 'episode_id': plan['episode'],
        'source_tick': plan['tick'], 'direction': plan['direction'], 'eligible': False,
        'eligibility_reason': 'REFERENCE_INCOMPLETE'})
    context = source_context(snapshot, plan['health_kind'], mapping, plan['ordinal'], 'STEP35_FIXED')
    context.update(context_id=plan['context_id'], case_id=plan['context_id'], backup_id='STEP35-' + plan['context_id'],
        role=plan['role'], episode=plan['episode'], source_snapshot=plan['snapshot_id'], split=plan['split'],
        source_state_id=plan['source_state_id'], source_state_ordinal=plan['source_state_ordinal'],
        snapshot_ordinal=plan['snapshot_ordinal'], gap_m=plan['gap_m'],
        front_or_rear='front' if plan['direction'] > 0 else 'rear')
    if context['eligible']:
        add_previous_identity(context, episode)
    return context



def make_reference(out, model, manifest, episode_spec, ticks, budget):
    episode_id, displacement, seed = episode_spec
    scenario = deepcopy(manifest['scenario'])
    scenario.update(seed=seed, initial_roll=scenario['initial_roll'] - .002,
        initial_pitch=scenario['initial_pitch'] + .002)
    path = out / 'episodes' / (episode_id + '.json')
    if path.exists():
        episode = load_numeric(path)
        event(out, 'REUSED_SAVED_REFERENCE', kind='REFERENCE', episode=episode_id, additional_QP=0, additional_steps=0)
    else:
        event(out, 'START', kind='REFERENCE', episode=episode_id, displacement_m=displacement, seed=seed)
        episode = reference_episode(model, scenario, displacement, episode_id, ticks, budget, evidence_callback=budget.record_raw)
        save_numeric(path, episode)
        event(out, 'RETURN', kind='REFERENCE', episode=episode_id, status=episode['status'], counts=episode['counts'])
    budget.persist(phase='REFERENCE_SAVED', episode=episode_id)
    return episode, {row['source_tick']: row for row in episode['snapshots']}


class ReferencePrefixFailed(RuntimeError):
    pass


def run_cal(out, model, manifest, kernel, budget):
    records = []; registry = []
    for spec in CAL_EPISODES:
        episode, snapshots = make_reference(out, model, manifest, spec, (29, 35, 41), budget)
        if spec[0] == 'C35_P062' and not episode['prefix_gate']['passed']:
            raise ReferencePrefixFailed('four formal reference ticks did not pass original current rows/status1')
        for plan in plans('CAL'):
            if plan['episode'] != spec[0]:
                continue
            context = context_for(plan, snapshots, episode, manifest['mapping'])
            directory = out / 'CAL' / context['context_id']; directory.mkdir(parents=True, exist_ok=True)
            packet_path = directory / 'PACKET.json'
            if packet_path.exists():
                packet = load_numeric(packet_path)
            else:
                event(out, 'START', kind='CAL_COLLECTION', context_id=context['context_id'])
                packet = kernel.collect_actions(context, budget, method=METHODS[0]) if context['eligible'] else {
                    'status': 'SOURCE_INELIGIBLE', 'method': METHODS[0], 'actions': {}, 'prehold': {}}
                kernel.flush_raw_evidence()
                save_numeric(packet_path, packet)
                event(out, 'RETURN', kind='CAL_COLLECTION', context_id=context['context_id'], status=packet['status'])
            for gamma in GAMMA_GRID:
                entry = packet['actions'].get(str(gamma), packet['actions'].get(gamma_key(gamma), {}))
                action = entry.get('action'); name = 'G' + gamma_key(gamma)
                result_path = directory / name / 'RESULT.json'
                if result_path.exists():
                    branch = read(result_path)
                elif (directory / name / 'actual.npz').exists():
                    branch=save_branch(out,directory,name,load_bank(directory / name / 'actual.npz'),context)
                    event(out,'RECOVERED_SAVED_CAL_RESULT',kind=name,context_id=context['context_id'],additional_QP=0,additional_steps=0)
                elif action and action.get('command_valid') and action.get('execution_eligible'):
                    if packet.get('step34_solver_owner') != kernel.solver_owner_identity():
                        branch=save_branch(out,directory,name,{'status':'NOT_RUN','reason':'PRIOR_OWNER_PACKET_UNEXECUTED_RESULT_MISSING_NO_RESOLVE'},context)
                    else:
                        branch = branch_once(out, directory, name, kernel, context, packet, budget,
                                             action=action, require_sent=False)
                else:
                    branch = save_branch(out, directory, name, {'status': 'NOT_RUN',
                        'reason': (action or {}).get('unavailable_reason', 'SOURCE_OR_ACTION_UNAVAILABLE')}, context)
                item = {'schema': 'STEP35_MATCHED_BOUNDED_CANDIDATE_CAL_V1',
                    'id': context['context_id'] + ':G' + gamma_key(gamma), 'context': context, 'split': 'CAL',
                    'method': METHODS[0], 'gamma': gamma, 'role': context['role'], 'episode': context['episode'],
                    'source_snapshot': context['source_snapshot'], 'features26': entry.get('features26'),
                    'prefix': entry.get('prefix'), 'prehold': packet.get('prehold'), 'labels': branch['label'],
                    'first_command_valid': bool(action and action.get('command_valid')),
                    'target_horizon_origin': 'SAMPLE', 'target_horizon_s': 1., 'teacher_100ms_used': False}
                record_path = directory / (name + '_CAL_RECORD.json')
                if record_path.exists():
                    item = read(record_path)
                else:
                    write(record_path, item)
                records.append(item)
                registry.append({'id': item['id'], 'path': relative(record_path, out), 'context_id': context['context_id'],
                    'gamma': gamma, 'role': context['role'], 'episode': context['episode'],
                    'source_snapshot': context['source_snapshot'], 'status': branch['status'],
                    'complete': branch['label'].get('complete', False), 'branch_result': branch['result_path'],
                    'packet_path': relative(packet_path, out)})
                write(out / 'CAL_REGISTRY.json', registry)
            budget.persist(phase='CAL', contexts_processed=plan['ordinal'] + 1, actions_processed=len(registry))
            print({'phase': 'CAL', 'contexts_processed': plan['ordinal'] + 1, 'actions_processed': len(registry),
                'budget': budget.snapshot()}, flush=True)
            gc.collect()
    return records


def run_test(out, model, manifest, kernels, bundle, budget, readiness):
    registry = [{**plan, 'status': 'NOT_RUN', 'result_path': relative(out / 'queue' / plan['context_id'] / 'RESULT.json', out)} for plan in plans('TEST')]
    write(out / 'QUEUE_REGISTRY.json', registry)
    diagnostic_ids = {row['context_id'] for row in [p for p in plans('TEST') if p['role'] == 'calf'][:4]}
    diagnostics = []; shadow_states = set(); shadow_calls = 0
    for spec in TEST_EPISODES:
        episode, snapshots = make_reference(out, model, manifest, spec, (31, 39), budget)
        for plan in plans('TEST'):
            if plan['episode'] != spec[0]:
                continue
            context = context_for(plan, snapshots, episode, manifest['mapping'])
            directory = out / 'queue' / context['context_id']; directory.mkdir(parents=True, exist_ok=True)
            result = {'context': context, 'plan': plan, 'context_id': context['context_id'], 'methods': {},
                'status': 'IN_PROGRESS' if readiness else 'NOT_RUN', 'shadow_path': None}
            write(directory / 'RESULT.json', result)
            if not readiness:
                if plan['context_id'] in diagnostic_ids:
                    for method in plan['method_order']:
                        packet = kernels[method].endpoint_diagnostic(context, budget, method=method) if context['eligible'] else {'status': 'SOURCE_INELIGIBLE', 'actions': {}}
                        kernels[method].flush_raw_evidence()
                        path = out / 'diagnostics' / context['context_id'] / method / 'PACKET.json'
                        asset = save_numeric(path, packet)
                        diagnostics.append({'context_id': context['context_id'], 'source_state_id': context['source_state_id'],
                            'ordinal': plan['ordinal'], 'method': method, 'status': packet['status'],
                            'numeric': asset, 'selected_command_sent': False, 'ACTUAL_runs': 0})
                        write(out / 'ENDPOINT_DIAGNOSTICS.json', diagnostics)
                        budget.persist(phase='ENDPOINT_DIAGNOSTIC', processed=len(diagnostics))
                registry[plan['ordinal']].update(reason='CALIBRATION_NOT_READY')
                write(out / 'QUEUE_REGISTRY.json', registry)
                continue
            for method in plan['method_order']:
                d = directory / method; d.mkdir(exist_ok=True)
                event(out, 'START', kind='ONLINE', context_id=context['context_id'], method=method,
                      source_state_id=context['source_state_id'], ordinal=plan['ordinal'], gap_m=context['gap_m'])
                packet = kernels[method].governor(context, bundle, context['gap_m'], budget, method) if context['eligible'] else {
                    'status': 'SOURCE_INELIGIBLE', 'method': method, 'selected_command_sent': False,
                    'selected_gamma': None, 'actions': {}, 'context_id': context['context_id']}
                kernels[method].flush_raw_evidence()
                asset = save_numeric(d / 'ONLINE_NUMERIC.json', packet)
                method_result = {'status': packet['status'], 'selected_sent': bool(packet.get('selected_command_sent')),
                    'selected_gamma': packet.get('selected_gamma'), 'command_ready_ms': packet.get('command_ready_ms'),
                    'online_numeric_path': relative(d / 'ONLINE_NUMERIC.json', out), 'numeric': asset, 'branches': {}}
                result['methods'][method] = method_result
                event(out, 'RETURN', kind='ONLINE', context_id=context['context_id'], method=method,
                    status=packet['status'], selected_sent=method_result['selected_sent'], gamma=method_result['selected_gamma'])
                write(directory / 'RESULT.json', result)
                if method_result['selected_sent']:
                    branch = branch_once(out, d, 'ACTUAL', kernels[method], context, packet, budget)
                    method_result['branches']['ACTUAL'] = branch
                    write(directory / 'RESULT.json', result)
                    middle = method_result['selected_gamma'] in (.75, .5, .25)
                    if method == METHODS[0] and middle:
                        workspace = prepare_shared(packet['context_used'], packet.get('C'), packet.get('B'))
                        for endpoint, gamma in (('C', 1.), ('B', 0.)):
                            action = make_action(packet['context_used'], packet.get('C'), packet.get('B'), gamma, workspace=workspace)
                            name = 'COUNTERFACTUAL_' + endpoint
                            if action.get('command_valid'):
                                cf = branch_once(out, d, name, kernels[method], context, packet, budget, action=action)
                            else:
                                cf = save_branch(out, d, name, {'status': 'NOT_RUN', 'reason': 'SAME_PACKET_ENDPOINT_UNAVAILABLE'}, context)
                            method_result['branches'][name] = cf
                            write(directory / 'RESULT.json', result)
                        if branch['status'] != 'NOT_RUN' and context['source_state_id'] not in shadow_states and shadow_calls < 32:
                            shadow = kernels[method].shadow(context, packet, budget)
                            numeric = save_numeric(d / 'CAPACITY_SHADOW_NUMERIC.json', shadow)
                            calls = sum((shadow.get(endpoint) or {}).get('new_QP_calls', 0) for endpoint in ('C', 'B'))
                            shadow_calls += calls; shadow_states.add(context['source_state_id'])
                            if shadow_calls > 32:
                                raise ValueError('STEP35 shadow count exceeded fixed32 contract')
                            write(d / 'CAPACITY_SHADOW_RESULT.json', {'status': shadow['status'], 'numeric': numeric,
                                'context_id': context['context_id'], 'source_state_id': context['source_state_id'], 'new_QP_calls': calls,
                                'same_packet_not_actuated': True})
                            result['shadow_path'] = relative(d / 'CAPACITY_SHADOW_RESULT.json', out)
                event(out, 'DONE', kind='TEST_CONTEXT_METHOD', context_id=context['context_id'], method=method)
                write(directory / 'RESULT.json', result)
                budget.persist(phase='TEST_METHOD', context_id=context['context_id'], method=method)
            result['status'] = 'DONE'; write(directory / 'RESULT.json', result)
            registry[plan['ordinal']].update(status='DONE', eligible=bool(context['eligible']))
            write(out / 'QUEUE_REGISTRY.json', registry)
            budget.persist(phase='TEST', processed=plan['ordinal'] + 1)
            print({'phase': 'TEST', 'processed': plan['ordinal'] + 1,
                   'sent': {m: row['selected_sent'] for m, row in result['methods'].items()}, 'budget': budget.snapshot()}, flush=True)
            gc.collect()


def run(run_id=RUN_ID, repair=False):
    out = output(run_id)
    if repair and ((read(out / 'REFERENCE_PREFIX.json', {}).get('passed') and
                    not (out / 'episodes/C35_P062.json').exists()) or
                   read(out / 'RUN_FINISHED.json', {}).get('status') == 'REFERENCE_PRECISION_FIX_NOT_ESTABLISHED'):
        raise ValueError('STEP35 cannot restart a passed prefix or retry a failed scientific prefix')
    if (out / 'RUN_STARTED.json').exists() and not repair:
        raise FileExistsError('unique STEP35 numerical batch already attempted')
    for name in ('TRAIN', 'CAL', 'models', 'queue', 'episodes', 'figures'):
        (out / name).mkdir(parents=True, exist_ok=True)
    budget = SprintBudget.resume_dev_repair(out) if repair else SprintBudget(out)
    budget.start(); status = 'COMPLETED'
    try:
        source = read(SOURCE34 / 'MANIFEST.json'); model = frozen.load_model()
        limits = extract_healthy_torque_limits(model)
        mapping = [dict(r, healthy_limit_nm=float(limits[r['actuator_index']])) for r in extract_actuator_audit(model)]
        dll = SOURCE30 / 'native/step30_prefix.dll'
        manifest = {'run_id': run_id, 'source_commit': PARENT, 'source_model': 'FROZEN_STEP34_TRAINED_ONLY', 'reference_eps_abs':1e-8, 'reference_eps_rel':1e-8, 'injured_eps_abs':1e-7, 'injured_eps_rel':1e-7,
            'scenario': source['scenario'], 'frozen_physical': source['frozen_physical'], 'mapping': mapping,
            'methods': METHODS, 'CAL': plans('CAL'), 'TEST': plans('TEST'), 'CAL_episodes': CAL_EPISODES,
            'TEST_episodes': TEST_EPISODES, 'gaps_m': GAPS, 'TEST_source_states': 16,
            'first_four_calf_diagnostic_ids': [p['context_id'] for p in plans('TEST') if p['role'] == 'calf'][:4],
            'max_QP': 25000, 'max_steps': 250000, 'max_wall_s': 5400,
            'regression_fit_limit': 0, 'risk_fit_limit': 0, 'first_C_B_QP_s': .003, 'feedback_QP_s': .006,
            'deadline_ms': 20, 'horizon_s': 1., 'physics_dt_s': .002, 'prehold_s': .020,
            'native_dll_path': str(dll), 'native_dll_sha256': sha(dll), 'protocol_sha256': sha(PROTOCOL),
            'original_HEAD_not_reset': True, 'historical_status_not_rejudged': True, 'no_E3_RL_hardware': True,
            'date': '2026-10-09', 'timezone': 'Asia/Seoul'}
        if not repair:
            write(out / 'MANIFEST.json', manifest)
            write(out / 'RUN_STARTED.json', {'pid': os.getpid(), 'start_utc': datetime.now(timezone.utc).isoformat(),
                'run_id': run_id, 'numerical_clock_includes_preparation': True})
        model_path = SOURCE34 / 'models/step34_trained_only.npz'
        metadata_path = model_path.with_suffix('.json')
        if not model_path.exists() or not metadata_path.exists():
            raise FileNotFoundError('STEP35_PREPARATION_MISSING_SOURCE_TRAINED_MODEL_NO_FIT_FALLBACK')
        trained = load_bundle(model_path)
        write(out / 'MODEL_LOAD.json', {'npz':str(model_path),'json':str(metadata_path),
            'npz_sha256':sha(model_path),'json_sha256':sha(metadata_path),
            'predictor_identity':identity(trained),'new_regression_fits':0,'new_risk_fits':0,
            'loaded_trained_only_not_empty_CAL':True,'new_CAL_required':True})
        write(out / 'QUEUE_REGISTRY.json', [{**p,'status':'NOT_RUN'} for p in plans('TEST')])
        write(out / 'CAL_PLAN_REGISTRY.json', [{**p,'status':'NOT_RUN'} for p in plans('CAL')])
        kernel = Kernel(model, 'BOUNDED', str(dll), budget)
        online = {m: Kernel(model, 'BOUNDED', str(dll), budget) for m in METHODS}
        home = home_context(model, manifest['scenario']); home.update(context_id='STEP35_HOME', backup_id='STEP35_HOME')
        start = perf_counter()
        write(out / ('repairs/STARTUP_REPAIR.json' if repair else 'STARTUP.json'), {
            'CAL': kernel.startup(home, budget), 'online': {m: k.startup(home, budget) for m, k in online.items()},
            'wall_ms': (perf_counter() - start) * 1000., 'owner_workspaces_independent': True})
        kernel.flush_raw_evidence()
        for instance in online.values():
            instance.flush_raw_evidence()
        cal_records = run_cal(out, model, manifest, kernel, budget)
        bundle = build_calibration(trained, cal_records)
        bundle['calibration_id'] = 'STEP35_NEW_BOUNDED_FEAS_CAL_V1'
        asset = save_bundle(bundle, out / 'models', stem='step35_application_model_cal')
        readiness = any(group['local_calibrated'] for key, group in bundle['groups'].items()
            if float(key.split(':')[0]) in (.75, .5, .25) and key.split(':')[1] in ('thigh', 'calf'))
        runtime = [*ROOT.glob('cavr_wbc/control/step35_*.py'),
            *[p for p in ROOT.glob('cavr_wbc/experiments/step35_*.py') if not any(w in p.name for w in ('report', 'figures', 'verify', 'delivery'))],
            *ROOT.glob('tests/test_step35*.py')]
        write(out / 'STEP35_FREEZE.json', {'freeze_count': 1, 'config': manifest, 'model_CAL_assets': asset,
            'predictor_identity_before_CAL': identity(trained), 'predictor_identity_after_CAL': identity(bundle),
            'CAL_ids': [r['id'] for r in cal_records], 'TEST_read_for_fit_or_CAL': False,
            'readiness_branch': 'FULL_FIXED_PANEL' if readiness else 'CALIBRATION_NOT_READY',
            'one_readiness_check': True, 'new_runtime_sha256': {relative(p, ROOT): sha(p) for p in runtime},
            'frozen_utc': datetime.now(timezone.utc).isoformat()})
        budget.persist(phase='MODEL_CAL_FROZEN', readiness_branch='FULL_FIXED_PANEL' if readiness else 'CALIBRATION_NOT_READY')
        del cal_records
        run_test(out, model, manifest, online, bundle, budget, readiness)
    except ReferencePrefixFailed as exc:
        status = 'REFERENCE_PRECISION_FIX_NOT_ESTABLISHED'
        write(out / 'STOP_REASON.json', {'reason':str(exc),'no_other_seven_references_or_panel_started':True,'budget':budget.snapshot()})
    except SprintLimit as exc:
        status = 'INCOMPLETE_BUDGET'
        write(out / 'INTERRUPTION.json', {'type': 'BUDGET', 'error': str(exc), 'budget': budget.snapshot()})
    except BaseException as exc:
        status = 'STOPPED_IMPLEMENTATION_OR_RESOURCE'
        write(out / 'INTERRUPTION.json', {'type': type(exc).__name__, 'error': str(exc),
            'traceback': traceback.format_exc(), 'budget': budget.snapshot()})
        raise
    finally:
        budget.event('NUMERICAL_FINISHED', status=status, **budget.snapshot()); budget.close()
        write(out / 'RUN_FINISHED.json', {'run_id': run_id, 'status': status, 'budget': budget.snapshot(),
            'finish_utc': datetime.now(timezone.utc).isoformat()})
        print({'status': status, 'budget': budget.snapshot()}, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('run_id', nargs='?', default=RUN_ID)
    parser.add_argument('--dev-engineering-repair', action='store_true')
    args = parser.parse_args(); run(args.run_id, args.dev_engineering_repair)
