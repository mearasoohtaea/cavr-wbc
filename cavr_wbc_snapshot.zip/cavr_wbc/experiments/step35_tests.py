"""One five-class necessary fixture suite; no historical suites/numerical work."""
import sys
import unittest
from datetime import datetime,timezone
from cavr_wbc.experiments.step35_io import ROOT,output,write

def run(targeted=False,state_restore=False):
    out=output()/'tests';out.mkdir(parents=True,exist_ok=True)
    stem='TARGETED_STATE_RESTORE' if state_restore else 'TARGETED_PRECISION_FIXTURE' if targeted else 'NECESSARY_TESTS'
    path=out/(stem+'.log')
    if path.exists():
        raise FileExistsError('STEP35 necessary fixture suite already attempted')
    start=datetime.now(timezone.utc).isoformat()
    suite=(unittest.defaultTestLoader.loadTestsFromName('tests.test_step35_protocol.ProtocolFixtures.test_3_formal_four_tick_checkpoint_continues_same_live_objects_without_restart')
           if state_restore else unittest.defaultTestLoader.loadTestsFromName('tests.test_step35_protocol.ProtocolFixtures.test_1_reference_and_injured_precision_owner_isolation_before_setup')
           if targeted else unittest.defaultTestLoader.discover(str(ROOT/'tests'),pattern='test_step35*.py'))
    with path.open('x',encoding='utf-8') as stream:
        result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    write(out/(stem+'.json'),{'command':'python -B -X utf8 -m cavr_wbc.experiments.step35_tests'+(' --targeted-state-restoration' if state_restore else ' --targeted-precision-fixture' if targeted else ''),
        'tests_run':result.testsRun,'errors':len(result.errors),'failures':len(result.failures),
        'successful':result.wasSuccessful(),'start_utc':start,'finish_utc':datetime.now(timezone.utc).isoformat(),
        'fixture_only':True,'new_QP_calls':0,'new_physics_steps':0,'new_model_fits':0,
        'five_classes':['precision isolation','raw/CSC readback','reference restoration/identity',
                        'samepacket/timeaxis','source model load fit0']})
    print(path.read_text(encoding='utf-8'),flush=True)
    return 0 if result.wasSuccessful() else 1

if __name__=='__main__':
    sys.exit(run('--targeted-precision-fixture' in sys.argv,'--targeted-state-restoration' in sys.argv))
