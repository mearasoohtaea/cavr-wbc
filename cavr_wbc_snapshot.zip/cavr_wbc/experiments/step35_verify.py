"""One STEP35 current-file readback; no solves/steps/fits/history audit."""
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
from cavr_wbc.experiments.step35_io import output,ROOT,SOURCE34,read,write,sha,load_numeric
from cavr_wbc.experiments.step33_report import jsonl_rows
from cavr_wbc.control.step34_margin import load_bundle,identity


def run():
    out=output();dest=out/'tests/CURRENT_DELIVERY_CHECK.json'
    if dest.exists():
        raise FileExistsError('STEP35 current readback check already attempted')
    checks=[]
    def check(name,value,detail=None):
        checks.append({'name':name,'condition_met':bool(value),'detail':detail})
    result=read(out/'STEP35_RESULT.json');finish=read(out/'RUN_FINISHED.json');budget=finish['budget']
    freeze=read(out/'STEP35_FREEZE.json');load=read(out/'MODEL_LOAD.json');manifest=read(out/'MANIFEST.json')
    tests=read(out/'tests/NECESSARY_TESTS.json');fix1=read(out/'tests/TARGETED_PRECISION_FIXTURE.json');fix2=read(out/'tests/TARGETED_STATE_RESTORE.json')
    check('five_class_fixture_once_failure_preserved_targeted_only',tests['tests_run']==5 and tests['errors']==1 and tests['failures']==0 and fix1['successful'] and fix2['successful'] and
        fix1['tests_run']==fix2['tests_run']==1 and tests['new_QP_calls']==fix1['new_QP_calls']==fix2['new_QP_calls']==0)
    trained=load_bundle(Path(load['npz']));cal=load_bundle(out/'models/step35_application_model_cal.npz')
    check('source_trained_model_only_identity_fit_zero',sha(load['npz'])==load['npz_sha256'] and sha(load['json'])==load['json_sha256'] and
        identity(trained)==load['predictor_identity']==freeze['predictor_identity_before_CAL']==freeze['predictor_identity_after_CAL']==identity(cal) and
        budget['multioutput_estimator_fits']==budget['physical_risk_head_fits']==0)
    source=read(SOURCE34/'MANIFEST.json')
    check('current_model_native_and_final_runtime_identity',all(sha(ROOT/path)==digest for path,digest in source['frozen_physical']['model_files_sha256'].items()) and
        sha(manifest['native_dll_path'])==manifest['native_dll_sha256'] and
        all(sha(ROOT/path)==digest for path,digest in freeze['new_runtime_sha256'].items()))
    prefix=read(out/'REFERENCE_PREFIX.json');first=load_numeric(out/'episodes/C35_P062.json')
    check('formal_four_tick_checkpoint_same_owner_not_restarted',prefix['passed'] and prefix['actual_physics_steps']==40 and
        abs(prefix['actual_time_s']-.08)<=1e-9 and not prefix['prefix_restarted'] and all(prefix['checks'].values()) and
        first['prefix_gate']['continued_same_owner_after_pass'] and first['counts']['control_qp_calls']==110)
    episodes=[load_numeric(path) for path in sorted((out/'episodes').glob('*.json'))]
    check('all_eight_complete_references_original_status1_and_single_generation',len(episodes)==8 and
        all(ep['status']=='COMPLETE' and ep['counts']['physical_steps']==1100 and len(ep['controls'])==110 and
            all(row['solver_status_val']==1 and row['reference_apply_valid'] for row in ep['controls']) for ep in episodes) and budget['QP_by_kind']['REFERENCE']==880)
    ledger=list(jsonl_rows(out/'STEP35_LEDGER.jsonl'));starts=Counter(r['global_qp_index'] for r in ledger if r['event']=='QP_START')
    returned=[r for r in ledger if r['event']=='QP_RETURN'];saved=[r for r in ledger if r['event']=='RAW_QP_SAVED']
    raw_paths=sorted((out/'raw_qp').glob('QP*.json'));rows=[]
    for path in raw_paths:
        record=load_numeric(path);raw=record['raw_result'];problem=raw.get('step34_problem')
        rows.append({'index':record['global_qp_index'],'kind':record['kind'],'owner':record['owner'],
            'eps_abs':raw.get('actual_setup_eps_abs'),'eps_rel':raw.get('actual_setup_eps_rel'),
            'limit':raw.get('osqp_time_limit_s'),'raw_status':raw.get('status_val'),
            'full':problem is not None and raw.get('full_current_raw_x') is not None,
            'certificate':raw.get('candidate_certificate')})
    indices=Counter(r['index'] for r in rows)
    check('every_real_call_one_return_and_lossless_raw_CSC_from_startup',starts==Counter(r['global_qp_index'] for r in returned)==indices==Counter(r['global_qp_index'] for r in saved) and
        len(rows)==budget['total_QP_calls']==1936 and all(v==1 for v in indices.values()) and all(r['full'] for r in rows))
    reference=[r for r in rows if r['kind']=='REFERENCE'];injured=[r for r in rows if r['kind']!='REFERENCE']
    check('actual_setup_reference1e8_injured1e7_caps_isolated',len(reference)==880 and
        all(r['eps_abs']==r['eps_rel']==1e-8 and r['limit']==.006 for r in reference) and
        all(r['eps_abs']==r['eps_rel']==1e-7 and r['limit'] in (.003,.006) for r in injured))
    check('cumulative_clock_budget_and_two_DEV_repairs_preserved',budget['total_QP_calls']<=25000 and budget['total_physics_steps']<=250000 and
        budget['numerical_elapsed_s']<=5400 and budget['numerical_started_utc']=='2026-10-09T07:20:12.290472+00:00' and
        budget['unknown_native_returns']==budget['uncompleted_native_step_reservations']==0 and
        len(list((out/'repairs').glob('REPAIR_*_STARTED.json')))==2 and
        (out/'repairs/attempt01_invalid_state_restore/STEP35_FREEZE.json').exists())
    records=read(out/'CAL_REGISTRY.json');queue=read(out/'QUEUE_REGISTRY.json');diag=read(out/'ENDPOINT_DIAGNOSTICS.json')
    check('CAL120_retains_complete_partial_unavailable_and_original_minimum',len(records)==120 and
        Counter(r['status'] for r in records)==Counter({'COMPLETE':18,'FAILED_NUMERICAL':37,'NOT_RUN':65}) and
        all(not g['local_calibrated'] for k,g in cal['groups'].items() if float(k.split(':')[0]) in (.75,.5,.25)))
    check('one_valid_freeze_diagnostic_branch_no_formal_test_or_fake_actual',freeze['freeze_count']==1 and freeze['readiness_branch']=='CALIBRATION_NOT_READY' and
        len(queue)==48 and all(r['status']=='NOT_RUN' for r in queue) and len({r['source_state_id'] for r in queue})==16 and
        len(diag)==8 and result['observed_formal_online_decisions']==result['actual_runs']==0 and all(r['ACTUAL_runs']==0 for r in diag))
    qa=read(out/'figures/FIGURE_QA.json')
    check('one_reviewed_real_data_figure_no_empty_event_decoration',qa['figure_count']==1 and qa['AI_visual_review']=='REVIEWED' and not qa['missing_glyph_warnings'] and
        all(not v['text_outside_canvas'] and not v['adjacent_tick_overlaps'] and v['minimum_visible_font_pt']>=8 for v in qa['programmatic'].values()))
    try:
        from pypdf import PdfReader
    except ImportError:
        from PyPDF2 import PdfReader
    fonts=[]
    for page in PdfReader(str(out/'figures/STEP35_full_results.pdf')).pages:
        for ref in page['/Resources']['/Font'].values():
            font=ref.get_object()
            for child_ref in font.get('/DescendantFonts') or [font]:
                child=child_ref.get_object();desc=child.get('/FontDescriptor');desc=desc.get_object() if desc else {}
                stream=desc.get('/FontFile2');fonts.append({'font':str(child.get('/BaseFont')),'bytes':len(stream.get_object().get_data()) if stream else 0})
    check('PDF_descendant_TrueType_embedded',bool(fonts) and all(r['bytes']>0 for r in fonts),fonts)
    document={'command':'python -B -X utf8 -m cavr_wbc.experiments.step35_verify','checks':checks,
        'check_count':len(checks),'conditions_met':sum(r['condition_met'] for r in checks),
        'current_delivery_consistent':all(r['condition_met'] for r in checks),'not_scientific_A_B_C_PASS':True,
        'scientific_status':result['SCIENTIFIC_RUN_STATUS'],'reference_status':result['REFERENCE_PRECISION_STATUS'],
        'new_QP_calls':0,'new_physics_steps':0,'new_model_fits':0,'checked_utc':datetime.now(timezone.utc).isoformat(),
        'scope':'CURRENT_FILES_AND_SOURCE_MODEL_ONLY_NO_HISTORICAL_SOLVE_AUDIT'}
    write(dest,document);print(document)
    return document


if __name__=='__main__':
    run()
