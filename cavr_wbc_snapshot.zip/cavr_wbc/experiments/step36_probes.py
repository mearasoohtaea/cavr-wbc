"""Stable saved-CAL probe plan and three single-call numerical experiments."""
from pathlib import Path
import argparse
import numpy as np
from cavr_wbc.experiments.step36_io import *
from cavr_wbc.control.step34_candidate import check_candidate
FRICTION_ROWS = tuple(60+5*f+k for f in range(4) for k in range(4))
PROBE_KINDS = ('FIRST_B_STATUS8_REJECTED','FEEDBACK_FRICTION_ONLY_UNPOLISHED','FEEDBACK_FRICTION_ONLY_POLISHED')

def select_plan():
    registry = read(SOURCE35/'CAL_REGISTRY.json')
    found = {k: [] for k in PROBE_KINDS}
    for rel in sorted({r['packet_path'] for r in registry}):
        packet=load_numeric(SOURCE35/rel)
        raw=packet['B'].get('raw_solver_result',packet['B'].get('wbc',{}))
        if raw.get('status_val')==8 and not raw.get('candidate_valid'):
            found[PROBE_KINDS[0]].append((raw['step35_global_qp_index'],rel))
    for row in registry:
        path=(SOURCE35/row['branch_result']).parent/'CONTROL_RESULTS.json'
        if not path.exists(): continue
        controls=load_numeric(path)['controls']
        for control in controls:
            if control.get('source') not in ('PREHOLD','PACKET_SELECTED'):
                raw=control.get('raw_solver_result') or {}
                proof=raw.get('candidate_certificate') or {}
                failed=set()
                for name in ('raw_hard_check','sent_hard_check'):
                    failed.update((proof.get(name) or {}).get('failed_row_indices',[]))
                if (raw.get('status_val')==1 and proof.get('candidate_valid') is False and failed and
                    failed <= set(FRICTION_ROWS) and proof.get('raw_capacity_exact_pass') and proof.get('sent_capacity_exact_pass')):
                    key=PROBE_KINDS[2] if raw.get('polish_status')==1 else PROBE_KINDS[1]
                    found[key].append((raw['step35_global_qp_index'],relative(path,SOURCE35)))
    entries=[]
    for key in PROBE_KINDS:
        if not found[key]: raise ValueError('fixed saved CAL probe absent: '+key)
        index, evidence=min(found[key])
        rawpath=SOURCE35/'raw_qp'/f'QP{index:06d}.json'
        raw=load_numeric(rawpath)['raw_result']
        entries.append({'probe_kind':key,'source_global_qp_index':index,'source_raw_path':str(rawpath),
            'source_raw_sha256':sha(rawpath),'source_numeric_sha256':sha(rawpath.with_suffix('.npz')),
            'source_CAL_evidence':evidence,'old_raw_status':raw['status_val'],'old_polish_status':raw['polish_status'],
            'old_original_candidate_valid':raw['candidate_valid']})
    return {'schema':'STEP36_FIXED_DEV_PROBE_PLAN_V1','source_commit':PARENT,'selection':'FIRST_GLOBAL_INDEX_FROM_FINAL_VALID_CAL_ONLY',
        'probes':entries,'changed_rows':FRICTION_ROWS,'working_upper_N':-1e-4,'limit_s':.006,'eps_abs_rel':1e-7,
        'new_calls_planned':3,'new_integration_steps':0,'source_TEST_or_invalid_attempt_used':False}

def prepare(run_id=RUN_ID):
    out=output(run_id)
    if out.exists(): raise FileExistsError('STEP36 first artifact must be unique frozen probe plan')
    plan=select_plan()
    write(out/'PROBE_PLAN.json',plan)
    print(plan)

def run_probes(model,out,budget):
    from cavr_wbc.control.step36_kernel import WorkingWBC
    rows=[]
    for plan in read(out/'PROBE_PLAN.json')['probes']:
        old=load_numeric(plan['source_raw_path'])['raw_result']
        matrix=old['source_matrices']; context={'context_id':matrix['context_id'],'health_vector':matrix['health_vector'],
            'state':{key:matrix[key] for key in ('qpos','qvel','integration_state')}}
        owner=WorkingWBC(model); owner.solver_time_limit_s=.006
        owner.evidence_budget=budget
        owner.working_row_units=matrix['row_units']
        owner.solve_callback=budget.qp_callback('DEV_NUMERICAL_REPAIR_PROBE',plan['probe_kind'])
        raw=owner._invoke(old['step34_problem'],'DEV_NUMERICAL_REPAIR_PROBE')
        proof=check_candidate(raw,matrix,context)
        raw.update(candidate_certificate=proof,candidate_valid=proof['candidate_valid'],source_matrices=matrix,
            full_current_raw_x=raw.get('x'),probe_source=plan,kind='DEV_NUMERICAL_REPAIR_PROBE')
        asset=budget.record_raw(raw,'DEV_NUMERICAL_REPAIR_PROBE',plan['probe_kind'])
        rows.append({**plan,'new_raw_status':raw['status_val'],'new_polish_status':raw['polish_status'],
            'original_candidate_valid':proof['candidate_valid'],'rejection_reason':proof['rejection_reason'],
            'raw_failed_rows':(proof.get('raw_hard_check') or {}).get('failed_row_indices'),
            'sent_failed_rows':(proof.get('sent_hard_check') or {}).get('failed_row_indices'),'new_numeric':asset,
            'new_QP_calls':1,'new_steps':0,'one_second_recovery_claim':False})
        write(out/'PROBE_RESULTS.json',rows)
    established=any(r['original_candidate_valid'] for r in rows[1:])
    write(out/'INTERIOR_NUMERICAL_REPAIR.json',{'established':established,'status':'INTERIOR_NUMERICAL_REPAIR_ESTABLISHED' if established else 'INTERIOR_NUMERICAL_REPAIR_NOT_ESTABLISHED',
        'B_probe_valid':rows[0]['original_candidate_valid'],'friction_only_probe_valid':[r['original_candidate_valid'] for r in rows[1:]],
        'original_acceptance_extra_slack':0,'new_steps':0})
    return established

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('run_id',nargs='?',default=RUN_ID);prepare(parser.parse_args().run_id)
