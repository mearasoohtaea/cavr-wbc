"""Saved-only STEP36 stop-gate analysis: plans are not observed trajectories."""
from collections import Counter
import numpy as np
from cavr_wbc.experiments.step36_io import *
from cavr_wbc.experiments.step36_sprint import plans,FALLBACK_IDS
from cavr_wbc.experiments.step33_report import csv_write,jsonl_rows

PROTOCOL_LINES="""AUTHORIZE_STEP36_INTERIOR_WORKING_QP_AND_RUN = TRUE
NEW_MODEL_FITS = 0
NEW_REFERENCE_SOLVES = 0
NEW_REFERENCE_INTEGRATION_STEPS = 0
WORKING_FRICTION_UPPER_N = -1e-4
WORKING_CHANGED_FRICTION_ROWS = 16
ORIGINAL_FRICTION_ACCEPTANCE_UPPER_N = 0
ORIGINAL_INEQUALITY_EXTRA_SLACK = 0
SOLVER_EPS_ABS_REL = 1e-7
FIRST_B_QP_LIMIT_UPPER_S = 0.006
FIRST_C_QP_LIMIT_UPPER_S = 0.003
FEEDBACK_QP_LIMIT_UPPER_S = 0.006
DEADLINE_MS = 20
CAL_CONTEXTS = 24
CAL_ACTION_SLOTS = 120
TEST_SOURCE_STATES = 16
TEST_PLANNED_INPUTS = 48
TEST_GAPS_MM = 4,6,8
FALLBACK_OFFLINE_SOURCE_STATES = 4
FALLBACK_OFFLINE_MAX_BRANCHES = 12
MAX_NEW_QP_CALLS = 25000
MAX_NEW_PHYSICS_STEPS = 250000
MAX_NUMERICAL_WALL_MINUTES = 90
MAX_DEV_IMPLEMENTATION_REPAIRS = 2
TEST_RESULT_BASED_RETRY = FALSE
HISTORICAL_RESULTS_UNCHANGED = TRUE
E3_RL_HARDWARE = NOT_AUTHORIZED"""

def dump(out,name,rows):
    write(out/(name+'.json'),rows);csv_write(out/(name+'.csv'),rows)

def summarize(run_id=RUN_ID):
    out=output(run_id);finished=read(out/'RUN_FINISHED.json');gate=read(out/'INTERIOR_NUMERICAL_REPAIR.json')
    if gate['established']:raise ValueError('stop-gate report must not fabricate later panel evidence')
    probes=[];failures=[];constraints=[];latency=[]
    for row in read(out/'PROBE_RESULTS.json'):
        saved=load_numeric(row['new_numeric']['json']);raw=saved['raw_result'];proof=raw['candidate_certificate']
        old=load_numeric(row['source_raw_path'])['raw_result'];m=raw['source_matrices']
        indices=raw['step36_working_changed_rows'];az=m['A']@raw['full_current_raw_x']
        margins=m['health_vector']*m['healthy_torque_limits_nm']-np.abs(proof['tau_raw'])
        new={'probe_kind':row['probe_kind'],'source_global_qp_index':row['source_global_qp_index'],
            'new_global_qp_index':saved['global_qp_index'],'old_raw_status':old['status_val'],'new_raw_status':raw['status_val'],
            'old_polish_status':old['polish_status'],'new_polish_status':raw['polish_status'],
            'original_candidate_valid':proof['candidate_valid'],'raw_capacity_exact_pass':proof['raw_capacity_exact_pass'],
            'sent_capacity_exact_pass':proof['sent_capacity_exact_pass'],'raw_failed_rows':row['raw_failed_rows'],
            'sent_failed_rows':row['sent_failed_rows'],'maximum_raw_capacity_violation_Nm':float(np.maximum(-margins,0).max()),
            'new_max_original_friction_violation_N':float(np.maximum(az[indices],0).max()),
            'new_max_working_friction_violation_N':float(np.maximum(az[indices]-raw['step36_working_u'][indices],0).max()),
            'old_max_original_friction_violation_N':float(np.maximum((old['source_matrices']['A']@old['full_current_raw_x'])[indices],0).max()),
            'old_warm_started':old.get('warm_started'),'new_warm_started':raw.get('warm_started'),
            'new_workspace_reused':raw.get('workspace_reused'),'native_limit_s':raw['osqp_time_limit_s'],
            'solve_wall_ms':1000*raw['solve_wall_time_s'],'setup_ms':1000*raw['setup_time_s'],
            'invoke_wall_ms':1000*raw['invoke_total_wall_time_s'],'iterations':raw['iterations'],
            'eps_abs':raw['actual_setup_eps_abs'],'eps_rel':raw['actual_setup_eps_rel'],
            'primal_residual':raw['primal_residual'],'dual_residual':raw['dual_residual'],
            'new_QP_calls':1,'new_integration_steps':0,'scope':'DEV_NUMERICAL_REPAIR_PROBE'}
        probes.append(new)
        latency.append({k:new[k] for k in ('probe_kind','new_global_qp_index','setup_ms','solve_wall_ms','invoke_wall_ms','native_limit_s')})
        for witness in ('raw','sent'):
            hard=proof[witness+'_hard_check']
            for index in hard['failed_row_indices']:
                index=int(index)
                failures.append({'probe_kind':row['probe_kind'],'witness':witness,'row_index':index,'row_unit':m['row_units'][index],
                    'original_lower':float(m['l'][index]),'original_upper':float(m['u'][index]),
                    'original_tolerance':float(m['row_abs_tolerance'][index]),'A_z':float(hard['A_z'][index]),
                    'original_contract_violation':float(hard['row_violation'][index])})
        for offset,index in enumerate(indices):
            index=int(index)
            constraints.append({'probe_kind':row['probe_kind'],'row_index':index,'family':raw['step36_working_row_families'][offset],
                'unit':'N','original_lower':float(raw['step36_original_l'][index]),'original_upper':float(raw['step36_original_u'][index]),
                'working_lower':float(raw['step36_working_l'][index]),'working_upper':float(raw['step36_working_u'][index]),
                'reserve_N':1e-4,'original_inequality_extra_slack':0.,'acceptance':'ORIGINAL_ROWS_ONLY','raw_Az_N':float(az[index])})
    for name,rows in (('PROBE_SUMMARY',probes),('ORIGINAL_CONTRACT_FAILURE_ROWS',failures),
        ('ORIGINAL_WORKING_CONSTRAINTS',constraints),('PHASE_LATENCY',latency)):dump(out,name,rows)
    reason='FIXED_FRICTION_PROBES_BOTH_REJECTED_STOP_RULE'
    cal=[{**p,'gamma':g,'status':'NOT_RUN','observed':False,'reason':reason} for p in plans('CAL') for g in (1.,.75,.5,.25,0.)]
    queue=[{**p,'method':method,'status':'NOT_RUN','observed':False,'selected_sent':False,'actual_runs':0,'reason':reason}
        for p in plans('TEST') for method in METHODS]
    fallback=[{'source_state_id':sid,'branch':name,'gamma':g,'status':'NOT_RUN','observed':False,
        'model_authorized':False,'selected_command_sent':False,'reason':'NO_CAL_READINESS_DECISION_PROBE_STOP'}
        for sid in FALLBACK_IDS for name,g in (('C',1.),('G0.5',.5),('B',0.))]
    groups=[{'group':str(g)+':'+role,'CAL_planned':12,'CAL_recorded':0,'CAL_complete':0,
        'CAL_complete_distinct_snapshots':0,'CAL_complete_episodes':0,'local_calibrated':None,
        'status':'NOT_EVALUATED_PROBE_STOP'} for g in (1.,.75,.5,.25,0.) for role in ('thigh','calf')]
    for name,rows in (('CAL_RESULTS',cal),('CAL_GROUP_SUMMARY',groups),('QUEUE_RESULTS',queue),
        ('FALLBACK_COUNTERFACTUAL_RESULTS',fallback),('ACTUAL_RESULTS',[]),('COUNTERFACTUAL_RESULTS',[]),('CAPACITY_RESULTS',[])):
        dump(out,name,rows)
    ledger=list(jsonl_rows(out/'STEP36_LEDGER.jsonl'))
    returns=[r for r in ledger if r['event']=='QP_RETURN'];dump(out,'QP_CALL_RETURNS',returns)
    attempt=out/'ATTEMPT_LEDGER.jsonl'
    if not attempt.exists():
        for event in ledger:
            if event['event'] in ('NUMERICAL_STARTED','QP_START','QP_RETURN','NUMERICAL_FINISHED'):
                append(attempt,{**event,'derived_from':'STEP36_LEDGER.jsonl','new_numeric_work':False})
    r={'run_id':run_id,'source_commit':PARENT,'NUMERICAL_STATUS':finished['status'],
        'INTERIOR_NUMERICAL_REPAIR_STATUS':gate['status'],'FIRST_B_PROBE_STATUS':'NOT_ESTABLISHED',
        'SCIENTIFIC_RUN_STATUS':'STOPPED_AT_FIXED_PROBE_GATE','OVERALL_STATUS':'FAIL / REVISE',
        'A_STATUS':'NOT_ESTABLISHED','B_STATUS':'NOT_ESTABLISHED','C_STATUS':'NOT_ESTABLISHED',
        'CAL_READINESS_STATUS':'NOT_EVALUATED_PROBE_STOP','formal_TEST_status':'NOT_RUN','fallback_status':'NOT_RUN',
        'CAL_contexts_planned':24,'CAL_action_slots_planned':120,'CAL_observed_contexts':0,'CAL_observed_action_slots':0,
        'TEST_source_states_planned':16,'TEST_inputs_planned':48,'TEST_method_slots_planned':96,
        'formal_online_decisions':0,'formal_sent_packets':0,'formal_ACTUAL_runs':0,'conditional_send_success_rate':None,
        'fallback_source_states_planned':4,'fallback_max_branches':12,'fallback_ACTUAL_runs':0,
        'new_reference_solves':0,'new_reference_integration_steps':0,'new_model_fits':0,'implementation_repairs_used':0,
        'probes':probes,'new_QP_calls':finished['budget']['total_QP_calls'],'new_physics_steps':finished['budget']['total_physics_steps'],
        'raw_QP_shards':len(list((out/'raw_qp').glob('QP*.json'))),'budget':finished['budget'],
        'source_old_statuses_not_replaced':True,'zero_working_tolerance_acceptance_gate':False,
        'original_inequality_extra_slack':0,'working_upper_N':-1e-4,'solver_limits':{'first_B_s':.006,'first_C_s':.003,'feedback_s':.006},
        'new_probe_owner_start':'NEW_INDEPENDENT_WORKSPACE_NO_SOURCE_WARM_START_REPLAY',
        'joint_numerical_intervention_not_single_factor_causal_claim':True,'saved_only_analysis_new_calls':0,
        'necessary_tests':read(out/'tests/NECESSARY_TESTS.json'),'current_delivery_check':read(out/'tests/CURRENT_DELIVERY_CHECK.json',{}),
        'figure_count':0,'historical_results_unchanged':True,'E3_RL_HARDWARE':'NOT_AUTHORIZED'}
    write(out/'STEP36_RESULT.json',r)
    lines=['# STEP36：摩擦内缩与备份预算修复','','## Material Passport','',
        'experiment-agent / run + saved-only analysis / 2026-10-10 / Asia/Seoul / ANALYZED / STEP36_v1。','',
        '## 结果','',
        '固定数值探针未建立修复。三个新调用均为raw status8，原raw/sent契约均拒收。两个摩擦-only探针均未通过，触发协议第5节停止条件。**FAIL / REVISE**；不继续CAL、TEST或offline fallback。',
        '本轮完成实施和一次必要suite（5/5），执行三个固定DEV问题，每个一次、6ms、eps1e-7、工作摩擦上界−1e-4N。累计3次QP、0积分、0新reference、0fit、0 DEV重启。退出码0表示按科学停止规则结束，不是机制PASS。','',
        '## 逐问题结果','',
        '| 源QP | 探针 | 原→新status | 原raw失败行 | 原sent失败行 | 最大raw容量越界(Nm) |',
        '|---:|---|---|---|---|---:|']
    for p in probes:
        lines.append(f"| {p['source_global_qp_index']} | {p['probe_kind']} | {p['old_raw_status']}→{p['new_raw_status']} | {p['raw_failed_rows']} | {p['sent_failed_rows']} | {p['maximum_raw_capacity_violation_Nm']:.6g} |")
    lines+=['','957：新raw动力学行10及容量行49失败；sent容量裁剪后仍在动力学行10失败。',
        '968：新raw/sent仅摩擦行63、73失败，内缩未在单次6ms求解中使该问题通过原界。',
        '1723：新raw在容量行56失败，sent裁剪后在动力学行17失败。旧polish成功不意味着新working问题也收敛；新polish status0均原样保留。','',
        '具体数值和单位：[PROBE_SUMMARY](PROBE_SUMMARY.csv)、[ORIGINAL_CONTRACT_FAILURE_ROWS](ORIGINAL_CONTRACT_FAILURE_ROWS.csv)。row_violation按各行原SI契约计算，不把不同单位残差汇总为统一安全指标。','',
        '## 原约束与工作问题','',
        '固定清单作为第一个本轮工件保存：[PROBE_PLAN](PROBE_PLAN.json)。仅最终有效CAL中的957/968/1723，不含无效attempt或TEST诊断。',
        '每个QP保留原P/q/A、原l/u与实际working l/u的lossless NPZ。只改16个N单位切向摩擦行上界−1e-4；normal-force行64/69/74/79不改。原健康、状态、目标和SI验收保留，inequality额外slack仍0，working残差仅诊断。',
        'raw status描述工作QP，原契约可行是独立核验；不称原QP最优或未来安全。三个probe使用新独立冷workspace，未重放旧warm start；结果不分离内缩与预算的单因素因果效应。',
        'B首调用6ms、C3ms、反馈6ms与绝对20ms整包预检已实现；本轮只有探针真实native6ms证据，startup、在线配对和feedback未实测。fixture通过不等于部署性能。',
        '约束明细：[ORIGINAL_WORKING_CONSTRAINTS](ORIGINAL_WORKING_CONSTRAINTS.csv)；全部raw：[raw_qp](raw_qp/)。','',
        '## 计划分母与观测','',
        'CAL：24初态、120动作位NOT_RUN，0观测；没有新CAL/readiness判断，CAL freeze_count0。',
        'TEST：16 source states、48 gap输入、96方法位NOT_RUN，0正式决策、0发送、0ACTUAL；零发送条件成功率未定义。',
        'fallback：四个独立source、最多12分支NOT_RUN。第8节要求实际CAL仍不可查询；本轮在更早探针门停止，不能绕过第5节直接运行fallback。',
        'A/B/C均NOT_ESTABLISHED。actual/CF/容量表为空观测，不用计划位代替实测。原STEP35结论及八条reference原样保留。','',
        '全计划：[CAL_RESULTS](CAL_RESULTS.csv)、[CAL_GROUP_SUMMARY](CAL_GROUP_SUMMARY.csv)、[QUEUE_RESULTS](QUEUE_RESULTS.csv)、[FALLBACK_COUNTERFACTUAL_RESULTS](FALLBACK_COUNTERFACTUAL_RESULTS.csv)。三个固定诊断采用逐行表展示全部结果，没有空面板或空ACTUAL装饰图。','',
        '## 执行与预算','',
        f"数值起点：{finished['budget']['numerical_started_utc']}；墙钟：{finished['budget']['numerical_elapsed_s']:.6f}s。账本start/return=3/3，UNKNOWN0，积分预留0。",
        'native time limit不是包含setup/复制/核验的总墙钟截止；阶段实测见[PHASE_LATENCY](PHASE_LATENCY.csv)。',
        '命令：E:/CAVR-WBC/_runtime_step30/python311/python.exe -B -X utf8 -m cavr_wbc.experiments.step36_sprint。',
        '测试：[NECESSARY_TESTS](tests/NECESSARY_TESTS.json)；数值控制台：[NUMERICAL_CONSOLE](NUMERICAL_CONSOLE.txt)；完整账本：[STEP36_LEDGER](STEP36_LEDGER.jsonl)。当前读回与scoped diff各一次，不扩展历史审计。不push/reset原HEAD，不访问机器人运控算法。','',
        '当前读回首次输出有一项报告器假阴性：START提取耗尽generator后，RETURN列表为空。原账本实际start/return均[1,2,3]且完整；仅修正保存结果解析，保留[首次核查](tests/CURRENT_DELIVERY_CHECK_INITIAL.json)，[修正记录](tests/CURRENT_DELIVERY_CHECK.json)说明同份已读取证据的修正，未重跑整套核查或数值工作。','',
        '## 协议状态','','~~~ini',PROTOCOL_LINES,
        'NUMERICAL_STATUS = INTERIOR_NUMERICAL_REPAIR_NOT_ESTABLISHED','SCIENTIFIC_RUN_STATUS = STOPPED_AT_FIXED_PROBE_GATE',
        'OVERALL_STATUS = FAIL / REVISE','CAL_READINESS_STATUS = NOT_EVALUATED_PROBE_STOP','CAL_OBSERVED_ACTION_SLOTS = 0',
        'FORMAL_TEST_DECISIONS = 0','FORMAL_SENT_PACKETS = 0','FORMAL_ACTUAL_RUNS = 0','FALLBACK_ACTUAL_RUNS = 0',
        'CONDITIONAL_SEND_SUCCESS_RATE = UNDEFINED','ACTUAL_NEW_QP_CALLS = 3','ACTUAL_NEW_PHYSICS_STEPS = 0',
        'ACTUAL_DEV_IMPLEMENTATION_REPAIRS = 0','A_STATUS = NOT_ESTABLISHED','B_STATUS = NOT_ESTABLISHED',
        'C_STATUS = NOT_ESTABLISHED','~~~','']
    (out/'STEP36_REPORT.md').write_text('\n'.join(lines),encoding='utf-8',newline='\n')
    handoff=['# STEP36研究交接','','## Material Passport','',
        'experiment-agent / bounded numerical repair / 2026-10-10 / Asia/Seoul / ANALYZED。','',
        '结论：INTERIOR_NUMERICAL_REPAIR_NOT_ESTABLISHED，FAIL / REVISE。固定三个问题一次各求解，新raw8及原契约拒收；按第5节停止。',
        '没有新CAL/readiness、TEST、ACTUAL、fallback、reference或fit。正式20ms和1s执行性能本轮未评价，A/B/C未建立。',
        'B6/C3/feedback6及16工作摩擦内缩已实现，原物理契约不放宽。真实原/工作问题、原raw/sent失败保存。',
        '957：动力学/容量；968：摩擦63/73；1723：raw容量、sent动力学。三个新workspace冷启动，仅评价固定单次保存问题修复。',
        '后续设计改变或更多数值调用需新授权；当前不追加reserve/eps搜索、历史reference重跑或证书审计。',
        '八条STEP35完整reference、原训练模型和所有旧失败原样保留。[报告](STEP36_REPORT.md)、[结果](STEP36_RESULT.json)。',
        '工作树 E:/CAVR-WBC/cavr_step17_formal_panel_targeted_repair_20260923；独立分支 codex/step36-interior-friction-20261010；未push/reset原HEAD。','',
        '~~~ini',PROTOCOL_LINES,'INTERIOR_NUMERICAL_REPAIR_STATUS = INTERIOR_NUMERICAL_REPAIR_NOT_ESTABLISHED',
        'OVERALL_STATUS = FAIL / REVISE','~~~','']
    (out/'STEP36_RESEARCH_HANDOFF.md').write_text('\n'.join(handoff),encoding='utf-8',newline='\n')
    print({key:r[key] for key in ('NUMERICAL_STATUS','OVERALL_STATUS','new_QP_calls','new_physics_steps')})
    return r

if __name__=='__main__':summarize()
