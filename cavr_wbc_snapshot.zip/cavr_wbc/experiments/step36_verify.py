"""One current identity/readback check; no numerical execution or historical audit."""
from datetime import datetime,timezone
import ast
import numpy as np
from cavr_wbc.experiments.step36_io import *
from cavr_wbc.experiments.step33_report import jsonl_rows

def verify():
    out=output();checks={};details=[];plan=read(out/'PROBE_PLAN.json')
    checks['fixed_probe_indices']=[p['source_global_qp_index'] for p in plan['probes']]==[957,968,1723]
    expected=np.array([60+5*f+k for f in range(4) for k in range(4)])
    for p,row in zip(plan['probes'],read(out/'PROBE_RESULTS.json')):
        source=Path(p['source_raw_path']);old=load_numeric(source)['raw_result']
        new=load_numeric(row['new_numeric']['json'])['raw_result']
        same_problem=all(np.array_equal(old['step34_problem'][key].toarray(),new['step34_problem'][key].toarray()) for key in ('P','A'))
        same_problem &= all(np.array_equal(old['step34_problem'][key],new['step34_problem'][key]) for key in ('q','l','u'))
        original=new['step34_problem'];delta=np.flatnonzero(new['step36_working_u']!=original['u'])
        good=bool(same_problem and sha(source)==p['source_raw_sha256'] and sha(source.with_suffix('.npz'))==p['source_numeric_sha256'] and
            np.array_equal(delta,expected) and np.array_equal(new['step36_working_changed_rows'],expected) and
            np.array_equal(new['step36_working_l'],original['l']) and
            np.array_equal(new['step36_original_u'],original['u']) and
            np.all(new['step36_working_u'][expected]==-1e-4) and
            new['osqp_time_limit_s']==.006 and new['actual_setup_eps_abs']==new['actual_setup_eps_rel']==1e-7 and
            new['candidate_certificate']['inequality_extra_slack']==0 and
            new['candidate_certificate']['current_state_health_identity'] and
            new['candidate_certificate']['candidate_valid'] is False and new['status_val']==8)
        details.append({'source_global_qp_index':p['source_global_qp_index'],'pass':good,
            'source_hash_unchanged':sha(source)==p['source_raw_sha256'],
            'same_original_P_q_A_l_u':bool(same_problem),'changed_rows':delta,'raw_status':new['status_val'],
            'original_candidate_valid':new['candidate_certificate']['candidate_valid']})
    checks['all_three_original_working_readbacks']=all(d['pass'] for d in details)
    ledger=list(jsonl_rows(out/'STEP36_LEDGER.jsonl'))
    starts=[r['global_qp_index'] for r in ledger if r['event']=='QP_START']
    returns=[r['global_qp_index'] for r in ledger if r['event']=='QP_RETURN']
    checks['ledger_three_exact_returns']=starts==returns==[1,2,3]
    budget=read(out/'RUN_FINISHED.json')['budget']
    checks['zero_steps_fits_unknown']=budget['total_physics_steps']==budget['multioutput_estimator_fits']==budget['unknown_native_returns']==budget['uncompleted_native_step_reservations']==0
    model=read(out/'MODEL_LOAD.json')
    checks['model_source_hash_unchanged']=sha(model['npz'])==model['npz_sha256'] and sha(model['json'])==model['json_sha256']
    checks['raw_evidence_complete']=len(list((out/'raw_qp').glob('QP*.json')))==3
    checks['ordinary_failures_not_retried']=len(list((out/'repairs').glob('REPAIR_*_STARTED.json')))==0
    checks['no_CAL_freeze_or_actual']=not (out/'STEP36_FREEZE.json').exists() and not list((out/'CAL').glob('*/PACKET.json')) and not list(out.rglob('actual.npz'))
    checks['necessary_suite_once_five_passed']=read(out/'tests/NECESSARY_TESTS.json')['passed']==5 and read(out/'tests/NECESSARY_TESTS.json')['suite_runs']==1
    syntax=[]
    for p in [*ROOT.glob('cavr_wbc/control/step36_*.py'),*ROOT.glob('cavr_wbc/experiments/step36_*.py'),*ROOT.glob('tests/test_step36*.py')]:
        ast.parse(p.read_text(encoding='utf-8'),filename=str(p));syntax.append(relative(p,ROOT))
    checks['current_source_syntax']=True
    checks['unobserved_denominators']=(len(read(out/'CAL_RESULTS.json'))==120 and len(read(out/'QUEUE_RESULTS.json'))==96 and
        all(not r['observed'] for r in read(out/'QUEUE_RESULTS.json')) and len(read(out/'FALLBACK_COUNTERFACTUAL_RESULTS.json'))==12)
    record={'timestamp_utc':datetime.now(timezone.utc).isoformat(),'check_count':1,'checks':checks,'all_pass':all(checks.values()),
        'current_probe_details':details,'syntax_files':syntax,'new_QP_calls':0,'new_integration_steps':0,'new_fits':0,
        'scientific_success_claim':False,'verification_command':'E:/CAVR-WBC/_runtime_step30/python311/python.exe -B -X utf8 -m cavr_wbc.experiments.step36_verify'}
    write(out/'tests/CURRENT_DELIVERY_CHECK.json',record)
    print(record)
    if not record['all_pass']:raise ValueError('current evidence readback failed')

if __name__=='__main__':verify()
