"""SciPilot saved-data figures, previews first and vector export after visual QA."""
import argparse,sys,gc
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap,BoundaryNorm
from matplotlib.lines import Line2D
from PIL import Image
from cavr_wbc.experiments.step37_io import *
from cavr_wbc.experiments.step37_sprint import REPRESENTATIONS,BRANCHES
from cavr_wbc.experiments.step26_features_storage import load_bank as physics_bank

SKILL=Path('C:/Users/ZhuanZ（无密码）/.codex/skills/scipilot-figure/scripts')
sys.path.insert(0,str(SKILL))
from setup_style import setup_style
from profile_data import profile_data,render_report
from visual_qa import render_preview,audit_layout
from layout_tools import add_panel_labels
from export_figure import export_figure

COLORS=['#d9d9d9','#E69F00','#CC79A7','#0072B2']
CODES=['N','I','U','S']
FULL=REPRESENTATIONS[0]
REP_COLOR={FULL:'#0072B2',REPRESENTATIONS[1]:'#D55E00'}

def style():
    result=setup_style(journal='ieee',lang='en',constrained_layout=False)
    plt.rcParams.update({'font.size':8,'xtick.labelsize':8,'ytick.labelsize':8,'legend.fontsize':8,
        'axes.spines.top':False,'axes.spines.right':False,'axes.titlesize':9,'pdf.fonttype':42,'svg.fonttype':'none'})
    return result

def metadata_profile(out):
    info=profile_data(str(out/'BRANCH_RESULTS.csv'),group_cols=['representation','branch'])
    write(out/'figures/DATA_PROFILE.json',info)
    (out/'figures/DATA_PROFILE.md').write_text(render_report(info),encoding='utf-8')
    write(out/'figures/FIGURE_DESIGN.json',{'goal':'show every planned branch, numerical missing, saved recovery and paired first packet timing',
        'recommended':'96-cell outcome matrix + paired packet dot plot; six-facet all-trajectory plots',
        'alternatives':['status table only','paired continuous scatter for both-complete subset'],
        'source_ordinal_is_categorical_ID_not_dose':True,'no_mean_bar_or_small_sample_KDE':True,
        'n_contexts':16,'physical_snapshots':8,'episodes':4,'local_gap_in_outcome_matrix_mm':6,
        'same_trajectories_4_6_8_in_saved_tables':True,'no_significance_or_independent_repeat_claim':True})

def outcomes(out):
    rows=read(out/'BRANCH_RESULTS.json');gap=read(out/'GAP_RESULTS.json');packets=read(out/'PACKET_RESULTS.json')
    ids=sorted({(r['source_ordinal'],r['source_state_id']) for r in rows})
    mat=np.zeros((16,6),dtype=int);timed=np.zeros((16,6),dtype=bool)
    for row in rows:
        j=REPRESENTATIONS.index(row['representation'])*3+[b for b,_ in BRANCHES].index(row['branch'])
        i=row['source_ordinal']
        g=next(x for x in gap if x['source_state_id']==row['source_state_id'] and x['representation']==row['representation'] and x['branch']==row['branch'] and x['gap_mm']==6)
        mat[i,j]=0 if not row['observed'] else 1 if not row['complete_501'] else 3 if g['full_safe'] else 2
        timed[i,j]=bool(row['timing_qualified'])
    fig,axes=plt.subplots(1,2,figsize=(7.16,5.5),gridspec_kw={'width_ratios':[1.35,1.]},constrained_layout=False)
    fig.subplots_adjust(left=.21,right=.97,bottom=.30,top=.90,wspace=.55)
    ax=axes[0]
    ax.pcolormesh(np.arange(7)-.5,np.arange(17)-.5,mat,cmap=ListedColormap(COLORS),
        norm=BoundaryNorm(np.arange(-.5,4.5),4),shading='flat',rasterized=False)
    ax.set_xlim(-.5,5.5);ax.set_ylim(15.5,-.5)
    for i in range(16):
        for j in range(6):
            ax.text(j,i,CODES[mat[i,j]]+('•' if timed[i,j] else ''),ha='center',va='center',
                fontsize=8,color='white' if mat[i,j]==3 else 'black')
    labels=[]
    for i,sid in ids:
        source=next(r for r in rows if r['source_state_id']==sid)
        labels.append(f"{i+1:02d} {source['episode'].replace('T35_','')}/{source['source_tick']:02d}/"+('TH' if source['role']=='thigh' else 'CA'))
    ax.set_yticks(range(16),labels);ax.set_xticks(range(6),['C','0.5','B','C','0.5','B'])
    ax.text(1,-.065,'Full',transform=ax.get_xaxis_transform(),ha='center',va='top',fontsize=8)
    ax.text(4,-.065,'Reduced',transform=ax.get_xaxis_transform(),ha='center',va='top',fontsize=8)
    ax.set_xlabel('Same-packet branch',labelpad=26);ax.set_ylabel('Source context')
    ax.set_title('All outcomes at 6 mm',loc='left',pad=14)
    ax.set_xticks(np.arange(-.5,6),minor=True);ax.set_yticks(np.arange(-.5,16),minor=True);ax.grid(which='minor',color='white',lw=.6);ax.tick_params(which='minor',length=0)
    legend=[Line2D([],[],marker='s',color=c,ls='',label=lab,markersize=6) for c,lab in zip(COLORS,['N: unavailable','I: numerical incomplete','U: complete, unsafe','S: complete, safe'])]
    fig.legend(handles=legend,loc='lower left',bbox_to_anchor=(.18,.05),ncol=2,fontsize=8,frameon=False)
    ax=axes[1]
    for i,sid in ids:
        p=[next(r for r in packets if r['source_state_id']==sid and r['representation']==rep) for rep in REPRESENTATIONS]
        values=[r['packet_ready_ms'] if r['recorded'] else None for r in p]
        if all(v is not None and np.isfinite(v) for v in values):ax.plot(values,[i,i],color='.65',lw=.7,zorder=1)
        for j,(rep,value) in enumerate(zip(REPRESENTATIONS,values)):
            if value is not None and np.isfinite(value):ax.scatter(value,i,marker='o' if j==0 else 's',s=22,
                facecolors='none' if j==0 else REP_COLOR[rep],edgecolors=REP_COLOR[rep],lw=.8,zorder=2,label='Full' if j==0 and i==0 else 'Reduced' if j==1 and i==0 else None)
    ax.axvline(20,color='.25',ls='--',lw=.9,label='20 ms deadline')
    ax.set_ylim(15.5,-.5);ax.set_yticks(range(16),[str(i+1).zfill(2) for i in range(16)])
    ax.set_xlabel('First packet ready (ms)');ax.set_ylabel('Context ID')
    ax.set_title('First-packet latency',loc='left',pad=14);ax.legend(loc='upper left',bbox_to_anchor=(0,-.10),frameon=False)
    fig.text(.18,.015,'Dot after code: timing-qualified complete branch',fontsize=8)
    add_panel_labels(fig,axes=axes,style='ieee',fontsize=9,x_offset_pt=-3,y_offset_pt=14,ha='right')
    return fig

def trajectories(out):
    rows=read(out/'BRANCH_RESULTS.json');fig,axes=plt.subplots(2,3,figsize=(7.16,5.6),sharex=True,sharey=True,constrained_layout=False)
    fig.subplots_adjust(left=.10,right=.98,bottom=.20,top=.91,wspace=.22,hspace=.45)
    trace_rows=[];extent=[]
    for i,rep in enumerate(REPRESENTATIONS):
        for j,(name,_) in enumerate(BRANCHES):
            ax=axes[i,j];sub=[r for r in rows if r['representation']==rep and r['branch']==name]
            nrun=0;npartial=0
            for row in sub:
                if not row['observed'] or not row.get('artifact'):continue
                bank=physics_bank(row['artifact']['path'])
                facts=([bank['initial_fact']] if bank.get('initial_fact') else [])+bank['physics_trajectory']
                anchor=bank['fixed_anchor_q_init'][0];direction=row['direction']
                xy=[(f['time_s'],1000*direction*(f['qpos'][0]-anchor)) for f in facts if f.get('qpos') is not None and f.get('time_s') is not None]
                if not xy:continue
                x,y=np.asarray(xy).T;nrun+=1;extent.extend(y)
                ax.plot(x,y,color=REP_COLOR[rep],lw=.6,alpha=.4,ls='-' if rep==FULL else '--')
                if not row['complete_501']:
                    npartial+=1;ax.scatter(x[-1],y[-1],marker='x',s=24,color='black',lw=.8)
                for time,value in xy:
                    trace_rows.append({'representation':rep,'branch':name,'source_state_id':row['source_state_id'],
                        'time_s':float(time),'signed_displacement_mm':float(value),'trajectory_status':row['status']})
                del bank;gc.collect()
            ax.axvspan(.02,.04,color='.82',alpha=.45,zorder=-1)
            ax.axhline(6,color='.4',ls=':',lw=.8)
            ax.set_title(('Full' if rep==FULL else 'Reduced')+': '+('0.5' if name=='MIDDLE' else name)+f'\n{nrun}/16 run, {npartial} partial',fontsize=8,pad=7)
            ax.set_xlim(0,1);ax.set_xticks([0,.5,1])
            if i==1:ax.set_xlabel('Sample time (s)')
            if j==0:ax.set_ylabel('Signed displacement (mm)')
    if extent:
        lo=min(0,min(extent));hi=max(8,max(extent));pad=.06*max(hi-lo,1)
        axes[0,0].set_ylim(lo-pad,hi+pad)
    add_panel_labels(fig,axes=axes.flat,style='ieee',fontsize=9,x_offset_pt=-3,y_offset_pt=15,ha='right')
    fig.text(.5,.025,'All saved trajectories; x = numerical stop; shaded = selected hold; dotted = 6 mm',ha='center',fontsize=8)
    from cavr_wbc.experiments.step33_report import csv_write
    csv_write(out/'figures/TRAJECTORY_FIGURE_DATA.csv',trace_rows)
    return fig

def draw(export=False):
    out=output();(out/'figures').mkdir(parents=True,exist_ok=True);style_info=style();metadata_profile(out)
    reports=[]
    for name,maker,size in [('STEP37_all_outcomes_latency',outcomes,(7.16,5.5)),('STEP37_all_actual_trajectories',trajectories,(7.16,5.6))]:
        fig=maker(out);fig.canvas.draw();issues=audit_layout(fig)
        path=out/'figures'/(name+'_preview.png');render_preview(fig,str(path),dpi=160)
        Image.open(path).convert('L').save(path.with_name(name+'_preview_grayscale.png'))
        if export:
            if any(s=='FAIL' for s,_ in issues):raise ValueError('figure glyph/layout FAIL before vector export')
            export_figure(fig,str(out/'figures'/name),formats=['pdf','svg','png'],size_inches=size,dpi=600,grayscale_preview=False,tight=False)
            Image.open(out/'figures'/(name+'.png')).convert('L').save(out/'figures'/(name+'_grayscale.png'),dpi=(600,600))
        reports.append({'figure':name,'issues':issues,'exported':export,'size_inches':size,'minimum_font_pt':8,'style':style_info,
            'data_contains_all_failures':True,'saved_only_new_QP_or_steps':0})
        plt.close(fig)
    write(out/'figures/VISUAL_PROGRAM_QA.json',reports)
    print(reports)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--export',action='store_true');draw(p.parse_args().export)
