"""Streaming saved-only STEP37 analysis. No solver, simulator or predictor calls."""
from collections import Counter,defaultdict
from pathlib import Path
import numpy as np
from cavr_wbc.experiments.step37_io import *
from cavr_wbc.experiments.step37_sprint import plans,REPRESENTATIONS,BRANCHES,GAPS
from cavr_wbc.experiments.step33_report import csv_write,statistics,jsonl_rows,finite

def dump(out,name,rows):
    write(out/(name+'.json'),rows);csv_write(out/(name+'.csv'),rows)

def analyze(run_id=RUN_ID):
    out=output(run_id);finished=read(out/'RUN_FINISHED.json');manifest=read(out/'MANIFEST.json')
    rows=[];packet_rows=[];eq_rows=[];startup=[]
    for p in plans():
        state_dir=out/'states'/p['context_id']
        eq=read(state_dir/'FIRST_PACKET_EQUIVALENCE.json',{})
        eq_rows.append({'source_state_id':p['source_state_id'],'ordinal':p['ordinal'],**eq})
        for rep in REPRESENTATIONS:
            directory=state_dir/rep;result=read(directory/'RESULT.json',{})
            packetdoc=read(directory/'PACKET.json',{})
            packet=packetdoc.get('record',{})
            ready=packet.get('command_ready_ms');ep={}
            for name in ('C','B'):
                e=packet.get(name) or {};raw=e.get('raw_solver_result',e.get('wbc',{})) or {}
                ep[name]={'status':raw.get('status_val'),'valid':bool(e.get('command_valid',e.get('valid_command'))),
                    'native_limit_s':(packet.get('first_QP_native_limits_s') or {}).get(name),'raw_global_index':raw.get('step37_global_qp_index')}
            packet_rows.append({'source_state_id':p['source_state_id'],'ordinal':p['ordinal'],'representation':rep,
                'recorded':bool(packetdoc),'packet_ready_ms':ready,'packet_timely':bool(finite(ready) and ready<=20),
                'packet_status':packet.get('status','NOT_RUN'),'C_raw_status':ep['C']['status'],'B_raw_status':ep['B']['status'],
                'C_valid':ep['C']['valid'],'B_valid':ep['B']['valid'],'C_native_limit_s':ep['C']['native_limit_s'],
                'B_native_limit_s':ep['B']['native_limit_s'],'C_QP_index':ep['C']['raw_global_index'],'B_QP_index':ep['B']['raw_global_index'],
                'phase_latency_ms':packet.get('phase_latency_ms'),'model_authorized':False,'selected_command_sent':False})
            prime=read(directory/'STARTUP.json',{})
            for branch,record in prime.get('owners',{}).items():
                startup.append({'source_state_id':p['source_state_id'],'representation':rep,'branch':branch,
                    'ready':record.get('ready'),'status':record.get('status'),'priming_QP_calls':record.get('priming_QP_calls'),
                    'nominal_priming_command_valid':record.get('nominal_priming_command_valid'),
                    'backup_priming_command_valid':record.get('backup_priming_command_valid'),
                    'preparation_wall_ms':prime.get('preparation_wall_ms'),'startup_ms':record.get('startup_ms'),
                    'owner_identity':prime.get('independent_owners',{}).get(branch)})
            for name,gamma in BRANCHES:
                record=read(directory/name/'RESULT.json',{});lab=record.get('label') or {}
                action=(packet.get('actions',{}).get(str(gamma)) or {}).get('action') or {}
                complete=bool(lab.get('complete') and lab.get('full_501_grid'))
                obs=bool(record.get('observed',False))
                row={'source_state_id':p['source_state_id'],'source_ordinal':p['ordinal'],'episode':p['episode'],
                    'physical_snapshot':p['snapshot_id'],'source_tick':p['tick'],'role':p['role'],'direction':p['direction'],
                    'representation':rep,'branch':name,'gamma':gamma,'status':record.get('status','NOT_RUN'),
                    'observed':obs,'candidate_available':bool(action.get('command_valid')),
                    'complete_501':complete,'steps':(record.get('counts') or {}).get('physical_steps',0),
                    'feedback_QP_calls':(record.get('counts') or {}).get('feedback_QP_calls',0),
                    'physical_pass':bool(complete and lab.get('original_physical_safe')),
                    'terminal_pass':bool(complete and lab.get('terminal_pass')),
                    'complete_physical_failure':bool(complete and not lab.get('original_physical_safe')),
                    'observed_partial_physical_failure':bool(not complete and (lab.get('original_failure') or lab.get('observed_original_physical_failure'))),
                    'numerical_incomplete':bool(obs and not complete),'D_m':lab.get('D'),'Y':lab.get('Y'),
                    'progress02_04_m':record.get('progress02_04_m'),'progress0_04_m':record.get('progress0_04_m'),
                    'first_packet_ready_ms':record.get('first_packet_ready_ms',ready),
                    'first_packet_timely':bool(record.get('first_packet_timely')),
                    'feedback_48_deadlines_pass':bool(record.get('feedback_48_deadlines_pass')),
                    'timing_qualified':bool(record.get('timing_qualified')),
                    'application_identity_pass':record.get('application_identity_pass'),
                    'first_tau_matches_packet':record.get('first_tau_matches_packet'),
                    'feedback_latencies_ms':record.get('feedback_latencies_ms',[]),'events':record.get('events'),
                    'backup_memory_restore':record.get('backup_memory_restore'),
                    'artifact':record.get('artifact'),'result_path':relative(directory/name/'RESULT.json',out),
                    'control_path':record.get('controls_path'),'reason':record.get('reason'),
                    'model_authorized':False,'selected_command_sent':False}
                rows.append(row)
    gap_rows=[]
    for row in rows:
        for gap in GAPS:
            local=bool(row['complete_501'] and finite(row['D_m']) and 0<=row['D_m']<=gap)
            safe=bool(row['complete_501'] and row['physical_pass'] and row['terminal_pass'] and local and
                row['application_identity_pass'] is True and row['first_tau_matches_packet'] is True)
            gap_rows.append({k:row[k] for k in ('source_state_id','source_ordinal','episode','role','representation','branch','status','observed','complete_501','physical_pass','terminal_pass','D_m','progress02_04_m')} |
                {'gap_mm':round(gap*1000),'local_pass':local,'full_safe':safe,'timing_qualified_safe':bool(safe and row['timing_qualified']),
                 'complete_local_failure':bool(row['complete_501'] and finite(row['D_m']) and row['D_m']>gap),
                 'same_trajectory_no_new_propagation':True})
    summaries=[]
    for rep in REPRESENTATIONS:
        for name,_ in BRANCHES:
            sub=[r for r in rows if r['representation']==rep and r['branch']==name]
            for gap in GAPS:
                gr=[r for r in gap_rows if r['representation']==rep and r['branch']==name and r['gap_mm']==round(gap*1000)]
                summaries.append({'representation':rep,'branch':name,'gap_mm':round(gap*1000),'planned_source_contexts':16,
                    'candidate_available':sum(r['candidate_available'] for r in sub),'observed_ACTUAL':sum(r['observed'] for r in sub),
                    'complete_501':sum(r['complete_501'] for r in sub),'physical_pass_complete':sum(r['physical_pass'] for r in sub),
                    'terminal_pass_complete':sum(r['terminal_pass'] for r in sub),'full_safe':sum(r['full_safe'] for r in gr),
                    'timing_qualified_complete':sum(r['timing_qualified'] for r in sub),'timing_qualified_safe':sum(r['timing_qualified_safe'] for r in gr),
                    'numerical_incomplete':sum(r['numerical_incomplete'] for r in sub),'NOT_RUN':sum(r['status']=='NOT_RUN' for r in sub),
                    'statuses':dict(Counter(r['status'] for r in sub))})
    paired=[]
    for p in plans():
        for name,_ in BRANCHES:
            a=next(r for r in rows if r['source_state_id']==p['source_state_id'] and r['representation']==REPRESENTATIONS[0] and r['branch']==name)
            b=next(r for r in rows if r['source_state_id']==p['source_state_id'] and r['representation']==REPRESENTATIONS[1] and r['branch']==name)
            both=bool(a['complete_501'] and b['complete_501'] and a['observed'] and b['observed'])
            item={'source_state_id':p['source_state_id'],'episode':p['episode'],'branch':name,'both_complete_ACTUAL':both,
                'FULL_status':a['status'],'REDUCED_status':b['status'],'missing_not_zero_filled':True}
            for key in ('D_m','progress02_04_m'):
                item['FULL_'+key]=a[key] if both and finite(a[key]) else None
                item['REDUCED_'+key]=b[key] if both and finite(b[key]) else None
                item['REDUCED_minus_FULL_'+key]=b[key]-a[key] if both and finite(a[key]) and finite(b[key]) else None
            paired.append(item)
    paired_latency=[]
    for p in plans():
        a=next(r for r in packet_rows if r['source_state_id']==p['source_state_id'] and r['representation']==REPRESENTATIONS[0])
        b=next(r for r in packet_rows if r['source_state_id']==p['source_state_id'] and r['representation']==REPRESENTATIONS[1])
        paired_latency.append({'source_state_id':p['source_state_id'],'episode':p['episode'],'both_packets_recorded':a['recorded'] and b['recorded'],
            'FULL_packet_ready_ms':a['packet_ready_ms'],'REDUCED_packet_ready_ms':b['packet_ready_ms'],
            'REDUCED_minus_FULL_ms':b['packet_ready_ms']-a['packet_ready_ms'] if finite(a['packet_ready_ms']) and finite(b['packet_ready_ms']) and a['recorded'] and b['recorded'] else None})
    mechanisms=[]
    for rep in REPRESENTATIONS:
        for p in plans():
            group={r['branch']:r for r in rows if r['source_state_id']==p['source_state_id'] and r['representation']==rep}
            for gap in GAPS:
                gg={r['branch']:r for r in gap_rows if r['source_state_id']==p['source_state_id'] and r['representation']==rep and r['gap_mm']==round(gap*1000)}
                C,M,B=group['C'],group['MIDDLE'],group['B']
                C_actual_unsafe=bool(C['complete_501'] and (not C['physical_pass'] or not C['terminal_pass'] or gg['C']['complete_local_failure']))
                progress_better=bool(finite(M['progress02_04_m']) and finite(B['progress02_04_m']) and M['progress02_04_m']>B['progress02_04_m'])
                extension=bool(gg['MIDDLE']['full_safe'] and gg['B']['full_safe'] and C_actual_unsafe and progress_better)
                mechanisms.append({'source_state_id':p['source_state_id'],'episode':p['episode'],'representation':rep,'gap_mm':round(gap*1000),
                    'middle_safe':gg['MIDDLE']['full_safe'],'B_safe':gg['B']['full_safe'],'C_actual_complete_unsafe':C_actual_unsafe,
                    'middle_progress_higher_than_B':progress_better,'DIRECT_extension':extension,
                    'timing_qualified_extension':bool(extension and M['timing_qualified'] and B['timing_qualified'] and C['timing_qualified']),
                    'utility_tradeoff_C_and_B_safe':bool(gg['C']['full_safe'] and gg['B']['full_safe']),
                    'M_progress02_04_m':M['progress02_04_m'],'B_progress02_04_m':B['progress02_04_m'],
                    'numerical_missing_is_not_C_unsafe':True})
    mechanism_summary=[]
    for rep in REPRESENTATIONS:
        for gap in GAPS:
            sub=[r for r in mechanisms if r['representation']==rep and r['gap_mm']==round(gap*1000) and r['DIRECT_extension']]
            timed=[r for r in sub if r['timing_qualified_extension']]
            nstates=len({r['source_state_id'] for r in sub});neps=len({r['episode'] for r in sub})
            mechanism_summary.append({'representation':rep,'gap_mm':round(gap*1000),'distinct_source_states':nstates,'episodes':neps,
                'status':'DIRECT_SAFE_ACTION_EXTENSION_OBSERVED' if nstates>=2 and neps>=2 else 'NOT_ESTABLISHED',
                'timing_qualified_states':len({r['source_state_id'] for r in timed}),'timing_qualified_episodes':len({r['episode'] for r in timed})})
    qp=[];unavailable=[]
    for path in sorted((out/'raw_qp').glob('QP*.json')):
        doc=read(path)['record'];r=doc['raw_result'];proof=r.get('candidate_certificate') or {};basis=r.get('step37_basis') or {}
        qp.append({'global_qp_index':doc['global_qp_index'],'kind':doc['kind'],'owner':doc['owner'],
            'representation':r.get('step37_representation'),'raw_status':r.get('status_val'),'candidate_valid':proof.get('candidate_valid'),
            'workspace_reused':r.get('workspace_reused'),'warm_started':r.get('warm_started'),
            'native_dimensions':r.get('step37_native_dimensions'),'native_x_shape':(r.get('step37_native_x') or {}).get('shape'),
            'native_y_shape':(r.get('step37_native_y') or {}).get('shape'),'physical_x_shape':(r.get('step37_physical_x') or {}).get('shape'),
            'original_equations_raw_residual_inf':(proof.get('raw_hard_check') or {}).get('dynamics_residual_inf'),
            'original_contact_raw_residual_inf':(proof.get('raw_hard_check') or {}).get('contact_residual_inf'),
            'native_primal_residual':r.get('native_primal_residual'),'native_dual_residual':r.get('native_dual_residual'),
            'native_residual_scope':r.get('native_residual_scope'),'rank':basis.get('rank'),'rank_tolerance':basis.get('rank_tolerance'),
            'QR_ms':basis.get('qr_ms',0.),'whitening_ms':basis.get('whitening_ms',0.),'transform_ms':r.get('step37_prepare_ms'),
            'native_solve_ms':r.get('solve_wall_time_s',0.)*1000,'native_setup_ms':r.get('setup_time_s',0.)*1000,
            'native_update_ms':r.get('update_time_s',0.)*1000,'reconstruction_ms':r.get('step37_reconstruction_ms'),
            'assembly_ms':r.get('kernel_assembly_ms'),'decode_ms':r.get('kernel_decode_ms'),'native_limit_s':r.get('osqp_time_limit_s'),
            'owner_pid':r.get('owner_pid'),'owner_id':r.get('solver_owner_id'),'raw_path':relative(path,out),
            'failed_raw_rows':((proof.get('raw_hard_check') or {}).get('failed_row_indices') or {}).get('shape'),
            'failed_sent_rows':((proof.get('sent_hard_check') or {}).get('failed_row_indices') or {}).get('shape')})
    for path in sorted((out/'unavailable_qp').glob('*.json')):
        doc=read(path)['record'];r=doc['raw_result']
        unavailable.append({'kind':doc['kind'],'owner':doc['owner'],'representation':r.get('step37_representation'),
            'status':r.get('status'),'reason':r.get('representation_unavailable_reason'),'new_QP_calls':0,'path':relative(path,out)})
    rep_stats=[]
    for rep in REPRESENTATIONS:
        sub=[r for r in qp if r['representation']==rep];pk=[r for r in packet_rows if r['representation']==rep]
        rep_stats.append({'representation':rep,'QP_calls':len(sub),'raw_statuses':dict(Counter(str(r['raw_status']) for r in sub)),
            'candidate_valid':sum(bool(r['candidate_valid']) for r in sub),'workspace_reused':sum(bool(r['workspace_reused']) for r in sub),
            'warm_started':sum(bool(r['warm_started']) for r in sub),'packet_ready_ms':statistics(r['packet_ready_ms'] for r in pk),
            'QR_ms_all_calls':statistics(r['QR_ms'] for r in sub),'whitening_ms_all_calls':statistics(r['whitening_ms'] for r in sub),
            'transformation_ms_all_calls':statistics(r['transform_ms'] for r in sub),
            'native_solve_ms_all_calls':statistics(r['native_solve_ms'] for r in sub),
            'reconstruction_ms_all_calls':statistics(r['reconstruction_ms'] for r in sub)})
    for name,data in (('BRANCH_RESULTS',rows),('GAP_RESULTS',gap_rows),('REPRESENTATION_BRANCH_SUMMARY',summaries),
        ('PACKET_RESULTS',packet_rows),('FIRST_PACKET_EQUIVALENCE',eq_rows),('STARTUP_RESULTS',startup),
        ('PAIRED_RECOVERY_RESULTS',paired),('PAIRED_PACKET_LATENCY',paired_latency),
        ('DIRECT_MECHANISM_RESULTS',mechanisms),('DIRECT_MECHANISM_SUMMARY',mechanism_summary),
        ('QP_REPRESENTATION_RESULTS',qp),('REPRESENTATION_QP_LATENCY_SUMMARY',rep_stats),('REDUCTION_UNAVAILABLE_RESULTS',unavailable)):
        dump(out,name,data)
    completed=finished['status']=='COMPLETED'
    direct=any(r['status']=='DIRECT_SAFE_ACTION_EXTENSION_OBSERVED' for r in mechanism_summary)
    result={'run_id':run_id,'source_commit':PARENT,'NUMERICAL_STATUS':finished['status'],
        'DIRECT_MECHANISM_STATUS':'DIRECT_SAFE_ACTION_EXTENSION_OBSERVED' if direct else 'NOT_ESTABLISHED',
        'OVERALL_STATUS':'DIRECT_MECHANISM_OBSERVED_WITH_SEPARATE_TIMING' if completed and direct else 'FAIL / REVISE' if completed else 'INCOMPLETE',
        'MODEL_AUTHORIZED_GOVERNOR':'NOT_ESTABLISHED_NOT_RUN','model_authorized_sent_packets':0,'new_model_fits':0,
        'new_CAL_actions':0,'new_reference_solves':0,'new_reference_steps':0,'old_cold_probe_gate_used':False,
        'source_state_health_contexts':16,'physical_snapshots':8,'episodes':4,'planned_ACTUAL_branches':96,
        'branch_results':len(rows),'observed_ACTUAL_branches':sum(r['observed'] for r in rows),'complete_501_branches':sum(r['complete_501'] for r in rows),
        'NOT_RUN_branches':sum(r['status']=='NOT_RUN' for r in rows),'numerical_incomplete_branches':sum(r['numerical_incomplete'] for r in rows),
        'branch_statuses':dict(Counter(r['status'] for r in rows)),'representations':REPRESENTATIONS,'summaries':summaries,
        'QP_statistics':rep_stats,'mechanism_summary':mechanism_summary,'raw_QP_shards':len(qp),
        'reduction_unavailable_no_solver_calls':len(unavailable),'budget':finished['budget'],
        'implementation_repairs_used':len(list((out/'repairs').glob('REPAIR_*_STARTED.json'))),
        'necessary_tests':read(out/'tests/NECESSARY_TESTS.json'),'current_delivery_check':read(out/'tests/CURRENT_DELIVERY_CHECK.json',{}),
        'saved_only_analysis_new_QP_calls':0,'saved_only_analysis_new_steps':0,'historical_results_unchanged':True,
        'initial_startup_raw_evidence_gap':read(out/'repairs/INTERFACE_REPAIR_01.json',{}).get('returned_startup_QP_full_raw_missing',[]),
        'full_raw_evidence_all_calls':len(qp)==finished['budget']['total_QP_calls'],
        'figure_count':2 if (out/'figures/STEP37_all_actual_trajectories.pdf').exists() else 0,
        'all_scientific_packet_feedback_raw_shards_preserved':True,
        'targeted_IO_repair_test':read(out/'tests/TARGETED_IO_REPAIR.json',{}),
        'software_budget_timing_not_asynchronous_feedback_delay_validation':True,'E3_RL_HARDWARE':'NOT_AUTHORIZED'}
    write(out/'STEP37_RESULT.json',result);write_reports(out,result,manifest)
    print({k:result[k] for k in ('NUMERICAL_STATUS','DIRECT_MECHANISM_STATUS','observed_ACTUAL_branches','complete_501_branches','OVERALL_STATUS')})
    return result

def write_reports(out,r,manifest):
    protocol=read_protocol_lines()
    lines=['# STEP37：等式消元、目标白化与直接配对恢复','','## Material Passport','',
        'experiment-agent / numerical representation + direct mechanism experiment / 2026-10-10 / Asia/Seoul / ANALYZED。','',
        '## 结果','',f"数值批次：{r['NUMERICAL_STATUS']}；直接机制：{r['DIRECT_MECHANISM_STATUS']}。",
        f"固定96分支中实际运行{r['observed_ACTUAL_branches']}，完整501状态{r['complete_501_branches']}，NOT_RUN {r['NOT_RUN_branches']}，数值未完成{r['numerical_incomplete_branches']}。全部失败保留。",
        'REDUCED的C/.5/B各16/16完成1s，共48/48；FULL完整16/48、数值未完成12/48、不可用20/48。6mm处REDUCED直接安全扩展为6state/2episode，8mm处2state/2episode；4mm未建立。首包ready中位数FULL15.222ms、REDUCED11.436ms。',
        '本轮是直接offline反事实，不读取模型/CAL、不建立学习governor认可发送。selected_command_sent=False；没有新reference求解/积分、fit或CAL。','',
        '## 两种表示与原契约','',
        'FULL：42变量/80行；RED：pivoted完整QR消30等式，再无正则Cholesky保目标白化为12变量/50不等式。标准仿射替换依据[Boyd与Vandenberghe讲义](https://see.stanford.edu/materials/lsocoee364a/11EqualityMin.pdf)，不将线性代数本身称论文原创。',
        '两个表示同工作集合：16切向摩擦upper−1e-4N，12torque box各边内缩1e-4Nm；原P/q/A、physical界、μ、PID/health和物理评价器保持。rank规则按机器精度/维度/QR尺度固定；rank不足/SPD失败/空box记不可用，不伪逆、正则、扫参或换solver。',
        'Pr由实际T.T P T计算，仅浮点对称化，不强设I。原raw/sent完整42维分别用原SI行、零额外slack和精确容量核验；native ξ12/dual50不冒充physical42/完整等式dual。相同原inequality row顺序下dual继承，缺少的30 equalitydual不伪造。',
        '每tick重新QR/白化计入本次准备成本；warm-start由本分支已接受physical witness映射新坐标，不能盲复用旧ξ。每source/表示/C/.5/B owner独立，startup健康home；B0由实际B owner生成，仅恢复同owner physical/native/basis/PID checkpoint。C/.5仅以自己已施加sent witness作初值，无跨owner内态复制。',
        '输入是已知修复队列：16 state-health contexts、8 physical snapshots、4 episode；方向同时决定front/rear fault，不推断独立方向效应，也不称未触碰holdout。','',
        '## 恢复与时延分别计数','',
        '| 表示 | 分支 | gap mm | 候选/16 | 实际/16 | 完整/16 | full safe/16 | timing-qualified safe/16 |',
        '|---|---|---:|---:|---:|---:|---:|---:|']
    for s in r['summaries']:
        lines.append(f"| {s['representation']} | {s['branch']} | {s['gap_mm']} | {s['candidate_available']} | {s['observed_ACTUAL']} | {s['complete_501']} | {s['full_safe']} | {s['timing_qualified_safe']} |")
    lines+=['','4/6/8mm是同一保存轨迹的三种评价，不重复传播、不当三个独立样本。numerical/NOT_RUN不填0，不替代物理失败。按原模型和current候选传播，失败候选在ctrl/forward/积分前停止，没有零命令补齐。',
        'sample0→prehold0–.02→诊断τ .02–.04→48反馈 .04… .98→终点1.000；2ms dense/500步/501状态/21checkpoints及原anchor不变。没有筛选Gamma prefix，仅application10步预测。',
        '超20ms首包仍offline传播，标LATE_FIRST_PACKET_OFFLINE_ONLY，固定虚拟首动作时刻.02并非可实现在线时序。后续feedback≤20ms独立列出，没有每tick另加等待传播。timing-qualified是软件预算与既定首包时序联合检查，不是完整异步反馈延迟验证。','',
        '## 直接动作集合机制','',
        '| 表示 | gap mm | 独立state | episode | 状态 | 同时timing-qualified state |',
        '|---|---:|---:|---:|---|---:|']
    for s in r['mechanism_summary']:
        lines.append(f"| {s['representation']} | {s['gap_mm']} | {s['distinct_source_states']} | {s['episodes']} | {s['status']} | {s['timing_qualified_states']} |")
    lines+=['','判据：至少两个state/两个episode，中间完整physical+terminal+local安全，B也安全，中间.02–.04任务进度更高，C有完整实测物理/局部/终端违反。C数值未完成不算C不安全；C/B皆安全仅记效用折中。99%容量与积分冻结独立保留，不增shadow。','',
        '## 配对与证据','',
        '首包同问题对应见[FIRST_PACKET_EQUIVALENCE](FIRST_PACKET_EQUIVALENCE.json)。之后反馈state随真实轨迹分化，不能把后续每tick视作同矩阵solver benchmark。连续D/进度只在同branch两表示实际且完整时配对；不填missing。',
        '全96位：[BRANCH_RESULTS](BRANCH_RESULTS.csv)；288个gap评价：[GAP_RESULTS](GAP_RESULTS.csv)；配对恢复：[PAIRED_RECOVERY_RESULTS](PAIRED_RECOVERY_RESULTS.csv)；配对首包时延：[PAIRED_PACKET_LATENCY](PAIRED_PACKET_LATENCY.csv)。',
        'native/physical/映射和原工作问题保存在raw_qp lossless json/npz，轨迹与controls位于states/<runtime>/<representation>/<branch>/。容量/99%/积分在每branch events保存；未追加shadow、teacher或其它gamma。',
        '每阶段QR/白化/native/setup/update/重构/原decode：[QP_REPRESENTATION_RESULTS](QP_REPRESENTATION_RESULTS.csv)；初始化可用与priming命令有效分别见[STARTUP_RESULTS](STARTUP_RESULTS.csv)。',
        'SciPilot按全数据EDA选择96位结果矩阵/配对时延与六分面全部实际轨迹，不用均值柱遮蔽失败；8pt、IEEE双栏7.16in、PDF/SVG/600dpiPNG，并完成程序与彩图/灰度读图复核。图：[全结果与首包时延](figures/STEP37_all_outcomes_latency.pdf)、[全部实际轨迹](figures/STEP37_all_actual_trajectories.pdf)。',
        f"累计预算：{r['budget']}。DEV接口修复{r['implementation_repairs_used']}/2，必要suite6/6，仅本轮fixture；保存后分析无新QP/积分。", '',
        '第8来源初始化期间进度文件原子替换遇到Windows共享锁。第一次DEV修复只给当前metadata原子替换增加文件级等待，不改数值路径或阈值；保持原时钟/累计预算，前7来源未重算。只重建尚未产生首包的第8来源resident初始化；旧初始化attempt和原短账本保留。定点IO fixture通过，未重跑整个suite。',
        f"该文件异常前已返回的5个startup调用（{r['initial_startup_raw_evidence_gap']}）未成功写出完整raw NPZ；短账本实际status/时延/owner仍保存，不能补算冒充旧raw。全部正式首包和feedback的raw仍保存。完整raw分片数与累计QP数相差5，明确不是UNKNOWN调用、不是全raw完备。", '',
        '## 研究交接与边界','',
        '直接恢复、软件时延与学习筛选结论分开；MODEL_AUTHORIZED_GOVERNOR未建立，本轮并未尝试。无连续安全、global viability或硬件实时声明。后续若校准学习筛选，需要新授权和独立新状态；本轮不追加。',
        '旧STEP36及历史结果不改写；与机器人运控算法隔离。当前文件读回/scoped diff各一次，独立分支提交、不push、不reset原HEAD。','',
        '## 协议状态','','~~~ini',protocol,f"NUMERICAL_STATUS = {r['NUMERICAL_STATUS']}",
        f"DIRECT_MECHANISM_STATUS = {r['DIRECT_MECHANISM_STATUS']}",f"OVERALL_STATUS = {r['OVERALL_STATUS']}",
        f"OBSERVED_ACTUAL_BRANCHES = {r['observed_ACTUAL_branches']}",f"COMPLETE_501_BRANCHES = {r['complete_501_branches']}",
        'MODEL_AUTHORIZED_GOVERNOR = NOT_ESTABLISHED_NOT_RUN','~~~','']
    (out/'STEP37_REPORT.md').write_text('\n'.join(lines),encoding='utf-8',newline='\n')
    handoff=['# STEP37研究交接','','## Material Passport','',
        'experiment-agent / direct counterfactual representation comparison / 2026-10-10 / Asia/Seoul / ANALYZED。','',
        f"批次{r['NUMERICAL_STATUS']}；直接机制{r['DIRECT_MECHANISM_STATUS']}。固定96位实际{r['observed_ACTUAL_branches']}、完整{r['complete_501_branches']}；失败/不可用不删除。",
        '两表示同保守工作集合，原physical零slack不改。QR/白化每tick收费，native与physical明确区分，独立resident branch及B0记忆同owner恢复。',
        '直接恢复结果、20ms时延和学习筛选是三个独立结论。本轮没有模型认可或CAL/训练，不称已部署governor。后续研究应在新授权下校准并使用独立新队列，而不是按当前结果调参重试。',
        '16contexts共享8physical snapshot，四episode；三gap重复评价同轨迹而非独立样本。数值未完成不算C不安全。',
        '[完整报告](STEP37_REPORT.md) · [结果](STEP37_RESULT.json) · [逐分支表](BRANCH_RESULTS.csv)。',
        '工作树 E:/CAVR-WBC/cavr_step17_formal_panel_targeted_repair_20260923；独立分支 codex/step37-reduced-direct-recovery-20261010；未push/reset原HEAD。','',
        '~~~ini',protocol,f"DIRECT_MECHANISM_STATUS = {r['DIRECT_MECHANISM_STATUS']}",'~~~','']
    (out/'STEP37_RESEARCH_HANDOFF.md').write_text('\n'.join(handoff),encoding='utf-8',newline='\n')

def read_protocol_lines():
    import re
    text=PROTOCOL.read_text(encoding='utf-8')
    return re.search(r'```ini\n(.*?)```',text,re.S).group(1).strip()

if __name__=='__main__':analyze()
