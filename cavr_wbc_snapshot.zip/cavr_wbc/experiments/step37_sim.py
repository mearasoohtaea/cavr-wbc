"""Independent sample-clock propagation of an already computed STEP34 packet.

Only feedback slots are solved here.  Prehold, endpoint commands and B0's
logical/primal/dual memory belong to the original packet; actual evidence is
never used to replace its predicted application state or select another action.
"""
from __future__ import annotations

from copy import deepcopy
from time import perf_counter

import mujoco
import numpy as np

from cavr_wbc.control.step37_actions import GAMMA_GRID, check_rows
from cavr_wbc.control.step34_candidate import VERSION as CANDIDATE_VERSION, status_eligible
from cavr_wbc.experiments import step29_sim as source
from cavr_wbc.experiments.step31_sim import capture_packet_memory, _workspace_id

VERSION = 'STEP37_UNCHANGED_FEASIBLE_SAME_PACKET_ACTUAL_V1'
STATE_FIELDS = ('qpos', 'qvel', 'act', 'ctrl', 'qacc_warmstart', 'qfrc_applied',
                'xfrc_applied', 'mocap_pos', 'mocap_quat', 'userdata', 'plugin_state')


def _not_run(sample, packet, purpose, reason, action=None):
    state = deepcopy(sample.get('state', sample.get('source_state', {})))
    return {'schema': VERSION, 'kind': 'ACTUAL_C', 'status': 'NOT_RUN',
        'branch_id': sample['context_id'] + ':' + packet.get('method', 'STEP34') + ':' + purpose,
        'branch_purpose': purpose, 'reason': {'reason': reason},
        'gamma': None if action is None else action.get('gamma'), 'method': packet.get('method'),
        'backup_id': sample['backup_id'], 'fixed_anchor_q_init': deepcopy(sample['backup_anchor_q_init']),
        'health_vector': deepcopy(sample['health_vector']), 'initial_state': state,
        'final_state': deepcopy(state), 'initial_fact': None, 'controls': [],
        'physics_trajectory': [], 'checkpoints': [], 'solver_ledger': [],
        'same_packet_used': True, 'new_governor_calls': 0, 'new_endpoint_QP_calls': 0,
        'selected_application_time_s': .020, 'horizon_s': 1.,
        'all_available_ticks_within_20ms': False, 'application_identity_pass': None,
        'progress0_04_m': None, 'progress02_04_m': None,
        'counts': {'physical_steps': 0, 'feedback_QP_calls': 0, 'new_feedback_QP_calls': 0,
            'control_qp_calls': 0, 'backup_qp_calls': 0, 'packet_B0_reused_count': 0,
            'clone_data_calls': 0, 'endpoint_QP_calls_new': 0, 'governor_calls_new': 0}}


def _action_reason(sample, packet, action, require_sent):
    if sample.get('eligible') is False:
        return 'CONTEXT_NOT_ELIGIBLE'
    if require_sent and not packet.get('selected_command_sent'):
        return 'PACKET_NOT_TIMELY_RECOGNIZED_SENT'
    if packet.get('context_id') != sample['context_id']:
        raise ValueError('STEP34 packet/sample identity mismatch')
    if not action or not action.get('command_valid'):
        return 'PACKET_ACTION_UNAVAILABLE'
    gamma = float(action.get('gamma', float('nan')))
    if gamma not in GAMMA_GRID:
        raise ValueError('STEP34 packet action gamma differs from the frozen grid')
    latency = float(packet.get('command_ready_ms', float('nan')))
    if not np.isfinite(latency) or latency < 0.:
        raise ValueError('STEP34 packet command-ready timestamp is invalid')
    if require_sent and latency > 20.:
        raise ValueError('STEP34 a sent packet violates the absolute 20 ms deadline')
    if not packet.get('prehold') or not packet.get('context_used'):
        return 'PACKET_PREHOLD_OR_WITNESS_STATE_UNAVAILABLE'
    return None


def _validate_prehold(sample, packet, limits):
    """Validate the frozen hold already constructed inside command-ready."""
    hold = packet['prehold']
    health = np.asarray(sample['health_vector'], dtype=float)
    raw = np.asarray(hold.get('tau_raw'), dtype=float)
    sent = np.asarray(hold.get('tau_sent'), dtype=float)
    state = sample.get('state', sample.get('source_state'))
    identity = hold.get('previous_command_identity') or {}
    if (hold.get('source') != 'LAST_COMMAND_HEALTH_CLIPPED' or
        not hold.get('command_valid') or hold.get('solver_status_val') is not None or
        hold.get('new_QP_calls', 0) != 0 or identity.get('available') is not True or
        raw.shape != health.shape or sent.shape != health.shape or
        not np.isfinite(raw).all() or not np.isfinite(sent).all() or
        not np.array_equal(hold.get('health_vector'), health) or
        not np.array_equal(hold.get('healthy_torque_limits_nm'), limits) or
        not np.array_equal(hold.get('effective_capacity_nm'), health * limits) or
        not np.array_equal(raw, state['ctrl']) or
        not np.array_equal(raw, identity.get('tau_sent')) or
        not np.array_equal(sent, np.clip(raw, -health * limits, health * limits))):
        raise ValueError('STEP34 frozen prehold source/health/capacity identity mismatch')
    interface = dict(hold, solver_exact_solved=False, certified_backup=False,
        saturation_mask=np.not_equal(raw, sent), correction_nm=sent - raw,
        raw_command_within_capacity_exact=bool(np.all(np.abs(raw) <= health * limits)),
        sent_command_within_capacity_exact=bool(np.all(np.abs(sent) <= health * limits)),
        raw_99_percent_active_indices=np.flatnonzero((health * limits <= 0.) | (np.abs(raw) >= .99 * health * limits)),
        sent_99_percent_active_indices=np.flatnonzero((health * limits <= 0.) | (np.abs(sent) >= .99 * health * limits)))
    return interface


def _candidate_interface(action, health, limits):
    interface = action.get('capacity_interface') or {}
    proof = action.get('candidate_certificate') or {}
    raw, sent = np.asarray(action.get('tau_raw')), np.asarray(action.get('tau_sent'))
    capacity = np.asarray(health) * np.asarray(limits)
    if not (action.get('command_valid') and proof.get('schema') == CANDIDATE_VERSION and proof.get('candidate_valid') and
        raw.shape == sent.shape == capacity.shape and np.isfinite(raw).all() and np.isfinite(sent).all() and
        np.array_equal(sent, np.clip(raw, -capacity, capacity)) and np.all(np.abs(raw) <= capacity) and
        np.array_equal(interface.get('tau_raw'), raw) and np.array_equal(interface.get('tau_sent'), sent) and
        np.array_equal(interface.get('health_vector'), health) and
        np.array_equal(interface.get('healthy_torque_limits_nm'), limits)):
        raise ValueError('STEP34 same-packet current candidate/capacity proof mismatch')
    if action.get('kind') == 'SYNTHESIZED_CONVEX_COMMAND':
        if not (action.get('solver_status_val') is None and action.get('shared_A_l_u_exact') and
            all(status_eligible(action.get('source_solver_statuses', {}).get(k)) for k in ('C', 'B'))):
            raise ValueError('STEP34 mixed first command source status/candidate proof mismatch')
    elif not status_eligible(action.get('solver_status_val')):
        raise ValueError('STEP34 endpoint raw optimizer status is not eligible')
    matrix = action.get('source_matrices')
    z, sent_z = np.asarray(action.get('z_raw')), np.asarray(action.get('z_sent'))
    if not (matrix and check_rows(matrix, z)['pass'] and check_rows(matrix, sent_z)['pass']):
        raise ValueError('STEP34 first command full raw/sent witness rejected')
    return interface


def _validate_ready(B, health, limits):
    raw = B.get('wbc', B.get('raw_solver_result', {}))
    proof = raw.get('candidate_certificate') or {}
    interface = B.get('capacity_interface') or {}
    if not (B.get('valid_command') and proof.get('schema') == CANDIDATE_VERSION and proof.get('candidate_valid') and
        proof.get('raw_optimizer_status') == raw.get('status_val') and status_eligible(raw.get('status_val')) and
        np.array_equal(interface.get('tau_raw'), proof.get('tau_raw')) and
        np.array_equal(B.get('tau_cmd'), proof.get('tau_sent')) and
        np.array_equal(interface.get('tau_sent'), proof.get('tau_sent')) and
        np.array_equal(interface.get('health_vector'), health) and
        np.array_equal(interface.get('healthy_torque_limits_nm'), limits) and
        proof.get('raw_hard_check', {}).get('pass') and proof.get('sent_hard_check', {}).get('pass') and
        np.array_equal(B.get('integral_record', {}).get('b_used'), np.zeros(6))):
        raise ValueError('STEP34 original B0 current feasible-candidate readiness mismatch')



def _restore_b0_memory(kernel, sample, packet, action):
    """Restore B0 memory only; never overwrite the already advanced actual data."""
    B = packet.get('B') or {}
    required = ('capacity_interface', 'tau_cmd', 'integral_record', 'valid_command')
    memory = packet.get('step31_backup_memory') or {}
    if any(key not in B for key in required) or memory.get('status') != 'CAPTURED_B0':
        return None
    _validate_ready(B, np.asarray(sample['health_vector']), np.asarray(kernel.healthy_limits))
    if (memory.get('context_id') != sample['context_id'] or
        memory.get('backup_id') != sample['backup_id'] or
        not np.array_equal(memory['integral_b_after'], B['integral_record']['b_after']) or
        not np.array_equal(B['tau_cmd'], action['tau_sent'])):
        raise ValueError('STEP34 application B0 packet/memory identity mismatch')
    kernel.backup_servo.b_integral[:] = memory['integral_b_after']
    kernel._backup_context_id = str(sample['context_id'])
    kernel._last_backup_slot = 0
    kernel._last_backup_response = B
    if hasattr(kernel, 'identity'):
        kernel.identity = (sample['context_id'], sample['backup_id'])
    caches = getattr(getattr(kernel, 'backup_controller', None), '_solver_cache', {})
    by_id = {_workspace_id(key): cache for key, cache in caches.items()}
    for saved in memory['workspaces']:
        if saved['workspace_id'] not in by_id:
            raise ValueError('STEP34 original B0 solver workspace missing')
        cache = by_id[saved['workspace_id']]
        x = None if saved['last_x'] is None else np.asarray(saved['last_x']).copy()
        y = None if saved['last_y'] is None else np.asarray(saved['last_y']).copy()
        cache.update(last_x=x, last_y=y, independent_case_zeroed=False)
        if x is not None or y is not None:
            cache['solver'].warm_start(x=x, y=y)
    physical_restore = None
    if hasattr(kernel.backup_controller, 'restore_physical_memory'):
        physical_memory = packet.get('step37_B0_physical_memory')
        if not physical_memory:
            raise ValueError('STEP37 B0 physical/native/basis checkpoint missing')
        physical_restore = kernel.backup_controller.restore_physical_memory(physical_memory)
    return {'physical_native_basis_restore': physical_restore,
        'no_cross_owner_native_internal_state_copy': True,
        'status': 'RESTORED_APPLICATION_PACKET_B0', 'logical_last_slot': 0,
        'integral_b_used': np.asarray(memory['integral_b_used']).copy(),
        'integral_b_after': np.asarray(memory['integral_b_after']).copy(),
        'primal_dual_workspaces_restored': len(memory['workspaces']),
        'physical_application_state_not_replaced': True, 'new_QP_calls': 0}


def _application_check(sample, packet, actual):
    prediction = packet.get('application_prediction') or {}
    saved = prediction.get('state')
    if actual is None or not prediction.get('complete') or not saved:
        return {'checked': False, 'pass': False, 'reason': 'APPLICATION_STATE_UNAVAILABLE',
            'actual_state_read_before_selection': False}
    fields = {}
    signature = int(mujoco.mjtState.mjSTATE_INTEGRATION)
    for name in ('integration_state',) + STATE_FIELDS:
        a = np.asarray(actual.get(name), dtype=float)
        p = np.asarray(saved.get(name), dtype=float)
        # JSON lists cannot retain the trailing dimensions of an empty named
        # MuJoCo array.  Canonicalize only those zero-element named fields;
        # the complete integration vector still requires its exact shape.
        canonical_empty = bool(name != 'integration_state' and a.size == p.size == 0)
        comparable = bool((a.shape == p.shape or canonical_empty) and
                          np.isfinite(a).all() and np.isfinite(p).all())
        fields[name] = {'pass': bool(comparable and np.array_equal(a.ravel(), p.ravel())),
            'shape_actual': list(a.shape), 'shape_prediction': list(p.shape),
            'canonical_empty': canonical_empty,
            'max_abs_difference': float(np.max(np.abs(a - p))) if comparable and a.size else 0. if comparable else None}
    anchor = np.asarray(sample['backup_anchor_q_init'])
    context_anchor = np.asarray(packet['context_used'].get('backup_anchor_q_init'))
    signature_pass = actual.get('integration_state_signature') == signature == saved.get('integration_state_signature')
    anchor_pass = bool(np.array_equal(anchor, context_anchor))
    matched = bool(signature_pass and anchor_pass and all(row['pass'] for row in fields.values()))
    return {'checked': True, 'pass': matched, 'integration_state_signature_pass': signature_pass,
        'original_anchor_pass': anchor_pass, 'fields': fields,
        'check_time_s': .020, 'comparison': 'EXACT_FULL_INTEGRATION_STATE',
        'actual_state_read_before_selection': False, 'actual_state_replaced_prediction': False}


def propagate(kernel, sample, packet, budget, purpose='ACTUAL', action=None, require_sent=True):
    """Prehold 10 steps, same-packet 10 steps, 48 feedback slots: sample 1 s.

    DEV may pass a valid but unapproved action with ``require_sent=False``.
    Every branch restores the original sample independently.  Counterfactual
    endpoints share packet latency and never cause another first endpoint QP.
    """
    branch_name = 'B' if (action or packet.get('selected_action') or {}).get('gamma') == 0. else 'C' if (action or packet.get('selected_action') or {}).get('gamma') == 1. else 'MIDDLE'
    if hasattr(kernel, 'solver_owner_identity'):
        allowed = packet.get('step37_branch_owners', {})
        if allowed:
            if allowed.get(branch_name) != kernel.solver_owner_identity():
                raise ValueError('STEP37 actual branch does not use its independent resident owner')
            if packet.get('representation') != kernel.representation:
                raise ValueError('STEP37 representation changed before actual branch')
        elif packet.get('step34_solver_owner') != kernel.solver_owner_identity():
            raise ValueError('same-packet owner unavailable')
    selected = packet.get('selected_action') if action is None else action
    reason = _action_reason(sample, packet, selected, require_sent)
    if reason:
        return _not_run(sample, packet, purpose, reason, selected)
    gamma = float(selected['gamma'])
    limits = np.asarray(kernel.healthy_limits, dtype=float)
    health = np.asarray(sample['health_vector'], dtype=float)
    hold = _validate_prehold(sample, packet, limits)
    witness = packet['context_used']
    if not np.array_equal(witness['health_vector'], health) or not np.array_equal(
        witness['backup_anchor_q_init'], sample['backup_anchor_q_init']):
        raise ValueError('STEP34 witness health/original anchor changed before actual')
    view = source.candidate_view(selected, witness, command_ready_ms=packet['command_ready_ms'])
    selected_interface = _candidate_interface(selected, health, limits)
    # This is post-ready memory persistence, not another controller decision.
    if 'step31_backup_memory' not in packet:
        raise ValueError('STEP37 B0 memory must be captured by its generating B owner before branches')
    if gamma == 0. and (packet.get('step31_backup_memory') or {}).get('status') != 'CAPTURED_B0':
        return _not_run(sample, packet, purpose, 'PACKET_B0_RESPONSE_OR_MEMORY_UNAVAILABLE', selected)
    begin = perf_counter()
    source._check(budget)
    bid = sample['backup_id']
    branch_id = sample['context_id'] + ':' + packet.get('method', 'STEP34') + ':' + purpose
    branch_context = dict(sample, branch_id=branch_id)
    metadata = source._metadata(branch_context, health)
    anchor = np.asarray(sample['backup_anchor_q_init'], dtype=float).copy()
    direction = float(sample.get('direction', 1. if sample['state']['qvel'][0] > 0. else -1.))
    if direction not in (-1., 1.):
        raise ValueError('STEP34 immutable sample direction must be +/-1')
    before = source._kernel_counts(kernel)
    kernel.reset_backup(kernel.data, branch_context, preserve_ready=False)
    data = kernel.backup_data
    initial = source.state_values(kernel.model, data)
    if abs(float(data.time)) > 1e-12:
        raise ValueError('STEP34 actual branch must restore relative sample clock zero')
    observer = source._observer(budget, 'ACTUAL', branch_id)
    controls, physics, checkpoints, ledger = [], [], [], []
    steps = action_forward = refresh = 0
    initial_fact = failure = application_state = None
    first_feedback_ms = control_ms = integration_s = refresh_s = fact_s = 0.
    memory_restore = {'status': 'INDEPENDENT_ZERO_INTEGRAL_RESET', 'new_QP_calls': 0}
    for slot in range(50):
        _, guard = source._budget_call(lambda: source._check(budget))
        if guard is not None:
            failure = dict(guard, slot=slot, physics_step=steps)
            break
        if not source._finite_state(data):
            failure = {'reason': 'NONFINITE_STATE_BEFORE_CONTROL', 'slot': slot, 'physics_step': steps}
            break
        response = None
        logical_slot = None
        if slot == 0:
            interface = hold
            tau = np.asarray(hold['tau_sent'])
            raw_wb = {'status': 'LAST_COMMAND_HEALTH_CLIPPED', 'status_val': None}
            valid, ms, ref = True, 0., 0.
            source_name = 'LAST_COMMAND_HEALTH_CLIPPED'
        elif slot == 1:
            if gamma == 0.:
                memory_restore = _restore_b0_memory(kernel, sample, packet, selected)
                if memory_restore is None:
                    failure = {'reason': 'PACKET_B0_RESPONSE_OR_MEMORY_UNAVAILABLE', 'slot': slot, 'physics_step': steps}
                    break
                response = packet['B']
            interface = selected_interface
            tau = np.asarray(selected['tau_sent'])
            raw_wb = view['raw_solver_result']
            valid, ms = True, float(packet['command_ready_ms'])
            ref = float(selected['a_base_ref'][0]) if selected.get('a_base_ref') is not None else 0.
            source_name = 'SAME_PACKET_TAU_AT_APPLICATION_20MS'
        else:
            logical_slot = slot - 1
            if slot == 2 and gamma != 0. and hasattr(kernel.backup_controller, 'seed_applied_witness'):
                kernel.backup_controller.seed_applied_witness(selected['z_sent'])
                memory_restore = {'status': 'OWN_BRANCH_APPLIED_PHYSICAL_WITNESS_SEED',
                    'physical_z': np.asarray(selected['z_sent']).copy(), 'new_QP_calls': 0,
                    'source': 'THIS_BRANCH_ALREADY_APPLIED_SENT_WITNESS',
                    'foreign_native_x_y_internal_state_copied': False}
            if hasattr(kernel, 'configure_feedback'):
                kernel.configure_feedback(sample)
            else:
                kernel.set_next_call_limit(.006)
            response, guard = source._budget_call(lambda: kernel.compute_backup(
                branch_context, logical_slot, budget=budget, kind='ACTUAL_B' if gamma == 0. else 'ACTUAL_C', owner=branch_id))
            if guard is not None:
                failure = dict(guard, slot=slot, physics_step=steps)
                break
            if hasattr(kernel, 'flush_raw_evidence'):
                kernel.flush_raw_evidence()
            interface = response['capacity_interface']
            raw_wb = response.get('wbc', response.get('raw_solver_result', {}))
            valid, ms = bool(response['valid_command']), float(response['command_ready_ms'])
            tau = np.asarray(response['tau_cmd']) if valid else None
            ref = float(response['a_base_ref'][0]) if len(response.get('a_base_ref', [])) else 0.
            source_name = 'FEEDBACK_BACKUP_QP_TOTAL' if valid else 'INVALID_BACKUP_QP'
            control_ms += ms
            if slot == 2:
                first_feedback_ms = ms
            ledger.extend(source._copy_ledger(response, branch_id=branch_id,
                kind='ACTUAL_B' if gamma == 0. else 'ACTUAL_C', slot=slot, bid=bid))
        if not valid:
            # The rejected candidate is preserved, but it is never a command.
            controls.append({'slot': slot, 'time_s': slot * .020, 'valid_command': False,
                'command_valid': False, 'source': source_name, 'tau_sent': None,
                'solver_status_val': raw_wb.get('status_val'),
                'raw_solver_result': deepcopy(raw_wb), 'candidate_certificate': deepcopy(raw_wb.get('candidate_certificate')),
                'capacity_interface': deepcopy(interface), 'latency_ms': ms, 'command_ready_ms': ms,
                'within_online_deadline': False, 'invalid_candidate_not_applied': True,
                'integral_record': deepcopy(response.get('integral_record')) if response else None,
                'actual_application_time_s': slot * .020, 'backup_feedback_logical_slot': logical_slot})
            failure = {'reason': 'INVALID_BACKUP_CURRENT_CANDIDATE', 'slot': slot, 'physics_step': steps,
                'solver_status': raw_wb.get('status'), 'solver_status_val': raw_wb.get('status_val'),
                'candidate_rejection_reason': (raw_wb.get('candidate_certificate') or {}).get('rejection_reason'),
                'invalid_candidate_not_applied': True, 'state': source.state_values(kernel.model, data)}
            break
        data.ctrl[:] = tau
        mujoco.mj_forward(kernel.model, data)
        action_forward += 1
        row = source._control_row(slot, source_name, tau, data, health, interface, response,
            raw_wb, valid, ms, candidate=view if slot == 1 else None)
        row.update(candidate_schema=CANDIDATE_VERSION,
            candidate_valid=True,
            optimizer_converged=raw_wb.get('optimizer_converged', raw_wb.get('status_val') == 1),
            strict_candidate_mask=raw_wb.get('strict_candidate_mask', False),
            candidate_certificate=deepcopy(raw_wb.get('candidate_certificate')),
            raw_solver_result=deepcopy(raw_wb),
            native_QP_limit_s=(packet.get('first_QP_native_limits_s', {}).get('B' if gamma == 0. else 'C')
                if slot == 1 and gamma in (0., 1.) else .006 if slot > 1 else None),
            source_endpoint_native_QP_limits_s=packet.get('first_QP_native_limits_s'),
            realtime_deployment_evidence=bool(require_sent),
            backup_feedback_logical_slot=logical_slot, actual_application_time_s=slot * .020,
            original_witness_time_s=.020,
            reused_packet_first=slot == 1, ready_command_reused=bool(slot == 1 and gamma == 0.),
            previous_command_not_new_solved_QP=slot == 0,
            packet_decision_cost_shared=slot == 1, additional_feedback_delay_simulated=False)
        if slot == 0:
            row['previous_command_identity'] = deepcopy(hold['previous_command_identity'])
            row['latency_is_already_timed_packet_prehold_component'] = True
        controls.append(row)
        if source._finite_state(data):
            t = perf_counter()
            fact = source.compact_fact(kernel.model, data, health, limits, tau, ref, ms, steps,
                slot, bid, branch_id, interface, metadata)
            fact_s += perf_counter() - t
            if slot == 0:
                initial_fact = fact
                checkpoints.append(dict(fact, checkpoint_index=0, checkpoint_target_s=0.))
        else:
            failure = {'reason': 'NONFINITE_STATE_AFTER_COMMAND_FORWARD', 'slot': slot, 'physics_step': steps}
        if failure:
            break
        for _ in range(10):
            if observer is not None:
                _, guard = source._budget_call(observer)
                if guard is not None:
                    failure = dict(guard, slot=slot, physics_step=steps)
                    break
            t = perf_counter()
            mujoco.mj_step(kernel.model, data)
            steps += 1
            integration_s += perf_counter() - t
            if not source._finite_state(data) or abs(float(data.time) - steps * .002) > 1e-9:
                failure = {'reason': 'NONFINITE_STATE_OR_SIMULATOR_RESET_AFTER_STEP', 'slot': slot, 'physics_step': steps}
            else:
                t = perf_counter()
                mujoco.mj_forward(kernel.model, data)
                refresh += 1
                refresh_s += perf_counter() - t
                if not source._finite_state(data):
                    failure = {'reason': 'NONFINITE_STATE_AFTER_INTEGRATION_REFRESH', 'slot': slot, 'physics_step': steps}
            if failure:
                physics.append({'time_s': steps * .002, 'physics_step': steps,
                    'numerical_failure': failure, 'state': source.state_values(kernel.model, data)})
                break
            t = perf_counter()
            fact = source.compact_fact(kernel.model, data, health, limits, tau, ref, ms, steps,
                slot, bid, branch_id, interface, metadata)
            fact_s += perf_counter() - t
            physics.append(fact)
            if steps == 10:
                application_state = source.state_values(kernel.model, data)
            if steps in source.CHECKPOINT_STEPS:
                checkpoints.append(dict(fact, checkpoint_index=len(checkpoints), checkpoint_target_s=steps * .002))
        if failure:
            break
    complete = steps == 500 and len(controls) == 50 and failure is None
    deltas = {key: value - before[key] for key, value in source._kernel_counts(kernel).items()}
    first = controls[1] if len(controls) > 1 else None
    state_check = _application_check(sample, packet, application_state)
    first_match = bool(first is not None and np.array_equal(first['tau_sent'], selected['tau_sent']))
    identity_pass = bool(state_check['pass'] and first_match)
    rows = ([initial_fact] if initial_fact is not None else []) + physics
    q = [row.get('qpos') for row in rows]
    signed = [float(direction * (value[0] - anchor[0])) for value in q if value is not None]
    prehold_d = max([0.] + signed[:11])
    progress04 = float(direction * (q[20][0] - anchor[0])) if len(q) > 20 and q[20] is not None else None
    progress02_04 = float(direction * (q[20][0] - q[10][0])) if len(q) > 20 and q[20] is not None and q[10] is not None else None
    result = {'schema': VERSION, 'kind': 'ACTUAL_B' if gamma == 0. else 'ACTUAL_C',
        'status': 'COMPLETE' if complete else 'FAILED_BUDGET' if failure and failure['reason'] == 'GLOBAL_BUDGET_EXHAUSTED' else 'FAILED_NUMERICAL',
        'branch_id': branch_id, 'branch_purpose': purpose,
        'label_semantics': 'MATCHED_CURRENT_CANDIDATE_BOUNDED_6MS',
        'representation': packet.get('representation'),
        'model_authorized': False,
        'native_feedback_QP_limit_s': .006,
        'first_packet_native_QP_limits_s': packet.get('first_QP_native_limits_s'),
        'realtime_deployment_evidence': bool(require_sent),
        'selected_command_sent': bool(packet.get('selected_command_sent')),
        'protocol_role': 'COUNTERFACTUAL_ENDPOINT' if purpose.startswith('COUNTERFACTUAL') else purpose,
        'method': packet.get('method'), 'reason': failure, 'gamma': gamma,
        'backup_id': bid, 'fixed_anchor_q_init': anchor.tolist(), 'original_direction': direction,
        'backup_version': source.HOLD_VERSION, 'capacity_interface_version': source.CAPACITY_VERSION,
        **metadata, 'initial_state': initial, 'initial_fact': initial_fact,
        'final_state': source.state_values(kernel.model, data), 'controls': controls,
        'physics_trajectory': physics, 'checkpoints': checkpoints, 'solver_ledger': ledger,
        'sample_start_s': 0., 'selected_application_time_s': .020, 'horizon_s': 1.,
        'original_witness_time_s': .020,
        'original_sample_anchor_not_application_anchor': True,
        'previous_command_identity': deepcopy(hold['previous_command_identity']),
        'previous_command_raw': hold['tau_raw'], 'previous_command_health_clipped': hold['tau_sent'],
        'previous_command_not_new_solved_QP': True, 'first_action_kind': selected.get('kind'),
        'synthesized_action_not_optimizer_return': 0. < gamma < 1.,
        'same_packet_used': True, 'new_governor_calls': 0, 'new_endpoint_QP_calls': 0,
        'first_tau_packet': np.asarray(selected['tau_sent']).copy(), 'first_tau_matches_packet': first_match,
        'shared_packet_command_ready_ms': float(packet['command_ready_ms']),
        'first_latency_is_shared_packet_cost': True, 'independent_baseline_decision_latency_measured': False,
        'counterfactual_model_approval_claim': False,
        'prehold_physics_steps': min(steps, 10), 'selected_hold_physics_steps': min(max(0, steps - 10), 10),
        'backup_memory_restore': memory_restore,
        'application_state_actual': application_state,
        'application_state_prediction': deepcopy((packet.get('application_prediction') or {}).get('state')),
        'application_state_check': state_check, 'application_state_match': state_check['pass'],
        'application_identity_pass': identity_pass,
        'identity_error': None if identity_pass or not state_check['checked'] else 'PREDICTED_APPLICATION_STATE_OR_PACKET_TAU_MISMATCH',
        'posthoc_actual_state_used_for_selection': False,
        'D_prehold_actual_m': prehold_d if len(rows) > 10 else None,
        'D_actual_available_prefix_m': max([0.] + signed),
        'progress0_04_m': progress04, 'progress02_04_m': progress02_04,
        'selected_action_progress20_m': progress02_04,
        'counts': {'physical_steps': steps, 'control_qp_calls': len(ledger), 'backup_qp_calls': len(ledger),
            'feedback_QP_calls': len(ledger), 'new_feedback_QP_calls': len(ledger),
            'packet_B0_reused_count': int(gamma == 0. and first is not None),
            'endpoint_QP_calls_new': 0, 'governor_calls_new': 0, 'clone_data_calls': 0,
            'backup_controller_instances': 0, 'backup_policy_resets': 1,
            'action_conditioned_forward_calls': action_forward, 'integration_refresh_forward_calls': refresh, **deltas},
        'first_backup_decision_ms': first_feedback_ms, 'elapsed_ms': (perf_counter() - begin) * 1000.,
        'feedback_latency_ms': [float(row['command_ready_ms']) for row in controls],
        'all_available_ticks_within_20ms': bool(controls and all(row['within_online_deadline'] for row in controls)),
        'additional_feedback_waits_simulated': False, 'timing_scope': 'ONE_INITIAL_PACKET_WAIT_ONLY',
        'timing': {'control_total_ms': control_ms, 'integration_s': integration_s,
            'integration_refresh_s': refresh_s, 'physical_fact_extraction_s': fact_s,
            'solver_wall_s': source._ledger_wall_s(ledger)}}
    return source._json_safe(result)
