"""Fixed 16-source direct counterfactual batch; no learner/CAL/reference generation."""
from copy import deepcopy
from datetime import datetime,timezone
from pathlib import Path
from time import perf_counter
import argparse,gc,os,traceback
import numpy as np
from cavr_wbc.experiments import step17_formal_panel as frozen,step37_sim as sim
from cavr_wbc.experiments.step37_io import *
from cavr_wbc.experiments.step37_budget import SprintBudget,SprintLimit
from cavr_wbc.experiments.step36_sprint import plans as source_plans,context_for as source_context_for
from cavr_wbc.experiments.step28_sprint import home_context
from cavr_wbc.experiments.step34_storage import save_bank,load_bank
from cavr_wbc.experiments.step35_sprint import current_events
from cavr_wbc.control.step34_margin import labels
from cavr_wbc.platforms.go2_mujoco import extract_actuator_audit,extract_healthy_torque_limits

REPRESENTATIONS=('FULL_INTERIOR_RESIDENT','REDUCED_WHITENED_RESIDENT')
BRANCHES=(('C',1.),('MIDDLE',.5),('B',0.))
GAPS=(.004,.006,.008)

def plans():
    result=[]
    for old in source_plans('TEST'):
        if old['gap_m']!=.004:continue
        p=deepcopy(old);p.update(context_id='S37_'+old['source_state_id'],case_id='S37_'+old['source_state_id'],
            ordinal=len(result),gap_m=None,
            representation_order=list(REPRESENTATIONS if len(result)%2==0 else REPRESENTATIONS[::-1]))
        p.pop('method_order')
        result.append(p)
    return result

def event(out,name,**fields):
    append(out/'ATTEMPT_LEDGER.jsonl',{'event':name,'timestamp_utc':datetime.now(timezone.utc).isoformat(),**fields})

def load_source(plan,manifest,episode_cache):
    if plan['episode'] not in episode_cache:
        path=SOURCE35/'episodes'/(plan['episode']+'.json')
        episode=load_numeric(path)
        if episode['status']!='COMPLETE' or episode['counts']['physical_steps']!=1100:
            raise ValueError('saved TEST reference must be complete; no generation fallback')
        episode_cache[plan['episode']]=episode
    episode=episode_cache[plan['episode']]
    snaps={r['source_tick']:r for r in episode['snapshots']}
    c=source_context_for(plan,snaps,episode,manifest['mapping'])
    c.update(context_id=plan['context_id'],case_id=plan['context_id'],backup_id='STEP37-'+plan['context_id'],
        runtime_id=plan['context_id'],split='TEST',gap_m=None)
    c['previous_command_identity']['source']='REUSED_STEP35_REFERENCE_CANDIDATE'
    return c

def save_branch(out,directory,name,branch,c,packet=None):
    path=directory/name;path.mkdir(parents=True,exist_ok=True)
    if branch['status']=='NOT_RUN':
        record={**branch,'result_path':relative(path/'RESULT.json',out),'observed':False,
            'model_authorized':False,'selected_command_sent':False}
    else:
        asset=save_bank(path/'actual.npz',branch)
        lab=labels(branch,c)
        controls=branch['controls'];first=controls[1]['capacity_interface'] if len(controls)>1 else {}
        ev=current_events(branch,{'capacity_interface':first,'first_capacity_event':bool(first.get('sent_99_percent_active_indices'))})
        ctrl_asset=save_numeric(path/'CONTROL_RESULTS.json',{'controls':controls,'status':branch['status'],'reason':branch.get('reason')})
        complete=bool(lab.get('complete') and lab.get('full_501_grid'))
        first_ms=float((packet or {}).get('command_ready_ms',float('nan')))
        ticks=[r.get('latency_ms') for r in controls]
        feedback=[r.get('latency_ms') for r in controls if r.get('slot',0)>1]
        valid_feedback=bool(len(feedback)==48 and all(v is not None and np.isfinite(v) and 0<=v<=20 for v in feedback))
        first_timely=bool(np.isfinite(first_ms) and first_ms<=20)
        record={'status':branch['status'],'reason':branch.get('reason'),'observed':True,'gamma':branch['gamma'],
            'label':lab,'artifact':asset,'controls_numeric':ctrl_asset,'controls_path':relative(path/'CONTROL_RESULTS.json',out),
            'result_path':relative(path/'RESULT.json',out),'counts':branch['counts'],'events':ev,
            'model_authorized':False,'selected_command_sent':False,'scope':'DIRECT_OFFLINE_COUNTERFACTUAL_RECOVERY',
            'representation':(packet or {}).get('representation'),'first_packet_ready_ms':first_ms,
            'first_packet_timely':first_timely,'first_packet_timing_status':'FIRST_PACKET_TIMELY_OFFLINE' if first_timely else 'LATE_FIRST_PACKET_OFFLINE_ONLY',
            'tick_latency_ms':ticks,'feedback_latencies_ms':feedback,'feedback_48_deadlines_pass':valid_feedback,
            'all_tick_deadline_pass':bool(complete and first_timely and valid_feedback),
            'timing_qualified':bool(complete and first_timely and valid_feedback),
            'application_identity_pass':branch.get('application_identity_pass'),'application_state_match':branch.get('application_state_match'),
            'application_identity_error':branch.get('identity_error'),'application_state_comparison':branch.get('application_state_check'),
            'first_tau_matches_packet':branch.get('first_tau_matches_packet'),'backup_memory_restore':branch.get('backup_memory_restore'),
            'progress0_04_m':branch.get('progress0_04_m'),'progress02_04_m':branch.get('progress02_04_m'),
            'actual_horizon_origin':'SAMPLE','actual_horizon_s':1.,'checkpoints':len(branch['checkpoints']),
            'additional_feedback_waits_simulated':False,'model_or_deployed_governor_claim':False}
    write(path/'RESULT.json',record)
    return record

def direct_packet(kernel,c,budget,owners):
    from cavr_wbc.control.step37_actions import prepare_shared,make_action
    begin=perf_counter();context,packet=kernel._packet_base(c,budget,'APPLICATION_FEAS_GOV')
    packet.update(method='DIRECT_RECOVERY_'+kernel.representation,representation=kernel.representation,
        status='DIRECT_OFFLINE_COUNTERFACTUAL_RECOVERY',model_authorized=False,selected_command_sent=False,
        stage='APPLICATION_PACKET',step37_branch_owners={name:k.solver_owner_identity() for name,k in owners.items()},
        no_CAL_model_or_governor=True,absolute_deadline=begin+.020,deadline_ms=20.)
    if packet['application_prediction']['complete']:
        workspace=kernel._endpoints(c,context,packet,budget,deadline=begin+.020)
        for name,gamma in BRANCHES:
            action=make_action(context,packet.get('C'),packet.get('B'),gamma,workspace=workspace)
            packet['actions'][str(gamma)]={'action':action,'screening_prefix_status':'NOT_REQUESTED_BY_DIRECT_PROTOCOL'}
    kernel._capture_packet(packet)
    packet['step37_B0_physical_memory']=kernel.backup_controller.capture_physical_memory()
    packet['command_ready_ms']=(perf_counter()-begin)*1000.
    packet['first_packet_timing_status']='FIRST_PACKET_TIMELY_OFFLINE' if packet['command_ready_ms']<=20 else 'LATE_FIRST_PACKET_OFFLINE_ONLY'
    return packet

def packet_equivalence(full,red):
    checks={}
    for name in ('B','C'):
        fr=(full.get(name) or {}).get('raw_solver_result',(full.get(name) or {}).get('wbc',{})) or {}
        rr=(red.get(name) or {}).get('raw_solver_result',(red.get(name) or {}).get('wbc',{})) or {}
        fp=fr.get('step34_problem');rp=rr.get('step34_problem')
        same={}
        if fp and rp:
            for k in ('P','A'):same[k]=bool(np.array_equal(fp[k].toarray(),rp[k].toarray()))
            for k in ('q','l','u'):same[k]=bool(np.array_equal(fp[k],rp[k]))
            fm,rm=fr.get('source_matrices') or {},rr.get('source_matrices') or {}
            for k in ('qpos','qvel','integration_state','health_vector'):same[k]=bool(np.array_equal(fm.get(k),rm.get(k)))
            fw,rw=fr.get('step37_working_problem'),rr.get('step37_working_problem')
            for k in ('l','u'):
                same['working_'+k]=bool(fw and rw and np.array_equal(fw[k],rw[k]))
        checks[name]={'available':bool(fp and rp),'checks':same,'pass':bool(same and all(same.values()))}
    return {'schema':'STEP37_FIRST_PACKET_SAME_WORKING_PROBLEM','endpoints':checks,
        'pass':all(v['pass'] for v in checks.values()),'after_first_packet_trajectory_states_may_differ':True}

def run(run_id=RUN_ID,repair=False):
    from cavr_wbc.control.step37_kernel import Kernel
    out=output(run_id)
    if (out/'RUN_STARTED.json').exists() and not repair:raise FileExistsError('fixed unique STEP37 batch already attempted')
    out.mkdir(parents=True,exist_ok=True)
    budget=SprintBudget.resume_dev_repair(out) if repair else SprintBudget(out)
    budget.start();status='COMPLETED';cache={}
    try:
        model=frozen.load_model();source=read(SOURCE35/'MANIFEST.json')
        limits=extract_healthy_torque_limits(model)
        mapping=[dict(r,healthy_limit_nm=float(limits[r['actuator_index']])) for r in extract_actuator_audit(model)]
        dll=SOURCE30/'native/step30_prefix.dll'
        manifest={'run_id':run_id,'source_commit':PARENT,'source_root':str(SOURCE35),'source_states':plans(),
            'representations':REPRESENTATIONS,'branches':BRANCHES,'gaps_evaluated_m':GAPS,'mapping':mapping,
            'scenario':source['scenario'],'frozen_physical':source['frozen_physical'],'native_dll_path':str(dll),
            'native_dll_sha256':sha(dll),'protocol_sha256':sha(PROTOCOL),'max_QP':12000,'max_steps':120000,'max_wall_s':5400,
            'friction_upper_N':-1e-4,'torque_inset_Nm':1e-4,'solver_eps_abs_rel':1e-7,'first_B_limit_s':.006,
            'first_C_limit_s':.003,'feedback_limit_s':.006,'deadline_ms':20,'horizon_s':1.,'physics_dt_s':.002,
            'new_reference_solves':0,'new_reference_steps':0,'new_model_fits':0,'new_CAL_actions':0,'model_authorized_packets':0,
            'source_states_count':16,'physical_snapshots':8,'episodes':4,'thread_env':{k:os.environ.get(k) for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS')}}
        if not repair:
            write(out/'MANIFEST.json',manifest)
            write(out/'RUN_STARTED.json',{'pid':os.getpid(),'start_utc':datetime.now(timezone.utc).isoformat(),'run_id':run_id})
            write(out/'BATCH_REGISTRY.json',[{**p,'status':'NOT_RUN','representations':{r:{'status':'NOT_RUN'} for r in REPRESENTATIONS}} for p in plans()])
            runtime=[*ROOT.glob('cavr_wbc/control/step37_*.py'),*[p for p in ROOT.glob('cavr_wbc/experiments/step37_*.py') if not any(k in p.name for k in ('report','figures','verify','delivery'))],*ROOT.glob('tests/test_step37*.py')]
            write(out/'RUNTIME_FREEZE.json',{'runtime_sha256':{relative(p,ROOT):sha(p) for p in runtime},'protocol_sha256':sha(PROTOCOL),
                'fixed_plan':plans(),'fit_CAL_reference_calls':0,'date':'2026-10-10','timezone':'Asia/Seoul'})
            try:
                import scipy,osqp,mujoco,threadpoolctl
                write(out/'ENVIRONMENT.json',{'numpy':np.__version__,'scipy':scipy.__version__,'osqp':osqp.__version__,'mujoco':mujoco.__version__,'threadpools':threadpoolctl.threadpool_info()})
            except ImportError:
                write(out/'ENVIRONMENT.json',{'numpy':np.__version__,'threadpools':'PACKAGE_METADATA_UNAVAILABLE'})
        registry=read(out/'BATCH_REGISTRY.json')
        for p in plans():
            if registry[p['ordinal']]['status']=='DONE':continue
            c=load_source(p,manifest,cache)
            sourcepath=SOURCE35/'episodes'/(p['episode']+'.json')
            directory=out/'states'/c['context_id'];directory.mkdir(parents=True,exist_ok=True)
            if repair and list(directory.glob('*/PACKET.json')):
                # Native internal state cannot be reconstituted by copying x/y into new owners.
                for rep in REPRESENTATIONS:
                    repdir=directory/rep
                    for name,gamma in BRANCHES:
                        resultpath=repdir/name/'RESULT.json'
                        if not resultpath.exists():
                            save_branch(out,repdir,name,{'status':'NOT_RUN','gamma':gamma,'reason':'IMPLEMENTATION_INTERRUPTION_NO_ORIGINAL_LIVE_RESIDENT_OWNER'},c)
                    registry[p['ordinal']]['representations'][rep].update(status='INTERRUPTED_PRESERVED_NO_RESOLVE')
                registry[p['ordinal']]['status']='DONE';write(out/'BATCH_REGISTRY.json',registry)
                continue
            write(directory/'SOURCE_IDENTITY.json',{'context':c,'source_path':str(sourcepath),
                'source_json_sha256':sha(sourcepath),'source_npz_sha256':sha(sourcepath.with_suffix('.npz')),
                'source_identity_preserved':True,'new_reference_solves':0,'new_reference_steps':0})
            packets={}
            for rep in p['representation_order']:
                repdir=directory/rep;repdir.mkdir(parents=True,exist_ok=True)
                event(out,'START',kind='SOURCE_REPRESENTATION',source_state_id=c['source_state_id'],representation=rep)
                before=perf_counter()
                owners={name:Kernel(model,'BOUNDED',str(dll),budget,representation=rep) for name,_ in BRANCHES}
                home=home_context(model,manifest['scenario']);home.update(context_id=c['context_id']+':HOME',backup_id=c['backup_id']+':HOME')
                startup={name:k.startup(home,budget) for name,k in owners.items()}
                for k in owners.values():k.flush_raw_evidence()
                write(repdir/'STARTUP.json',{'owners':startup,'preparation_wall_ms':1000*(perf_counter()-before),
                    'independent_owners':{name:k.solver_owner_identity() for name,k in owners.items()},'source_state_id':c['source_state_id']})
                packet=direct_packet(owners['B'],c,budget,owners) if c['eligible'] else {
                    'context_id':c['context_id'],'context_used':c,'method':'DIRECT_RECOVERY_'+rep,'representation':rep,
                    'status':'SOURCE_INELIGIBLE','selected_command_sent':False,'actions':{},'command_ready_ms':0.}
                owners['B'].flush_raw_evidence()
                save_numeric(repdir/'PACKET.json',packet);packets[rep]=packet
                partial={'representation':rep,'source_state_id':c['source_state_id'],'status':'IN_PROGRESS',
                    'packet_path':relative(repdir/'PACKET.json',out),'candidate_available':{},
                    'packet_ready_ms':packet['command_ready_ms'],'branches':{}}
                write(repdir/'RESULT.json',partial)
                for name,gamma in BRANCHES:
                    action=(packet.get('actions',{}).get(str(gamma)) or {}).get('action') or {}
                    partial['candidate_available'][name]=bool(action.get('command_valid'))
                    event(out,'START',kind='ACTUAL_DIRECT',source_state_id=c['source_state_id'],representation=rep,branch=name,gamma=gamma)
                    if action.get('command_valid') and action.get('execution_eligible'):
                        branch=sim.propagate(owners[name],c,packet,budget,purpose=name,action=action,require_sent=False)
                        record=save_branch(out,repdir,name,branch,c,packet)
                    else:
                        record=save_branch(out,repdir,name,{'status':'NOT_RUN','gamma':gamma,'reason':'CURRENT_SAME_PACKET_WITNESS_UNAVAILABLE'},c,packet)
                    partial['branches'][name]=record;write(repdir/'RESULT.json',partial)
                    event(out,'RETURN',kind='ACTUAL_DIRECT',source_state_id=c['source_state_id'],representation=rep,branch=name,
                        status=record['status'],counts=record.get('counts'),result_path=record['result_path'])
                    if record.get('application_identity_error'):raise ValueError('actual/predicted complete state identity mismatch')
                    if record['status']=='FAILED_BUDGET':raise SprintLimit('branch preserved at cap')
                    budget.persist(phase='ACTUAL_BRANCH_SAVED',source_ordinal=p['ordinal'],representation=rep,branch=name)
                partial['status']='DONE';write(repdir/'RESULT.json',partial)
                registry[p['ordinal']]['representations'][rep].update(status='DONE',result_path=relative(repdir/'RESULT.json',out))
                write(out/'BATCH_REGISTRY.json',registry)
                del owners;gc.collect()
            if all(rep in packets for rep in REPRESENTATIONS):
                comparison=packet_equivalence(packets[REPRESENTATIONS[0]],packets[REPRESENTATIONS[1]])
                write(directory/'FIRST_PACKET_EQUIVALENCE.json',comparison)
                # A cutoff/missing QP is ordinary missing evidence. Mismatched available matrices are implementation errors.
                if any(ep['available'] and not ep['pass'] for ep in comparison['endpoints'].values()):
                    raise ValueError('paired first application physical/working QP mismatch')
            registry[p['ordinal']]['status']='DONE';write(out/'BATCH_REGISTRY.json',registry)
            budget.persist(phase='SOURCE_DONE',sources_processed=p['ordinal']+1)
            print({'phase':'SOURCE_DONE','source':c['source_state_id'],'sources_processed':p['ordinal']+1,'total_sources':16,'budget':budget.snapshot()},flush=True)
            del packets;gc.collect()
    except SprintLimit as exc:
        status='INCOMPLETE_BUDGET';write(out/'INTERRUPTION.json',{'type':'BUDGET','error':str(exc),'budget':budget.snapshot()})
    except BaseException as exc:
        status='STOPPED_IMPLEMENTATION_OR_RESOURCE'
        write(out/'INTERRUPTION.json',{'type':type(exc).__name__,'error':str(exc),'traceback':traceback.format_exc(),'budget':budget.snapshot()})
        raise
    finally:
        budget.event('NUMERICAL_FINISHED',status=status,**budget.snapshot());budget.close()
        write(out/'RUN_FINISHED.json',{'run_id':run_id,'status':status,'budget':budget.snapshot(),'finish_utc':datetime.now(timezone.utc).isoformat()})
        print({'status':status,'budget':budget.snapshot()},flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('run_id',nargs='?',default=RUN_ID);parser.add_argument('--dev-engineering-repair',action='store_true')
    args=parser.parse_args();run(args.run_id,args.dev_engineering_repair)
