"""One saved current-batch readback; no solver/integration or historical audit."""
from datetime import datetime,timezone
from pathlib import Path
import ast,json
import numpy as np
from cavr_wbc.experiments.step37_io import *
from cavr_wbc.experiments.step37_sprint import REPRESENTATIONS,plans,BRANCHES
from cavr_wbc.experiments.step33_report import jsonl_rows

def verify():
    out=output();finished=read(out/'RUN_FINISHED.json');budget=finished['budget'];checks={};details={}
    ledger=list(jsonl_rows(out/'STEP37_LEDGER.jsonl'))
    starts=[r['global_qp_index'] for r in ledger if r['event']=='QP_START']
    returns=[r['global_qp_index'] for r in ledger if r['event']=='QP_RETURN']
    checks['ledger_real_QP_start_return_exact']=starts==returns==list(range(1,budget['total_QP_calls']+1))
    checks['budget_and_original_clock']=budget['total_QP_calls']<=12000 and budget['total_physics_steps']<=120000 and budget['numerical_elapsed_s']<=5400 and budget['numerical_started_utc']==read(out/'repairs/REPAIR_01_PREVIOUS_FINISH.json',finished)['budget']['numerical_started_utc']
    checks['no_unknown_or_uncompleted_reservations']=budget['unknown_native_returns']==budget['uncompleted_native_step_reservations']==0
    checks['no_fit_reference_CAL_or_governor']=budget['multioutput_estimator_fits']==0 and not list((out/'CAL').glob('*')) and not list((out/'episodes').glob('*'))
    rows=read(out/'BRANCH_RESULTS.json')
    checks['complete_fixed_denominators']=len(rows)==96 and len({r['source_state_id'] for r in rows})==16 and len({r['physical_snapshot'] for r in rows})==8 and len({r['episode'] for r in rows})==4
    checks['no_fake_model_send']=all(r['model_authorized'] is False and r['selected_command_sent'] is False for r in rows)
    checks['observed_identity_and_complete_time_axis']=all((not r['observed']) or
        (r['application_identity_pass'] is True and r['first_tau_matches_packet'] is True and
         (not r['complete_501'] or (r['steps']==500 and r['artifact']['row_count']==501))) for r in rows)
    checks['three_gaps_are_one_trajectory']=len(read(out/'GAP_RESULTS.json'))==288 and all(r['same_trajectory_no_new_propagation'] for r in read(out/'GAP_RESULTS.json'))
    first=read(out/'FIRST_PACKET_EQUIVALENCE.json')
    checks['available_first_packets_same_original_and_working_problem']=all(not ep.get('available') or ep.get('pass') for rec in first for ep in rec.get('endpoints',{}).values())
    startup=read(out/'STARTUP_RESULTS.json');groups={}
    for rec in startup:
        groups.setdefault((rec['source_state_id'],rec['representation']),[]).append(rec)
    checks['independent_concurrent_branch_owners']=all(len(gr)==3 and len({r['owner_identity']['backup_owner'] for r in gr})==3 for gr in groups.values())
    b0=True
    for row in rows:
        if row['observed'] and row['branch']=='B':
            status=(row.get('backup_memory_restore') or {}).get('status')
            b0 &= status=='RESTORED_APPLICATION_PACKET_B0'
        if row['observed'] and row['branch'] in ('C','MIDDLE') and row['feedback_QP_calls']:
            b0 &= (row.get('backup_memory_restore') or {}).get('status')=='OWN_BRANCH_APPLIED_PHYSICAL_WITNESS_SEED'
    checks['B0_same_owner_and_other_branch_physical_seed']=bool(b0)
    source_ok=True
    for p in plans():
        doc=read(out/'states'/p['context_id']/'SOURCE_IDENTITY.json')
        source_ok &= bool(sha(doc['source_path'])==doc['source_json_sha256'] and sha(Path(doc['source_path']).with_suffix('.npz'))==doc['source_npz_sha256'])
    checks['saved_source_hashes_unchanged']=source_ok
    saved={r['global_qp_index']:r for r in ledger if r['event']=='RAW_QP_SAVED'}
    expected_gap=set(read(out/'repairs/INTERFACE_REPAIR_01.json',{}).get('returned_startup_QP_full_raw_missing',[]))
    missing=set(starts)-set(saved)
    checks['startup_gap_disclosed_no_unexpected_gap']=missing==expected_gap
    details['returned_initial_startup_full_raw_missing']=sorted(missing)
    hashes_ok=True;bounds_ok=True;dimensions_ok=True;expectedF=np.array([60+5*f+k for f in range(4) for k in range(4)])
    for index,entry in saved.items():
        path=out/entry['path'];doc=read(path);raw=doc['record']['raw_result'];rep=raw['step37_representation']
        hashes_ok &= sha(path)==entry['json_sha256'] and sha(path.with_suffix('.npz'))==entry['npz_sha256']==doc['numeric_sha256']
        physical=raw.get('step37_physical_x');native=raw.get('step37_native_x');dual=raw.get('step37_native_y')
        dimensions_ok &= (native is None or native['shape']==([42] if rep==REPRESENTATIONS[0] else [12])) and (physical is None or physical['shape']==[42]) and (dual is None or dual['shape']==([80] if rep==REPRESENTATIONS[0] else [50]))
        with np.load(path.with_suffix('.npz'),allow_pickle=False) as bank:
            def a(v):return bank[v['npz_key']]
            pl=a(raw['step34_problem']['l']);pu=a(raw['step34_problem']['u'])
            wl=a(raw['step37_working_l']);wu=a(raw['step37_working_u'])
            expectedl=pl.copy();expectedu=pu.copy();expectedl[48:60]+=1e-4;expectedu[48:60]-=1e-4;expectedu[expectedF]=-1e-4
            bounds_ok &= bool(np.array_equal(wl,expectedl) and np.array_equal(wu,expectedu) and raw['candidate_certificate']['inequality_extra_slack']==0)
        if rep==REPRESENTATIONS[1]:
            dimensions_ok &= raw['step37_basis']['rank']==30 and raw.get('step34_existing_dual') is None and raw['native_residual_scope']=='REDUCED50_INEQUALITIES_ONLY'
    checks['current_raw_hash_readback']=bool(hashes_ok);checks['true_working_bounds_and_original_slack']=bool(bounds_ok)
    checks['native_physical_and_dual_dimensions']=bool(dimensions_ok)
    runtime=read(out/'RUNTIME_FREEZE.json')['runtime_sha256'];runtime_ok=True;changes=[]
    for rel,digest in runtime.items():
        if sha(ROOT/rel)!=digest:changes.append(rel)
    runtime_ok=set(changes)<= {'cavr_wbc/experiments/step37_io.py'}
    checks['numerical_runtime_only_IO_repair_changed']=runtime_ok
    details['runtime_files_changed_from_initial_freeze']=changes
    syntax=[]
    for path in [*ROOT.glob('cavr_wbc/control/step37_*.py'),*ROOT.glob('cavr_wbc/experiments/step37_*.py'),*ROOT.glob('tests/test_step37*.py')]:
        ast.parse(path.read_text(encoding='utf-8'),filename=str(path));syntax.append(relative(path,ROOT))
    checks['current_source_syntax']=True
    checks['necessary_suite_six_passed']=read(out/'tests/NECESSARY_TESTS.json')['passed']==6
    details['syntax_files']=syntax
    result={'check_count':1,'timestamp_utc':datetime.now(timezone.utc).isoformat(),'checks':checks,'all_current_checks_pass':all(checks.values()),
        'details':details,'full_raw_evidence_all_calls':not missing,'scientific_success_not_implied_by_readback':True,
        'new_QP_calls':0,'new_steps':0,'new_fits':0,
        'command':'E:/CAVR-WBC/_runtime_step30/python311/python.exe -B -X utf8 -m cavr_wbc.experiments.step37_verify'}
    write(out/'tests/CURRENT_DELIVERY_CHECK.json',result);print(result)
    if not result['all_current_checks_pass']:raise ValueError('current evidence readback mismatch; preserve evidence, no numeric rerun')

if __name__=='__main__':verify()
