"""Once-only exposed CAL: forward input first, historical labels afterwards."""
from copy import deepcopy
import numpy as np
from cavr_wbc.experiments.step38_io import *
from cavr_wbc.control.step34_margin import build_calibration,load_bundle,save_bundle,identity,group_key
from cavr_wbc.experiments.step38_inputs import BRANCHES

def prediction_input(packet,gamma):
    # Explicit projection: cannot carry any saved actual/future labels or controls.
    excluded={'labels','label','terminal','D_max','future_controls','actual_results'}
    context=deepcopy({k:v for k,v in packet['context_used'].items() if k not in excluded})
    context['split']='CAL';context['source_split']='STEP37_EXPOSED_TEST'
    entry=packet['actions'][str(float(gamma))]
    action=deepcopy(entry['action'])
    return context,action,deepcopy(packet['prehold'])

def forward_entry(kernel,packet,gamma,budget):
    c,a,prehold=prediction_input(packet,gamma)
    kernel.reset(c)
    prefix=kernel._prefix_one(c,a,budget) if a.get('command_valid') else None
    entry=kernel._entry(c,a,prefix,prehold)
    entry.update(prediction_source='INDEPENDENT_10_STEP_APPLICATION_ACTION_PREFIX',
        source_split='STEP37_EXPOSED_TEST',split='CAL',future_labels_read=False,
        old_actual_prefix_not_relabelled_prediction=True,new_endpoint_QP_calls=0)
    return c,entry

def calibrate(out,model,dll,budget,Kernel):
    path=SOURCE34/'models/step34_trained_only.npz'
    trained=None;source_error=None
    try:
        if not path.exists() or not path.with_suffix('.json').exists():
            raise FileNotFoundError('trained-only NPZ and JSON both required; no fit fallback')
        trained=load_bundle(path)
        predictor_identity=identity(trained)
    except (OSError,ValueError,KeyError) as exc:
        source_error=str(exc);predictor_identity=None
    source=read(SOURCE37/'MANIFEST.json')
    rows=[]
    prefix_owner=Kernel(model,'BOUNDED',str(dll),budget) if trained is not None else None
    for p in source['source_states']:
        directory=SOURCE37/'states'/p['context_id']/'REDUCED_WHITENED_RESIDENT'
        packet=None;packet_error=None
        try:
            if trained is not None:packet=load_numeric(directory/'PACKET.json')
        except (OSError,ValueError,KeyError) as exc:packet_error=str(exc)
        for name,gamma in BRANCHES:
            entry={'features26':None,'prefix':None,'first_command_valid':False,
                'prediction_unavailable':source_error or packet_error}
            c={'episode':p['episode'],'source_snapshot':p['snapshot_id']}
            if packet is not None:
                try:
                    c,entry=forward_entry(prefix_owner,packet,gamma,budget)
                    entry['first_command_valid']=bool(entry['action'].get('command_valid'))
                except (ValueError,TypeError,KeyError) as exc:
                    entry.update(prediction_unavailable=str(exc))
            # The complete trajectory's target is deliberately unavailable until here.
            result=read(directory/name/'RESULT.json',{})
            record={'id':'CAL38:'+p['context_id']+':'+name,'gamma':gamma,'role':p['role'],
                'episode':p['episode'],'source_snapshot':p['snapshot_id'],'source_state_id':p['source_state_id'],
                'context':c,'ctx':c,'split':'CAL','source_split':'STEP37_EXPOSED_TEST',
                'features26':entry.get('features26'),'prefix':entry.get('prefix'),
                'prehold':(packet or {}).get('prehold'),
                'first_command_valid':bool(entry.get('first_command_valid')),
                'labels':result.get('label',{}),'prediction_unavailable':entry.get('prediction_unavailable'),
                'source_packet_sha256':sha(directory/'PACKET.json') if (directory/'PACKET.json').exists() else None,
                'source_actual_result_sha256':sha(directory/name/'RESULT.json') if result else None,
                'future_target_consumed_only_after_prefix_features':True,'new_QP_calls':0,
                'old_actual_full_horizon_not_recomputed':True}
            save_numeric(out/'CAL'/('A'+str(len(rows)).zfill(3)+'.json'),{'entry':entry,'record':record})
            rows.append(record)
            budget.persist(phase='EXPOSED_CAL_PREFIX_SAVED',CAL_actions=len(rows))
    bundle=build_calibration(trained,rows) if trained is not None else None
    table=[];asset=None
    if bundle is not None:
        # Only the six specified gamma-role groups may be consulted in STEP38.
        bundle['groups']={group_key(g,r):bundle['groups'][group_key(g,r)] for g in (1.,.5,0.) for r in ('thigh','calf')}
        from cavr_wbc.control.step34_margin import prepare_resident
        prepare_resident(bundle)
        bundle.update(calibration_id='STEP38_STEP37_EXPOSED_ALL48_ONCE',CAL_source='STEP37_RED_ALL48_EXPOSED_TRAJECTORIES',
            new_model_fits=0,STEP38_fresh_TEST_consumed=False)
        if identity(bundle)!=predictor_identity:raise ValueError('CAL changed frozen predictor coefficients')
        asset=save_bundle(bundle,out/'models',stem='step38_frozen_screen')
        for key,g in bundle['groups'].items():
            table.append({'group':key,**{k:g.get(k) for k in ('CAL_planned','CAL_finite','CAL_complete',
                'CAL_complete_distinct_snapshots','CAL_complete_episodes','CAL_complete_physical_failures',
                'CAL_physical_unknown','local_calibrated','distance_threshold')}})
    else:
        table=[{'group':group_key(g,r),'CAL_planned':8,'CAL_finite':0,'local_calibrated':False,
                'source_unavailable':source_error} for g in (1.,.5,0.) for r in ('thigh','calf')]
    freeze={'status':'FROZEN' if bundle is not None else 'SOURCE_UNAVAILABLE',
        'source_error':source_error,'predictor_identity':predictor_identity,'model_asset':asset,'groups':table,
        'planned_CAL_actions':48,'generated_CAL_action_records':len(rows),'new_model_fits':0,
        'source_trained_NPZ_sha256':sha(path) if path.exists() else None,
        'source_trained_JSON_sha256':sha(path.with_suffix('.json')) if path.with_suffix('.json').exists() else None,
        'not_a_primary_panel_readiness_gate':True,'old_raw_startup_gaps_not_repaired':True}
    write(out/'CAL_GROUP_TABLE.json',table);write(out/'CAL_FREEZE.json',freeze)
    return bundle,freeze
