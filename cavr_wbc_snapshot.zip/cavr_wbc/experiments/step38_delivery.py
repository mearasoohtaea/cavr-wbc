"""Saved-only delivery supplement with full coverage, timing and repair history."""
from collections import Counter
import re
import numpy as np
from cavr_wbc.experiments.step38_io import *
from cavr_wbc.experiments.step38_inputs import plans

def seal(run_id=RUN_ID):
    """Finalize delivery hashes, without repeating scientific readback."""
    out=output(run_id)
    # Saved-only presentation correction: separate first-decision latency
    # from actual feedback termination, without changing any experiment.
    result=read(out/'STEP38_RESULT.json');ds=read(out/'GOVERNOR_DECISIONS.json')
    rec=read(out/'RECOGNIZED_RESULTS.json');supp=read(out/'DELIVERY_SUPPLEMENT.json')
    first_late=sum(d.get('command_ready_ms') is not None and np.isfinite(d['command_ready_ms']) and d['command_ready_ms']>20 for d in ds)
    feedback_late=sum(r['status']=='FAILED_DEADLINE' for r in rec)
    result['C'].update(decision_deadline_miss=first_late,ACTUAL_feedback_deadline_miss=feedback_late,
        deadline_miss=first_late+feedback_late)
    write(out/'STEP38_RESULT.json',result)
    supp.update(decision_deadline_miss=first_late,ACTUAL_feedback_deadline_miss=feedback_late)
    write(out/'DELIVERY_SUPPLEMENT.json',supp)
    reason_lines={}
    for r in supp['direct_incomplete_or_unavailable']:
        reason=r['reason']
        if isinstance(reason,dict):
            reason='; '.join(f'{key}={reason[key]}' for key in ('reason','candidate_rejection_reason','solver_status_val','slot','physics_step') if key in reason)
        reason_lines[f"- {r['context_id']} / {r['branch']}："] = f"- {r['context_id']} / {r['branch']}：{r['status']}；{reason}（完整状态保留在该分支 RESULT.json）。"
    for name in ('STEP38_REPORT.md','STEP38_RESEARCH_HANDOFF.md'):
        path=out/name;lines=path.read_text(encoding='utf-8').splitlines()
        for i,line in enumerate(lines):
            for prefix,replacement in reason_lines.items():
                if line.startswith(prefix):lines[i]=replacement
            if line.startswith('认可 ACTUAL deadline miss = '):
                lines[i]=f"首包检查超过20 ms = {first_late}；认可 ACTUAL 反馈 deadline miss = {feedback_late}；numerical incomplete = {result['C']['numerical_incomplete']}；planned/eligible 认可覆盖率均为 {result['C']['planned_coverage']:.5f}。"
        command='python.exe -B -X utf8 -m cavr_wbc.experiments.step38_delivery --seal'
        if command not in lines:
            index=lines.index('python.exe -B -X utf8 -m cavr_wbc.experiments.step38_verify')+1
            lines[index:index]=['python.exe -B -X utf8 -m cavr_wbc.experiments.step38_delivery',command]
        note='唯一 scoped diff exit=2：仅 Windows CRLF 换行格式告警，代码告警为0；保留证据原字节，详情见 SCOPED_DIFF_CHECK.txt / GIT_DELIVERY.json。'
        if note not in lines:lines.extend(['',note])
        path.write_text('\n'.join(lines)+'\n',encoding='utf-8')
    # Preserve the single diff log and the original Windows evidence bytes.
    # Classify its formatting warnings; do not launch another scoped diff.
    diff_log=out/'SCOPED_DIFF_CHECK.txt';raw_log=diff_log.read_bytes()
    log_text=raw_log.decode('utf-16' if raw_log.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig',errors='replace')
    warnings=[];byte_cache={}
    for line in log_text.splitlines():
        match=re.match(r'^(.+):(\d+): (trailing whitespace|new blank line at EOF)\.$',line)
        if not match:continue
        rel,number,kind=match.groups();path=ROOT/rel
        if path not in byte_cache:byte_cache[path]=path.read_bytes().split(b'\n')
        value=byte_cache[path][int(number)-1]
        cr_only=kind=='trailing whitespace' and value.endswith(b'\r') and not value[:-1].endswith((b' ',b'\t'))
        warnings.append({'file':rel,'line':int(number),'kind':kind,'CRLF_only':cr_only})
    git_meta=read(out/'GIT_DELIVERY.json')
    git_meta['scoped_diff_check']={'command_runs':1,'exit_code':2 if warnings else 0,
        'warnings':len(warnings),'all_warnings_CRLF_only':bool(warnings) and all(v['CRLF_only'] for v in warnings),
        'source_code_warnings':sum(v['file'].endswith('.py') for v in warnings),
        'warning_files':sorted({v['file'] for v in warnings}),
        'evidence_bytes_not_reformatted':True,'no_new_scientific_gate':True}
    write(out/'GIT_DELIVERY.json',git_meta)
    code=sorted([p for folder in ('cavr_wbc/control','cavr_wbc/experiments','tests')
        for p in (ROOT/folder).glob('*step38*.py')])
    files=sorted({relative(p,ROOT) for p in out.rglob('*') if p.is_file()} |
        {relative(out/'DELIVERY_FILES.json',ROOT),relative(out/'FILE_HASHES.json',ROOT)})
    write(out/'DELIVERY_FILES.json',{'source_and_test_files':[relative(p,ROOT) for p in code],
        'source_and_test_sha256':{relative(p,ROOT):sha(p) for p in code},
        'artifact_files':files,'historical_files_in_delivery':False,
        'one_scientific_readback_only':True,'new_QP_calls':0,'new_physics_steps':0})
    hashes={relative(p,out):sha(p) for p in sorted(out.rglob('*'))
        if p.is_file() and p.name!='FILE_HASHES.json'}
    write(out/'FILE_HASHES.json',hashes)
    return {'artifact_files_hashed':len(hashes),'source_and_test_files':len(code),
        'scientific_readback_not_repeated':True}

def deliver(run_id=RUN_ID):
    out=output(run_id);result=read(out/'STEP38_RESULT.json');decisions=read(out/'GOVERNOR_DECISIONS.json')
    direct=read(out/'DIRECT_RESULTS.json');rec=read(out/'RECOGNIZED_RESULTS.json')
    action_status=Counter();reject=Counter();decision_status=Counter();latencies=[]
    for p in plans():
        if p['role']=='healthy':continue
        d=load_numeric(out/'states'/p['context_id']/'GOVERNOR_DECISION.json');decision_status[d['status']]+=1
        if np.isfinite(d.get('command_ready_ms',np.nan)):latencies.append(float(d['command_ready_ms']))
        for key,e in d.get('actions',{}).items():
            action_status[e.get('evaluation_status','UNSPECIFIED')]+=1
            choice=e.get('decision') or {};numeric=choice.get('numeric') or {}
            if numeric and not choice.get('accepted'):
                for gate in ('finite_input','pose_gate','support_gate','distance_gate','calibration_gate','physical_risk_gate'):
                    if gate in numeric and not bool(numeric[gate]):reject[gate]+=1
                if np.any(np.asarray(numeric.get('U_T',[]))>1.):reject['terminal_upper_ratio']+=1
                if numeric.get('U_D',float('-inf'))>.006:reject['local_upper_6mm']+=1
    gaps=read(out/'GAP_RESULTS.json');secondary={str(g):{'safe_direct':sum(r['full_safe'] for r in gaps if r['gap_mm']==g),
        'timing_qualified_safe_direct':sum(r['timing_qualified_safe'] for r in gaps if r['gap_mm']==g)} for g in (4,6,8)}
    A=read(out/'DIRECT_MECHANISM_RESULTS.json');A_primary=[r for r in A if r['gap_mm']==6 and r['observed']]
    A_by_health={role:{'contexts':len([r for r in A_primary if r['role']==role]),
        'physical_snapshots':len({r['snapshot_id'] for r in A_primary if r['role']==role}),
        'episodes':len({r['episode'] for r in A_primary if r['role']==role})} for role in ('healthy','thigh','calf')}
    incomplete=[{'context_id':r['context_id'],'branch':r['branch'],'status':r['status'],'reason':r['reason']}
        for r in direct if not r['complete']]
    supplement={'decision_statuses':dict(decision_status),'action_evaluation_statuses':dict(action_status),
        'nonexclusive_action_gate_rejections':dict(reject),'secondary_saved_only':secondary,'A_by_health':A_by_health,
        'direct_timing_qualified':sum(r['timing_qualified'] for r in direct),
        'direct_complete_safe_primary':sum(r['full_safe'] for r in gaps if r['gap_mm']==6),
        'direct_incomplete_or_unavailable':incomplete,'recognized_no_safety_label_when_incomplete':True,
        'DEV_repairs_used':len(list((out/'repairs').glob('REPAIR_*_STARTED.json'))),
        'unrecoverable_old_live_owners_not_recreated':True,'old_attempts_preserved_in_repairs':True,
        'storage_workaround':'NTFS transparent compression of this output directory only; logical bytes and hashes unchanged',
        'necessary_suite':read(out/'tests/NECESSARY_TESTS.json'),'repair_target_test':read(out/'tests/REPAIR_01_TARGETED.json'),
        'repair_02_target_test':read(out/'tests/REPAIR_02_TARGETED.json'),
        'readback':{k:v for k,v in read(out/'CURRENT_READBACK.json').items() if k!='checks'},
        'new_QP_calls':0,'new_physics_steps':0,'new_model_fits':0}
    write(out/'DELIVERY_SUPPLEMENT.json',supplement)
    lines=['','## 覆盖、执行失败与持久化修复','',
        f"直接对照：完整 {result['direct_complete']}/144；6 mm 完整安全 {supplement['direct_complete_safe_primary']}；全 tick 计时合格 {supplement['direct_timing_qualified']}。",
        f"A 的健康层分解（不增加独立样本）：{A_by_health}。",
        f"筛选决定状态：{dict(decision_status)}；action 状态：{dict(action_status)}。",
        f"非互斥拒收原因：{dict(reject)}。门均为原冻结门，不因本批结果调整。",
        f"首包检查超过20 ms = {result['C'].get('decision_deadline_miss',0)}；认可 ACTUAL 反馈 deadline miss = {result['C'].get('ACTUAL_feedback_deadline_miss',0)}；numerical incomplete = {result['C']['numerical_incomplete']}；覆盖率 planned = {result['C']['planned_coverage']}，eligible = {result['C']['eligible_coverage']}。",
        '','| gap (mm) | 完整安全直接轨迹 | 安全且全 tick 计时合格 |','| --- | ---: | ---: |']
    for g,values in secondary.items():lines.append(f"| {g} | {values['safe_direct']} | {values['timing_qualified_safe_direct']} |")
    lines.extend(['', 'DEV 修复1（接口/存储）：将相同数值的 context 健康向量转成原评价器要求的序列接口。首条轨迹从已有 bank 补全元数据，没有新 QP/积分；已退出的两个待执行 owner 不复制 cache、不重建，按不可恢复留位。其余未开始输入沿用原数值时钟继续，CAL 和新参考轨迹不重复。',
        'DEV 修复2（Windows资源/API）：大量独立 owner 的旧加载器反复注册 DLL 搜索目录且未显式关闭 cookie，出现 WinError206。STEP38 在库及依赖完成加载后关闭搜索 cookie，保留已加载库和全部 native 数值配置；故障发生在下一 owner 的构造阶段、未进入其新求解。只继续未开始输入，不恢复/复制已退出的 solver cache。两次修复各运行一次对应纯定点测试，未重复原集中 suite。',
        '原始 INTERRUPTION、初始 RUN_FINISHED 和修复前预算保留在 repairs/；累计预算包含中断修复耗时。透明 NTFS 压缩只作用于本轮输出，不删除文件、不改逻辑内容/哈希。',
        '', '未完成/不可用直接位：'] )
    lines.extend(f"- {r['context_id']} / {r['branch']}：{r['status']}；{r['reason']}" for r in incomplete)
    lines.extend(['','## 当前验证与全结果图','',
        f"必要纯测试 {supplement['necessary_suite']['passed']}/{supplement['necessary_suite']['tests_run']}；两次修复各 1 项定点测试通过；本轮读回 {supplement['readback']['status']}。测试不代替 A/B/C 科学结果。",
        '图1：figures/FIGURE_1_ALL_DIRECT_PAIRS.png（全部144位及全部可用健康—受损配对）；图2：figures/FIGURE_2_ALL_DECISIONS_ACTUAL.png（32个完整决策时延及所有已施加认可轨迹）。',
        'Origin Skill: experiment-agent 约束累计执行与失败留位；SciPilot 使用配对结构、显式缺失及颜色/字母冗余编码，未筛掉阴性结果。',
        '', '## 执行命令','', '```powershell',
        'python.exe -B -X utf8 -m tests.test_step38_protocol',
        'python.exe -B -X utf8 -m cavr_wbc.experiments.step38_sprint',
        'python.exe -B -X utf8 -m tests.test_step38_repair',
        'python.exe -B -X utf8 -m cavr_wbc.experiments.step38_sprint --dev-engineering-repair',
        'python.exe -B -X utf8 -m tests.test_step38_dll_resources',
        'python.exe -B -X utf8 -m cavr_wbc.experiments.step38_sprint --dev-engineering-repair # repair 02; same cumulative clock',
        'python.exe -B -X utf8 -m cavr_wbc.experiments.step38_report',
        'python.exe -B -X utf8 -m cavr_wbc.experiments.step38_figures',
        'python.exe -B -X utf8 -m cavr_wbc.experiments.step38_verify',
        '```', '', f'运行时：E:/CAVR-WBC/_runtime_step30/python311/python.exe；工作树：{ROOT}。',
        'Git 交付见 GIT_DELIVERY.json / FINAL_GIT_STATUS.txt；独立分支提交、不 reset 原 HEAD、不 push。'])
    text='\n'.join(lines)+'\n'
    for name in ('STEP38_REPORT.md','STEP38_RESEARCH_HANDOFF.md'):
        path=out/name;path.write_text(path.read_text(encoding='utf-8')+text,encoding='utf-8')
    return supplement

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--seal',action='store_true')
    if parser.parse_args().seal:print(seal())
    else:print({k:v for k,v in deliver().items() if k not in ('direct_incomplete_or_unavailable','necessary_suite','repair_target_test','repair_02_target_test','readback')})
