"""SciPilot saved-only all-result figures; no numerical experiment reruns."""
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap,BoundaryNorm
from matplotlib.lines import Line2D
from PIL import Image
from cavr_wbc.experiments.step38_io import *
from cavr_wbc.experiments.step38_inputs import plans,BRANCHES
from cavr_wbc.experiments.step34_storage import load_bank
from cavr_wbc.experiments.step38_report import is_safe

COLORS={'C':'#0072B2','MIDDLE':'#CC79A7','B':'#009E73'}
MARKERS={'thigh':'o','calf':'^'}

def profile(rows):
    fields=('D_m','progress02_04_m','first_packet_ready_ms')
    stats={}
    for field in fields:
        values=np.array([r[field] for r in rows if r.get(field) is not None and np.isfinite(r[field])])
        stats[field]={'n':len(values),'missing':len(rows)-len(values),
            'min':float(values.min()) if len(values) else None,'max':float(values.max()) if len(values) else None,
            'q25_q50_q75':np.quantile(values,[.25,.5,.75]).tolist() if len(values) else None}
    return {'rows':len(rows),'types':'categorical identity/status; continuous SI observations',
        'grouping':'16 physical snapshots x 3 health conditions x 3 branches; paired, not independent 144 samples',
        'continuous':stats,'missing_values_not_imputed':True,'plot_choice':'annotated categorical matrix plus all available paired scatters',
        'no_mean_bar_no_dual_axis_no_result_selection':True}

def save(fig,path):
    fig.canvas.draw();renderer=fig.canvas.get_renderer();w,h=fig.canvas.get_width_height()
    # Matplotlib retains locator-generated ticks outside the view interval,
    # but Axis.draw does not render those labels. Exclude only these undrawn
    # ticks from the canvas check; keep every rendered label in the check.
    undrawn_ticks=set()
    for ax in fig.axes:
        for axis,limits in ((ax.xaxis,ax.get_xlim()),(ax.yaxis,ax.get_ylim())):
            lo,hi=sorted(limits)
            for tick in axis.get_major_ticks()+axis.get_minor_ticks():
                if not lo-1e-10<=tick.get_loc()<=hi+1e-10:
                    undrawn_ticks.update((id(tick.label1),id(tick.label2)))
    clipped=[]
    for text in fig.findobj(matplotlib.text.Text):
        if id(text) not in undrawn_ticks and text.get_visible() and text.get_text():
            box=text.get_window_extent(renderer)
            if box.x0 < -2 or box.y0 < -2 or box.x1 > w+2 or box.y1 > h+2:clipped.append(text.get_text())
    for ext in ('png','pdf','svg'):
        target=path.with_suffix('.'+ext);fig.savefig(target,dpi=300,facecolor='white')
        if ext=='svg':target.write_text('\n'.join(line.rstrip() for line in target.read_text(encoding='utf-8').splitlines())+'\n',encoding='utf-8')
    with Image.open(path.with_suffix('.png')) as im:im.convert('L').save(path.parent/(path.stem+'_gray.png'))
    write(path.with_suffix('.QA.json'),{'nonempty_text_outside_canvas':clipped,'canvas_px':[w,h],
        'undrawn_locator_tick_labels_excluded':len(undrawn_ticks),
        'colorblind_palette':'Okabe-Ito; outcomes additionally letter coded',
        'grayscale_preview':path.stem+'_gray.png','visual_review_required':True})
    plt.close(fig)

def figures(run_id=RUN_ID):
    out=output(run_id);dest=out/'figures';dest.mkdir(parents=True,exist_ok=True)
    direct=read(out/'DIRECT_RESULTS.json');pairs=read(out/'HEALTH_INJURY_PAIRS.json')
    decisions=read(out/'GOVERNOR_DECISIONS.json');recognized=read(out/'RECOGNIZED_RESULTS.json')
    write(dest/'DATA_PROFILE.json',{'direct':profile(direct),'paired_rows':len(pairs),
        'decisions':len(decisions),'recognized_observed':sum(r['observed'] for r in recognized),
        'fresh_TEST_hashes':{name:sha(out/(name+'.json')) for name in ('DIRECT_RESULTS','HEALTH_INJURY_PAIRS','GOVERNOR_DECISIONS','RECOGNIZED_RESULTS')}})
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.titlesize':10,'axes.labelsize':9,
        'svg.fonttype':'none','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
    fig=plt.figure(figsize=(12.2,7.2),layout='constrained');gs=fig.add_gridspec(2,2,width_ratios=[1.5,1])
    ax=fig.add_subplot(gs[:,0]);progress=fig.add_subplot(gs[0,1]);margin=fig.add_subplot(gs[1,1])
    snapshots=list(dict.fromkeys(p['snapshot_id'] for p in plans()));by={(r['snapshot_id'],r['health_kind'],r['branch']):r for r in direct}
    cells=[];labels=[]
    for snap in snapshots:
        codes=[]
        for health in ('HEALTHY','THIGH_15','CALF_15'):
            for name,_ in BRANCHES:
                r=by[snap,health,name]
                code=0 if not r['observed'] else 1 if not r['complete'] else 2 if not r['physical_pass'] else 3 if not r['terminal_pass'] else 4 if not is_safe(r) else 5
                codes.append(code)
        cells.append(codes)
        labels.append(snap.replace('T38_','').replace('_T',' / t'))
    palette=['#EEEEEE','#B8B8B8','#D55E00','#CC79A7','#56B4E9','#009E73'];letters=['U','N','P','T','L','S']
    arr=np.asarray(cells);ax.imshow(arr,aspect='auto',cmap=ListedColormap(palette),norm=BoundaryNorm(np.arange(-.5,6.5),6))
    for i in range(16):
        for j in range(9):ax.text(j,i,letters[arr[i,j]],ha='center',va='center',fontsize=9)
    ax.set_yticks(range(16),labels);ax.set_xticks(range(9),['C','0.5','B']*3)
    for x in (2.5,5.5):ax.axvline(x,color='white',lw=2)
    ax.set_title('a  All 144 direct positions, primary 6 mm',loc='left',pad=24)
    for x,label in ((1,'Healthy'),(4,'Thigh 0.15'),(7,'Calf 0.15')):ax.text(x,-.8,label,ha='center',va='bottom')
    ax.set_xlabel('U not run; N numerical incomplete; P physical failure;\nT terminal failure; L local violation; S full safe',labelpad=9)
    ax.set_ylabel('Physical snapshot (not health/gamma replicate)')
    used=0
    for role in ('thigh','calf'):
        for name,_ in BRANCHES:
            group=[r for r in pairs if r['role']==role and r['branch']==name and r['both_complete']]
            xp=[r['healthy_progress02_04_m']*1000 for r in group if r['healthy_progress02_04_m'] is not None and r['injured_progress02_04_m'] is not None]
            yp=[r['injured_progress02_04_m']*1000 for r in group if r['healthy_progress02_04_m'] is not None and r['injured_progress02_04_m'] is not None]
            progress.scatter(xp,yp,s=22,marker=MARKERS[role],color=COLORS[name],alpha=.8)
            xm=[6-r['healthy_D_m']*1000 for r in group if r['healthy_D_m'] is not None and r['injured_D_m'] is not None]
            ym=[6-r['injured_D_m']*1000 for r in group if r['healthy_D_m'] is not None and r['injured_D_m'] is not None]
            margin.scatter(xm,ym,s=22,marker=MARKERS[role],color=COLORS[name],alpha=.8);used+=len(group)
    for a in (progress,margin):
        lo=min(*a.get_xlim(),*a.get_ylim());hi=max(*a.get_xlim(),*a.get_ylim());a.plot([lo,hi],[lo,hi],color='.6',ls='--',lw=.8)
        a.set_xlim(lo,hi);a.set_ylim(lo,hi);a.grid(alpha=.15)
    progress.set(title=f'b  Paired early progress ({used}/96 complete pairs)',xlabel='Healthy progress, 0.02–0.04 s (mm)',ylabel='Injured progress (mm)')
    margin.axhline(0,color='.4',lw=.7);margin.axvline(0,color='.4',lw=.7)
    margin.set(title='c  Paired local margin',xlabel='Healthy 6 − Dmax (mm)',ylabel='Injured 6 − Dmax (mm)')
    handles=[Line2D([],[],marker='o',ls='',color=v,label=k) for k,v in COLORS.items()]+[Line2D([],[],marker=v,ls='',color='.3',label=k) for k,v in MARKERS.items()]
    progress.legend(handles=handles,ncol=3,fontsize=7,frameon=False,loc='best')
    save(fig,dest/'FIGURE_1_ALL_DIRECT_PAIRS')
    fig,(ax,tr)=plt.subplots(1,2,figsize=(12.2,7.2),layout='constrained',gridspec_kw={'width_ratios':[1.1,1]})
    for i,d in enumerate(decisions):
        ms=d.get('command_ready_ms')
        if ms is not None:ax.scatter(ms,i,marker='o' if d['timely_recognized'] else 'x',color='#009E73' if d['timely_recognized'] else '#666666',s=25)
    ax.axvline(20,color='#D55E00',ls='--',lw=1,label='20 ms deadline')
    ax.set_yticks(range(32),[d['context_id'].replace('T38_','').replace('_THIGH_15',' / thigh').replace('_CALF_15',' / calf') for d in decisions],fontsize=7)
    ax.invert_yaxis();ax.set(xlabel='Complete decision command-ready (ms)',title='a  All 32 frozen-screen decisions')
    ax.legend(handles=[Line2D([],[],marker='o',ls='',color='#009E73',label='Timely recognized'),Line2D([],[],marker='x',ls='',color='.4',label='Not applied'),Line2D([],[],ls='--',color='#D55E00',label='20 ms')],frameon=False,fontsize=7)
    drawn=0
    for r in recognized:
        if not r['observed']:continue
        artifact=r.get('artifact') or {};bank=load_bank(out/Path(r['result_path']).parent/'actual.npz')
        rows=([bank['initial_fact']] if bank.get('initial_fact') else [])+bank['physics_trajectory']
        x=[v.get('time_s',v.get('physics_step',0)*.002) for v in rows if v.get('qpos') is not None]
        y=[r['direction']*(v['qpos'][0]-bank['fixed_anchor_q_init'][0])*1000 for v in rows if v.get('qpos') is not None]
        color='#009E73' if is_safe(r) else '#D55E00' if r['complete'] else '#666666'
        tr.plot(x,y,color=color,lw=.85,alpha=.75,ls='-' if r['complete'] else '--')
        if x:tr.plot(x[-1],y[-1],marker='o' if r['complete'] else 'x',color=color,ms=3)
        drawn+=1
    tr.axhline(6,color='#0072B2',ls=':',lw=1);tr.set(xlim=(0,1),xlabel='Sample-clock time (s)',ylabel='Signed displacement from frozen anchor (mm)',title=f'b  All recognized actual trajectories (n={drawn})')
    if not drawn:
        tr.set_ylim(0,8)
        tr.text(.5,.5,'Recognized actual: 0/32.\nNo trajectory was applied.',ha='center',va='center',transform=tr.transAxes)
    else:
        tr.legend(handles=[Line2D([],[],color='#009E73',label='Complete safe'),
            Line2D([],[],color='#D55E00',label='Complete unsafe'),
            Line2D([],[],color='#666666',ls='--',marker='x',label='Incomplete execution'),
            Line2D([],[],color='#0072B2',ls=':',label='Primary 6 mm')],frameon=False,fontsize=7)
    tr.grid(alpha=.15);save(fig,dest/'FIGURE_2_ALL_DECISIONS_ACTUAL')
    write(dest/'FIGURES_MANIFEST.json',{'scientific_figures':2,'source':'all saved results','new_QP_calls':0,'new_physics_steps':0,
        'all_direct_positions':144,'all_pairs':96,'complete_pairs_plotted':used,'all_decisions':32,'recognized_trajectories_plotted':drawn})

if __name__=='__main__':figures()
