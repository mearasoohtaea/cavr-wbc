"""Fixed fresh target and cross-direction named-channel intervention table."""
from copy import deepcopy
import numpy as np
from cavr_wbc.experiments.step35_sprint import add_previous_identity

MAGNITUDES=(.0635,.0665,.0695,.0725)
TICKS=(34,38)
KINDS=('HEALTHY','THIGH_15','CALF_15')
BRANCHES=(('C',1.),('MIDDLE',.5),('B',0.))
GAPS=(.004,.006,.008)

def episodes():
    return [{'episode_id':f'T38_M{i}_{side}','magnitude_index':i,'direction':direction,
             'displacement_m':direction*mag,'snapshot_ticks':list(TICKS)}
            for i,mag in enumerate(MAGNITUDES) for side,direction in (('P',1),('N',-1))]

def plans():
    rows=[]
    for ep in episodes():
        for si,tick in enumerate(TICKS):
            snap=ep['episode_id']+f'_T{tick:03d}'
            leg=('FR','RR')[(ep['magnitude_index']+si)%2]
            for kind in KINDS:
                cid=snap+'_'+kind
                rows.append({**ep,'episode':ep['episode_id'],'source_tick':tick,'tick':tick,
                    'snapshot_index':si,'snapshot_id':snap,'source_snapshot':snap,
                    'snapshot_ordinal':len(rows)//3,'ordinal':len(rows),'context_id':cid,'case_id':cid,
                    'source_state_id':cid,'source_state_ordinal':len(rows),'health_kind':kind,
                    'role':'healthy' if kind=='HEALTHY' else kind.split('_')[0].lower(),
                    'fault_leg':leg,'split':'FRESH_TEST','gap_m':.006,
                    'branch_order':[BRANCHES[(j+len(rows))%3][0] for j in range(3)]})
    return rows

def context_for(plan,episode,mapping):
    snap=next((s for s in episode.get('snapshots',[]) if s['source_tick']==plan['source_tick']),None)
    c=deepcopy(snap or {'eligible':False,'eligibility_reason':'REQUESTED_SNAPSHOT_NOT_PRODUCED'})
    c.update(deepcopy(plan),backup_id='STEP38-'+plan['context_id'],runtime_id=plan['context_id'],
        group='STEP38_FRESH_FIXED',front_or_rear='front' if plan['fault_leg']=='FR' else 'rear',
        original_direction=plan['direction'])
    h=np.ones(len(mapping));name='NONE';ix=None;health=1.
    if plan['role']!='healthy':
        name=plan['fault_leg']+'_'+plan['role']
        ix=next(r['actuator_index'] for r in mapping if r['actuator_name']==name)
        health=.15;h[ix]=health
    c.update(health_vector=h,faulted_actuator_name=name,faulted_actuator_index=ix,faulted_health=health,
        health_effective_from_sample_s=0.,plant_QP_feedback_health_identical=True,
        reference_complete=episode.get('status')=='COMPLETE',future_reference_completion_not_eligibility_gate=True)
    if snap:
        c['eligible']=bool(snap.get('eligible'))
        add_previous_identity(c,episode)
        c['previous_command_identity']['source']='NEW_STEP38_REFERENCE_CANDIDATE'
    else:c['previous_command_identity']={'available':False,'reason':'SNAPSHOT_NOT_PRODUCED'}
    return c

def reference_scenario(base):
    # Identical STEP35 recipe; no new posture disturbance or seed search.
    s=deepcopy(base);s['initial_roll']-=.002;s['initial_pitch']+=.002
    return s
