"""STEP38 paths and streaming evidence utilities; older evidence is read-only."""
from pathlib import Path
import numpy as np
from scipy import sparse
from cavr_wbc.experiments.step30_io import append, sha, encode, relative
import json
import os
from time import sleep

def write(path,value):
    """Metadata-only sharing-lock retry; never repeat numerical work."""
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    pending=path.with_suffix(path.suffix+'.'+str(os.getpid())+'.tmp')
    with pending.open('w',encoding='utf-8',newline='\n') as stream:
        json.dump(encode(value),stream,sort_keys=True,separators=(',',':'),allow_nan=False,ensure_ascii=False)
        stream.write('\n');stream.flush()
    for attempt in range(21):
        try:
            os.replace(pending,path)
            return
        except PermissionError:
            if attempt==20:raise
            sleep(.01)

def _restore(value):
    if isinstance(value, dict):
        if set(value) == {'nonfinite'}:
            return float(value['nonfinite'])
        return {key: _restore(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_restore(item) for item in value]
    return value

def read(path, default=None):
    path = Path(path)
    return _restore(json.loads(path.read_text(encoding='utf-8'))) if path.exists() else default


ROOT = Path(__file__).resolve().parents[2]
SOURCE30 = ROOT / 'artifacts/step30_injured_governor_20261008/step30-injured-governor-20261008-01'
RUN_ID = 'step38-fresh-recovery-20261010-01'
PARENT = 'bb622319100d57f3cdbfd69d330c0e2ee13886af'
MODEL_PARENT = 'dc9a2cdfc33e2abba2d581ac4cc3eed1456b5fde'
PROTOCOL = Path('E:/CAVR-WBC/experiment_handoff_20260921/NEXT_CODEX_INSTRUCTIONS_STEP38_FRESH_RECOVERY_AND_FROZEN_SCREEN_20261010.md')
METHODS = ('APPLICATION_FEAS_GOV', 'APPLICATION_FEAS_BINARY')


def output(run_id=RUN_ID):
    return ROOT / 'artifacts/step38_fresh_recovery_20261010' / run_id


def save_numeric(path, value):
    """Separate all numeric arrays/sparse QP witnesses from JSON indexes."""
    path = Path(path)
    arrays = {}

    def split(item):
        if sparse.issparse(item):
            c = item.tocsc()
            return {'sparse_format': 'csc', 'shape': list(c.shape),
                    'data': split(c.data), 'indices': split(c.indices), 'indptr': split(c.indptr)}
        if isinstance(item, np.ndarray):
            key = 'a' + str(len(arrays))
            arrays[key] = item
            return {'npz_key': key, 'shape': list(item.shape), 'dtype': str(item.dtype)}
        if isinstance(item, dict):
            return {str(k): split(v) for k, v in item.items()}
        if isinstance(item, (list, tuple)):
            return [split(v) for v in item]
        return encode(item)

    saved = split(value)
    path.parent.mkdir(parents=True, exist_ok=True)
    npz = path.with_suffix('.npz')
    with npz.open('xb') as stream:
        np.savez_compressed(stream, **arrays)
    write(path, {'numeric_npz': npz.name, 'numeric_sha256': sha(npz), 'record': saved})
    return {'json': str(path), 'npz': str(npz), 'json_sha256': sha(path),
            'npz_sha256': sha(npz), 'numeric_arrays': len(arrays)}


def load_numeric(path):
    """Restore one saved current-batch packet, without another decision/QP."""
    path = Path(path)
    saved = read(path)
    npz = path.parent / saved['numeric_npz']
    if sha(npz) != saved['numeric_sha256']:
        raise ValueError('current STEP38 numeric shard integrity mismatch')
    with np.load(npz, allow_pickle=False) as archive:
        def restore(item):
            if isinstance(item, dict) and 'npz_key' in item:
                return archive[item['npz_key']].copy()
            if isinstance(item, dict) and item.get('sparse_format') == 'csc':
                return sparse.csc_matrix((restore(item['data']), restore(item['indices']),
                    restore(item['indptr'])), shape=tuple(item['shape']))
            if isinstance(item, dict):
                return {key: restore(value) for key, value in item.items()}
            if isinstance(item, list):
                return [restore(value) for value in item]
            return item
        return restore(saved['record'])

SOURCE32 = ROOT / 'artifacts/step32_application_time_20261009/step32-application-time-20261009-01'


SOURCE33 = ROOT / 'artifacts/step33_calibration_repair_20261009/step33-calibration-repair-20261009-01'


SOURCE34 = ROOT / 'artifacts/step34_feasibility_application_20261009/step34-feasibility-application-20261009-01'


SOURCE35 = ROOT / 'artifacts/step35_reference_precision_20261009/step35-reference-precision-20261009-01'


SOURCE37 = ROOT / 'artifacts/step37_reduced_direct_recovery_20261010/step37-reduced-direct-recovery-20261010-01'
