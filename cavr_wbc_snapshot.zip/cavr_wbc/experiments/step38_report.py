"""Saved-only independent A/B/C summaries; no solve/integration or fitting."""
from collections import Counter
import numpy as np
from cavr_wbc.experiments.step38_io import *
from cavr_wbc.experiments.step38_inputs import plans,episodes,BRANCHES,GAPS
from cavr_wbc.experiments.step33_report import csv_write,statistics,finite

def dump(out,name,rows):
    write(out/(name+'.json'),rows);csv_write(out/(name+'.csv'),rows)

def branch_row(out,p,name,recognized=False):
    path=out/'states'/p['context_id']
    path=path/'RECOGNIZED_ACTUAL' if recognized else path/'DIRECT'/name
    r=read(path/'RESULT.json',{});lab=r.get('label') or {}
    complete=bool(r.get('complete_501'))
    return {**{k:p[k] for k in ('ordinal','context_id','episode','snapshot_id','role','health_kind','direction','fault_leg','source_tick')},
        'branch':'RECOGNIZED' if recognized else name,'gamma':r.get('gamma',dict(BRANCHES).get(name)),
        'status':r.get('status','NOT_RUN'),'reason':r.get('reason'),'observed':r.get('observed',False),
        'complete':complete,'physical_pass':bool(complete and lab.get('original_physical_safe')),
        'terminal_pass':bool(complete and lab.get('terminal_pass')),'D_m':lab.get('D'),'Y':lab.get('Y'),
        'physical_failure':bool(complete and not lab.get('original_physical_safe')),
        'partial_observed_physical_failure':bool(not complete and (lab.get('original_failure') or lab.get('observed_original_physical_failure'))),
        'progress02_04_m':r.get('progress02_04_m'),'progress0_04_m':r.get('progress0_04_m'),
        'timing_qualified':bool(r.get('timing_qualified')),'first_packet_ready_ms':r.get('first_packet_ready_ms'),
        'feedback_latencies_ms':r.get('feedback_latencies_ms',[]),'events':r.get('events'),
        'application_identity_pass':r.get('application_identity_pass'),'first_tau_matches_packet':r.get('first_tau_matches_packet'),
        'staging_summary':r.get('staging_summary'),'model_authorized':r.get('model_authorized',False),
        'selected_command_sent':r.get('selected_command_sent',False),'artifact':r.get('artifact'),
        'result_path':relative(path/'RESULT.json',out),'counts':r.get('counts',{})}

def is_safe(row,gap=.006):
    return bool(row['complete'] and row['physical_pass'] and row['terminal_pass'] and
        finite(row['D_m']) and 0<=row['D_m']<=gap and row['application_identity_pass'] is True and row['first_tau_matches_packet'] is True)

def actual_unsafe(row,gap=.006):
    return bool(row['complete'] and (not row['physical_pass'] or not row['terminal_pass'] or
        (finite(row['D_m']) and row['D_m']>gap)))

def evidence_counts(rows,key):
    hit=[r for r in rows if r.get(key)]
    return {'contexts':len(hit),'physical_snapshots':len({r['snapshot_id'] for r in hit}),
        'episodes':len({r['episode'] for r in hit})}

def criterion(counts):return counts['physical_snapshots']>=2 and counts['episodes']>=2

def analyze(run_id=RUN_ID):
    out=output(run_id);finish=read(out/'RUN_FINISHED.json',{});manifest=read(out/'PROTOCOL_AND_MANIFEST.json')
    registry=read(out/'BATCH_REGISTRY.json');direct=[branch_row(out,p,name) for p in plans() for name,_ in BRANCHES]
    rec=[branch_row(out,p,'RECOGNIZED',True) for p in plans() if p['role']!='healthy']
    by={(r['context_id'],r['branch']):r for r in direct};gaprows=[];A=[]
    for r in direct:
        for gap in GAPS:gaprows.append({**r,'gap_mm':round(gap*1000),'full_safe':is_safe(r,gap),
            'timing_qualified_safe':is_safe(r,gap) and r['timing_qualified'],
            'same_saved_trajectory_no_new_integration':True})
    for p in plans():
        C,M,B=(by[p['context_id'],n] for n in ('C','MIDDLE','B'))
        better=bool(finite(M['progress02_04_m']) and finite(B['progress02_04_m']) and M['progress02_04_m']>B['progress02_04_m'])
        for gap in GAPS:
            extension=bool(is_safe(M,gap) and is_safe(B,gap) and actual_unsafe(C,gap) and better)
            A.append({**p,'gap_mm':round(gap*1000),'observed':extension,
                'timing_qualified':bool(extension and all(x['timing_qualified'] for x in (C,M,B))),
                'C_complete':C['complete'],'C_physical_failure':C['physical_failure'],
                'C_local_only_failure':bool(C['complete'] and C['physical_pass'] and C['terminal_pass'] and finite(C['D_m']) and C['D_m']>gap),
                'middle_safe':is_safe(M,gap),'B_safe':is_safe(B,gap),'middle_progress_higher':better,
                'progress_gain_m':M['progress02_04_m']-B['progress02_04_m'] if better else None})
    paired=[];Bfacts=[]
    for p in plans():
        if p['role']=='healthy':continue
        hc=p['snapshot_id']+'_HEALTHY';C=by[p['context_id'],'C'];M=by[p['context_id'],'MIDDLE'];B=by[p['context_id'],'B'];H=by[hc,'C']
        effect=bool(is_safe(H) and C['physical_failure'] and is_safe(M) and is_safe(B))
        Bfacts.append({**p,'strong_damage_specific_physical_effect':effect,'healthy_C_safe':is_safe(H),
            'injured_C_complete_physical_failure':C['physical_failure'],'injured_M_safe':is_safe(M),'injured_B_safe':is_safe(B)})
        for name,_ in BRANCHES:
            a=by[hc,name];b=by[p['context_id'],name];both=a['complete'] and b['complete']
            pair={**p,'branch':name,'both_complete':bool(both),'healthy_status':a['status'],'injured_status':b['status'],
                'healthy_full_safe':is_safe(a),'injured_full_safe':is_safe(b),'healthy_Y':a['Y'],'injured_Y':b['Y'],
                'healthy_events':a['events'],'injured_events':b['events'],'missing_not_zero_filled':True}
            for key in ('D_m','progress02_04_m'):
                pair['healthy_'+key]=a[key] if a['complete'] else None
                pair['injured_'+key]=b[key] if b['complete'] else None
                pair['injured_minus_healthy_'+key]=b[key]-a[key] if both and finite(a[key]) and finite(b[key]) else None
            paired.append(pair)
    decisions=[];Cfacts=[]
    for p,r in zip([p for p in plans() if p['role']!='healthy'],rec):
        d=read(out/'states'/p['context_id']/'GOVERNOR_DECISION.json',{}).get('record',{})
        eligible=bool(registry[p['ordinal']].get('eligible'));sent=bool(d.get('selected_command_sent'))
        ds={'context_id':p['context_id'],'snapshot_id':p['snapshot_id'],'episode':p['episode'],'role':p['role'],
            'ordinal':p['ordinal'],'current_eligible':eligible,'decision_recorded':bool(d),'status':d.get('status','NOT_RUN'),
            'selected_gamma':d.get('selected_gamma'),'command_ready_ms':d.get('command_ready_ms'),
            'timely_recognized':sent,'actions':{g:{k:v for k,v in e.items() if k in ('evaluation_status','decision','feature_error')}
                for g,e in d.get('actions',{}).items()},'phase_latency_ms':d.get('phase_latency_ms'),
            'actual_status':r['status'],'complete_safe':is_safe(r),'unsafe_accepted':bool(sent and actual_unsafe(r)),
            'decision_before_direct_outcomes':True,'result_path':r['result_path']}
        decisions.append(ds)
        directB=by[p['context_id'],'B'];directC=by[p['context_id'],'C']
        utility=bool(sent and d.get('selected_gamma')==.5 and is_safe(r) and is_safe(directB) and
            finite(r['progress02_04_m']) and finite(directB['progress02_04_m']) and r['progress02_04_m']>directB['progress02_04_m'])
        Cfacts.append({**p,'screen_recovery_utility':utility,'matched_mechanism_concordance':bool(utility and actual_unsafe(directC)),
            'same_source_separate_packets_not_exact_packet_counterfactual':True})
    primary=[r for r in A if r['gap_mm']==6];Ac=evidence_counts(primary,'observed');Bc=evidence_counts(Bfacts,'strong_damage_specific_physical_effect')
    Cc=evidence_counts(Cfacts,'screen_recovery_utility');Cc_match=evidence_counts(Cfacts,'matched_mechanism_concordance')
    finished=finish.get('status')=='COMPLETED' and all(r['status']=='DONE' for r in registry)
    def result_status(obs):return 'OBSERVED' if obs else 'NOT_ESTABLISHED' if finished else 'INCOMPLETE'
    eligible=sum(d['current_eligible'] for d in decisions);accepted=sum(d['timely_recognized'] for d in decisions)
    unsafe=sum(d['unsafe_accepted'] for d in decisions)
    summary={'A':{'status':result_status(criterion(Ac)),'primary_gap_mm':6,'counts':Ac,
        'timing_qualified_counts':evidence_counts(primary,'timing_qualified'),
        'name':'FRESH_DIRECT_SAFE_ACTION_EXTENSION' if criterion(Ac) else 'NOT_ESTABLISHED'},
        'B':{'status':result_status(criterion(Bc)),'strong_damage_specific_physical_effect_counts':Bc,
        'local_only_task_boundary_recovery_contexts':sum(r['observed'] and r['C_local_only_failure'] for r in primary)},
        'C':{'status':result_status(criterion(Cc) and unsafe==0),
        'name':'FROZEN_SCREEN_RECOVERY_UTILITY_OBSERVED' if criterion(Cc) and unsafe==0 else 'NOT_ESTABLISHED',
        'utility_counts':Cc,'matched_mechanism_concordance_counts':Cc_match,
        'planned':32,'current_eligible':eligible,'timely_recognized':accepted,
        'planned_coverage':accepted/32,'eligible_coverage':accepted/eligible if eligible else None,
        'ACTUAL_complete':sum(r['complete'] for r in rec),'complete_safe':sum(is_safe(r) for r in rec),
        'unsafe_accepted':unsafe,
        'decision_deadline_miss':sum(finite(d['command_ready_ms']) and d['command_ready_ms']>20 for d in decisions),
        'ACTUAL_feedback_deadline_miss':sum(r['status']=='FAILED_DEADLINE' for r in rec),
        'deadline_miss':sum(finite(d['command_ready_ms']) and d['command_ready_ms']>20 for d in decisions)+sum(r['status']=='FAILED_DEADLINE' for r in rec),
        'numerical_incomplete':sum(r['observed'] and not r['complete'] and r['status']!='FAILED_DEADLINE' for r in rec),
        'zero_acceptance_not_zero_risk_success':True,'latency_ms':statistics([d['command_ready_ms'] for d in decisions if finite(d['command_ready_ms'])])},
        'numerical_status':finish.get('status','INCOMPLETE'),'budget':finish.get('budget'),
        'denominators':{'reference_episodes':8,'physical_snapshots':16,'health_contexts':48,'direct_branches':144,'injured_decisions':32},
        'direct_statuses':dict(Counter(r['status'] for r in direct)),'direct_complete':sum(r['complete'] for r in direct),
        'recognized_statuses':dict(Counter(r['status'] for r in rec)),
        'actual_new_reference_QP_calls':(finish.get('budget') or {}).get('QP_by_kind',{}).get('REFERENCE',0),
        'actual_new_reference_steps':(finish.get('budget') or {}).get('physics_by_kind',{}).get('REFERENCE',0),
        'new_model_fits':0,'CAL':read(out/'CAL_FREEZE.json',{}),'formal_population_generalization':False,
        'async_continuous_hardware_guarantee':False,'E3_RL_HARDWARE':'NOT_AUTHORIZED'}
    for name,rows in [('DIRECT_RESULTS',direct),('GAP_RESULTS',gaprows),('DIRECT_MECHANISM_RESULTS',A),
        ('HEALTH_INJURY_PAIRS',paired),('DAMAGE_SPECIFIC_RESULTS',Bfacts),('GOVERNOR_DECISIONS',decisions),
        ('RECOGNIZED_RESULTS',rec),('SCREEN_UTILITY_RESULTS',Cfacts)]:dump(out,name,rows)
    write(out/'STEP38_RESULT.json',summary)
    budget=summary['budget'] or {};lines=[f'# STEP38：新轨迹恢复与冻结筛选器',
        '',f"A = {summary['A']['status']}；B = {summary['B']['status']}；C = {summary['C']['status']}。",
        f"6 mm 主判据直接扩展：{Ac['contexts']} context / {Ac['physical_snapshots']} 物理 snapshot / {Ac['episodes']} episode。",
        f"能力损伤特异的物理机制：{Bc['contexts']} context / {Bc['physical_snapshots']} snapshot / {Bc['episodes']} episode。",
        f"冻结筛选器：{accepted}/32 及时认可，{summary['C']['ACTUAL_complete']} 条完整实际轨迹，{summary['C']['complete_safe']} 条完整安全，{unsafe} 条完整实测错误接受。",
        '',f"实际新增 {budget.get('total_QP_calls')} 次 QP、{budget.get('total_physics_steps')} 步积分、fit=0；预算耗时 {budget.get('numerical_elapsed_s')} s。",
        f"新 reference：{summary['actual_new_reference_QP_calls']} QP / {summary['actual_new_reference_steps']} 步；直接轨迹完整 {summary['direct_complete']}/144。",
        '', '## 证据与解释边界', '',
        '主任务不受 CAL/弃权门控制。所有健康—受损配对及失败位保留；4/8 mm 为同轨迹的 secondary 评价，不是新增样本。',
        '只有完整实测违反才作 C unsafe；数值未完成及认可执行中止不填完整安全标签。局部边界效用与真实接触/全身物理效用分别统计。',
        '反馈 command-ready 包括 seed、configure、staging、检查与 commit/拷贝；较 STEP37 wrapper 范围更完整，不作无说明的跨轮加速比较。',
        '迟到认可反馈不施加；direct 迟到作为 offline 对照保留。所用控制时钟未加入逐 tick 的额外通信/运算等待，不构成异步、硬件或连续时间安全保证。',
        'STEP37 全48条 RED轨迹明确转为已曝光 CAL，新预测 prefix 独立从 application context 积分10步；预测完成后才读旧标签。训练系数不变、旧历史不修改。',
        '', '## 下一步', '', '按 A/B/C 分别使用本批证据，后续研究或面板需新协议；本轮不进入 E3、RL 或硬件。',
        '', '## Material Passport', '', 'Origin Skill: experiment-agent / SciPilot；Mode: run；Date: 2026-10-10 Asia/Seoul；Verification: current delivery readback only。',
        '', '## 协议状态', '', '```ini']
    protocol=PROTOCOL.read_text(encoding='utf-8');lines.extend(protocol.split('~~~ini')[1].split('~~~')[0].strip().splitlines())
    lines.extend(['```','',f"NUMERICAL_STATUS = {summary['numerical_status']}",f"A_STATUS = {summary['A']['status']}",
        f"B_STATUS = {summary['B']['status']}",f"C_STATUS = {summary['C']['status']}"])
    report='\n'.join(lines)+'\n'
    (out/'STEP38_REPORT.md').write_text(report,encoding='utf-8')
    (out/'STEP38_RESEARCH_HANDOFF.md').write_text(report+'\n数据：DIRECT_RESULTS、HEALTH_INJURY_PAIRS、GOVERNOR_DECISIONS、RECOGNIZED_RESULTS 与对应 raw/trajectory/controls。\n',encoding='utf-8')
    return summary

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('run_id',nargs='?',default=RUN_ID);print(analyze(p.parse_args().run_id))
