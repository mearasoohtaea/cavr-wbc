"""One fresh fixed panel; causal frozen-screen decision precedes direct outcomes."""
from copy import deepcopy
from datetime import datetime,timezone
from time import perf_counter
import argparse,gc,os,traceback
import numpy as np
from cavr_wbc.experiments.step38_io import *
from cavr_wbc.experiments.step38_inputs import episodes,plans,context_for,reference_scenario,BRANCHES,GAPS
from cavr_wbc.experiments.step38_budget import SprintBudget,SprintLimit
from cavr_wbc.experiments.step38_calibration import calibrate
from cavr_wbc.experiments.step35_reference import reference_episode
from cavr_wbc.experiments.step28_sprint import home_context
from cavr_wbc.experiments.step34_storage import save_bank,load_bank
from cavr_wbc.experiments.step35_sprint import current_events
from cavr_wbc.control.step34_margin import labels
from cavr_wbc.experiments import step17_formal_panel as frozen
from cavr_wbc.platforms.go2_mujoco import extract_actuator_audit,extract_healthy_torque_limits

def event(out,name,**fields):
    append(out/'ATTEMPT_LEDGER.jsonl',{'event':name,'timestamp_utc':datetime.now(timezone.utc).isoformat(),**fields})

def save_branch(out,directory,name,branch,c,packet,recognized=False,recover_saved=False):
    path=directory/name;path.mkdir(parents=True,exist_ok=True)
    record={k:v for k,v in branch.items() if k in ('status','reason','gamma','counts','progress02_04_m','progress0_04_m',
        'application_identity_pass','application_state_match','first_tau_matches_packet','backup_memory_restore',
        'application_state_check','identity_error','staging_summary')}
    record.update(result_path=relative(path/'RESULT.json',out),observed=branch['status']!='NOT_RUN',
        model_authorized=bool(recognized and packet.get('selected_command_sent')),
        selected_command_sent=bool(recognized and packet.get('selected_command_sent')),
        scope='FROZEN_SCREEN_RECOGNIZED_ACTUAL' if recognized else 'DIRECT_COUNTERFACTUAL',
        first_packet_ready_ms=packet.get('command_ready_ms'),feedback_timing_scope='FULL_STAGE_CONFIGURE_SEED_RESTORE_CHECK_COMMIT',
        first_packet_timing_status='TIMELY' if packet.get('command_ready_ms',float('inf'))<=20 else 'LATE_FIRST_PACKET_OFFLINE_ONLY',
        realtime_deployment_evidence=False,additional_feedback_waits_simulated=False)
    if record['observed']:
        record['artifact']=({'path':str(path/'actual.npz'),'sha256':sha(path/'actual.npz'),
            'row_count':len(branch['physics_trajectory'])+int(branch.get('initial_fact') is not None),
            'recovered_saved_only_no_QP_or_integration':True} if recover_saved else save_bank(path/'actual.npz',branch))
        controls=branch['controls']
        if recover_saved:
            record['controls_numeric']={'path':str(path/'CONTROL_RESULTS.json'),
                'json_sha256':sha(path/'CONTROL_RESULTS.json'),'npz_sha256':sha(path/'CONTROL_RESULTS.npz')}
        else:record['controls_numeric']=save_numeric(path/'CONTROL_RESULTS.json',
            {'controls':controls,'status':branch['status'],'reason':branch.get('reason')})
        # Original evaluator's public boundary is serialized lists, not ndarray
        # comparison; retain exact values without changing any physical gate.
        from cavr_wbc.experiments.step29_sim import _json_safe
        lab=labels(branch,_json_safe(c));record['label']=lab
        first=controls[1]['capacity_interface'] if len(controls)>1 else {}
        record['events']=current_events(branch,{'capacity_interface':first,
            'first_capacity_event':bool(len(first.get('sent_99_percent_active_indices',[])))})
        unapplied=[r for r in controls if r.get('tau_applied') is None]
        record['events']['unapplied_rows_including_late']=len(unapplied)
        fb=[r.get('latency_ms') for r in controls if r.get('slot',0)>1]
        firstms=packet.get('command_ready_ms')
        complete=bool(lab.get('complete') and lab.get('full_501_grid'))
        timely=bool(complete and np.isfinite(firstms) and firstms<=20 and len(fb)==48 and
                    all(v is not None and np.isfinite(v) and 0<=v<=20 for v in fb))
        record.update(complete_501=complete,timing_qualified=timely,all_tick_deadline_pass=timely,
            feedback_latencies_ms=fb,tick_latency_ms=[r.get('latency_ms') for r in controls],
            checkpoints=len(branch['checkpoints']),execution_failure_not_full_label=not complete)
    else:record.update(label={},complete_501=False,timing_qualified=False)
    write(path/'RESULT.json',record)
    if record.get('identity_error'):raise ValueError('application prediction/full integration-state identity mismatch')
    if record['status']=='FAILED_BUDGET':raise SprintLimit('partial branch saved at cap')
    return record

def not_run(gamma,reason):
    return {'status':'NOT_RUN','gamma':gamma,'reason':{'reason':reason}}

def make_owner(model,dll,budget,c,manifest,Kernel):
    k=Kernel(model,'BOUNDED',str(dll),budget)
    home=home_context(model,manifest['scenario']);home.update(context_id=c['context_id']+':HOME',backup_id=c['backup_id']+':HOME')
    startup=k.startup(home,budget);k.flush_raw_evidence()
    return k,startup

def run(run_id=RUN_ID,repair=False):
    from cavr_wbc.control.step38_kernel import Kernel,direct_packet
    from cavr_wbc.experiments import step38_sim as sim
    out=output(run_id)
    if (out/'RUN_STARTED.json').exists() and not repair:raise FileExistsError('unique STEP38 batch already attempted')
    out.mkdir(parents=True,exist_ok=True)
    model=frozen.load_model();old=read(SOURCE35/'MANIFEST.json')
    limits=extract_healthy_torque_limits(model)
    mapping=[dict(r,healthy_limit_nm=float(limits[r['actuator_index']])) for r in extract_actuator_audit(model)]
    dll=SOURCE30/'native/step30_prefix.dll'
    manifest={'run_id':run_id,'source_commit':PARENT,'protocol_sha256':sha(PROTOCOL),'mapping':mapping,
        'scenario':old['scenario'],'reference_scenario':reference_scenario(old['scenario']),
        'frozen_physical':old['frozen_physical'],'native_dll_path':str(dll),'native_dll_sha256':sha(dll),
        'episodes':episodes(),'contexts':plans(),'representation':'REDUCED_WHITENED_RESIDENT',
        'primary_gap_m':.006,'secondary_gaps_m':[.004,.008],'branches':BRANCHES,
        'reference_eps':1e-8,'candidate_eps':1e-7,'deadline_ms':20,'first_B_limit_s':.006,
        'first_C_limit_s':.003,'feedback_limit_s':.006,'friction_upper_N':-1e-4,'torque_inset_Nm':1e-4,
        'original_inequality_extra_slack':0,'horizon_s':1,'physics_dt_s':.002,
        'max_QP_calls':20000,'max_physics_steps':200000,'max_wall_s':7200,'new_model_fits':0,
        'primary_direct_panel_independent_of_CAL_readiness':True}
    if not repair:write(out/'PROTOCOL_AND_MANIFEST.json',manifest)
    else:manifest=read(out/'PROTOCOL_AND_MANIFEST.json')
    runtime=[*ROOT.glob('cavr_wbc/control/step38_*.py'),*ROOT.glob('cavr_wbc/experiments/step38_*.py'),*ROOT.glob('tests/test_step38*.py')]
    oldhash=read(SOURCE37/'RUNTIME_FREEZE.json')['runtime_sha256']
    runtime.extend(ROOT/p for p in oldhash if (ROOT/p).exists())
    if repair:
        repair_ordinal=len(list((out/'repairs').glob('REPAIR_*_STARTED.json')))+1
        for previous in ('REPAIR_RUNTIME_FREEZE.json','REPAIR_ENVIRONMENT.json'):
            if (out/previous).exists():write(out/'repairs'/f'REPAIR_{repair_ordinal:02d}_PREVIOUS_{previous}',read(out/previous))
    write(out/('REPAIR_RUNTIME_FREEZE.json' if repair else 'RUNTIME_FREEZE.json'),{'runtime_sha256':{relative(p,ROOT):sha(p) for p in runtime},
        'protocol_sha256':sha(PROTOCOL),'fixed_input_table':plans(),'date':'2026-10-10','timezone':'Asia/Seoul'})
    import scipy,osqp,mujoco,threadpoolctl
    write(out/('REPAIR_ENVIRONMENT.json' if repair else 'ENVIRONMENT.json'),{'numpy':np.__version__,'scipy':scipy.__version__,'osqp':osqp.__version__,
        'mujoco':mujoco.__version__,'threadpools':threadpoolctl.threadpool_info(),'TMP':os.environ.get('TMP'),
        'resource_check_once':True,'all_output_on_E':True})
    budget=SprintBudget.resume_dev_repair(out) if repair else SprintBudget(out);status='COMPLETED';cache={}
    registry=read(out/'BATCH_REGISTRY.json') if repair else [dict(p,status='NOT_RUN') for p in plans()]
    if not repair:
        write(out/'BATCH_REGISTRY.json',registry)
        write(out/'RUN_STARTED.json',{'run_id':run_id,'pid':os.getpid(),'start_utc':datetime.now(timezone.utc).isoformat()})
    try:
        if repair:
            from cavr_wbc.control.step34_margin import load_bundle
            bundle=load_bundle(out/'models/step38_frozen_screen.npz') if (out/'models/step38_frozen_screen.npz').exists() else None
            contexts=load_numeric(out/'FRESH_CONTEXTS.json')
            budget.event('REPAIR_REUSES_FROZEN_CAL_REFERENCES_CONTEXTS_NO_RECOMPUTATION',new_CAL_prefixes=0,new_reference_solves=0)
        else:
            bundle,calfreeze=calibrate(out,model,dll,budget,Kernel)
            budget.event('CAL_FROZEN_BEFORE_FRESH_TEST',cal_freeze_sha256=sha(out/'CAL_FREEZE.json'))
            for ep in episodes():
                event(out,'START',kind='FRESH_REFERENCE',**ep)
                episode=reference_episode(model,manifest['reference_scenario'],ep['displacement_m'],ep['episode_id'],
                    ep['snapshot_ticks'],budget,evidence_callback=budget.record_raw)
                save_numeric(out/'episodes'/(ep['episode_id']+'.json'),episode)
                event(out,'RETURN',kind='FRESH_REFERENCE',episode=ep['episode_id'],status=episode['status'],counts=episode['counts'])
                cache[ep['episode_id']]=episode;budget.persist(phase='REFERENCE_SAVED',episode=ep['episode_id'])
            contexts=[context_for(p,cache[p['episode']],mapping) for p in plans()]
            save_numeric(out/'FRESH_CONTEXTS.json',contexts)
        for p,c in zip(plans(),contexts):
            if registry[p['ordinal']]['status']=='DONE':continue
            directory=out/'states'/c['context_id'];directory.mkdir(parents=True,exist_ok=True)
            if repair and ((directory/'DIRECT/PACKET.json').exists() or (directory/'GOVERNOR_DECISION.json').exists()):
                # Completed banks can be evaluated without reconstructing any
                # live native owner. Every other already-started slot remains
                # unrecoverable; never solve a replacement packet.
                packets={}
                for name,gamma in BRANCHES:
                    path=directory/'DIRECT'/name
                    if (path/'RESULT.json').exists():continue
                    packet=load_numeric(directory/'DIRECT/PACKET.json') if (directory/'DIRECT/PACKET.json').exists() else {}
                    if (path/'actual.npz').exists():
                        saved=load_bank(path/'actual.npz');save_branch(out,directory/'DIRECT',name,saved,c,packet,recover_saved=True)
                    else:save_branch(out,directory/'DIRECT',name,not_run(gamma,'INTERRUPTION_NO_ORIGINAL_LIVE_OWNER'),c,packet)
                if c['role']!='healthy' and not (directory/'RECOGNIZED_ACTUAL/RESULT.json').exists():
                    packet=load_numeric(directory/'GOVERNOR_DECISION.json')
                    path=directory/'RECOGNIZED_ACTUAL'
                    if (path/'actual.npz').exists():save_branch(out,directory,'RECOGNIZED_ACTUAL',load_bank(path/'actual.npz'),c,packet,True,True)
                    else:save_branch(out,directory,'RECOGNIZED_ACTUAL',not_run(packet.get('selected_gamma'),'INTERRUPTION_NO_ORIGINAL_LIVE_OWNER'),c,packet,True)
                registry[p['ordinal']].update(status='DONE',eligible=bool(c.get('eligible')),interrupted_native_owner_lost=True)
                write(out/'BATCH_REGISTRY.json',registry);budget.persist(phase='INTERRUPTED_CONTEXT_PRESERVED',context_ordinal=p['ordinal'])
                continue
            if not (directory/'SOURCE_IDENTITY.json').exists():save_numeric(directory/'SOURCE_IDENTITY.json',{'context':c,'plan':p,
                'reference_json_sha256':sha(out/'episodes'/(p['episode']+'.json')),
                'reference_npz_sha256':sha(out/'episodes'/(p['episode']+'.npz'))})
            if c['role']!='healthy':
                event(out,'START',kind='GOVERNOR_DECISION',context_id=c['context_id'],CAL_freeze_sha256=sha(out/'CAL_FREEZE.json'))
                if c.get('eligible'):
                    live,prime=make_owner(model,dll,budget,c,manifest,Kernel)
                    write(directory/'GOVERNOR_STARTUP.json',prime)
                    decision=live.governor(c,bundle,.006,budget)
                    live.flush_raw_evidence()
                else:
                    live=None;decision={'context_id':c['context_id'],'selected_command_sent':False,
                        'status':'SOURCE_INELIGIBLE','command_ready_ms':0.,'actions':{},'selected_action':None}
                save_numeric(directory/'GOVERNOR_DECISION.json',decision)
                event(out,'DECISION_IMMUTABLY_SAVED',context_id=c['context_id'],selected_command_sent=decision.get('selected_command_sent'),
                    selected_gamma=decision.get('selected_gamma'),decision_sha256=sha(directory/'GOVERNOR_DECISION.json'),
                    direct_packet_or_results_not_generated=True)
                if decision.get('selected_command_sent'):
                    actual=sim.propagate(live,c,decision,budget,purpose='RECOGNIZED_ACTUAL',require_sent=True)
                else:actual=not_run(decision.get('selected_gamma'),'ABSTAIN_OR_LATE_NOT_APPLIED')
                save_branch(out,directory,'RECOGNIZED_ACTUAL',actual,c,decision,recognized=True)
                if live is not None:del live
                budget.persist(phase='GOVERNOR_AND_RECOGNIZED_SAVED',context_ordinal=p['ordinal'])
            directdir=directory/'DIRECT';directdir.mkdir(parents=True,exist_ok=True)
            if c.get('eligible'):
                owners={};startup={}
                for name in p['branch_order']:owners[name],startup[name]=make_owner(model,dll,budget,c,manifest,Kernel)
                write(directdir/'STARTUP.json',startup)
                packet=direct_packet(owners['B'],c,budget,owners)
                owners['B'].flush_raw_evidence()
            else:
                owners={};packet={'context_id':c['context_id'],'selected_command_sent':False,'model_authorized':False,
                    'status':'SOURCE_INELIGIBLE','command_ready_ms':0.,'actions':{}}
            save_numeric(directdir/'PACKET.json',packet)
            for name in p['branch_order']:
                gamma=dict(BRANCHES)[name];action=(packet['actions'].get(str(gamma)) or {}).get('action') or {}
                event(out,'START',kind='DIRECT_COUNTERFACTUAL',context_id=c['context_id'],branch=name,gamma=gamma)
                if action.get('command_valid') and action.get('execution_eligible'):
                    branch=sim.propagate(owners[name],c,packet,budget,purpose=name,action=action,require_sent=False)
                else:branch=not_run(gamma,'CURRENT_SAME_PACKET_WITNESS_UNAVAILABLE')
                record=save_branch(out,directdir,name,branch,c,packet)
                event(out,'RETURN',kind='DIRECT_COUNTERFACTUAL',context_id=c['context_id'],branch=name,status=record['status'])
                budget.persist(phase='DIRECT_BRANCH_SAVED',context_ordinal=p['ordinal'],branch=name)
            registry[p['ordinal']].update(status='DONE',eligible=bool(c.get('eligible')))
            write(out/'BATCH_REGISTRY.json',registry)
            budget.persist(phase='CONTEXT_DONE',contexts_processed=p['ordinal']+1)
            print({'phase':'CONTEXT_DONE','context':c['context_id'],'contexts':p['ordinal']+1,'planned':48,'budget':budget.snapshot()},flush=True)
            del owners;gc.collect()
    except SprintLimit as exc:
        status='INCOMPLETE_BUDGET';write(out/'INTERRUPTION.json',{'type':'BUDGET','error':str(exc),'budget':budget.snapshot()})
    except BaseException as exc:
        status='STOPPED_IMPLEMENTATION_OR_RESOURCE'
        write(out/'INTERRUPTION.json',{'type':type(exc).__name__,'error':str(exc),'traceback':traceback.format_exc(),'budget':budget.snapshot()})
        raise
    finally:
        budget.event('NUMERICAL_FINISHED',status=status,**budget.snapshot());budget.close()
        write(out/'RUN_FINISHED.json',{'run_id':run_id,'status':status,'budget':budget.snapshot(),
            'finish_utc':datetime.now(timezone.utc).isoformat()})
        print({'status':status,'budget':budget.snapshot()},flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('run_id',nargs='?',default=RUN_ID)
    parser.add_argument('--dev-engineering-repair',action='store_true');args=parser.parse_args()
    run(args.run_id,args.dev_engineering_repair)
