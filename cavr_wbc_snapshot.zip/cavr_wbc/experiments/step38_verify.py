"""One current-delivery readback. No historical rerun or new scientific gate."""
from collections import Counter
import json
import numpy as np
from cavr_wbc.experiments.step38_io import *
from cavr_wbc.experiments.step38_inputs import plans,episodes,BRANCHES
from cavr_wbc.experiments.step34_storage import load_bank

def verify(run_id=RUN_ID):
    out=output(run_id);errors=[];checks={};hashes={}
    def check(name,value):
        checks[name]=bool(value)
        if not value:errors.append(name)
    finish=read(out/'RUN_FINISHED.json');budget=finish['budget'];registry=read(out/'BATCH_REGISTRY.json')
    contexts=load_numeric(out/'FRESH_CONTEXTS.json');manifest=read(out/'PROTOCOL_AND_MANIFEST.json')
    check('fixed_48_contexts',len(contexts)==48 and len(registry)==48)
    check('16_unique_snapshots_8_episodes',len({c['snapshot_id'] for c in contexts})==16 and len({c['episode'] for c in contexts})==8)
    for p,c in zip(plans(),contexts):
        expected=('FR','RR')[(p['magnitude_index']+p['snapshot_index'])%2]
        check(c['context_id']+':mapping',c['fault_leg']==expected and c['context_id']==p['context_id'])
        h=np.asarray(c['health_vector']);index=c['faulted_actuator_index']
        check(c['context_id']+':health',len(h)==12 and np.count_nonzero(h<1.)==int(p['role']!='healthy') and
            (index is None if p['role']=='healthy' else h[index]==.15 and c['faulted_actuator_name']==expected+'_'+p['role']))
        siblings=[r for r in contexts if r['snapshot_id']==c['snapshot_id']]
        check(c['context_id']+':matched_source',all(np.array_equal(r['state']['integration_state'],c['state']['integration_state']) and
            np.array_equal(r['previous_tau_sent'],c['previous_tau_sent']) and np.array_equal(r['backup_anchor_q_init'],c['backup_anchor_q_init']) for r in siblings))
    refs=[]
    for ep in episodes():
        saved=load_numeric(out/'episodes'/(ep['episode_id']+'.json'));refs.append(saved)
        check(ep['episode_id']+':fresh_identity',saved['episode_id']==ep['episode_id'] and saved['d_ref_m']==ep['displacement_m'])
        check(ep['episode_id']+':reference_precision',saved['reference_settings']['eps_abs']==1e-8 and saved['reference_settings']['eps_rel']==1e-8)
    ledger=[json.loads(line) for line in (out/'STEP38_LEDGER.jsonl').read_text(encoding='utf-8').splitlines()]
    starts=[r for r in ledger if r['event']=='QP_START'];returns=[r for r in ledger if r['event']=='QP_RETURN'];raws=[r for r in ledger if r['event']=='RAW_QP_SAVED']
    check('QP_accounting_no_fabricated_unknown',len(starts)==budget['total_QP_calls'] and len(returns)==budget['QP_returns'] and
        len(starts)-len(returns)==budget['unknown_native_returns'])
    check('one_start_return_each_recorded_call',Counter(r['global_qp_index'] for r in starts)==Counter(r['global_qp_index'] for r in returns))
    check('every_return_full_raw_preserved',len(raws)==len(returns) and len({r['global_qp_index'] for r in raws})==len(returns))
    reduced_count=0
    for r in raws:
        path=out/r['path'];asset=read(path)
        check(f"raw{r['global_qp_index']}:hash",sha(path)==r['json_sha256'] and sha(path.with_suffix('.npz'))==r['npz_sha256'])
        if r['kind']=='REFERENCE':continue
        raw=load_numeric(path)['raw_result'];reduced_count+=1
        check(f"raw{r['global_qp_index']}:reduced_dimensions",raw.get('step37_representation')=='REDUCED_WHITENED_RESIDENT' and
            tuple(raw['step37_native_dimensions'])==(12,50) and raw['step37_native_problem']['A'].shape==(50,12) and
            raw['step37_original_problem']['A'].shape==(80,42))
        check(f"raw{r['global_qp_index']}:frozen_settings",raw.get('configured_eps_abs')==1e-7 and raw.get('configured_eps_rel')==1e-7 and
            raw.get('step37_torque_box_inset_Nm')==1e-4)
    prstarts=[r for r in ledger if r['event']=='PREFIX_NATIVE_START'];prreturns=[r for r in ledger if r['event']=='PREFIX_NATIVE_RETURN']
    check('native_steps_returned_without_unknown_reservation',len(prstarts)==len(prreturns) and budget['uncompleted_native_step_reservations']==0)
    check('no_new_fits_and_original_caps',budget['multioutput_estimator_fits']==0 and budget['physical_risk_head_fits']==0 and
        budget['total_QP_calls']<=20000 and budget['total_physics_steps']<=200000 and budget['numerical_elapsed_s']<=7200)
    cal=[]
    for path in sorted((out/'CAL').glob('A*.json')):
        item=load_numeric(path);r=item['record'];cal.append(r)
        check(path.stem+':CAL_not_TEST_predictor',r['split']=='CAL' and r['source_split']=='STEP37_EXPOSED_TEST' and
            r['future_target_consumed_only_after_prefix_features'] and r['new_QP_calls']==0)
        source_id=r['id'].removeprefix('CAL38:').rsplit(':',1)[0]
        branch_name=dict((g,n) for n,g in BRANCHES)[r['gamma']]
        source_dir=SOURCE37/'states'/source_id/'REDUCED_WHITENED_RESIDENT'
        check(path.stem+':cited_old_evidence_unchanged',sha(source_dir/'PACKET.json')==r['source_packet_sha256'] and
            sha(source_dir/branch_name/'RESULT.json')==r['source_actual_result_sha256'])
        prefix=r.get('prefix') or {};features=r.get('features26')
        if prefix.get('complete'):
            check(path.stem+':true_new_prefix_shape',prefix.get('actual_steps',prefix.get('physics_steps'))==10 and np.shape(features)==(26,) and
                np.shape(prefix['numeric']['qpos'])==(11,19) and np.shape(prefix['numeric']['qvel'])==(11,18))
    check('all48_CAL_records',len(cal)==48)
    frozen=read(out/'CAL_FREEZE.json');trained=SOURCE34/'models/step34_trained_only.npz'
    check('source_coefficients_unchanged',sha(trained)==frozen['source_trained_NPZ_sha256'] and sha(trained.with_suffix('.json'))==frozen['source_trained_JSON_sha256'])
    if frozen['status']=='FROZEN':
        from cavr_wbc.control.step34_margin import load_bundle,identity
        check('frozen_predictor_identity_unchanged',identity(load_bundle(out/'models/step38_frozen_screen.npz'))==frozen['predictor_identity'])
        check('exact_six_CAL_groups',len(frozen['groups'])==6)
    attempts=[json.loads(line) for line in (out/'ATTEMPT_LEDGER.jsonl').read_text(encoding='utf-8').splitlines()]
    decisions=[r for r in attempts if r['event']=='DECISION_IMMUTABLY_SAVED'];check('32_decisions_saved',len(decisions)==32)
    for d in decisions:
        own=[i for i,r in enumerate(attempts) if r.get('context_id')==d['context_id']]
        di=next(i for i in own if attempts[i]['event']=='DECISION_IMMUTABLY_SAVED')
        direct=[i for i in own if attempts[i].get('kind')=='DIRECT_COUNTERFACTUAL']
        check(d['context_id']+':causal_before_direct_results',bool(direct) and di<min(direct))
        check(d['context_id']+':immutable_decision_hash',sha(out/'states'/d['context_id']/'GOVERNOR_DECISION.json')==d['decision_sha256'])
    branch_count=recognized_count=complete_count=deadlines=0;steps=0
    for p in plans():
        for name in [n for n,_ in BRANCHES]+(['RECOGNIZED_ACTUAL'] if p['role']!='healthy' else []):
            base=out/'states'/p['context_id'];path=base/name if name=='RECOGNIZED_ACTUAL' else base/'DIRECT'/name
            r=read(path/'RESULT.json');check(p['context_id']+':'+name+':result_present',r is not None)
            if r is None:continue
            branch_count+=name!='RECOGNIZED_ACTUAL';recognized_count+=name=='RECOGNIZED_ACTUAL'
            if not r['observed']:continue
            branch=load_bank(path/'actual.npz');n=branch['counts']['physical_steps'];steps+=n
            check(p['context_id']+':'+name+':bank_hash',sha(path/'actual.npz')==r['artifact']['sha256'])
            if branch['status']=='COMPLETE':
                complete_count+=1
                check(p['context_id']+':'+name+':500_501_21',n==500 and len(branch['physics_trajectory'])+1==501 and len(branch['checkpoints'])==21 and len(branch['controls'])==50)
                check(p['context_id']+':'+name+':application_identity',branch['application_identity_pass'] and branch['first_tau_matches_packet'])
            if name=='RECOGNIZED_ACTUAL':
                check(p['context_id']+':recognized_not_offline',r['selected_command_sent'] and r['first_packet_ready_ms']<=20)
                rejected=[v for v in branch['controls'] if not v.get('staging_committed') and v['slot']>1]
                for v in rejected:
                    deadlines+=v.get('latency_ms',0)>20
                    check(p['context_id']+':late_unapplied',v['tau_applied'] is None and not v['actual_ctrl_written'] and
                        n==v['slot']*10)
    check('144_direct_and32_recognized_positions',branch_count==144 and recognized_count==32)
    check('actual_steps_match_saved_banks',steps==budget['physics_by_kind'].get('ACTUAL',0))
    freeze=read(out/('REPAIR_RUNTIME_FREEZE.json' if (out/'REPAIR_RUNTIME_FREEZE.json').exists() else 'RUNTIME_FREEZE.json'))
    # Only experimental runtime is frozen; saved-only report/figure/verify code
    # is delivery tooling, not a numerical input or a new advancement gate.
    for p,digest in freeze['runtime_sha256'].items():
        if any(s in p for s in ('step38_report','step38_figures','step38_verify','step38_delivery')):continue
        check('runtime:'+p,sha(ROOT/p)==digest)
    check('protocol_hash_unchanged',sha(PROTOCOL)==manifest['protocol_sha256'])
    for path in sorted(out.rglob('*')):
        if path.is_file() and path.name not in ('CURRENT_READBACK.json','FILE_HASHES.json'):hashes[relative(path,out)]=sha(path)
    write(out/'FILE_HASHES.json',hashes)
    result={'status':'READBACK_OK' if not errors else 'READBACK_ISSUES','checks':checks,'errors':errors,
        'native_reduced_raw_records':reduced_count,'all_QP_raw_records':len(raws),'complete_saved_branches':complete_count,
        'actual_integration_steps_readback':steps,'new_QP_calls':0,'new_physics_steps':0,'historical_audit_not_run':True,
        'readback_runs':1,'no_extra_advancement_gate':True,'output_file_count':len(hashes)}
    write(out/'CURRENT_READBACK.json',result);print({k:v for k,v in result.items() if k!='checks'})
    return result

if __name__=='__main__':verify()
