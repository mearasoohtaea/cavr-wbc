"""Saved-only STEP39 aggregation and one current-run evidence readback.

No controller construction, optimizer, integration, fit, or numerical retry.
"""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import csv, json, argparse
import numpy as np
from cavr_wbc.experiments.step39_io import output, read, write, load_numeric, sha, relative, OUTPUT_ROOT_D
from cavr_wbc.experiments.step39_inputs import plans, BRANCHES

def physical(r):
    return bool(r.get('complete_501') and r.get('physical_pass'))

def physical_terminal(r):
    return bool(physical(r) and r.get('terminal_pass'))

def safe(r, gap=.006):
    return bool(physical_terminal(r) and r.get('D_m') is not None and r['D_m'] <= gap)

def outcome(r):
    if not r.get('observed'): return 'NOT_RUN'
    if not r.get('complete_501'): return 'NUMERICAL_INCOMPLETE'
    if not r.get('physical_pass'): return 'PHYSICAL_FAIL'
    if not r.get('terminal_pass'): return 'TERMINAL_FAIL'
    return 'SAFE_6MM' if safe(r) else 'LOCAL_FAIL_ONLY'

def csv_save(path, rows):
    fields=list(dict.fromkeys(k for r in rows for k in r))
    with path.open('x', newline='', encoding='utf-8') as f:
        w=csv.DictWriter(f, fieldnames=fields); w.writeheader()
        for r in rows:
            w.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else v for k,v in r.items()})

def flatten(p, name, r, path, out):
    lab=r.get('label') or {}; cap=r.get('capacity') or {}
    controls=cap.get('control_series',[])
    ratios=[v['actual_tau_capacity_ratio'] for v in controls if v.get('applied') and v.get('actual_tau_capacity_ratio') is not None]
    fail=cap.get('first_dense_physical_failure') or {}
    fb=r.get('feedback_latencies_ms',[])
    return dict(id=p['context_id']+':'+name, context_id=p['context_id'], split=p['split'],
        episode=p['episode'], snapshot_id=p['snapshot_id'], tick=p['tick'], condition=p['health_kind'],
        role=p['role'], fault_leg=p['fault_leg'], health=p['health'], branch=name,
        gamma=r.get('gamma'), result_path=relative(path,out), result_exists=path.exists(),
        status=r.get('status','NOT_RUN'), reason=r.get('reason'), observed=bool(r.get('observed')),
        complete_501=bool(r.get('complete_501')), physical_pass=lab.get('original_physical'),
        terminal_pass=lab.get('original_terminal'), D_m=lab.get('D_m',lab.get('D')),
        terminal_Y=lab.get('Y'), progress02_04_m=r.get('progress02_04_m'), progress0_04_m=r.get('progress0_04_m'),
        timing_qualified=bool(r.get('timing_qualified')), first_packet_ready_ms=r.get('first_packet_ready_ms'),
        max_feedback_latency_ms=max(fb) if fb else None, feedback_deadline_misses=sum(v>20 for v in fb),
        selected_command_sent=bool(r.get('selected_command_sent')), model_authorized=bool(r.get('model_authorized')),
        fault_name=cap.get('fault_name'), fault_index=cap.get('fault_index'),
        first_actual_99percent_s=cap.get('first_actual_99percent_s'),
        actual_99percent_slots=cap.get('actual_99percent_slots'), max_actual_tau_capacity_ratio=max(ratios) if ratios else None,
        antiwindup_frozen_slots=sum(v.get('antiwindup_frozen',False) for v in controls if v['slot']>1),
        first_dense_failure_s=fail.get('time_s'), first_dense_failure_reasons=fail.get('reasons'),
        capacity_precedes_failure=bool(cap.get('activation_precedes_first_failure')),
        identity_error=r.get('identity_error'), trajectory_npz=(r.get('artifact') or {}).get('path'))

def counts(rows):
    return dict(planned=len(rows), result_records=sum(r['result_exists'] for r in rows),
        attempted=sum(r['observed'] for r in rows), complete_501=sum(r['complete_501'] for r in rows),
        complete_physical_pass=sum(physical(r) for r in rows), complete_physical_terminal=sum(physical_terminal(r) for r in rows),
        complete_safe_6mm=sum(safe(r) for r in rows), timing_qualified=sum(r['timing_qualified'] for r in rows),
        outcomes=dict(Counter(outcome(r) for r in rows)), statuses=dict(Counter(r['status'] for r in rows)))

def collect(out):
    rows=[]; records={}; contexts={}; decisions=[]; query_rows=[]
    for split in ('CAL','TEST'):
        path=out/(split+'_CONTEXTS.json')
        if path.exists(): contexts.update({c['context_id']:c for c in load_numeric(path)})
        for p in plans(split):
            folder=out/split/p['context_id']
            for name in p['branch_order']+(['RECOGNIZED'] if p['governor_planned'] else []):
                path=folder/(('DIRECT/'+name) if split=='TEST' and name!='RECOGNIZED' else name)/'RESULT.json'
                r=read(path,{})
                row=flatten(p,name,r,path,out); rows.append(row); records[row['id']]=r
            if p['governor_planned']:
                path=folder/'GOVERNOR_DECISION.json'; d=load_numeric(path) if path.exists() else {}
                q=[]
                for gamma in (.5,0.):
                    e=(d.get('actions') or {}).get(str(gamma),{}); n=(e.get('decision') or {}).get('numeric',{})
                    ab=e.get('reserve_ablation') or {}
                    qr=dict(context_id=p['context_id'],snapshot_id=p['snapshot_id'],episode=p['episode'],
                        condition=p['health_kind'],gamma=gamma,evaluation_status=e.get('evaluation_status','NOT_RUN'),
                        evaluated=e.get('evaluation_status')=='EVALUATED',accepted=(e.get('decision') or {}).get('accepted'),
                        U_D_main_m=ab.get('main_U_D_m'), U_D_ablation_m=ab.get('ablation_U_D_m'),
                        main_local_eligible=ab.get('main_local_eligible'),ablation_local_eligible=ab.get('ablation_local_eligible'),
                        U_T=np.asarray(n['U_T']).tolist() if 'U_T' in n else None,
                        gates={k:bool(n[k]) for k in ('finite_input','pose_gate','support_gate','distance_gate','calibration_gate','physical_risk_gate') if k in n},
                        complete_at_ms=e.get('complete_at_ms'))
                    q.append(qr); query_rows.append(qr)
                recognized=next(r for r in rows if r['id']==p['context_id']+':RECOGNIZED')
                c=contexts.get(p['context_id'],{})
                decisions.append(dict(context_id=p['context_id'],snapshot_id=p['snapshot_id'],episode=p['episode'],
                    condition=p['health_kind'],eligible=bool(c.get('eligible')),decision_exists=path.exists(),
                    decision_path=relative(path,out),status=d.get('status','NOT_RUN'),
                    command_ready_ms=d.get('command_ready_ms'),selected_gamma=d.get('selected_gamma'),
                    selected_command_sent=bool(d.get('selected_command_sent')),overall_deadline_failure=bool(d.get('overall_deadline_failure')),
                    complete_actual=recognized['complete_501'],safe_actual_6mm=safe(recognized),actual_outcome=outcome(recognized),
                    ablation_choice_identified=bool(d.get('ablation_final_choice_identified')),
                    ablation_unqueried_B='UNIDENTIFIED',queries=q))
    return rows, records, contexts, decisions, query_rows

def independent_endpoints(rows, decisions):
    by={r['id']:r for r in rows}; screen_pairs=[]; capacity_pairs=[]; local_pairs=[]
    for p in plans('TEST'):
        cid=p['context_id']; C,M,B=[by[cid+':'+n] for n in ('C','MIDDLE','B')]
        healthy_cid=p['snapshot_id']+'_HEALTHY'; healthy=by[healthy_cid+':C']
        gain=None if M['progress02_04_m'] is None or B['progress02_04_m'] is None else M['progress02_04_m']-B['progress02_04_m']
        if p['role']!='healthy':
            qualified=bool(physical_terminal(healthy) and C['complete_501'] and C['physical_pass'] is False and physical_terminal(M) and physical_terminal(B))
            capacity_pairs.append(dict(context_id=cid,snapshot_id=p['snapshot_id'],episode=p['episode'],
                condition=p['health_kind'],qualified=qualified,healthy_C_physical_terminal=physical_terminal(healthy),
                injured_C_complete_physical_failure=bool(C['complete_501'] and C['physical_pass'] is False),
                middle_physical_terminal=physical_terminal(M), B_physical_terminal=physical_terminal(B),
                C_actual_capacity_activation=bool(C['actual_99percent_slots']),
                C_capacity_precedes_failure=C['capacity_precedes_failure'],
                strong_capacity_evidence=bool(qualified and C['actual_99percent_slots'] and C['capacity_precedes_failure']),
                complete_pair=all(r['complete_501'] for r in (healthy,C,M,B)),middle_B_progress_gain_m=gain))
        for gap in (.004,.006,.008):
            qualified=bool(safe(M,gap) and safe(B,gap) and gain is not None and gain>0 and C['complete_501'] and not safe(C,gap))
            local_pairs.append(dict(context_id=cid,snapshot_id=p['snapshot_id'],episode=p['episode'],gap_m=gap,
                qualified=qualified,complete_triplet=all(r['complete_501'] for r in (C,M,B)),middle_B_progress_gain_m=gain))
        if p['governor_planned']:
            R=by[cid+':RECOGNIZED']; d=next(d for d in decisions if d['context_id']==cid)
            gainR=None if R['progress02_04_m'] is None or B['progress02_04_m'] is None else R['progress02_04_m']-B['progress02_04_m']
            qualified=bool(d['selected_command_sent'] and d['selected_gamma']==.5 and safe(R) and safe(B) and gainR is not None and gainR>0)
            screen_pairs.append(dict(context_id=cid,snapshot_id=p['snapshot_id'],episode=p['episode'],
                qualified=qualified,recognized_middle_safe=safe(R) and d['selected_gamma']==.5,
                matched_direct_B_safe=safe(B),recognized_B_progress_gain_m=gainR,
                direct_C_complete_unsafe=bool(C['complete_501'] and not safe(C)),
                complete_accepted_unsafe=bool(d['selected_command_sent'] and R['complete_501'] and not safe(R)),
                timely_accepted_incomplete=bool(d['selected_command_sent'] and not R['complete_501']),
                exact_same_packet_counterfactual=False))
    def endpoint(pairs, incompletes):
        q=[p for p in pairs if p['qualified']]; ns=len({p['snapshot_id'] for p in q}); ne=len({p['episode'] for p in q})
        return dict(status='OBSERVED' if ns>=2 and ne>=2 else 'INCOMPLETE' if incompletes else 'NOT_ESTABLISHED',
            qualified_contexts=len(q),physical_snapshots=ns,episodes=ne,qualified_context_ids=[p['context_id'] for p in q],pairs=pairs)
    screen=endpoint(screen_pairs,any(p['timely_accepted_incomplete'] for p in screen_pairs) or any(not d['decision_exists'] for d in decisions))
    unsafe=sum(p['complete_accepted_unsafe'] for p in screen_pairs)
    if unsafe: screen['status']='NOT_ESTABLISHED'
    screen.update(planned=16,eligible=sum(d['eligible'] for d in decisions),decisions_saved=sum(d['decision_exists'] for d in decisions),
        timely_recognized=sum(d['selected_command_sent'] for d in decisions),complete_actual=sum(d['complete_actual'] for d in decisions),
        complete_safe=sum(d['safe_actual_6mm'] for d in decisions),complete_unsafe_accepts=unsafe,
        late=sum(d['overall_deadline_failure'] for d in decisions),abstain=sum(d['status']=='ABSTAIN' for d in decisions),
        accepted_numerical_incomplete=sum(p['timely_accepted_incomplete'] for p in screen_pairs),
        zero_error_goal='FAILED' if unsafe else 'NOT_IDENTIFIED' if any(p['timely_accepted_incomplete'] for p in screen_pairs) or not any(d['selected_command_sent'] for d in decisions) else 'NO_COMPLETE_ERROR_OBSERVED')
    capacity=endpoint(capacity_pairs,any(not p['complete_pair'] for p in capacity_pairs))
    capacity['strong_capacity_qualified_contexts']=sum(p['strong_capacity_evidence'] for p in capacity_pairs)
    secondary={str(int(g*1000)):endpoint([p for p in local_pairs if p['gap_m']==g],any(not p['complete_triplet'] for p in local_pairs if p['gap_m']==g)) for g in (.004,.006,.008)}
    return dict(screen_execution=screen,capacity_physical=capacity,local_secondary_6mm=secondary['6'],offline_gap_reassessment=secondary)

def readback(out, rows, records, contexts):
    """One pass over this run only; use serialized facts, never solve/step."""
    from cavr_wbc.experiments.step39_storage import load_branch
    from cavr_wbc.control.step34_margin import labels
    from cavr_wbc.experiments.step29_sim import _json_safe
    issues=[]; loaded=0; complete=0
    for row in rows:
        rec=records[row['id']]
        if not row['observed']: continue
        path=out/row['result_path']; directory=path.parent
        if sha(directory/'actual.npz')!=rec['artifact']['sha256']: issues.append(row['id']+':fact hash')
        for ext,key in (('json','json_sha256'),('npz','npz_sha256')):
            if sha(directory/('controls.'+ext))!=rec['controls_numeric'][key]: issues.append(row['id']+':control hash')
        branch=load_branch(directory); lab=labels(branch,_json_safe(contexts[row['context_id']]))
        for key in ('complete','full_501_grid','original_physical','original_terminal','observed_original_physical_failure'):
            if lab.get(key)!=rec['label'].get(key): issues.append(row['id']+':label '+key)
        for key in ('D_m','Y'):
            a,b=lab.get(key),rec['label'].get(key)
            if (a is None)!=(b is None) or (a is not None and not np.allclose(a,b,rtol=0,atol=1e-12,equal_nan=True)):
                issues.append(row['id']+':numeric label '+key)
        if row['complete_501']:
            complete+=1
            if branch['counts']['physical_steps']!=500 or len(branch['physics_trajectory'])+1!=501 or len(branch['checkpoints'])!=21:
                issues.append(row['id']+':grid')
        loaded+=1
    events=[json.loads(line) for line in (out/'STEP39_LEDGER.jsonl').read_text(encoding='utf-8').splitlines()]
    starts=[e for e in events if e['event']=='QP_START']; returns=[e for e in events if e['event']=='QP_RETURN']; raw=[e for e in events if e['event']=='RAW_QP_SAVED']
    ix=lambda a:[e['global_qp_index'] for e in a]
    if sorted(ix(starts))!=sorted(ix(returns)) or sorted(ix(starts))!=sorted(ix(raw)) or sorted(ix(starts))!=list(range(1,len(starts)+1)):
        issues.append('QP identity/count')
    for e in raw:
        path=out/e['path']
        if sha(path)!=e['json_sha256'] or sha(path.with_suffix('.npz'))!=e['npz_sha256']: issues.append(e['path']+':raw hash')
    if sorted(e['reservation_id'] for e in events if e['event']=='PREFIX_NATIVE_START')!=sorted(e['reservation_id'] for e in events if e['event']=='PREFIX_NATIVE_RETURN'):
        issues.append('prediction reservation return count')
    from cavr_wbc.control.step39_margin import load_bundle,identity
    cal=read(out/'CAL_FREEZE.json',{})
    if cal.get('asset'):
        trained=load_bundle(out/'models/step39_trained_only.npz'); frozen=load_bundle(out/'models/step39_frozen_screen.npz')
        if not (identity(trained)==identity(frozen)==cal['predictor_identity_before']==cal['predictor_identity_after']): issues.append('predictor identity')
    freeze=read(out/'RUNTIME_FREEZE.json')
    for name,digest in freeze['runtime_sha256'].items():
        if sha(OUTPUT_ROOT_D/name)!=digest: issues.append(name+':runtime hash')
    if sha(Path(read(out/'PROTOCOL_AND_MANIFEST.json')['native_dll_path']))!=read(out/'PROTOCOL_AND_MANIFEST.json')['native_dll_sha256']:
        issues.append('readonly native DLL hash')
    result=dict(status='VERIFIED' if not issues else 'EVIDENCE_ERROR',issues=issues,
        observed_banks_read_once=loaded,complete_grids_verified=complete,qp_starts=len(starts),qp_returns=len(returns),raw_qp_shards=len(raw),
        unknown_qp=len(starts)-len(returns),coefficient_identity_unchanged=True if cal.get('asset') and 'predictor identity' not in issues else None,
        label_tolerance=1e-12,new_optimizer_calls=0,new_physics_steps=0,new_fits=0,
        scope='STEP39_CURRENT_RUN_ONLY',timestamp_utc=datetime.now(timezone.utc).isoformat())
    write(out/'CURRENT_RUN_READBACK.json',result)
    return result

def summarize(out):
    if not (out/'RUN_FINISHED.json').exists(): raise RuntimeError('Numerical process must finish before saved-only delivery')
    if (out/'STEP39_RESULT.json').exists(): raise FileExistsError('single delivery already attempted')
    rows,records,contexts,decisions,queries=collect(out)
    evidence=readback(out,rows,records,contexts)
    endpoints=independent_endpoints(rows,decisions)
    result=dict(schema='STEP39_SAVED_ONLY_RESULT_V1',run_id=out.name,run=read(out/'RUN_FINISHED.json'),
        train=read(out/'TRAIN_COUNTS.json'),calibration=read(out/'CAL_FREEZE.json'),
        CAL=counts([r for r in rows if r['split']=='CAL']),TEST_direct=counts([r for r in rows if r['split']=='TEST' and r['branch']!='RECOGNIZED']),
        TEST_recognized=counts([r for r in rows if r['branch']=='RECOGNIZED']),readback=evidence,
        independent_TEST_physical_snapshots=4,independent_TEST_episodes=2,all_planned_branch_positions=len(rows),
        endpoint_statuses={k:v['status'] for k,v in endpoints.items() if k!='offline_gap_reassessment'},endpoints=endpoints,
        result_based_retries=0,numerical_DEV_recomputations=0,prelaunch_storage_repairs=1,
        empirical_reserve_not_physical_error_bound=True,no_population_generalization=True,all_new_files_on_D=True,
        E_source_read_only=True,E3_RL_hardware_authorized=False)
    write(out/'ALL_PLANNED_RESULTS.json',rows);csv_save(out/'ALL_BRANCH_RESULTS.csv',rows)
    write(out/'ALL_GOVERNOR_DECISIONS.json',decisions); csv_save(out/'GOVERNOR_DECISIONS.csv',[{k:v for k,v in d.items() if k!='queries'} for d in decisions])
    csv_save(out/'RESERVE_ABLATION_QUERIES.csv',queries)
    write(out/'STEP39_RESULT.json',result)
    print(json.dumps({k:result[k] for k in ('endpoint_statuses','CAL','TEST_direct','TEST_recognized','readback')},ensure_ascii=False))
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--run-id',default=None);args=p.parse_args()
    summarize(output(args.run_id) if args.run_id else output())
