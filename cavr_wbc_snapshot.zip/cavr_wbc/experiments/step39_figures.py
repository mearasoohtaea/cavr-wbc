"""Two SciPilot all-result figures; saved evidence only, no fits/solves/steps."""
import argparse, sys, warnings
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from matplotlib.colors import to_rgba
from cavr_wbc.experiments.step39_io import output,read,write
from cavr_wbc.experiments.step39_delivery import safe,physical_terminal,outcome

SKILL=Path('C:/Users/ZhuanZ（无密码）/.codex/skills/scipilot-figure/scripts')
sys.path.insert(0,str(SKILL))
from setup_style import setup_style
from profile_data import profile_data,render_report
setup_style(journal='ieee',lang='en',use_sciplots=False)
plt.rcParams.update({'font.size':8,'xtick.labelsize':8,'ytick.labelsize':8,'legend.fontsize':8,
    'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','pdf.fonttype':42,
    'figure.constrained_layout.use':False,'figure.autolayout':False})
BLUE='#0072B2'; ORANGE='#E69F00'; RED='#D55E00'; PURPLE='#CC79A7'; GREEN='#009E73'; GREY='#BBBBBB'
COLORS=dict(SAFE_6MM=BLUE,PHYSICAL_FAIL=RED,TERMINAL_FAIL=PURPLE,LOCAL_FAIL_ONLY=ORANGE,
    NUMERICAL_INCOMPLETE='#DDDDDD',NOT_RUN='white')
SYMBOLS=dict(SAFE_6MM='S',PHYSICAL_FAIL='P',TERMINAL_FAIL='T',LOCAL_FAIL_ONLY='L',NUMERICAL_INCOMPLETE='?',NOT_RUN='x')

def row_axes(ax,n):
    ax.set_ylim(n-.5,-.5);ax.set_yticks(range(n));ax.tick_params(axis='y',length=0)
    ax.grid(axis='x',color='#E0E0E0',lw=.5,zorder=0)
    for j in range(1,n):
        if j%4==0:ax.axhline(j-.5,color='#CCCCCC',lw=.6,zorder=0)

def figure1(rows,decisions):
    by={r['id']:r for r in rows};n=16
    fig,axs=plt.subplots(1,4,figsize=(7.16,6.5),sharey=True)
    fig.set_layout_engine(None)
    fig.subplots_adjust(left=.16,right=.985,bottom=.13,top=.80,wspace=.25)
    ticks=[];lat=[];uds=[];ds=[];gains=[]
    for j,d in enumerate(decisions):
        snap=d['snapshot_id'];si=list(dict.fromkeys(x['snapshot_id'] for x in decisions)).index(snap)+1
        kind=d['condition'].replace('THIGH15','th .15').replace('CALF15','ca .15').replace('_',' ')
        ticks.append(f'S{si} {kind}')
        v=d.get('command_ready_ms');sent=d['selected_command_sent'];late=d['overall_deadline_failure']
        if v is not None and np.isfinite(v):
            axs[0].plot(v,j,'o' if sent else 'X' if late else 'x',c=BLUE if sent else RED if late else '#666666',ms=4)
            lat.append(v)
        else:axs[0].text(.02,j,'NA',transform=axs[0].get_yaxis_transform(),va='center',color='#777777',fontsize=7)
        any_u=False
        for q in d['queries']:
            offset=-.14 if q['gamma']==.5 else .14
            values=[]
            for key,color,marker in (('U_D_main_m',BLUE,'o'),('U_D_ablation_m',ORANGE,'D')):
                v=q.get(key)
                if v is not None and np.isfinite(v):
                    axs[1].plot(v*1000,j+offset,marker=marker,color=color,ms=3,fillstyle='full' if q['gamma']==.5 else 'none',ls='none')
                    uds.append(v*1000);values.append(v*1000);any_u=True
            if len(values)==2:axs[1].plot(values,[j+offset,j+offset],c='#AAAAAA',lw=.6,zorder=0)
        if not any_u:axs[1].text(.03,j,'no finite U_D',transform=axs[1].get_yaxis_transform(),va='center',fontsize=6.5,color='#666666')
        r=by[d['context_id']+':RECOGNIZED'];b=by[d['context_id']+':B']
        v=r.get('D_m')
        if r['complete_501'] and v is not None:
            axs[2].plot(v*1000,j,'o' if safe(r) else 'X',c=GREEN if safe(r) else RED,ms=4);ds.append(v*1000)
        else:axs[2].text(.02,j,'partial' if r['observed'] else 'unapplied',transform=axs[2].get_yaxis_transform(),va='center',fontsize=7,color='#777777')
        if r['complete_501'] and b['complete_501'] and r.get('progress02_04_m') is not None and b.get('progress02_04_m') is not None:
            gain=(r['progress02_04_m']-b['progress02_04_m'])*1000
            axs[3].plot(gain,j,'o' if safe(r) and safe(b) else 'X',c=GREEN if safe(r) and safe(b) else RED,ms=4);gains.append(gain)
        else:axs[3].text(.02,j,'unidentified',transform=axs[3].get_yaxis_transform(),va='center',fontsize=7,color='#777777')
    for ax in axs:row_axes(ax,n)
    axs[0].set_yticklabels(ticks)
    for ax in axs[1:]:ax.tick_params(labelleft=False)
    axs[0].axvline(20,c=RED,ls='--',lw=.8);axs[0].set_xlim(0,max(24,max(lat,default=0)*1.1));axs[0].set_xlabel('Command-ready\nlatency (ms)')
    axs[1].axvline(6,c='#333333',ls='--',lw=.8);axs[1].set_xlim(0,max(8,max(uds,default=0)*1.05));axs[1].set_xlabel('Same-input\nU_D (mm)')
    axs[2].axvline(6,c='#333333',ls='--',lw=.8);axs[2].set_xlim(0,max(8,max(ds,default=0)*1.1));axs[2].set_xlabel('Recognized actual\nD (mm)')
    axs[3].axvline(0,c='#333333',lw=.7);axs[3].set_xlim(min(-.05,min(gains,default=0)*1.1),max(.1,max(gains,default=0)*1.15));axs[3].set_xlabel('Recognized - B\nprogress gain (mm)')
    for letter,ax,title in zip('abcd',axs,('Full decision window','Reserve ablation','Full 1 s actual','Paired .02-.04 s')):
        ax.set_title(title,fontsize=8,pad=8);ax.text(0,1.045,letter,transform=ax.transAxes,fontweight='bold',fontsize=10)
    fig.text(.16,.965,'All 16 planned decisions; four fresh physical snapshots, two episodes',fontsize=9)
    fig.text(.16,.923,'Latency: blue = sent; x = abstain; red X = late. U_D: blue circle R=.1 mm;',fontsize=8)
    fig.text(.16,.895,'orange diamond R=1 mm; filled = gamma .5, hollow = B. Green actual = safe.',fontsize=8)
    fig.text(.16,.035,'Unqueried B leaves the ablation final choice unidentified; no extra prefix or trajectory.',fontsize=8)
    return fig

def figure2(rows):
    direct=[r for r in rows if r['split']=='TEST' and r['branch']!='RECOGNIZED'];snaps=list(dict.fromkeys(r['snapshot_id'] for r in direct))
    cond=list(dict.fromkeys(r['condition'] for r in direct));names=[(c,b) for c in cond for b in ('C','MIDDLE','B')]
    by={(r['snapshot_id'],r['condition'],r['branch']):r for r in direct}
    fig,axs=plt.subplots(1,3,figsize=(7.16,7.4),sharey=True,gridspec_kw={'width_ratios':[1,1,1.2]})
    fig.set_layout_engine(None)
    fig.subplots_adjust(left=.195,right=.985,bottom=.15,top=.80,wspace=.19)
    for j,(c,b) in enumerate(names):
        for s,snap in enumerate(snaps):
            r=by[snap,c,b];o=outcome(r)
            axs[0].add_patch(Rectangle((s-.48,j-.48),.96,.96,facecolor=COLORS[o],edgecolor='#EEEEEE',lw=.4))
            axs[0].text(s,j,SYMBOLS[o],ha='center',va='center',color='white' if o in ('SAFE_6MM','PHYSICAL_FAIL') else '#222222',fontsize=8)
            v=r['max_actual_tau_capacity_ratio']
            fill='white' if v is None else plt.colormaps['cividis'](float(np.clip(v,0.,1.)))
            axs[1].add_patch(Rectangle((s-.48,j-.48),.96,.96,facecolor=fill,edgecolor='#EEEEEE',lw=.4))
            axs[1].text(s,j,'-' if v is None else f'{v:.2f}',ha='center',va='center',fontsize=7,color='#222222' if v is None or v>=.55 else 'white')
            pr=r['progress02_04_m']
            if pr is not None:
                axs[2].plot(pr*1000,j+(s-1.5)*.17,marker=('o','s','^','D')[s],c=(BLUE,GREEN,ORANGE,PURPLE)[s],ms=3,ls='none',fillstyle='full' if r['complete_501'] else 'none')
            else:axs[2].text(.02,j,'NA',transform=axs[2].get_yaxis_transform(),va='center',color='#777777',fontsize=7)
    for ax in axs:
        ax.set_ylim(len(names)-.5,-.5);ax.set_yticks(range(len(names)));ax.tick_params(axis='y',length=0)
        for j in range(3,len(names),3):ax.axhline(j-.5,c='#333333',lw=.5)
    short=lambda c:c.replace('HEALTHY','Healthy').replace('THIGH','th').replace('CALF','ca').replace('30',' .30').replace('15',' .15').replace('_',' ')
    axs[0].set_yticklabels([short(c)+' / '+('.5' if b=='MIDDLE' else b) for c,b in names])
    for ax in axs[1:]:ax.tick_params(labelleft=False)
    for ax in axs[:2]:ax.set_xlim(-.5,3.5);ax.set_xticks(range(4),[f'S{i+1}' for i in range(4)])
    axs[0].set_xlabel('Physical snapshot');axs[1].set_xlabel('Physical snapshot')
    axs[2].set_xlabel('Actual .02-.04 s\nprogress (mm)');axs[2].axvline(0,c='#333333',lw=.7);axs[2].grid(axis='x',c='#EEEEEE',lw=.5)
    for letter,ax,title in zip('abc',axs,('Independent outcome','Max fault |tau|/cap','Early task progress')):
        ax.set_title(title,fontsize=8,pad=10);ax.text(0,1.035,letter,transform=ax.transAxes,fontweight='bold',fontsize=10)
    fig.text(.195,.965,'All 84 same-state direct positions; no result-based exclusions',fontsize=9)
    fig.text(.195,.935,'S: physical + terminal + 6 mm pass; P: physical fail; T: terminal fail;',fontsize=8)
    fig.text(.195,.908,'L: local-only fail; ?: numerical incomplete; x: not run. Timing is separate.',fontsize=8)
    fig.text(.195,.880,'Ratio values retained for partials; healthy has no fault channel (-).',fontsize=8)
    handles=[plt.Line2D([],[],marker=m,c=co,ls='none',ms=4,label=f'S{i+1}') for i,(m,co) in enumerate(zip(('o','s','^','D'),(BLUE,GREEN,ORANGE,PURPLE)))]
    fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.6,.066),ncol=4,frameon=False)
    fig.text(.195,.033,'S1/S2: positive reference ticks 32/40; S3/S4: negative reference ticks 32/40.',fontsize=8)
    fig.text(.195,.008,'Four physical initial states, not 84 independent samples; hollow progress markers = partial.',fontsize=8)
    return fig

def figure_audit(fig):
    fig.canvas.draw();renderer=fig.canvas.get_renderer();issues=[];boxes=[]
    canvas=fig.bbox
    outside=set()
    for ax in fig.axes:
        for ticks,lim in ((ax.xaxis.get_major_ticks(),ax.get_xlim()),(ax.yaxis.get_major_ticks(),ax.get_ylim())):
            for tick in ticks:
                if not min(lim)-1e-12<=tick.get_loc()<=max(lim)+1e-12:
                    outside.update((id(tick.label1),id(tick.label2)))
    for t in fig.findobj(matplotlib.text.Text):
        if not t.get_visible() or not t.get_text() or id(t) in outside:continue
        b=t.get_window_extent(renderer)
        if b.x0 < canvas.x0-1 or b.y0 < canvas.y0-1 or b.x1 > canvas.x1+1 or b.y1 > canvas.y1+1:issues.append('clipped: '+t.get_text())
        if t.get_fontsize()<6:issues.append('font below 6 pt: '+t.get_text())
    for ax in fig.axes:
        for labels in (ax.get_xticklabels(),ax.get_yticklabels()):
            bb=[(t.get_text(),t.get_window_extent(renderer)) for t in labels if t.get_visible() and t.get_text() and id(t) not in outside]
            for (s,a),(v,b) in zip(bb,bb[1:]):
                if a.overlaps(b):issues.append('overlapping ticks: '+s+' / '+v)
    structural=fig.texts+[t for ax in fig.axes for t in (ax.title,ax.xaxis.label,ax.yaxis.label)]
    bb=[(t.get_text(),t.get_window_extent(renderer)) for t in structural if t.get_visible() and t.get_text()]
    for i,(s,a) in enumerate(bb):
        for v,b in bb[i+1:]:
            if a.overlaps(b):issues.append('overlapping structural text: '+s+' / '+v)
    return dict(status='PASS' if not issues else 'REVISE',issues=issues,width_in=fig.get_figwidth(),height_in=fig.get_figheight(),
        required_visual_review=['claim-data fit','layout/alignment','labels/units','color/encoding','scale/ticks','annotation overlap','font/glyphs','cross-panel consistency'])

def greyscale(fig):
    for artist in fig.findobj():
        for getter,setter in (('get_color','set_color'),('get_facecolor','set_facecolor'),('get_edgecolor','set_edgecolor')):
            if not hasattr(artist,getter) or not hasattr(artist,setter):continue
            try:
                r,g,b,a=to_rgba(getattr(artist,getter)());v=.2126*r+.7152*g+.0722*b
                getattr(artist,setter)((v,v,v,a))
            except (ValueError,TypeError):pass

def run(final=False):
    out=output();directory=out/'figures';directory.mkdir(exist_ok=True)
    rows=read(out/'ALL_PLANNED_RESULTS.json');decisions=read(out/'ALL_GOVERNOR_DECISIONS.json')
    if not final and not (directory/'DATA_PROFILE.json').exists():
        prof={}
        for filename,group in (('ALL_BRANCH_RESULTS.csv',['split','branch','condition']),('GOVERNOR_DECISIONS.csv',['condition'])):
            info=profile_data(str(out/filename),group_cols=group);prof[filename]=info
        write(directory/'DATA_PROFILE.json',prof)
        with (directory/'DATA_PROFILE.md').open('x',encoding='utf-8') as f:
            for name,info in prof.items():f.write('# '+name+'\n\n'+render_report(info)+'\n\n')
        write(directory/'FIGURE_DESIGN.json',dict(journal='IEEE T-RO',width_inches=7.16,png_dpi=600,
            figure1='All 16 decision rows: latency, both reserves for actually queried actions, realized D and complete-pair gain',
            figure2='All 84 direct cells: outcome, fault-channel capacity ratio, per-snapshot early progress',
            rationale='Small fixed repeated-state panel: individual observations and categorical outcomes, no means/CI/p-values',
            missing='Explicit unknown/unapplied/partial; never zero filled',redundant_encoding=True,rainbow=False,dual_y_axis=False))
    elif final and not (directory/'VISUAL_REVIEW.json').exists():raise RuntimeError('Visual review must precede vector delivery')
    reports=[]
    for number,builder in ((1,lambda:figure1(rows,decisions)),(2,lambda:figure2(rows))):
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always');fig=builder();audit=figure_audit(fig)
            stem=directory/f'FIGURE{number}'
            if final:
                fig.savefig(str(stem)+'.pdf');fig.savefig(str(stem)+'.svg')
            else:
                fig.savefig(str(stem)+'_preview.png',dpi=180)
                fig.savefig(str(stem)+'.png',dpi=600)
                greyscale(fig);fig.savefig(str(stem)+'_grayscale.png',dpi=180)
            audit['warnings']=[str(w.message) for w in caught]
            if any('Glyph' in w for w in audit['warnings']):audit['status']='REVISE'
            audit['number']=number;reports.append(audit);plt.close(fig)
    if final:qa_path=directory/'FINAL_PROGRAM_QA.json'
    else:
        count=len(list(directory.glob('PREVIEW_PROGRAM_QA*.json')))
        qa_path=directory/('PREVIEW_PROGRAM_QA.json' if not count else f'PREVIEW_PROGRAM_QA_V{count+1}.json')
    write(qa_path,reports)
    print(reports)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--final',action='store_true');a=p.parse_args();run(a.final)
