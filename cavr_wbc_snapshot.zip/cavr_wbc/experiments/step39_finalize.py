"""Non-numerical publication check and compact current-run delivery hash index."""
import argparse,hashlib,json,subprocess,sys
from pathlib import Path
from cavr_wbc.experiments.step39_io import output,read,write,sha,relative,OUTPUT_ROOT_D,PROTOCOL
SKILL=Path('C:/Users/ZhuanZ（无密码）/.codex/skills/scipilot-figure/scripts')

def check():
    out=output();folder=out/'figures'
    paths=[folder/f'FIGURE{i}.{ext}' for i in (1,2) for ext in ('png','pdf','svg')]
    cmd=[sys.executable,'-B','-X','utf8',str(SKILL/'check_figure.py'),*[str(p) for p in paths],'--min-dpi','600','--strict']
    run=subprocess.run(cmd,text=True,encoding='utf-8',capture_output=True)
    from pypdf import PdfReader
    fonts=[]
    for path in [p for p in paths if p.suffix=='.pdf']:
        for page in PdfReader(str(path)).pages:
            resources=page['/Resources'].get_object()
            for name,ref in resources['/Font'].get_object().items():
                font=ref.get_object()
                descendants=font.get('/DescendantFonts',[])
                for descendant in descendants:
                    child=descendant.get_object();desc=child['/FontDescriptor'].get_object()
                    keys=[k for k in ('/FontFile','/FontFile2','/FontFile3') if k in desc]
                    fonts.append(dict(path=path.name,name=name,font_type=str(font['/Subtype']),
                        descendant_type=str(child['/Subtype']),base=str(font['/BaseFont']),embedded_keys=keys,embedded=bool(keys)))
    status='PASS' if run.returncode==0 and fonts and all(f['embedded'] and f['descendant_type']=='/CIDFontType2' for f in fonts) else 'REVISE'
    write(folder/'SCIPILOT_CHECK.json',dict(status=status,command=cmd,exit_code=run.returncode,stdout=run.stdout,stderr=run.stderr,
        checked_deliverable_paths=[str(p) for p in paths],previews_are_180dpi_not_submission_files=True,
        pdf_font_evidence=fonts,PDF_warning_resolution='Provided checker tests Type0 parent descriptor only; embedded TrueType programs verified in CIDFontType2 descendants',
        new_optimizer_calls=0,new_physics_steps=0,new_fits=0))
    # Preserve the initial broad-glob check rather than redraw preview files to fake 600 dpi.
    write(folder/'SCIPILOT_INITIAL_SCOPE_NOTE.json',dict(initial_scope='FIGURE*.png included 180 dpi review previews',
        initial_strict_exit_nonzero=True,real_submission_PNG_600dpi_passed=True,
        correction='Scope strict check to the six actual submission PNG/PDF/SVG files; retain 180 dpi QA previews',numerical_data_changed=False))
    sys.path.insert(0,str(SKILL));import pandas as pd
    from profile_data import profile_data,render_report
    typed={}
    for filename,group in (('ALL_BRANCH_RESULTS.csv',['split','branch','condition']),('GOVERNOR_DECISIONS.csv',['condition'])):
        df=pd.read_csv(out/filename)
        for column in df.columns:
            if isinstance(df[column].dtype,pd.StringDtype):df[column]=df[column].astype(object)
        typed[filename]=profile_data(df,group_cols=group)
    write(folder/'DATA_PROFILE_TYPED.json',typed)
    with (folder/'DATA_PROFILE_TYPED.md').open('x',encoding='utf-8') as f:
        f.write('# 类型解释复查\n\n保留原 CSV 和初始剖析。新 pandas StringDtype 转为仅用于剖析的 object，以兼容技能脚本分类；值、缺失和实验数据均不改变。\n\n')
        for filename,info in typed.items():f.write('## '+filename+'\n\n'+render_report(info)+'\n\n')
    print(json.dumps({'status':status,'strict_exit':run.returncode,'embedded_TrueType_fonts':len(fonts)},ensure_ascii=False))
    if status!='PASS':raise RuntimeError('Figure publication check needs repair')

def hashes():
    out=output();index={}
    code=list(OUTPUT_ROOT_D.glob('cavr_wbc/control/step39*.py'))+list(OUTPUT_ROOT_D.glob('cavr_wbc/experiments/step39*.py'))
    anchors=code+[OUTPUT_ROOT_D/'tests/test_step39_protocol.py',OUTPUT_ROOT_D/'configs/validation/STEP39_PROTOCOL.md',PROTOCOL]
    anchors+=list(out.glob('*.json'))+list(out.glob('*.jsonl'))+list(out.glob('*.csv'))+list(out.glob('*.md'))
    anchors+=list((out/'models').glob('*'))+list((out/'figures').glob('*'))+list((out/'tests').glob('*.json'))
    for path in anchors:
        if path.is_file() and path.name!='CURRENT_HASH_INDEX.json':index[str(path)]=dict(sha256=sha(path),size_bytes=path.stat().st_size)
    branch={}
    for row in read(out/'ALL_PLANNED_RESULTS.json'):
        path=out/row['result_path'];rec=read(path)
        branch[row['id']]=dict(result_path=row['result_path'],result_sha256=sha(path),
            facts=rec.get('artifact'),controls=rec.get('controls_numeric'),observed=row['observed'])
    events=[json.loads(line) for line in (out/'STEP39_LEDGER.jsonl').read_text(encoding='utf-8').splitlines()]
    raw=[e for e in events if e['event']=='RAW_QP_SAVED']
    root=hashlib.sha256(json.dumps([(e['global_qp_index'],e['json_sha256'],e['npz_sha256']) for e in raw],separators=(',',':')).encode()).hexdigest()
    files=[p for p in out.rglob('*') if p.is_file()]
    write(out/'CURRENT_HASH_INDEX.json',dict(scope='STEP39_CURRENT_ONLY',anchors=index,planned_branch_evidence=branch,
        raw_qp_count=len(raw),raw_qp_ordered_hash_root=root,raw_qp_hash_detail_location='STEP39_LEDGER.jsonl RAW_QP_SAVED',
        artifact_file_count_before_this_index=len(files),artifact_bytes_before_this_index=sum(p.stat().st_size for p in files),
        raw_and_branch_hashes_verified_by='CURRENT_RUN_READBACK.json',source_history_not_enumerated=True))
    print({'anchors':len(index),'planned_branches':len(branch),'raw_qp':len(raw),'files':len(files)})

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('phase',choices=['check','hashes']);a=p.parse_args()
    check() if a.phase=='check' else hashes()
