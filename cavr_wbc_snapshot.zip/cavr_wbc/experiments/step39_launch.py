"""D-only stdout/stderr for the sole numerical batch."""
from contextlib import redirect_stdout,redirect_stderr
from cavr_wbc.experiments.step39_io import output
from cavr_wbc.experiments.step39_sprint import run
if __name__=='__main__':
    path=output()/'NUMERICAL_CONSOLE.log';path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf-8',buffering=1) as log,redirect_stdout(log),redirect_stderr(log):run()
