"""Chinese STEP39 research handoff from frozen saved-only aggregation."""
from collections import Counter
from pathlib import Path
from math import isfinite
import json
from cavr_wbc.experiments.step39_io import output,read,write,sha,OUTPUT_ROOT_D,SOURCE_COMMIT
from cavr_wbc.experiments.step39_delivery import physical_terminal,safe,outcome

def table(headers,rows):
    return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+
        ['| '+' | '.join(str(v).replace('|','/').replace('\n',' ') for v in r)+' |' for r in rows])+'\n'

def md(path,body):
    with path.open('x',encoding='utf-8',newline='\n') as f:f.write(body)

def link(name):return '['+name+']('+name+')'

def reason_short(value):
    if not isinstance(value,dict):return value
    return {k:value[k] for k in ('reason','solver_status','solver_status_val','slot','physics_step','candidate_rejection_reason','invalid_candidate_not_applied') if k in value}

def run():
    out=output();r=read(out/'STEP39_RESULT.json');rows=read(out/'ALL_PLANNED_RESULTS.json')
    dec=read(out/'ALL_GOVERNOR_DECISIONS.json');e=r['endpoints'];s=e['screen_execution'];c=e['capacity_physical'];local=e['local_secondary_6mm']
    budget=r['run']['budget'];cal=r['calibration'];train=r['train'];source=read(out/'SOURCE_READONLY_CHECK.json',{})
    queries=[q for d in dec for q in d['queries']];finite=[q for q in queries if q['U_D_main_m'] is not None and q['U_D_ablation_m'] is not None and isfinite(q['U_D_main_m']) and isfinite(q['U_D_ablation_m'])]
    change=sum(q['main_local_eligible'] is True and q['ablation_local_eligible'] is False for q in finite)
    direct=[v for v in rows if v['split']=='TEST' and v['branch']!='RECOGNIZED'];recognized=[v for v in rows if v['branch']=='RECOGNIZED']
    by={v['id']:v for v in rows}
    named=[v for v in direct if v['observed'] and not v['complete_501']]
    numeric_fail=[v for v in rows if v['observed'] and not v['complete_501']]
    failure_reasons=Counter(reason for v in rows for reason in v.get('first_dense_failure_reasons') or [])
    decision_latency=[d['command_ready_ms'] for d in dec if d['command_ready_ms'] is not None]
    tests=read(out/'tests/NECESSARY_TESTS.json');repair=read(out/'tests/PRELAUNCH_STORAGE_TARGETED_REPAIR.json')
    snapshots=list(dict.fromkeys(v['snapshot_id'] for v in direct))
    protocol=(OUTPUT_ROOT_D/'configs/validation/STEP39_PROTOCOL.md').read_text(encoding='utf-8')
    ini=protocol.split('~~~ini',1)[1].split('~~~',1)[0].strip()
    lines=['# STEP39：匹配筛选与同态容量交叉实验','',
        f"执行状态：**{r['run']['status']}**。固定批次已结束，没有结果驱动重试、补样本或重新拟合。",'',
        '## 三项预注册结论','',
        table(['终点','状态','合格 context','独立 physical snapshot','episode'],[
            ('筛选执行',s['status'],s['qualified_contexts'],s['physical_snapshots'],s['episodes']),
            ('容量物理恢复',c['status'],c['qualified_contexts'],c['physical_snapshots'],c['episodes']),
            ('6 mm 局部扩展 secondary',local['status'],local['qualified_contexts'],local['physical_snapshots'],local['episodes'])]),
        f"筛选器处理 {s['decisions_saved']}/16 个决定，eligible={s['eligible']}，及时认可={s['timely_recognized']}，完整认可实际轨迹={s['complete_actual']}，完整 6 mm safe={s['complete_safe']}，完整错误接受={s['complete_unsafe_accepts']}。零错误目标标记：`{s['zero_error_goal']}`；认可后不完整={s['accepted_numerical_incomplete']}，首包 late={s['late']}，ABSTAIN={s['abstain']}。",'',
        f"及时认可的 gamma=.5 为 {sum(d['selected_command_sent'] and d['selected_gamma']==.5 for d in dec)} 个，gamma=0 为 {sum(d['selected_command_sent'] and d['selected_gamma']==0 for d in dec)} 个。唯一认可 middle 来自 T39_TEST_1_T040_RR_THIGH15，其实际轨迹 safe，但同 source direct B 完整 physical 失败，所以不能计作安全 B 配对的筛选扩展；这也是图 1 progress-gain 红 X 的含义。",'',
        f"能力物理主终点严格要求同 snapshot 健康 C 的 physical+terminal 通过、受损 C 完整实测 physical 失败、受损 middle/B 均完整 physical+terminal 通过。合格 {c['qualified_contexts']} 个 context，强容量时序分层满足 {c['strong_capacity_qualified_contexts']} 个。健康 C 的 6 mm local 资格没有充当前置否决条件。",'',
        '这四个 physical snapshot 来自两条新 reference。七个 health 条件及三个 direct 分支是同态干预，不是额外独立初态；三个 gap 也不是新增样本。结果只描述这个有限固定批次，不作总体泛化、异步硬件实时、连续安全或形式证书结论。', '',
        '## 批次覆盖、失败与时间资格','',
        table(['批次','计划位','attempted','完整 501','physical+terminal','safe 6 mm','timing qualified'],[
            (k,r[k]['planned'],r[k]['attempted'],r[k]['complete_501'],r[k]['complete_physical_terminal'],r[k]['complete_safe_6mm'],r[k]['timing_qualified'])
            for k in ('CAL','TEST_direct','TEST_recognized')]),
        '全部 164 计划位见 '+link('ALL_PLANNED_RESULTS.json')+' 和 '+link('ALL_BRANCH_RESULTS.csv')+'；没有把未认可 ACTUAL 填成完整轨迹。', '',
        '普通 physical、terminal、local、数值失败均保留。direct 迟到仅作 offline 证据，timing-qualified 独立记录。认可实际反馈迟到或无效命令在 commit/forward/integration 前停止，不补零命令；对应数据是 partial，而非正常结束。', '',
        table(['批次','状态计数','结果类型计数'],[(k,json.dumps(r[k]['statuses'],ensure_ascii=False),json.dumps(r[k]['outcomes'],ensure_ascii=False)) for k in ('CAL','TEST_direct','TEST_recognized')]),
        table(['不完整已尝试分支','status','停止原因'],[(v['id'],v['status'],json.dumps(reason_short(v['reason']),ensure_ascii=False)) for v in numeric_fail]) if numeric_fail else '没有已尝试分支不完整。\n',
        '已观察到的首次 dense physical 失败类型（每条轨迹按首次失败多原因计数，不是独立样本）：`'+json.dumps(failure_reasons,ensure_ascii=False)+'`。', '',
        '### 所有同态 health/腿对照','',
        table(['条件','C complete / PT / safe','middle complete / PT / safe','B complete / PT / safe'],[
            (condition,*[' / '.join(str(sum(f(v) for v in direct if v['condition']==condition and v['branch']==b)) for f in (lambda v:v['complete_501'],physical_terminal,safe)) for b in ('C','MIDDLE','B')])
            for condition in dict.fromkeys(v['condition'] for v in direct)]),
        'PT = physical+terminal。D、signed terminal Y、.02–.04 s 及 0–.04 s progress、完整首包与反馈 latency 全部公开在 CSV/RESULT；它们不合并成一个 PASS。', '',
        '## 28 维匹配模型与一次新校准','',
        f"TRAIN 仅来自已曝光 STEP38 direct 的 144 个计划位；本轮独立生成有效 action 的十步 prefix，然后才读取保存标签。记录 {train['records']}，有限输入 {train['finite']}，完整六输出 target {train['complete_targets']}，已知 physical risk {train['known_risk']}，已知 class={train['classes']}。旧 TRAIN 不是本轮独立 TEST。",'',
        f"六输出 Ridge alpha=1、intercept=True、D scale=.01 m，仅 fit 一次；LogisticRegression C=1/lbfgs/max_iter=1000/tol=1e-8/seed=20261039，仅 fit 一次，收敛={train.get('risk_converged')}。两维 `fault_is_FR/RR` 来自真实 actuator name/index，健康均 0，二值 scale floor=.5。mean/scale/pose/support 只来自 TRAIN；schema 与单位见 PROTOCOL_AND_MANIFEST.json。",'',
        '新 CAL：±60.5/±68.5 mm、tick 33/39，四条 reference，八个 physical snapshot，32 context×middle/B=64 分支。C 只合成当前 middle，不额外传播 CAL C；TEST 为 ±64.5 mm、tick 32/40 的两条新 reference。', '',
        table(['CAL 组','计划','有限','完整','独立 snapshot','episode','physical failure','physical unknown','冻结可用'],[
            (g['group'],g['CAL_planned'],g['CAL_finite'],g['CAL_complete'],g['CAL_complete_distinct_snapshots'],g['CAL_complete_episodes'],g['CAL_complete_physical_failures'],g['CAL_physical_unknown'],g['local_calibrated']) for g in cal['groups']]),
        'CAL 前后系数、scaler 与 pose identity 相同；不足只拒绝对应 action，不使用全批 readiness veto。失败没有从距离排序、正残差或 risk 校准中删除。冻结模型见 models/step39_frozen_screen.json/.npz。', '',
        '本版 `U_D=max(0,D_hat,D_prefix,D_prehold)+max(0,local_CAL_positive_residual)+R`，所有位移按米与同一固定 anchor。主 R=.0001 m；同输入消融 R=.001 m。0.1 mm 是已曝光开发资料上选择的新算法参数，不是测量得到的物理误差上界；该局部经验校准不是 conformal 覆盖或已证明的 CBF。', '',
        '## 所有 16 个筛选决定与同输入 R 消融','',
        table(['context','decision','gamma','ready ms','recognized actual','R=1 最终 choice 可识别'],[(d['context_id'],d['status'],d['selected_gamma'],None if d['command_ready_ms'] is None else round(d['command_ready_ms'],3),d['actual_outcome'],d['ablation_choice_identified']) for d in dec]),
        f"有限同输入消融 query {len(finite)} 个，其中主 R 的 local 资格为真而 R=1 mm 为假的 {change} 个。它仅比较已生成 query 的 local 资格，不把未查询 B 填成 ABSTAIN，不计算旧 reserve 的完整轨迹安全率或反事实 latency。逐 query gates/U_T/U_D 见 {link('RESERVE_ABLATION_QUERIES.csv')}。",'',
        f"全部 governor 首包 latency 范围：{min(decision_latency,default=float('nan')):.3f}–{max(decision_latency,default=float('nan')):.3f} ms。timer 包括 prehold/application、C/B endpoint、原/工作行检查、合成、按 .5→0 请求的 prefix/features/inference/gates、消融算术和 selected/B0 拷贝。未生成 C prefix。",'',
        '每次 governor 先冻结 decision，再由自身 live owner 执行认可 ACTUAL，随后才生成三条独立 direct 对照。γ=0 恢复自身 B0，middle seed 自身 physical witness；未跨 owner 复制 native cache。认可与 direct 各自拥有 packet，因此是同 source 方法比较，不是精确同 packet 反事实。', '',
        '## 容量时序与局部扩展','',
        table(['容量合格 context','C 激活99%','激活早于首次 physical failure','强容量证据'],[(p['context_id'],p['C_actual_capacity_activation'],p['C_capacity_precedes_failure'],p['strong_capacity_evidence']) for p in c['pairs'] if p['qualified']]),
        '所有 fault-channel actual |tau|/effective capacity 比、99% 首次时刻/槽数、anti-windup 冻结和首次 dense 失败见各 RESULT.json 的 capacity/control_series；lossless actual.npz 保存每个 2 ms 的 contact/force/friction/torque margin。实际施加字段与未施加 rejected raw 字段分开；健康条件没有 fault channel，显示 NA。事件相关性没有被写成因果中介或 viability 定理。', '',
        table(['离线 gap (mm)','状态','合格 context','physical snapshot','episode'],[(g,z['status'],z['qualified_contexts'],z['physical_snapshots'],z['episodes']) for g,z in e['offline_gap_reassessment'].items()]),
        f"6 mm secondary 的 {local['qualified_contexts']} 个合格 context 中，健康条件 {sum(by[p['context_id']+':C']['role']=='healthy' for p in local['pairs'] if p['qualified'])} 个、受损条件 {sum(by[p['context_id']+':C']['role']!='healthy' for p in local['pairs'] if p['qualified'])} 个；逐 context 清单在 STEP39_RESULT.json，未把健康 local 失败充当受损 physical 失败。",'',
        '4/6/8 mm 全部从同一已保存轨迹重新判读，没有传播、求解、改线上 gap 或挑选新实验。', '',
        '## 两张 SciPilot 全结果图','',
        'SciPilot 的数据剖析驱动图型选择：固定小面板采用逐观测 dot 与分类 cell，不画均值柱、CI 或显著性。IEEE 双栏 7.16 in、600 dpi PNG、PDF/SVG vector；颜色和 marker/字母冗余编码，另有灰度预览。缺失/partial/未施加/未查询均可见。', '',
        '![全部筛选决定、实际执行和同输入 reserve 消融](figures/FIGURE1.png)','',
        '![全部同态容量、物理结果和任务进度](figures/FIGURE2.png)','',
        '源数据、设计理由与图形 QA：figures/DATA_PROFILE.json、FIGURE_DESIGN.json、VISUAL_REVIEW.json、FINAL_PROGRAM_QA.json、SCIPILOT_CHECK.json。图 1 的 progress gain 仅在认可与 direct B 都完整时显示，绿点为双方 safe，红 X 为完整但非双 safe 的配对；图 2 未完整但已观察到的 ratio/progress 仍显示并区分 partial，capacity ratio 显示两位小数，99% 激活使用保存的原精度值而不是图上舍入值。', '',
        '## 预算、一次验证与交付边界','',
        f"首个新数值动作：{budget['numerical_started_utc']}；结束：{r['run']['finish_utc']}；数值墙钟 {budget['numerical_elapsed_s']:.3f} s。QP {budget['total_QP_calls']}/{15000}，returns {budget['QP_returns']}，UNKNOWN={budget['unknown_native_returns']}；积分 {budget['total_physics_steps']}/150000；Ridge/risk fit={budget['multioutput_estimator_fits']}/{budget['physical_risk_head_fits']}，DEV 重算=0。未重置累计时间或预算。",'',
        'QP 按种类：`'+json.dumps(budget['QP_by_kind'],ensure_ascii=False)+'`；积分按种类：`'+json.dumps(budget['physics_by_kind'],ensure_ascii=False)+'`。', '',
        '必要纯测试集中执行一次：8 项中 7 项首轮通过；small shard 去重测试失败后，只修改存储身份去重并定点复测 1 项通过。初始失败与修复记录均保留，未声称重新跑过完整 8/8。纯测试没有真实 QP、积分或 fit。记录：tests/NECESSARY_TESTS.json、tests/PRELAUNCH_STORAGE_TARGETED_REPAIR.json。', '',
        '当前路径一次 saved-only readback：`'+r['readback']['status']+'`。'+str(r['readback']['observed_banks_read_once'])+' 个 observed fact/control bank 按 hash 读取并重建独立标签；完整 grid 验证 '+str(r['readback']['complete_grids_verified'])+' 条；'+str(r['readback']['qp_starts'])+' QP START/RETURN/raw shard 对齐；数值标签容差1e-12。没有历史全 suite、历史全树列表或额外物理审计。', '',
        f"指定源 commit：`{SOURCE_COMMIT}`；D 分支 `codex/step39-matched-screen-capacity-20261010`。E source HEAD 与旧 index 只读检查：`{source}`。所有新代码、索引、Git 对象/log、模型、工件、cache、临时文件和 commit receipt 都在 D。只读 alternate 依赖记录在 ENVIRONMENT.json。",'',
        '最终验证命令与 Git scoped-diff 记录见 DELIVERY_COMMANDS.json / GIT_SCOPED_DIFF.txt；新提交号保存到 D 的 .runtime/COMMIT_RECEIPT.json 并在交付回复给出。receipt 在提交之后写入，避免自引用提交 hash；不推送。', '',
        '## Material Passport','',
        '- 任务身份：STEP39_MATCHED_SCREEN_AND_CAPACITY_CROSSOVER；版本与授权仅限本文件固定 DEV。',
        '- 数据来源：已曝光 STEP38 direct TRAIN、新独立 CAL、新 TEST；TRAIN/TEST 身份和标签读取顺序分开。',
        '- 测量单位：D/progress 米，图转毫米；force N、torque N·m、latency ms、time s、health 无量纲。',
        '- 物理独立性：TEST 4 snapshot / 2 episode；health×branch 为重复状态干预，无 p 值或总体置信区间。',
        '- 缺失机制：不可用 action、数值停止、late、ABSTAIN 分别留账；没有插值或零填充。',
        '- 再现入口：冻结协议、FROZEN_INPUTS、TRAIN/CAL 对象、attempt/native ledger、raw QP、lossless states/controls；本轮不授权再次求解。',
        '- 下一轮边界：只交接本批 OBSERVED/NOT_ESTABLISHED/INCOMPLETE；E3、RL、硬件、历史复跑均未授权；“机器人运控算法”项目未访问。', '',
        '## 协议状态行','', '```ini',ini,'```','']
    md(out/'REPORT.md','\n'.join(lines))
    handoff=['# STEP39 研究交接','',f"当前批次已经结束：{r['run']['status']}。三项状态：",'',
        table(['筛选执行','容量物理','6 mm secondary'],[(s['status'],c['status'],local['status'])]),
        '报告：'+link('REPORT.md')+'；机器结果：'+link('STEP39_RESULT.json')+'。', '',
        f"固定16decision完成{s['decisions_saved']}；及时认可{s['timely_recognized']}、完整safe{s['complete_safe']}、完整错误接受{s['complete_unsafe_accepts']}。物理恢复合格{c['qualified_contexts']}context/{c['physical_snapshots']}snapshot/{c['episodes']}episode。",'',
        '没有 pending 数值分支等待重启。NOT_RUN/ABSTAIN/partial 均是当前批次已记录结果，不应补跑或拼接。没有根据结果放宽参数、删除失败或修改 STEP38 历史。', '',
        '主筛选是匹配 28 维 TRAIN、一次新四组 CAL、.5→0 shortlist、经验 R=.1 mm；同输入 R=1 mm 消融只覆盖实际已查询动作。不能把该对象升级成形式安全证书、硬件部署或总体泛化论证。', '',
        '下一轮若获得新授权，应从本轮新 D 提交继承；保留本批固定输入/ledger/hash。当前不进入 E3/RL/hardware，禁止历史复跑和禁区项目访问。', '',
        '资料索引：REPORT、STEP39_RESULT、ALL_PLANNED_RESULTS、ALL_BRANCH_RESULTS、ALL_GOVERNOR_DECISIONS、RESERVE_ABLATION_QUERIES、CAL_FREEZE、CURRENT_RUN_READBACK、FROZEN_INPUTS、PROTOCOL_AND_MANIFEST、RUNTIME_FREEZE、STEP39_LEDGER、ATTEMPT_LEDGER、RUN_STARTED/RUN_FINISHED、figures、tests。', '']
    md(out/'HANDOFF.md','\n'.join(handoff))
    print({'report':str(out/'REPORT.md'),'handoff':str(out/'HANDOFF.md'),'statuses':r['endpoint_statuses']})

if __name__=='__main__':run()
