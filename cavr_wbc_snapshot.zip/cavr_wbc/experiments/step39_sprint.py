"""One fixed TRAIN fit, fresh CAL freeze and matched-state TEST batch."""
from copy import deepcopy
from datetime import datetime,timezone
import argparse,gc,os,traceback
import numpy as np
from cavr_wbc.experiments.step39_io import *
from cavr_wbc.experiments.step39_inputs import episodes,plans,context_for,reference_scenario,BRANCHES
from cavr_wbc.experiments.step39_budget import SprintBudget,SprintLimit
from cavr_wbc.experiments.step39_training import train_once,forward_entry,record
from cavr_wbc.experiments.step39_storage import save_branch,not_run
from cavr_wbc.experiments.step35_reference import reference_episode
from cavr_wbc.experiments.step28_sprint import home_context
from cavr_wbc.experiments import step17_formal_panel as frozen,step38_sim as sim
from cavr_wbc.control.step39_kernel import Kernel,direct_packet
from cavr_wbc.control import step39_margin as margin
from cavr_wbc.platforms.go2_mujoco import extract_actuator_audit,extract_healthy_torque_limits
def event(out,name,**values):
    append(out/'ATTEMPT_LEDGER.jsonl',{'event':name,'timestamp_utc':datetime.now(timezone.utc).isoformat(),**values})
def make_owner(model,dll,budget,c,manifest):
    k=Kernel(model,'BOUNDED',str(dll),budget)
    home=home_context(model,manifest['scenario']);home.update(context_id=c['context_id']+':HOME',backup_id=c['backup_id']+':HOME')
    startup=k.startup(home,budget);k.flush_raw_evidence()
    return k,startup
def reference_inputs(out,split,model,manifest,budget):
    contexts=[]
    for ep in episodes(split):
        event(out,'START',kind='REFERENCE',**ep)
        episode=reference_episode(model,manifest['reference_scenario'],ep['displacement_m'],ep['episode_id'],
            ep['snapshot_ticks'],budget,evidence_callback=budget.record_raw)
        # Every raw optimizer return is already stored once in raw_qp.
        for c in episode['controls']:c.pop('raw_solver_result',None)
        save_numeric(out/'episodes'/(ep['episode_id']+'.json'),episode)
        event(out,'RETURN',kind='REFERENCE',episode_id=ep['episode_id'],status=episode['status'],counts=episode['counts'])
        contexts.extend(context_for(p,episode,manifest['mapping']) for p in plans(split) if p['episode']==ep['episode_id'])
        budget.persist(phase='REFERENCE_SAVED',split=split,episode=ep['episode_id'])
    save_numeric(out/(split+'_CONTEXTS.json'),contexts)
    return contexts
def packet_once(out,path,c,model,dll,budget,manifest):
    owners={};startup={}
    if c.get('eligible'):
        # Independent resident owners are retained through their own branch.
        for name,_ in BRANCHES:owners[name],startup[name]=make_owner(model,dll,budget,c,manifest)
        packet=direct_packet(owners['B'],c,budget,owners);owners['B'].flush_raw_evidence()
    else:packet={'context_id':c['context_id'],'selected_command_sent':False,'status':'SOURCE_INELIGIBLE',
        'command_ready_ms':0.,'actions':{}}
    write(path/'STARTUP.json',startup);save_numeric(path/'PACKET.json',packet)
    return owners,packet
def run(run_id=RUN_ID):
    out=output(run_id)
    if (out/'RUN_STARTED.json').exists():raise FileExistsError('STEP39 unique run already attempted')
    out.mkdir(parents=True,exist_ok=True)
    old=read(SOURCE38/'PROTOCOL_AND_MANIFEST.json');model=frozen.load_model()
    limits=extract_healthy_torque_limits(model)
    mapping=[dict(r,healthy_limit_nm=float(limits[r['actuator_index']])) for r in extract_actuator_audit(model)]
    dll=Path(old['native_dll_path'])
    manifest={'run_id':run_id,'source_commit':SOURCE_COMMIT,'source_root_read_only':str(SOURCE_ROOT_E),
        'new_file_drive':'D','scenario':old['scenario'],'reference_scenario':reference_scenario(old['scenario']),
        'frozen_physical':old['frozen_physical'],'mapping':mapping,'native_dll_path':str(dll),
        'native_dll_sha256':sha(dll),'protocol_sha256':sha(PROTOCOL),
        'TRAIN_source':'STEP38_EXPOSED_DIRECT_ONLY','TRAIN_planned':144,'feature_dimension':28,
        'feature_names':list(margin.FEATURE_NAMES),'feature_scale_floors':margin.PHYSICAL_FLOORS,
        'feature_units':['m/s','m/s^2','rad','rad','rad/s','rad/s','m','m','ratio','binary','binary','ratio',
            'm/s^2','rad/s','m/s','m/s','m','m/s','m/s','rad','rad','binary','ratio','sign','rad','ratio','binary','binary'],
        'CAL_episodes':episodes('CAL'),'TEST_episodes':episodes('TEST'),'CAL_plans':plans('CAL'),'TEST_plans':plans('TEST'),
        'max_QP_calls':15000,'max_physics_steps':150000,'max_wall_s':7200,'max_fits':2,
        'max_DEV_implementation_repairs':2,'online_gamma_order':[.5,0.],
        'empirical_D_reserve_main_m':.0001,'empirical_D_reserve_ablation_m':.001,
        'actual_local_bound_m':.006,'deadline_ms':20.,'horizon_s':1.,'physics_dt_s':.002,
        'candidate_eps':1e-7,'reference_eps':1e-8,'first_B_limit_s':.006,'first_C_limit_s':.003,
        'feedback_limit_s':.006,'friction_upper_N':-1e-4,'torque_inset_Nm':1e-4,
        'original_inequality_extra_slack':0,'E3_RL_hardware_authorized':False}
    write(out/'PROTOCOL_AND_MANIFEST.json',manifest)
    write(out/'FROZEN_INPUTS.json',{'CAL':plans('CAL'),'TEST':plans('TEST'),
        'planned_branch_positions':[
            {'id':p['context_id']+':'+name,'split':split,'context':p['context_id'],'branch':name,'gamma':g}
            for split in ('CAL','TEST') for p in plans(split) for name,g in BRANCHES if name in p['branch_order']]+[
            {'id':p['context_id']+':RECOGNIZED','split':'TEST','context':p['context_id'],'branch':'RECOGNIZED'}
            for p in plans('TEST') if p['governor_planned']]})
    write(out/'RUNTIME_FREEZE.json',{'source_commit':SOURCE_COMMIT,'protocol_sha256':sha(PROTOCOL),
        'runtime_sha256':{relative(p,OUTPUT_ROOT_D):sha(p) for p in [*OUTPUT_ROOT_D.glob('cavr_wbc/**/*.py'),*OUTPUT_ROOT_D.glob('tests/test_step39*.py')]},
        'old_source_HEAD':'263a643c2cccfdc2d6a4fd5d3aa59bb29dd271d1','old_source_index_exists':False})
    import scipy,osqp,mujoco,sklearn,threadpoolctl
    write(out/'ENVIRONMENT.json',{'numpy':np.__version__,'scipy':scipy.__version__,'osqp':osqp.__version__,
        'mujoco':mujoco.__version__,'sklearn':sklearn.__version__,'threadpools':threadpoolctl.threadpool_info(),
        'TMP':os.environ.get('TMP'),'TEMP':os.environ.get('TEMP'),'MPLCONFIGDIR':os.environ.get('MPLCONFIGDIR'),
        'D_write_and_free_check_once':True,'D_free_bytes_before':80442933248,'all_new_output_on_D':True,
        'readonly_git_alternates':(OUTPUT_ROOT_D/'.git/objects/info/alternates').read_text().splitlines()})
    budget=SprintBudget(out);status='COMPLETED';cal=[]
    write(out/'RUN_STARTED.json',{'run_id':run_id,'pid':os.getpid(),'start_utc':datetime.now(timezone.utc).isoformat()})
    try:
        bundle=train_once(out,model,dll,budget,Kernel)
        predictor_id=margin.identity(bundle) if bundle else None
        calcontexts=reference_inputs(out,'CAL',model,manifest,budget)
        prefix_owner=Kernel(model,'BOUNDED',str(dll),budget)
        for p,c in zip(plans('CAL'),calcontexts):
            path=out/'CAL'/c['context_id'];owners,packet=packet_once(out,path,c,model,dll,budget,manifest)
            for name,gamma in (('MIDDLE',.5),('B',0.)):
                event(out,'START',kind='CAL_BRANCH',context_id=c['context_id'],branch=name)
                action=(packet['actions'].get(str(gamma)) or {}).get('action') or {}
                entry={'features28':None,'prefix':None,'prehold':None}
                if action.get('command_valid') and action.get('execution_eligible'):
                    _,entry=forward_entry(prefix_owner,packet,gamma,budget,'CAL')
                    branch=sim.propagate(owners[name],c,packet,budget,purpose='CAL_'+name,action=action,require_sent=False)
                else:branch=not_run(gamma,'CURRENT_PACKET_UNAVAILABLE')
                r=save_branch(out,path/name,branch,c,packet)
                row=record(p,entry,r['label'],gamma,'CAL');cal.append(row)
                save_numeric(path/(name+'_PREFIX.json'),{'entry':entry,'record':row})
                event(out,'RETURN',kind='CAL_BRANCH',context_id=c['context_id'],branch=name,status=r['status'])
                budget.persist(phase='CAL_BRANCH_SAVED',CAL_positions=len(cal))
            print({'phase':'CAL_CONTEXT_DONE','completed':p['ordinal']+1,'planned':32,'budget':budget.snapshot()},flush=True)
            del owners;gc.collect()
        groups=[]
        if bundle:
            bundle['groups']={margin.group_key(g,r):bundle['groups'][margin.group_key(g,r)] for g in (.5,0.) for r in ('thigh','calf')}
            bundle=margin.build_calibration(bundle,cal)
            if margin.identity(bundle)!=predictor_id:raise ValueError('CAL changed frozen coefficients')
            asset=margin.save_bundle(bundle,out/'models','step39_frozen_screen')
            groups=[{'group':key,**{k:g[k] for k in ('CAL_planned','CAL_finite','CAL_complete','CAL_complete_distinct_snapshots',
                'CAL_complete_episodes','CAL_complete_physical_failures','CAL_physical_unknown','local_calibrated','distance_threshold')}} for key,g in bundle['groups'].items()]
        else:asset=None
        write(out/'CAL_FREEZE.json',{'status':'FROZEN' if bundle else 'HEAD_UNAVAILABLE','groups':groups,
            'planned':64,'recorded':len(cal),'asset':asset,'predictor_identity_before':predictor_id,
            'predictor_identity_after':margin.identity(bundle) if bundle else None,'no_global_readiness_veto':True})
        budget.event('CAL_FROZEN_BEFORE_TEST',cal_freeze_sha256=sha(out/'CAL_FREEZE.json'))
        contexts=reference_inputs(out,'TEST',model,manifest,budget)
        for p,c in zip(plans('TEST'),contexts):
            directory=out/'TEST'/c['context_id']
            save_numeric(directory/'SOURCE_IDENTITY.json',{'plan':p,'context':c})
            if p['governor_planned']:
                event(out,'START',kind='GOVERNOR',context_id=c['context_id'])
                if c.get('eligible'):
                    live,startup=make_owner(model,dll,budget,c,manifest);write(directory/'GOVERNOR_STARTUP.json',startup)
                    decision=live.governor(c,bundle,.006,budget);live.flush_raw_evidence()
                else:live=None;decision={'context_id':c['context_id'],'selected_command_sent':False,'status':'SOURCE_INELIGIBLE','actions':{},'command_ready_ms':0.}
                save_numeric(directory/'GOVERNOR_DECISION.json',decision)
                event(out,'DECISION_IMMUTABLE',context_id=c['context_id'],decision_sha256=sha(directory/'GOVERNOR_DECISION.json'),direct_not_started=True,
                    selected_command_sent=decision.get('selected_command_sent'),selected_gamma=decision.get('selected_gamma'))
                branch=sim.propagate(live,c,decision,budget,purpose='RECOGNIZED_ACTUAL',require_sent=True) if decision.get('selected_command_sent') else not_run(decision.get('selected_gamma'),'ABSTAIN_OR_LATE_UNAPPLIED')
                save_branch(out,directory/'RECOGNIZED',branch,c,decision,True)
                if live is not None:del live
                budget.persist(phase='RECOGNIZED_SAVED',context_ordinal=p['ordinal'])
            owners,packet=packet_once(out,directory/'DIRECT',c,model,dll,budget,manifest)
            for name,gamma in BRANCHES:
                event(out,'START',kind='TEST_DIRECT',context_id=c['context_id'],branch=name)
                action=(packet['actions'].get(str(gamma)) or {}).get('action') or {}
                branch=sim.propagate(owners[name],c,packet,budget,purpose=name,action=action,require_sent=False) if action.get('command_valid') and action.get('execution_eligible') else not_run(gamma,'CURRENT_PACKET_UNAVAILABLE')
                r=save_branch(out,directory/'DIRECT'/name,branch,c,packet)
                event(out,'RETURN',kind='TEST_DIRECT',context_id=c['context_id'],branch=name,status=r['status'])
                budget.persist(phase='TEST_DIRECT_SAVED',context_ordinal=p['ordinal'],branch=name)
            budget.persist(phase='TEST_CONTEXT_DONE',contexts_processed=p['ordinal']+1)
            print({'phase':'TEST_CONTEXT_DONE','completed':p['ordinal']+1,'planned':28,'budget':budget.snapshot()},flush=True)
            del owners;gc.collect()
    except SprintLimit as e:
        status='INCOMPLETE_BUDGET';write(out/'INTERRUPTION.json',{'error':str(e),'budget':budget.snapshot()})
    except BaseException as e:
        status='STOPPED_IMPLEMENTATION_OR_RESOURCE';write(out/'INTERRUPTION.json',{'type':type(e).__name__,'error':str(e),
            'traceback':traceback.format_exc(),'budget':budget.snapshot()});raise
    finally:
        budget.event('NUMERICAL_FINISHED',status=status,**budget.snapshot());budget.close()
        write(out/'RUN_FINISHED.json',{'status':status,'run_id':run_id,'budget':budget.snapshot(),'finish_utc':datetime.now(timezone.utc).isoformat()})
        print({'status':status,'budget':budget.snapshot()},flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('run_id',nargs='?',default=RUN_ID);a=p.parse_args();run(a.run_id)
