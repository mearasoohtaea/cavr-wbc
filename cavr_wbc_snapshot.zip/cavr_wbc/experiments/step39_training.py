"""STEP38 direct only: independent causal input before any future target read."""
from copy import deepcopy
from collections import Counter
from cavr_wbc.experiments.step39_io import *
from cavr_wbc.control import step39_margin as margin
FORBIDDEN={'labels','label','terminal','D_max','future_controls','actual_results'}
def prediction_input(packet,gamma,split):
    c=deepcopy({k:v for k,v in packet['context_used'].items() if k not in FORBIDDEN})
    c.update(split=split,source_split='STEP38_EXPOSED_DIRECT_ONLY' if split=='TRAIN' else 'STEP39_FRESH_CAL')
    a=deepcopy(packet['actions'][str(float(gamma))]['action'])
    return c,a,deepcopy(packet['prehold'])
def forward_entry(kernel,packet,gamma,budget,split):
    c,a,hold=prediction_input(packet,gamma,split)
    kernel.reset(c)
    prefix=kernel._prefix_one(c,a,budget) if a.get('command_valid') else None
    entry=kernel._entry(c,a,prefix,hold)
    return c,entry
def record(p,entry,label,gamma,split):
    return {'id':split+':'+p['context_id']+':'+str(gamma),'gamma':gamma,'role':p['role'],
        'episode':p['episode'],'source_snapshot':p.get('source_snapshot',p['snapshot_id']),
        'split':split,'source_split':'STEP38_EXPOSED_DIRECT_ONLY' if split=='TRAIN' else 'STEP39_FRESH_CAL',
        'source_method':'STEP38_EXPOSED_DIRECT' if split=='TRAIN' else 'STEP39_MATCHED_RED',
        'features28':entry.get('features28'),'prefix':entry.get('prefix'),'prehold':entry.get('prehold'),
        'labels':label,'future_target_consumed_only_after_independent_prefix_features':True}
def train_once(out,model,dll,budget,Kernel):
    source=read(SOURCE38/'PROTOCOL_AND_MANIFEST.json');rows=[]
    k=Kernel(model,'BOUNDED',str(dll),budget)
    for p in source['contexts']:
        directory=SOURCE38/'states'/p['context_id']/'DIRECT'
        packet=load_numeric(directory/'PACKET.json') if (directory/'PACKET.json').exists() else None
        for name,gamma in (('C',1.),('MIDDLE',.5),('B',0.)):
            entry={'features28':None,'prefix':None,'prehold':None,'evaluation_status':'PACKET_MISSING'}
            if packet is not None:_,entry=forward_entry(k,packet,gamma,budget,'TRAIN')
            # This is the first access to the saved full-horizon label.
            result=read(directory/name/'RESULT.json',{})
            row=record(p,entry,result.get('label',{}),gamma,'TRAIN');rows.append(row)
            save_numeric(out/'TRAIN'/f'A{len(rows):03d}.json',{'record':row,
                'source_packet_path':str(directory/'PACKET.json'),
                'source_packet_sha256':sha(directory/'PACKET.json') if packet is not None else None,
                'source_result_path':str(directory/name/'RESULT.json'),
                'source_result_sha256':sha(directory/name/'RESULT.json') if result else None,
                'new_endpoint_QP_calls':0,'old_full_trajectory_not_recomputed':True})
            budget.persist(phase='TRAIN_PREFIX_SAVED',TRAIN_positions=len(rows))
    counts={'planned':144,'records':len(rows),'finite':sum(margin.finite_input(r) is not None for r in rows),
        'complete_targets':sum(margin.original._complete_target(r) is not None for r in rows),
        'known_risk':sum(margin.physical_target(r) is not None for r in rows),
        'classes':dict(Counter(margin.physical_target(r) for r in rows)),
        'source':'STEP38_EXPOSED_DIRECT_ONLY','independent_TEST':False}
    try:bundle=margin.train(rows,budget)
    except ValueError as e:
        if not any(s in str(e) for s in ('no finite TRAIN','no complete D/Y','RISK_HEAD_UNAVAILABLE')):raise
        bundle=None;counts['head_unavailable']=str(e)
    if bundle is not None:
        counts['model_asset']=margin.save_bundle(bundle,out/'models','step39_trained_only')
        counts['predictor_identity']=margin.identity(bundle)
        counts['risk_converged']=bundle['risk_converged']
    write(out/'TRAIN_COUNTS.json',counts)
    return bundle
