"""Single saved-only STEP40 readback and pre-registered aggregation."""
from collections import Counter
from datetime import datetime, timezone
import json
import numpy as np
from cavr_wbc.experiments.step40_io import *
from cavr_wbc.experiments.step40_inputs import plans
from cavr_wbc.experiments.step40_storage import load_branch, contact_statistics
from cavr_wbc.experiments.step40_identity import fingerprint
from cavr_wbc.experiments.step40_mechanisms import all_endpoints
from cavr_wbc.experiments.step39_delivery import flatten, counts, safe, outcome, csv_save


def decision_fields(entry):
    return entry.get('decision') or {}


def collect(out):
    rows, records, decisions, queries = [], {}, [], []
    path = out / 'TEST_CONTEXTS.json'
    contexts = {c['context_id']: c for c in load_numeric(path)} if path.exists() else {}
    for p in plans('TEST'):
        folder = out / 'TEST' / p['context_id']
        for name in p['branch_order'] + (['RECOGNIZED'] if p['governor_planned'] else []):
            path = folder / ('RECOGNIZED' if name == 'RECOGNIZED' else 'DIRECT/' + name) / 'RESULT.json'
            r = read(path, {})
            row = flatten(p, name, r, path, out)
            row.update(direction=p['direction'], displacement_m=p['displacement_m'],
                       contact_statistics=r.get('contact_statistics'))
            rows.append(row); records[row['id']] = r
        if p['governor_planned']:
            path = folder / 'GOVERNOR_DECISION.json'
            d = load_numeric(path) if path.exists() else {}
            query = []
            for gamma in (.5, 0.):
                e = d.get('actions', {}).get(str(gamma), {})
                numeric = decision_fields(e).get('numeric') or {}
                row = {'context_id': p['context_id'], 'snapshot_id': p['snapshot_id'], 'gamma': gamma,
                    'evaluation_status': e.get('evaluation_status', 'NOT_RUN'),
                    'accepted': decision_fields(e).get('accepted'),
                    'U_D_m': numeric.get('U_D'), 'U_T': numeric.get('U_T'),
                    'gates': {key: numeric.get(key) for key in ('finite_input', 'pose_gate', 'support_gate',
                        'distance_gate', 'calibration_gate', 'physical_risk_gate') if key in numeric}}
                query.append(row); queries.append(row)
            R = next(r for r in rows if r['id'] == p['context_id'] + ':RECOGNIZED')
            decisions.append({'context_id': p['context_id'], 'snapshot_id': p['snapshot_id'],
                'episode': p['episode'], 'condition': p['health_kind'], 'direction': p['direction'],
                'displacement_m': p['displacement_m'], 'fault_leg': p['fault_leg'],
                'eligible': bool(contexts.get(p['context_id'], {}).get('eligible')),
                'decision_exists': path.exists(), 'decision_path': relative(path, out),
                'decision_sha256': sha(path) if path.exists() else None,
                'status': d.get('status', 'NOT_RUN'), 'command_ready_ms': d.get('command_ready_ms'),
                'selected_gamma': d.get('selected_gamma'), 'selected_command_sent': bool(d.get('selected_command_sent')),
                'overall_deadline_failure': bool(d.get('overall_deadline_failure')),
                'complete_actual': R['complete_501'], 'safe_actual_6mm': safe(R),
                'max_feedback_latency_ms': R['max_feedback_latency_ms'],
                'actual_outcome': outcome(R), 'actual_partial': bool(R['observed'] and not R['complete_501']),
                'timing_qualified_actual': R['timing_qualified'], 'queries': query})
    return rows, records, contexts, decisions, queries


def readback(out, rows, records, contexts, decisions):
    from cavr_wbc.control.step34_margin import labels
    from cavr_wbc.experiments.step29_sim import _json_safe
    issues, loaded, grids, capacity = [], 0, 0, []
    source_identities = {}
    for c in contexts.values():
        if 'state' not in c:
            continue
        digest = fingerprint({key: c.get(key) for key in ('state', 'current_reference', 'source_external_reference',
            'nominal_q_init', 'nominal_d_m', 'nominal_b_used', 'backup_anchor_q_init', 'previous_command_identity')})
        previous = source_identities.setdefault(c['snapshot_id'], digest)
        if previous != digest:
            issues.append(c['context_id'] + ':same-state intervention source mismatch')
        health = np.ones(len(c['health_vector']))
        if c['faulted_actuator_index'] is not None:
            health[c['faulted_actuator_index']] = c['faulted_health']
        if not np.array_equal(health, c['health_vector']):
            issues.append(c['context_id'] + ':health mapping')
    for row in rows:
        if not row['observed']:
            continue
        rec = records[row['id']]
        directory = (out / row['result_path']).parent
        if sha(directory / 'actual.npz') != rec['artifact']['sha256']:
            issues.append(row['id'] + ':fact hash')
        for ext, key in (('json', 'json_sha256'), ('npz', 'npz_sha256')):
            if sha(directory / ('controls.' + ext)) != rec['controls_numeric'][key]:
                issues.append(row['id'] + ':control hash')
        branch = load_branch(directory)
        context = contexts[row['context_id']]
        lab = labels(branch, _json_safe(context))
        for key in ('complete', 'full_501_grid', 'original_physical', 'original_terminal', 'observed_original_physical_failure'):
            if lab.get(key) != rec['label'].get(key):
                issues.append(row['id'] + ':label ' + key)
        for key in ('D_m', 'Y'):
            a, b = lab.get(key), rec['label'].get(key)
            if (a is None) != (b is None) or (a is not None and not np.allclose(a, b, rtol=0, atol=1e-12, equal_nan=True)):
                issues.append(row['id'] + ':numeric label ' + key)
        if contact_statistics(branch) != rec['contact_statistics']:
            issues.append(row['id'] + ':contact descriptive facts')
        if not np.array_equal(branch['health_vector'], context['health_vector']):
            issues.append(row['id'] + ':plant/control health')
        if row['complete_501']:
            grids += 1
            if branch['counts']['physical_steps'] != 500 or len(branch['physics_trajectory']) + 1 != 501 or len(branch['checkpoints']) != 21:
                issues.append(row['id'] + ':500/501/21 time grid')
        ix = context.get('faulted_actuator_index')
        for r in branch['controls']:
            interface = r.get('capacity_interface') or {}
            tau, cap = r.get('tau_applied'), interface.get('effective_capacity_nm')
            raw, sent = interface.get('tau_raw'), interface.get('tau_sent')
            applied = tau is not None
            record = {'id': row['id'], 'context_id': row['context_id'], 'branch': row['branch'],
                'snapshot_id': row['snapshot_id'], 'episode': row['episode'], 'condition': row['condition'],
                'slot': r['slot'], 'time_s': r['slot'] * .02,
                'stage': 'PREHOLD' if r['slot'] == 0 else 'FIRST_ACTION' if r['slot'] == 1 else 'FEEDBACK',
                'actual_applied': applied, 'fault_name': context.get('faulted_actuator_name'),
                'actual_fault_tau_nm': None if ix is None or not applied else float(tau[ix]),
                'effective_fault_capacity_nm': None if ix is None or cap is None else float(cap[ix]),
                'actual_tau_capacity_ratio': None if ix is None or not applied or cap is None else abs(float(tau[ix])) / float(cap[ix]),
                'candidate_fault_tau_raw_nm': None if ix is None or raw is None else float(raw[ix]),
                'candidate_fault_tau_sent_nm': None if ix is None or sent is None else float(sent[ix]),
                'fault_clipped': None if ix is None or raw is None or sent is None else bool(raw[ix] != sent[ix]),
                'antiwindup_frozen': bool(r.get('integral_record') and not r['integral_record'].get('updated', False)),
                'latency_ms': r.get('latency_ms')}
            record['actual_99percent'] = bool(record['actual_tau_capacity_ratio'] is not None and record['actual_tau_capacity_ratio'] >= .99)
            capacity.append(record)
        loaded += 1
    events = [json.loads(line) for line in (out / 'STEP40_LEDGER.jsonl').read_text(encoding='utf-8').splitlines()]
    starts = [e for e in events if e['event'] == 'QP_START']
    returns = [e for e in events if e['event'] == 'QP_RETURN']
    raw = [e for e in events if e['event'] == 'RAW_QP_SAVED']
    ix = lambda a: sorted(e['global_qp_index'] for e in a)
    if ix(starts) != ix(returns) or ix(starts) != ix(raw) or ix(starts) != list(range(1, len(starts) + 1)):
        issues.append('QP START/RETURN/raw identity')
    for e in raw:
        path = out / e['path']
        if sha(path) != e['json_sha256'] or sha(path.with_suffix('.npz')) != e['npz_sha256']:
            issues.append(e['path'] + ':raw hash')
    reservations = [e for e in events if e['event'] == 'PREFIX_NATIVE_START']
    completed = [e for e in events if e['event'] == 'PREFIX_NATIVE_RETURN']
    if sorted(e['reservation_id'] for e in reservations) != sorted(e['reservation_id'] for e in completed):
        issues.append('prediction reservations/returns')
    budget = read(out / 'RUN_FINISHED.json')['budget']
    if (budget['total_QP_calls'] != len(starts) or budget['QP_returns'] != len(returns)
            or budget['multioutput_estimator_fits'] or budget['physical_risk_head_fits']
            or budget['new_CAL_branches'] or budget['total_QP_calls'] > 10000 or budget['total_physics_steps'] > 100000):
        issues.append('cumulative counts/budgets/zero fit/CAL')
    checkpoint = read(out / 'SCREEN_IDENTITY_END.json')
    if not checkpoint['full_model_CAL_TRAIN_threshold_identity_unchanged']:
        issues.append('frozen screen groups/predictor/threshold identity')
    freeze = read(out / 'RUNTIME_FREEZE.json')
    for name, digest in {**freeze['runtime_sha256'], **freeze['model_checkout_bytes']}.items():
        if sha(OUTPUT_ROOT_D / name) != digest:
            issues.append(name + ':frozen checkout byte hash')
    manifest = read(out / 'PROTOCOL_AND_MANIFEST.json')
    if sha(NATIVE_DLL) != manifest['native_dll_sha256']:
        issues.append('native DLL hash')
    attempts = [json.loads(line) for line in (out / 'ATTEMPT_LEDGER.jsonl').read_text().splitlines()]
    for d in decisions:
        ev = next((e for e in attempts if e['event'] == 'DECISION_IMMUTABLE' and e['context_id'] == d['context_id']), None)
        if d['decision_exists']:
            if ev is None or ev['decision_sha256'] != d['decision_sha256']:
                issues.append(d['context_id'] + ':immutable decision')
            order = [i for i, e in enumerate(attempts) if e.get('context_id') == d['context_id'] and e.get('kind') == 'TEST_DIRECT']
            if order and attempts.index(ev) >= min(order):
                issues.append(d['context_id'] + ':decision after future direct')
    write(out / 'CAPACITY_EVENTS_FULL.json', capacity)
    csv_save(out / 'CAPACITY_EVENTS_FULL.csv', capacity)
    result = {'status': 'VERIFIED' if not issues else 'EVIDENCE_ERROR', 'issues': issues,
        'observed_banks_read_once': loaded, 'complete_grids_verified': grids,
        'qp_starts': len(starts), 'qp_returns': len(returns), 'raw_qp_shards': len(raw),
        'unknown_qp': len(starts) - len(returns), 'source_snapshot_fingerprints': source_identities,
        'full_frozen_screen_identity_unchanged': checkpoint['full_model_CAL_TRAIN_threshold_identity_unchanged'],
        'label_tolerance': 1e-12, 'new_optimizer_calls': 0, 'new_physics_steps': 0,
        'new_fits': 0, 'scope': 'STEP40_CURRENT_RUN_ONLY', 'timestamp_utc': datetime.now(timezone.utc).isoformat()}
    write(out / 'CURRENT_RUN_READBACK.json', result)
    return result


def summarize(out=output()):
    if not (out / 'RUN_FINISHED.json').exists():
        raise RuntimeError('finish numerical process before saved-only delivery')
    if (out / 'STEP40_RESULT.json').exists() or (out / 'CURRENT_RUN_READBACK.json').exists():
        raise FileExistsError('single STEP40 readback already attempted')
    rows, records, contexts, decisions, queries = collect(out)
    evidence = readback(out, rows, records, contexts, decisions)
    endpoints = all_endpoints(rows, decisions, plans('TEST'))
    strata = []
    for direction in (1, -1):
        for amplitude in (.0625, .0675):
            for leg in ('FR', 'RR'):
                group = [r for r in rows if r['branch'] != 'RECOGNIZED' and r['direction'] == direction
                         and abs(r['displacement_m']) == amplitude and r['fault_leg'] == leg]
                strata.append({'direction': direction, 'target_amplitude_m': amplitude, 'fault_leg': leg,
                    'direct': counts(group), 'TYPE_I_qualified': sum(p['qualified'] for p in endpoints['TYPE_I']['pairs']
                        if p['direction'] == direction and abs(p['displacement_m']) == amplitude and p['fault_leg'] == leg),
                    'TYPE_II_qualified': sum(p['qualified'] for p in endpoints['TYPE_II']['pairs']
                        if p['direction'] == direction and abs(p['displacement_m']) == amplitude and p['fault_leg'] == leg)})
    result = {'schema': 'STEP40_SAVED_ONLY_RESULT_V1', 'run_id': out.name,
        'run': read(out / 'RUN_FINISHED.json'), 'readback': evidence,
        'direct': counts([r for r in rows if r['branch'] != 'RECOGNIZED']),
        'recognized': counts([r for r in rows if r['branch'] == 'RECOGNIZED']),
        'governor': {'planned': 16, 'saved': sum(d['decision_exists'] for d in decisions),
            'eligible': sum(d['eligible'] for d in decisions),
            'timely_recognized': sum(d['selected_command_sent'] for d in decisions),
            'selected_gamma_counts': dict(Counter(str(d['selected_gamma']) for d in decisions if d['selected_command_sent'])),
            'ABSTAIN': sum(d['status'] == 'ABSTAIN' for d in decisions),
            'late': sum(d['overall_deadline_failure'] for d in decisions),
            'partial': sum(d['actual_partial'] for d in decisions),
            'complete_safe': sum(d['safe_actual_6mm'] for d in decisions),
            'complete_unsafe_accepts': endpoints['complete_unsafe_accepts']},
        'endpoint_statuses': {k: v['status'] for k, v in endpoints.items() if isinstance(v, dict) and 'status' in v},
        'endpoints': endpoints, 'all_direction_leg_amplitude_strata': strata,
        'planned_positions': len(rows), 'independent_physical_snapshots': 8, 'independent_episodes': 4,
        'new_fits': 0, 'new_CAL': 0, 'result_based_retries': 0, 'numerical_DEV_recomputations': 0,
        'screen_full_identity': read(out / 'SCREEN_IDENTITY_END.json'), 'all_new_files_on_D': True,
        'source_worktree_read_only': True, 'E3_RL_hardware_authorized': False}
    write(out / 'ALL_PLANNED_RESULTS.json', rows); csv_save(out / 'ALL_BRANCH_RESULTS.csv', rows)
    write(out / 'ALL_GOVERNOR_DECISIONS.json', decisions)
    csv_save(out / 'GOVERNOR_DECISIONS.csv', [{k: v for k, v in d.items() if k != 'queries'} for d in decisions])
    write(out / 'SCREEN_QUERIES.json', queries)
    write(out / 'STEP40_RESULT.json', result)
    for kind in ('TYPE_I', 'TYPE_II', 'screen_safe_B_progress', 'screen_failed_B_recovery'):
        csv_save(out / (kind + '_PAIRS.csv'), endpoints[kind]['pairs'])
    print(json.dumps({k: result[k] for k in ('endpoint_statuses', 'direct', 'recognized', 'governor', 'readback')}, ensure_ascii=False))
    return result


if __name__ == '__main__':
    summarize()
