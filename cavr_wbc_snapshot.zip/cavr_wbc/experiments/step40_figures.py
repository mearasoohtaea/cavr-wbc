"""Two all-result SciPilot figures. Only saved results are consumed."""
import argparse
import sys
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, BoundaryNorm
from cavr_wbc.experiments.step40_io import output, read, write, encode
from cavr_wbc.experiments.step40_inputs import plans
from cavr_wbc.experiments.step39_delivery import safe

SKILL = Path('C:/Users/ZhuanZ（无密码）/.codex/skills/scipilot-figure/scripts')
sys.path.insert(0, str(SKILL))
from setup_style import setup_style
from profile_data import profile_data, render_report
from visual_qa import audit_layout, render_preview
from layout_tools import add_panel_labels
from export_figure import export_figure

BLUE = '#0072B2'
ORANGE = '#E69F00'
GREY = '#DDDDDD'
setup_style(journal='ieee', lang='en', use_sciplots=False)
plt.rcParams.update({'font.size': 8, 'xtick.labelsize': 7, 'ytick.labelsize': 7,
    'axes.labelsize': 8, 'axes.titlesize': 8, 'legend.fontsize': 8,
    'figure.constrained_layout.use': False, 'figure.autolayout': False,
    'savefig.bbox': None,
    'pdf.fonttype': 42, 'svg.fonttype': 'none', 'axes.spines.top': False,
    'axes.spines.right': False})


def source_label(p, snapshots):
    si = snapshots.index(p['snapshot_id']) + 1
    kind = {'HEALTHY': 'H', 'FR_THIGH30': 'F30', 'FR_THIGH15': 'F15',
            'RR_THIGH30': 'R30', 'RR_THIGH15': 'R15'}[p['health_kind']]
    return f'S{si} {kind}'


def figure1(rows, result):
    by = {r['id']: r for r in rows}
    ps = plans('TEST')
    snapshots = list(dict.fromkeys(p['snapshot_id'] for p in ps))
    fig = plt.figure(figsize=(7.16, 8.6))
    axes = [fig.add_axes([.12, .33, .36, .51]), fig.add_axes([.62, .33, .36, .51]),
            fig.add_axes([.12, .105, .86, .14])]
    palette = ListedColormap(['white', GREY, ORANGE, BLUE])
    for ax, direction in zip(axes[:2], (1, -1)):
        group = [p for p in ps if p['direction'] == direction]
        values = np.zeros((20, 9), dtype=int)
        symbols = [['' for _ in range(9)] for _ in range(20)]
        for i, p in enumerate(group):
            for j, branch in enumerate(('C', 'MIDDLE', 'B')):
                r = by[p['context_id'] + ':' + branch]
                components = [r['physical_pass'], r['terminal_pass'],
                    None if r['D_m'] is None else r['D_m'] <= .006]
                for k, value in enumerate(components):
                    code, symbol = (0, 'x') if not r['observed'] else (1, '?') if not r['complete_501'] else (3, '1') if value else (2, '0')
                    values[i, j * 3 + k] = code
                    symbols[i][j * 3 + k] = symbol
        ax.pcolormesh(np.arange(-.5, 9.5), np.arange(-.5, 20.5), values,
            cmap=palette, norm=BoundaryNorm(np.arange(-.5, 4.5), 4), shading='flat', rasterized=False)
        ax.set_xlim(-.5, 8.5); ax.set_ylim(19.5, -.5)
        for i in range(20):
            for j in range(9):
                ax.text(j, i, symbols[i][j], ha='center', va='center', fontsize=8,
                        color='white' if values[i, j] == 3 else '#222222')
        ax.set_yticks(range(20), [source_label(p, snapshots) for p in group])
        ax.set_xticks(range(9), ['P', 'T', 'L'] * 3)
        for x in (2.5, 5.5):
            ax.axvline(x, color='white', lw=1.5)
        for y in (4.5, 9.5, 14.5):
            ax.axhline(y, color='black', lw=.7)
        ax.set_xlabel('C                     middle                     B', labelpad=6)
        ax.set_title('Positive targets: +62.5 / +67.5 mm' if direction > 0 else 'Negative targets: -62.5 / -67.5 mm', pad=12)
        ax.tick_params(length=0)
    mechanism_ax = axes[2]
    matrix = np.full((4, 8), 2.)
    symbols = np.full((4, 8), '.', dtype=object)
    for type_index, name in enumerate(('TYPE_I', 'TYPE_II')):
        for p in result['endpoints'][name]['pairs']:
            y = type_index * 2 + (0 if p['fault_leg'] == 'FR' else 1)
            x = snapshots.index(p['snapshot_id'])
            code, symbol = (3, 'Q') if p['qualified'] else (2, '0') if p['complete_pair'] else (1, '?')
            matrix[y, x] = code; symbols[y, x] = symbol
            if p['timing_qualified_mechanism']:
                mechanism_ax.plot(x, y, marker='s', ms=15, mfc='none', mec='black', mew=1.2)
    mechanism_ax.pcolormesh(np.arange(-.5, 8.5), np.arange(-.5, 4.5), matrix,
        cmap=palette, norm=BoundaryNorm(np.arange(-.5, 4.5), 4), shading='flat', rasterized=False)
    mechanism_ax.set_xlim(-.5, 7.5); mechanism_ax.set_ylim(3.5, -.5)
    for y in range(4):
        for x in range(8):
            mechanism_ax.text(x, y, symbols[y, x], ha='center', va='center', fontsize=8,
                             color='white' if matrix[y, x] == 3 else 'black')
    mechanism_ax.set_yticks(range(4), ['Type-I FR', 'Type-I RR', 'Type-II FR', 'Type-II RR'])
    mechanism_ax.set_xticks(range(8), [f'S{i + 1}' for i in range(8)])
    mechanism_ax.set_xlabel('Same-state physical snapshots (two per episode)')
    mechanism_ax.set_title('Pre-registered complete mechanism pairs; box = all required windows timely', pad=12)
    mechanism_ax.tick_params(length=0)
    fig.text(.12, .97, 'Same-state health intervention: all 120 direct trajectories', fontsize=11, weight='bold')
    fig.text(.12, .93, 'P = physical, T = terminal, L = 6 mm local; 1 pass, 0 fail, ? partial, x unapplied', fontsize=8)
    fig.text(.12, .90, 'H = healthy; F/R = FR/RR thigh; 30/15 = health .30/.15; Q = qualified mechanism', fontsize=8)
    fig.text(.12, .035, 'S1/S2: +62.5; S3/S4: -62.5; S5/S6: +67.5; S7/S8: -67.5 mm. Ticks 36/40.', fontsize=8)
    add_panel_labels(fig, axes=axes, style='ieee', fontsize=9)
    return fig


def make_figures(export=False):
    import pandas as pd
    out = output(); directory = out / 'figures'; directory.mkdir(exist_ok=True)
    rows = read(out / 'ALL_PLANNED_RESULTS.json')
    decisions = read(out / 'ALL_GOVERNOR_DECISIONS.json')
    result = read(out / 'STEP40_RESULT.json')
    capacity = read(out / 'CAPACITY_EVENTS_FULL.json')
    # Typed profile copies only; original scalar evidence is never rewritten.
    profile_rows = [{k: r[k] for k in ('id', 'snapshot_id', 'episode', 'condition', 'branch',
        'complete_501', 'physical_pass', 'terminal_pass', 'D_m', 'first_packet_ready_ms',
        'max_feedback_latency_ms', 'max_actual_tau_capacity_ratio')} for r in rows]
    frame = pd.DataFrame(profile_rows)
    for key in ('id', 'snapshot_id', 'episode', 'condition', 'branch'):
        frame[key] = frame[key].astype(object)
    profile = profile_data(frame, ['condition', 'branch'])
    write(directory / 'DATA_PROFILE.json', profile)
    with (directory / 'DATA_PROFILE.md').open('w', encoding='utf-8', newline='\n') as f:
        f.write(render_report(profile))
    write(directory / 'FIGURE_DESIGN.json', {
        'goal_1': 'All same-state dose branches, separate Type-I and Type-II completeness and timing',
        'goal_2': 'All actual fault-channel capacity timing, first violation and every frozen online decision',
        'primary_chart': 'Individual outcome cells and paired timing/latency dots',
        'alternatives': ['Separate per-snapshot dot facets', 'Full outcome tables'],
        'reason': '8 physical snapshots / 4 episodes and paired repeated conditions; no stable independent-group CI',
        'no_mean_bars': True, 'no_p_values_or_CI': True, 'all_partial_unapplied_visible': True,
        'continuous_capacity_scale': [0, 1], 'palette': 'Okabe-Ito categorical and cividis continuous',
        'redundant_encoding': '1/0/?/x/Q symbols and o/x timing markers',
        'journal_style': 'IEEE double-column 7.16 inch, 600 DPI, PDF TrueType / SVG vectors',
        'capacity_columns': 'Actual applied control slots only; rejected candidate is never treated as sent'})
    figures = [figure1(rows, result), figure2(rows, decisions, capacity, result)]
    qa = {}
    for i, fig in enumerate(figures, 1):
        stem = directory / ('FIGURE' + str(i))
        render_preview(fig, str(stem) + '_preview.png', dpi=180)
        from PIL import Image
        with Image.open(str(stem) + '_preview.png') as img:
            img.convert('L').save(str(stem) + '_preview_gray.png')
        qa[str(i)] = audit_layout(fig)
        if export:
            export_figure(fig, str(stem), formats=['pdf', 'svg', 'png'],
                          size_inches=tuple(fig.get_size_inches()), dpi=600,
                          grayscale_preview=False, tight=False)
            # The skill helper's gray mode rewrites the color PNG with tight crop.
            # Read the exact-size export instead; do not overwrite that PNG.
            with Image.open(str(stem) + '.png') as img:
                img.convert('L').save(str(stem) + '_grayscale.png', dpi=(600, 600))
        plt.close(fig)
    write(directory / 'PROGRAM_QA.json', qa)
    print(encode({'export': export, 'QA': qa}))


def figure2(rows, decisions, capacity, result):
    by = {r['id']: r for r in rows}
    ps = plans('TEST')
    snapshots = list(dict.fromkeys(p['snapshot_id'] for p in ps))
    fig = plt.figure(figsize=(7.16, 11.0))
    top = [fig.add_axes([.15, .405, .32, .465]), fig.add_axes([.66, .405, .32, .465])]
    numeric = {r['id']: [] for r in rows}
    for r in capacity:
        numeric[r['id']].append(r)
    image = None
    for ax, direction in zip(top, (1, -1)):
        group = [(p, b) for p in ps if p['direction'] == direction and p['health_kind'] != 'HEALTHY'
                 for b in ('C', 'MIDDLE', 'B', 'RECOGNIZED') if b != 'RECOGNIZED' or p['governor_planned']]
        matrix = np.full((56, 50), np.nan)
        for y, (p, b) in enumerate(group):
            r = by[p['context_id'] + ':' + b]
            for c in numeric[r['id']]:
                if c['actual_tau_capacity_ratio'] is not None and c['actual_applied']:
                    matrix[y, c['slot']] = c['actual_tau_capacity_ratio']
            first, failure = r['first_actual_99percent_s'], r['first_dense_failure_s']
            if first is not None:
                ax.plot(first, y, marker='o', ms=3.5, mfc='white', mec='black', mew=.6)
            if failure is not None:
                ax.plot(failure, y, marker='x', ms=4, color='white', mew=1.8)
                ax.plot(failure, y, marker='x', ms=4, color='black', mew=.7)
            if not r['complete_501']:
                ax.text(1.02, y, '?' if r['observed'] else 'x', ha='center', va='center', fontsize=7)
        cmap = plt.get_cmap('cividis').copy(); cmap.set_bad('white')
        image = ax.pcolormesh(np.arange(51) * .02 - .01, np.arange(-.5, 56.5), matrix,
            cmap=cmap, vmin=0, vmax=1, shading='flat', rasterized=False)
        ax.set_ylim(55.5, -.5)
        ax.set_xlim(-.01, 1.055)
        ax.set_xticks([0, .5, 1.])
        ax.set_yticks(range(56), [source_label(p, snapshots) + ' ' +
            ('M' if b == 'MIDDLE' else 'G' if b == 'RECOGNIZED' else b) for p, b in group])
        ax.set_xlabel('Application-clock time (s)')
        ax.set_title('Positive targets' if direction > 0 else 'Negative targets', pad=12)
        ax.tick_params(axis='y', length=0, labelsize=6.5)
        for y in range(13, 55, 14):
            ax.axhline(y + .5, c='black', lw=.6)
    cax = fig.add_axes([.36, .315, .4, .012])
    cb = fig.colorbar(image, cax=cax, orientation='horizontal')
    cb.solids.set_rasterized(False)
    cb.set_label('Actual sent |fault torque| / effective capacity', fontsize=8)
    cb.set_ticks([0, .5, .99])
    bottom = [fig.add_axes([.15, .075, .25, .175]), fig.add_axes([.465, .075, .20, .175]),
              fig.add_axes([.75, .075, .23, .175])]
    recovery = {p['context_id']: p for p in result['endpoints']['screen_failed_B_recovery']['pairs']}
    gains = {p['context_id']: p for p in result['endpoints']['screen_safe_B_progress']['pairs']}
    for y, d in enumerate(decisions):
        sent = d['selected_command_sent']
        values = ((d.get('command_ready_ms'), 'o', BLUE if sent else '#777777'),
                  (d.get('max_feedback_latency_ms'), 's', '#222222'))
        for value, marker, color in values:
            if value is not None and np.isfinite(value):
                bottom[0].plot(value, y, marker=marker if sent else 'x', c=color, ms=3.5, ls='none')
        R, B = by[d['context_id'] + ':RECOGNIZED'], by[d['context_id'] + ':B']
        if R['complete_501'] and R['D_m'] is not None:
            bottom[1].plot(R['D_m'] * 1000, y, marker='o' if safe(R) else 'X', c=BLUE if safe(R) else ORANGE, ms=4, ls='none')
        else:
            bottom[1].text(.04, y, 'partial' if R['observed'] else 'unapplied', transform=bottom[1].get_yaxis_transform(), fontsize=7, va='center')
        pair = gains[d['context_id']]
        if R['complete_501'] and B['complete_501'] and pair['recognized_B_gain_m'] is not None:
            bottom[2].plot(pair['recognized_B_gain_m'] * 1000, y, marker='o' if pair['qualified'] else 'x',
                           c=BLUE if pair['qualified'] else '#555555', ms=4, ls='none')
        if recovery[d['context_id']]['qualified']:
            bottom[2].text(.97, y, 'II', transform=bottom[2].get_yaxis_transform(), ha='right', va='center', fontsize=7, weight='bold')
    for ax in bottom:
        ax.set_ylim(15.5, -.5); ax.set_yticks(range(16)); ax.grid(axis='x', color='#E0E0E0', lw=.5)
    bottom[0].set_yticklabels([source_label(next(p for p in ps if p['context_id'] == d['context_id']), snapshots) for d in decisions])
    for ax in bottom[1:]:
        ax.tick_params(labelleft=False, axis='y', length=0)
    maximum = max([d.get('command_ready_ms') or 0 for d in decisions] + [d.get('max_feedback_latency_ms') or 0 for d in decisions])
    bottom[0].set_xlim(0, max(24, maximum * 1.15)); bottom[0].axvline(20, c='#D55E00', ls='--', lw=.7)
    bottom[0].set_xlabel('First / max feedback (ms)'); bottom[0].set_title('All 16 decisions', pad=12)
    ds = [r['D_m'] * 1000 for r in rows if r['branch'] == 'RECOGNIZED' and r['complete_501'] and r['D_m'] is not None]
    bottom[1].set_xlim(0, max(8, max(ds, default=0) * 1.1)); bottom[1].axvline(6, c='black', ls='--', lw=.7)
    bottom[1].set_xlabel('Actual D (mm)'); bottom[1].set_title('Recognized horizon', pad=12)
    gs = [g['recognized_B_gain_m'] * 1000 for g in gains.values() if g['recognized_B_gain_m'] is not None]
    bottom[2].set_xlim(min(-.1, min(gs, default=0) * 1.1), max(.2, max(gs, default=0) * 1.3))
    bottom[2].axvline(0, c='black', lw=.5); bottom[2].set_xlabel('Actual - B gain (mm)'); bottom[2].set_title('Complete paired gain', pad=12)
    fig.text(.15, .97, 'Capacity timing and frozen online selection', fontsize=11, weight='bold')
    fig.text(.15, .945, 'All injured positions: 96 direct + 16 recognized; o first 99%; x first physical violation', fontsize=8)
    fig.text(.15, .922, 'G = independent recognized actual; white = unapplied; ? partial; M = middle.', fontsize=8)
    fig.text(.15, .275, 'Latency: circle first, square feedback; x abstain/late. Gain: circle safe-B pair; II failed-B recovery.', fontsize=7.5)
    fig.text(.15, .025, '8 physical snapshots / 4 episodes; paired interventions, no independent-sample CI or p-values.', fontsize=8)
    add_panel_labels(fig, axes=top + bottom, style='ieee', fontsize=9)
    return fig


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--export', action='store_true')
    make_figures(parser.parse_args().export)
