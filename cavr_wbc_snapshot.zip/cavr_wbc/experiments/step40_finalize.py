"""Figure-format verification only, separate from the sole numerical readback."""
from pathlib import Path
import subprocess
import sys
from cavr_wbc.experiments.step40_io import output, read, write


def check_figures(out=output()):
    directory = out / 'figures'
    checker = Path('C:/Users/ZhuanZ（无密码）/.codex/skills/scipilot-figure/scripts/check_figure.py')
    runs = []
    for i, height in ((1, 8.6), (2, 11.)):
        command = [sys.executable, '-B', '-X', 'utf8', str(checker),
                   *[str(directory / ('FIGURE' + str(i) + '.' + ext)) for ext in ('pdf', 'svg', 'png')],
                   '--min-dpi', '600', '--width-in', '7.16', '--height-in', str(height), '--strict']
        r = subprocess.run(command, capture_output=True, text=True, encoding='utf-8')
        runs.append({'command': command, 'exit_code': r.returncode, 'stdout': r.stdout, 'stderr': r.stderr})
    from pypdf import PdfReader
    fonts = []
    for i in (1, 2):
        pdf = directory / ('FIGURE' + str(i) + '.pdf')
        for page in PdfReader(pdf).pages:
            for _, reference in page['/Resources'].get_object().get('/Font', {}).items():
                font = reference.get_object()
                descendants = font.get('/DescendantFonts', [font])
                for reference in descendants:
                    child = reference.get_object()
                    descriptor = child.get('/FontDescriptor')
                    descriptor = descriptor.get_object() if descriptor else {}
                    fonts.append({'file': pdf.name, 'subtype': str(child.get('/Subtype')),
                                  'embedded': any(key in descriptor for key in ('/FontFile', '/FontFile2', '/FontFile3'))})
    svg = {f'FIGURE{i}.svg': '<image' in (directory / f'FIGURE{i}.svg').read_text(encoding='utf-8') for i in (1, 2)}
    from PIL import Image
    dimensions = []
    for i, height in ((1, 8.6), (2, 11.)):
        with Image.open(directory / f'FIGURE{i}.png') as img:
            dpi = img.info['dpi']; inches = [img.width / dpi[0], img.height / dpi[1]]
        box = PdfReader(directory / f'FIGURE{i}.pdf').pages[0].mediabox
        pdf_inches = [float(box.width) / 72, float(box.height) / 72]
        dimensions.append({'figure': i, 'PNG_inches': inches, 'PDF_inches': pdf_inches,
            'target_inches': [7.16, height], 'exact_size_pass': all(abs(a - b) < .01
                for actual in (inches, pdf_inches) for a, b in zip(actual, (7.16, height)))})
    result = {'status': 'PASS' if all(r['exit_code'] == 0 for r in runs)
              and fonts and all(f['embedded'] for f in fonts) and not any(svg.values())
              and all(d['exact_size_pass'] for d in dimensions) else 'FAIL',
        'strict_checker_runs': runs, 'descendant_font_verification': fonts,
        'svg_embedded_bitmap': svg, 'program_layout_QA': read(directory / 'PROGRAM_QA.json'),
        'exact_final_dimensions': dimensions,
        'PDF_Type0_parent_warning_resolution': 'Actual CIDFontType2 descendant FontFile2 embedding checked directly.',
        'current_figures_only': True, 'new_solver_calls': 0, 'new_physics_steps': 0, 'new_fits': 0}
    write(directory / 'SCIPILOT_CHECK.json', result)
    print({'figure_format_status': result['status'], 'strict_exit_codes': [r['exit_code'] for r in runs],
           'font_count': len(fonts), 'SVG_embedded_bitmap': svg})
    if result['status'] != 'PASS':
        raise SystemExit(1)


if __name__ == '__main__':
    check_figures()
