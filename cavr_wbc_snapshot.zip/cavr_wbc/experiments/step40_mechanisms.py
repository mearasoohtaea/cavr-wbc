"""Pre-registered same-state Type-I/II and online endpoints, no numerical calls."""
from cavr_wbc.experiments.step39_delivery import physical, physical_terminal, safe


def mechanism(kind, healthy, mild, failed, middle, backup=None):
    necessary = [healthy, mild, failed, middle] + ([backup] if kind == 'TYPE_I' else [])
    complete = all(bool(r and r.get('complete_501')) for r in necessary)
    failure_observed = bool(failed and failed.get('complete_501') and failed.get('physical_pass') is False)
    temporal = bool(failed and failed.get('capacity_precedes_failure'))
    qualified = bool(complete and physical_terminal(healthy) and physical_terminal(mild)
                     and failure_observed and temporal and safe(middle)
                     and (kind == 'TYPE_II' or physical_terminal(backup)))
    return {'complete_pair': complete, 'qualified': qualified,
            'healthy_physical_terminal': physical_terminal(healthy or {}),
            'mild_physical_terminal': physical_terminal(mild or {}),
            'severe_complete_original_physical_failure': failure_observed,
            'capacity_precedes_failure': temporal, 'middle_safe_6mm': safe(middle or {}),
            'severe_B_physical_terminal': None if backup is None else physical_terminal(backup),
            'timing_qualified_mechanism': bool(qualified and all(r.get('timing_qualified') for r in necessary)),
            'necessary_latency': [{'id': r.get('id'), 'first_ms': r.get('first_packet_ready_ms'),
                'feedback_max_ms': r.get('max_feedback_latency_ms'), 'timing_qualified': r.get('timing_qualified')}
                for r in necessary if r]}


def endpoint(pairs, across='OBSERVED_ACROSS_EPISODES'):
    qualified = [p for p in pairs if p['qualified']]
    ns = len({p['snapshot_id'] for p in qualified})
    ne = len({p['episode'] for p in qualified})
    timely = [p for p in pairs if p.get('timing_qualified_mechanism')]
    ts, te = len({p['snapshot_id'] for p in timely}), len({p['episode'] for p in timely})
    return {'status': across if ns >= 2 and ne >= 2 else
            'INCOMPLETE' if any(not p['complete_pair'] for p in pairs) else 'NOT_ESTABLISHED',
            'qualified_contexts': len(qualified), 'physical_snapshots': ns, 'episodes': ne,
            'qualified_context_ids': [p['context_id'] for p in qualified],
            'timing_qualified_contexts': len(timely), 'timing_qualified_snapshots': ts,
            'timing_qualified_episodes': te,
            'online_closure': 'TIMING_QUALIFIED_MECHANISM' if ts >= 2 and te >= 2 else 'NOT_ESTABLISHED',
            'pairs': pairs}


def all_endpoints(rows, decisions, plans):
    by = {r['id']: r for r in rows}
    dec = {d['context_id']: d for d in decisions}
    type_i, type_ii, gain_pairs, recovery_pairs, local = [], [], [], [], []
    for p in plans:
        cid = p['context_id']
        C, M, B = [by[cid + ':' + b] for b in ('C', 'MIDDLE', 'B')]
        gain = None if M['progress02_04_m'] is None or B['progress02_04_m'] is None else M['progress02_04_m'] - B['progress02_04_m']
        identity = {k: p[k] for k in ('context_id', 'snapshot_id', 'episode', 'direction', 'displacement_m', 'fault_leg', 'health_kind')}
        local.append({**identity, 'complete_pair': all(r['complete_501'] for r in (C, M, B)),
            'qualified': bool(C['complete_501'] and not safe(C) and safe(M) and safe(B) and gain is not None and gain > 0),
            'middle_B_gain_m': gain, 'healthy_condition': p['health_kind'] == 'HEALTHY'})
        if not p['governor_planned']:
            continue
        def peer(condition, branch):
            return by[p['snapshot_id'] + '_' + condition + ':' + branch]
        leg = p['fault_leg']
        I = {**identity, **mechanism('TYPE_I', peer('HEALTHY', 'C'), peer(leg + '_THIGH30', 'C'), C, M, B)}
        II = {**identity, **mechanism('TYPE_II', peer('HEALTHY', 'B'), peer(leg + '_THIGH30', 'B'), B, M)}
        type_i.append(I); type_ii.append(II)
        R = by[cid + ':RECOGNIZED']; d = dec[cid]
        rgain = None if R['progress02_04_m'] is None or B['progress02_04_m'] is None else R['progress02_04_m'] - B['progress02_04_m']
        middle = bool(d['selected_command_sent'] and d['selected_gamma'] == .5 and safe(R))
        common = {**identity, 'recognized_middle_safe': middle, 'recognized_complete': R['complete_501'],
                  'recognized_B_gain_m': rgain, 'same_source_not_same_packet': True}
        gain_pairs.append({**common, 'complete_pair': bool(d['decision_exists'] and B['complete_501'] and
            (R['complete_501'] or not d['selected_command_sent'])),
            'qualified': bool(middle and safe(B) and rgain is not None and rgain > 0)})
        recovery_pairs.append({**common, 'complete_pair': bool(d['decision_exists'] and II['complete_pair'] and
            (R['complete_501'] or not d['selected_command_sent'])), 'qualified': bool(middle and II['qualified'])})
    unsafe = sum(d['selected_command_sent'] and d['complete_actual'] and not d['safe_actual_6mm'] for d in decisions)
    gains, recoveries = endpoint(gain_pairs), endpoint(recovery_pairs)
    if unsafe:
        gains['status'] = recoveries['status'] = 'NOT_ESTABLISHED'
    return {'TYPE_I': endpoint(type_i), 'TYPE_II': endpoint(type_ii),
            'screen_safe_B_progress': gains, 'screen_failed_B_recovery': recoveries,
            'local_secondary_6mm': endpoint(local, across='OBSERVED'),
            'complete_unsafe_accepts': unsafe,
            'healthy_local_secondary_contexts': sum(p['qualified'] and p['healthy_condition'] for p in local),
            'injured_local_secondary_contexts': sum(p['qualified'] and not p['healthy_condition'] for p in local)}
