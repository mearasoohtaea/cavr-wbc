"""Chinese complete-result report, bounded handoff and current-file hash index."""
import json
from cavr_wbc.experiments.step40_io import *
from cavr_wbc.experiments.step39_delivery import safe, physical_terminal, outcome


def text_file(path, text):
    require_output(path)
    with path.open('w', encoding='utf-8', newline='\n') as f:
        f.write(text.rstrip() + '\n')


def number(value, scale=1., digits=3):
    return 'NA' if value is None else f'{value * scale:.{digits}f}'


def table(fields, rows):
    content = ['| ' + ' | '.join(fields) + ' |', '| ' + ' | '.join(['---'] * len(fields)) + ' |']
    content += ['| ' + ' | '.join(str(v).replace('|', '/') for v in row) + ' |' for row in rows]
    return '\n'.join(content)


def render(out=output()):
    r = read(out / 'STEP40_RESULT.json'); rows = read(out / 'ALL_PLANNED_RESULTS.json')
    decisions = read(out / 'ALL_GOVERNOR_DECISIONS.json'); manifest = read(out / 'PROTOCOL_AND_MANIFEST.json')
    endpoints = r['endpoints']; budget = r['run']['budget']
    statuses = table(['终点', '状态', '合格 context', 'physical snapshot', 'episode', '全部必要窗口及时'],
        [[key, e['status'], e['qualified_contexts'], e['physical_snapshots'], e['episodes'],
          e['online_closure'] if key in ('TYPE_I', 'TYPE_II') else 'NA（非Type-I/II资格）']
         for key, e in endpoints.items() if isinstance(e, dict) and 'status' in e])
    by = {v['id']: v for v in rows}
    branch_table = table(['context', 'C (P/T/D mm)', 'middle (P/T/D mm)', 'B (P/T/D mm)', 'timely C/M/B'],
        [[p['context_id'], *[('/'.join(('?' if not by[p['context_id'] + ':' + name]['complete_501'] else
            str(int(bool(by[p['context_id'] + ':' + name][key]))) for key in ('physical_pass', 'terminal_pass')))
            + '/' + number(by[p['context_id'] + ':' + name]['D_m'], 1000)) for name in ('C', 'MIDDLE', 'B')],
          '/'.join(str(int(by[p['context_id'] + ':' + name]['timing_qualified'])) for name in ('C', 'MIDDLE', 'B'))]
         for p in manifest['TEST_plans']])
    mechanism_tables = []
    for kind in ('TYPE_I', 'TYPE_II'):
        pairs = endpoints[kind]['pairs']
        rows_pair = [[p['context_id'], p['complete_pair'], p['qualified'], p['timing_qualified_mechanism'],
            p['healthy_physical_terminal'], p['mild_physical_terminal'], p['severe_complete_original_physical_failure'],
            p['capacity_precedes_failure'], p['middle_safe_6mm'],
            '; '.join(v['id'] + ':' + number(v['first_ms']) + '/' + number(v['feedback_max_ms']) for v in p['necessary_latency'])] for p in pairs]
        mechanism_tables.append('### ' + kind + '\n\n' + table(['context', '完整', '机制合格', 'timing-qualified',
            '健康 PT', '.30 PT', '.15 实测物理失败', '99%早于失败', 'middle 6mm安全', '必要分支首包/反馈最大 ms'], rows_pair))
    decision_table = table(['context', '决定', 'gamma', '首包 ms', 'actual', 'actual D mm', '反馈最大 ms', '安全B增益 mm', 'Type-II在线恢复'],
        [[d['context_id'], d['status'], d['selected_gamma'], number(d['command_ready_ms']),
          d['actual_outcome'], number(by[d['context_id'] + ':RECOGNIZED']['D_m'], 1000), number(d['max_feedback_latency_ms']),
          number(next(p for p in endpoints['screen_safe_B_progress']['pairs'] if p['context_id'] == d['context_id'])['recognized_B_gain_m'], 1000),
          next(p for p in endpoints['screen_failed_B_recovery']['pairs'] if p['context_id'] == d['context_id'])['qualified']] for d in decisions])
    strata = table(['方向', '幅值 mm', '腿', '完整 direct', 'PT通过', '6mm安全', 'Type-I', 'Type-II'],
        [[s['direction'], number(s['target_amplitude_m'], 1000), s['fault_leg'], s['direct']['complete_501'],
          s['direct']['complete_physical_terminal'], s['direct']['complete_safe_6mm'], s['TYPE_I_qualified'], s['TYPE_II_qualified']]
         for s in r['all_direction_leg_amplitude_strata']])
    contact_rows = []
    for v in rows:
        for foot, f in (v.get('contact_statistics') or {}).get('contacts', {}).items():
            for reason in ('CONTACT_LOSS', 'NEGATIVE_NORMAL_FORCE', 'FRICTION_VIOLATION'):
                if f[reason]['unqualified_points']:
                    ev = f[reason]
                    contact_rows.append([v['id'], foot, reason, ev['unqualified_points'],
                        number(ev['longest_grid_supported_duration_s'], 1000), number(ev['longest_observed_point_span_s'], 1000),
                        number(f['min_normal_force_n']), number(f['min_friction_margin_n']), number(ev['first_s'])])
    contacts = table(['branch', '足', '违反类型', '点数', '最长网格支持 ms', '最长点跨度 ms', '最小法向力 N', '最小摩擦裕量 N', '首次 s'], contact_rows)
    protocol = (OUTPUT_ROOT_D / 'configs/validation/STEP40_PROTOCOL.md').read_text(encoding='utf-8')
    ini = protocol.split('~~~ini\n', 1)[1].split('~~~', 1)[0].strip()
    report = f'''# STEP40：容量退化与备份失效恢复

## Material Passport

- Origin Skill: experiment-agent（run）；图形使用 SciPilot。
- Version: STEP40 固定 DEV；数据为新 8 个物理 snapshot / 4 个 episode。
- Verification: 当前工件 saved-only readback = {r['readback']['status']}；不是复跑验证。
- 方法：同一实际 integration state 的真实单关节 health 干预，冻结 STEP39 在线模型/CAL。
- 单位：D/任务进度 m（图表转 mm）；force N，torque N·m，time s，latency ms。

## 本批结论

{statuses}

数值批次状态 {r['run']['status']}。120 计划 direct 中完整 {r['direct']['complete_501']}，physical+terminal 通过 {r['direct']['complete_physical_terminal']}，6 mm 安全 {r['direct']['complete_safe_6mm']}，timing-qualified {r['direct']['timing_qualified']}。
全部 16 筛选决定中及时认可 {r['governor']['timely_recognized']}，完整安全 {r['governor']['complete_safe']}，完整错误接受 {r['governor']['complete_unsafe_accepts']}，partial {r['governor']['partial']}，ABSTAIN {r['governor']['ABSTAIN']}，首包 late {r['governor']['late']}。

本批筛选零错误目标 = {'FAILED' if r['governor']['complete_unsafe_accepts'] else 'NO_COMPLETE_ERROR_OBSERVED'}。错误接受 `T40_TEST_1_T040_FR_THIGH15:RECOGNIZED` 的gamma=.5，完整physical与6mm local通过，但terminal未通过；D=5.126899mm，首包12.048800ms、最大feedback4.077900ms，原始结果保留，不通过调阈值消除该失败。
Type-II的跨episode观察覆盖负向−62.5mm RR的tick36/40以及正向+67.5mm FR的tick40；分别属于两个episode。合并的是同一预注册类型，而不是Type-I/II混合；各方向/腿单独尚非跨episode证据。

6 mm secondary：健康 {endpoints['healthy_local_secondary_contexts']} 个、受损 {endpoints['injured_local_secondary_contexts']} 个合格 context；不把健康 local 越界解释为损伤物理收益。Type-I/II、两类在线收益分别计数，未合并凑门。

## 固定设计与完整分母

source commit `{SOURCE_COMMIT}`；D 独立 checkout，分支 `codex/step40-capacity-backup-recovery-20261010`。来源只读：`{SOURCE_ROOT_D}`。
四条新健康 reference，目标 +62.5 / -62.5 / +67.5 / -67.5 mm，各110 control tick /1100步；tick36/40产生8个物理快照。每个快照 HEALTHY、FR_THIGH30/15、RR_THIGH30/15，各 C/middle/B，合计120 direct。16个 .15 筛选决定对应16个认可计划位；所有136位置在 ALL_PLANNED_RESULTS.json / ALL_BRANCH_RESULTS.csv，未施加、缺失和partial保留。

控制链原样沿用 REDUCED_WHITENED_RESIDENT 与42维原 hard rows、独立 native owner、同owner B0及staging→check→commit；健康reference精度1e-8、candidate1e-7、friction工作上界-1e-4N、torque双侧inset1e-4N·m、original extra slack=0。sample0、prehold0–.02、首动作.02–.04、48次feedback .04… .98、终点1.000s；dt=.002，500/501/21网格。任务、物理/terminal阈值、6mm边界和20ms未变。

每个 .15 source 先保存不可改的筛选决定，再用自身live owner执行认可ACTUAL，最后运行独立direct。没有未来标签选择、免费复用direct或跨owner复制缓存。direct允许offline迟到传播；认可ACTUAL无效/迟到在commit和积分前终止，不用零命令补齐。

## Type-I 与 Type-II

Type-I要求健康C、.30C完整PT通过，.15C完整实测物理违反、99%容量激活早于首次违反，.15 middle/B均PT通过且middle满足6mm。
Type-II要求健康B、.30B完整PT通过，.15B完整实测物理违反、99%容量激活早于首次违反，.15 middle完整PT+6mm安全。各自至少2snapshot/2episode，适用域按方向/腿/幅值列出；健康C/B是否满足6mm不作为物理终点前置。

{chr(10).join(mechanism_tables)}

首包/feedback最大window全部列出，任一必要分支迟到则物理观察不能称为在线闭合。99%时序仅为容量事件证据，不证明饱和是因果中介、全局稳定性或viability。

## 方向、故障腿、幅值分层

{strata}

## 全部同态 direct 结果

P/T 的1/0为完整物理/terminal通过/失败，?为未完成；D为已有实测值，partial的D不当完整local资格。最后一列为完整首包与feedback时延合格 C/M/B。

{branch_table}

## 冻结筛选器在线收益

继承28维模型、四组CAL、TRAIN姿态范围/padding、K=5支持、原距离/risk/terminal门、R=.1mm和.5→0 shortlist。fit=0、新CAL=0。启动/结束同时核对系数/scaler/pose、所有group CAL/TRAIN数组、身份和阈值，完整指纹不变={r['screen_full_identity']['full_model_CAL_TRAIN_threshold_identity_unchanged']}。输入npz/json与源CAL_FREEZE的SHA一致；没有用仅系数一致替代CAL一致。

安全B配对进度收益和B实测失败时的Type-II恢复收益为两个预注册分母，不修改STEP39旧结论。认可与direct拥有不同packet，比较是同source方法配对，不是精确同packet反事实。

{decision_table}

所有首包窗口包含sample/prehold/application、C/B、native/reconstruct/hard-check、prefix、features/inference/gates、最终selected/B0记忆拷贝；首包及时不等于任意horizon/硬件实时。ABSTAIN不施加未经认可的B。

## 接触违反事实与容量时序

全部故障 actual sent tau/effective capacity、99%首次与槽数、prehold/feedback限幅、anti-windup见 CAPACITY_EVENTS_FULL.json/.csv；无效未施加candidate与actual_applied分开。lossless actual.npz保留dense接触/力/摩擦/距离裕量，controls.json/.npz保留命令/记忆/时延及raw引用。

{contacts}

最长网格支持时长为连续不合格点数×2ms，点跨度为(n-1)×2ms。单个2ms点为接触保持约束违反，不写成持续跌倒；统计没有更改原拒收阈值。

## 两张全结果图

SciPilot先对全部计划结果进行类型、缺失率、分组与分布剖析，再采用逐观测分类cell和paired dots，不画均值柱、p值或独立样本CI。8snapshot/4episode的health×branch是同态干预，不扩成120独立样本。图形7.16in IEEE双栏、600dpi PNG及PDF/SVG，冗余符号与灰度检查。

![所有health剂量及Type-I/II](figures/FIGURE1.png)

![全部故障capacity时序、首次违反、16决定与认可轨迹](figures/FIGURE2.png)

## 预算与一次交付验证

首次新数值动作 {budget['numerical_started_utc']}；数值墙钟 {budget['numerical_elapsed_s']:.3f}s。QP {budget['total_QP_calls']}/10000、返回 {budget['QP_returns']}、UNKNOWN {budget['unknown_native_returns']}；积分 {budget['total_physics_steps']}/100000；fit=0、新CAL=0。数值DEV重算0、结果导向retry0，固定批次没有重置预算。
direct状态 {r['direct']['statuses']}；完整输出分类 {r['direct']['outcomes']}；认可输出 {r['recognized']['outcomes']}。

必要纯测试一次9/9通过，无真实QP/积分/fit；只跑身份、机制fixture、冻结group指纹、B0/late/grid和小shard。一次当前路径saved-only readback：{r['readback']['observed_banks_read_once']} bank，完整网格 {r['readback']['complete_grids_verified']}；QP/returns/raw {r['readback']['qp_starts']}/{r['readback']['qp_returns']}/{r['readback']['raw_qp_shards']}；label容差1e-12，未调用新optimizer/step/fit。其问题清单：{r['readback']['issues']}。
汇总集合阶段出现一次 `decision=null` 读取错误，发生在任何轨迹读回前；按协议修复空metadata读取并只定点复查null/false fixture，随后执行了唯一实际readback。错误及修复记录在repairs/，IO修复1次，数值结果没有重算。
第二项集中IO修复为图形导出兼容：关闭SVG色条栅格化，并防止灰度辅助函数裁切覆盖最终PNG。首次失败/尺寸告警均保留，最终SCIPILOT_CHECK为PASS；TrueType descendant嵌入与PNG/PDF精确尺寸均单独确认。两项修复均未增加数值动作；当前源HEAD及index hash未变（SOURCE_READONLY_CHECK.json）。
当前源码/模型检出字节hash记录在RUNTIME_FREEZE及manifest，未冒称旧CRLF原始字节一致。完整命令、Git scoped diff、hash索引与source HEAD/index状态另存交付记录。提交后回执位于D的 .runtime/COMMIT_RECEIPT.json；仅本轮scope提交一次，不push。

## 研究交接边界

机制解释见 METHOD_MECHANISM_NOTE.md。本轮没有重新训练、补CAL、solver/rho/gain搜索或新增条件；旧STEP39及更早结果只读，不进入E3/RL/硬件，不访问“机器人运控算法”项目。若有限面板仍不足，只交接本批事实，不自动扩样。

## 协议状态行

```ini
{ini}
```
'''
    text_file(out / 'REPORT.md', report)
    text_file(out / 'HANDOFF.md', f'''# STEP40 研究交接

数值批次 {r['run']['status']}，一次readback {r['readback']['status']}。

{statuses}

136计划位、全部16决定、全部Type-I/II及两类在线收益配对、真实capacity/接触时间事实和完整raw账本均已保存；详见REPORT.md、STEP40_RESULT.json及逐branch lossless工件。
固定输入：4episode/8snapshot，40health context、120direct、最多16ACTUAL。fit=0、新CAL=0，冻结STEP39模型/CAL与全部group阈值指纹原样继承；6mm、20ms和物理/terminal条件未变。

只读取当前保存轨迹作统计与图形，不把partial、ABSTAIN、缺失当完整安全。各机制及在线收益分别要求2snapshot/2episode，不合并Type-I/II。timing-qualified子集与offline物理结果分开。

源commit {SOURCE_COMMIT}；工作目录 {OUTPUT_ROOT_D}；新分支 codex/step40-capacity-backup-recovery-20261010。提交号见D .runtime/COMMIT_RECEIPT.json，不push。
当前共同硬约束内凸组合可行性与后续可恢复性为两层问题，B不能因目标保守就假定未来安全。旧STEP39结论不改；E3、RL、硬件、历史复跑及禁区访问均未授权。
''')
    text_file(out / 'METHOD_MECHANISM_NOTE.md', '''# 当前可行与后续可恢复：两层机制

当两个当前witness共享同一线性约束A、上下界l/u时，z_gamma=gamma*z_C+(1-gamma)*z_B满足共同凸约束是当前单步可行性问题；本实现仍逐一检查原42维raw/sent hard rows及真实health容量。

实际1s接触保持、状态边界和固定terminal到达依赖真实MuJoCo推进、prehold、已施加命令、feedback memory及后续QP。当前可行不推出未来可恢复，保守目标B也不是普遍安全backup。Type-I与Type-II因此分别注册名义或backup实际违反后middle的恢复，而不是事后把失败B重新称安全fallback。

冻结Ridge/risk与经验CAL是有预算的输入筛选器，不是已证明CBF、安全证书或全局viability判据。health是同态真实干预；99%事件先于接触违反提供时序事实，但不能单凭相关性宣称饱和为因果中介。全部必要执行窗口≤20ms才可记timing-qualified机制，offline成功不等于硬件实时闭合。
''')
    anchors = [out / n for n in ('PROTOCOL_AND_MANIFEST.json', 'FROZEN_INPUTS.json', 'RUNTIME_FREEZE.json',
        'SCREEN_IDENTITY_START.json', 'SCREEN_IDENTITY_END.json', 'RUN_STARTED.json', 'RUN_FINISHED.json',
        'STEP40_LEDGER.jsonl', 'ATTEMPT_LEDGER.jsonl', 'CURRENT_RUN_READBACK.json', 'STEP40_RESULT.json',
        'ALL_PLANNED_RESULTS.json', 'ALL_GOVERNOR_DECISIONS.json', 'CAPACITY_EVENTS_FULL.json',
        'REPORT.md', 'HANDOFF.md', 'METHOD_MECHANISM_NOTE.md', 'tests/NECESSARY_TESTS.json')]
    anchors += [out / 'SOURCE_READONLY_CHECK.json', out / 'DELIVERY_COMMANDS.json', out / 'GIT_SCOPED_DIFF.txt']
    anchors += list((out / 'repairs').glob('*.json'))
    anchors += list(out.glob('*.csv'))
    anchors += list((out / 'figures').glob('*.json')) + [p for p in (out / 'figures').glob('FIGURE*') if p.suffix in ('.png', '.pdf', '.svg')]
    anchors += list((OUTPUT_ROOT_D / 'cavr_wbc/experiments').glob('step40*.py'))
    anchors += [OUTPUT_ROOT_D / 'tests/test_step40_protocol.py', OUTPUT_ROOT_D / 'configs/validation/STEP40_PROTOCOL.md']
    write(out / 'CURRENT_HASH_INDEX.json', {'scope': 'STEP40_ONLY',
        'anchors': {relative(p, OUTPUT_ROOT_D): sha(p) for p in anchors if p.exists()},
        'branch_result_sha256': {v['id']: sha(out / v['result_path']) for v in rows if v['result_exists']},
        'raw_QP_detailed_hashes': 'STEP40_LEDGER.jsonl RAW_QP_SAVED entries',
        'readonly_source_model_files': manifest['frozen_screen'].get('files'),
        'no_historical_full_tree_list': True})


if __name__ == '__main__':
    render()
