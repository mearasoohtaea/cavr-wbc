"""One dense fact bank and one control shard, raw solver data linked once."""
from copy import deepcopy
import numpy as np
from cavr_wbc.experiments.step40_io import *
from cavr_wbc.experiments.step26_features_storage import save_bank as fact_bank,load_bank as fact_load
from cavr_wbc.control.step34_margin import labels
from cavr_wbc.experiments.step29_sim import _json_safe
from cavr_wbc.experiments.step35_sprint import current_events
from cavr_wbc.evaluation.step23_actual import actual_reasons
def not_run(gamma,reason):return {'status':'NOT_RUN','gamma':gamma,'reason':{'reason':reason}}
def contact_statistics(branch):
    """Describe saved-grid violations; no changed threshold or new propagation."""
    dense=([branch.get('initial_fact')] if branch.get('initial_fact') else [])+branch.get('physics_trajectory',[])
    rows=[r for r in dense if not r.get('numerical_failure') and r.get('contacts')]
    names=sorted({k for r in rows for k in r['contacts']})
    output={}
    for name in names:
        observations=[(r['time_s'],r['contacts'][name]) for r in rows if name in r['contacts']]
        masks={
            'CONTACT_LOSS':[not c['present'] for _,c in observations],
            'NEGATIVE_NORMAL_FORCE':[c['normal_force_n']<0 for _,c in observations],
            'FRICTION_VIOLATION':[c['friction_margin_n']<0 for _,c in observations]}
        foot={}
        for reason,mask in masks.items():
            run=longest=0;last=None
            for (time,_),bad in zip(observations,mask):
                run=run+1 if bad and (last is None or abs(time-last-.002)<1e-9) else int(bad)
                longest=max(longest,run);last=time
            times=[t for (t,_),bad in zip(observations,mask) if bad]
            foot[reason]={'unqualified_points':sum(mask),'longest_consecutive_points':longest,
                'longest_grid_supported_duration_s':longest*.002,
                'longest_observed_point_span_s':max(0,longest-1)*.002,
                'first_s':min(times) if times else None,'last_s':max(times) if times else None}
        foot.update(min_normal_force_n=min(c['normal_force_n'] for _,c in observations),
            min_friction_margin_n=min(c['friction_margin_n'] for _,c in observations),
            min_contact_presence_margin=int(all(c['present'] for _,c in observations)))
        output[name]=foot
    return {'contacts':output,'grid_dt_s':.002,'constraint_thresholds_unchanged':True,
            'single_2ms_contact_loss_is_not_sustained_fall':True,'observed_state_points':len(rows)}
def capacity_series(branch,c):
    ix=c.get('faulted_actuator_index');rows=[]
    dense=([branch.get('initial_fact')] if branch.get('initial_fact') else [])+branch.get('physics_trajectory',[])
    first_failure=None
    for f in dense:
        if not f.get('numerical_failure'):
            reasons=actual_reasons(f)
            if reasons and first_failure is None:first_failure={'time_s':f['time_s'],'reasons':reasons}
    for r in branch['controls']:
        tau=r.get('tau_applied');cap=r.get('capacity_interface',{}).get('effective_capacity_nm')
        ratio=None if ix is None or tau is None or cap is None else abs(float(tau[ix]))/float(cap[ix])
        integ=r.get('integral_record') or {}
        rows.append({'slot':r['slot'],'time_s':r['slot']*.02,'actual_tau_capacity_ratio':ratio,
            'actual_99percent':ratio is not None and ratio>=.99,
            'antiwindup_frozen':bool(integ and not integ.get('updated',False)),
            'applied':tau is not None,'latency_ms':r.get('latency_ms')})
    activated=[r for r in rows if r['actual_99percent']]
    first=activated[0]['time_s'] if activated else None
    return {'fault_name':c.get('faulted_actuator_name'),'fault_index':ix,'health':c.get('faulted_health'),
        'control_series':rows,'first_actual_99percent_s':first,'actual_99percent_slots':len(activated),
        'first_dense_physical_failure':first_failure,
        'activation_precedes_first_failure':bool(first is not None and first_failure and first<first_failure['time_s']),
        'dense_contacts_and_margins_in_lossless_fact_bank':True,'causal_mediator_claim':False}
def save_branch(out,path,branch,c,packet,recognized=False):
    path.mkdir(parents=True,exist_ok=True)
    rec={k:branch.get(k) for k in ('status','reason','gamma','counts','progress02_04_m','progress0_04_m',
        'application_identity_pass','application_state_match','first_tau_matches_packet','backup_memory_restore','identity_error','staging_summary')}
    rec.update(observed=branch['status']!='NOT_RUN',model_authorized=bool(recognized and packet.get('selected_command_sent')),
        selected_command_sent=bool(recognized and packet.get('selected_command_sent')),
        first_packet_ready_ms=packet.get('command_ready_ms'),result_path=relative(path/'RESULT.json',out))
    if rec['observed']:
        # Avoid a duplicate full control bank inside the physical bank header.
        light={k:v for k,v in branch.items() if k not in ('solver_ledger','controls')}
        light['controls']=[];light['solver_ledger']=[]
        rec['artifact']=fact_bank(path/'actual.npz',light)
        controls=[]
        for r in branch['controls']:
            raw=r.get('raw_solver_result') or {}
            index=raw.get('step37_global_qp_index',raw.get('step35_global_qp_index'))
            slim={k:v for k,v in r.items() if k!='raw_solver_result'}
            slim['raw_solver_evidence']=None if index is None else f'raw_qp/QP{int(index):06d}.json'
            controls.append(slim)
        rec['controls_numeric']=save_numeric(path/'controls.json',{'controls':controls,'solver_ledger':branch['solver_ledger']})
        lab=labels(branch,_json_safe(c));rec['label']=lab
        first=branch['controls'][1]['capacity_interface'] if len(branch['controls'])>1 else {}
        rec['events']=current_events(branch,{'capacity_interface':first,
            'first_capacity_event':bool(len(first.get('sent_99_percent_active_indices',[])))})
        rec['capacity']=capacity_series(branch,c)
        rec['contact_statistics']=contact_statistics(branch)
        complete=bool(lab.get('complete') and lab.get('full_501_grid'))
        fb=[r.get('latency_ms') for r in branch['controls'] if r.get('slot',0)>1]
        rec.update(complete_501=complete,feedback_latencies_ms=fb,
            timing_qualified=bool(complete and packet.get('command_ready_ms',float('inf'))<=20 and len(fb)==48 and all(np.isfinite(v) and v<=20 for v in fb)),
            checkpoints=len(branch['checkpoints']))
    else:rec.update(label={},complete_501=False,timing_qualified=False)
    write(path/'RESULT.json',rec)
    if rec.get('identity_error'):raise ValueError('application scientific identity mismatch')
    if rec['status']=='FAILED_BUDGET':
        from cavr_wbc.experiments.step40_budget import SprintLimit
        raise SprintLimit('partial branch saved at cap')
    return rec
def load_branch(path):
    branch=fact_load(path/'actual.npz');control=load_numeric(path/'controls.json')
    branch.update(control);return branch
