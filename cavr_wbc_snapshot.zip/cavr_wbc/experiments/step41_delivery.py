"""Single current-run saved-only readback and paired endpoint aggregation."""
from collections import Counter
from datetime import datetime, timezone
import json
import numpy as np
from cavr_wbc.experiments.step41_io import *
from cavr_wbc.experiments.step41_inputs import plans, METHODS
from cavr_wbc.experiments.step41_storage import load_branch, contact_statistics
from cavr_wbc.experiments.step41_identity import fingerprint
from cavr_wbc.experiments.step39_delivery import flatten, counts, safe, physical, physical_terminal, outcome, csv_save
from cavr_wbc.control.step41_terminal_domain import ResidentDomain


def collect(out):
    rows,records,decisions,queries=[],{},[],[]
    contextpath=out/'TEST_CONTEXTS.json'
    contexts={c['context_id']:c for c in load_numeric(contextpath)} if contextpath.exists() else {}
    domain=ResidentDomain(read(out/'TERMINAL_CAL_DOMAIN.json'),sha(out/'TERMINAL_CAL_DOMAIN.json'))
    for p in plans('TEST'):
        folder=out/'TEST'/p['context_id']
        for name in ('MIDDLE','B','LEGACY_ACTUAL','DOMAIN_ACTUAL'):
            path=folder/(name.split('_')[0]+'/ACTUAL' if name.endswith('_ACTUAL') else 'DIRECT/'+name)/'RESULT.json'
            rec=read(path,{})
            row=flatten(p,name,rec,path,out)
            row.update(direction=p['direction'],displacement_m=p['displacement_m'],contact_statistics=rec.get('contact_statistics'))
            rows.append(row);records[row['id']]=rec
        for method in METHODS:
            path=folder/method/'DECISION.json'
            packet=load_numeric(path) if path.exists() else {}
            query=[]
            for gamma in (.5,0.):
                entry=packet.get('actions',{}).get(str(gamma)) or {}
                old=entry.get('decision') or {}; numeric=old.get('numeric') or {}
                observed=entry.get('features28') is not None
                support=entry.get('terminal_domain')
                if method=='LEGACY' and observed:
                    support=domain.check(entry['features28'],entry['action'],packet['context_used'])
                qr=dict(context_id=p['context_id'],snapshot_id=p['snapshot_id'],episode=p['episode'],
                    method=method,gamma=gamma,observed_causal_query=observed,
                    evaluation_status=entry.get('evaluation_status','NOT_RUN'),
                    accepted=old.get('accepted'),legacy_same_candidate_accepted=entry.get('legacy_accepted_same_candidate',old.get('accepted')),
                    U_D_m=numeric.get('U_D'),U_T=numeric.get('U_T'),terminal_domain=support,
                    domain_counted_in_online_window=method=='DOMAIN' and support is not None,
                    legacy_domain_is_saved_only_diagnostic=method=='LEGACY',
                    complete_at_ms=entry.get('complete_at_ms'),
                    gates={k:numeric.get(k) for k in ('finite_input','pose_gate','support_gate','distance_gate','calibration_gate','physical_risk_gate') if k in numeric})
                queries.append(qr);query.append(qr)
            R=next(r for r in rows if r['id']==p['context_id']+':'+method+'_ACTUAL')
            chosen=next((q for q in query if q['gamma']==packet.get('selected_gamma')),None)
            decisions.append(dict(context_id=p['context_id'],snapshot_id=p['snapshot_id'],episode=p['episode'],
                method=method,condition=p['health_kind'],fault_leg=p['fault_leg'],direction=p['direction'],
                displacement_m=p['displacement_m'],eligible=bool(contexts.get(p['context_id'],{}).get('eligible')),
                decision_exists=path.exists(),decision_path=relative(path,out),decision_sha256=sha(path) if path.exists() else None,
                status=packet.get('status','NOT_RUN'),command_ready_ms=packet.get('command_ready_ms'),
                selected_gamma=packet.get('selected_gamma'),selected_command_sent=bool(packet.get('selected_command_sent')),
                overall_deadline_failure=bool(packet.get('overall_deadline_failure')),complete_actual=R['complete_501'],
                safe_actual_6mm=safe(R),physical_pass=R['physical_pass'],terminal_pass=R['terminal_pass'],
                D_m=R['D_m'],terminal_Y=R['terminal_Y'],actual_outcome=outcome(R),
                actual_partial=bool(R['observed'] and not R['complete_501']),timing_qualified_actual=R['timing_qualified'],
                max_feedback_latency_ms=R['max_feedback_latency_ms'],selected_query=chosen,queries=query))
    return rows,records,contexts,decisions,queries


def across(rows):
    qualified=[r for r in rows if r['qualified']]
    ns=len({r['snapshot_id'] for r in qualified}); ne=len({r['episode'] for r in qualified})
    return dict(status='OBSERVED_ACROSS_EPISODES' if ns>=2 and ne>=2 else 'NOT_ESTABLISHED',
        contexts=len(qualified),physical_snapshots=ns,episodes=ne,
        context_ids=[r['context_id'] for r in qualified],pairs=rows)


def paired_endpoints(rows,decisions):
    by={r['id']:r for r in rows}; totals={}; method_pairs=[]
    for method in METHODS:
        ds=[d for d in decisions if d['method']==method]
        actual=[by[d['context_id']+':'+method+'_ACTUAL'] for d in ds]
        unsafe=sum(d['selected_command_sent'] and d['complete_actual'] and not d['safe_actual_6mm'] for d in ds)
        useful=[]; gains=[]; recoveries=[]
        for d,R in zip(ds,actual):
            B=by[d['context_id']+':B']
            middle=bool(d['selected_command_sent'] and d['selected_gamma']==.5 and safe(R) and R['timing_qualified'])
            gain=None if R['progress02_04_m'] is None or B['progress02_04_m'] is None else R['progress02_04_m']-B['progress02_04_m']
            identity={k:d[k] for k in ('context_id','snapshot_id','episode','condition','fault_leg','direction','displacement_m')}
            common=dict(**identity,method=method,recognized_middle_safe_timely=middle,
                recognized_actual_id=R['id'],matched_direct_B_id=B['id'],
                same_source_not_same_packet=True,progress_gain_m=gain,
                B_complete=B['complete_501'],B_safe=safe(B),B_physical_pass=B['physical_pass'],
                B_timing_qualified=B['timing_qualified'],B_capacity99_precedes_failure=B['capacity_precedes_failure'],
                actual_partial=d['actual_partial'],selected=d['selected_command_sent'])
            useful.append({**common,'qualified':middle})
            gains.append({**common,'qualified':bool(middle and safe(B) and gain is not None and gain>0)})
            recoveries.append({**common,'qualified':bool(middle and B['complete_501'] and B['physical_pass'] is False)})
        endpoints={name:across(pairs) for name,pairs in
            (('useful_middle_execution',useful),('safe_B_progress',gains),('failed_B_recovery',recoveries))}
        if unsafe:
            for value in endpoints.values():value['status']='FAIL_COMPLETE_ERROR_ACCEPT'
        totals[method]=dict(planned=16,saved=sum(d['decision_exists'] for d in ds),eligible=sum(d['eligible'] for d in ds),
            recognized=sum(d['selected_command_sent'] for d in ds),ABSTAIN=sum(d['status']=='ABSTAIN' for d in ds),
            late=sum(d['overall_deadline_failure'] for d in ds),
            gamma_counts=dict(Counter(str(d['selected_gamma']) for d in ds if d['selected_command_sent'])),
            complete=sum(d['complete_actual'] for d in ds),physical=sum(physical(r) for r in actual),
            terminal=sum(r['complete_501'] and bool(r['terminal_pass']) for r in actual),
            local=sum(r['complete_501'] and r['D_m'] is not None and r['D_m']<=.006 for r in actual),
            safe=sum(safe(r) for r in actual),partial=sum(d['actual_partial'] for d in ds),
            complete_error_accepts=unsafe,zero_complete_error_target='FAIL' if unsafe else
                'FINITE_ZERO_COMPLETE_ERRORS' if any(d['complete_actual'] for d in ds) else 'NO_ACTUAL_EVIDENCE',
            all_abstain_or_B=not any(d['selected_command_sent'] and d['selected_gamma']==.5 for d in ds),endpoints=endpoints)
    for p in plans('TEST'):
        ds={m:next(d for d in decisions if d['context_id']==p['context_id'] and d['method']==m) for m in METHODS}
        L,D=ds['LEGACY'],ds['DOMAIN']
        qL,qD=L['selected_query'] or {},D['selected_query'] or {}
        method_pairs.append(dict(context_id=p['context_id'],snapshot_id=p['snapshot_id'],episode=p['episode'],
            condition=p['health_kind'],direction=p['direction'],LEGACY=L,DOMAIN=D,
            same_source_not_same_packet=True,
            coverage_cost_domain_abstains_legacy_complete_safe=bool(not D['selected_command_sent'] and L['selected_command_sent'] and L['safe_actual_6mm']),
            DOMAIN_unapplied_true_safety='UNKNOWN' if not D['selected_command_sent'] else 'MEASURED',
            domain_actual_set_subset_of_legacy_not_claimed=True))
    return dict(methods=totals,method_pairs=method_pairs,
        coverage_cost_positions=sum(p['coverage_cost_domain_abstains_legacy_complete_safe'] for p in method_pairs),
        legacy_error_reduction_claim_allowed=bool(totals['LEGACY']['complete_error_accepts']>0 and
            totals['DOMAIN']['complete_error_accepts']<totals['LEGACY']['complete_error_accepts']),
        formal_safety_or_population_error_probability_claim=False,new_Type_II_intervention_claim=False)

def readback(out, rows, records, contexts, decisions):
    from cavr_wbc.control.step34_margin import labels
    from cavr_wbc.experiments.step29_sim import _json_safe
    issues, loaded, grids, capacity = [], 0, 0, []
    source_identities = {}
    for c in contexts.values():
        if 'state' not in c:
            continue
        digest = fingerprint({key: c.get(key) for key in ('state', 'current_reference', 'source_external_reference',
            'nominal_q_init', 'nominal_d_m', 'nominal_b_used', 'backup_anchor_q_init', 'previous_command_identity')})
        previous = source_identities.setdefault(c['snapshot_id'], digest)
        if previous != digest:
            issues.append(c['context_id'] + ':same-state intervention source mismatch')
        health = np.ones(len(c['health_vector']))
        if c['faulted_actuator_index'] is not None:
            health[c['faulted_actuator_index']] = c['faulted_health']
        if not np.array_equal(health, c['health_vector']):
            issues.append(c['context_id'] + ':health mapping')
    for row in rows:
        if not row['observed']:
            continue
        rec = records[row['id']]
        directory = (out / row['result_path']).parent
        if sha(directory / 'actual.npz') != rec['artifact']['sha256']:
            issues.append(row['id'] + ':fact hash')
        for ext, key in (('json', 'json_sha256'), ('npz', 'npz_sha256')):
            if sha(directory / ('controls.' + ext)) != rec['controls_numeric'][key]:
                issues.append(row['id'] + ':control hash')
        branch = load_branch(directory)
        context = contexts[row['context_id']]
        lab = labels(branch, _json_safe(context))
        for key in ('complete', 'full_501_grid', 'original_physical', 'original_terminal', 'observed_original_physical_failure'):
            if lab.get(key) != rec['label'].get(key):
                issues.append(row['id'] + ':label ' + key)
        for key in ('D_m', 'Y'):
            a, b = lab.get(key), rec['label'].get(key)
            if (a is None) != (b is None) or (a is not None and not np.allclose(a, b, rtol=0, atol=1e-12, equal_nan=True)):
                issues.append(row['id'] + ':numeric label ' + key)
        if contact_statistics(branch) != rec['contact_statistics']:
            issues.append(row['id'] + ':contact descriptive facts')
        if not np.array_equal(branch['health_vector'], context['health_vector']):
            issues.append(row['id'] + ':plant/control health')
        if row['complete_501']:
            grids += 1
            if branch['counts']['physical_steps'] != 500 or len(branch['physics_trajectory']) + 1 != 501 or len(branch['checkpoints']) != 21:
                issues.append(row['id'] + ':500/501/21 time grid')
        ix = context.get('faulted_actuator_index')
        for r in branch['controls']:
            interface = r.get('capacity_interface') or {}
            tau, cap = r.get('tau_applied'), interface.get('effective_capacity_nm')
            raw, sent = interface.get('tau_raw'), interface.get('tau_sent')
            applied = tau is not None
            record = {'id': row['id'], 'context_id': row['context_id'], 'branch': row['branch'],
                'snapshot_id': row['snapshot_id'], 'episode': row['episode'], 'condition': row['condition'],
                'slot': r['slot'], 'time_s': r['slot'] * .02,
                'stage': 'PREHOLD' if r['slot'] == 0 else 'FIRST_ACTION' if r['slot'] == 1 else 'FEEDBACK',
                'actual_applied': applied, 'fault_name': context.get('faulted_actuator_name'),
                'actual_fault_tau_nm': None if ix is None or not applied else float(tau[ix]),
                'effective_fault_capacity_nm': None if ix is None or cap is None else float(cap[ix]),
                'actual_tau_capacity_ratio': None if ix is None or not applied or cap is None else abs(float(tau[ix])) / float(cap[ix]),
                'candidate_fault_tau_raw_nm': None if ix is None or raw is None else float(raw[ix]),
                'candidate_fault_tau_sent_nm': None if ix is None or sent is None else float(sent[ix]),
                'fault_clipped': None if ix is None or raw is None or sent is None else bool(raw[ix] != sent[ix]),
                'antiwindup_frozen': bool(r.get('integral_record') and not r['integral_record'].get('updated', False)),
                'latency_ms': r.get('latency_ms')}
            record['actual_99percent'] = bool(record['actual_tau_capacity_ratio'] is not None and record['actual_tau_capacity_ratio'] >= .99)
            capacity.append(record)
        loaded += 1
    events = [json.loads(line) for line in (out / 'STEP41_LEDGER.jsonl').read_text(encoding='utf-8').splitlines()]
    starts = [e for e in events if e['event'] == 'QP_START']
    returns = [e for e in events if e['event'] == 'QP_RETURN']
    raw = [e for e in events if e['event'] == 'RAW_QP_SAVED']
    ix = lambda a: sorted(e['global_qp_index'] for e in a)
    if ix(starts) != ix(returns) or ix(starts) != ix(raw) or ix(starts) != list(range(1, len(starts) + 1)):
        issues.append('QP START/RETURN/raw identity')
    for e in raw:
        path = out / e['path']
        if sha(path) != e['json_sha256'] or sha(path.with_suffix('.npz')) != e['npz_sha256']:
            issues.append(e['path'] + ':raw hash')
    reservations = [e for e in events if e['event'] == 'PREFIX_NATIVE_START']
    completed = [e for e in events if e['event'] == 'PREFIX_NATIVE_RETURN']
    if sorted(e['reservation_id'] for e in reservations) != sorted(e['reservation_id'] for e in completed):
        issues.append('prediction reservations/returns')
    budget = read(out / 'RUN_FINISHED.json')['budget']
    if (budget['total_QP_calls'] != len(starts) or budget['QP_returns'] != len(returns)
            or budget['multioutput_estimator_fits'] or budget['physical_risk_head_fits']
            or budget['new_CAL_branches'] or budget['total_QP_calls'] > 6000 or budget['total_physics_steps'] > 60000):
        issues.append('cumulative counts/budgets/zero fit/CAL')
    checkpoint = read(out / 'SCREEN_IDENTITY_END.json')
    if not checkpoint['full_model_CAL_TRAIN_threshold_identity_unchanged']:
        issues.append('frozen screen groups/predictor/threshold identity')
    freeze = read(out / 'RUNTIME_FREEZE.json')
    for name, digest in {**freeze['runtime_sha256'], **freeze['model_checkout_bytes']}.items():
        if sha(OUTPUT_ROOT_D / name) != digest:
            issues.append(name + ':frozen checkout byte hash')
    manifest = read(out / 'PROTOCOL_AND_MANIFEST.json')
    if sha(NATIVE_DLL) != manifest['native_dll_sha256']:
        issues.append('native DLL hash')
    attempts = [json.loads(line) for line in (out / 'ATTEMPT_LEDGER.jsonl').read_text().splitlines()]
    for p in plans('TEST'):
        cid=p['context_id']
        for method in METHODS:
            d=next(row for row in decisions if row['context_id']==cid and row['method']==method)
            ev=next((e for e in attempts if e['event']=='DECISION_IMMUTABLE' and e['context_id']==cid and e.get('method')==method),None)
            if d['decision_exists'] and (ev is None or ev['decision_sha256']!=d['decision_sha256']):
                issues.append(cid+':'+method+':immutable decision')
        both=next((e for e in attempts if e['event']=='BOTH_DECISIONS_IMMUTABLE' and e['context_id']==cid),None)
        future=[i for i,e in enumerate(attempts) if e.get('context_id')==cid and e.get('kind') in ('RECOGNIZED_ACTUAL','TEST_DIRECT')]
        if both:
            expected=list(METHODS if p['ordinal']%2==0 else METHODS[::-1])
            if both['order']!=expected or (future and attempts.index(both)>=min(future)):
                issues.append(cid+':paired decision order')
            identities=both['owner_identities']
            if identities['LEGACY'] is not None and identities['LEGACY']==identities['DOMAIN']:
                issues.append(cid+':same resident owner across methods')
        elif future:
            issues.append(cid+':future before both decisions')
    if not checkpoint['terminal_domain_unchanged']:
        issues.append('terminal domain resident table hash')
    domain_table=read(out/'TERMINAL_CAL_DOMAIN.json')
    source_hashes={path:digest for record in domain_table['records'] for path,digest in record['source_hashes'].items()}
    for path,digest in source_hashes.items():
        if digest is not None and sha(Path(path))!=digest:
            issues.append(path+':CAL raw source changed')
    write(out / 'CAPACITY_EVENTS_FULL.json', capacity)
    csv_save(out / 'CAPACITY_EVENTS_FULL.csv', capacity)
    result = {'status': 'VERIFIED' if not issues else 'EVIDENCE_ERROR', 'issues': issues,
        'observed_banks_read_once': loaded, 'complete_grids_verified': grids,
        'qp_starts': len(starts), 'qp_returns': len(returns), 'raw_qp_shards': len(raw),
        'unknown_qp': len(starts) - len(returns), 'source_snapshot_fingerprints': source_identities,
        'full_frozen_screen_identity_unchanged': checkpoint['full_model_CAL_TRAIN_threshold_identity_unchanged'],
        'label_tolerance': 1e-12, 'new_optimizer_calls': 0, 'new_physics_steps': 0,
        'new_fits': 0, 'scope': 'STEP41_CURRENT_RUN_ONLY', 'timestamp_utc': datetime.now(timezone.utc).isoformat()}
    write(out / 'CURRENT_RUN_READBACK.json', result)
    return result


def summarize(out=output()):
    if not (out/'RUN_FINISHED.json').exists():
        raise RuntimeError('numerical process must finish before saved-only delivery')
    if (out/'CURRENT_RUN_READBACK.json').exists() or (out/'STEP41_RESULT.json').exists():
        raise FileExistsError('one current-path readback only')
    rows,records,contexts,decisions,queries=collect(out)
    evidence=readback(out,rows,records,contexts,decisions)
    endpoints=paired_endpoints(rows,decisions)
    primary=endpoints['methods']['DOMAIN']
    useful=primary['endpoints']['useful_middle_execution']['status']
    complete_run=read(out/'RUN_FINISHED.json')['status']=='COMPLETED'
    result=dict(schema='STEP41_SAVED_ONLY_RESULT_V1',run_id=out.name,
        run=read(out/'RUN_FINISHED.json'),readback=evidence,
        task_execution_status='COMPLETE' if complete_run and evidence['status']=='VERIFIED' else 'INCOMPLETE',
        repair_endpoint_status='OBSERVED_USEFUL_ZERO_COMPLETE_ERRORS' if useful=='OBSERVED_ACROSS_EPISODES' else
            'FAIL_COMPLETE_ERROR_ACCEPT' if primary['complete_error_accepts'] else 'NOT_ESTABLISHED',
        direct_middle_B=counts([r for r in rows if not r['branch'].endswith('_ACTUAL')]),
        actual_by_method={m:counts([r for r in rows if r['branch']==m+'_ACTUAL']) for m in METHODS},
        endpoints=endpoints,methods=endpoints['methods'],planned_positions=64,
        method_decisions_planned=32,method_decisions_saved=sum(d['decision_exists'] for d in decisions),
        physical_snapshots_planned=8,reference_episodes_planned=4,health_contexts_planned=16,
        terminal_domain_sha256=sha(out/'TERMINAL_CAL_DOMAIN.json'),
        old_model_identity=read(out/'SCREEN_IDENTITY_END.json'),
        implementation_IO_repairs=len(list((out/'repairs').glob('IMPLEMENTATION_REPAIR_*.json'))),
        numerical_launches=1,result_based_retries=0,new_fits=0,new_CAL=0,
        historical_results_unchanged=True,E3_RL_hardware_authorized=False)
    write(out/'ALL_PLANNED_RESULTS.json',rows);csv_save(out/'ALL_BRANCH_RESULTS.csv',rows)
    write(out/'ALL_METHOD_DECISIONS.json',decisions)
    csv_save(out/'METHOD_DECISIONS.csv',[{k:v for k,v in d.items() if k not in ('queries','selected_query')} for d in decisions])
    write(out/'ALL_CAUSAL_QUERIES.json',queries)
    write(out/'SAME_SOURCE_METHOD_PAIRS.json',endpoints['method_pairs'])
    for m in METHODS:
        for name,endpoint in endpoints['methods'][m]['endpoints'].items():
            csv_save(out/(m+'_'+name+'_PAIRS.csv'),endpoint['pairs'])
    write(out/'STEP41_RESULT.json',result)
    print(json.dumps({k:result[k] for k in ('task_execution_status','repair_endpoint_status','direct_middle_B','actual_by_method','method_decisions_saved','readback')},ensure_ascii=False))
    print({m:{k:v for k,v in value.items() if k!='endpoints'} for m,value in result['methods'].items()})
    return result


if __name__=='__main__':summarize()
