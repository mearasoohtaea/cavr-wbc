"""Saved-only SciPilot figures: all paired decisions, queries and executions."""
from pathlib import Path
import sys
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
from PIL import Image
from cavr_wbc.experiments.step41_io import output, read, write, sha, load_numeric
from cavr_wbc.control.step41_terminal_domain import ResidentDomain

SKILL=Path('C:/Users/ZhuanZ（无密码）/.codex/skills/scipilot-figure/scripts')
sys.path.insert(0,str(SKILL))
from setup_style import setup_style
from profile_data import profile_data
from visual_qa import audit_layout, render_preview
from export_figure import export_figure
from check_figure import check_figure

COL={'LEGACY':'#0072B2','DOMAIN':'#009E73','B':'#555555','error':'#D55E00'}
MARK={'LEGACY':'o','DOMAIN':'s','B':'x'}

def verify_exported_fonts():
    """Resolve Type0 descendant embedding; generic checker misses this level."""
    from pypdf import PdfReader
    home=output()/'figures';result={}
    for path in sorted(home.glob('FIG41_*.pdf')):
        fonts=[]
        for page in PdfReader(str(path)).pages:
            for name,ref in page['/Resources']['/Font'].items():
                font=ref.get_object()
                children=font.get('/DescendantFonts')
                descs=[x.get_object() for x in children] if children else [font]
                embedded=[]
                for child in descs:
                    descriptor=child.get('/FontDescriptor')
                    descriptor=descriptor.get_object() if descriptor else {}
                    embedded.append(any(k in descriptor for k in ('/FontFile','/FontFile2','/FontFile3')))
                fonts.append(dict(resource=str(name),base_font=str(font.get('/BaseFont')),subtype=str(font.get('/Subtype')),
                    descendants_embedded=embedded,type3=str(font.get('/Subtype'))=='/Type3'))
        result[path.name]=dict(fonts=fonts,all_embedded=all(all(f['descendants_embedded']) and not f['type3'] for f in fonts))
    write(home/'PDF_DESCENDANT_FONT_VERIFICATION.json',result)
    if not all(v['all_embedded'] for v in result.values()):raise RuntimeError('PDF font embedding')
    print('All PDF Type0 descendant FontFile2 streams embedded; no Type3 fonts.')

def finish(fig,home,name,size):
    fig.set_size_inches(*size)
    issues=audit_layout(fig)
    render_preview(fig,str(home/(name+'_preview.png')),dpi=180)
    if issues:
        write(home/(name+'_LAYOUT.json'),dict(issues=issues,exported=False))
        raise RuntimeError('fix figure layout before final export: '+str(issues))
    paths=export_figure(fig,str(home/name),formats=['pdf','svg','png'],size_inches=size,
        dpi=600,tight=False,grayscale_preview=False)
    with Image.open(home/(name+'.png')) as im:
        im.convert('L').save(home/(name+'_grayscale.png'),dpi=(600,600))
    checks={}
    for path in paths:
        found,info=check_figure(path,min_dpi=600,target_inches=size)
        checks[Path(path).name]=dict(issues=found,info=info)
    write(home/(name+'_LAYOUT.json'),dict(issues=issues,exported=True,format_checks=checks))
    plt.close(fig)

def separators(ax):
    for y in (3.5,7.5,11.5):ax.axhline(y,color='.82',lw=.5,zorder=0)

def figure_decisions(home,decisions,queries,cids):
    fig=plt.figure(figsize=(7.16,10.0))
    gs=fig.add_gridspec(3,3,height_ratios=[1.16,1,1],hspace=.30,wspace=.30)
    ax=fig.add_subplot(gs[0,:2]); lat=fig.add_subplot(gs[0,2])
    lookup={(d['context_id'],d['method']):d for d in decisions}
    for i,cid in enumerate(cids):
        for j,m in enumerate(('LEGACY','DOMAIN')):
            d=lookup[cid,m]
            if not d['selected_command_sent']:
                text='ABSTAIN' if d['status']=='ABSTAIN' else d['status']; color='.92'
            else:
                prefix='M' if d['selected_gamma']==.5 else 'B'
                result='PARTIAL' if d['actual_partial'] else 'SAFE' if d['safe_actual_6mm'] else 'PHYS' if d['physical_pass'] is False else 'TERM' if d['terminal_pass'] is False else 'LOCAL'
                text=prefix+' / '+result
                color='#D9EBDD' if result=='SAFE' else '#F2D3B9'
            ax.add_patch(Rectangle((j-.48,i-.46),.96,.92,facecolor=color,edgecolor='white',lw=.3))
            ax.text(j,i,text,ha='center',va='center',fontsize=8)
            lat.scatter(d['command_ready_ms'],i+(-.14 if m=='LEGACY' else .14),s=17,
                marker=MARK[m],color=COL[m],edgecolors='black',linewidths=.3)
    ax.set(xlim=(-.5,1.5),ylim=(15.6,-.6),xticks=[0,1],xticklabels=['LEGACY','DOMAIN'],
        yticks=range(16),yticklabels=[f'C{i+1:02d}' for i in range(16)])
    ax.set_title('a  All same-source method decisions',loc='left',fontweight='bold')
    ax.set_ylabel('Fixed context (8 snapshots / 4 episodes)')
    lat.set(ylim=(15.6,-.6),yticks=[],xlim=(0,22),xticks=[0,10,20],xlabel='Decision (ms)')
    lat.axvline(20,color='black',ls='--',lw=.7)
    lat.set_title('b  Full timer',loc='left',fontweight='bold')
    separators(lat);separators(ax)
    labels=['Current direction velocity\n(m/s)','Prefix-end direction velocity\n(m/s)','Max sent utilization\n(dimensionless)']
    qs={(q['context_id'],q['method'],q['gamma']):q for q in queries}
    table=read(home.parent/'TERMINAL_CAL_DOMAIN.json')
    for row,gamma in enumerate((.5,0.)):
        for col in range(3):
            a=fig.add_subplot(gs[row+1,col]); allvalues=[]
            for i,cid in enumerate(cids):
                matches=[qs[cid,m,gamma] for m in ('LEGACY','DOMAIN')]
                s=next((q['terminal_domain'] for q in matches if q['terminal_domain']),None)
                if s is None:
                    d=lookup[cid,'LEGACY']
                    key=f'{gamma}:thigh:{d["direction"]}:{d["fault_leg"]}:0.15'
                    s=table['strata'][key]
                if s:
                    lo,hi=s['lo'][col],s['hi'][col]
                    a.plot([lo,hi],[i,i],color='.70',lw=3,solid_capstyle='butt',zorder=1)
                    a.plot([lo,hi],[i,i],color='.45',lw=.5,marker='|',markersize=4,zorder=1)
                    allvalues.extend([lo,hi])
                for m,q in zip(('LEGACY','DOMAIN'),matches):
                    yy=i+(-.14 if m=='LEGACY' else .14)
                    s=q['terminal_domain']
                    if not q['observed_causal_query'] or not s:
                        a.text(.01,yy,'x',transform=a.get_yaxis_transform(),fontsize=7,color='.6',va='center')
                        continue
                    v=s['axes'][col];allvalues.append(v)
                    a.scatter(v,yy,s=13,marker=MARK[m],facecolors='none' if q.get('figure_only_unchecked_domain_diagnostic') else COL[m],edgecolors=COL[m] if q.get('figure_only_unchecked_domain_diagnostic') else 'black',linewidths=.45,zorder=3)
                    if not s['axis_pass'][col]:a.scatter(v,yy,s=32,marker='x',color=COL['error'],lw=.7,zorder=4)
            if allvalues:
                lo,hi=min(allvalues),max(allvalues);pad=max((hi-lo)*.15,1e-5)
                a.set_xlim(lo-pad,hi+pad)
            a.set(ylim=(15.6,-.6),yticks=range(16),xlabel=labels[col])
            a.set_yticklabels([f'C{i+1:02d}' for i in range(16)] if col==0 else [])
            a.tick_params(axis='x',labelsize=7)
            a.xaxis.set_major_locator(plt.MaxNLocator(3))
            a.set_title(f'{chr(99+row*3+col)}  '+('Middle' if gamma==.5 else 'Backup')+f' axis {col+1}',loc='left',fontweight='bold')
            separators(a)
    handles=[Line2D([],[],marker=MARK[m],color=COL[m],ls='',markersize=4,label=m) for m in ('LEGACY','DOMAIN')]
    handles += [Line2D([],[],color='.65',lw=3,label='Raw CAL min-max'),Line2D([],[],marker='x',color=COL['error'],ls='',label='Outside axis range')]
    fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.5,.018),ncol=4,frameon=False,fontsize=8)
    fig.text(.5,.008,'Left x = no causal input; open D = untimed diagnostic; LEGACY domain is diagnostic; partial = 0.',ha='center',fontsize=7)
    fig.subplots_adjust(left=.12,right=.98,bottom=.10,top=.965)
    finish(fig,home,'FIG41_1_DECISIONS_AND_DOMAIN',(7.16,10.0))

def figure_execution(home,decisions,rows,cids):
    by={r['id']:r for r in rows}; selected=[d for d in decisions if d['selected_command_sent']]
    n=len(selected); fig,axes=plt.subplots(2,2,figsize=(7.16,7.4))
    vel,pro,states,lat=axes.flat
    names=[]
    for i,d in enumerate(selected):
        cid,m=d['context_id'],d['method']; A=by[cid+':'+m+'_ACTUAL'];B=by[cid+':B']
        names.append(f'C{cids.index(cid)+1:02d} '+m[0]+(' M' if d['selected_gamma']==.5 else ' B'))
        for a,field,scale in ((vel,'terminal_Y',1),(pro,'progress02_04_m',1000)):
            va=abs(A[field][1]) if field=='terminal_Y' and A[field] else A[field]
            vb=abs(B[field][1]) if field=='terminal_Y' and B[field] else B[field]
            if va is not None and vb is not None:
                a.plot([vb*scale,va*scale],[i,i],color='.7',lw=.6)
                a.scatter(vb*scale,i,s=18,marker='x',color=COL['B'],lw=.7)
                a.scatter(va*scale,i,s=24,marker=MARK[m],color=COL[m],edgecolors='black',lw=.3)
            if not d['safe_actual_6mm'] and va is not None:
                a.scatter(va*scale,i,s=58,marker='x',color=COL['error'],lw=.9)
        for j,R in enumerate((A,B)):
            vals=[R['physical_pass'],R['terminal_pass'],None if R['D_m'] is None else R['D_m']<=.006]
            for k,v in enumerate(vals):
                x=j*3+k
                states.add_patch(Rectangle((x-.46,i-.46),.92,.92,facecolor='#D9EBDD' if v else '#F2D3B9',edgecolor='white',lw=.3))
                states.text(x,i,'Y' if v else 'N' if v is False else '?',ha='center',va='center',fontsize=8)
        lat.scatter(d['command_ready_ms'],i-.12,s=24,marker=MARK[m],color=COL[m],edgecolors='black',lw=.3)
        lat.scatter(d['max_feedback_latency_ms'],i+.12,s=20,marker=MARK[m],facecolors='none',edgecolors=COL[m],lw=.7)
        lat.scatter(B['max_feedback_latency_ms'],i,s=18,marker='x',color=COL['B'],lw=.7)
    for a in axes.flat:
        a.set(ylim=(n-.4,-.6),yticks=range(n),yticklabels=names)
        a.grid(axis='y',color='.9',lw=.5,zorder=0)
    vel.set(xlabel='Absolute terminal base velocity (mm/s)',xlim=(0,1.25))
    vel.axvline(1,color='black',ls='--',lw=.7)
    pro.set(xlabel='Directed progress, 0.02-0.04 s (mm)',xlim=(1.6,2.15))
    states.set(xlim=(-.5,5.5),xticks=range(6),xticklabels=['A:P','A:T','A:L','B:P','B:T','B:L'])
    states.set_xlabel('Actual / matched direct B: physical, terminal, local')
    lat.set(xlabel='Full decision / feedback latency (ms)',xlim=(0,22),xticks=[0,10,20])
    lat.axvline(20,color='black',ls='--',lw=.7)
    for a,title in zip(axes.flat,('a  Terminal endpoint','b  Paired immediate progress','c  All observed outcomes','d  Online windows')):
        a.set_title(title,loc='left',fontweight='bold')
    handles=[Line2D([],[],marker=MARK[m],color=COL[m],ls='',label=m+' actual / decision') for m in ('LEGACY','DOMAIN')]
    handles += [Line2D([],[],marker='x',color=COL['B'],ls='',label='Matched direct B'),
        Line2D([],[],marker='o',mfc='none',color='black',ls='',label='Actual feedback max'),
        Line2D([],[],marker='x',color=COL['error'],ls='',label='Complete error accept')]
    fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.5,.036),ncol=2,frameon=False,fontsize=8)
    fig.text(.5,.012,'12 recognized method executions; same-source pairing, not extra independent samples. Direct B is offline.',ha='center',fontsize=7)
    fig.subplots_adjust(left=.14,right=.98,top=.945,bottom=.18,wspace=.48,hspace=.34)
    finish(fig,home,'FIG41_2_ALL_RECOGNIZED_PAIRS',(7.16,7.4))

def main():
    out=output();home=out/'figures';home.mkdir(exist_ok=True)
    setup=setup_style(journal='ieee',lang='en',constrained_layout=False)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.labelsize':8,'axes.titlesize':9,'xtick.labelsize':8,'ytick.labelsize':8,'legend.fontsize':8})
    ds=read(out/'ALL_METHOD_DECISIONS.json');qs=read(out/'ALL_CAUSAL_QUERIES.json');rs=read(out/'ALL_PLANNED_RESULTS.json')
    domain=ResidentDomain(read(out/'TERMINAL_CAL_DOMAIN.json'),sha(out/'TERMINAL_CAL_DOMAIN.json'))
    packets={}
    for q in qs:
        if q['observed_causal_query'] and q['terminal_domain'] is None:
            key=(q['context_id'],q['method'])
            if key not in packets:packets[key]=load_numeric(out/'TEST'/key[0]/key[1]/'DECISION.json')
            packet=packets[key];entry=packet['actions'][str(q['gamma'])]
            q['terminal_domain']=domain.check(entry['features28'],entry['action'],packet['context_used'])
            q['figure_only_unchecked_domain_diagnostic']=True
    write(home/'FIGURE_QUERY_DATA.json',qs)
    cids=list(dict.fromkeys(d['context_id'] for d in ds))
    profile=profile_data(pd.DataFrame([{k:d[k] for k in ('context_id','snapshot_id','episode','method','selected_gamma','command_ready_ms','complete_actual','safe_actual_6mm','physical_pass','terminal_pass','D_m','max_feedback_latency_ms')} for d in ds]),group_cols=['method'])
    write(home/'DATA_PROFILE.json',profile)
    write(home/'FIGURE_DESIGN.json',dict(style=setup,independent_units=dict(physical_snapshots=8,episodes=4),
        no_CI_pvalues_or_synthetic_replication=True,figures=['all 32 method decisions and all 64 planned causal query positions against raw stratum intervals','all 12 recognized executions against their same-source direct B'],
        input_sha256={n:sha(out/n) for n in ('ALL_METHOD_DECISIONS.json','ALL_CAUSAL_QUERIES.json','ALL_PLANNED_RESULTS.json')},
        context_keys={f'C{i+1:02d}':c for i,c in enumerate(cids)}))
    figure_decisions(home,ds,qs,cids);figure_execution(home,ds,rs,cids)
    print('Saved-only figures complete; no QP, propagation, fit or CAL generation.')

if __name__=='__main__':
    if '--verify-exported-fonts' in sys.argv:verify_exported_fonts()
    else:main()
