"""Read-only full predictor, CAL/TRAIN group and threshold fingerprints."""
import hashlib
import json
import numpy as np
from cavr_wbc.control import step39_margin as margin
from cavr_wbc.experiments.step41_io import MODEL_NPZ, SOURCE39, NATIVE_DLL, read, sha


def fingerprint(value):
    def pack(item):
        if isinstance(item, np.ndarray):
            a = np.ascontiguousarray(item)
            return {'dtype': str(a.dtype), 'shape': list(a.shape),
                    'sha256': hashlib.sha256(a.tobytes()).hexdigest()}
        if isinstance(item, dict):
            return {k: pack(v) for k, v in sorted(item.items()) if not k.startswith('_')}
        if isinstance(item, (tuple, list)):
            return [pack(v) for v in item]
        if isinstance(item, np.generic):
            return item.item()
        return item
    encoded = json.dumps(pack(value), sort_keys=True, separators=(',', ':'), allow_nan=False)
    return hashlib.sha256(encoded.encode('utf-8')).hexdigest()


def bundle_identity(bundle):
    return {'predictor': margin.identity(bundle), 'full_bundle': fingerprint(bundle),
            'groups': {key: fingerprint(group) for key, group in bundle['groups'].items()},
            'thresholds': fingerprint({k: getattr(margin, k) for k in
                ('K', 'MIN_CAL_SNAPSHOTS', 'MIN_CAL_EPISODES', 'D_SCALE_M',
                 'D_RESERVE_M', 'TERMINAL_RESERVE', 'POSE_PAD_RAD', 'DISTANCE_FLOOR')})}


def load_frozen():
    cal = read(SOURCE39 / 'CAL_FREEZE.json')
    expected = cal.get('asset')
    if not expected:
        return None, {'status': 'SOURCE_HEAD_UNAVAILABLE', 'new_fits': 0, 'new_CAL': 0}
    paths = {'npz': MODEL_NPZ, 'json': MODEL_NPZ.with_suffix('.json')}
    for kind, path in paths.items():
        if sha(path) != expected[kind + '_sha256']:
            raise ValueError('source frozen model file hash mismatch: ' + kind)
    if sha(NATIVE_DLL) != '8420ae87000deff3caecd5b9379056ad0961fbad8302231684641bf4b8717084':
        raise ValueError('specified STEP30 native DLL hash mismatch')
    bundle = margin.load_bundle(MODEL_NPZ)
    identity = bundle_identity(bundle)
    if identity['predictor'] != cal['predictor_identity_after']:
        raise ValueError('source predictor identity mismatch')
    return bundle, {'status': 'FROZEN_SOURCE_LOADED', 'identity': identity,
                    'files': {str(p): sha(p) for p in paths.values()},
                    'source_CAL_FREEZE_sha256': sha(SOURCE39 / 'CAL_FREEZE.json'),
                    'new_fits': 0, 'new_CAL': 0}

