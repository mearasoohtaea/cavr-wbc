"""Four fresh references and 16 same-state health interventions."""
from copy import deepcopy
import numpy as np
from cavr_wbc.experiments.step38_inputs import reference_scenario
from cavr_wbc.experiments.step35_sprint import add_previous_identity
BRANCHES=(('MIDDLE',.5),('B',0.))
OWNER_BRANCHES=(('C',1.),*BRANCHES)
METHODS=('LEGACY','DOMAIN')
TEST_KINDS=('FR_THIGH15','RR_THIGH15')
def episodes(split):
    if split != 'TEST': raise ValueError('STEP41 has no new CAL/TRAIN')
    targets=(.063,-.063,.066,-.066)
    ticks=(36,40)
    return [dict(episode_id=f'T41_{split}_{i}',direction=1 if d>0 else -1,
        displacement_m=d,snapshot_ticks=list(ticks)) for i,d in enumerate(targets)]
def plans(split):
    rows=[]
    for ep in episodes(split):
        for si,tick in enumerate(ep['snapshot_ticks']):
            snap=ep['episode_id']+f'_T{tick:03d}'
            for kind in TEST_KINDS:
                role='healthy' if kind=='HEALTHY' else 'thigh' if 'THIGH' in kind else 'calf'
                cid=snap+'_'+kind
                rows.append({**ep,'episode':ep['episode_id'],'source_tick':tick,'tick':tick,
                    'snapshot_index':si,'snapshot_id':snap,'source_snapshot':snap,'ordinal':len(rows),
                    'context_id':cid,'case_id':cid,'source_state_id':cid,'health_kind':kind,'role':role,
                    'fault_leg':'NONE' if role=='healthy' else kind[:2],
                    'health':1. if role=='healthy' else .30 if kind.endswith('30') else .15,
                    'split':split,'source_split':'STEP41_FRESH_'+split,'gap_m':.006,
                    'governor_planned':split=='TEST' and role!='healthy' and kind.endswith('15'),
                    'branch_order':['MIDDLE','B'] if split=='TEST' else ['MIDDLE','B']})
    return rows
def context_for(p,episode,mapping):
    snap=next((s for s in episode['snapshots'] if s['source_tick']==p['tick']),None)
    c=deepcopy(snap or {'eligible':False,'eligibility_reason':'REQUESTED_SNAPSHOT_NOT_PRODUCED'})
    c.update(deepcopy(p),backup_id='STEP41-'+p['context_id'],runtime_id=p['context_id'],
        group='STEP41_FIXED_'+p['split'],original_direction=p['direction'],
        front_or_rear='front' if p['fault_leg']=='FR' else 'rear')
    h=np.ones(len(mapping));name='NONE';ix=None
    if p['role']!='healthy':
        name=p['fault_leg']+'_'+p['role']
        ix=next(r['actuator_index'] for r in mapping if r['actuator_name']==name)
        h[ix]=p['health']
    c.update(health_vector=h,faulted_actuator_name=name,faulted_actuator_index=ix,faulted_health=p['health'],
        health_effective_from_sample_s=0.,plant_QP_feedback_health_identical=True,
        reference_complete=episode['status']=='COMPLETE',future_reference_completion_not_eligibility_gate=True)
    if snap:
        add_previous_identity(c,episode)
        c['previous_command_identity']['source']='NEW_STEP41_REFERENCE_CANDIDATE'
    else:c['previous_command_identity']={'available':False,'reason':'SNAPSHOT_NOT_PRODUCED'}
    return c

