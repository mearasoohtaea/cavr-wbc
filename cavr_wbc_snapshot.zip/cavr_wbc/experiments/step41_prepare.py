"""Once-only saved CAL table and exposed-development rejudgement; no solves."""
import numpy as np
from cavr_wbc.experiments.step41_io import *
from cavr_wbc.experiments.step39_inputs import plans as old_plans
from cavr_wbc.control.step41_terminal_domain import build_table, causal_axes, stratum_key, ResidentDomain


def prepare(out=output()):
    path = out / 'TERMINAL_CAL_DOMAIN.json'
    if path.exists():
        raise FileExistsError('terminal domain already built; no replacement')
    manifest = read(SOURCE39 / 'PROTOCOL_AND_MANIFEST.json')
    mapping = manifest['mapping']
    records = []
    for p in old_plans('CAL'):
        if p['role'] != 'thigh' or p['health'] != .15:
            continue
        folder = CAL_ROOT / p['context_id']
        pp = folder / 'PACKET.json'
        packet = load_numeric(pp) if pp.exists() else {}
        context = packet.get('sample_context') or {}
        if packet and packet['context_id'] != p['context_id']:
            raise ValueError('saved CAL packet context mismatch')
        for name, gamma in (('MIDDLE', .5), ('B', 0.)):
            prefixpath = folder / (name + '_PREFIX.json')
            saved = load_numeric(prefixpath) if prefixpath.exists() else {}
            record, entry = saved.get('record') or {}, saved.get('entry') or {}
            identity = 'CAL:' + p['context_id'] + ':' + str(gamma)
            if record and (record.get('id') != identity or record.get('gamma') != gamma or
                record.get('episode') != p['episode'] or record.get('source_snapshot') != p['snapshot_id'] or
                record.get('role') != 'thigh' or record.get('split') != 'CAL'):
                raise ValueError('saved CAL raw record identity mismatch')
            action = (packet.get('actions', {}).get(str(gamma)) or {}).get('action') or {}
            x = entry.get('features28')
            if x is not None and not np.array_equal(x, record.get('features28')):
                raise ValueError('CAL raw entry/record features mismatch')
            if entry.get('action') and action:
                for k in ('tau_sent', 'health_vector'):
                    if not np.array_equal(entry['action'][k], action[k]):
                        raise ValueError('CAL prefix action/packet mismatch')
            key = stratum_key(gamma, p['direction'], p['fault_leg'])
            axes, error = None, None
            try:
                observed_key, axes = causal_axes(x, action, context, mapping)
                if key != observed_key:
                    raise RuntimeError('CAL stratum/direction/packet mismatch')
            except (ValueError, KeyError, TypeError, IndexError) as exc:
                error = str(exc)
            lab = record.get('labels') or {}
            y = np.asarray(lab.get('Y'), dtype=float)
            complete = bool(lab.get('complete') and lab.get('full_501_grid') and
                y.shape == (5,) and np.isfinite(y).all() and
                lab.get('original_terminal') in (True, False))
            sources = [pp, pp.with_suffix('.npz'), prefixpath, prefixpath.with_suffix('.npz')]
            records.append(dict(id=identity, context_id=p['context_id'], stratum=key,
                snapshot=p['snapshot_id'], episode=p['episode'], gamma=gamma, direction=p['direction'],
                fault_leg=p['fault_leg'], health=.15, role='thigh', axes=axes, input_error=error,
                complete_terminal_evaluation=complete, original_physical=lab.get('original_physical'),
                original_terminal=lab.get('original_terminal'), source_status=lab.get('status', 'UNKNOWN'),
                source_hashes={str(source):sha(source) if source.exists() else None for source in sources},
                raw_feature_values=x, action_tau_sent=action.get('tau_sent'),
                action_effective_capacity=(action.get('capacity_interface') or {}).get('effective_capacity_nm')))
    if len(records) != 32:
        raise ValueError('32 planned thigh/.15 causal CAL records required')
    table = build_table(records, mapping)
    write(path, table)
    digest = sha(path)
    write(out / 'TERMINAL_CAL_DOMAIN_FREEZE.json', dict(path=relative(path, out), sha256=digest,
        planned_records=32, strata=8, constructed_once=True, new_QP_calls=0,
        new_prefixes=0, new_physics_steps=0, new_CAL=0, new_fits=0))
    resident = ResidentDomain(table, digest)
    exposed = read(SOURCE40 / 'ALL_PLANNED_RESULTS.json')
    outcomes = {r['context_id']:r for r in exposed if r['branch'] == 'RECOGNIZED'}
    rows = []
    for cid, old_result in outcomes.items():
        source = SOURCE40 / 'TEST' / cid / 'GOVERNOR_DECISION.json'
        old = load_numeric(source)
        for gamma in (.5, 0.):
            entry = old.get('actions', {}).get(str(gamma)) or {}
            action = entry.get('action') or {}
            queried = entry.get('features28') is not None
            check = resident.check(entry.get('features28'), action, old.get('context_used') or {}) if queried else None
            selected = old.get('selected_command_sent') and old.get('selected_gamma') == gamma
            rows.append(dict(context_id=cid, gamma=gamma, queried=queried, domain=check,
                original_accepted=(entry.get('decision') or {}).get('accepted'),
                original_actual_selected=bool(selected), original_actual_result=old_result if selected else None,
                dev_selected_candidate_retained=bool(selected and check and check['accepted']),
                old_final_choice_reconstructed=False, unqueried_B_final_choice='UNIDENTIFIED',
                new_actual_trajectory=False, exposed_development_not_new_TEST=True,
                source_hashes={str(source):sha(source),str(source.with_suffix('.npz')):sha(source.with_suffix('.npz'))}))
    write(out / 'DEVELOPMENT_REJUDGEMENT.json', rows)
    print({'strata':{k:{n:v[n] for n in ('planned','finite','complete','ready','lo','hi')} for k,v in table['strata'].items()},
           'domain_sha256':digest,'new_numerical_calls':0}, flush=True)


if __name__ == '__main__':
    prepare()
