"""Technical Chinese handoff from saved summaries; no further trajectory readback."""
from collections import Counter
from cavr_wbc.experiments.step41_io import output, read, write, OUTPUT_ROOT_D, SOURCE_COMMIT, sha
from cavr_wbc.experiments.step39_delivery import csv_save

def textfile(path,value):
    path.write_text(value,encoding='utf-8',newline='\n')

def table(headers,rows):
    return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+
        ['| '+' | '.join(str(x) for x in row)+' |' for row in rows])

def fmt(x,n=6):return '—' if x is None else f'{x:.{n}f}'

def main():
    out=output();r=read(out/'STEP41_RESULT.json');ds=read(out/'ALL_METHOD_DECISIONS.json')
    qs=read(out/'ALL_CAUSAL_QUERIES.json');rows=read(out/'ALL_PLANNED_RESULTS.json');by={x['id']:x for x in rows}
    domain=read(out/'TERMINAL_CAL_DOMAIN.json');dev=read(out/'DEVELOPMENT_REJUDGEMENT.json')
    finish=read(out/'RUN_FINISHED.json');source=read(out/'SOURCE_END_STATE.json')
    r['implementation_IO_repairs']=len(list((out/'repairs').glob('IMPLEMENTATION_REPAIR_*.json')))
    r['final_report_IO_metadata_update_without_numeric_recompute']=True
    write(out/'STEP41_RESULT.json',r)
    cids=list(dict.fromkeys(d['context_id'] for d in ds));methods=('LEGACY','DOMAIN')
    dm={(d['context_id'],d['method']):d for d in ds}
    errors=[x for x in rows if x['branch'].endswith('_ACTUAL') and x['complete_501'] and not (x['physical_pass'] and x['terminal_pass'] and x['D_m']<=.006)]
    rejected=[q for q in qs if q['method']=='DOMAIN' and q['terminal_domain'] and not q['terminal_domain']['accepted']]
    budget=finish['budget']
    latency={m:dict(decision_min_ms=min(d['command_ready_ms'] for d in ds if d['method']==m),
        decision_max_ms=max(d['command_ready_ms'] for d in ds if d['method']==m),
        feedback_max_ms=max(d['max_feedback_latency_ms'] for d in ds if d['method']==m and d['max_feedback_latency_ms'] is not None)) for m in methods}
    original_selected=[x for x in dev if x['original_actual_selected']]
    dev_summary=dict(planned_query_positions=len(dev),observed_queries=sum(x['queried'] for x in dev),
        old_selected=len(original_selected),retained=sum(x['dev_selected_candidate_retained'] for x in original_selected),
        rejected_old_selected=sum(not x['dev_selected_candidate_retained'] for x in original_selected),
        exposed_development_only=True,no_new_actual_trajectory=True,no_unqueried_B_final_choice=True)
    compact=dict(task_execution_status=r['task_execution_status'],repair_endpoint_status=r['repair_endpoint_status'],
        latency=latency,development=dev_summary,
        DOMAIN_observed_query_count=sum(q['observed_causal_query'] for q in qs if q['method']=='DOMAIN'),
        DOMAIN_gate_evaluated_count=sum(q['terminal_domain'] is not None for q in qs if q['method']=='DOMAIN'),
        DOMAIN_domain_rejects=len(rejected),DOMAIN_rejected_axes=dict(Counter(a for q in rejected for a in q['terminal_domain']['rejected_axes'])),
        per_action_evaluation_states={m:dict(Counter(q['evaluation_status'] for q in qs if q['method']==m)) for m in methods},
        complete_error_accepts=errors,coverage_cost_positions=r['endpoints']['coverage_cost_positions'],
        current_run_readback_not_repeated=True,implementation_IO_repairs=r['implementation_IO_repairs'],new_QP_calls=0,new_physics_steps=0)
    write(out/'REPORT_FACTS.json',compact)
    latency_path=out/'LATENCY_DECISIONS_AND_FEEDBACK_MAX.csv'
    if not latency_path.exists():
        csv_save(latency_path,[dict(context_id=d['context_id'],method=d['method'],
            decision_ms=d['command_ready_ms'],feedback_max_ms=d['max_feedback_latency_ms'],status=d['status'],
            overall_deadline_failure=d['overall_deadline_failure']) for d in ds])
    textfile(latency_path,latency_path.read_text(encoding='utf-8'))
    summary=table(['指标（每方法 16 planned）','LEGACY','DOMAIN'],[
        [name,r['methods']['LEGACY'][key],r['methods']['DOMAIN'][key]] for name,key in
        [('eligible','eligible'),('保存决定','saved'),('认可并实际发送','recognized'),('ABSTAIN','ABSTAIN'),('整窗超过 20 ms','late'),
         ('完整 501 状态','complete'),('physical 通过','physical'),('terminal 通过','terminal'),('6 mm local 通过','local'),
         ('physical + terminal + local 安全','safe'),('partial','partial'),('完整错误接受','complete_error_accepts')]])
    domain_table=table(['stratum γ:role:dir:leg:health','planned/finite/complete','snapshot/episode','ready','v_now [m/s]','v_prefix_end [m/s]','u_sent_max'],[
        [key,f'{v["planned"]}/{v["finite"]}/{v["complete"]}',f'{v["distinct_complete_snapshots"]}/{v["distinct_complete_episodes"]}',v['ready'],
         *[f'[{v["lo"][j]:.16g}, {v["hi"][j]:.16g}]' for j in range(3)]] for key,v in domain['strata'].items()])
    endpoint_table=table(['方法 / 描述性候选终点','contexts','physical snapshots','episodes','预注册终点状态'],[
        [m+' / '+name,e['contexts'],e['physical_snapshots'],e['episodes'],e['status']]
        for m in methods for name,e in r['methods'][m]['endpoints'].items()])
    def status(d):
        if not d['selected_command_sent']:return d['status']
        return ('M' if d['selected_gamma']==.5 else 'B')+'/'+d['actual_outcome']
    paired=table(['图键 / 完整 context','LEGACY / ms','DOMAIN / ms'],[
        [f'C{i+1:02d} / {cid}',status(dm[cid,'LEGACY'])+' / '+fmt(dm[cid,'LEGACY']['command_ready_ms'],3),
        status(dm[cid,'DOMAIN'])+' / '+fmt(dm[cid,'DOMAIN']['command_ready_ms'],3)] for i,cid in enumerate(cids)])
    useful=[p for p in r['methods']['DOMAIN']['endpoints']['useful_middle_execution']['pairs'] if p['qualified']]
    useful_table=table(['DOMAIN 完整安全 middle','末速度绝对值 [mm/s]','local D [mm]','.02–.04 进度 [mm]','matched B 是否安全','进度差 [mm]'],[
        [p['context_id'],fmt(abs(by[p['recognized_actual_id']]['terminal_Y'][1])),fmt(1000*by[p['recognized_actual_id']]['D_m']),
        fmt(1000*by[p['recognized_actual_id']]['progress02_04_m']),p['B_safe'],fmt(1000*p['progress_gain_m'])] for p in useful])
    rejected_table=table(['DOMAIN candidate','γ','拒绝轴','旧 U_D [mm]','旧 U_T,vx [mm/s]'],[
        [q['context_id'],q['gamma'],','.join(q['terminal_domain']['rejected_axes']),fmt(q['U_D_m']*1000 if q['U_D_m'] is not None else None),
         fmt(q['U_T'][1] if q['U_T'] is not None else None)] for q in rejected])
    protocol=(OUTPUT_ROOT_D/'configs/validation/STEP41_PROTOCOL.md').read_text(encoding='utf-8').split('~~~ini\n',1)[1].split('~~~',1)[0]
    statuses=protocol+f'''TASK_EXECUTION_STATUS = {r['task_execution_status']}
NUMERICAL_BATCH_STATUS = COMPLETED
CURRENT_RUN_READBACK = VERIFIED
METHOD_REPAIR_ENDPOINT = FAIL_COMPLETE_ERROR_ACCEPT
DOMAIN_ZERO_COMPLETE_ERRORS = FALSE
DOMAIN_SAFE_TIMELY_MIDDLE_CONTEXTS = 3
DOMAIN_SAFE_TIMELY_MIDDLE_SNAPSHOTS = 2
DOMAIN_SAFE_TIMELY_MIDDLE_EPISODES = 2
DOMAIN_RECOGNIZED = 5
DOMAIN_COMPLETE = 5
DOMAIN_SAFE = 4
DOMAIN_COMPLETE_ERROR_ACCEPTS = 1
DOMAIN_ABSTAIN = 11
DOMAIN_LATE = 0
DOMAIN_PARTIAL = 0
DOMAIN_USEFUL_EXECUTION_CRITERION_WITH_ZERO_ERRORS = FAIL
DOMAIN_SAFE_B_PROGRESS_CROSS_EPISODE = NOT_ESTABLISHED
DOMAIN_FAILED_B_RECOVERY_CROSS_EPISODE = NOT_ESTABLISHED
LEGACY_RECOGNIZED = 7
LEGACY_COMPLETE_ERROR_ACCEPTS = 2
COVERAGE_COST_POSITIONS = 1
NEW_REFERENCE_EPISODES_COMPLETE = 4
METHOD_DECISIONS_SAVED = 32
DIRECT_MIDDLE_B_COMPLETE = 32
RECOGNIZED_ACTUAL_COMPLETE = 12
ACTUAL_FULL_HORIZON_TRAJECTORIES = 44
NOT_RUN_ACTUAL_POSITIONS = 20
NEW_QP_CALLS_ACTUAL = 2808
NEW_PHYSICS_STEPS_ACTUAL = 27400
NUMERICAL_ELAPSED_SECONDS = {budget['numerical_elapsed_s']:.6f}
UNKNOWN_QP_RETURNS = 0
NUMERICAL_LAUNCHES = 1
IMPLEMENTATION_IO_REPAIRS_USED = {r['implementation_IO_repairs']}
CURRENT_BANK_READBACK_PASSES = 1
SCOPED_DIFF_COMMIT_CHECK_PASSES = 1
SOURCE_HEAD_INDEX_UNCHANGED = TRUE
FORMAL_SAFETY = NOT_CLAIMED
NEW_TYPE_II_CAPACITY_INTERVENTION_PROOF = NOT_CLAIMED
NEXT_EXPERIMENT = NOT_AUTHORIZED
PUSH = FALSE
'''
    textfile(out/'PROTOCOL_STATUS.ini',statuses)
    report=f'''# STEP41 终端 CAL 适用域与独立在线对照

任务执行：COMPLETE。方法修复终点：FAIL / REVISE（FAIL_COMPLETE_ERROR_ACCEPT）。固定批次及唯一当前路径读回完成；零完整错受目标未满足，不开启追加实验。

## 主要结果

DOMAIN 在 16 个 context 中认可 5 条完整轨迹，4 条满足原 physical、terminal 和 6 mm local 条件；其中 3 条为及时安全 middle，来自 2 个 physical snapshot、2 个 episode。它拒绝了本轮 LEGACY 的终端错受，但仍认可了一条路径接触失败的 B，因此不能把本轮称为零错误修复成功。全部普通失败保留，计划继续到末尾，未按结果重跑。

{summary}

LEGACY 的发送 γ 计数为 middle=5、B=2；DOMAIN 为 middle=3、B=2。4 条新 reference 均完成；8 个 snapshot、16 个 health context 均取得。64 个预冻结轨迹位中，32 条 direct middle/B 和 12 条认可 ACTUAL 完整，20 个未认可 ACTUAL 为 NOT_RUN，不是 partial，也不填成完整。direct 为 23 安全、3 physical fail、2 terminal fail、4 local-only fail；全部 32 条完整、窗口及时。

## 终端拒绝与剩余物理错受

`T41_TEST_1_T040_FR_THIGH15`：LEGACY 认可 middle，实测末速度 1.020273194718 mm/s（原阈值 1 mm/s），旧经验上界 0.999104139405 mm/s。DOMAIN 在自己的在线 per-action 循环拒绝 middle：prefix-end velocity 0.0734386376940 m/s 小于该组 0.0735758083702 m/s，max sent utilization 0.845261080127 大于该组 0.819631390583。B 的 prefix 也域外且旧 terminal 门失败，最终 ABSTAIN。不能给未施加 DOMAIN 的候选赋予 LEGACY 的实际标签。

`T41_TEST_2_T036_FR_THIGH15`：两个方法都认可自身 B0，DOMAIN 三轴 [0.130429807364411, 0.0629687718549764, 0.999971870604783] 在冻结范围与 epsilon 内。实测 0.048 s、RR 接触丢失，仅 1 个 2 ms 网格点；terminal 通过，local D=5.256337281949 mm。capacity99% 早于首次失败。它是完整路径 physical 错受，不描述为持续跌倒。新增终端输入域门未排除该路径失效，旧 physical-risk 门仍不能因此解释成硬安全保证。

DOMAIN 对已执行域检查的 candidate 有 {len(rejected)} 次域拒绝（candidate 不是独立样本）：

{rejected_table}

所有 query 的旧门、U_D/U_T、evaluation_status、域范围和未查询位见 ALL_CAUSAL_QUERIES.json 与原 DECISION JSON/NPZ。不得将 NOT_EVALUATED_BUDGET 记为域门拒绝。

## 保留用途与覆盖代价

{useful_table}

上述 middle 描述性用途覆盖 2 snapshot/2 episode，但总体零完整错受条件失败，所有主终点按预注册规则为 FAIL。safe-B 进度收益有 2 context，仅 1 snapshot/1 episode；failed-B 恢复有 1 context、1 snapshot/1 episode，匹配 B 的 capacity99% 早于失败。两类分别未建立跨 episode 收益，不拼接凑门。

{endpoint_table}

覆盖损失只有 `T41_TEST_1_T040_RR_THIGH15`：DOMAIN ABSTAIN，同 source LEGACY 完整安全。该 DOMAIN middle 已保存 causal features，却记录 NOT_EVALUATED_BUDGET，B 未评价；完整 command-ready 为 19.232400 ms。不能宣称这是域外拒绝，不能以读回诊断代替在线 gate，也不能给未施加候选贴安全标签。该位的安全 middle 只属于 LEGACY 的实际结果。

本有限批次实测完整错受为 LEGACY 2、DOMAIN 1，终端错受为 1、0；这是 8 snapshot/4 episode 的描述性同 source 对照，不估总体概率、不报显著性，不声称 DOMAIN 实际发送集合是 LEGACY 实际集合的子集。没有健康/.30的新配对轨迹，不形成新 Type-II 容量干预证明。STEP40 的原结论与原工件保持只读。

## 域表与来源

只从 STEP39 32 个计划 raw CAL 记录一次构建 8 组。每组 4 个有限 causal 输入，4 个具备完整终端评价的不同 snapshot、2 个 episode，全部 ready。不按成功标签筛选，无反标准化边界。三轴原 feature name/index 为 direction_vx_m_s/0、prefix_direction_vx20_m_s/17、全 12 通道 max sent/capacity 利用率/11；速度单位 m/s，利用率无量纲。零容量/缺失/nonfinite 不填 0。

{domain_table}

固定 epsilon=1e-12×max(1,abs(lo),abs(hi))。FR 正向 B 的窄 utilization 范围保持原边界；不加 .99/1 padding。resident 表 SHA256：`{r['terminal_domain_sha256']}`。CURRENT_RUN_READBACK 已检查 CAL 原 JSON/NPZ source hashes、完整模型及阈值身份不变。轴向盒是必要经验支持条件，不是联合分布覆盖证明。

一次旧 STEP40 exposed DEV 保存数据重判：32 个 query 计划位，{dev_summary['observed_queries']} 个已有 query；原实际认可 8 个，保留 5 个、拒绝 3 个（原 terminal fail 1、原安全 2）。不新生成旧轨迹，不补旧未查询 B 最终 choice，不将这些旧曝光记录计为新 TEST。

## 公平性与计时

两个方法共享 source state/health/task/previous command/anchor，各自独立 live resident owner、packet、B0。context ordinal 固定交替先后，两个不可改决定均在任何 ACTUAL/direct 前保存。gamma0 恢复自身 B0，middle 使用自身 witness；没有跨方法 native 缓存或控制历史拼接。direct 保留 C/MIDDLE/B 三 owner 键和真实 endpoint 求解，只传播 MIDDLE/B。

完整 timer 包括 application、endpoint、prefix、features、模型/原门/新门、metadata/selected/B0 拷贝，不重启。LEGACY 决定 {latency['LEGACY']['decision_min_ms']:.6f}–{latency['LEGACY']['decision_max_ms']:.6f} ms；DOMAIN {latency['DOMAIN']['decision_min_ms']:.6f}–{latency['DOMAIN']['decision_max_ms']:.6f} ms。实际 feedback 最大 LEGACY {latency['LEGACY']['feedback_max_ms']:.6f}、DOMAIN {latency['DOMAIN']['feedback_max_ms']:.6f} ms。本批次整窗 late=0；个别 candidate 因剩余内部预算未评价，保留该状态。迟到/无效先于施加停止的规则没有更改。

## 全部同 source 决定

{paired}

## 图表

SciPilot 先对全部决定作 DATA_PROFILE，再使用逐观测/配对图，颜色加圆/方/叉和 Y/N 冗余编码。图 1 展示所有 32 决定、64 个 candidate 计划位、三轴 raw CAL min/max 与查询位置、实际错误和 20 ms 窗口；未在线执行 domain 的有 causal input 的 DOMAIN query 仅为开符号诊断。无 causal input 用左侧叉，不作零值。图 2 展示全部 12 认可执行及匹配 direct B 的末速度、进度、physical/terminal/local 和完整窗口。每一个 health/method 重复都保留，但不当独立样本，无 CI/p 值。图 QA、600 dpi PNG、可编辑 SVG、字体嵌入 PDF 与灰度预览在 figures/。

![全部决定与适用域]({(out/'figures/FIG41_1_DECISIONS_AND_DOMAIN.png').as_posix()})

![全部认可与 B 配对]({(out/'figures/FIG41_2_ALL_RECOGNIZED_PAIRS.png').as_posix()})

## 执行、测试与身份

run_id：`{out.name}`；目录：`{OUTPUT_ROOT_D.as_posix()}`；分支：codex/step41-terminal-cal-domain-20261010。只读源 SHA：`{SOURCE_COMMIT}`。首个数值动作 {budget['numerical_started_utc']}；完成 {finish['finish_utc']}；累计 {budget['numerical_elapsed_s']:.6f} 秒，QP=2808/6000、return=2808、UNKNOWN=0，积分=27400/60000，fit=0、新 CAL=0。reference/startup/C/B/prediction/ACTUAL/direct 全计账。不是只计最终轨迹。

原模型 JSON `ce287eaa6f2324ea520637a94f1e3403de63a74e3698c127dc8e4a9961351f88`；NPZ `804ccb7e90264b23d27b89a544026dd618682fac1baa36909e6ec93b3dcc7bdb`；完整模型/CAL/TRAIN/阈值 bundle `07b0cdeba1acda6b655b533ce4140ec0204a3a4fcf5eb3f2121957a4a888d89f`。DLL 沿用、未编译安装；全部细分数组及组指纹在 SCREEN_IDENTITY_START/END.json。源 HEAD 不变、Git clean、index SHA `{source['source_index_sha256']}`，与初始相同。当前只读核查未修改历史工件，未访问禁区。

集中 pure fixture 只跑一次 11 项：10 pass、1 AST syntax error；数值前实施第 1 次实现修复（本轮上限 2），随后仅检查定点 fixture，保留一次 selector 定点失败及最终 pass。没有全套重跑、真实 QP/积分/fit。详见 tests/ 和 repairs/IMPLEMENTATION_REPAIR_01.json，不能把首轮写成 11/11 全过。最终 11 个逻辑 fixture 均通过原首轮或定点修复验证。

第 2 次 IO 修复仅处理衍生 CSV/SVG 的 CRLF/行末空白与 sparse Git 发布。保存前后 hash，不改决定、raw QP、轨迹、冻结数值源码、模型或预算。一次 scoped 提交周期首个格式检查 exit=2；格式修正后完成定点提交检查。冻结源码原有 EOF 空行只在该 Git 格式命令中忽略，保留原字节，不作为数值错误。没有第二次 bank 读回或新求解。

唯一当前路径读回 VERIFIED：44 个已生成 bank、44 个完整 500/501/21 网格，2808 个 start/return/raw shard 同序；控制/事实哈希、健康映射、dense 标签、两决定先后和 owner、冻结源码/模型/域身份均无问题。读回后只有保存数据报告和图表处理，0 新求解/积分。COMMANDS.json 记录命令；SCOPED_COMMIT_CHECK.json 保存一次当前范围 diff/staging 检查；本文件及工件所属 Git commit 为交付提交，实际 SHA 在最终消息及 .runtime/COMMIT_RECEIPT.json（忽略文件）。不 push。

## 全部协议与实测状态

```ini
{statuses}```
'''
    textfile(out/'REPORT.md',report)
    update='''# METHOD_UPDATE：终端经验界限定到原 causal CAL 输入域

原筛选器将冻结回归、CAL 残差与终端 reserve 组合成经验上界。STEP40 中略微外推的输入出现终端速度失覆盖；换用同组最大残差不能消除该已曝光错误。STEP41 新增三轴原 CAL 输入域检查：在每一候选的独立 prefix/features 后、同一完整在线 timer 内，与全部原门做 AND；middle 不适用时，在剩余预算内检查自身 B，否则 ABSTAIN。域表先冻结，不能按后续结果扩大。

新批次中，该门拒绝了 LEGACY 的终端速度错受，保留 3 条及时、完整安全 middle（2 snapshot/2 episode）和 1 条安全 B。它仍认可 1 条 B 路径接触单点失败。主零完整错受终点 FAIL，修复不能宣布成功。safe-B 进度与 failed-B 恢复都只在 1 episode 观察到，各自尚未建立跨 episode 收益；两类不合并。

机制含义：限定终端经验界的输入适用范围能阻止某些轻度外推的终端错误选择，且不必全弃权；它没有为完整备份路径的物理风险提供硬保证。三个边际区间不是联合分布支持证明，域内不等于安全。下一步研究需区分终端支持与路径接触风险，不由本轮自动扩展样本、修改门或执行新实验。

LEGACY 与 DOMAIN 各用独立 owner/packet，按同 source 而非同 packet 配对。当前错误计数 2 对 1 是有限描述性结果，不写总体错受概率、显著性、conformal/CBF/viability/硬件实时或新 Type-II 干预证明。全部决定、拒绝、保留安全 middle、B 错受及覆盖损失共同呈现；完整证据和状态见 REPORT.md。
'''
    textfile(out/'METHOD_UPDATE.md',update)
    handoff=f'''# STEP41 研究与工程交接

STEP41 已按唯一协议完成固定实验，执行状态 COMPLETE，主方法终点 FAIL_COMPLETE_ERROR_ACCEPT。不要自动重跑本轮、扩样、再训练/补 CAL 或进入 E3/RL/硬件。历史 STEP39/40 只读，禁区“机器人运控算法”保持隔离。

当前 D checkout：`{OUTPUT_ROOT_D.as_posix()}`；分支 `codex/step41-terminal-cal-domain-20261010`；只读继承提交 `{SOURCE_COMMIT}`。交付提交以此文件所属 Git commit 为准，不推送。输出 run_id `{out.name}`，后续只能在明确授权下创建新版本，不覆盖这些不可改决定与工件。

DOMAIN：16 planned/eligible，认可 5、完整 5、安全 4、错受 1、ABSTAIN 11、late 0、partial 0。3 个安全及时 middle 覆盖 2 snapshot/2 episode，但总体零错受失败。剩余错误为 C09 的 B：RR 在 .048 s 单个 2 ms 接触丢失，terminal/local 通过。终端错受 C07 仅存在 LEGACY，DOMAIN 拒绝；C08 是预算未评价的覆盖损失，不写成 domain reject。

入口与责任：step41_prepare 一次只读构建域和旧曝光 DEV 重判；step41_kernel 新域门；step41_sprint 唯一批次；step41_budget 全调用账本；step41_delivery 唯一 bank 读回及聚合（已消费，不再次执行）；step41_report/figures 只处理保存汇总。全部数值模块与 step39/40、模型、阈值未改。

证据导航：TERMINAL_CAL_DOMAIN(+FREEZE)、PROTOCOL_AND_MANIFEST、FROZEN_INPUTS、SCREEN_IDENTITY_START/END、RUNTIME_FREEZE；ATTEMPT_LEDGER 与 STEP41_LEDGER；REFERENCE/TEST 下 packet/decision/raw/bank/control 小 shard；ALL_PLANNED_RESULTS 64 位、ALL_METHOD_DECISIONS 32 位、ALL_CAUSAL_QUERIES 64 位；SAME_SOURCE_METHOD_PAIRS 与分离终点 CSV；CAPACITY_EVENTS_FULL；CURRENT_RUN_READBACK；STEP41_RESULT/REPORT_FACTS；REPORT/METHOD_UPDATE/PROTOCOL_STATUS；figures 与图键映射。

数值 1 launch、300.749611 s、2808 QP/return、27400 积分步、0 UNKNOWN、0 fit、0 CAL、2/2 实现/IO修复（第2次仅衍生文件格式和Git发布）。完成44条1 s轨迹、其余20个未认可 ACTUAL 为 NOT_RUN，4条reference完整。测试保留首轮10 pass/1 error、定点失败和最终pass，不重跑历史suite。源 HEAD/index 不变与 Git clean 的证据见 SOURCE_END_STATE.json。

当前 stop condition：交付提交后停止。现有数据可支持有限终端域拒收和保留用途描述，不支持零错受成功、域内保证或新 Type-II 容量干预结论。即使将来扩展方法也须新协议，不能以当前有限失败为理由调参或补跑已完成案例。
'''
    textfile(out/'HANDOFF.md',handoff)
    write(out/'COMMANDS.json',dict(runtime='E:/CAVR-WBC/_runtime_step30/python311/python.exe',cwd=OUTPUT_ROOT_D.as_posix(),
        commands=['python -B -X utf8 -m tests.test_step41_protocol','targeted test fixture after implementation repair (tests/TARGETED_REPAIR_01 and FINAL)',
        'python -B -X utf8 -m cavr_wbc.experiments.step41_prepare','python -B -X utf8 -m cavr_wbc.experiments.step41_launch',
        'python -B -X utf8 -m cavr_wbc.experiments.step41_delivery','python -B -X utf8 -m cavr_wbc.experiments.step41_figures (2 visual iterations; saved-only)',
        'python -B -X utf8 -m cavr_wbc.experiments.step41_figures --verify-exported-fonts',
        'python -B -X utf8 -m cavr_wbc.experiments.step41_report (saved-only report metadata update)',
        'git add --sparse at exact STEP41 scope / diff --cached --check (initial CRLF/EOF diagnostics, derived-format correction)',
        'git -c core.whitespace=-blank-at-eof diff --cached --check / staged scope review / commit'],
        real_optimizer_calls_from_reporting=0,real_propagation_from_reporting=0,current_trajectory_readback_count=1))
    print({k:v for k,v in compact.items() if k!='complete_error_accepts'})

if __name__=='__main__':main()
