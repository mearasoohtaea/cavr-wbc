"""One fixed capacity/backup batch; frozen STEP39 screen, zero fit and CAL."""
from copy import deepcopy
from datetime import datetime, timezone
import gc
import os
import traceback
import numpy as np
from cavr_wbc.experiments.step41_io import *
from cavr_wbc.experiments.step41_inputs import episodes, plans, context_for, BRANCHES, OWNER_BRANCHES, METHODS
from cavr_wbc.experiments.step41_budget import SprintBudget, SprintLimit
from cavr_wbc.experiments.step41_storage import save_branch, not_run
from cavr_wbc.experiments.step41_identity import load_frozen, bundle_identity
from cavr_wbc.experiments.step35_reference import reference_episode
from cavr_wbc.experiments.step28_sprint import home_context
from cavr_wbc.experiments import step17_formal_panel as frozen, step38_sim as sim
from cavr_wbc.control.step39_kernel import Kernel as LegacyKernel, direct_packet
from cavr_wbc.control.step41_kernel import Kernel as DomainKernel
from cavr_wbc.control.step41_terminal_domain import ResidentDomain
Kernel = LegacyKernel
from cavr_wbc.platforms.go2_mujoco import extract_actuator_audit, extract_healthy_torque_limits


def event(out, name, **values):
    append(out / 'ATTEMPT_LEDGER.jsonl', {'event': name,
        'timestamp_utc': datetime.now(timezone.utc).isoformat(), **values})


def make_owner(model, budget, c, manifest, method='DIRECT', domain=None):
    k = DomainKernel(model, 'BOUNDED', str(NATIVE_DLL), budget, domain=domain) if method == 'DOMAIN' else LegacyKernel(model, 'BOUNDED', str(NATIVE_DLL), budget)
    home = home_context(model, manifest['scenario'])
    home.update(context_id=c['context_id'] + ':' + method + ':HOME', backup_id=c['backup_id'] + ':' + method + ':HOME')
    startup = k.startup(home, budget)
    k.flush_raw_evidence()
    return k, startup


def reference_inputs(out, model, manifest, budget):
    contexts = []
    for ep in episodes('TEST'):
        event(out, 'START', kind='REFERENCE', **ep)
        episode = reference_episode(model, manifest['reference_scenario'], ep['displacement_m'],
            ep['episode_id'], ep['snapshot_ticks'], budget, evidence_callback=budget.record_raw)
        for c in episode['controls']:
            c.pop('raw_solver_result', None)
        save_numeric(out / 'episodes' / (ep['episode_id'] + '.json'), episode)
        event(out, 'RETURN', kind='REFERENCE', episode_id=ep['episode_id'],
              status=episode['status'], counts=episode['counts'])
        contexts.extend(context_for(p, episode, manifest['mapping']) for p in plans('TEST')
                        if p['episode'] == ep['episode_id'])
        budget.persist(phase='REFERENCE_SAVED', episode=ep['episode_id'])
    save_numeric(out / 'TEST_CONTEXTS.json', contexts)
    return contexts


def packet_once(out, path, c, model, budget, manifest):
    owners, startup = {}, {}
    if c.get('eligible'):
        for name, _ in OWNER_BRANCHES:
            owners[name], startup[name] = make_owner(model, budget, c, manifest)
        packet = direct_packet(owners['B'], c, budget, owners)
        owners['B'].flush_raw_evidence()
    else:
        packet = {'context_id': c['context_id'], 'selected_command_sent': False,
                  'status': 'SOURCE_INELIGIBLE', 'command_ready_ms': 0., 'actions': {}}
    write(path / 'STARTUP.json', startup)
    save_numeric(path / 'PACKET.json', packet)
    return owners, packet


def run(run_id=RUN_ID):
    out = output(run_id)
    if (out / 'RUN_STARTED.json').exists():
        raise FileExistsError('STEP41 run already attempted; no numerical restart')
    out.mkdir(parents=True, exist_ok=True)
    old = read(SOURCE39 / 'PROTOCOL_AND_MANIFEST.json')
    bundle, screen = load_frozen()
    table_path = out / 'TERMINAL_CAL_DOMAIN.json'
    table_freeze = read(out / 'TERMINAL_CAL_DOMAIN_FREEZE.json')
    if sha(table_path) != table_freeze['sha256']:
        raise ValueError('frozen terminal domain identity mismatch')
    domain = ResidentDomain(read(table_path), table_freeze['sha256'])
    model = frozen.load_model()
    limits = extract_healthy_torque_limits(model)
    mapping = [dict(r, healthy_limit_nm=float(limits[r['actuator_index']])) for r in extract_actuator_audit(model)]
    inherited = ('scenario', 'reference_scenario', 'feature_names', 'feature_units',
                 'feature_scale_floors', 'feature_dimension', 'online_gamma_order',
                 'actual_local_bound_m', 'deadline_ms', 'horizon_s', 'physics_dt_s',
                 'candidate_eps', 'reference_eps', 'first_B_limit_s', 'first_C_limit_s',
                 'feedback_limit_s', 'friction_upper_N', 'torque_inset_Nm',
                 'original_inequality_extra_slack', 'empirical_D_reserve_main_m')
    manifest = {k: deepcopy(old[k]) for k in inherited}
    assets = OUTPUT_ROOT_D / 'third_party/unitree_mujoco_snapshot/unitree_robots/go2'
    model_bytes = {relative(p, OUTPUT_ROOT_D): sha(p) for p in assets.rglob('*') if p.is_file()}
    physical = deepcopy(old['frozen_physical'])
    physical['model_files_sha256'] = model_bytes
    manifest.update(run_id=run_id, source_commit=SOURCE_COMMIT,
        source_worktree_read_only=str(SOURCE_ROOT_D), new_file_drive='D',
        native_dll_path=str(NATIVE_DLL), native_dll_sha256=sha(NATIVE_DLL),
        frozen_physical=physical, mapping=mapping, protocol_sha256=sha(PROTOCOL),
        reference_episodes=episodes('TEST'), TEST_plans=plans('TEST'),
        max_QP_calls=6000, max_physics_steps=60000, max_wall_s=3600,
        max_fits=0, new_CAL=0, max_implementation_IO_repairs=2,
        frozen_screen=screen, model_checkout_bytes_not_old_CRLF_bytes=True,
        screen_version='LEGACY_AND_TERMINAL_CAL_DOMAIN_GATE', terminal_domain_sha256=table_freeze['sha256'], E3_RL_hardware_authorized=False)
    write(out / 'PROTOCOL_AND_MANIFEST.json', manifest)
    positions = [{'id': p['context_id'] + ':' + name, 'context': p['context_id'],
                  'branch': name, 'gamma': g, 'split': 'TEST'}
                 for p in plans('TEST') for name, g in BRANCHES]
    positions += [{'id': p['context_id'] + ':' + method + '_ACTUAL', 'context': p['context_id'],
                   'branch': method + '_ACTUAL', 'method': method, 'split': 'TEST'}
                  for p in plans('TEST') for method in METHODS]
    write(out / 'FROZEN_INPUTS.json', {'TEST': plans('TEST'), 'planned_branch_positions': positions,
        'distinct_physical_snapshots': 8, 'distinct_episodes': 4, 'new_CAL': 0, 'new_fits': 0,
        'planned_decisions': [{'id':p['context_id']+':'+method,'context_id':p['context_id'],'method':method} for p in plans('TEST') for method in METHODS],
        'methods': list(METHODS), 'context_order': [list(METHODS if p['ordinal'] % 2 == 0 else METHODS[::-1]) for p in plans('TEST')]})
    write(out / 'SCREEN_IDENTITY_START.json', screen)
    write(out / 'RUNTIME_FREEZE.json', {'source_commit': SOURCE_COMMIT, 'protocol_sha256': sha(PROTOCOL),
        'runtime_sha256': {relative(p, OUTPUT_ROOT_D): sha(p) for p in
            [*OUTPUT_ROOT_D.glob('cavr_wbc/**/*.py'), OUTPUT_ROOT_D / 'tests/test_step41_protocol.py']},
        'model_checkout_bytes': model_bytes})
    import cavr_wbc, scipy, osqp, mujoco, threadpoolctl
    if not Path(cavr_wbc.__file__).resolve().is_relative_to(OUTPUT_ROOT_D):
        raise ValueError('wrong cavr_wbc package')
    write(out / 'ENVIRONMENT.json', {'cavr_wbc_file': cavr_wbc.__file__,
        'numpy': np.__version__, 'scipy': scipy.__version__, 'osqp': osqp.__version__,
        'mujoco': mujoco.__version__, 'threadpools': threadpoolctl.threadpool_info(),
        'TMP': os.environ.get('TMP'), 'TEMP': os.environ.get('TEMP'), 'MPLCONFIGDIR': os.environ.get('MPLCONFIGDIR'),
        'D_write_and_free_check_once': True, 'D_free_bytes_before': 77658796032,
        'readonly_git_alternates': (OUTPUT_ROOT_D / '.git/objects/info/alternates').read_text().splitlines(),
        'new_objects_index_logs_on_D': True, 'protected_robot_control_project_accessed': False})
    budget = SprintBudget(out)
    status = 'COMPLETED'
    write(out / 'RUN_STARTED.json', {'run_id': run_id, 'pid': os.getpid(),
        'start_utc': datetime.now(timezone.utc).isoformat(), 'command': 'cavr_wbc.experiments.step41_launch'})
    try:
        contexts = reference_inputs(out, model, manifest, budget)
        for p, c in zip(plans('TEST'), contexts):
            directory = out / 'TEST' / c['context_id']
            save_numeric(directory / 'SOURCE_IDENTITY.json', {'plan': p, 'context': c})
            order = METHODS if p['ordinal'] % 2 == 0 else METHODS[::-1]
            live_owners, packets = {}, {}
            for method in order:
                event(out, 'START', kind='GOVERNOR', context_id=c['context_id'], method=method)
                if c.get('eligible'):
                    live, startup = make_owner(model, budget, c, manifest, method, domain)
                    write(directory / method / 'STARTUP.json', startup)
                    decision = live.governor(c, bundle, .006, budget)
                    live.flush_raw_evidence()
                else:
                    live = None
                    decision = {'context_id':c['context_id'], 'selected_command_sent':False,
                        'status':'SOURCE_INELIGIBLE', 'actions':{}, 'command_ready_ms':0.}
                live_owners[method], packets[method] = live, decision
                save_numeric(directory / method / 'DECISION.json', decision)
                event(out, 'DECISION_IMMUTABLE', context_id=c['context_id'], method=method,
                    decision_sha256=sha(directory / method / 'DECISION.json'), actual_and_direct_not_started=True,
                    selected_command_sent=decision.get('selected_command_sent'), selected_gamma=decision.get('selected_gamma'))
            event(out, 'BOTH_DECISIONS_IMMUTABLE', context_id=c['context_id'], order=list(order),
                owner_identities={m:live_owners[m].solver_owner_identity() if live_owners[m] else None for m in METHODS})
            for method in order:
                decision, live = packets[method], live_owners[method]
                event(out, 'START', kind='RECOGNIZED_ACTUAL', method=method, context_id=c['context_id'])
                branch = (sim.propagate(live, c, decision, budget, purpose=method+'_ACTUAL', require_sent=True)
                    if decision.get('selected_command_sent') else not_run(decision.get('selected_gamma'), 'ABSTAIN_OR_LATE_UNAPPLIED'))
                r = save_branch(out, directory / method / 'ACTUAL', branch, c, decision, True)
                event(out, 'RETURN', kind='RECOGNIZED_ACTUAL', context_id=c['context_id'], method=method, status=r['status'])
                budget.persist(phase='RECOGNIZED_SAVED', context_ordinal=p['ordinal'], method=method)
            del live_owners, packets
            owners, packet = packet_once(out, directory / 'DIRECT', c, model, budget, manifest)
            for name, gamma in BRANCHES:
                event(out, 'START', kind='TEST_DIRECT', context_id=c['context_id'], branch=name)
                action = (packet['actions'].get(str(gamma)) or {}).get('action') or {}
                branch = sim.propagate(owners[name], c, packet, budget, purpose=name, action=action, require_sent=False) \
                    if action.get('command_valid') and action.get('execution_eligible') else not_run(gamma, 'CURRENT_PACKET_UNAVAILABLE')
                r = save_branch(out, directory / 'DIRECT' / name, branch, c, packet)
                event(out, 'RETURN', kind='TEST_DIRECT', context_id=c['context_id'], branch=name, status=r['status'])
                budget.persist(phase='TEST_DIRECT_SAVED', context_ordinal=p['ordinal'], branch=name)
            budget.persist(phase='TEST_CONTEXT_DONE', contexts_processed=p['ordinal'] + 1)
            print({'phase': 'TEST_CONTEXT_DONE', 'completed': p['ordinal'] + 1, 'planned': 16,
                   'budget': budget.snapshot()}, flush=True)
            del owners
            gc.collect()
    except SprintLimit as exc:
        status = 'INCOMPLETE_BUDGET'
        write(out / 'INTERRUPTION.json', {'error': str(exc), 'budget': budget.snapshot()})
    except BaseException as exc:
        status = 'STOPPED_IMPLEMENTATION_OR_RESOURCE'
        write(out / 'INTERRUPTION.json', {'type': type(exc).__name__, 'error': str(exc),
            'traceback': traceback.format_exc(), 'budget': budget.snapshot()})
        raise
    finally:
        end = bundle_identity(bundle) if bundle is not None else None
        unchanged = end == screen.get('identity')
        file_hashes = {path: sha(Path(path)) for path in screen.get('files', {})}
        unchanged = unchanged and file_hashes == screen.get('files', {})
        write(out / 'SCREEN_IDENTITY_END.json', {'identity': end, 'files': file_hashes,
            'full_model_CAL_TRAIN_threshold_identity_unchanged': unchanged, 'terminal_domain_unchanged': sha(table_path)==table_freeze['sha256'], 'new_fits': 0, 'new_CAL': 0})
        if not unchanged:
            status = 'INVALID_SCREEN_IDENTITY'
        budget.event('NUMERICAL_FINISHED', status=status, **budget.snapshot())
        budget.close()
        write(out / 'RUN_FINISHED.json', {'status': status, 'run_id': run_id, 'budget': budget.snapshot(),
              'finish_utc': datetime.now(timezone.utc).isoformat()})
        print({'status': status, 'budget': budget.snapshot()}, flush=True)


if __name__ == '__main__':
    run()
