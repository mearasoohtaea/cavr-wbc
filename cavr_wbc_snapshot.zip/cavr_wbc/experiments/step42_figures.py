"""Two saved-only SciPilot observation plots; preview, visual check, then export."""
from pathlib import Path
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from PIL import Image
from cavr_wbc.experiments.step42_io import output,read,write,sha
SKILL=Path('C:/Users/ZhuanZ（无密码）/.codex/skills/scipilot-figure/scripts')
sys.path.insert(0,str(SKILL))
from setup_style import setup_style
from profile_data import profile_data
from visual_qa import audit_layout,render_preview
from export_figure import export_figure
from check_figure import check_figure
COL={'DOMAIN':'#0072B2','CONSENSUS':'#009E73','B':'#555555','error':'#D55E00'}
MARK={'DOMAIN':'o','CONSENSUS':'s','B':'x'}
EXPORT='--export' in sys.argv

def verify_exported_fonts():
    """Resolve Type0 descendant embedding; generic checker misses this level."""
    from pypdf import PdfReader
    home=output()/'figures';result={}
    for path in sorted(home.glob('FIG42_*.pdf')):
        fonts=[]
        for page in PdfReader(str(path)).pages:
            for name,ref in page['/Resources']['/Font'].items():
                font=ref.get_object()
                children=font.get('/DescendantFonts')
                descs=[x.get_object() for x in children] if children else [font]
                embedded=[]
                for child in descs:
                    descriptor=child.get('/FontDescriptor')
                    descriptor=descriptor.get_object() if descriptor else {}
                    embedded.append(any(k in descriptor for k in ('/FontFile','/FontFile2','/FontFile3')))
                fonts.append(dict(resource=str(name),base_font=str(font.get('/BaseFont')),subtype=str(font.get('/Subtype')),
                    descendants_embedded=embedded,type3=str(font.get('/Subtype'))=='/Type3'))
        result[path.name]=dict(fonts=fonts,all_embedded=all(all(f['descendants_embedded']) and not f['type3'] for f in fonts))
    write(home/'PDF_DESCENDANT_FONT_VERIFICATION.json',result)
    if not all(v['all_embedded'] for v in result.values()):raise RuntimeError('PDF font embedding')
    print('All PDF Type0 descendant FontFile2 streams embedded; no Type3 fonts.')

def finish(fig,home,name,size):
    fig.set_size_inches(*size)
    issues=audit_layout(fig)
    render_preview(fig,str(home/(name+'_preview.png')),dpi=180)
    with Image.open(home/(name+'_preview.png')) as image:
        image.convert('L').save(home/(name+'_gray_preview.png'))
    write(home/(name+'_LAYOUT.json'),dict(issues=issues,exported=False,size_inches=size))
    if issues:
        raise RuntimeError('layout must be corrected before exporting: '+str(issues))
    if EXPORT:
        paths=export_figure(fig,str(home/name),formats=['pdf','svg','png'],size_inches=size,
            dpi=600,tight=False,grayscale_preview=False)
        with Image.open(home/(name+'.png')) as image:
            image.convert('L').save(home/(name+'_grayscale.png'),dpi=(600,600))
        checks={}
        for path in paths:
            found,info=check_figure(path,min_dpi=599.9,target_inches=size)
            checks[Path(path).name]=dict(issues=found,info=info,
                Type0_embedding_resolved_separately=True)
        write(home/(name+'_LAYOUT.json'),dict(issues=issues,exported=True,size_inches=size,format_checks=checks))
    plt.close(fig)

def label(d,i):
    e=d['episode'].split('_')[-1]
    tick=d['snapshot_id'].split('_T')[-1]
    return f"{i+1:02d} E{e} {d['displacement_m']*1000:+g}/t{tick} {d['fault_leg']}"

def row_axes(ax,n,labels=None):
    ax.set(ylim=(n-.45,-.6),yticks=range(n))
    if labels is not None:ax.set_yticklabels(labels)
    else:ax.tick_params(labelleft=False)
    ax.grid(axis='y',color='.91',lw=.45,zorder=0)

def figure_decisions(home,ds,qs,cids):
    n=len(cids)
    fig,axes=plt.subplots(1,3,figsize=(7.16,9.8),gridspec_kw={'width_ratios':[1.7,1.5,1.6]})
    choices,lat,nei=axes
    lookup={(d['context_id'],d['method']):d for d in ds}
    names=[label(lookup[(cid,'DOMAIN')],i) for i,cid in enumerate(cids)]
    for i,cid in enumerate(cids):
        for j,m in enumerate(('DOMAIN','CONSENSUS')):
            d=lookup[(cid,m)];y=i+(-.17 if j==0 else .17)
            choice='M' if d['selected_gamma']==.5 and d['selected_command_sent'] else 'B' if d['selected_command_sent'] else 'A'
            if d['selected_command_sent'] and not d['complete_actual']:choice+='?'
            elif d['selected_command_sent'] and not d['safe_actual_6mm']:choice+='!'
            color=COL['error'] if '!' in choice else COL[m]
            choices.scatter(j,y,s=44,marker=MARK[m],facecolor='white',edgecolor=color,lw=.85)
            choices.text(j+.14,y,choice,va='center',fontsize=8,color=color)
            lat.scatter(d['command_ready_ms'],y,s=22,marker=MARK[m],color=COL[m],
                edgecolor='black',lw=.25,zorder=3)
            for q in (q for q in qs if q['context_id']==cid and q['method']==m):
                evidence=q.get('physical_consensus') or {}
                offset=(-.3 if q['gamma']==.5 else -.1) if j==0 else (.1 if q['gamma']==.5 else .3)
                failed=evidence.get('failed_neighbor_count')
                if q['evaluation_status']=='EVALUATED' and failed is not None:
                    nei.scatter(failed,i+offset,s=23,marker=MARK[m],
                        facecolors=COL[m] if q['gamma']==.5 else 'none',edgecolors=COL[m],lw=.8)
                else:
                    nei.plot(4.8,i+offset,marker='x',color='.6',ms=3,ls='')
    for ax in axes:
        row_axes(ax,n,names if ax is choices else None)
        for y in (3.5,7.5,11.5,15.5,19.5,23.5,27.5):ax.axhline(y,color='.65',lw=.55,zorder=0)
    choices.set(xlim=(-.3,1.65),xticks=[0,1],xticklabels=['DOMAIN','CONSENSUS'])
    choices.set_xlabel('Selection: M / B / A')
    choices.set_ylabel('Context / episode / target (mm), tick, fault leg')
    lat.set_xlabel('Full decision latency (ms)')
    lat.set_xlim(0,max(22,max(d['command_ready_ms'] or 0 for d in ds)*1.08))
    lat.axvline(20,color='black',ls='--',lw=.75)
    nei.set(xlim=(-.4,5.2),xticks=[0,1,2,3,4,4.8],xticklabels=['0','1','2','3','4','NQ'])
    nei.set_xlabel('Original local4\nphysical failures')
    for ax,title in zip(axes,('(a) All choices','(b) Decision time','(c) CAL conflicts')):
        ax.set_title(title,loc='left',fontweight='bold',fontsize=8)
    handles=[Line2D([],[],marker=MARK[m],color=COL[m],ls='',label=m) for m in ('DOMAIN','CONSENSUS')]
    handles += [Line2D([],[],marker='o',color='black',ls='',label='Filled: middle query'),
        Line2D([],[],marker='o',mfc='none',color='black',ls='',label='Open: B query'),
        Line2D([],[],marker='x',color='.6',ls='',label='NQ: not evaluated / invalid local4')]
    fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.5,.045),ncol=2,frameon=False,fontsize=8)
    fig.text(.5,.018,'A = abstain (unapplied / unknown); ! = complete error; ? = incomplete sent. 16 snapshots / 8 episodes.',ha='center',fontsize=8)
    fig.subplots_adjust(left=.285,right=.98,top=.955,bottom=.15,wspace=.42)
    finish(fig,home,'FIG42_1_DECISIONS_AND_LOCAL4',(7.16,9.8))

def figure_execution(home,ds,rows,cids):
    chosen=[d for d in ds if d['selected_command_sent']]
    by={r['id']:r for r in rows};n=len(chosen)
    size=(7.16,min(9.8,max(6.5,2.6+n*.24)))
    fig,axes=plt.subplots(1,4,figsize=size,gridspec_kw={'width_ratios':[1,1,1.15,1.35]})
    vel,exc,pro,state=axes
    names=[];values=[[],[],[]]
    for i,d in enumerate(chosen):
        cid=d['context_id'];m=d['method'];A=by[cid+':'+m+'_ACTUAL'];B=by[cid+':B']
        names.append(f"C{cids.index(cid)+1:02d} {m[:1]} "+('M' if d['selected_gamma']==.5 else 'B'))
        pairvals=[]
        for r in (A,B):
            y=r['terminal_Y']
            pairvals.append([None if y is None else abs(float(y[3])),
                None if r['D_m'] is None else r['D_m']*1000,
                None if r['progress02_04_m'] is None else r['progress02_04_m']*1000])
        for k,ax in enumerate((vel,exc,pro)):
            a,b=pairvals[0][k],pairvals[1][k]
            if a is not None and b is not None:
                ax.plot([a,b],[i-.12,i+.12],color='.7',lw=.6,zorder=0)
            if a is not None:
                ax.scatter(a,i-.12,s=27,marker=MARK[m],color=COL[m],edgecolor='black',lw=.3)
                if d['complete_actual'] and not d['safe_actual_6mm']:
                    ax.plot(a,i-.12,'x',color=COL['error'],ms=7,mew=1.)
                values[k].append(a)
            if b is not None:
                ax.scatter(b,i+.12,s=25,marker='x',color=COL['B'],lw=.8);values[k].append(b)
        for j,r in enumerate((A,B)):
            flags=(r['physical_pass'],r['terminal_pass'],
                None if r['D_m'] is None else r['D_m']<=.006)
            for k,flag in enumerate(flags):
                x=j*3+k
                state.text(x,i,'Y' if flag is True else 'N' if flag is False else '?',
                    ha='center',va='center',fontsize=8,color='black' if flag else COL['error'])
    for ax in axes:row_axes(ax,max(n,1),names if ax is vel else None)
    vel.axvline(1,color='black',ls='--',lw=.7)
    vel.set_xlabel('|Terminal base vx|\n(mm/s)')
    exc.axvline(6,color='black',ls='--',lw=.7);exc.set_xlabel('Local excursion\n(mm)')
    pro.set_xlabel('Directed progress (mm)\n0.02-0.04 s')
    for k,ax in enumerate((vel,exc,pro)):
        include=values[k]+([0.,1.] if k==0 else [0.,6.] if k==1 else [0.])
        lo,hi=min(include),max(include);pad=max((hi-lo)*.12,.02)
        ax.set_xlim(max(0,lo-pad) if k<2 else lo-pad,hi+pad)
    state.set(xlim=(-.6,5.6),xticks=range(6),xticklabels=['A:P','T','L','B:P','T','L'])
    state.set_xlabel('Actual / direct B\nPhysical, terminal, local')
    for ax,title in zip(axes,('(a) Terminal','(b) Local','(c) Progress','(d) Endpoints')):
        ax.set_title(title,loc='left',fontweight='bold',fontsize=8)
    handles=[Line2D([],[],marker=MARK[m],color=COL[m],ls='',label=m+' actual') for m in ('DOMAIN','CONSENSUS')]
    handles += [Line2D([],[],marker='x',color=COL['B'],ls='',label='Same-source direct B (offline)'),
        Line2D([],[],marker='x',color=COL['error'],ls='',label='Complete error accept')]
    fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.5,.045),ncol=2,frameon=False,fontsize=8)
    fig.text(.5,.018,f'{n} recognized trajectories, all included. Lines connect same-source pairs; not independent samples.',ha='center',fontsize=8)
    fig.subplots_adjust(left=.14,right=.985,top=.95,bottom=.18,wspace=.5)
    finish(fig,home,'FIG42_2_ALL_RECOGNIZED_PAIRS',size)

def main():
    out=output();home=out/'figures';home.mkdir(exist_ok=True)
    setup=setup_style(journal='ieee',lang='en',constrained_layout=False)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.labelsize':8,
        'axes.titlesize':8,'xtick.labelsize':8,'ytick.labelsize':8,'legend.fontsize':8})
    ds=read(out/'ALL_METHOD_DECISIONS.json');qs=read(out/'ALL_CAUSAL_QUERIES.json');rows=read(out/'ALL_PLANNED_RESULTS.json')
    cids=list(dict.fromkeys(d['context_id'] for d in ds))
    if not (home/'DATA_PROFILE.json').exists():
        profile=profile_data(pd.DataFrame([{k:d[k] for k in ('context_id','snapshot_id','episode','method',
            'selected_gamma','command_ready_ms','complete_actual','safe_actual_6mm','physical_pass','terminal_pass','D_m')}
            for d in ds]),group_cols=['method'])
        write(home/'DATA_PROFILE.json',profile)
        write(home/'FIGURE_DESIGN.json',dict(style=setup,physical_snapshots=16,episodes=8,
            small_sample_no_CI_pvalues_or_mean_bars=True,
            context_keys={f'C{i+1:02d}':cid for i,cid in enumerate(cids)},
            selection_reason='Show each online choice and original failed neighbor; retain every recognized execution and matched B',
            alternatives=['supplementary observation table','same-source paired point plot'],
            inputs_sha256={n:sha(out/n) for n in ('ALL_METHOD_DECISIONS.json','ALL_CAUSAL_QUERIES.json','ALL_PLANNED_RESULTS.json')}))
    figure_decisions(home,ds,qs,cids);figure_execution(home,ds,rows,cids)
    if EXPORT:verify_exported_fonts()
    print('Two saved-only figures: no optimizer, propagation, fitting, new CAL or historical bank readback.')

if __name__=='__main__':main()
