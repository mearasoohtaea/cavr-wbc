"""Copy the unchanged domain; diagnose exactly five exposed saved selections."""
import shutil
from cavr_wbc.experiments.step42_io import *
from cavr_wbc.experiments.step42_identity import load_frozen
from cavr_wbc.control.step42_physical_consensus import check_consensus

def prepare(out=output()):
    target = out/'TERMINAL_CAL_DOMAIN.json'
    if target.exists():
        raise FileExistsError('STEP42 preparation already persisted; no replacement')
    # Git checkout may normalize JSON newlines; use the authoritative frozen bytes.
    source = SOURCE41
    freeze = read(source/'TERMINAL_CAL_DOMAIN_FREEZE.json')
    if sha(source/'TERMINAL_CAL_DOMAIN.json') != freeze['sha256']:
        raise ValueError('specified STEP41 domain identity mismatch')
    out.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source/'TERMINAL_CAL_DOMAIN.json',target)
    write(out/'TERMINAL_CAL_DOMAIN_FREEZE.json', {**freeze,
        'source_commit':SOURCE_COMMIT,'source_sha256':freeze['sha256'],
        'unchanged_bytes':sha(target)==freeze['sha256'],'constructed_once_in_STEP41':True,
        'new_QP_calls':0,'new_physics_steps':0,'new_prefixes':0,'new_CAL':0,'new_fits':0})
    bundle, _ = load_frozen()
    decisions = read(SOURCE41/'ALL_METHOD_DECISIONS.json')
    selected = [d for d in decisions if d['method']=='DOMAIN' and d['selected_command_sent']]
    if len(selected)!=5:
        raise ValueError('five saved STEP41 DOMAIN selections required for designated DEV diagnosis')
    rows=[]
    for d in selected:
        path = SOURCE41/d['decision_path']
        packet=load_numeric(path)
        entry=packet['actions'][str(d['selected_gamma'])]
        numeric=entry['decision']['numeric']
        check=check_consensus(bundle,d['selected_gamma'],'thigh',numeric)
        rows.append(dict(context_id=d['context_id'],gamma=d['selected_gamma'],
            consensus=check,retained=check['accepted'],original_complete_safe=d['safe_actual_6mm'],
            original_physical=d['physical_pass'],original_terminal=d['terminal_pass'],
            source_json_sha256=sha(path),source_npz_sha256=sha(path.with_suffix('.npz')),
            exposed_development_only=True,new_TEST=False,new_actual_trajectory=False,
            no_reconstructed_unqueried_B=True))
    write(out/'DEVELOPMENT_REJUDGEMENT.json',rows)
    print({'domain_sha256':sha(target),'exposed_selected':len(rows),
           'retained':sum(r['retained'] for r in rows),'new_numerical_calls':0},flush=True)

if __name__=='__main__':prepare()
