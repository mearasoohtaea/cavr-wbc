"""Chinese bounded research delivery from saved summaries, no bank reread."""
from collections import Counter
import csv,json
from cavr_wbc.experiments.step42_io import *
from cavr_wbc.experiments.step39_delivery import safe
from cavr_wbc.experiments.step42_inputs import METHODS,plans

def table(headers,rows):
    return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+
        ['| '+' | '.join(str(v).replace('|','/') for v in row)+' |' for row in rows])
def fmt(x,n=4):return '—' if x is None else f'{x:.{n}f}'
def csv_new(path,rows):
    if path.exists():return
    fields=list(dict.fromkeys(k for row in rows for k in row))
    with path.open('x',encoding='utf-8',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=fields,lineterminator='\n')
        writer.writeheader()
        for row in rows:
            writer.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else v for k,v in row.items()})
def textfile(path,value):path.write_text(value,encoding='utf-8',newline='\n')
def choice(d):
    if not d['selected_command_sent']:return d['status']+'/NOT_RUN'
    return ('M' if d['selected_gamma']==.5 else 'B')+'/'+d['actual_outcome']

def main():
    out=output();r=read(out/'STEP42_RESULT.json');ds=read(out/'ALL_METHOD_DECISIONS.json')
    qs=read(out/'ALL_CAUSAL_QUERIES.json');rows=read(out/'ALL_PLANNED_RESULTS.json')
    dev=read(out/'DEVELOPMENT_REJUDGEMENT.json');finish=read(out/'RUN_FINISHED.json')
    b=finish['budget'];by={x['id']:x for x in rows};dm={(d['context_id'],d['method']):d for d in ds}
    consensus=r['methods']['CONSENSUS'];errors=[x for x in rows if x['branch'].endswith('_ACTUAL') and x['complete_501'] and not safe(x)]
    source=read(out/'SOURCE_END_STATE.json')
    cids=[p['context_id'] for p in plans('TEST')]
    repairs=len(list((out/'repairs').glob('IMPLEMENTATION_REPAIR_*.json')))
    r['implementation_IO_repairs']=repairs
    write(out/'STEP42_RESULT.json',r)
    endpoint=r['repair_endpoint_status']
    ready=endpoint=='READY_FOR_CONFIRMATORY_PANEL'
    summaries=[]
    for m in METHODS:
        x=r['methods'][m]
        summaries.append([m,x['planned'],x['eligible'],x['recognized'],x['gamma_counts'],x['ABSTAIN'],
            x['budget_not_evaluated_candidates'],x['late'],x['partial'],x['complete'],x['safe'],x['complete_error_accepts']])
    allpairs=[]
    for p in plans('TEST'):
        D,C=dm[(p['context_id'],'DOMAIN')],dm[(p['context_id'],'CONSENSUS')]
        allpairs.append([p['context_id'],fmt(p['displacement_m']*1000,1),p['tick'],choice(D),choice(C),
            fmt(D['command_ready_ms']),fmt(C['command_ready_ms'])])
    endpointrows=[]
    for m in METHODS:
        for name,v in r['methods'][m]['endpoints'].items():
            endpointrows.append([m,name,v['status'],v['contexts'],v['physical_snapshots'],v['episodes']])
    reject=[q for q in qs if q['method']=='CONSENSUS' and q['evaluation_status']=='EVALUATED' and
            q.get('physical_consensus') and not q['physical_consensus']['accepted']]
    gateonly=[q for q in reject if q.get('step41_same_candidate_accepted')]
    lost=[];safe_domain_veto=[]
    for q in reject:
        cid=q['context_id'];D=dm[(cid,'DOMAIN')];C=dm[(cid,'CONSENSUS')]
        if not D['complete_actual'] or not D['safe_actual_6mm']:continue
        safe_domain_veto.append(dict(context_id=cid,DOMAIN_actual=choice(D),
            DOMAIN_selected_gamma=D['selected_gamma'],CONSENSUS_candidate_gamma=q['gamma'],
            CONSENSUS_actual=choice(C),same_candidate_DOMAIN_acceptance=q.get('step41_same_candidate_accepted'),
            original_local4=q['physical_consensus'].get('local_cal_indices'),
            neighbor_reasons=q['physical_consensus']['reasons'],
            rejected_CONSENSUS_candidate_true_safety='UNKNOWN',candidate_actual_label_not_transferred=True))
    write(out/'SAFE_DOMAIN_POSITIONS_WITH_CONSENSUS_VETO.json',safe_domain_veto)
    for pair in r['endpoints']['method_pairs']:
        if not pair['coverage_cost_consensus_abstains_DOMAIN_complete_safe']:continue
        cid=pair['context_id'];C=dm[(cid,'CONSENSUS')];D=dm[(cid,'DOMAIN')]
        q=next((q for q in C['queries'] if q['gamma']==D['selected_gamma']),{})
        evidence=q.get('physical_consensus') or {}
        lost.append(dict(context_id=cid,DOMAIN_actual=choice(D),CONSENSUS_actual='UNAPPLIED_TRUE_SAFETY_UNKNOWN',
            candidate_evaluation_status=q.get('evaluation_status'),DOMAIN_selected_gamma=D['selected_gamma'],
            same_candidate_DOMAIN_acceptance=q.get('step41_same_candidate_accepted'),
            new_physical_gate_reject=q.get('consensus_gate_applied') and evidence.get('accepted') is False,
            neighbor_reasons=evidence.get('reasons'),candidate_actual_label_not_transferred=True))
    write(out/'COVERAGE_LOSS_DETAILS.json',lost)
    latency={}
    for m in METHODS:
        selected=[d for d in ds if d['method']==m]
        vals=[d['command_ready_ms'] for d in selected if d['command_ready_ms'] is not None]
        fb=[d['max_feedback_latency_ms'] for d in selected if d['max_feedback_latency_ms'] is not None]
        sent=[d['command_ready_ms'] for d in selected if d['selected_command_sent']]
        latency[m]=dict(decision_min_ms=min(vals),decision_max_ms=max(vals),
            sent_decision_max_ms=max(sent) if sent else None,
            feedback_max_ms=max(fb) if fb else None,evaluation_states=dict(Counter(q['evaluation_status'] for q in qs if q['method']==m)))
    csv_new(out/'LATENCY_DECISIONS_AND_FEEDBACK_MAX.csv',[{k:d[k] for k in ('context_id','method','status','command_ready_ms','max_feedback_latency_ms','overall_deadline_failure','phase_latency_ms')} for d in ds])
    neighborrows=[]
    for q in qs:
        e=q.get('physical_consensus') or {}
        for n in e.get('neighbors',[]):
            neighborrows.append(dict(context_id=q['context_id'],method=q['method'],gamma=q['gamma'],
                **n,query_probability=e.get('query_physical_probability'),original_threshold=e.get('original_physical_threshold'),
                DOMAIN_same_candidate=q.get('step41_same_candidate_accepted'),domain=q.get('terminal_domain'),
                consensus=e.get('accepted'),consensus_gate_applied=q.get('consensus_gate_applied'),
                final_accepted=q.get('accepted'),rejection_reasons=q.get('rejection_reasons'),complete_at_ms=q.get('complete_at_ms')))
    csv_new(out/'ORIGINAL_LOCAL4_NEIGHBORS.csv',neighborrows)
    facts=dict(endpoint=endpoint,latency=latency,complete_error_accepts=errors,
        consensus_evaluated_conflicts=len(reject),consensus_added_veto_candidates=len(gateonly),
        rejection_reason_counts=dict(Counter(reason for q in reject for reason in q['physical_consensus']['reasons'])),
        coverage_loss_details=lost,safe_DOMAIN_positions_with_CONSENSUS_veto=safe_domain_veto,
        current_bank_readback_not_repeated=True,new_QP_calls=0,new_physics_steps=0)
    write(out/'REPORT_FACTS.json',facts)
    headline=('本轮通过进入更广确认面板的有用执行门槛。' if ready else
        '本轮仍存在完整错误接受，方法终点为 FAIL / REVISE。' if consensus['complete_error_accepts'] else
        '本轮没有建立跨 snapshot/episode 的零错误有用执行，不能标记 PASS。')
    error_table=table(['认可分支','physical','terminal','local excursion (mm)','首物理失败 (s)','容量99%先于失败'],
        [[x['id'],x['physical_pass'],x['terminal_pass'],fmt(x['D_m']*1000 if x['D_m'] is not None else None),
          x['first_dense_failure_s'],x['capacity_precedes_failure']] for x in errors]) if errors else '两方法认可 ACTUAL 中没有完整物理/终端/local 错误接受。'
    report=f'''# STEP42：冻结 CAL 物理共识与 fresh 在线执行

## Material Passport

- Origin Skill: experiment-agent / ARS；模式：run；目标：IEEE T-RO。
- Verification Status: UNVERIFIED（未进行重现实验）；当前保存路径一致性读回为 {r['readback']['status']}。
- Version Label: STEP42_CAL_PHYSICAL_CONSENSUS_V1；run_id：{out.name}。
- 源提交：{SOURCE_COMMIT}；旧模型与 CAL 属于冻结来源；STEP41 已曝光结果仅用于开发诊断，不并入本轮 TEST。

## 核心结果

{headline} 执行状态为 {r['task_execution_status']}，方法终点为 {endpoint}，二者分别报告。CONSENSUS 实际认可 {consensus['recognized']} 条，完整安全 {consensus['safe']} 条，完整错误接受 {consensus['complete_error_accepts']} 条，partial {consensus['partial']} 条。
有用 middle 为 {consensus['endpoints']['useful_middle_execution']['contexts']} 个 context，覆盖 {consensus['endpoints']['useful_middle_execution']['physical_snapshots']} 个 physical snapshot / {consensus['endpoints']['useful_middle_execution']['episodes']} 个 episode。

该门的意义是拒绝已有 CAL 邻居中存在物理冲突的候选，同时检验受损中间动作的在线可用性与任务保留；它不是安全定理。实际包与 owner 可不同，只作同 source 配对，不声称 CONSENSUS 发送集合必为 DOMAIN 子集。

## 方法与冻结条件

唯一新增接受条件为本候选原 `numeric.local_cal_indices` 的四个合法非负整数索引，其四个不同 snapshot、至少两个 episode 的物理标签均完整、已知、通过；不另搜成功邻居、不改变稳定距离排序、K、概率阈值或 γ=.5→0 顺序。拒绝 middle 后，B 查询仍在同一次未重启的 20 ms 窗口。

保留 STEP41 三轴域表；字节 SHA256：{r['terminal_domain_sha256']}。prehold 0–.02 s、首动作 .02–.04 s、48 次反馈、终点1 s、dt=.002、500积分步/501状态/21 checkpoint 均不变；dense 接触评价覆盖每个状态。6 mm local、1 mm/s terminal vx、真实 subtree COM、command torque、anchor、42维 raw/sent 检查与原 evaluator 均保留。candidate 1e-7/reference 1e-8，B6 ms/C3 ms/feedback6 ms、friction upper−1e-4 N、torque inset1e-4 N·m 未调参。

MODEL/CAL/阈值完整身份见 SCREEN_IDENTITY_START/END；DOMAIN 和新增共识实现源码分别记录于 PROTOCOL_AND_MANIFEST/RUNTIME_FREEZE。fit=0 不等于没有开发选择，STEP41 诊断已公开保留。

## 固定批次与在线统计

新 reference 目标依次 +62、−62、+63.5、−63.5、+66.5、−66.5、+67、−67 mm；每条110tick/1100步，tick36/40，共16snapshot/8episode。每个仅 FR_THIGH15 和 RR_THIGH15，其他通道健康=1。
64个在线决定、64条计划独立direct middle/B、最多64条认可ACTUAL，总计划128条1s位置。未认可 ACTUAL 是 NOT_RUN，不是缺失轨迹或安全通过。

{table(['方法','planned','eligible','认可','gamma计数','ABSTAIN','候选预算未评价','late','partial','完整ACTUAL','完整安全','完整错受'],summaries)}

direct middle/B：{r['direct_middle_B']}。

## 各用途独立终点

{table(['方法','用途','状态','context','snapshot','episode'],endpointrows)}

safe-B progress 要求独立direct B完整安全，认可middle有向.02–.04 s进度严格更大；failed-B recovery 要求direct B完整且原physical失败、认可middle完整安全。两类各自要求2snapshot/2episode，不合并凑门。
本轮没有健康/.30新控制轨迹，不产生新的Type-II容量干预证明；历史STEP40结果原样保留。

## 全部同source位置：正负方向、故障与episode

以下32行涵盖全部16snapshot/8episode；两方法的决定均先冻结保存，未来ACTUAL及direct结果之后才生成。

{table(['context','目标mm','tick','DOMAIN / outcome','CONSENSUS / outcome','DOMAIN ms','CONSENSUS ms'],allpairs)}

M=middle，B=该方法自己的B0。ABSTAIN不施加未经认可B，也不表示系统具有安全fallback。两方法未发送动作的真实安全均UNKNOWN，不转移另一方法或direct标签。

## 错误接受与接触事实

{error_table}

全部实际 contact loss、负法向力及摩擦违例的网格位置、最长连续点数和首次时间，保存在每条RESULT的contact_statistics及lossless fact bank。单个2ms网格contact loss不改称持续跌倒。完整错误接受优先判FAIL；已发送但partial或缺少终点评价则不能作为完整安全，主终点NOT_ESTABLISHED。

## 新物理门与覆盖代价

CONSENSUS 实际 EVALUATED 的物理冲突候选为 {len(reject)} 个；其中 DOMAIN 同一候选原条件已通过、被新增门否决的为 {len(gateonly)} 个。每条原四邻居身份、距离、snapshot/episode、complete/known/physical、查询概率和原阈值、域判定、共识与最终原因、完整计时保存在 CAL_NEIGHBOR_EVIDENCE、ORIGINAL_LOCAL4_NEIGHBORS 和完整DECISION packet。NOT_EVALUATED_BUDGET 单列，不能称物理门拒绝。

DOMAIN 完整安全而 CONSENSUS 弃权的同source位为 {len(lost)} 个：
{table(['context','DOMAIN已发送结果','CONSENSUS候选状态','新增物理门拒绝','未施加动作真值'],
    [[x['context_id'],x['DOMAIN_actual'],x['candidate_evaluation_status'],x['new_physical_gate_reject'],'UNKNOWN'] for x in lost])}

同source已有完整安全DOMAIN实际结果、但CONSENSUS候选发生原四邻居冲突的全部位置如下（包括CONSENSUS随后发送B的情况）；完整候选级记录见 SAFE_DOMAIN_POSITIONS_WITH_CONSENSUS_VETO.json。它们并不自动等于新增门独立造成的覆盖损失，原门也可能已拒绝；被拒候选的实际安全仍为UNKNOWN，不借用DOMAIN真值。
{table(['context','DOMAIN已发送','CONSENSUS候选gamma','该候选原DOMAIN条件','CONSENSUS最终','被拒候选真值'],
    [[x['context_id'],x['DOMAIN_actual'],x['CONSENSUS_candidate_gamma'],x['same_candidate_DOMAIN_acceptance'],x['CONSENSUS_actual'],'UNKNOWN'] for x in safe_domain_veto])}

若本轮DOMAIN没有错受，不声称实证降低错误率；有限零错误不换算总体概率，无p值或伪独立CI。

开发诊断：STEP41现有5个DOMAIN认可候选仅作保存数据重判，保留 {sum(x['retained'] for x in dev)} 个、拒绝 {sum(not x['retained'] for x in dev)} 个（已知错误B和安全负向RR middle）。没有重演旧轨迹、重搜门或重建未查B。
{table(['旧context','gamma','共识保留','原已发送完整安全','共识原因'],
    [[x['context_id'],x['gamma'],x['retained'],x['original_complete_safe'],x['consensus']['reasons']] for x in dev])}

## 计时、预算、测试与证据

- 数值入口仅一次：python -B -X utf8 -m cavr_wbc.experiments.step42_launch。
- 首数值动作：{b['numerical_started_utc']}；固定上限90min/12000QP/120000step；实际 {b['numerical_elapsed_s']:.6f}s、{b['total_QP_calls']}QP、{b['total_physics_steps']}step。
- QP START/RETURN/raw shard：{r['readback']['qp_starts']}/{r['readback']['qp_returns']}/{r['readback']['raw_qp_shards']}；未返回 {r['readback']['unknown_qp']}；fit=0、newCAL=0，预算未重置。
- 两方法完整在线计时：{latency}。新增门、邻居及metadata复制计入原准备起点至command-ready；反馈沿对应 live owner推进，迟到无效动作先停施加与积分。
- 每方法有1个决定超过20ms但未施加；它们作为迟到弃权保留，不排除结果也不补跑。反馈6ms是冻结QP求解预算，完整staging/check/commit的在线deadline仍为20ms；已发送认可ACTUAL的48个反馈均满足该deadline，完整反馈最大值单独报告，不冒充均低于6ms。
- 纯fixture集中一次15项通过；因域表checkout行尾IO修复，只补1项相关fixture通过；未调用真实QP/MuJoCo/fit，未跑历史全套。实现/IO定点修复实际 {repairs}/2。
- 当前路径读回仅一次，{r['readback']['observed_banks_read_once']}条已观察bank、{r['readback']['complete_grids_verified']}条完整轴；问题列表：{r['readback']['issues']}。不重读历史bank，不建立另一个审计阶段。
- 源HEAD/index保持：{source}。新代码/工件/缓存/Git写入D；旧E依赖只读；禁区机器人运控算法未访问。无依赖安装、probe、重编译、结果性重跑或扩大预算。

## 两张逐观测图

图1展示所有同source选择、完整错受、弃权、20ms与原四邻居物理失败数；图2保留所有认可middle/B的终端速度、local excursion、有向进度及physical/terminal/local同source direct B配对。每个点代表观测而非独立重复，连接线仅指同source配对，无统计误差棒。

![全部在线选择与原四CAL邻居]({(out/'figures/FIG42_1_DECISIONS_AND_LOCAL4.png').as_posix()})
![全部认可ACTUAL与独立direct B]({(out/'figures/FIG42_2_ALL_RECOGNIZED_PAIRS.png').as_posix()})

PDF/SVG/600dpi PNG与视觉检查记录保存在figures/；风格由SciPilot选择逐点/配对图，避免均值柱掩盖弃权和失败。

## 研究交接

{'READY_FOR_CONFIRMATORY_PANEL：建议下一轮采用独立新reference episode，分层覆盖正负方向、多个任务幅度及早/晚snapshot；在FR/RR thigh之外覆盖其余腿的同类能力损伤，并预冻结多个健康等级。两方法保持同source、独立owner和20ms完整窗口；完整物理/terminal/local错受、弃权覆盖、safe-B progress及failed-B recovery分别作为终点，按episode及snapshot报告，不将未发送动作补成安全标签。先冻结状态/故障清单和样本量，再一次执行，不按中途结果补样本；明确比较可靠性与有用执行的折衷。需要新的明确授权，本轮不自动启动。当前3snapshot/3episode只是进入门槛，不是T-RO投稿充分证据。' if ready else
'下一研究选择是接触裕量建模或新的物理校准，针对原短prefix与后续反馈物理风险的差距建立机制证据；不继续任意堆门获取表面零错误。任何新校准、拟合或确认面板需新的明确授权，本轮到此停止。'}

贡献中心仍是执行器能力受损下动作/备份的可恢复性与任务保留。经验四邻居否决本身不是T-RO级安全保证，也不宣称conformal、CBF、viability、稳定性或连续时间证书。

工件：ALL_PLANNED_RESULTS/ALL_METHOD_DECISIONS/SAME_SOURCE_METHOD_PAIRS、CAL_NEIGHBOR_EVIDENCE/CONFLICTS、完整ledger、轨迹及owner packet、CAPACITY_EVENTS_FULL、latency、METHOD_UPDATE、HANDOFF、全部PROTOCOL_STATUS。提交号见拥有本报告的Git提交与最终交付；不push。
'''
    textfile(out/'REPORT.md',report)
    method=f'''# STEP42 METHOD UPDATE
唯一接受更新：CONSENSUS = 同候选STEP41 DOMAIN接受 AND 原numeric.local_cal_indices四个CAL物理标签完整、已知、通过；索引非法/缺失/UNKNOWN/不完整均拒绝。原稳定距离选择不变，不建安全CAL子集，不禁止整个gamma0，不改域、阈值、R或deadline。
DOMAIN采用同原接受规则，额外保存原邻居诊断但不施加物理共识否决；邻居及metadata复制均计入在线窗口。两者独立resident/B0，交替顺序，同source而非同packet。
实际方法终点：{endpoint}；fit=0/newCAL=0。旧源码与新增源码hash均保留，不声称所有算法源码未变。已曝光STEP41仅为DEV，新8episode为固定TEST。
'''
    textfile(out/'METHOD_UPDATE.md',method)
    textfile(out/'HANDOFF.md',f'''# STEP42 RESEARCH HANDOFF
执行：{r['task_execution_status']}；方法：{endpoint}。
源：{SOURCE_COMMIT}；新checkout：{OUTPUT_ROOT_D.as_posix()}；run：{out.name}。
CONSENSUS认可/安全/错受={consensus['recognized']}/{consensus['safe']}/{consensus['complete_error_accepts']}；有用middle {consensus['endpoints']['useful_middle_execution']['physical_snapshots']}snapshot/{consensus['endpoints']['useful_middle_execution']['episodes']}episode。
safe-B progress：{consensus['endpoints']['safe_B_progress']['status']}；failed-B recovery：{consensus['endpoints']['failed_B_recovery']['status']}；分别计数，不合并。
{'下一轮可提出更广独立状态/故障确认设计，需单独授权。' if ready else '下一研究选择：接触裕量模型或新的物理校准；不继续堆任意否决门。'}
旧证据只读，无历史重演、E3、RL、硬件或禁区访问，无push。完整报告、计划位、邻居证据、延迟、容量和调用账本见同目录工件。修复{repairs}/2；当前bank只读回一次，禁止将本次缺失或迟到改成安全通过。
''')
    ini=PROTOCOL.read_text(encoding='utf-8').split('~~~ini\n',1)[1].split('~~~',1)[0]
    actual=dict(TASK_EXECUTION_STATUS=r['task_execution_status'],NUMERICAL_BATCH_STATUS=finish['status'],
        CURRENT_RUN_READBACK=r['readback']['status'],METHOD_REPAIR_ENDPOINT=endpoint,
        NEXT_HANDOFF='READY_FOR_CONFIRMATORY_PANEL' if ready else 'CONTACT_MARGIN_OR_NEW_PHYSICAL_CALIBRATION',
        CONSENSUS_RECOGNIZED=consensus['recognized'],CONSENSUS_COMPLETE=consensus['complete'],
        CONSENSUS_SAFE=consensus['safe'],CONSENSUS_COMPLETE_ERROR_ACCEPTS=consensus['complete_error_accepts'],
        CONSENSUS_ABSTAIN=consensus['ABSTAIN'],CONSENSUS_LATE=consensus['late'],CONSENSUS_PARTIAL=consensus['partial'],
        CONSENSUS_SAFE_TIMELY_MIDDLE_CONTEXTS=consensus['endpoints']['useful_middle_execution']['contexts'],
        CONSENSUS_SAFE_TIMELY_MIDDLE_SNAPSHOTS=consensus['endpoints']['useful_middle_execution']['physical_snapshots'],
        CONSENSUS_SAFE_TIMELY_MIDDLE_EPISODES=consensus['endpoints']['useful_middle_execution']['episodes'],
        CONSENSUS_SAFE_B_PROGRESS=consensus['endpoints']['safe_B_progress']['status'],
        CONSENSUS_FAILED_B_RECOVERY=consensus['endpoints']['failed_B_recovery']['status'],
        DOMAIN_COMPLETE_ERROR_ACCEPTS=r['methods']['DOMAIN']['complete_error_accepts'],
        COVERAGE_COST_POSITIONS=len(lost),METHOD_DECISIONS_SAVED=r['method_decisions_saved'],
        DIRECT_MIDDLE_B_COMPLETE=r['direct_middle_B']['complete_501'],
        NEW_QP_CALLS_ACTUAL=b['total_QP_calls'],NEW_PHYSICS_STEPS_ACTUAL=b['total_physics_steps'],
        UNKNOWN_QP_RETURNS=r['readback']['unknown_qp'],NUMERICAL_LAUNCHES=1,
        IMPLEMENTATION_IO_REPAIRS_USED=repairs,CURRENT_BANK_READBACK_PASSES=1,
        SOURCE_HEAD_INDEX_UNCHANGED=source.get('unchanged'),FORMAL_SAFETY='NOT_CLAIMED',
        NEW_TYPE_II_CAPACITY_INTERVENTION_PROOF='NOT_CLAIMED',NEXT_EXPERIMENT='NOT_AUTHORIZED')
    textfile(out/'PROTOCOL_STATUS.ini',ini+'\n'+'\n'.join(k+' = '+('TRUE' if v is True else 'FALSE' if v is False else str(v)) for k,v in actual.items())+'\n')
    print({'report':str(out/'REPORT.md'),'endpoint':endpoint,'new_numerical_calls':0})

if __name__=='__main__':main()
