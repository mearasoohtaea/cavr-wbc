"""Single current-run saved-only readback and paired endpoint aggregation."""
from collections import Counter
from datetime import datetime, timezone
import json
import numpy as np
from cavr_wbc.experiments.step43_io import *
from cavr_wbc.experiments.step43_inputs import plans, METHODS, severe_plans
from cavr_wbc.experiments.step43_storage import load_branch, contact_statistics
from cavr_wbc.experiments.step43_identity import fingerprint
from cavr_wbc.experiments.step39_delivery import flatten, counts, safe, physical, physical_terminal, outcome, csv_save
from cavr_wbc.control.step41_terminal_domain import ResidentDomain


def collect(out):
    rows,records,decisions,queries=[],{},[],[]
    contextpath=out/'TEST_CONTEXTS.json'
    contexts={c['context_id']:c for c in load_numeric(contextpath)} if contextpath.exists() else {}
    domain=ResidentDomain(read(out/'TERMINAL_CAL_DOMAIN.json'),sha(out/'TERMINAL_CAL_DOMAIN.json'))
    for p in plans('TEST'):
        folder=out/'TEST'/p['context_id']
        for name in (*p['branch_order'],*([m+'_ACTUAL' for m in METHODS] if p['governor_planned'] else [])):
            path=folder/(name.split('_')[0]+'/ACTUAL' if name.endswith('_ACTUAL') else 'DIRECT/'+name)/'RESULT.json'
            rec=read(path,{})
            row=flatten(p,name,rec,path,out)
            row.update(direction=p['direction'],displacement_m=p['displacement_m'],contact_statistics=rec.get('contact_statistics'))
            rows.append(row);records[row['id']]=rec
        for method in METHODS if p['governor_planned'] else ():
            path=folder/method/'DECISION.json'
            packet=load_numeric(path) if path.exists() else {}
            query=[]
            for gamma in (.5,0.):
                entry=packet.get('actions',{}).get(str(gamma)) or {}
                old=entry.get('decision') or {}; numeric=old.get('numeric') or {}
                observed=entry.get('features28') is not None
                support=entry.get('terminal_domain')
                qr=dict(context_id=p['context_id'],snapshot_id=p['snapshot_id'],episode=p['episode'],
                    method=method,gamma=gamma,observed_causal_query=observed,
                    evaluation_status=entry.get('evaluation_status','NOT_RUN'),
                    accepted=old.get('accepted'),legacy_same_candidate_accepted=entry.get('legacy_accepted_same_candidate',old.get('accepted')),
                    U_D_m=numeric.get('U_D'),U_T=numeric.get('U_T'),terminal_domain=support,
                    domain_counted_in_online_window=support is not None,
                    physical_consensus=entry.get('cal_physical_consensus'),
                    consensus_gate_applied=entry.get('consensus_gate_applied',False),
                    consensus_counted_in_online_window=entry.get('consensus_counted_in_online_window',False),
                    step41_same_candidate_accepted=entry.get('step41_same_candidate_accepted'),
                    rejection_reasons=entry.get('rejection_reasons',[]),
                    original_numeric=numeric,
                    complete_at_ms=entry.get('complete_at_ms'),
                    gates={k:numeric.get(k) for k in ('finite_input','pose_gate','support_gate','distance_gate','calibration_gate','physical_risk_gate') if k in numeric})
                queries.append(qr);query.append(qr)
            R=next(r for r in rows if r['id']==p['context_id']+':'+method+'_ACTUAL')
            chosen=next((q for q in query if q['gamma']==packet.get('selected_gamma')),None)
            decisions.append(dict(context_id=p['context_id'],snapshot_id=p['snapshot_id'],episode=p['episode'],
                method=method,condition=p['health_kind'],fault_leg=p['fault_leg'],direction=p['direction'],
                displacement_m=p['displacement_m'],eligible=bool(contexts.get(p['context_id'],{}).get('eligible')),
                decision_exists=path.exists(),decision_path=relative(path,out),decision_sha256=sha(path) if path.exists() else None,
                status=packet.get('status','NOT_RUN'),command_ready_ms=packet.get('command_ready_ms'),
                phase_latency_ms=packet.get('phase_latency_ms',{}),absolute_deadline=packet.get('absolute_deadline'),prepare_begin=packet.get('prepare_begin'),
                selected_gamma=packet.get('selected_gamma'),selected_command_sent=bool(packet.get('selected_command_sent')),
                overall_deadline_failure=bool(packet.get('overall_deadline_failure')),complete_actual=R['complete_501'],
                safe_actual_6mm=safe(R),physical_pass=R['physical_pass'],terminal_pass=R['terminal_pass'],
                D_m=R['D_m'],terminal_Y=R['terminal_Y'],actual_outcome=outcome(R),
                actual_partial=bool(R['observed'] and not R['complete_501']),timing_qualified_actual=R['timing_qualified'],
                max_feedback_latency_ms=R['max_feedback_latency_ms'],selected_query=chosen,queries=query))
    return rows,records,contexts,decisions,queries


def across(rows):
    qualified=[r for r in rows if r['qualified']]
    ns=len({r['snapshot_id'] for r in qualified}); ne=len({r['episode'] for r in qualified})
    return dict(status='OBSERVED_ACROSS_EPISODES' if ns>=2 and ne>=2 else 'NOT_ESTABLISHED',
        contexts=len(qualified),physical_snapshots=ns,episodes=ne,
        context_ids=[r['context_id'] for r in qualified],pairs=rows)


def paired_endpoints(rows,decisions):
    by={r['id']:r for r in rows}; totals={}; method_pairs=[]
    for method in METHODS:
        ds=[d for d in decisions if d['method']==method]
        actual=[by[d['context_id']+':'+method+'_ACTUAL'] for d in ds]
        unsafe=sum(d['selected_command_sent'] and d['complete_actual'] and not d['safe_actual_6mm'] for d in ds)
        useful=[]; gains=[]; recoveries=[]
        for d,R in zip(ds,actual):
            B=by[d['context_id']+':B']
            middle=bool(d['selected_command_sent'] and d['selected_gamma']==.5 and safe(R) and R['timing_qualified'])
            gain=None if R['progress02_04_m'] is None or B['progress02_04_m'] is None else R['progress02_04_m']-B['progress02_04_m']
            identity={k:d[k] for k in ('context_id','snapshot_id','episode','condition','fault_leg','direction','displacement_m')}
            identity['tick']=R['tick']
            common=dict(**identity,method=method,recognized_middle_safe_timely=middle,
                recognized_actual_id=R['id'],matched_direct_B_id=B['id'],
                same_source_not_same_packet=True,progress_gain_m=gain,
                B_complete=B['complete_501'],B_safe=safe(B),B_physical_pass=B['physical_pass'],
                B_timing_qualified=B['timing_qualified'],B_capacity99_precedes_failure=B['capacity_precedes_failure'],
                actual_partial=d['actual_partial'],selected=d['selected_command_sent'])
            useful.append({**common,'qualified':middle})
            gains.append({**common,'qualified':bool(middle and safe(B) and gain is not None and gain>0)})
            recoveries.append({**common,'qualified':bool(middle and B['complete_501'] and B['physical_pass'] is False)})
        endpoints={name:across(pairs) for name,pairs in
            (('useful_middle_execution',useful),('safe_B_progress',gains),('failed_B_recovery',recoveries))}
        unresolved_sent = sum(d['selected_command_sent'] and not (d['complete_actual'] and d['timing_qualified_actual']) for d in ds)
        if unsafe:
            for value in endpoints.values():value['status']='FAIL_COMPLETE_ERROR_ACCEPT'
        elif unresolved_sent:
            for value in endpoints.values():value['status']='NOT_ESTABLISHED_INCOMPLETE_SENT'
        for value in endpoints.values():
            value['unresolved_sent_trajectories']=int(unresolved_sent)
        totals[method]=dict(planned=72,saved=sum(d['decision_exists'] for d in ds),eligible=sum(d['eligible'] for d in ds),
            recognized=sum(d['selected_command_sent'] for d in ds),ABSTAIN=sum(d['status']=='ABSTAIN' for d in ds),
            late=sum(d['overall_deadline_failure'] for d in ds),
            gamma_counts=dict(Counter(str(d['selected_gamma']) for d in ds if d['selected_command_sent'])),
            complete=sum(d['complete_actual'] for d in ds),physical=sum(physical(r) for r in actual),
            terminal=sum(r['complete_501'] and bool(r['terminal_pass']) for r in actual),
            local=sum(r['complete_501'] and r['D_m'] is not None and r['D_m']<=.006 for r in actual),
            safe=sum(safe(r) for r in actual),partial=sum(d['actual_partial'] for d in ds),
            budget_not_evaluated_candidates=sum(q['evaluation_status']=='NOT_EVALUATED_BUDGET' for d in ds for q in d['queries']),
            unresolved_sent_trajectories=int(unresolved_sent),complete_error_accepts=unsafe,zero_complete_error_target='FAIL' if unsafe else
                'FINITE_ZERO_COMPLETE_ERRORS' if any(d['complete_actual'] for d in ds) else 'NO_ACTUAL_EVIDENCE',
            all_abstain_or_B=not any(d['selected_command_sent'] and d['selected_gamma']==.5 for d in ds),endpoints=endpoints)
    for p in severe_plans():
        ds={m:next(d for d in decisions if d['context_id']==p['context_id'] and d['method']==m) for m in METHODS}
        L,D=ds['DOMAIN'],ds['CONSENSUS']
        qL,qD=L['selected_query'] or {},D['selected_query'] or {}
        method_pairs.append(dict(context_id=p['context_id'],snapshot_id=p['snapshot_id'],episode=p['episode'],
            condition=p['health_kind'],direction=p['direction'],DOMAIN=L,CONSENSUS=D,
            same_source_not_same_packet=True,
            coverage_cost_consensus_abstains_DOMAIN_complete_safe=bool(not D['selected_command_sent'] and L['selected_command_sent'] and L['safe_actual_6mm']),
            CONSENSUS_unapplied_true_safety='UNKNOWN' if not D['selected_command_sent'] else 'MEASURED',
            consensus_actual_set_subset_of_domain_not_claimed=True))
    return dict(methods=totals,method_pairs=method_pairs,
        coverage_cost_positions=sum(p['coverage_cost_consensus_abstains_DOMAIN_complete_safe'] for p in method_pairs),
        error_reduction_claim_allowed=bool(totals['DOMAIN']['complete_error_accepts']>0 and
            totals['CONSENSUS']['complete_error_accepts']<totals['DOMAIN']['complete_error_accepts']),
        formal_safety_or_population_error_probability_claim=False,new_Type_II_intervention_claim=False)

def readback(out, rows, records, contexts, decisions):
    from cavr_wbc.control.step34_margin import labels
    from cavr_wbc.experiments.step29_sim import _json_safe
    issues, loaded, grids, capacity = [], 0, 0, []
    tasks=[]
    if len(rows)!=396 or any(not row['result_exists'] for row in rows):
        issues.append('all 396 planned result slots must have a status record')
    if len(decisions)!=144 or any(not d['decision_exists'] for d in decisions):
        issues.append('all 144 planned decisions must be saved')
    source_identities = {}
    for c in contexts.values():
        if 'state' not in c:
            continue
        digest = fingerprint({key: c.get(key) for key in ('state', 'current_reference', 'source_external_reference',
            'nominal_q_init', 'nominal_d_m', 'nominal_b_used', 'backup_anchor_q_init', 'previous_command_identity')})
        previous = source_identities.setdefault(c['snapshot_id'], digest)
        if previous != digest:
            issues.append(c['context_id'] + ':same-state intervention source mismatch')
        health = np.ones(len(c['health_vector']))
        if c['faulted_actuator_index'] is not None:
            health[c['faulted_actuator_index']] = c['faulted_health']
        if not np.array_equal(health, c['health_vector']):
            issues.append(c['context_id'] + ':health mapping')
    for row in rows:
        if not row['observed']:
            continue
        rec = records[row['id']]
        directory = (out / row['result_path']).parent
        if sha(directory / 'actual.npz') != rec['artifact']['sha256']:
            issues.append(row['id'] + ':fact hash')
        for ext, key in (('json', 'json_sha256'), ('npz', 'npz_sha256')):
            if sha(directory / ('controls.' + ext)) != rec['controls_numeric'][key]:
                issues.append(row['id'] + ':control hash')
        branch = load_branch(directory)
        context = contexts[row['context_id']]
        task=task_response(branch,context)
        row['task_response']=task['summary'];tasks.append(dict(id=row['id'],**task))
        lab = labels(branch, _json_safe(context))
        for key in ('complete', 'full_501_grid', 'original_physical', 'original_terminal', 'observed_original_physical_failure'):
            if lab.get(key) != rec['label'].get(key):
                issues.append(row['id'] + ':label ' + key)
        for key in ('D_m', 'Y'):
            a, b = lab.get(key), rec['label'].get(key)
            if (a is None) != (b is None) or (a is not None and not np.allclose(a, b, rtol=0, atol=1e-12, equal_nan=True)):
                issues.append(row['id'] + ':numeric label ' + key)
        if contact_statistics(branch) != rec['contact_statistics']:
            issues.append(row['id'] + ':contact descriptive facts')
        if not np.array_equal(branch['health_vector'], context['health_vector']):
            issues.append(row['id'] + ':plant/control health')
        if row['complete_501']:
            grids += 1
            if branch['counts']['physical_steps'] != 500 or len(branch['physics_trajectory']) + 1 != 501 or len(branch['checkpoints']) != 21:
                issues.append(row['id'] + ':500/501/21 time grid')
        ix = context.get('faulted_actuator_index')
        for r in branch['controls']:
            interface = r.get('capacity_interface') or {}
            tau, cap = r.get('tau_applied'), interface.get('effective_capacity_nm')
            raw, sent = interface.get('tau_raw'), interface.get('tau_sent')
            applied = tau is not None
            record = {'id': row['id'], 'context_id': row['context_id'], 'branch': row['branch'],
                'snapshot_id': row['snapshot_id'], 'episode': row['episode'], 'condition': row['condition'],
                'slot': r['slot'], 'time_s': r['slot'] * .02,
                'stage': 'PREHOLD' if r['slot'] == 0 else 'FIRST_ACTION' if r['slot'] == 1 else 'FEEDBACK',
                'actual_applied': applied, 'fault_name': context.get('faulted_actuator_name'),
                'actual_fault_tau_nm': None if ix is None or not applied else float(tau[ix]),
                'effective_fault_capacity_nm': None if ix is None or cap is None else float(cap[ix]),
                'actual_tau_capacity_ratio': None if ix is None or not applied or cap is None else abs(float(tau[ix])) / float(cap[ix]),
                'candidate_fault_tau_raw_nm': None if ix is None or raw is None else float(raw[ix]),
                'candidate_fault_tau_sent_nm': None if ix is None or sent is None else float(sent[ix]),
                'fault_clipped': None if ix is None or raw is None or sent is None else bool(raw[ix] != sent[ix]),
                'antiwindup_frozen': bool(r.get('integral_record') and not r['integral_record'].get('updated', False)),
                'latency_ms': r.get('latency_ms')}
            record['actual_99percent'] = bool(record['actual_tau_capacity_ratio'] is not None and record['actual_tau_capacity_ratio'] >= .99)
            capacity.append(record)
        loaded += 1
    events = [json.loads(line) for line in (out / 'STEP43_LEDGER.jsonl').read_text(encoding='utf-8').splitlines()]
    starts = [e for e in events if e['event'] == 'QP_START']
    returns = [e for e in events if e['event'] == 'QP_RETURN']
    raw = [e for e in events if e['event'] == 'RAW_QP_SAVED']
    ix = lambda a: sorted(e['global_qp_index'] for e in a)
    if ix(starts) != ix(returns) or ix(starts) != ix(raw) or ix(starts) != list(range(1, len(starts) + 1)):
        issues.append('QP START/RETURN/raw identity')
    for e in raw:
        path = out / e['path']
        if sha(path) != e['json_sha256'] or sha(path.with_suffix('.npz')) != e['npz_sha256']:
            issues.append(e['path'] + ':raw hash')
    reservations = [e for e in events if e['event'] == 'PREFIX_NATIVE_START']
    completed = [e for e in events if e['event'] == 'PREFIX_NATIVE_RETURN']
    if sorted(e['reservation_id'] for e in reservations) != sorted(e['reservation_id'] for e in completed):
        issues.append('prediction reservations/returns')
    budget = read(out / 'RUN_FINISHED.json')['budget']
    if (budget['total_QP_calls'] != len(starts) or budget['QP_returns'] != len(returns)
            or budget['multioutput_estimator_fits'] or budget['physical_risk_head_fits']
            or budget['new_CAL_branches'] or budget['total_QP_calls'] > 30000 or budget['total_physics_steps'] > 300000):
        issues.append('cumulative counts/budgets/zero fit/CAL')
    checkpoint = read(out / 'SCREEN_IDENTITY_END.json')
    if not checkpoint['acceptance_algorithm_unchanged']:
        issues.append('acceptance algorithm source identity')
    if not checkpoint['full_model_CAL_TRAIN_threshold_identity_unchanged']:
        issues.append('frozen screen groups/predictor/threshold identity')
    freeze = read(out / 'RUNTIME_FREEZE.json')
    for name, digest in {**freeze['runtime_sha256'], **freeze['model_checkout_bytes']}.items():
        if sha(OUTPUT_ROOT_D / name) != digest:
            issues.append(name + ':frozen checkout byte hash')
    manifest = read(out / 'PROTOCOL_AND_MANIFEST.json')
    if sha(NATIVE_DLL) != manifest['native_dll_sha256']:
        issues.append('native DLL hash')
    attempts = [json.loads(line) for line in (out / 'ATTEMPT_LEDGER.jsonl').read_text().splitlines()]
    for p in plans('TEST'):
        cid=p['context_id']
        for method in METHODS if p['governor_planned'] else ():
            d=next(row for row in decisions if row['context_id']==cid and row['method']==method)
            ev=next((e for e in attempts if e['event']=='DECISION_IMMUTABLE' and e['context_id']==cid and e.get('method')==method),None)
            if d['decision_exists'] and (ev is None or ev['decision_sha256']!=d['decision_sha256']):
                issues.append(cid+':'+method+':immutable decision')
        if not p['governor_planned']:
            positions=[i for i,e in enumerate(attempts) if e.get('context_id')==cid and e.get('kind')=='TEST_DIRECT']
            peers=[i for i,e in enumerate(attempts) if e['event']=='BOTH_DECISIONS_IMMUTABLE' and e.get('context_id') in (p['snapshot_id']+'_FR_THIGH15',p['snapshot_id']+'_RR_THIGH15')]
            if positions and (len(peers)!=2 or max(peers)>=min(positions)):issues.append(cid+':control before both severe decisions')
            continue
        both=next((e for e in attempts if e['event']=='BOTH_DECISIONS_IMMUTABLE' and e['context_id']==cid),None)
        future=[i for i,e in enumerate(attempts) if e.get('context_id')==cid and e.get('kind') in ('RECOGNIZED_ACTUAL','TEST_DIRECT')]
        if both:
            expected=list(METHODS if next(i for i,x in enumerate(severe_plans()) if x['context_id']==cid)%2==0 else METHODS[::-1])
            if both['order']!=expected or (future and attempts.index(both)>=min(future)):
                issues.append(cid+':paired decision order')
            identities=both['owner_identities']
            if identities['DOMAIN'] is not None and identities['DOMAIN']==identities['CONSENSUS']:
                issues.append(cid+':same resident owner across methods')
        elif future:
            issues.append(cid+':future before both decisions')
    if not checkpoint['terminal_domain_unchanged']:
        issues.append('terminal domain resident table hash')
    # Current evidence uses frozen bundle arrays, never historical trajectory banks.
    from cavr_wbc.experiments.step43_identity import load_frozen
    from cavr_wbc.control.step42_physical_consensus import check_consensus
    bundle,_=load_frozen()
    for d in decisions:
        for q in d['queries']:
            saved=q.get('physical_consensus')
            if saved is None:
                continue
            expected=check_consensus(bundle,q['gamma'],'thigh',q['original_numeric'])
            if fingerprint(saved)!=fingerprint(expected):
                issues.append(q['context_id']+':'+d['method']+':CAL neighbor evidence')
            idx=q['original_numeric'].get('local_cal_indices')
            if expected['local_cal_indices'] is not None and not np.array_equal(idx,expected['local_cal_indices']):
                issues.append(q['context_id']+':original four indices altered')
            if q['accepted'] and d['method']=='CONSENSUS' and not (q.get('step41_same_candidate_accepted') and saved['accepted']):
                issues.append(q['context_id']+':accepted without DOMAIN and consensus')
        if d.get('prepare_begin') is not None and abs(d['absolute_deadline']-d['prepare_begin']-.020)>1e-10:
            issues.append(d['context_id']+':deadline reset')
    if sha(out/'TERMINAL_CAL_DOMAIN.json')!=read(out/'TERMINAL_CAL_DOMAIN_FREEZE.json')['sha256']:
        issues.append('unchanged domain byte identity')
    write(out/'TASK_RESPONSE_ALL.json',tasks)
    write(out / 'CAPACITY_EVENTS_FULL.json', capacity)
    csv_save(out / 'CAPACITY_EVENTS_FULL.csv', capacity)
    result = {'status': 'VERIFIED' if not issues else 'EVIDENCE_ERROR', 'issues': issues,
        'observed_banks_read_once': loaded, 'complete_grids_verified': grids,
        'qp_starts': len(starts), 'qp_returns': len(returns), 'raw_qp_shards': len(raw),
        'unknown_qp': len(starts) - len(returns), 'source_snapshot_fingerprints': source_identities,
        'full_frozen_screen_identity_unchanged': checkpoint['full_model_CAL_TRAIN_threshold_identity_unchanged'],
        'label_tolerance': 1e-12, 'new_optimizer_calls': 0, 'new_physics_steps': 0,
        'new_fits': 0, 'scope': 'STEP43_CURRENT_RUN_ONLY', 'timestamp_utc': datetime.now(timezone.utc).isoformat()}
    write(out / 'CURRENT_RUN_READBACK.json', result)
    return result



def task_response(branch,c):
    from cavr_wbc.control.step20_task_reference import reference
    dense=([branch['initial_fact']] if branch.get('initial_fact') else [])+branch.get('physics_trajectory',[])
    valid=[f for f in dense if 'qpos' in f and 'subtree_com' in f]
    if not valid:return dict(summary={'available':False,'complete':False},series=[])
    origin=float(valid[0]['subtree_com'][0]);base0=float(valid[0]['qpos'][0]);sign=c['direction']
    p0=float(c['nominal_q_init'][0]);d=float(c['nominal_d_m'])
    series=[]
    for f in valid:
        ref=reference(p0,d,c['source_tick']*.02+f['time_s'])
        series.append(dict(time_s=f['time_s'],directed_subtree_COM_displacement_m=sign*(f['subtree_com'][0]-origin),
            directed_base_displacement_m=sign*(f['qpos'][0]-base0),base_task_error_m=f['qpos'][0]-ref['p_ref_m'],
            external_base_reference_m=ref['p_ref_m']))
    ts=np.asarray([f['time_s'] for f in series]);err=np.asarray([f['base_task_error_m'] for f in series])
    last=series[-1]
    summary=dict(available=True,complete=bool(branch['status']=='COMPLETE' and len(valid)==501),
        observed_end_time_s=last['time_s'],terminal_directed_subtree_COM_displacement_m=last['directed_subtree_COM_displacement_m'],
        terminal_directed_base_displacement_m=last['directed_base_displacement_m'],terminal_base_task_error_m=last['base_task_error_m'],
        max_abs_base_task_error_m=float(np.max(np.abs(err))),
        time_mean_abs_base_task_error_m=float(np.sum((np.abs(err)[1:]+np.abs(err)[:-1])*.5*np.diff(ts))/ts[-1]) if ts[-1]>0 else None,
        observed_directed_COM_range_m=[min(v['directed_subtree_COM_displacement_m'] for v in series),max(v['directed_subtree_COM_displacement_m'] for v in series)],
        metric_scope='DESCRIPTIVE_1S_EXTERNAL_QUINTIC_BASE_TASK_REFERENCE; evaluator and anchor unchanged')
    return dict(summary=summary,series=series)

def confirmation(rows,decisions,evidence,complete_run):
    from cavr_wbc.experiments.step43_mechanisms import h2_gate,type_ii_only,distribution
    paired=paired_endpoints(rows,decisions);by={r['id']:r for r in rows}
    matrices={};purpose_rows={};h={}
    for method in METHODS:
        ds=[d for d in decisions if d['method']==method];totals=paired['methods'][method]
        h1=('FAIL_COMPLETE_ERROR_ACCEPT' if totals['complete_error_accepts'] else
            'NOT_ESTABLISHED' if totals['unresolved_sent_trajectories'] or evidence['unknown_qp'] or evidence['status']!='VERIFIED' or not complete_run else
            'FINITE_ZERO_COMPLETE_ERRORS' if totals['recognized'] else 'NO_ACTUAL_EVIDENCE')
        gain=totals['endpoints']['safe_B_progress']['pairs'];rec=totals['endpoints']['failed_B_recovery']['pairs']
        qualified=[dict(a,qualified=bool(a['qualified'] or b['qualified'])) for a,b in zip(gain,rec)]
        gate=h2_gate(qualified)
        h[method]=dict(H1=h1,H2='CONFIRMED' if h1=='FINITE_ZERO_COMPLETE_ERRORS' and gate['pass_gate'] else 'NOT_ESTABLISHED',
            H2_gate=gate,H1_pass=h1=='FINITE_ZERO_COMPLETE_ERRORS')
        support=[]
        for direction in (1,-1):
            for leg in ('FR','RR'):
                subset=[p for p in qualified if p['direction']==direction and p['fault_leg']==leg]
                support.append(dict(direction=direction,fault_leg=leg,planned=len(subset),**distribution(subset),
                    support_status='OBSERVED' if any(p['qualified'] for p in subset) else 'NOT_CONFIRMED'))
        matrices[method]=support
        opportunities=[p for p in severe_plans() if safe(by[p['context_id']+':MIDDLE']) and by[p['context_id']+':MIDDLE']['timing_qualified']]
        safe_actual_middle=totals['endpoints']['useful_middle_execution']['pairs']
        numerator=[p for p in opportunities if any(q['context_id']==p['context_id'] and q['qualified'] for q in safe_actual_middle)]
        h[method]['denominators']=dict(safe_timely_useful_middle=sum(p['qualified'] for p in safe_actual_middle),
            H2_use_qualified_middle=sum(p['qualified'] for p in qualified),planned_severe_contexts=72,
            full_safe_timing_qualified_direct_middle_opportunities=len(opportunities),recognized_middle_in_opportunities=len(numerator),
            incomplete_direct_middle=sum(not by[p['context_id']+':MIDDLE']['complete_501'] for p in severe_plans()),
            full_safe_but_untimely_direct_middle=sum(safe(by[p['context_id']+':MIDDLE']) and not by[p['context_id']+':MIDDLE']['timing_qualified'] for p in severe_plans()),
            opportunity_recall=len(numerator)/len(opportunities) if opportunities else None,unapplied_candidate_true_safety='UNKNOWN')
        purpose=[]
        for d,a,b in zip(ds,gain,rec):
            A=by[d['context_id']+':'+method+'_ACTUAL'];B=by[d['context_id']+':B'];M=by[d['context_id']+':MIDDLE']
            bv=B['progress02_04_m'];av=A['progress02_04_m']
            purpose.append(dict(**{k:d[k] for k in ('context_id','snapshot_id','episode','fault_leg','direction','displacement_m')},
                tick=B['tick'],selected_middle=bool(d['selected_command_sent'] and d['selected_gamma']==.5),
                safe_B_progress=a['qualified'],failed_B_recovery=b['qualified'],useful_qualified=a['qualified'] or b['qualified'],
                progress_ACTUAL_m=av,progress_B_m=bv,absolute_gain_m=a['progress_gain_m'],
                relative_gain=None if bv in (None,0) or av is None else (av-bv)/bv,
                ACTUAL_outcome=outcome(A),B_outcome=outcome(B),direct_middle_outcome=outcome(M),
                actual_timing_qualified=A['timing_qualified'],B_timing_qualified=B['timing_qualified'],
                actual_task_response=A.get('task_response'),B_task_response=B.get('task_response'),
                query_states=[dict(gamma=q['gamma'],evaluation_status=q['evaluation_status'],rejection_reasons=q['rejection_reasons']) for q in d['queries']]))
        purpose_rows[method]=purpose
    mech=type_ii_only(rows,decisions,severe_plans())
    healthy_ids={p['healthy_shared_control_id'] for p in mech['direct_TYPE_II']['pairs']}
    mech['healthy_B_planned_shared_positions']=len(healthy_ids)
    mech['healthy_B_real_computations']=sum(by[cid]['observed'] for cid in healthy_ids)
    actuals=[r for r in rows if r['branch'].endswith('_ACTUAL') and r['observed']]
    misses=sum(d['overall_deadline_failure'] for d in decisions)+sum(r['feedback_deadline_misses'] for r in actuals)
    rt=dict(status='REALTIME_DEADLINE_MISS_OBSERVED' if misses else 'FINITE_PLANNED_WINDOWS_WITHOUT_MISS',
        planned_decision_deadline_misses=sum(d['overall_deadline_failure'] for d in decisions),
        recognized_feedback_deadline_misses=sum(r['feedback_deadline_misses'] for r in actuals),
        hard_realtime_deployment_verified=False)
    for method in METHODS:
        dd=[d for d in decisions if d['method']==method]
        vals=[d['command_ready_ms'] for d in dd if d['command_ready_ms'] is not None]
        sent=[d['command_ready_ms'] for d in dd if d['selected_command_sent']]
        rt[method]=dict(planned=72,planned_command_ready_min_ms=min(vals) if vals else None,
            planned_command_ready_max_ms=max(vals) if vals else None,sent_command_ready_max_ms=max(sent) if sent else None,
            decision_deadline_misses=sum(d['overall_deadline_failure'] for d in dd),internal_budget_not_evaluated=paired['methods'][method]['budget_not_evaluated_candidates'],
            recognized_feedback_max_ms=max([r['max_feedback_latency_ms'] for r in actuals if r['branch']==method+'_ACTUAL' and r['max_feedback_latency_ms'] is not None],default=None))
    primary=h['CONSENSUS']
    status=('INCOMPLETE' if not complete_run else 'FAIL_COMPLETE_ERROR_ACCEPT' if primary['H1']=='FAIL_COMPLETE_ERROR_ACCEPT' else
        'SUPPORTED_SCOPE_USEFUL_EXECUTION_CONFIRMED' if primary['H2']=='CONFIRMED' else 'NOT_ESTABLISHED')
    closure=mech['online_TYPE_II']['online_closure']=='TIMING_QUALIFIED_MECHANISM'
    return dict(status=status,H1_H2_by_method=h,direction_leg_support=matrices,
        purpose_rows=purpose_rows,method_comparison=paired,TypeII=mech,
        capacity_closure_status='CAPACITY_BACKUP_RECOVERY_CLOSURE_OBSERVED' if closure else 'CAPACITY_RECOVERY_OPEN',
        realtime=rt,finite_deterministic_source_scope_not_IID=True)

def summarize(out=output()):
    if not (out/'RUN_FINISHED.json').exists():raise RuntimeError('wait for numerical process finish')
    if (out/'CURRENT_RUN_READBACK.json').exists() or (out/'STEP43_RESULT.json').exists():raise FileExistsError('one current-path readback only')
    rows,records,contexts,decisions,queries=collect(out)
    evidence=readback(out,rows,records,contexts,decisions)
    return emit_results(out,rows,decisions,queries,evidence)

def finalize_saved(out=output()):
    """Resume metadata aggregation only after completed readback; never reload banks."""
    if not (out/'CURRENT_RUN_READBACK.json').exists() or (out/'STEP43_RESULT.json').exists():
        raise FileExistsError('requires completed readback and absent final result')
    rows,records,contexts,decisions,queries=collect(out)
    tasks={v['id']:v['summary'] for v in read(out/'TASK_RESPONSE_ALL.json')}
    for row in rows:
        if row['id'] in tasks:row['task_response']=tasks[row['id']]
    return emit_results(out,rows,decisions,queries,read(out/'CURRENT_RUN_READBACK.json'))

def emit_results(out,rows,decisions,queries,evidence):
    complete_run=read(out/'RUN_FINISHED.json')['status']=='COMPLETED'
    conclusions=confirmation(rows,decisions,evidence,complete_run)
    result=dict(schema='STEP43_SAVED_ONLY_RESULT_V1',run_id=out.name,run=read(out/'RUN_FINISHED.json'),readback=evidence,
        task_execution_status='COMPLETE' if complete_run and evidence['status']=='VERIFIED' and all(r['result_exists'] for r in rows) and all(d['decision_exists'] for d in decisions) else 'INCOMPLETE',
        confirmation=conclusions,methods=conclusions['method_comparison']['methods'],
        direct=counts([r for r in rows if not r['branch'].endswith('_ACTUAL')]),
        actual_by_method={m:counts([r for r in rows if r['branch']==m+'_ACTUAL']) for m in METHODS},
        planned_positions=396,method_decisions_planned=144,method_decisions_saved=sum(d['decision_exists'] for d in decisions),
        physical_snapshots=36,reference_episodes=12,health_contexts=180,
        terminal_domain_sha256=sha(out/'TERMINAL_CAL_DOMAIN.json'),numerical_launches=1,result_based_retries=0,new_fits=0,new_CAL=0,new_acceptance_gates=0,
        source_acceptance_unchanged=read(out/'SCREEN_IDENTITY_END.json')['acceptance_algorithm_unchanged'],
        implementation_IO_repairs=len(list((out/'repairs').glob('IMPLEMENTATION_REPAIR_*.json'))))
    write(out/'ALL_PLANNED_RESULTS.json',rows);csv_save(out/'ALL_BRANCH_RESULTS.csv',rows)
    write(out/'ALL_METHOD_DECISIONS.json',decisions);write(out/'ALL_CAUSAL_QUERIES.json',queries)
    write(out/'CAL_NEIGHBOR_EVIDENCE.json',queries)
    write(out/'CAL_NEIGHBOR_CONFLICTS.json',[q for q in queries if q['evaluation_status']=='EVALUATED' and q.get('physical_consensus') and not q['physical_consensus']['accepted']])
    write(out/'SAME_SOURCE_METHOD_PAIRS.json',conclusions['method_comparison']['method_pairs'])
    write(out/'DIRECTION_LEG_SUPPORT.json',conclusions['direction_leg_support'])
    for method in METHODS:
        csv_save(out/(method+'_TASK_USE_PAIRS.csv'),conclusions['purpose_rows'][method])
        csv_save(out/(method+'_DECISIONS.csv'),[{k:v for k,v in d.items() if k not in ('queries','selected_query')} for d in decisions if d['method']==method])
    write(out/'TYPE_II_ONLY.json',conclusions['TypeII'])
    for name in ('direct_TYPE_II','online_TYPE_II'):csv_save(out/(name+'_ALL_PAIRS.csv'),conclusions['TypeII'][name]['pairs'])
    write(out/'LATENCY.json',conclusions['realtime'])
    write(out/'STEP43_RESULT.json',result)
    print(json.dumps(dict(execution=result['task_execution_status'],confirmation=conclusions['status'],capacity=conclusions['capacity_closure_status'],
        realtime=conclusions['realtime'],methods={m:{k:v for k,v in x.items() if k!='endpoints'} for m,x in result['methods'].items()},
        readback=evidence),ensure_ascii=False))
if __name__=='__main__':summarize()
