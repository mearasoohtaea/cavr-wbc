"""Two saved-only SciPilot observation plots; preview, visual check, then export."""
from pathlib import Path
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from PIL import Image
from cavr_wbc.experiments.step43_io import output,read,write,sha
SKILL=Path('C:/Users/ZhuanZ（无密码）/.codex/skills/scipilot-figure/scripts')
sys.path.insert(0,str(SKILL))
from setup_style import setup_style
from profile_data import profile_data
from visual_qa import audit_layout,render_preview
from export_figure import export_figure
from check_figure import check_figure
COL={'DOMAIN':'#0072B2','CONSENSUS':'#009E73','B':'#555555','error':'#D55E00'}
MARK={'DOMAIN':'o','CONSENSUS':'s','B':'x'}
EXPORT='--export' in sys.argv

def verify_exported_fonts():
    """Resolve Type0 descendant embedding; generic checker misses this level."""
    from pypdf import PdfReader
    home=output()/'figures';result={}
    for path in sorted(home.glob('FIG43_*.pdf')):
        fonts=[]
        for page in PdfReader(str(path)).pages:
            for name,ref in page['/Resources']['/Font'].items():
                font=ref.get_object()
                children=font.get('/DescendantFonts')
                descs=[x.get_object() for x in children] if children else [font]
                embedded=[]
                for child in descs:
                    descriptor=child.get('/FontDescriptor')
                    descriptor=descriptor.get_object() if descriptor else {}
                    embedded.append(any(k in descriptor for k in ('/FontFile','/FontFile2','/FontFile3')))
                fonts.append(dict(resource=str(name),base_font=str(font.get('/BaseFont')),subtype=str(font.get('/Subtype')),
                    descendants_embedded=embedded,type3=str(font.get('/Subtype'))=='/Type3'))
        result[path.name]=dict(fonts=fonts,all_embedded=all(all(f['descendants_embedded']) and not f['type3'] for f in fonts))
    write(home/'PDF_DESCENDANT_FONT_VERIFICATION.json',result)
    if not all(v['all_embedded'] for v in result.values()):raise RuntimeError('PDF font embedding')
    print('All PDF Type0 descendant FontFile2 streams embedded; no Type3 fonts.')

def finish(fig,home,name,size):
    fig.set_size_inches(*size)
    issues=audit_layout(fig)
    render_preview(fig,str(home/(name+'_preview.png')),dpi=180)
    with Image.open(home/(name+'_preview.png')) as image:
        image.convert('L').save(home/(name+'_gray_preview.png'))
    write(home/(name+'_LAYOUT.json'),dict(issues=issues,exported=False,size_inches=size))
    if issues:
        raise RuntimeError('layout must be corrected before exporting: '+str(issues))
    if EXPORT:
        paths=export_figure(fig,str(home/name),formats=['pdf','svg','png'],size_inches=size,
            dpi=600,tight=False,grayscale_preview=False)
        with Image.open(home/(name+'.png')) as image:
            image.convert('L').save(home/(name+'_grayscale.png'),dpi=(600,600))
        checks={}
        for path in paths:
            found,info=check_figure(path,min_dpi=599.9,target_inches=size)
            checks[Path(path).name]=dict(issues=found,info=info,
                Type0_embedding_resolved_separately=True)
        write(home/(name+'_LAYOUT.json'),dict(issues=issues,exported=True,size_inches=size,format_checks=checks))
    plt.close(fig)


def save(fig,name,size):
    finish(fig,output()/'figures',name,size)
def figure_decisions(ds,ps):
    lookup={(d['context_id'],d['method']):d for d in ds}
    fig,axs=plt.subplots(3,2,figsize=(7.16,9.8))
    maximum=max(22,max(d['command_ready_ms'] or 0 for d in ds)*1.1)
    for block,ax in enumerate(axs.flat):
        sub=ps[block*12:(block+1)*12]
        for i,p in enumerate(sub):
            for j,m in enumerate(('DOMAIN','CONSENSUS')):
                d=lookup[(p['context_id'],m)];y=i+(-.30 if j==0 else .30);send=d['selected_command_sent']
                code=('M' if d['selected_gamma']==.5 else 'B') if send else 'A'
                if send and not d['complete_actual']:code+='?'
                elif send and not d['safe_actual_6mm']:code+='!'
                color=COL['error'] if '!' in code else COL[m]
                ax.scatter(d['command_ready_ms'],y,s=18,marker=MARK[m],
                    facecolors=color if send else 'none',edgecolors=color,lw=.75)
                ax.text(d['command_ready_ms']+.5,y,code,va='center',fontsize=7.5,color=color)
        names=[f"{block*12+i+1:02d} E{int(p['episode'].split('_')[-1]):02d} {p['displacement_m']*1000:+g} {p['tick']}{p['fault_leg']}" for i,p in enumerate(sub)]
        ax.set(yticks=range(12),yticklabels=names,ylim=(11.8,-.8),xlim=(0,maximum),xticks=[0,10,20])
        ax.tick_params(axis='y',labelsize=7.5)
        ax.axvline(20,color='black',ls='--',lw=.7)
        ax.grid(axis='y',color='.9',lw=.4)
        ax.set_title(f"({chr(97+block)}) C{block*12+1:02d}-{block*12+12:02d}",loc='left',fontsize=8,fontweight='bold')
        if block>=4:ax.set_xlabel('Complete decision latency (ms)')
    handles=[Line2D([],[],marker=MARK[m],color=COL[m],ls='',label=m) for m in ('DOMAIN','CONSENSUS')]
    fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.57,.048),ncol=2,frameon=False,fontsize=8)
    fig.text(.5,.018,'All 144 decisions. M/B = sent; A = unapplied; ! = full error; ? = partial. Dashed = 20 ms.',ha='center',fontsize=7.5)
    fig.subplots_adjust(left=.26,right=.965,bottom=.15,top=.955,hspace=.38,wspace=1.5)
    save(fig,'FIG43_1_ALL_DECISIONS',(7.16,9.8))

def figure_task(r):
    fig,axs=plt.subplots(4,2,figsize=(7.16,9.8))
    purpose=r['confirmation']['purpose_rows'];ticks={34:0,37:1,41:2}
    for row,(direction,leg) in enumerate(((1,'FR'),(1,'RR'),(-1,'FR'),(-1,'RR'))):
        gain,cover=axs[row]
        for j,m in enumerate(('DOMAIN','CONSENSUS')):
            selected=[p for p in purpose[m] if p['direction']==direction and p['fault_leg']==leg]
            for p in selected:
                x=abs(p['displacement_m'])*1000+(-.045 if j==0 else .045)
                value=p['absolute_gain_m'];safe=p['ACTUAL_outcome']=='SAFE_6MM' and p['actual_timing_qualified']
                if value is not None:
                    marker={34:'^',37:'o',41:'s'}[p['tick']]
                    gain.scatter(x,value*1000,s=24,marker=marker,facecolors=COL[m] if m=='DOMAIN' else 'none',
                        edgecolors=COL[m],lw=.75)
                    if not safe:gain.plot(x,value*1000,'x',color=COL['error'],ms=5)
                code=('M' if p['selected_middle'] else 'B') if p['ACTUAL_outcome']=='SAFE_6MM' else 'A' if p['ACTUAL_outcome']=='NOT_RUN' else 'P' if p['ACTUAL_outcome']=='NUMERICAL_INCOMPLETE' else 'F'
                cover.text(x,ticks[p['tick']]+(-.18 if j==0 else .18),code,
                    fontsize=8,ha='center',va='center',color=COL[m])
        gain.axhline(0,color='.5',lw=.65)
        gain.set_title(f"({chr(97+row*2)}) {'+' if direction>0 else '-'} / {leg}: task",loc='left',fontsize=8,fontweight='bold')
        cover.set_title(f"({chr(98+row*2)}) {'+' if direction>0 else '-'} / {leg}: coverage",loc='left',fontsize=8,fontweight='bold')
        gain.set_ylabel('First-action gain vs B\n(mm, 0.02-0.04 s)')
        cover.set(yticks=[0,1,2],yticklabels=['t34','t37','t41'],ylim=(-.55,2.55))
        gain.set_xlim(61.4,68.1);cover.set_xlim(61.4,68.1)
        for ax in (gain,cover):
            ax.set_xticks([61.75,62.75,64.25,64.75,65.25,67.75]);ax.grid(axis='x',color='.92',lw=.4)
            ax.tick_params(axis='x',rotation=90,labelsize=7.5)
        if row==3:
            gain.set_xlabel('|Reference target| (mm)')
            cover.set_xlabel('|Reference target| (mm)')
    handles=[Line2D([],[],marker='o',color=COL[m],mfc=COL[m] if m=='DOMAIN' else 'none',ls='',label=m) for m in ('DOMAIN','CONSENSUS')]
    handles+=[Line2D([],[],marker=mark,color='black',ls='',label='tick '+str(t)) for t,mark in ((34,'^'),(37,'o'),(41,'s'))]
    fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.5,.05),ncol=5,frameon=False,fontsize=7.5)
    fig.text(.5,.024,'Coverage: M/B safe actual; A unapplied (unknown); P partial; F full error.',ha='center',fontsize=7.1)
    fig.text(.5,.008,'Gain: filled DOMAIN / open CONSENSUS; x = unqualified. Coverage: DOMAIN lower / CONSENSUS upper.',ha='center',fontsize=7.1)
    fig.subplots_adjust(left=.15,right=.975,top=.955,bottom=.15,hspace=.65,wspace=.45)
    save(fig,'FIG43_2_TASK_AND_COVERAGE',(7.16,9.8))

def figure_type_ii(r,rows):
    from cavr_wbc.experiments.step39_delivery import outcome
    from cavr_wbc.experiments.step43_inputs import snapshot_groups
    by={p['id']:p for p in rows};mech=r['confirmation']['TypeII']
    md={p['context_id']:p for p in mech['direct_TYPE_II']['pairs']}
    mo={p['context_id']:p for p in mech['online_TYPE_II']['pairs']}
    fig,axs=plt.subplots(1,3,figsize=(7.16,9.8),gridspec_kw={'width_ratios':[2.35,.95,1.45]})
    states,qual,time=axs;groups=snapshot_groups();labels=[];times=[]
    for i,group in enumerate(groups):
        p=group[0];snap=p['snapshot_id'];labels.append(f"E{int(p['episode'].split('_')[-1]):02d} {p['displacement_m']*1000:+g}/t{p['tick']}")
        ids=[snap+'_HEALTHY:B']
        for leg in ('FR','RR'):
            ids += [snap+'_'+leg+'_THIGH30:B',snap+'_'+leg+'_THIGH15:B',snap+'_'+leg+'_THIGH15:MIDDLE',snap+'_'+leg+'_THIGH15:CONSENSUS_ACTUAL']
        for j,cid in enumerate(ids):
            v=by[cid];code={'SAFE_6MM':'S','PHYSICAL_FAIL':'P','TERMINAL_FAIL':'T','LOCAL_FAIL_ONLY':'L','NUMERICAL_INCOMPLETE':'I','NOT_RUN':'-'}[outcome(v)]
            if code!='-' and not v['timing_qualified']:code=code.lower()
            states.text(j,i,code,ha='center',va='center',fontsize=8,color='black' if code.lower()=='s' else '.5' if code=='-' else COL['error'])
        for leg_index,leg in enumerate(('FR','RR')):
            cid=snap+'_'+leg+'_THIGH15'
            for k,d in enumerate((md[cid],mo[cid])):
                flag='Y' if d['timing_qualified_mechanism'] else 'p' if d['qualified'] else '-'
                qual.text(leg_index*2+k,i,flag,ha='center',va='center',fontsize=8)
            B=by[cid+':B'];y=i+(-.21 if leg=='FR' else .21)
            t1,t2=B['first_actual_99percent_s'],B['first_dense_failure_s']
            col=COL['DOMAIN'] if leg=='FR' else COL['CONSENSUS']
            if t1 is not None:time.scatter(t1,y,marker='^' if leg=='FR' else 's',s=17,color=col);times.append(t1)
            if t2 is not None:time.plot(t2,y,'x',color=COL['error'],ms=5);times.append(t2)
            if t1 is not None and t2 is not None:time.plot([t1,t2],[y,y],color=col,lw=.6,ls='-' if leg=='FR' else '--')
    for ax in axs:
        ax.set(ylim=(35.65,-.7),yticks=range(36));ax.grid(axis='y',color='.92',lw=.4)
        if ax is states:ax.set_yticklabels(labels,fontsize=8)
        else:ax.tick_params(labelleft=False)
    states.set(xlim=(-.5,8.5),xticks=range(9),xticklabels=['H','F30B','F15B','FM','FA','R30B','R15B','RM','RA'])
    states.tick_params(axis='x',labelsize=7,rotation=60)
    states.set_xlabel('All trajectory endpoint outcomes')
    qual.set(xlim=(-.5,3.5),xticks=range(4),xticklabels=['DF','OF','DR','OR']);qual.tick_params(axis='x',labelsize=7,rotation=60)
    qual.set_xlabel('Type-II\nD=direct, O=online')
    time.set_xlim(0,max(.1,max(times,default=0)*1.1));time.set_xlabel('Severe B event time (s)')
    for ax,title in zip(axs,('(a) All controls','(b) Qualification','(c) Capacity / failure')):
        ax.set_title(title,loc='left',fontsize=8,fontweight='bold')
    fig.text(.5,.087,'S safe; P physical; T terminal; L local; I incomplete; - unrun. Lowercase = timing unqualified.',ha='center',fontsize=7.2)
    fig.text(.5,.062,'Y = physical + timing Type-II; p = physical only. H shared once. A = CONSENSUS actual.',ha='center',fontsize=7.2)
    fig.text(.5,.037,'Event: triangle FR / square RR = actual 99% capacity; x = dense failure. Blank = no event.',ha='center',fontsize=7.2)
    fig.subplots_adjust(left=.245,right=.98,top=.955,bottom=.19,wspace=.35)
    save(fig,'FIG43_3_TYPE_II_AND_EVENTS',(7.16,9.8))

def main():
    out=output();home=out/'figures';home.mkdir(exist_ok=True)
    setup=setup_style(journal='ieee',lang='en',constrained_layout=False)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.labelsize':8,
        'axes.titlesize':8,'xtick.labelsize':8,'ytick.labelsize':8,'legend.fontsize':8})
    from cavr_wbc.experiments.step43_inputs import severe_plans
    r=read(out/'STEP43_RESULT.json');ds=read(out/'ALL_METHOD_DECISIONS.json');rows=read(out/'ALL_PLANNED_RESULTS.json')
    if not (home/'DATA_PROFILE.json').exists():
        profile=profile_data(pd.DataFrame([{k:d[k] for k in ('context_id','snapshot_id','episode','method','selected_gamma',
            'command_ready_ms','complete_actual','safe_actual_6mm','D_m')} for d in ds]),group_cols=['method'])
        write(home/'DATA_PROFILE.json',profile)
        write(home/'FIGURE_DESIGN.json',dict(style=setup,independence_unit='36 snapshots / 12 deterministic episodes; not IID',
            rationale='Full decision dot plots; four-combination gain/coverage facets; all Type-II control matrix and paired event times',
            alternatives=['all-observation tables','descriptive heatmap'],no_means_CI_pvalues=True,
            all_decisions=144,all_typeII_planned_pairs=72,context_keys={f'C{i+1:02d}':p['context_id'] for i,p in enumerate(severe_plans())},
            inputs_sha256={n:sha(out/n) for n in ('ALL_METHOD_DECISIONS.json','ALL_PLANNED_RESULTS.json','TYPE_II_ONLY.json')}))
    figure_decisions(ds,severe_plans());figure_task(r);figure_type_ii(r,rows)
    if EXPORT:verify_exported_fonts()
    print('Three saved-summary-only SciPilot figures; zero new numerical work.')
if __name__=='__main__':main()
