"""The single authorized numerical launch, with D-only console persistence."""
from contextlib import redirect_stdout, redirect_stderr
from cavr_wbc.experiments.step43_io import output
from cavr_wbc.experiments.step43_sprint import run

if __name__ == '__main__':
    path = output() / 'NUMERICAL_CONSOLE.log'
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8', newline='\n', buffering=1) as stream:
        with redirect_stdout(stream), redirect_stderr(stream):
            run()
