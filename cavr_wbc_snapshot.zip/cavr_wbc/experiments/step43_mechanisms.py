"""Type-II-only and supported-scope endpoints from saved rows; never C trajectory."""
from cavr_wbc.experiments.step39_delivery import safe,physical_terminal
from cavr_wbc.experiments.step40_mechanisms import mechanism,endpoint
def distribution(pairs):
    q=[p for p in pairs if p.get('qualified')]
    return dict(contexts=len(q),snapshots=len({p['snapshot_id'] for p in q}),episodes=len({p['episode'] for p in q}),
        positive_episodes=len({p['episode'] for p in q if p['direction']>0}),
        negative_episodes=len({p['episode'] for p in q if p['direction']<0}),
        ticks=sorted({p['tick'] for p in q}),legs=sorted({p['fault_leg'] for p in q}),
        context_ids=[p['context_id'] for p in q])
def h2_gate(pairs):
    d=distribution(pairs)
    return dict(**d,pass_gate=bool(d['snapshots']>=6 and d['episodes']>=4 and d['positive_episodes']>=2 and
        d['negative_episodes']>=2 and len(d['ticks'])>=2 and 'FR' in d['legs'] and 'RR' in d['legs']))
def type_ii_only(rows,decisions,ps):
    by={r['id']:r for r in rows};dm={(d['context_id'],d['method']):d for d in decisions};direct=[];online=[]
    for p in ps:
        cid=p['context_id'];s=p['snapshot_id'];leg=p['fault_leg']
        H=by[s+'_HEALTHY:B'];L=by[s+'_'+leg+'_THIGH30:B'];B=by[cid+':B'];M=by[cid+':MIDDLE'];A=by[cid+':CONSENSUS_ACTUAL']
        common={k:p[k] for k in ('context_id','snapshot_id','episode','tick','direction','fault_leg','displacement_m','health_kind')}
        common.update(healthy_shared_control_id=H['id'],mild_control_id=L['id'],severe_B_id=B['id'],
            actual_capacity99_s=B['first_actual_99percent_s'],first_dense_failure_s=B['first_dense_failure_s'],
            first_dense_failure_reasons=B['first_dense_failure_reasons'])
        direct.append({**common,**mechanism('TYPE_II',H,L,B,M), 'middle_id':M['id']})
        d=dm[(cid,'CONSENSUS')]
        o=mechanism('TYPE_II',H,L,B,A)
        sent=bool(d['selected_command_sent'] and d['selected_gamma']==.5)
        # Unsent ACTUAL is an unobserved opportunity, not a missing planned direct.
        o['complete_pair']=bool(H['complete_501'] and L['complete_501'] and B['complete_501'] and (A['complete_501'] if sent else True))
        o['qualified']=bool(o['qualified'] and sent and A['timing_qualified'])
        o['timing_qualified_mechanism']=bool(o['timing_qualified_mechanism'] and o['qualified'])
        online.append({**common,**o,'middle_id':A['id'],'online_middle_sent':sent,'unapplied_true_safety':'UNKNOWN' if not sent else 'MEASURED'})
    return dict(TYPE_I='NOT_TESTED',direct_TYPE_II=endpoint(direct),online_TYPE_II=endpoint(online),
        healthy_B_real_computations=len({p['healthy_shared_control_id'] for p in direct}),
        healthy_shared_not_independent_replication=True)
