"""Only materialize frozen bytes and source identities; no historical result diagnosis."""
import shutil
from cavr_wbc.experiments.step43_io import *
from cavr_wbc.experiments.step43_identity import load_frozen
def prepare():
    out=output();target=out/'TERMINAL_CAL_DOMAIN.json'
    if target.exists():raise FileExistsError('STEP43 preparation already persisted')
    freeze=read(SOURCE_DOMAIN/'TERMINAL_CAL_DOMAIN_FREEZE.json')
    if sha(SOURCE_DOMAIN/'TERMINAL_CAL_DOMAIN.json')!=freeze['sha256']:raise ValueError('frozen domain source identity')
    out.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(SOURCE_DOMAIN/'TERMINAL_CAL_DOMAIN.json',target)
    write(out/'TERMINAL_CAL_DOMAIN_FREEZE.json',{**freeze,'STEP43_unchanged_bytes':sha(target)==freeze['sha256'],'new_fit':0,'new_CAL':0,'new_gate':0})
    names=('step42_kernel.py','step42_physical_consensus.py','step39_margin.py','step41_terminal_domain.py')
    canonical={n:sha(SOURCE_ROOT_D/'cavr_wbc/control'/n) for n in names}
    actual={n:sha(OUTPUT_ROOT_D/'cavr_wbc/control'/n) for n in names}
    if actual!=canonical:raise ValueError('acceptance source identity changed')
    write(out/'ACCEPTANCE_IDENTITY_FREEZE.json',dict(source_commit=SOURCE_COMMIT,sha256=actual,source_sha256=canonical,byte_exact=True))
    bundle,identity=load_frozen()
    write(out/'PREPARATION.json',dict(identity=identity,domain_sha256=sha(target),new_numeric_actions=0,new_fits=0,new_CAL=0))
    import cavr_wbc
    if not Path(cavr_wbc.__file__).resolve().is_relative_to(OUTPUT_ROOT_D):raise ValueError('wrong import')
    write(out/'IMPORT_LOCATION.json',dict(cavr_wbc_file=cavr_wbc.__file__,new_package=True))
    print({'prepared':True,'domain':sha(target),'acceptance_byte_exact':True,'new_numerical_actions':0})
if __name__=='__main__':prepare()
