"""Chinese confirmation evidence mapping from current saved summaries only."""
from collections import Counter
from cavr_wbc.experiments.step43_io import *
from cavr_wbc.experiments.step43_inputs import severe_plans,METHODS
def table(h,rows):
    return '\n'.join(['| '+' | '.join(h)+' |','| '+' | '.join(['---']*len(h))+' |']+
        ['| '+' | '.join(str(v).replace('|','/') for v in row)+' |' for row in rows])
def f(x):return '—' if x is None else f'{x:.4f}'
def text(path,s):path.write_text(s,encoding='utf-8',newline='\n')
def summary_counts(x):return {k:v for k,v in x.items() if k not in ('pairs','endpoints','method_pairs','purpose_rows')}
def main():
    out=output();r=read(out/'STEP43_RESULT.json');c=r['confirmation'];b=r['run']['budget'];qs=read(out/'ALL_CAUSAL_QUERIES.json')
    ds=read(out/'ALL_METHOD_DECISIONS.json');rows=read(out/'ALL_PLANNED_RESULTS.json');by={p['id']:p for p in rows}
    start=read(out/'SCREEN_IDENTITY_START.json');end=read(out/'SCREEN_IDENTITY_END.json');source=read(out/'SOURCE_END_STATE.json')
    h=c['H1_H2_by_method'];mech=c['TypeII'];rt=c['realtime']
    method_rows=[];den=[];use=[];support=[];mechanism_rows=[]
    for m in METHODS:
        v=r['methods'][m];method_rows.append([m,v['planned'],v['eligible'],v['recognized'],v['gamma_counts'],v['ABSTAIN'],v['late'],v['partial'],v['complete'],v['safe'],v['complete_error_accepts'],v['budget_not_evaluated_candidates']])
        n=h[m]['denominators'];den.append([m,n['safe_timely_useful_middle'],72,n['H2_use_qualified_middle'],n['recognized_middle_in_opportunities'],n['full_safe_timing_qualified_direct_middle_opportunities'],f(n['opportunity_recall']),n['incomplete_direct_middle'],n['full_safe_but_untimely_direct_middle']])
        for name,x in v['endpoints'].items():
            use.append([m,name,x['status'],x['contexts'],x['physical_snapshots'],x['episodes']])
        for x in c['direction_leg_support'][m]:support.append([m,x['direction'],x['fault_leg'],x['planned'],x['contexts'],x['snapshots'],x['episodes'],x['ticks'],x['support_status']])
    for name in ('direct_TYPE_II','online_TYPE_II'):
        x=mech[name];mechanism_rows.append([name,x['status'],x['qualified_contexts'],x['physical_snapshots'],x['episodes'],x['timing_qualified_contexts'],x['timing_qualified_snapshots'],x['timing_qualified_episodes'],x['online_closure']])
    paired=c['method_comparison']['method_pairs'];lost=[p for p in paired if p['coverage_cost_consensus_abstains_DOMAIN_complete_safe']]
    retained=[p for p in paired if p['DOMAIN']['safe_actual_6mm'] and p['CONSENSUS']['safe_actual_6mm']]
    coverage=[]
    for p in lost:
        q=p['CONSENSUS']['queries']
        coverage.append(dict(context_id=p['context_id'],DOMAIN_outcome=p['DOMAIN']['actual_outcome'],CONSENSUS_status=p['CONSENSUS']['status'],
            CONSENSUS_unapplied_true_safety='UNKNOWN',candidates=[{k:x.get(k) for k in ('gamma','evaluation_status','step41_same_candidate_accepted','rejection_reasons','physical_consensus')} for x in q]))
    veto=[q for q in qs if q['method']=='CONSENSUS' and q['evaluation_status']=='EVALUATED' and q.get('physical_consensus') and not q['physical_consensus']['accepted']]
    safe_domain_veto=[q for q in veto if any(p['context_id']==q['context_id'] and p['DOMAIN']['safe_actual_6mm'] for p in paired)]
    write(out/'COVERAGE_LOSS_DETAILS.json',dict(safe_DOMAIN_sent_retained_same_source=len(retained),
        DOMAIN_safe_send_denominator=r['methods']['DOMAIN']['safe'],lost_same_source=coverage,
        safe_DOMAIN_positions_with_consensus_conflict=safe_domain_veto,strict_packet_subset_not_claimed=True))
    errors=[x for x in rows if x['branch'].endswith('_ACTUAL') and x['complete_501'] and not (x['physical_pass'] and x['terminal_pass'] and x['D_m']<=.006)]
    ert=table(['ACTUAL','physical','terminal','D mm','首dense失败s','原因'],[[x['id'],x['physical_pass'],x['terminal_pass'],f(x['D_m']*1000),x['first_dense_failure_s'],x['first_dense_failure_reasons']] for x in errors]) if errors else 'DOMAIN/CONSENSUS均无完整错误接受。'
    all_dec=[]
    for p in severe_plans():
        vv=[next(d for d in ds if d['context_id']==p['context_id'] and d['method']==m) for m in METHODS]
        all_dec.append([p['context_id'],p['tick'],*[('M' if d['selected_gamma']==.5 else 'B')+'/'+d['actual_outcome'] if d['selected_command_sent'] else d['status']+'/NOT_RUN' for d in vv],*[f(d['command_ready_ms']) for d in vv]])
    gains=[x for x in c['purpose_rows']['CONSENSUS'] if x['safe_B_progress']]
    metric_rows=[]
    for x in gains:
        a=x['actual_task_response'] or {};bb=x['B_task_response'] or {}
        metric_rows.append([x['context_id'],f(x['absolute_gain_m']*1000),f(x['relative_gain']),
            f(a.get('terminal_directed_subtree_COM_displacement_m',0)*1000),f(bb.get('terminal_directed_subtree_COM_displacement_m',0)*1000),
            f(a.get('terminal_base_task_error_m',0)*1000),f(bb.get('terminal_base_task_error_m',0)*1000),
            f(a.get('time_mean_abs_base_task_error_m',0)*1000),f(bb.get('time_mean_abs_base_task_error_m',0)*1000)])
    txt=f"""# STEP43：冻结方法确认面板与容量备份对照

## Material Passport

Origin Skill: experiment-agent / ARS；Origin Mode: run；日期2026-10-11（韩国时间）；Version STEP43_FROZEN_CONFIRMATION_V1。
Verification Status: UNVERIFIED（没有重现实验；本轮保存数据一致性读回单独为 {r['readback']['status']}）。
源提交 {SOURCE_COMMIT}；run_id {out.name}。本轮仅编排新固定批次，未改变接受算法、预测器、CAL或评价器。

## 主结果：可靠性、用途、容量和实时分别报告

执行完整性：{r['task_execution_status']}。H1/H2主终点：{c['status']}。
容量恢复闭合：{c['capacity_closure_status']}。全计划实时状态：{rt['status']}。
这些状态不是单个合并PASS；完整错受优先FAIL，发送不完整/UNKNOWN保留NOT_ESTABLISHED，计划中断写INCOMPLETE。

{table(['方法','H1','H2','预冻结H2资格分布'],[[m,h[m]['H1'],h[m]['H2'],h[m]['H2_gate']] for m in METHODS])}

H2规则事前固定为6 snapshot/4 episode、正负方向各2episode、FR/RR各至少1context、至少2tick；资格middle必须及时、完整physical+terminal+6mm安全且归入safe-B progress或failed-B recovery之一。
四组合支持分开见下表，合并H2不能替代缺失组合的观察。

## 固定批次、方法身份与时间轴

12条新reference目标+61.75、−61.75、+62.75、−62.75、+64.25、−64.25、+64.75、−64.75、+65.25、−65.25、+67.75、−67.75mm，每条110tick/1100step，取34/37/41。
36snapshot/12episode、180context；在线仅FR/RR thigh=.15的72severe位置，两方法144决定。
252计划direct：144severe middle/B，36共享healthy B和72mild(.30) B；最多144认可ACTUAL，总396计划轨迹位。
healthy故障index=None/name=NONE/role=healthy，只有指定受损通道改变health。控制、QP、plant、反馈和评价一致。healthy/.30不调用筛选器。

两个方法直接导入冻结STEP42 kernel，consensus_enabled=False/True；DOMAIN同样保存共识诊断且计入时间，不扣时。三轴域、原四CAL邻居排序、概率/距离/pose/K、R=.1mm、gamma=.5→0全部不变，无新增门/fit/CAL。
域表SHA256 {r['terminal_domain_sha256']}；完整predictor/CAL/TRAIN/阈值身份见SCREEN_IDENTITY_START/END；接受源码SHA256见ACCEPTANCE_IDENTITY_FREEZE。启动/结束保持：{end}。

每severe两独立owner/B0：按ordinal交替，两个决定先不可变保存，再各自ACTUAL、独立direct；当前snapshot两个severe之后才生成healthy/mild对照。三owner C/MIDDLE/B保留，healthy/.30也执行真实C/B endpoint，但不传播C的1s分支。
计时从原准备起点包含application、endpoint、prefix、features、原门/共识/邻居诊断、selected/B0及metadata复制；20ms不重启。gamma0恢复自身B0，middle沿自身witness和live owner。两方法只作同source，不宣称同packet或发送子集。

prehold0–.02s、first action .02–.04s、48反馈、1s/500steps/501states/21checkpoint，dt=.002；dense接触逐状态，local6mm、terminal vx1mm/s和其余边界不变。
candidate1e-7/reference1e-8，friction upper−1e-4N、torque inset1e-4Nm，B6ms/C3ms/feedback6ms为QP求解预算；完整反馈staging/check/commit deadline仍20ms。没有改变任何数值接受算法或物理失败豁免。

## 全计划统计与覆盖

{table(['方法','planned','eligible','认可','gamma','ABSTAIN','late','partial','完整ACTUAL','完整安全','完整错受','候选预算未评价'],method_rows)}

direct统计：{r['direct']}。全部396计划位保存ALL_PLANNED_RESULTS/ALL_BRANCH_RESULTS；NOT_RUN不作安全或轨迹缺失。当前无有效命令、源不合格、数值不完整及partial保留各自原因。

{table(['方法','安全及时middle','planned','H2用途资格middle','机会内安全middle','完整安全及时direct机会','机会召回','direct未完整','direct安全但迟到'],den)}

机会分母仅同source完整safe6mm且timing-qualified的独立direct middle；分子仅本方法真实及时安全middle，不含gamma0。它不是未发送候选真值或总体召回。未完成direct单列，不按结果扩大批次。
相对DOMAIN完整安全实际发送同source保留 {len(retained)}/{r['methods']['DOMAIN']['safe']}；覆盖损失 {len(lost)} 位，全部原因及每候选预算状态见COVERAGE_LOSS_DETAILS。
CONSENSUS共识冲突候选{len(veto)}个；安全DOMAIN同source中有共识冲突的候选{len(safe_domain_veto)}个。NOT_EVALUATED_BUDGET不写成新增门拒绝。
未施加的CONSENSUS动作安全仍UNKNOWN，不能复制DOMAIN/direct标签。DOMAIN无完整错受时不声称降低错误率；有错受也仅作同分母描述性比较。

## 四组合支持矩阵

{table(['方法','方向','leg','planned','资格context','snapshot','episode','ticks','支持状态'],support)}

## 两类用途分别报告

{table(['方法','用途','状态','context','snapshot','episode'],use)}

safe-B progress仅在独立B完整safe6mm时比较.02–.04s有向进度；相对增益B=0时不计算。failed-B recovery仅在severe B完整原physical失败且自身认可middle安全时计入，要求2snapshot/2episode，不用safe-B收益凑门。
CONSENSUS任务收益的短段与全程描述如下（COM位移、base外部任务误差分别列，不能将短段增益写成整任务完成提升）：

{table(['context','首动作增益mm','相对B增益','1s COM位移A mm','1s COM位移B mm','终点任务误差A mm','终点任务误差B mm','全程绝对误差均值A mm','全程绝对误差均值B mm'],metric_rows)}

TASK_RESPONSE_ALL保存所有已观察轨迹逐状态有向COM/base位移及外部quintic base参考误差（source_tick*.02+分支time）。
所有用途计划行、失败/partial/不认可及幅度/tick/direction/leg分层在DOMAIN/CONSENSUS_TASK_USE_PAIRS，不只输出成功。

## Type-II-only：容量备份与在线闭合

{table(['类型','物理状态','资格context','snapshot','episode','及时context','及时snapshot','及时episode','时延资格闭合'],mechanism_rows)}

Type-I=NOT_TESTED；未调用旧all_endpoints，未补C轨迹。全部72个同snapshot/同leg对照在TYPE_II_ONLY与两个ALL_PAIRS。
必要四轨迹healthyB、mild(.30)B、severe(.15)B、middle依原STEP40定义：前两者完整physical+terminal；severe B完整原physical失败，实际施加的该关节力矩/真实health×capacity>=99%严格早于dense首次失败；middle完整physical+terminal+6mm。
direct Type-II使用独立direct middle，online Type-II使用当前context CONSENSUS自己真实及时认可middle，不拼接其他context。共享healthy对照真实计算{mech['healthy_B_real_computations']}次，不增加独立样本数。
CAPACITY_EVENTS_FULL保存实际actuator_force、实际有效容量、99%首事件、失败时间原因、每轨迹完整窗口时延。未用QP active-row/sent限幅或其他关节最大值替代。
容量先后与健康干预是有限机制证据，不单独证明饱和充分致因；单2ms contact loss仍是physical失败，不改称跌倒或豁免。

## 错误与实时

{ert}

全计划实时：{rt}。
LATENCY保存所有planned/sent command-ready；每条ACTUAL反馈最大时延、内部预算未评价及两gamma complete_at/phase计时保留。
有任何计划窗口miss就不能写全部144决定满足20ms或硬实时部署验证。迟到弃权未发送但作为计划超时报告；已发送partial也不排除或补跑。ordinary错误、接触失败与deadline miss未全局停止。
本轮是一次动作选择+1s反馈备份，不是每tick重跑governor的持续闭环部署。

## 一次执行、测试、预算和交付

首数值动作 {b['numerical_started_utc']}；实际{b['numerical_elapsed_s']:.3f}s，{b['total_QP_calls']}QP，{b['total_physics_steps']}step；上限180min/30000QP/300000step未重置。0fit/0newCAL/0newgate。
集中纯fixture16/16通过，无真实QP/MuJoCo/fit；没有历史全套测试。保存数据汇总的两次定点修复分别是NumPy已移除trapz后的等价显式梯形和、以及用途记录缺失tick的字段适配；各自相关纯fixture1/1通过。实现/IO定点修复{r['implementation_IO_repairs']}/2，无结果性重试；数值入口STEP43 launch仅一次。
本轮readback有一次首bank派生统计接口错误导致的中断，随后完成一个完整成功读回；首bank明确重复读取一次，其余bank不重复，无历史bank或native重演。完整读回 {r['readback']['status']}，{r['readback']['observed_banks_read_once']}bank/{r['readback']['complete_grids_verified']}完整grid，QP START/RETURN/raw={r['readback']['qp_starts']}/{r['readback']['qp_returns']}/{r['readback']['raw_qp_shards']}，unknown={r['readback']['unknown_qp']}；issues={r['readback']['issues']}。其后的tick汇总修复只用已存TASK_RESPONSE_ALL与当前RESULT/DECISION metadata调用finalize_saved，未再次调用bank读回。错误与命令保存在两条repairs记录和COMMANDS_AND_VALIDATION。
源结束状态：{source}。所有新增代码、Git对象/index/log、工件、TMP/cache、图在D；旧E依赖只读，没有安装、编译或probe。禁区、E3、RL、硬件未访问/执行。

## 三张SciPilot图

1. 全部144决定、认可/弃权/错误/partial及20ms窗口，每个位置可见。
2. 全幅度/tick/direction/leg的实际任务增益及覆盖，不用成功均值柱掩盖不认可位置。
3. 全Type-II计划对照的physical/terminal/local或partial，以及实际capacity99%→dense失败时间关系。

![全部在线决定]({(out/'figures/FIG43_1_ALL_DECISIONS.png').as_posix()})
![任务收益与覆盖]({(out/'figures/FIG43_2_TASK_AND_COVERAGE.png').as_posix()})
![容量与备份对照]({(out/'figures/FIG43_3_TYPE_II_AND_EVENTS.png').as_posix()})

PDF/SVG/PNG、灰度预览及视觉检查见figures；每点是观测，deterministic source不是IID随机部署episode，不计算总体零错误概率、p值或伪独立CI。

## 论文证据与下一阶段

TRO_CONFIRMATION_EVIDENCE_UPDATE将H1/H2/H3和实时分别对应主张，贡献仍是受损能力下任务保留与备份恢复。
{'支持冻结FR/RR thigh=.15范围内的更广触发任务用途；容量闭合是否成立依独立H3，不以H2代替。' if c['status']=='SUPPORTED_SCOPE_USEFUL_EXECUTION_CONFIRMED' else '本轮未通过预冻结用途确认门，保留完整位置和失败结果，不降低6snapshot/4episode等门槛。'}
不宣称跨故障域、持续闭环、硬件实时或连续时间conformal/CBF/viability/稳定性保证。下阶段应优先解决最重要的剩余科学缺口，需新的明确授权，不自动开展新CAL/fit或E3。
"""
    text(out/'REPORT.md',txt)
    claims=[['H1',h['CONSENSUS']['H1'],'冻结支持范围内的有限实际接受可靠性','不估计总体安全概率'],
        ['H2',h['CONSENSUS']['H2'],'广幅度/触发时刻的任务保留','四组合依各自支持；短段不等于整任务完成'],
        ['H3 direct',mech['direct_TYPE_II']['status'],'独立容量备份干预对照','不替代在线动作'],
        ['H3 online',mech['online_TYPE_II']['online_closure'],'容量备份机制和真实发送恢复的同context闭合','不拼接context或direct标签'],
        ['实时',rt['status'],'真实计入20ms窗口的动作/反馈记录','计划miss与有限安全发送时延分开，非硬实时部署']]
    evidence=f"""# T-RO确认面板证据更新

只使用STEP43保存汇总，无新增数值动作/审计门。run_id={out.name}，执行={r['task_execution_status']}。

{table(['终点','实测状态','可支持的主张','边界'],claims)}

主结论：{c['status']}；容量：{c['capacity_closure_status']}。direct/online Type-II及时版本分别覆盖{mech['direct_TYPE_II']['timing_qualified_snapshots']}/{mech['online_TYPE_II']['timing_qualified_snapshots']}snapshot和{mech['direct_TYPE_II']['timing_qualified_episodes']}/{mech['online_TYPE_II']['timing_qualified_episodes']}episode。
任务保留证据从真实middle的短段收益与全程误差共同组织；未发送真实安全UNKNOWN。DOMAIN同分母错受为{r['methods']['DOMAIN']['complete_error_accepts']}，CONSENSUS为{r['methods']['CONSENSUS']['complete_error_accepts']}；DOMAIN零错受时不宣称共识实证降低错误率。
剩余缺口包括未支持故障/健康域、持续闭环每tick决策、部署分布随机场景及硬件时延/真实接触。一个CAL否决条件不是T-RO创新本身；核心仍是受损能力下任务保留和备份恢复机制。
下一阶段优先缺口：{'持续闭环与域外故障验证，先冻结独立设计。' if c['capacity_closure_status']=='CAPACITY_BACKUP_RECOVERY_CLOSURE_OBSERVED' else '容量恢复为何未在线闭合：围绕接触裕量/backup能力机制建立解释和干预，不叠任意否决门。'}
不自动启动，不根据本轮结果扩样或调门。
"""
    text(out/'TRO_CONFIRMATION_EVIDENCE_UPDATE.md',evidence)
    text(out/'HANDOFF.md',f"# STEP43研究交接\n执行={r['task_execution_status']}；主终点={c['status']}；容量={c['capacity_closure_status']}；实时={rt['status']}。\n源码源提交={SOURCE_COMMIT}；新checkout={OUTPUT_ROOT_D.as_posix()}；run={out.name}。\n完整REPORT、全部计划/两方法配对/四组合/Type-II/latency/ledger及三图均在此目录。TRO_CONFIRMATION_EVIDENCE_UPDATE仅用保存汇总。\n旧证据/源HEAD/index保持，禁区未触及。无push；下一实验未授权。\n")
    ini=PROTOCOL.read_text(encoding='utf-8').split('~~~ini\n',1)[1].split('~~~',1)[0]
    states=dict(TASK_EXECUTION_STATUS=r['task_execution_status'],NUMERICAL_BATCH_STATUS=r['run']['status'],
        CURRENT_RUN_READBACK=r['readback']['status'],PRIMARY_CONFIRMATION=c['status'],
        H1_CONSENSUS=h['CONSENSUS']['H1'],H2_CONSENSUS=h['CONSENSUS']['H2'],
        TYPE_II_DIRECT=mech['direct_TYPE_II']['status'],TYPE_II_ONLINE=mech['online_TYPE_II']['status'],
        TYPE_II_ONLINE_TIMING=mech['online_TYPE_II']['online_closure'],CAPACITY_CLOSURE=c['capacity_closure_status'],
        REALTIME_STATUS=rt['status'],CONSENSUS_RECOGNIZED=r['methods']['CONSENSUS']['recognized'],
        CONSENSUS_H2_MIDDLE_CONTEXTS=h['CONSENSUS']['H2_gate']['contexts'],
        CONSENSUS_H2_PHYSICAL_SNAPSHOTS=h['CONSENSUS']['H2_gate']['snapshots'],
        CONSENSUS_H2_EPISODES=h['CONSENSUS']['H2_gate']['episodes'],
        CONSENSUS_H2_POSITIVE_EPISODES=h['CONSENSUS']['H2_gate']['positive_episodes'],
        CONSENSUS_H2_NEGATIVE_EPISODES=h['CONSENSUS']['H2_gate']['negative_episodes'],
        NEGATIVE_RR_USEFUL_EXECUTION='NOT_CONFIRMED',
        DIRECT_TYPE_II_TIMELY_SNAPSHOTS=mech['direct_TYPE_II']['timing_qualified_snapshots'],
        DIRECT_TYPE_II_TIMELY_EPISODES=mech['direct_TYPE_II']['timing_qualified_episodes'],
        ONLINE_TYPE_II_TIMELY_SNAPSHOTS=mech['online_TYPE_II']['timing_qualified_snapshots'],
        ONLINE_TYPE_II_TIMELY_EPISODES=mech['online_TYPE_II']['timing_qualified_episodes'],
        DOMAIN_COMPLETE_ERRORS=r['methods']['DOMAIN']['complete_error_accepts'],
        PLANNED_DECISION_DEADLINE_MISSES=rt['planned_decision_deadline_misses'],
        CONSENSUS_COMPLETE_SAFE=r['methods']['CONSENSUS']['safe'],CONSENSUS_COMPLETE_ERRORS=r['methods']['CONSENSUS']['complete_error_accepts'],
        CONSENSUS_PARTIAL=r['methods']['CONSENSUS']['partial'],QP_CALLS=b['total_QP_calls'],PHYSICS_STEPS=b['total_physics_steps'],
        UNKNOWN_QP_RETURNS=r['readback']['unknown_qp'],NUMERICAL_LAUNCHES=1,IMPLEMENTATION_IO_REPAIRS=r['implementation_IO_repairs'],
        ACCEPTANCE_ALGORITHM_BYTE_IDENTITY_UNCHANGED=r['source_acceptance_unchanged'],
        SOURCE_HEAD_INDEX_UNCHANGED=source['unchanged'],NEXT_EXPERIMENT='NOT_AUTHORIZED')
    text(out/'PROTOCOL_STATUS.ini',ini+'\n'+'\n'.join(k+' = '+('TRUE' if v is True else 'FALSE' if v is False else str(v)) for k,v in states.items())+'\n')
    print({'report':str(out/'REPORT.md'),'confirmation':c['status'],'capacity':c['capacity_closure_status'],'new_numerical_actions':0})
if __name__=='__main__':main()
