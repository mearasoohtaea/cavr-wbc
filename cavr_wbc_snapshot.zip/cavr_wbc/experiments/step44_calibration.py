"""Append-only independent CAL; fixed STEP39 formulas and STEP41 domain builder."""
from copy import deepcopy
import numpy as np
from cavr_wbc.control import step39_margin as margin
from cavr_wbc.control.step41_terminal_domain import build_table, causal_axes, stratum_key, ResidentDomain
from cavr_wbc.experiments.step44_identity import fingerprint, bundle_identity
from cavr_wbc.experiments.step44_io import write, sha, output, read

CAL_ARRAYS = ('cal_z','cal_ids','cal_snapshot_ids','cal_episode_ids','cal_complete',
    'cal_residual','cal_physical_known','cal_physical_pass','cal_probability')

def clean(value):
    if isinstance(value,dict):return {k:clean(v) for k,v in value.items() if not k.startswith('_')}
    return deepcopy(value)

def append_calibration(old_bundle,new_rows):
    """The replacing builder is used only as a temporary new-row constructor."""
    new_rows=list(new_rows)
    old_ids={str(i) for g in old_bundle['groups'].values() for i in g['cal_ids']}
    if old_ids & {r['id'] for r in new_rows}:raise ValueError('old/new CAL identity overlap')
    temporary=margin.build_calibration(clean(old_bundle),new_rows)
    bundle=clean(old_bundle);mapping={}
    for key,group in bundle['groups'].items():
        if key not in ('0.5:thigh','0.0:thigh'):continue
        new=temporary['groups'][key]
        for name in CAL_ARRAYS:group[name]=np.concatenate((group[name],new[name]),axis=0)
        for identity,code in (('cal_snapshot_ids','cal_snapshot_index'),('cal_episode_ids','cal_episode_index')):
            values=sorted(set(str(i) for i in group[identity]));codes={v:i for i,v in enumerate(values)}
            group[code]=np.asarray([codes[str(v)] for v in group[identity]],dtype=np.int64)
            mapping[key+':'+code]=codes
        complete=group['cal_complete'];known=group['cal_physical_known'];physical=group['cal_physical_pass']
        snaps=set(group['cal_snapshot_ids'][complete]);eps=set(group['cal_episode_ids'][complete])
        z=group['cal_z'];train=group['train_z']
        nearest=np.sqrt(np.min(np.sum((z[:,None,:]-train[None,:,:])**2,axis=2),axis=1)) if len(z) and len(train) else np.empty(0)
        group.update(CAL_planned=group['CAL_planned']+new['CAL_planned'],CAL_finite=len(z),
            CAL_complete=int(complete.sum()),CAL_complete_distinct_snapshots=len(snaps),CAL_complete_episodes=len(eps),
            CAL_complete_physical_failures=int(np.sum(complete & ~physical)),CAL_physical_unknown=int(np.sum(~known)),
            CAL_missing_feature_ids=group.get('CAL_missing_feature_ids',[])+new['CAL_missing_feature_ids'],
            CAL_incomplete_finite_ids=group['cal_ids'][~complete].tolist(),
            local_calibrated=bool(bundle['trained'] and len(snaps)>=4 and len(eps)>=2),
            cal_max_nearest_distance=float(nearest.max()) if len(nearest) else 0.,
            distance_threshold=max(3.*float(nearest.max()) if len(nearest) else 0.,margin.DISTANCE_FLOOR))
    bundle.update(calibration_id='STEP44_APPEND_ALL_FINITE_CAL_V1',
        CAL_ids_all=list(old_bundle['CAL_ids_all'])+[r['id'] for r in new_rows],CAL_frozen=True,TEST_consumed=False)
    bundle=margin.prepare_resident(bundle)
    return bundle,mapping

def prefix_check(old,new):
    checks={}
    for key,g in old['groups'].items():
        n=len(g['cal_ids']);ng=new['groups'][key]
        if key not in ('0.5:thigh','0.0:thigh'):
            checks[key]={'unchanged':fingerprint(g)==fingerprint(ng)};continue
        numeric={k:fingerprint(g[k])==fingerprint(ng[k][:n]) for k in CAL_ARRAYS if g[k].dtype.kind not in 'US'}
        strings={k:g[k].tolist()==ng[k][:n].tolist() for k in CAL_ARRAYS if g[k].dtype.kind in 'US'}
        checks[key]=dict(old_rows=n,new_rows=len(ng['cal_ids']),numeric_prefix=numeric,string_prefix=strings,
            old_failed_retained=int(np.sum(~g['cal_physical_pass'])),old_unknown_retained=int(np.sum(~g['cal_physical_known'])),
            TRAIN_unchanged=all(fingerprint(v)==fingerprint(ng[k]) for k,v in g.items() if k.startswith('train_')),
            unchanged=all(numeric.values()) and all(strings.values()))
    if margin.identity(old)!=margin.identity(new) or not all(v['unchanged'] and v.get('TRAIN_unchanged',True) for v in checks.values()):
        raise ValueError('append changed old CAL/TRAIN/predictor')
    return checks

def domain_record(p,row,entry,packet,result,mapping,source_hashes):
    action=entry.get('action') or {};context=packet.get('context_used') or {}
    error=None;axes=None
    key=stratum_key(row['gamma'],p['direction'],p['fault_leg'])
    try:
        actual_key,axes=causal_axes(entry.get('features28'),action,context,mapping)
        if actual_key!=key:raise ValueError('CAL domain stratum identity')
    except (ValueError,KeyError,TypeError,IndexError) as exc:error=str(exc)
    lab=result['label']
    return dict(id=row['id'],context_id=p['context_id'],gamma=row['gamma'],role='thigh',health=.15,
        direction=p['direction'],fault_leg=p['fault_leg'],episode=p['episode'],snapshot=p['snapshot_id'],
        stratum=key,axes=axes,raw_feature_values=entry.get('features28'),input_error=error,
        action_tau_sent=action.get('tau_sent'),action_effective_capacity=(action.get('capacity_interface') or {}).get('effective_capacity_nm'),
        complete_terminal_evaluation=bool(lab.get('complete') and lab.get('full_501_grid')),
        original_physical=lab.get('original_physical'),original_terminal=lab.get('original_terminal'),
        source_status=result['status'],source_hashes=source_hashes)

def freeze(out,old,rows,old_table,domain_rows,attempted):
    augmented,codes=append_calibration(old,rows)
    prefixes=prefix_check(old,augmented)
    write(out/'OLD_CAL_PREFIX_CHECK.json',dict(status='VERIFIED',groups=prefixes,code_mappings=codes,
        predictor_unchanged=margin.identity(old)==margin.identity(augmented),old_ids_not_replaced=True))
    write(out/'MISSING_FEATURE_MANIFEST.json',[dict(id=r['id'],split=r['split'],episode=r['episode'],snapshot=r['source_snapshot']) for r in rows if margin.finite_input(r) is None])
    # Original records, including failed extremes and source hashes, remain a prefix.
    records=deepcopy(old_table['records'])+domain_rows
    table=build_table(records,old_table['mapping'])
    table.update(new_CAL_trajectories=128,new_CAL_planned=128,new_CAL_attempted=attempted,
        new_CAL_complete=sum(r['complete_terminal_evaluation'] for r in domain_rows),STEP44_append_only=True,TEST_consumed=False)
    if fingerprint(table['records'][:len(old_table['records'])])!=fingerprint(old_table['records']):raise ValueError('old domain rows changed')
    write(out/'AUGMENTED_TERMINAL_CAL_DOMAIN.json',table)
    assets={m:margin.save_bundle(b,out/'models',m) for m,b in (('OLD_CAL_CONSENSUS',old),('AUGMENTED_CAL_CONSENSUS',augmented))}
    domains={'OLD_CAL_CONSENSUS':dict(path='OLD_TERMINAL_CAL_DOMAIN.json',sha256=sha(out/'OLD_TERMINAL_CAL_DOMAIN.json')),
        'AUGMENTED_CAL_CONSENSUS':dict(path='AUGMENTED_TERMINAL_CAL_DOMAIN.json',sha256=sha(out/'AUGMENTED_TERMINAL_CAL_DOMAIN.json'))}
    identity={m:bundle_identity(b) for m,b in (('OLD_CAL_CONSENSUS',old),('AUGMENTED_CAL_CONSENSUS',augmented))}
    metadata=dict(status='FROZEN',planned=128,recorded=len(rows),attempted=attempted,
        finite=sum(margin.finite_input(r) is not None for r in rows),
        complete=sum(r['complete_terminal_evaluation'] for r in domain_rows),
        assets=assets,domains=domains,identities=identity,predictor_identity=margin.identity(old),
        TEST_consumed=False,TEST_generated=False,new_fits=0,new_TRAIN=0,
        groups={k:{n:v for n,v in g.items() if n.startswith('CAL_') or n in ('distance_threshold','local_calibrated','cal_max_nearest_distance')} for k,g in augmented['groups'].items()})
    write(out/'STEP44_CAL_FREEZE.json',metadata)
    return augmented,table,metadata

def load_pair(out=output()):
    f=read(out/'STEP44_CAL_FREEZE.json');bundles={};domains={}
    for m,a in f['assets'].items():
        for ext in ('npz','json'):
            if sha(a[ext])!=a[ext+'_sha256']:raise ValueError('CAL asset hash')
        bundles[m]=margin.load_bundle(a['npz'])
        d=f['domains'][m];p=out/d['path']
        if sha(p)!=d['sha256']:raise ValueError('CAL domain hash')
        domains[m]=ResidentDomain(read(p),d['sha256'])
    return bundles,domains,f
