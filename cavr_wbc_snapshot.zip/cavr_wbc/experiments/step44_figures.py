"""Two SciPilot figures from saved STEP44 tables only; no numerical calls."""
from pathlib import Path
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from cavr_wbc.experiments.step44_io import *
SCRIPTS=Path('C:/Users/ZhuanZ（无密码）/.codex/skills/scipilot-figure/scripts')
sys.path.insert(0,str(SCRIPTS))
from setup_style import setup_style
from layout_tools import finalize_figure,add_panel_labels
from visual_qa import render_preview,audit_layout
from profile_data import profile_data,render_report
from export_figure import export_figure
from check_figure import check_figure
from pypdf import PdfReader
METHODS=('OLD_CAL_CONSENSUS','AUGMENTED_CAL_CONSENSUS')
SHORT=['Old CAL','Augmented CAL']
COLORS=['#0072B2','#D55E00']
OUTCOME_COLORS={'M':'#0072B2','B':'#56B4E9','F':'#D55E00','P':'#CC79A7','A':'#D9D9D9','L':'#E69F00','?':'#FFFFFF'}
def code(d):
    if not d['decision_exists']:return '?'
    if d['selected_command_sent']:
        if not d['complete_actual']:return 'P'
        if not d['safe_actual_6mm']:return 'F'
        if not d['timing_qualified_actual']:return 'L'
        return 'M' if d['selected_gamma']==.5 else 'B'
    return 'L' if d['overall_deadline_failure'] else 'A'

def coverage(out,r):
    fig,axes=plt.subplots(3,2,figsize=(7.16,6.8),constrained_layout=True)
    matrices=r['confirmation']['direction_leg_support'];pairs=r['confirmation']['source_pairs']
    for k,(direction,leg) in enumerate([(1,'FR'),(1,'RR'),(-1,'FR'),(-1,'RR')]):
        ax=axes[k//2,k%2]
        labels=['Planned','Sent','Safe','Type-II']
        for j,m in enumerate(METHODS):
            v=next(v for v in matrices[m] if v['direction']==direction and v['fault_leg']==leg)
            values=[v['planned'],v['recognized'],v['complete_safe'],v['contexts']]
            ax.plot(range(4),values,marker='o' if j==0 else 's',color=COLORS[j],linestyle='--' if j==0 else '-',label=SHORT[j])
            previous=next(v for v in matrices[METHODS[0]] if v['direction']==direction and v['fault_leg']==leg)
            oldvalues=[previous['planned'],previous['recognized'],previous['complete_safe'],previous['contexts']]
            for x,y in enumerate(values):
                offset=6 if j==0 or y>oldvalues[x] else -13
                ax.annotate(str(y),(x,y),xytext=(0,offset),textcoords='offset points',ha='center',fontsize=8)
        subset=[p for p in pairs if p['direction']==direction and p['fault_leg']==leg]
        snap=len({p['snapshot_id'] for p in subset});ep=len({p['episode'] for p in subset})
        ax.set_title(('Positive' if direction>0 else 'Negative')+' '+leg+f' | {snap} snapshots / {ep} episodes',fontsize=8)
        ax.set_xticks(range(4),labels);ax.set_ylim(-1.7,14.3);ax.set_yticks([0,4,8,12])
        ax.set_ylabel('Severe source contexts')
        ax.grid(axis='y',alpha=.15)
    axes[0,0].legend(loc='upper right',frameon=False,fontsize=8)
    for j,direction in enumerate((1,-1)):
        ax=axes[2,j];subset=[p for p in pairs if p['direction']==direction]
        for x,p in enumerate(subset):
            for y,key in enumerate(('old','augmented')):
                d=p[key];c=code(d)
                ax.scatter([x],[y],marker='s',s=145,color=OUTCOME_COLORS[c],edgecolors='#666666',linewidths=.4)
                ax.text(x,y,c,ha='center',va='center',fontsize=8,color='white' if c in ('M','F','P') else 'black')
                method=METHODS[y]
                if p['online_type_ii'][method]['timing_qualified_mechanism']:
                    ax.plot(x,y-.29,marker='*',color='black',markersize=4)
            state=p['direct_opportunity']
            ax.text(x,2,'D' if state=='OPPORTUNITY' else '?' if state=='UNKNOWN' else '-',ha='center',va='center',fontsize=8)
        ax.set_xticks(range(len(subset)),[str(i+1) for i in range(len(subset))])
        ax.tick_params(axis='x',rotation=90)
        ax.set_yticks([0,1,2],['Old','Aug.','Direct']);ax.set_ylim(2.5,-.6);ax.set_xlim(-.7,len(subset)-.3)
        ax.set_xlabel('Source ordinal (within direction)')
        ax.set_title(('Positive' if direction>0 else 'Negative')+' | every planned paired source',fontsize=8)
        ax.spines[['top','right']].set_visible(False)
    fig.suptitle('Matched CAL: fixed planned coverage and own-ACTUAL transitions',fontsize=9)
    fig.supxlabel('M: safe middle; B: safe backup; F: unsafe; P: partial; A: abstain.\nL: late; ?: unknown; star: online Type-II; D: direct Type-II opportunity.',fontsize=8)
    return fig

def response(out,r):
    fig,axes=plt.subplots(2,2,figsize=(7.16,5.7),constrained_layout=True)
    wins=read(out/'LATENCY_ALL_WINDOWS.json')
    ax=axes[0,0]
    for j,m in enumerate(METHODS):
        used=[w for w in wins if w['method']==m and w['latency_ms'] is not None and (w['window']=='FEEDBACK' or w['applied'])]
        for window,marker in [('PREPARATION','s'),('FEEDBACK','.')]:
            subset=[w for w in used if w['window']==window]
            xs=np.linspace(j-.16,j+.16,len(subset)) if subset else []
            ax.scatter(xs,[w['latency_ms'] for w in subset],s=13 if marker=='s' else 3,marker=marker,color=COLORS[j],alpha=.5)
            withheld=[(x,w) for x,w in zip(xs,subset) if not w['applied']]
            ax.scatter([x for x,w in withheld],[w['latency_ms'] for x,w in withheld],s=32,marker='x',color=COLORS[j],linewidths=1.2,zorder=5)
        missing=sum(w['method']==m and w['window']=='PREPARATION' and not w['observed'] for w in wins)
        nsend=r['methods'][m]['recognized'];abst=r['methods'][m]['ABSTAIN'];late=r['methods'][m]['late']
        ax.text(j,1.025,f'sent {nsend}/48\nabstain {abst}; late {late}; ? {missing}',transform=ax.get_xaxis_transform(),ha='center',fontsize=8)
    ax.axhline(20,color='black',linestyle='--',linewidth=.9,label='20 ms')
    sent_windows=[w for w in wins if w['latency_ms'] is not None and (w['window']=='FEEDBACK' or w['applied'])]
    peak=max(w['latency_ms'] for w in sent_windows)
    ax.set_xticks([0,1],SHORT);ax.set_ylabel('Sent-window latency (ms)');ax.set_title('All sent preparation / feedback windows',fontsize=8,pad=37)
    ax.set_yscale('symlog',linthresh=2);ax.set_ylim(0,max(40,peak*1.65))
    # Use a dedicated empty-area legend instead of floating peak annotations.
    # This simplifies the latency panel after the bounded visual-review cycle.
    ax.legend(handles=[Line2D([0],[0],color='black',linestyle='--',label='20 ms'),
        Line2D([0],[0],color=COLORS[1],marker='x',linestyle='none',label=f'{peak:.2f} ms; withheld')],
        frameon=False,loc='lower right',fontsize=8)
    for k,(metric,label) in enumerate([('first_action_gain_m','First-action directed gain vs B (mm)'),
            ('terminal_absolute_task_error_change_m','1 s terminal absolute error change (mm)'),
            ('full_horizon_abs_task_error_integral_change_m_s','1 s absolute error integral change (mm s)')]):
        ax=axes.flat[k+1]
        for j,m in enumerate(METHODS):
            values=r['confirmation']['task_use'][m]
            known=[p for p in values if p[metric] is not None and np.isfinite(p[metric])]
            for i,p in enumerate(known):
                x=j+(.32*(i/(max(1,len(known)-1))-.5))
                marker='o' if p['actual_safe'] and p['actual_timely'] else 'x' if p['ACTUAL_outcome'] not in ('NOT_RUN','NUMERICAL_INCOMPLETE') else '^'
                ax.scatter([x],[p[metric]*1000],color=COLORS[j],marker=marker,s=18,linewidths=.7,alpha=.75)
            ax.text(j,1.03,f'known {len(known)}/48\nmissing {48-len(known)}',transform=ax.get_xaxis_transform(),ha='center',fontsize=8)
        ax.axhline(0,color='black',linewidth=.65,linestyle='--')
        ax.set_xlim(-.45,1.45);ax.set_xticks([0,1],SHORT);ax.set_ylabel(label)
        ax.set_title(['0.02-0.04 s action benefit','Full-horizon terminal tracking','Full-horizon integrated tracking'][k],fontsize=8,pad=31)
        ax.grid(axis='y',alpha=.15)
    fig.supxlabel('Task panels: circle = complete safe timely; cross = unsafe/untimely; triangle = partial.\nLatency cross = withheld feedback; missing task values are not zeros.',fontsize=8)
    return fig

def main(out=output()):
    if not (out/'STEP44_RESULT.json').exists():raise RuntimeError('saved results required')
    setup_style(journal='ieee',lang='en')
    plt.rcParams.update({'font.size':8,'axes.labelsize':8,'axes.titlesize':8,'xtick.labelsize':8,'ytick.labelsize':8,'legend.fontsize':8,'font.family':'DejaVu Sans','pdf.fonttype':42,'ps.fonttype':42,'savefig.bbox':None})
    r=read(out/'STEP44_RESULT.json');folder=out/'figures';folder.mkdir(exist_ok=True)
    data=[]
    for m in METHODS:
        for d in read(out/'ALL_METHOD_DECISIONS.json'):
            if d['method']==m:
                data.append({k:d[k] for k in ('context_id','snapshot_id','episode','method','direction','fault_leg','selected_command_sent','complete_actual','safe_actual_6mm','actual_partial','overall_deadline_failure','command_ready_ms')})
    df=pd.DataFrame(data)
    profile=profile_data(df,group_cols=['method','direction','fault_leg'])
    write(folder/'DATA_PROFILE.json',profile)
    (folder/'DATA_PROFILE.md').write_text(render_report(profile),encoding='utf-8')
    reviews=[]
    for name,build,size in [('FIG1_COVERAGE_MIGRATION',coverage,(7.16,6.8)),('FIG2_LATENCY_TASK_RESPONSE',response,(7.16,5.7))]:
        fig=build(out,r);finalize_figure(fig);add_panel_labels(fig,style='nature')
        render_preview(fig,str(folder/(name+'_preview.png')),dpi=180)
        issues=audit_layout(fig)
        reviews.append(dict(name=name,layout_issues=issues,minimum_text_pt=min(t.get_fontsize() for t in fig.findobj(matplotlib.text.Text) if t.get_text()),
            planned_decisions=96,planned_severe_sources=48,physical_snapshots=24,reference_episodes=8))
        export_figure(fig,str(folder/name),formats=['pdf','png'],size_inches=size,dpi=600,grayscale_preview=True,tight=False)
        # SciPilot's grayscale helper re-saves its source PNG with tight bounds.
        # Restore the deliverable PNG to the explicit final journal dimensions.
        fig.savefig(folder/(name+'.png'),dpi=600,bbox_inches=None)
        for ext in ('pdf','png'):
            checks,info=check_figure(str(folder/(name+'.'+ext)),min_dpi=600,target_inches=size)
            reviews[-1][ext+'_checks']=checks;reviews[-1][ext+'_info']=info
        reader=PdfReader(folder/(name+'.pdf'));fonts=[]
        for page in reader.pages:
            for font in page['/Resources']['/Font'].get_object().values():
                font=font.get_object();descendants=font.get('/DescendantFonts')
                nodes=[node.get_object() for node in descendants] if descendants else [font]
                for node in nodes:
                    descriptor=node.get('/FontDescriptor')
                    descriptor=descriptor.get_object() if descriptor else {}
                    fonts.append(dict(base=str(font.get('/BaseFont')),subtype=str(node.get('/Subtype')),
                        embedded_truetype='/FontFile2' in descriptor,type3=str(node.get('/Subtype'))=='/Type3'))
        reviews[-1]['pdf_descendant_font_verification']=fonts
        reviews[-1]['pdf_font_embedding_verified']=bool(fonts) and all(v['embedded_truetype'] and not v['type3'] for v in fonts)
        reviews[-1]['pdf_dimensions_inches']=[float(reader.pages[0].mediabox.width)/72,float(reader.pages[0].mediabox.height)/72]
        plt.close(fig)
    write(folder/'PROGRAMMATIC_FIGURE_QA.json',reviews)
    write(folder/'FIGURE_SOURCE_INDEX.json',[dict(direction=p['direction'],ordinal=i+1,context_id=p['context_id'],snapshot_id=p['snapshot_id'],episode=p['episode'],fault_leg=p['fault_leg'],tick=p['tick'],displacement_m=p['displacement_m']) for direction in (1,-1) for i,p in enumerate([p for p in r['confirmation']['source_pairs'] if p['direction']==direction])])
if __name__=='__main__':main()
