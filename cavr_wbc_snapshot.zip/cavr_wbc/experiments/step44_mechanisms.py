"""Saved-only original Type-II, independent paired methods and fixed STEP44 endpoints."""
from cavr_wbc.experiments.step39_delivery import safe,physical_terminal
from cavr_wbc.experiments.step40_mechanisms import mechanism,endpoint
from cavr_wbc.experiments.step43_mechanisms import distribution
from cavr_wbc.experiments.step44_inputs import METHODS,severe_plans

def type_ii(rows,decisions):
    by={r['id']:r for r in rows};dm={(d['context_id'],d['method']):d for d in decisions}
    direct=[];online={m:[] for m in METHODS}
    for p in severe_plans():
        cid=p['context_id'];snap=p['snapshot_id'];leg=p['fault_leg']
        H=by[snap+'_HEALTHY:B'];L=by[snap+'_'+leg+'_THIGH30:B'];B=by[cid+':B'];M=by[cid+':MIDDLE']
        common={k:p[k] for k in ('context_id','snapshot_id','episode','tick','direction','fault_leg','displacement_m')}
        common.update(healthy_shared_control_id=H['id'],mild_control_id=L['id'],severe_B_id=B['id'],
            actual_capacity99_s=B['first_actual_99percent_s'],first_dense_failure_s=B['first_dense_failure_s'],
            first_dense_failure_reasons=B['first_dense_failure_reasons'])
        direct_m=mechanism('TYPE_II',H,L,B,M)
        direct.append(dict(**common,**direct_m,middle_id=M['id'],
            opportunity_state='UNKNOWN' if not direct_m['complete_pair'] else 'OPPORTUNITY' if direct_m['qualified'] else 'NOT_QUALIFIED'))
        for method in METHODS:
            d=dm[(cid,method)];A=by[cid+':'+method+'_ACTUAL'];o=mechanism('TYPE_II',H,L,B,A)
            sent=bool(d['selected_command_sent'] and d['selected_gamma']==.5)
            o['complete_pair']=bool(H['complete_501'] and L['complete_501'] and B['complete_501'] and (A['complete_501'] if sent else d['decision_exists']))
            o['qualified']=bool(o['qualified'] and sent)
            o['timing_qualified_mechanism']=bool(o['timing_qualified_mechanism'] and sent and A['timing_qualified'])
            online[method].append(dict(**common,**o,method=method,middle_id=A['id'],
                online_middle_sent=sent,own_actual=True,actual_packet_sha256=d['decision_sha256'],
                own_application_identity_verified=bool(A.get('application_identity_pass')),
                direct_opportunity_state=direct[-1]['opportunity_state'],direct_opportunity_timely=direct_m['timing_qualified_mechanism'],
                unapplied_true_safety='UNKNOWN' if not sent else 'MEASURED'))
    return dict(TYPE_I='NOT_TESTED',direct=endpoint(direct),online={m:endpoint(v) for m,v in online.items()},
        planned_severe_sources=48,healthy_shared_positions=24,healthy_controls_not_independent_replication=True,
        direct_opportunity_unknown=sum(p['opportunity_state']=='UNKNOWN' for p in direct))

def evaluate(rows,decisions,evidence,complete_panel):
    mech=type_ii(rows,decisions);by={r['id']:r for r in rows}
    methods={};matrices={};tasks={};pairs=[]
    for method in METHODS:
        ds=[d for d in decisions if d['method']==method];acts=[by[d['context_id']+':'+method+'_ACTUAL'] for d in ds]
        errors=sum(d['selected_command_sent'] and d['complete_actual'] and not d['safe_actual_6mm'] for d in ds)
        unresolved=sum(d['selected_command_sent'] and not (d['complete_actual'] and d['timing_qualified_actual']) for d in ds)
        S=('FAIL' if errors else 'NOT_ESTABLISHED' if unresolved or evidence['status']!='VERIFIED' or not complete_panel or not any(d['selected_command_sent'] for d in ds) else 'FINITE_EMPIRICAL_ACCEPTANCE_ESTABLISHED')
        physical_pairs=mech['online'][method]['pairs']
        timely=[dict(p,qualified=bool(p['timing_qualified_mechanism'])) for p in physical_pairs]
        dist=distribution(timely);negative=[p for p in timely if p['direction']<0 and p['fault_leg']=='RR' and p['qualified']]
        negative_ep=len({p['episode'] for p in negative})
        C=bool(S=='FINITE_EMPIRICAL_ACCEPTANCE_ESTABLISHED' and complete_panel and dist['snapshots']>=3 and dist['episodes']>=2 and negative_ep>=2)
        opportunities=mech['direct']['pairs']
        pp=[p for p in opportunities if p['qualified']];tp=[p for p in opportunities if p['timing_qualified_mechanism']]
        ownp={p['context_id'] for p in physical_pairs if p['qualified']};ownt={p['context_id'] for p in timely if p['qualified']}
        methods[method]=dict(planned=48,saved=sum(d['decision_exists'] for d in ds),recognized=sum(d['selected_command_sent'] for d in ds),
            recognized_middle=sum(d['selected_command_sent'] and d['selected_gamma']==.5 for d in ds),
            complete=sum(d['complete_actual'] for d in ds),complete_safe=sum(safe(r) for r in acts),
            complete_safe_timely=sum(safe(r) and r['timing_qualified'] for r in acts),complete_error_accepts=errors,unresolved_sent=unresolved,
            partial=sum(d['actual_partial'] for d in ds),ABSTAIN=sum(d['status']=='ABSTAIN' for d in ds),late=sum(d['overall_deadline_failure'] for d in ds),
            candidate_budget_not_evaluated=sum(q['evaluation_status']=='NOT_EVALUATED_BUDGET' for d in ds for q in d['queries']),
            S=S,C='ESTABLISHED_IN_MEASURED_SCOPE' if C else 'NOT_ESTABLISHED',online_type_ii_distribution=dist,
            negative_RR_episodes=negative_ep,negative_RR_scope='CONFIRMED_IN_AT_LEAST_TWO_EPISODES' if negative_ep>=2 else 'NOT_ESTABLISHED',
            opportunity_denominator=len(pp),timely_opportunity_denominator=len(tp),opportunity_unknown=mech['direct_opportunity_unknown'],
            physical_closure_in_opportunities=sum(p['context_id'] in ownp for p in pp),
            timely_closure_in_opportunities=sum(p['context_id'] in ownt for p in tp),
            physical_opportunity_fraction=sum(p['context_id'] in ownp for p in pp)/len(pp) if pp else None,
            timely_opportunity_fraction=sum(p['context_id'] in ownt for p in tp)/len(tp) if tp else None)
        matrices[method]=[]
        for direction in (1,-1):
            for leg in ('FR','RR'):
                subset=[d for d in ds if d['direction']==direction and d['fault_leg']==leg]
                qualified=[p for p in timely if p['direction']==direction and p['fault_leg']==leg]
                matrices[method].append(dict(direction=direction,fault_leg=leg,planned=len(subset),
                    recognized=sum(d['selected_command_sent'] for d in subset),
                    complete_safe=sum(d['safe_actual_6mm'] for d in subset),
                    error_accepts=sum(d['selected_command_sent'] and d['complete_actual'] and not d['safe_actual_6mm'] for d in subset),
                    partial=sum(d['actual_partial'] for d in subset),ABSTAIN=sum(d['status']=='ABSTAIN' for d in subset),late=sum(d['overall_deadline_failure'] for d in subset),
                    **distribution(qualified)))
        tasks[method]=[]
        for d,A in zip(ds,acts):
            B=by[d['context_id']+':B'];M=by[d['context_id']+':MIDDLE'];at=A.get('task_response') or {};bt=B.get('task_response') or {}
            gain=None if A['progress02_04_m'] is None or B['progress02_04_m'] is None else A['progress02_04_m']-B['progress02_04_m']
            terminal=None if not (at.get('complete') and bt.get('complete')) else abs(at['terminal_base_task_error_m'])-abs(bt['terminal_base_task_error_m'])
            integral=None if not (at.get('complete') and bt.get('complete')) else at['time_mean_abs_base_task_error_m']-bt['time_mean_abs_base_task_error_m']
            tasks[method].append(dict(**{k:d[k] for k in ('context_id','snapshot_id','episode','tick','direction','fault_leg','displacement_m')},
                method=method,planned=True,selected=d['selected_command_sent'],gamma=d['selected_gamma'],
                actual_safe=safe(A),actual_timely=A['timing_qualified'],B_safe=safe(B),B_timely=B['timing_qualified'],
                ACTUAL_outcome=outcome_local(A),B_outcome=outcome_local(B),direct_middle_outcome=outcome_local(M),
                first_action_gain_m=gain,first_action_relative_gain=None if B['progress02_04_m'] in (None,0) or gain is None else gain/B['progress02_04_m'],
                terminal_absolute_task_error_change_m=terminal,full_horizon_abs_task_error_integral_change_m_s=integral,
                ACTUAL_task=at,B_task=bt,own_actual_id=A['id'],B_control_id=B['id'],
                unobserved_value_is_not_zero=True))
        observed=[p for p in tasks[method] if p['selected'] and p['gamma']==.5 and p['actual_safe'] and p['actual_timely'] and p['terminal_absolute_task_error_change_m'] is not None]
        methods[method]['task_middle_descriptives']=dict(full_pairs=len(observed),short_gain_positive=sum(p['first_action_gain_m'] is not None and p['first_action_gain_m']>0 for p in observed),
            terminal_abs_error_improved=sum(p['terminal_absolute_task_error_change_m']<0 for p in observed),terminal_abs_error_worse=sum(p['terminal_absolute_task_error_change_m']>0 for p in observed),
            error_integral_improved=sum(p['full_horizon_abs_task_error_integral_change_m_s']<0 for p in observed),
            full_task_improvement_claim='NOT_ESTABLISHED_AS_GENERAL_TASK_IMPROVEMENT')
    dm={(d['context_id'],d['method']):d for d in decisions}
    for p in severe_plans():
        cid=p['context_id'];a,b=[dm[(cid,m)] for m in METHODS]
        op=next(q for q in mech['direct']['pairs'] if q['context_id']==cid)
        online={m:next(q for q in mech['online'][m]['pairs'] if q['context_id']==cid) for m in METHODS}
        pairs.append(dict(**{k:p[k] for k in ('context_id','snapshot_id','episode','tick','direction','fault_leg','displacement_m')},
            direct_opportunity=op['opportunity_state'],direct_opportunity_timely=op['timing_qualified_mechanism'],
            old=a,augmented=b,online_type_ii=online,
            added_safe_coverage=bool(not a['selected_command_sent'] and b['safe_actual_6mm'] and b['timing_qualified_actual']),
            lost_safe_coverage=bool(a['safe_actual_6mm'] and a['timing_qualified_actual'] and not b['selected_command_sent']),
            transition=str(a['selected_gamma'] if a['selected_command_sent'] else 'ABSTAIN')+' -> '+str(b['selected_gamma'] if b['selected_command_sent'] else 'ABSTAIN'),
            same_source_not_same_packet=True))
    primary=methods[METHODS[1]]
    return dict(status='INCOMPLETE' if not complete_panel else 'FAIL' if primary['S']=='FAIL' else 'CAPACITY_ONLINE_CLOSURE_IN_SCOPE' if primary['C']=='ESTABLISHED_IN_MEASURED_SCOPE' else 'NOT_ESTABLISHED',
        methods=methods,TypeII=mech,direction_leg_support=matrices,task_use=tasks,source_pairs=pairs,
        attribution='APPEND_CAL_SUPPORT_PLUS_FIXED_FORMULA_RESIDUAL_RISK_DISTANCE_DOMAIN_DERIVATIVES; NOT_SINGLE_GATE_CAUSAL_EFFECT',
        no_IID_population_or_formal_safety_claim=True)

def outcome_local(r):
    from cavr_wbc.experiments.step39_delivery import outcome
    return outcome(r)
