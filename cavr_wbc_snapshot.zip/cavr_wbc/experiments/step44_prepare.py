"""The single filesystem/import preparation; no solver, simulation or probe."""
import shutil
from cavr_wbc.experiments.step44_io import *
from cavr_wbc.experiments.step44_identity import load_frozen
def prepare():
    out=output();out.mkdir(parents=True,exist_ok=True)
    if (out/'PREPARATION.json').exists():raise FileExistsError('preparation once')
    freeze=read(SOURCE_DOMAIN/'TERMINAL_CAL_DOMAIN_FREEZE.json')
    domain=SOURCE_DOMAIN/'TERMINAL_CAL_DOMAIN.json'
    if sha(domain)!=freeze['sha256']:raise ValueError('OLD frozen domain hash')
    shutil.copyfile(domain,out/'OLD_TERMINAL_CAL_DOMAIN.json')
    names=('step42_kernel.py','step42_physical_consensus.py','step39_margin.py','step41_terminal_domain.py')
    source={n:sha(SOURCE_ROOT_D/'cavr_wbc/control'/n) for n in names}
    actual={n:sha(OUTPUT_ROOT_D/'cavr_wbc/control'/n) for n in names}
    if source!=actual:raise ValueError('unchanged acceptance source bytes')
    write(out/'ACCEPTANCE_IDENTITY_FREEZE.json',dict(source_sha256=source,sha256=actual,byte_exact=True))
    bundle,identity=load_frozen()
    import cavr_wbc,osqp,mujoco,scipy
    if not Path(cavr_wbc.__file__).resolve().is_relative_to(OUTPUT_ROOT_D):raise ValueError('import checkout location')
    write(out/'PREPARATION.json',dict(identity=identity,domain_sha256=freeze['sha256'],
        cavr_wbc_file=cavr_wbc.__file__,new_numeric_actions=0,new_fits=0,
        source_HEAD=SOURCE_COMMIT,source_index_sha256='10c374b7b74b0ad14f116177a2e273c57564d0b32d3ab65dba24d9cd7138fe4c',
        source_git_status_start=[],D_free_bytes_before=73250566144,D_write_marker=True))
    print(dict(prepared=True,import_location=cavr_wbc.__file__,new_numeric_actions=0))
if __name__=='__main__':prepare()
