"""Chinese report and research handoff from saved STEP44 evidence."""
from collections import Counter
from cavr_wbc.experiments.step44_io import *
from cavr_wbc.experiments.step44_inputs import METHODS
from cavr_wbc.experiments.step39_delivery import safe
def main(out=output()):
    r=read(out/'STEP44_RESULT.json');c=r['confirmation'];m=r['methods'];a=m[METHODS[1]]
    git=read(out/'SCOPED_GIT_VERIFICATION.json',{})
    hist=bool(git.get('source_HEAD_unchanged') and git.get('source_index_unchanged') and git.get('source_RESULT_blob_unchanged') and r['source_acceptance_unchanged'] and r['readback']['status']=='VERIFIED')
    protocol=dict(AUTHORIZE_STEP44_MATCHED_CAL_AND_PAIRED_TEST='TRUE',SOURCE_STEP43_RESULT_UNCHANGED='TRUE' if hist else 'NOT_VERIFIED',
        STEP44_NEW_CAL_PLANNED=128,STEP44_TEST_SEVERE_CONTEXTS=48,STEP44_ONLINE_DECISIONS_PLANNED=96,STEP44_DIRECT_TRAJECTORIES_PLANNED=168,
        STEP44_MAX_NEW_1S_BRANCHES=392,STEP44_REFERENCE_EPISODES=16,STEP44_NEW_FITS=0,
        STEP44_OLD_CAL_ROWS_RETAINED='TRUE' if r['readback']['status']=='VERIFIED' and read(out/'OLD_CAL_PREFIX_CHECK.json',{}).get('status')=='VERIFIED' else 'NOT_VERIFIED',
        STEP44_SAFETY_ACCEPTANCE=a['S'],STEP44_ONLINE_TYPE_II=a['C'],STEP44_RR_NEGATIVE_SCOPE=a['negative_RR_scope'],
        STEP44_FULL_TASK_IMPROVEMENT=a['task_middle_descriptives']['full_task_improvement_claim'],
        E3_AUTHORIZED='FALSE',RL_HARDWARE_AUTHORIZED='FALSE',HISTORICAL_RESULTS_UNCHANGED='TRUE' if hist else 'NOT_VERIFIED')
    (out/'PROTOCOL_STATUS.ini').write_text('\n'.join(f'{k} = {v}' for k,v in protocol.items())+'\n',encoding='utf-8',newline='\n')
    phase=r['run']['budget'];f=r['cal_freeze'] or {}
    lines=['# STEP44：匹配 CAL 与在线容量恢复','',
        f"执行状态：**{r['task_execution_status']}**；研究端点：**{c['status']}**。",
        f"增强 CAL 方法发送 {a['recognized']}/48 个 own ACTUAL，完整安全 {a['complete_safe']}，完整错受 {a['complete_error_accepts']}；时延合格在线 Type-II {a['online_type_ii_distribution']['contexts']} 个 severe source、{a['online_type_ii_distribution']['snapshots']} 个 physical snapshot、{a['online_type_ii_distribution']['episodes']} 个 reference episode，负向 RR 覆盖 {a['negative_RR_episodes']} 个 episode。",
        '', '## 固定对照与 CAL 冻结','',
        '两方法独立 resident owner、独立 B0/packet/ACTUAL；源状态相同，不强制 packet 相同。唯一变化是 CAL 追加及原公式得到的 residual/risk/distance/domain 派生量。预测器、TRAIN、四邻居选择、控制器、backup、20 ms/6 mm/physical/terminal 验收保持固定。',
        f"CAL 计划128条（32 snapshot / 8 episode），记录 {f.get('recorded',0)} 条，有限特征 {f.get('finite',0)} 条，完整网格 {f.get('complete',0)} 条。TEST 使用另外24 snapshot / 8 episode；48 severe source，每种方法48决定，另有168条 direct。16次新参考推进计入总资源，不与392条上界混算。",
        '旧失败、unknown、数值数组前缀及原域记录全部保留；有有限特征的 partial/unknown 可被原排序选中，不以第五个安全邻居替代。CAL 冻结在 TEST 参考生成之前，未消费 TEST 标签。重复 snapshot 的 FR/RR 和共享 healthy 对照不增加独立 episode 数。',
        '', '| 方法 | planned | 发送 | 完整安全 | 安全且实时 | 完整错受 | partial | 弃权 | late | 在线Type-II（实时） |',
        '|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
    for method in METHODS:
        v=m[method]
        lines.append('| '+method+' | '+' | '.join(str(v[k]) for k in ('planned','recognized','complete_safe','complete_safe_timely','complete_error_accepts','partial','ABSTAIN','late'))+' | '+str(v['online_type_ii_distribution']['contexts'])+' |')
    lines+=['','## S / C：安全接受与容量恢复','',
        'S 对所有已发送 ACTUAL 要求完整1 s、原 physical+terminal+6 mm及每个必要实时窗口。完整错受为FAIL；发送后未完成/未验证为NOT_ESTABLISHED；无发送不建立用途。本轮零错受仅描述有限冻结来源。',
        'C 保留 healthy B、同腿 mild(.30) B、severe(.15) B、middle 的四方定义，要求实际 sent/effective capacity≥99% 严格先于 dense physical failure。在线 middle 必须由该方法及时发送γ=.5并真实推进 own ACTUAL；不能用离线 direct 的成功代替在线恢复。主门槛为S成立、面板完整、≥3 snapshot /2 episode，且负向RR≥2 episode。','']
    for method in METHODS:
        v=m[method];lines.append(f"- {method}：S={v['S']}；C={v['C']}；direct机会物理分母{v['opportunity_denominator']}，本方法物理闭合{v['physical_closure_in_opportunities']}；direct机会实时分母{v['timely_opportunity_denominator']}，本方法实时闭合{v['timely_closure_in_opportunities']}；direct未知{v['opportunity_unknown']}。")
    lines+=['','| 方法 | direction / leg | planned | 发送 | 完整安全 | 在线Type-II | snapshot | episode |',
        '|---|---|---:|---:|---:|---:|---:|---:|']
    for method,vs in c['direction_leg_support'].items():
        for v in vs:lines.append('| '+method+' | '+('+' if v['direction']>0 else '-')+v['fault_leg']+' | '+' | '.join(str(v[k]) for k in ('planned','recognized','complete_safe','contexts','snapshots','episodes'))+' |')
    pairs=c['source_pairs']
    partials=[v for v in read(out/'ALL_PLANNED_RESULTS.json') if v['branch'].endswith('_ACTUAL') and v['observed'] and not v['complete_501']]
    for v in partials:
        reason=v.get('reason') or {}
        lines.append(f"已发送未完成案例：{v['id']}，状态{v['status']}；slot={reason.get('slot')}，已推进{reason.get('physics_step')}个物理步（本例0.96 s），最大反馈时延{v['max_feedback_latency_ms']:.4f} ms。超时动作未应用，完整1 s安全性不能由前缀替代；该案例不删除、不重跑。")
    lines+=['',f"逐源配对新增安全覆盖 {sum(p['added_safe_coverage'] for p in pairs)}，失去安全覆盖 {sum(p['lost_safe_coverage'] for p in pairs)}。来源迁移和每个γ的邻居/拒收理由保留于 [SAME_SOURCE_METHOD_PAIRS.json](SAME_SOURCE_METHOD_PAIRS.json) 与 [NEIGHBOR_REJECTION_MIGRATIONS.json](NEIGHBOR_REJECTION_MIGRATIONS.json)。未应用候选真安全性为UNKNOWN；本轮变化不归因于单一consensus门。",
        '', '## U：首动作与整段任务分开','',
        '报告全部48个planned source/方法：首动作有向进度(.02–.04 s)、1 s末外部任务绝对误差/有向COM位移、全段绝对任务误差积分。缺测留空，不按零值补齐，不仅展示成功者。safe-B对照及物理失败B分别保留在任务配对表。',
        'STEP43已公开的14个middle首动作增益成立，14/14末任务绝对误差略变差；该历史事实原样保留，本轮不重跑历史轨迹。','']
    for method in METHODS:
        t=m[method]['task_middle_descriptives'];ps=c['task_use'][method]
        lines.append(f"- {method}：安全实时middle完整任务配对{t['full_pairs']}；首动作正增益{t['short_gain_positive']}；末绝对误差改善{t['terminal_abs_error_improved']}、变差{t['terminal_abs_error_worse']}；全段误差积分改善{t['error_integral_improved']}。全部planned首动作可测{sum(p['first_action_gain_m'] is not None for p in ps)}/48、末任务可测{sum(p['terminal_absolute_task_error_change_m'] is not None for p in ps)}/48。")
    lines+=['','## 实时与资源','',
        f"一次唯一数值启动。首次数值动作 {phase['numerical_started_utc']}；累计QP {phase['total_QP_calls']} /35000、物理步 {phase['total_physics_steps']} /350000，数值墙钟 {phase['numerical_elapsed_s']:.1f} s /10800 s；fit=0，结果驱动重试=0。",
        f"QP START/RETURN/raw={r['readback']['qp_starts']}/{r['readback']['qp_returns']}/{r['readback']['raw_qp_shards']}；unknown QP={r['readback']['unknown_qp']}。必要纯测试12项通过；唯一当前运行读回={r['readback']['status']}，读回不产生求解或物理推进。",
        'B/C/feedback内部6/3/6 ms只是子预算，不是放宽完整20 ms截止。完整决定、已发送准备窗口和每个feedback窗口见 [LATENCY_ALL_WINDOWS.csv](LATENCY_ALL_WINDOWS.csv)。',
        '', '## 两图与数据','',
        f"![图1]({(out/'figures/FIG1_COVERAGE_MIGRATION.png').as_posix()})",'',
        '图1：四个direction×leg分层的planned→sent→complete-safe→online Type-II；逐源格包含全部96个决定，星号表示时延合格在线Type-II；direct未知保留为?。分组计数标注独立physical snapshot/episode。来源序号与故障、位移、tick对应见figure source index。',
        '', f"![图2]({(out/'figures/FIG2_LATENCY_TASK_RESPONSE.png').as_posix()})",'',
        '图2：全部已发送准备与feedback窗口（20 ms线），并列首动作有向增益、1 s末任务绝对误差变化和全段误差积分变化。所有可测 own ACTUAL 均显示，失败/不及时/partial采用冗余形状；每方法planned=48，缺测显式计数。任务误差变化<0才代表该量改善。',
        '', 'SciPilot：完整数据剖析、色盲友好配色/形状、600 dpi PNG、嵌入字体PDF、灰度预览和一次视觉检查记录见figures目录。',
        '', '## 交付与停止','',
        f"源提交：{SOURCE_COMMIT}。工作区：{OUTPUT_ROOT_D.as_posix()}。分支：codex/step44-matched-cal-online-recovery-20261011。所有新代码/工件写D，E依赖只读使用。源HEAD/index核对见SCOPED_GIT_VERIFICATION.json；未推送。",
        '本轮结束，不自动开启STEP45，不进入E3/RL/硬件。协议全部状态如下：','', '~~~ini',
        *[f'{k} = {v}' for k,v in protocol.items()],'~~~','']
    (out/'REPORT.md').write_text('\n'.join(lines),encoding='utf-8',newline='\n')
    handoff=['# STEP44 研究交接','',f"结果：{c['status']}；执行：{r['task_execution_status']}。",
        '证据入口：REPORT.md、STEP44_RESULT.json、PROTOCOL_STATUS.ini、CURRENT_RUN_READBACK.json、STEP44_CAL_FREEZE.json、QP与attempt ledger、全部原始轨迹/控制shard。',
        '',f"主方法S={a['S']}；C={a['C']}；negativeRR={a['negative_RR_scope']}。",
        f"已观察到时延合格在线Type-II {a['online_type_ii_distribution']['contexts']}个source /{a['online_type_ii_distribution']['snapshots']} snapshot /{a['online_type_ii_distribution']['episodes']} episode（均为负向RR），数量与范围门槛已满足；但增强方法13个已发送ACTUAL中1个在0.96 s因37.0346 ms反馈截止失败，S未建立，故总体C不能建立。下一项实质缺口是已发送闭环的实时完整性，不是继续增添成功CAL或删除partial。",
        '若达到端点，下一项研究应是该测得恢复范围的独立确认与更长任务闭环设计；若未达到，依据固定OLD/AUG配对和拒收迁移区分支持/预测/backup缺口。未授权任何下一轮求解。',
        '新增CAL改变的是支持及原公式派生量，不能解释成单一consensus门的独立因果效果；首动作收益、末任务误差和全段积分分开。',
        '固定科学输入、旧CAL失败/unknown、完整源记录、未应用候选UNKNOWN全部保留；不允许以本轮TEST转入CAL。E3/RL/硬件均未授权。',
        '',f"worktree={OUTPUT_ROOT_D.as_posix()}",f"source_SHA={SOURCE_COMMIT}",f"run_id={out.name}",'']
    (out/'HANDOFF.md').write_text('\n'.join(handoff),encoding='utf-8',newline='\n')
    write(out/'MATERIAL_PASSPORT.json',dict(evidence_integrity=r['readback']['status'],independent_reproduction='UNVERIFIED_NOT_RERUN',
        predictor_TRAIN_and_acceptance_algorithm_unchanged=r['source_acceptance_unchanged'],numeric_launches=1,fit_count=0,
        CAL_TEST_separation='FROZEN_BEFORE_TEST',source_SHA=SOURCE_COMMIT,source_unchanged=hist,finite_deterministic_measured_scope=True,
        scoped_git_receipt='SCOPED_GIT_VERIFICATION.json',tests='tests/NECESSARY_TESTS.json',readback='CURRENT_RUN_READBACK.json',
        raw_ledger='STEP44_LEDGER.jsonl',attempt_ledger='ATTEMPT_LEDGER.jsonl',visual_qa='figures/VISUAL_REVIEW.json'))
if __name__=='__main__':main()
