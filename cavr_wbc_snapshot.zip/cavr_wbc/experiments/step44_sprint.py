"""One independent CAL append/freeze followed by one fixed matched TEST panel."""
from copy import deepcopy
from datetime import datetime, timezone
import gc
import os
import traceback
import numpy as np
from cavr_wbc.experiments.step44_io import *
from cavr_wbc.experiments.step44_inputs import episodes, plans, context_for, BRANCHES, OWNER_BRANCHES, METHODS, severe_plans, snapshot_groups, planned_positions
from cavr_wbc.experiments.step44_budget import SprintBudget, SprintLimit
from cavr_wbc.experiments.step44_storage import save_branch, not_run
from cavr_wbc.experiments.step44_identity import load_frozen, bundle_identity
from cavr_wbc.experiments.step35_reference import reference_episode
from cavr_wbc.experiments.step28_sprint import home_context
from cavr_wbc.experiments import step17_formal_panel as frozen, step38_sim as sim
from cavr_wbc.control.step39_kernel import Kernel as LegacyKernel, direct_packet
from cavr_wbc.control.step42_kernel import Kernel as DomainKernel
from cavr_wbc.control.step41_terminal_domain import ResidentDomain
Kernel = LegacyKernel
from cavr_wbc.experiments.step39_training import forward_entry,record
from cavr_wbc.experiments.step44_calibration import domain_record,freeze as freeze_cal
from cavr_wbc.platforms.go2_mujoco import extract_actuator_audit, extract_healthy_torque_limits


def event(out, name, **values):
    append(out / 'ATTEMPT_LEDGER.jsonl', {'event': name,
        'timestamp_utc': datetime.now(timezone.utc).isoformat(), **values})


def make_owner(model, budget, c, manifest, method='DIRECT', domain=None):
    k = (DomainKernel(model, 'BOUNDED', str(NATIVE_DLL), budget, domain=domain, consensus_enabled=True) if method in METHODS else LegacyKernel(model, 'BOUNDED', str(NATIVE_DLL), budget))
    home = home_context(model, manifest['scenario'])
    home.update(context_id=c['context_id'] + ':' + method + ':HOME', backup_id=c['backup_id'] + ':' + method + ':HOME')
    startup = k.startup(home, budget)
    k.flush_raw_evidence()
    return k, startup


def reference_inputs(out, split, model, manifest, budget):
    contexts = []
    for ep in episodes(split):
        event(out, 'START', kind='REFERENCE', **ep)
        episode = reference_episode(model, manifest['reference_scenario'], ep['displacement_m'],
            ep['episode_id'], ep['snapshot_ticks'], budget, evidence_callback=budget.record_raw)
        for c in episode['controls']:
            c.pop('raw_solver_result', None)
        save_numeric(out / 'episodes' / (ep['episode_id'] + '.json'), episode)
        event(out, 'RETURN', kind='REFERENCE', episode_id=ep['episode_id'],
              status=episode['status'], counts=episode['counts'])
        contexts.extend(context_for(p, episode, manifest['mapping']) for p in plans(split)
                        if p['episode'] == ep['episode_id'])
        budget.persist(phase='REFERENCE_SAVED', episode=ep['episode_id'])
    save_numeric(out / (split+'_CONTEXTS.json'), contexts)
    return contexts


def packet_once(out, path, c, model, budget, manifest):
    owners, startup = {}, {}
    if c.get('eligible'):
        for name, _ in OWNER_BRANCHES:
            owners[name], startup[name] = make_owner(model, budget, c, manifest)
        packet = direct_packet(owners['B'], c, budget, owners)
        owners['B'].flush_raw_evidence()
    else:
        packet = {'context_id': c['context_id'], 'selected_command_sent': False,
                  'status': 'SOURCE_INELIGIBLE', 'command_ready_ms': 0., 'actions': {}}
    write(path / 'STARTUP.json', startup)
    save_numeric(path / 'PACKET.json', packet)
    return owners, packet


def run(run_id=RUN_ID):
    out = output(run_id)
    if (out / 'RUN_STARTED.json').exists():
        raise FileExistsError('STEP44 run already attempted; no numerical restart')
    out.mkdir(parents=True, exist_ok=True)
    old = read(SOURCE39 / 'PROTOCOL_AND_MANIFEST.json')
    bundle, screen = load_frozen()
    table_path=out/'OLD_TERMINAL_CAL_DOMAIN.json'
    table_freeze=read(SOURCE_DOMAIN/'TERMINAL_CAL_DOMAIN_FREEZE.json')
    if sha(table_path)!=table_freeze['sha256']:raise ValueError('OLD domain byte identity')
    old_table=read(table_path)
    domain=ResidentDomain(old_table,sha(table_path))
    frozen_sources = {name:sha(OUTPUT_ROOT_D/'cavr_wbc/control'/name) for name in ('step42_kernel.py','step42_physical_consensus.py','step39_margin.py','step41_terminal_domain.py')}
    if frozen_sources != read(out/'ACCEPTANCE_IDENTITY_FREEZE.json')['sha256']:
        raise ValueError('frozen acceptance source byte identity mismatch')
    model = frozen.load_model()
    limits = extract_healthy_torque_limits(model)
    mapping = [dict(r, healthy_limit_nm=float(limits[r['actuator_index']])) for r in extract_actuator_audit(model)]
    inherited = ('scenario', 'reference_scenario', 'feature_names', 'feature_units',
                 'feature_scale_floors', 'feature_dimension', 'online_gamma_order',
                 'actual_local_bound_m', 'deadline_ms', 'horizon_s', 'physics_dt_s',
                 'candidate_eps', 'reference_eps', 'first_B_limit_s', 'first_C_limit_s',
                 'feedback_limit_s', 'friction_upper_N', 'torque_inset_Nm',
                 'original_inequality_extra_slack', 'empirical_D_reserve_main_m')
    manifest = {k: deepcopy(old[k]) for k in inherited}
    assets = OUTPUT_ROOT_D / 'third_party/unitree_mujoco_snapshot/unitree_robots/go2'
    model_bytes = {relative(p, OUTPUT_ROOT_D): sha(p) for p in assets.rglob('*') if p.is_file()}
    physical = deepcopy(old['frozen_physical'])
    physical['model_files_sha256'] = model_bytes
    manifest.update(run_id=run_id, source_commit=SOURCE_COMMIT,
        source_worktree_read_only=str(SOURCE_ROOT_D), new_file_drive='D',
        native_dll_path=str(NATIVE_DLL), native_dll_sha256=sha(NATIVE_DLL),
        frozen_physical=physical, mapping=mapping, protocol_sha256=sha(PROTOCOL),
        reference_episodes=episodes('CAL')+episodes('TEST'), CAL_plans=plans('CAL'), TEST_plans=plans('TEST'),
        max_QP_calls=35000, max_physics_steps=350000, max_wall_s=10800,
        max_fits=0, new_CAL_planned=128, engineering_repair_only_no_semantics=True,
        frozen_screen=screen, model_checkout_bytes_not_old_CRLF_bytes=True,
        acceptance_algorithm_unchanged=True, new_acceptance_gates=0, online_health=.15, offline_control_healths=[1.,.30], TYPE_I='NOT_TESTED',
        screen_version='MATCHED_OLD_AND_AUGMENTED_CAL_CONSENSUS', terminal_domain_sha256=table_freeze['sha256'], local_neighbor_selection_unchanged=True, method_source_sha256={name:sha(OUTPUT_ROOT_D/'cavr_wbc/control'/name) for name in ('step41_kernel.py','step42_kernel.py','step42_physical_consensus.py','step39_margin.py','step41_terminal_domain.py')}, E3_RL_hardware_authorized=False)
    write(out / 'PROTOCOL_AND_MANIFEST.json', manifest)
    positions = planned_positions()
    write(out / 'FROZEN_INPUTS.json', {'CAL':plans('CAL'),'TEST': plans('TEST'), 'planned_branch_positions': positions,
        'CAL_physical_snapshots':32,'TEST_physical_snapshots':24,'distinct_episodes':16,'new_CAL_planned':128,'new_fits':0,
        'planned_decisions': [{'id':p['context_id']+':'+method,'context_id':p['context_id'],'method':method} for p in severe_plans() for method in METHODS],
        'methods': list(METHODS), 'context_order': [list(METHODS if i%2==0 else METHODS[::-1]) for i,p in enumerate(severe_plans())],
        'healthy_B_shared_once':True,'TYPE_I':'NOT_TESTED'})
    write(out / 'SCREEN_IDENTITY_START.json', screen)
    write(out / 'RUNTIME_FREEZE.json', {'source_commit': SOURCE_COMMIT, 'protocol_sha256': sha(PROTOCOL),
        'runtime_sha256': {relative(p, OUTPUT_ROOT_D): sha(p) for p in
            [*OUTPUT_ROOT_D.glob('cavr_wbc/**/*.py'), OUTPUT_ROOT_D / 'tests/test_step44_protocol.py']},
        'model_checkout_bytes': model_bytes})
    import cavr_wbc, scipy, osqp, mujoco, threadpoolctl
    if not Path(cavr_wbc.__file__).resolve().is_relative_to(OUTPUT_ROOT_D):
        raise ValueError('wrong cavr_wbc package')
    write(out / 'ENVIRONMENT.json', {'cavr_wbc_file': cavr_wbc.__file__,
        'numpy': np.__version__, 'scipy': scipy.__version__, 'osqp': osqp.__version__,
        'mujoco': mujoco.__version__, 'threadpools': threadpoolctl.threadpool_info(),
        'TMP': os.environ.get('TMP'), 'TEMP': os.environ.get('TEMP'), 'MPLCONFIGDIR': os.environ.get('MPLCONFIGDIR'),
        'D_write_and_free_check_once': True, 'D_free_bytes_before': 73250566144,
        'readonly_git_alternates': (OUTPUT_ROOT_D / '.git/objects/info/alternates').read_text().splitlines(),
        'new_objects_index_logs_on_D': True, 'protected_robot_control_project_accessed': False})
    budget = SprintBudget(out)
    status = 'COMPLETED'
    write(out / 'RUN_STARTED.json', {'run_id': run_id, 'pid': os.getpid(),
        'start_utc': datetime.now(timezone.utc).isoformat(), 'command': 'cavr_wbc.experiments.step44_launch'})
    try:
        calcontexts=reference_inputs(out,'CAL',model,manifest,budget)
        prefix_owner=LegacyKernel(model,'BOUNDED',str(NATIVE_DLL),budget)
        calrows=[];domain_rows=[]
        for p,c in zip(plans('CAL'),calcontexts):
            path=out/'CAL'/c['context_id']
            save_numeric(path/'SOURCE_IDENTITY.json',{'plan':p,'context':c})
            owners,packet=packet_once(out,path,c,model,budget,manifest)
            for name,gamma in BRANCHES:
                event(out,'START',kind='CAL_BRANCH',context_id=c['context_id'],branch=name)
                action=(packet['actions'].get(str(gamma)) or {}).get('action') or {}
                entry={'features28':None,'prefix':None,'prehold':packet.get('prehold'),'action':action}
                valid=bool(action.get('command_valid') and action.get('execution_eligible'))
                if valid:
                    _,entry=forward_entry(prefix_owner,packet,gamma,budget,'CAL')
                    prefix_owner.flush_raw_evidence()
                save_numeric(path/(name+'_CAUSAL_PREFIX.json'),{'entry':entry,'offline_CAL':True,'future_label_consumed':False})
                event(out,'CAL_PREFIX_IMMUTABLE',context_id=c['context_id'],branch=name,
                    sha256=sha(path/(name+'_CAUSAL_PREFIX.json')),future_not_started=True)
                if valid:
                    budget.cal_attempted=getattr(budget,'cal_attempted',0)+1
                    branch=sim.propagate(owners[name],c,packet,budget,purpose='CAL_'+name,action=action,require_sent=False)
                else:branch=not_run(gamma,'CURRENT_PACKET_UNAVAILABLE')
                result=save_branch(out,path/name,branch,c,packet)
                row=record(p,entry,result['label'],gamma,'CAL')
                row.update(source_split='STEP44_FRESH_CAL',source_method='STEP44_OFFLINE_MATCHED_FEEDBACK',offline_CAL=True)
                calrows.append(row)
                save_numeric(path/(name+'_CAL_ROW.json'),row)
                hashes={relative(f,out):sha(f) for f in (path/'SOURCE_IDENTITY.json',path/'SOURCE_IDENTITY.npz',path/'PACKET.json',path/'PACKET.npz',path/(name+'_CAUSAL_PREFIX.json'),path/(name+'_CAUSAL_PREFIX.npz'),path/name/'RESULT.json')}
                domain_rows.append(domain_record(p,row,entry,packet,result,mapping,hashes))
                event(out,'DONE',kind='CAL_BRANCH',context_id=c['context_id'],branch=name,status=result['status'])
                budget.persist(phase='CAL_BRANCH_SAVED',CAL_positions=len(calrows))
            budget.persist(phase='CAL_CONTEXT_DONE',CAL_contexts_processed=p['ordinal']+1)
            print({'phase':'CAL_CONTEXT_DONE','completed':p['ordinal']+1,'planned':64,'budget':budget.snapshot()},flush=True)
            del owners,packet,branch;gc.collect()
        del prefix_owner
        augmented,new_table,cal_freeze=freeze_cal(out,bundle,calrows,old_table,domain_rows,getattr(budget,'cal_attempted',0))
        bundle_by_method={METHODS[0]:bundle,METHODS[1]:augmented}
        domains={METHODS[0]:domain,METHODS[1]:ResidentDomain(new_table,sha(out/'AUGMENTED_TERMINAL_CAL_DOMAIN.json'))}
        frozen_pair={m:bundle_identity(v) for m,v in bundle_by_method.items()}
        budget.event('CAL_FROZEN_BEFORE_TEST',sha256=sha(out/'STEP44_CAL_FREEZE.json'),TEST_consumed=False)
        budget.persist(phase='CAL_FROZEN')
        contexts = reference_inputs(out,'TEST',model,manifest,budget)
        by_context = {c['context_id']:c for c in contexts}
        severe_ordinal = {p['context_id']:i for i,p in enumerate(severe_plans())}
        for p in plans('TEST'):
            c = by_context[p['context_id']]
            directory = out / 'TEST' / c['context_id']
            save_numeric(directory / 'SOURCE_IDENTITY.json', {'plan': p, 'context': c})
            order = (METHODS if severe_ordinal[p['context_id']] % 2 == 0 else METHODS[::-1]) if p['governor_planned'] else ()
            live_owners, packets = {}, {}
            live = None
            for method in order:
                event(out, 'START', kind='GOVERNOR', context_id=c['context_id'], method=method)
                if c.get('eligible'):
                    live, startup = make_owner(model, budget, c, manifest, method, domains[method])
                    write(directory / method / 'STARTUP.json', startup)
                    decision = live.governor(c, bundle_by_method[method], .006, budget)
                    live.flush_raw_evidence()
                else:
                    live = None
                    decision = {'context_id':c['context_id'], 'selected_command_sent':False,
                        'status':'SOURCE_INELIGIBLE', 'actions':{}, 'command_ready_ms':0.}
                live_owners[method], packets[method] = live, decision
                save_numeric(directory / method / 'DECISION.json', decision)
                event(out, 'DECISION_IMMUTABLE', context_id=c['context_id'], method=method,
                    decision_sha256=sha(directory / method / 'DECISION.json'), actual_and_direct_not_started=True,
                    selected_command_sent=decision.get('selected_command_sent'), selected_gamma=decision.get('selected_gamma'))
            if p['governor_planned']:
                event(out, 'BOTH_DECISIONS_IMMUTABLE', context_id=c['context_id'], order=list(order),
                    owner_identities={m:live_owners[m].solver_owner_identity() if live_owners[m] else None for m in METHODS})
            else:
                event(out,'CONTROL_AFTER_BOTH_SEVERE_DECISIONS',snapshot_id=p['snapshot_id'],context_id=p['context_id'],
                    healthy_shared_control_id=p['snapshot_id']+'_HEALTHY:B',online_screen_called=False)
            for method in order:
                decision, live = packets[method], live_owners[method]
                event(out, 'START', kind='RECOGNIZED_ACTUAL', method=method, context_id=c['context_id'])
                branch = (sim.propagate(live, c, decision, budget, purpose=method+'_ACTUAL', require_sent=True)
                    if decision.get('selected_command_sent') else not_run(decision.get('selected_gamma'), 'ABSTAIN_OR_LATE_UNAPPLIED'))
                r = save_branch(out, directory / method / 'ACTUAL', branch, c, decision, True)
                event(out, 'RETURN', kind='RECOGNIZED_ACTUAL', context_id=c['context_id'], method=method, status=r['status'])
                budget.persist(phase='RECOGNIZED_SAVED', context_ordinal=p['ordinal'], method=method)
            del live_owners, packets, live
            owners, packet = packet_once(out, directory / 'DIRECT', c, model, budget, manifest)
            for name, gamma in BRANCHES if p['governor_planned'] else (('B',0.),):
                event(out, 'START', kind='TEST_DIRECT', context_id=c['context_id'], branch=name)
                action = (packet['actions'].get(str(gamma)) or {}).get('action') or {}
                branch = sim.propagate(owners[name], c, packet, budget, purpose=name, action=action, require_sent=False) \
                    if action.get('command_valid') and action.get('execution_eligible') else not_run(gamma, 'CURRENT_PACKET_UNAVAILABLE')
                r = save_branch(out, directory / 'DIRECT' / name, branch, c, packet)
                event(out, 'RETURN', kind='TEST_DIRECT', context_id=c['context_id'], branch=name, status=r['status'])
                budget.persist(phase='TEST_DIRECT_SAVED', context_ordinal=p['ordinal'], branch=name)
            budget.persist(phase='TEST_CONTEXT_DONE', contexts_processed=p['ordinal'] + 1)
            print({'phase': 'TEST_CONTEXT_DONE', 'completed': p['ordinal'] + 1, 'planned': 120,
                   'budget': budget.snapshot()}, flush=True)
            del owners
            gc.collect()
    except SprintLimit as exc:
        status = 'INCOMPLETE_BUDGET'
        write(out / 'INTERRUPTION.json', {'error': str(exc), 'budget': budget.snapshot()})
    except BaseException as exc:
        status = 'STOPPED_IMPLEMENTATION_OR_RESOURCE'
        write(out / 'INTERRUPTION.json', {'type': type(exc).__name__, 'error': str(exc),
            'traceback': traceback.format_exc(), 'budget': budget.snapshot()})
        raise
    finally:
        end = bundle_identity(bundle) if bundle is not None else None
        pair_unchanged=all(bundle_identity(v)==frozen_pair[m] for m,v in bundle_by_method.items()) if 'frozen_pair' in locals() else None
        unchanged = end == screen.get('identity')
        file_hashes = {path: sha(Path(path)) for path in screen.get('files', {})}
        unchanged = unchanged and file_hashes == screen.get('files', {})
        write(out / 'SCREEN_IDENTITY_END.json', {'identity': end, 'files': file_hashes,
            'full_model_CAL_TRAIN_threshold_identity_unchanged': unchanged, 'terminal_domain_unchanged': sha(table_path)==table_freeze['sha256'], 'acceptance_algorithm_unchanged':{name:sha(OUTPUT_ROOT_D/'cavr_wbc/control'/name) for name in frozen_sources}==frozen_sources, 'acceptance_source_sha256':frozen_sources,
            'new_fits': 0, 'new_CAL_planned': 128,'pair_bundle_identity_unchanged':pair_unchanged})
        unchanged = unchanged and {name:sha(OUTPUT_ROOT_D/'cavr_wbc/control'/name) for name in frozen_sources}==frozen_sources
        if not unchanged or pair_unchanged is False:
            status = 'INVALID_SCREEN_IDENTITY'
        budget.event('NUMERICAL_FINISHED', status=status, **budget.snapshot())
        budget.close()
        write(out / 'RUN_FINISHED.json', {'status': status, 'run_id': run_id, 'budget': budget.snapshot(),
              'finish_utc': datetime.now(timezone.utc).isoformat()})
        print({'status': status, 'budget': budget.snapshot()}, flush=True)


if __name__ == '__main__':
    run()
