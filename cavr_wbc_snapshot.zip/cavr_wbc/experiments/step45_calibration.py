"""Saved-data canonical gamma-zero repair; no integration, solver or fitting."""
from copy import deepcopy
import shutil
import numpy as np
from cavr_wbc.control import step39_margin as margin
from cavr_wbc.control.step41_terminal_domain import ResidentDomain
from cavr_wbc.experiments.step44_calibration import CAL_ARRAYS, clean
from cavr_wbc.experiments.step44_identity import fingerprint, bundle_identity
from cavr_wbc.experiments.step44_inputs import plans as saved_plans
from cavr_wbc.experiments.step45_io import *

def merge_gamma0(augmented, rows):
    """Only the canonical gamma-zero group; global planned IDs stay unchanged."""
    key=margin.group_key(0., 'thigh')
    rows=list(rows)
    if len({r['id'] for r in rows})!=len(rows): raise ValueError('duplicate saved B ID')
    if any(r['gamma']!=0. or r['role']!='thigh' or r['split']!='CAL' for r in rows):
        raise ValueError('saved B row gamma/role/split')
    old=augmented['groups'][key]
    if set(old['cal_ids']) & {r['id'] for r in rows}: raise ValueError('CAL prefix overlap')
    if not {r['id'] for r in rows}.issubset(augmented['CAL_ids_all']):
        raise ValueError('B IDs must already be in STEP44 global planned list')
    temporary=margin.build_calibration(clean(augmented), rows)
    new=temporary['groups'][key]
    bundle=clean(augmented);group=bundle['groups'][key];codes={}
    for name in CAL_ARRAYS: group[name]=np.concatenate((group[name],new[name]),axis=0)
    for identity,code in (('cal_snapshot_ids','cal_snapshot_index'),('cal_episode_ids','cal_episode_index')):
        values=sorted(set(str(i) for i in group[identity]));mapping={v:i for i,v in enumerate(values)}
        group[code]=np.asarray([mapping[str(v)] for v in group[identity]],dtype=np.int64)
        codes[code]=mapping
    complete=group['cal_complete'];known=group['cal_physical_known'];physical=group['cal_physical_pass']
    snaps=set(group['cal_snapshot_ids'][complete]);eps=set(group['cal_episode_ids'][complete])
    z=group['cal_z'];train=group['train_z']
    nearest=np.sqrt(np.min(np.sum((z[:,None,:]-train[None,:,:])**2,axis=2),axis=1)) if len(z) and len(train) else np.empty(0)
    group.update(CAL_planned=group['CAL_planned']+new['CAL_planned'],CAL_finite=len(z),
        CAL_complete=int(complete.sum()),CAL_complete_distinct_snapshots=len(snaps),CAL_complete_episodes=len(eps),
        CAL_complete_physical_failures=int(np.sum(complete & ~physical)),CAL_physical_unknown=int(np.sum(~known)),
        CAL_missing_feature_ids=group.get('CAL_missing_feature_ids',[])+new['CAL_missing_feature_ids'],
        CAL_incomplete_finite_ids=group['cal_ids'][~complete].tolist(),
        local_calibrated=bool(bundle['trained'] and len(snaps)>=4 and len(eps)>=2),
        cal_max_nearest_distance=float(nearest.max()) if len(nearest) else 0.,
        distance_threshold=max(3.*float(nearest.max()) if len(nearest) else 0.,margin.DISTANCE_FLOOR))
    bundle.update(calibration_id='FULL_CAL_CONSENSUS_STEP45_V1', CAL_frozen=True, TEST_consumed=False)
    bundle=margin.prepare_resident(bundle)
    return bundle,codes

def source_assets():
    freeze=read(SOURCE44/'STEP44_CAL_FREEZE.json');bundles={};files={}
    for method,a in freeze['assets'].items():
        for ext in ('json','npz'):
            path=SOURCE44/'models'/Path(a[ext]).name
            if sha(path)!=a[ext+'_sha256']: raise ValueError('STEP44 model byte identity '+method+ext)
            files[str(path)]=a[ext+'_sha256']
        bundles[method]=margin.load_bundle(SOURCE44/'models'/Path(a['npz']).name)
        if bundle_identity(bundles[method])!=freeze['identities'][method]: raise ValueError('saved model identity')
    for d in freeze['domains'].values():
        path=SOURCE44/d['path']
        if sha(path)!=d['sha256']: raise ValueError('STEP44 domain byte identity')
        files[str(path)]=d['sha256']
    return bundles,freeze,files

def repair_saved_gamma0(out=output()):
    if (out/'STEP45_METHOD_FREEZE.json').exists():raise FileExistsError('repair saved rows once')
    bundles,source,files=source_assets()
    rows=[];mapping=[]
    for p in saved_plans('CAL'):
        path=SOURCE44/'CAL'/p['context_id']/'B_CAL_ROW.json'
        row=load_numeric(path)  # Each of the 64 JSON/NPZ row pairs is consumed once.
        if row['id']!='CAL:'+p['context_id']+':0.0':raise ValueError('saved CAL plan order/ID')
        if margin.finite_input(row) is None or margin.physical_target(row) is None:raise ValueError('saved B complete feature/label')
        rows.append(row)
        mapping.append(dict(ordinal=p['ordinal'],id=row['id'],source_json=str(path),
            json_sha256=sha(path),npz_sha256=sha(path.with_suffix('.npz')),
            physical_pass=margin.physical_target(row)==1,episode=p['episode'],snapshot=p['snapshot_id']))
    old=bundles['OLD_CAL_CONSENSUS'];aug=bundles['AUGMENTED_CAL_CONSENSUS']
    full,codes=merge_gamma0(aug,rows);key=margin.group_key(0.,'thigh');g=full['groups'][key]
    unchanged={k:fingerprint(v)==fingerprint(full['groups'][k]) for k,v in aug['groups'].items() if k!=key}
    prefix={k:fingerprint(aug['groups'][key][k])==fingerprint(g[k][:16]) for k in CAL_ARRAYS}
    train={k:fingerprint(v)==fingerprint(g[k]) for k,v in aug['groups'][key].items() if k.startswith('train_')}
    global_ids_unchanged=aug['CAL_ids_all']==full['CAL_ids_all'] and len(set(full['CAL_ids_all']))==len(full['CAL_ids_all'])
    checks=dict(canonical_key=key,reused_B_rows=64,new_B_pass=sum(r['physical_pass'] for r in mapping),
        new_B_fail=sum(not r['physical_pass'] for r in mapping),gamma0_finite=g['CAL_finite'],
        gamma0_complete=g['CAL_complete'],gamma0_fail=g['CAL_complete_physical_failures'],gamma0_unknown=g['CAL_physical_unknown'],
        unchanged_groups=unchanged,old16_prefix=prefix,TRAIN_unchanged=train,global_CAL_ids_unchanged=global_ids_unchanged,
        predictor_unchanged=margin.identity(full)==margin.identity(aug),thresholds_unchanged=bundle_identity(full)['thresholds']==bundle_identity(aug)['thresholds'],
        resident_group_position=full['_resident']['group_position'][key],gamma05_finite=full['groups'][margin.group_key(.5,'thigh')]['CAL_finite'])
    if (g['CAL_finite'],g['CAL_complete'],g['CAL_complete_physical_failures'],g['CAL_physical_unknown'])!=(80,80,19,0):raise ValueError('required gamma0 counts')
    if not (all(unchanged.values()) and all(prefix.values()) and all(train.values()) and global_ids_unchanged and checks['predictor_unchanged']):raise ValueError('saved group/prefix changed')
    write(out/'SAVED_CAL_REPAIR_MAPPING.json',dict(rows=mapping,codes=codes,checks=checks,saved_rows_read_once=64,new_simulations=0,new_fits=0))
    assets={'OLD_CAL_CONSENSUS':source['assets']['OLD_CAL_CONSENSUS'],
            'FULL_CAL_CONSENSUS':margin.save_bundle(full,out/'models','FULL_CAL_CONSENSUS')}
    # Relocate original old model paths to the byte-exact local materialization.
    assets['OLD_CAL_CONSENSUS']=dict(assets['OLD_CAL_CONSENSUS'])
    for ext in ('json','npz'):assets['OLD_CAL_CONSENSUS'][ext]=str(SOURCE44/'models'/Path(assets['OLD_CAL_CONSENSUS'][ext]).name)
    domains={}
    for method,source_method in (('OLD_CAL_CONSENSUS','OLD_CAL_CONSENSUS'),('FULL_CAL_CONSENSUS','AUGMENTED_CAL_CONSENSUS')):
        d=source['domains'][source_method];src=SOURCE44/d['path'];target=out/d['path']
        if target.exists():raise FileExistsError('frozen domain already materialized')
        shutil.copyfile(src,target)
        domains[method]=dict(path=d['path'],sha256=sha(target))
        if domains[method]['sha256']!=d['sha256']:raise ValueError('domain changed')
    pair={'OLD_CAL_CONSENSUS':old,'FULL_CAL_CONSENSUS':full}
    freeze=dict(status='FROZEN',version='FULL_CAL_CONSENSUS_STEP45_V1',assets=assets,domains=domains,
        identities={m:bundle_identity(b) for m,b in pair.items()},source_files=files,
        source_freeze_sha256=sha(SOURCE44/'STEP44_CAL_FREEZE.json'),recorded=64,
        TEST_generated=False,TEST_consumed=False,new_CAL=0,new_TRAIN=0,new_fits=0,checks=checks)
    write(out/'STEP45_METHOD_FREEZE.json',freeze)
    return freeze

def load_pair(out=output()):
    freeze=read(out/'STEP45_METHOD_FREEZE.json');bundles={};domains={}
    for m,a in freeze['assets'].items():
        for ext in ('json','npz'):
            if sha(a[ext])!=a[ext+'_sha256']:raise ValueError('STEP45 frozen asset hash')
        bundles[m]=margin.load_bundle(a['npz'])
        if bundle_identity(bundles[m])!=freeze['identities'][m]:raise ValueError('STEP45 bundle identity')
        d=freeze['domains'][m];p=out/d['path']
        if sha(p)!=d['sha256']:raise ValueError('STEP45 domain hash')
        domains[m]=ResidentDomain(read(p),d['sha256'])
    return bundles,domains,freeze
