"""One saved-only current STEP45 readback; never optimize, integrate, fit or rerun."""
from collections import Counter
from datetime import datetime,timezone
import json
import numpy as np
from cavr_wbc.experiments.step45_io import *
from cavr_wbc.experiments.step45_inputs import plans,METHODS,severe_plans
from cavr_wbc.experiments.step45_storage import load_branch,contact_statistics
from cavr_wbc.experiments.step44_identity import fingerprint
from cavr_wbc.experiments.step39_delivery import flatten,counts,safe,physical,physical_terminal,outcome,csv_save
def collect(out):
    rows,records,decisions,queries=[],{},[],[]
    contextpath=out/'TEST_CONTEXTS.json'
    contexts={c['context_id']:c for c in load_numeric(contextpath)} if contextpath.exists() else {}
    calpath=out/'CAL_CONTEXTS.json'
    if calpath.exists():contexts.update({c['context_id']:c for c in load_numeric(calpath)})
    for p in plans('TEST'):
        folder=out/'TEST'/p['context_id']
        for name in (*p['branch_order'],*([m+'_ACTUAL' for m in METHODS] if p['governor_planned'] else [])):
            path=folder/(name.removesuffix('_ACTUAL')+'/ACTUAL' if name.endswith('_ACTUAL') else 'DIRECT/'+name)/'RESULT.json'
            rec=read(path,{})
            row=flatten(p,name,rec,path,out)
            row.update(direction=p['direction'],displacement_m=p['displacement_m'],contact_statistics=rec.get('contact_statistics'),application_identity_pass=rec.get('application_identity_pass'))
            rows.append(row);records[row['id']]=rec
        for method in METHODS if p['governor_planned'] else ():
            path=folder/method/'DECISION.json'
            packet=load_numeric(path) if path.exists() else {}
            query=[]
            for gamma in (.5,0.):
                entry=packet.get('actions',{}).get(str(gamma)) or {}
                old=entry.get('decision') or {}; numeric=old.get('numeric') or {}
                observed=entry.get('features28') is not None
                support=entry.get('terminal_domain')
                qr=dict(context_id=p['context_id'],snapshot_id=p['snapshot_id'],episode=p['episode'],
                    method=method,gamma=gamma,observed_causal_query=observed,
                    evaluation_status=entry.get('evaluation_status','NOT_RUN'),
                    accepted=old.get('accepted'),legacy_same_candidate_accepted=entry.get('legacy_accepted_same_candidate',old.get('accepted')),
                    U_D_m=numeric.get('U_D'),U_T=numeric.get('U_T'),terminal_domain=support,
                    domain_counted_in_online_window=support is not None,
                    physical_consensus=entry.get('cal_physical_consensus'),
                    consensus_gate_applied=entry.get('consensus_gate_applied',False),
                    consensus_counted_in_online_window=entry.get('consensus_counted_in_online_window',False),
                    step41_same_candidate_accepted=entry.get('step41_same_candidate_accepted'),
                    rejection_reasons=entry.get('rejection_reasons',[]),
                    original_numeric=numeric,
                    complete_at_ms=entry.get('complete_at_ms'),
                    gates={k:numeric.get(k) for k in ('finite_input','pose_gate','support_gate','distance_gate','calibration_gate','physical_risk_gate') if k in numeric})
                queries.append(qr);query.append(qr)
            R=next(r for r in rows if r['id']==p['context_id']+':'+method+'_ACTUAL')
            chosen=next((q for q in query if q['gamma']==packet.get('selected_gamma')),None)
            decisions.append(dict(context_id=p['context_id'],snapshot_id=p['snapshot_id'],episode=p['episode'],
                method=method,condition=p['health_kind'],fault_leg=p['fault_leg'],direction=p['direction'],
                tick=p['tick'],displacement_m=p['displacement_m'],eligible=bool(contexts.get(p['context_id'],{}).get('eligible')),
                decision_exists=path.exists(),decision_path=relative(path,out),decision_sha256=sha(path) if path.exists() else None,
                status=packet.get('status','NOT_RUN'),command_ready_ms=packet.get('command_ready_ms'),
                phase_latency_ms=packet.get('phase_latency_ms',{}),absolute_deadline=packet.get('absolute_deadline'),prepare_begin=packet.get('prepare_begin'),
                selected_gamma=packet.get('selected_gamma'),selected_command_sent=bool(packet.get('selected_command_sent')),
                overall_deadline_failure=bool(packet.get('overall_deadline_failure')),complete_actual=R['complete_501'],
                safe_actual_6mm=safe(R),physical_pass=R['physical_pass'],terminal_pass=R['terminal_pass'],
                D_m=R['D_m'],terminal_Y=R['terminal_Y'],actual_outcome=outcome(R),
                actual_partial=bool(R['observed'] and not R['complete_501']),timing_qualified_actual=R['timing_qualified'],
                max_feedback_latency_ms=R['max_feedback_latency_ms'],selected_query=chosen,queries=query))
    return rows,records,contexts,decisions,queries


def readback(out, rows, records, contexts, decisions):
    from cavr_wbc.control.step34_margin import labels
    from cavr_wbc.experiments.step29_sim import _json_safe
    issues, loaded, grids, capacity = [], 0, 0, []
    tasks=[];latencies=[]
    complete_run=read(out/'RUN_FINISHED.json')['status']=='COMPLETED'
    if len(rows)!=264 or (complete_run and any(not row['result_exists'] for row in rows)):
        issues.append('all 264 planned result slots must have a status record')
    if len(decisions)!=96 or (complete_run and any(not d['decision_exists'] for d in decisions)):
        issues.append('all 96 planned decisions must be saved')
    source_identities = {}
    for c in contexts.values():
        if 'state' not in c:
            continue
        digest = fingerprint({key: c.get(key) for key in ('state', 'current_reference', 'source_external_reference',
            'nominal_q_init', 'nominal_d_m', 'nominal_b_used', 'backup_anchor_q_init', 'previous_command_identity')})
        previous = source_identities.setdefault(c['snapshot_id'], digest)
        if previous != digest:
            issues.append(c['context_id'] + ':same-state intervention source mismatch')
        health = np.ones(len(c['health_vector']))
        if c['faulted_actuator_index'] is not None:
            health[c['faulted_actuator_index']] = c['faulted_health']
        if not np.array_equal(health, c['health_vector']):
            issues.append(c['context_id'] + ':health mapping')
    direct_preparation_seen=set()
    for row in rows:
        rec = records[row['id']]
        if not row['branch'].endswith('_ACTUAL') and row['context_id'] not in direct_preparation_seen:
            latencies.append(dict(context_id=row['context_id'],snapshot_id=row['snapshot_id'],episode=row['episode'],
                split='TEST',method='DIRECT_PACKET',window='PREPARATION',slot=1,
                latency_ms=rec.get('first_packet_ready_ms'),deadline_ms=20,observed=row['result_exists'],applied=False,
                offline_counterfactual=True,shared_packet_context=row['context_id'],
                complete_trajectory=None,safe_trajectory=None))
            direct_preparation_seen.add(row['context_id'])
        if not row['observed']:
            continue
        directory = (out / row['result_path']).parent
        if sha(directory / 'actual.npz') != rec['artifact']['sha256']:
            issues.append(row['id'] + ':fact hash')
        for ext, key in (('json', 'json_sha256'), ('npz', 'npz_sha256')):
            if sha(directory / ('controls.' + ext)) != rec['controls_numeric'][key]:
                issues.append(row['id'] + ':control hash')
        branch = load_branch(directory)
        context = contexts[row['context_id']]
        task=task_response(branch,context)
        row['task_response']=task['summary'];tasks.append(dict(id=row['id'],**task))
        lab = labels(branch, _json_safe(context))
        for key in ('complete', 'full_501_grid', 'original_physical', 'original_terminal', 'observed_original_physical_failure'):
            if lab.get(key) != rec['label'].get(key):
                issues.append(row['id'] + ':label ' + key)
        for key in ('D_m', 'Y'):
            a, b = lab.get(key), rec['label'].get(key)
            if (a is None) != (b is None) or (a is not None and not np.allclose(a, b, rtol=0, atol=1e-12, equal_nan=True)):
                issues.append(row['id'] + ':numeric label ' + key)
        if contact_statistics(branch) != rec['contact_statistics']:
            issues.append(row['id'] + ':contact descriptive facts')
        if not np.array_equal(branch['health_vector'], context['health_vector']):
            issues.append(row['id'] + ':plant/control health')
        if row['complete_501']:
            grids += 1
            if branch['counts']['physical_steps'] != 500 or len(branch['physics_trajectory']) + 1 != 501 or len(branch['checkpoints']) != 21:
                issues.append(row['id'] + ':500/501/21 time grid')
        if row['branch'].endswith('_ACTUAL') and not (rec.get('application_identity_pass') and rec.get('application_state_match') and rec.get('first_tau_matches_packet')):
            issues.append(row['id']+':own packet/application identity')
        ix = context.get('faulted_actuator_index')
        for r in branch['controls']:
            interface = r.get('capacity_interface') or {}
            tau, cap = r.get('tau_applied'), interface.get('effective_capacity_nm')
            raw, sent = interface.get('tau_raw'), interface.get('tau_sent')
            applied = tau is not None
            record = {'id': row['id'], 'context_id': row['context_id'], 'branch': row['branch'],
                'snapshot_id': row['snapshot_id'], 'episode': row['episode'], 'condition': row['condition'],
                'slot': r['slot'], 'time_s': r['slot'] * .02,
                'stage': 'PREHOLD' if r['slot'] == 0 else 'FIRST_ACTION' if r['slot'] == 1 else 'FEEDBACK',
                'actual_applied': applied, 'fault_name': context.get('faulted_actuator_name'),
                'actual_fault_tau_nm': None if ix is None or not applied else float(tau[ix]),
                'effective_fault_capacity_nm': None if ix is None or cap is None else float(cap[ix]),
                'actual_tau_capacity_ratio': None if ix is None or not applied or cap is None else abs(float(tau[ix])) / float(cap[ix]),
                'candidate_fault_tau_raw_nm': None if ix is None or raw is None else float(raw[ix]),
                'candidate_fault_tau_sent_nm': None if ix is None or sent is None else float(sent[ix]),
                'fault_clipped': None if ix is None or raw is None or sent is None else bool(raw[ix] != sent[ix]),
                'antiwindup_frozen': bool(r.get('integral_record') and not r['integral_record'].get('updated', False)),
                'latency_ms': r.get('latency_ms')}
            record['actual_99percent'] = bool(record['actual_tau_capacity_ratio'] is not None and record['actual_tau_capacity_ratio'] >= .99)
            capacity.append(record)
            if r.get('slot',0)>1:
                latencies.append(dict(context_id=row['context_id'],snapshot_id=row['snapshot_id'],episode=row['episode'],split=row['split'],method=row['branch'].removesuffix('_ACTUAL') if row['branch'].endswith('_ACTUAL') else 'DIRECT_'+row['branch'],window='FEEDBACK',slot=r['slot'],latency_ms=r.get('latency_ms'),deadline_ms=20,observed=True,applied=applied,complete_trajectory=row['complete_501'],safe_trajectory=safe(row),timing=r.get('timing',{}),raw_solver_evidence=r.get('raw_solver_evidence')))
        loaded += 1
    events = [json.loads(line) for line in (out / 'STEP45_LEDGER.jsonl').read_text(encoding='utf-8').splitlines()]
    starts = [e for e in events if e['event'] == 'QP_START']
    returns = [e for e in events if e['event'] == 'QP_RETURN']
    raw = [e for e in events if e['event'] == 'RAW_QP_SAVED']
    ix = lambda a: sorted(e['global_qp_index'] for e in a)
    if ix(returns) != ix(raw) or not set(ix(returns)).issubset(ix(starts)) or ix(starts) != list(range(1, len(starts) + 1)) or (complete_run and ix(starts) != ix(returns)):
        issues.append('QP START/RETURN/raw identity')
    assembly=[]
    for e in raw:
        path = out / e['path']
        if sha(path) != e['json_sha256'] or sha(path.with_suffix('.npz')) != e['npz_sha256']:
            issues.append(e['path'] + ':raw hash')
        record=read(path).get('record',{})
        result=record.get('raw_result',{})
        assembly.append(dict(global_qp_index=e['global_qp_index'],path=e['path'],kind=record.get('kind'),
            raw_status=result.get('status'),optimizer_converged=result.get('optimizer_converged'),
            assembly_ms=result.get('kernel_assembly_ms'),thread_cpu_ms=result.get('kernel_assembly_thread_cpu_ms'),
            subblocks=result.get('assembly_subblocks',{}),nested_not_additive=True,
            other_timing={k:v for k,v in result.items() if k.endswith('_ms') or k.endswith('_time_s')}))
    reservations = [e for e in events if e['event'] == 'PREFIX_NATIVE_START']
    completed = [e for e in events if e['event'] == 'PREFIX_NATIVE_RETURN']
    if complete_run and sorted(e['reservation_id'] for e in reservations) != sorted(e['reservation_id'] for e in completed):
        issues.append('prediction reservations/returns')
    budget = read(out / 'RUN_FINISHED.json')['budget']
    if (budget['total_QP_calls'] != len(starts) or budget['QP_returns'] != len(returns)
            or budget['multioutput_estimator_fits'] or budget['physical_risk_head_fits']
            or budget['new_CAL_branches'] != 0 or budget['total_QP_calls'] > 25000 or budget['total_physics_steps'] > 250000):
        issues.append('cumulative counts/budgets/zero fit')
    checkpoint = read(out / 'SCREEN_IDENTITY_END.json')
    if not checkpoint['acceptance_algorithm_unchanged']:
        issues.append('acceptance algorithm source identity')
    if not checkpoint['full_model_CAL_TRAIN_threshold_identity_unchanged']:
        issues.append('frozen screen groups/predictor/threshold identity')
    freeze = read(out / 'RUNTIME_FREEZE.json')
    for name, digest in {**freeze['runtime_sha256'], **freeze['model_checkout_bytes']}.items():
        if sha(OUTPUT_ROOT_D / name) != digest:
            issues.append(name + ':frozen checkout byte hash')
    manifest = read(out / 'PROTOCOL_AND_MANIFEST.json')
    if sha(NATIVE_DLL) != manifest['native_dll_sha256']:
        issues.append('native DLL hash')
    attempts = [json.loads(line) for line in (out / 'ATTEMPT_LEDGER.jsonl').read_text().splitlines()]
    for p in plans('TEST'):
        cid=p['context_id']
        for method in METHODS if p['governor_planned'] else ():
            d=next(row for row in decisions if row['context_id']==cid and row['method']==method)
            ev=next((e for e in attempts if e['event']=='DECISION_IMMUTABLE' and e['context_id']==cid and e.get('method')==method),None)
            if d['decision_exists'] and (ev is None or ev['decision_sha256']!=d['decision_sha256']):
                issues.append(cid+':'+method+':immutable decision')
        if not p['governor_planned']:
            positions=[i for i,e in enumerate(attempts) if e.get('context_id')==cid and e.get('kind')=='TEST_DIRECT']
            peers=[i for i,e in enumerate(attempts) if e['event']=='BOTH_DECISIONS_IMMUTABLE' and e.get('context_id') in (p['snapshot_id']+'_FR_THIGH15',p['snapshot_id']+'_RR_THIGH15')]
            if positions and (len(peers)!=2 or max(peers)>=min(positions)):issues.append(cid+':control before both severe decisions')
            continue
        both=next((e for e in attempts if e['event']=='BOTH_DECISIONS_IMMUTABLE' and e['context_id']==cid),None)
        future=[i for i,e in enumerate(attempts) if e.get('context_id')==cid and e.get('kind') in ('RECOGNIZED_ACTUAL','TEST_DIRECT')]
        if both:
            expected=list(METHODS if next(i for i,x in enumerate(severe_plans()) if x['context_id']==cid)%2==0 else METHODS[::-1])
            if both['order']!=expected or (future and attempts.index(both)>=min(future)):
                issues.append(cid+':paired decision order')
            identities=both['owner_identities']
            if identities[METHODS[0]] is not None and identities[METHODS[0]]==identities[METHODS[1]]:
                issues.append(cid+':same resident owner across methods')
        elif future:
            issues.append(cid+':future before both decisions')
    if not checkpoint['terminal_domain_unchanged'] or checkpoint.get('pair_bundle_identity_unchanged') is False:
        issues.append('terminal domain resident table hash')
    # Current evidence uses frozen bundle arrays, never historical trajectory banks.
    from cavr_wbc.experiments.step45_calibration import load_pair
    from cavr_wbc.control.step42_physical_consensus import check_consensus
    bundles,domains,calfreeze=load_pair(out)
    if calfreeze['TEST_generated'] or calfreeze['TEST_consumed'] or calfreeze['recorded']!=64 or calfreeze['new_fits'] or calfreeze['new_TRAIN'] or calfreeze['new_CAL']:
        issues.append('saved CAL/TEST segregation')
    checks=calfreeze['checks']
    if (checks['gamma0_finite'],checks['gamma0_complete'],checks['gamma0_fail'],checks['gamma0_unknown'])!=(80,80,19,0):
        issues.append('gamma0 repair counts')
    if not all(checks['unchanged_groups'].values()) or not all(checks['old16_prefix'].values()) or not checks['global_CAL_ids_unchanged']:
        issues.append('CAL prefix/group identities')
    for method,d in calfreeze['domains'].items():
        if sha(out/d['path'])!=d['sha256']:issues.append(method+':domain bytes')
    frozen_event=next((e for e in events if e['event']=='METHOD_AND_INPUT_FROZEN_BEFORE_TEST'),None)
    test_ref=next((e for e in attempts if e.get('kind')=='REFERENCE'),None)
    if frozen_event is None or frozen_event['sha256']!=sha(out/'STEP45_METHOD_FREEZE.json') or (test_ref and frozen_event['timestamp_utc']>=test_ref['timestamp_utc']):
        issues.append('TEST reference before method freeze')
    for d in decisions:
        for q in d['queries']:
            saved=q.get('physical_consensus')
            if saved is None:
                continue
            expected=check_consensus(bundles[d['method']],q['gamma'],'thigh',q['original_numeric'])
            if fingerprint(encode(saved))!=fingerprint(encode(expected)):
                issues.append(q['context_id']+':'+d['method']+':CAL neighbor evidence')
            idx=q['original_numeric'].get('local_cal_indices')
            if expected['local_cal_indices'] is not None and not np.array_equal(idx,expected['local_cal_indices']):
                issues.append(q['context_id']+':original four indices altered')
            if q['accepted'] and not (q.get('step41_same_candidate_accepted') and saved['accepted']):
                issues.append(q['context_id']+':accepted without DOMAIN and consensus')
        if d.get('prepare_begin') is not None and abs(d['absolute_deadline']-d['prepare_begin']-.020)>1e-10:
            issues.append(d['context_id']+':deadline reset')
    for d in decisions:
        latencies.append(dict(context_id=d['context_id'],snapshot_id=d['snapshot_id'],episode=d['episode'],split='TEST',method=d['method'],window='PREPARATION',slot=1,latency_ms=d['command_ready_ms'],deadline_ms=20,observed=d['decision_exists'],applied=d['selected_command_sent'],complete_trajectory=d['complete_actual'],safe_trajectory=d['safe_actual_6mm'],phase_latency_ms=d['phase_latency_ms']))
    write(out/'LATENCY_ALL_WINDOWS.json',latencies)
    csv_save(out/'LATENCY_ALL_WINDOWS.csv',encode(latencies))
    write(out/'TASK_RESPONSE_ALL.json',tasks)
    write(out/'ASSEMBLY_QP_TIMING.json',assembly)
    write(out / 'CAPACITY_EVENTS_FULL.json', capacity)
    csv_save(out / 'CAPACITY_EVENTS_FULL.csv', encode(capacity))
    result = {'status': 'VERIFIED' if not issues else 'EVIDENCE_ERROR', 'issues': issues,
        'observed_banks_read_once': loaded, 'complete_grids_verified': grids,
        'qp_starts': len(starts), 'qp_returns': len(returns), 'raw_qp_shards': len(raw),
        'unknown_qp': len(starts) - len(returns), 'source_snapshot_fingerprints': source_identities,
        'full_frozen_screen_identity_unchanged': checkpoint['full_model_CAL_TRAIN_threshold_identity_unchanged'],
        'label_tolerance': 1e-12, 'new_optimizer_calls': 0, 'new_physics_steps': 0,
        'new_fits': 0, 'scope': 'STEP45_CURRENT_RUN_ONLY', 'timestamp_utc': datetime.now(timezone.utc).isoformat()}
    write(out / 'CURRENT_RUN_READBACK.json', result)
    return result

def task_response(branch,c):
    from cavr_wbc.control.step20_task_reference import reference
    dense=([branch['initial_fact']] if branch.get('initial_fact') else [])+branch.get('physics_trajectory',[])
    valid=[f for f in dense if 'qpos' in f and 'subtree_com' in f]
    if not valid:return dict(summary={'available':False,'complete':False},series=[])
    origin=float(valid[0]['subtree_com'][0]);base0=float(valid[0]['qpos'][0]);sign=c['direction']
    p0=float(c['nominal_q_init'][0]);d=float(c['nominal_d_m'])
    series=[]
    for f in valid:
        ref=reference(p0,d,c['source_tick']*.02+f['time_s'])
        series.append(dict(time_s=f['time_s'],directed_subtree_COM_displacement_m=sign*(f['subtree_com'][0]-origin),
            directed_base_displacement_m=sign*(f['qpos'][0]-base0),base_task_error_m=f['qpos'][0]-ref['p_ref_m'],
            external_base_reference_m=ref['p_ref_m']))
    ts=np.asarray([f['time_s'] for f in series]);err=np.asarray([f['base_task_error_m'] for f in series])
    last=series[-1]
    integral=float(np.sum((np.abs(err)[1:]+np.abs(err)[:-1])*.5*np.diff(ts)))
    summary=dict(available=True,complete=bool(branch['status']=='COMPLETE' and len(valid)==501),
        observed_end_time_s=last['time_s'],terminal_directed_subtree_COM_displacement_m=last['directed_subtree_COM_displacement_m'],
        terminal_directed_base_displacement_m=last['directed_base_displacement_m'],terminal_base_task_error_m=last['base_task_error_m'],
        max_abs_base_task_error_m=float(np.max(np.abs(err))),
        observed_abs_task_error_integral_m_s=integral,
        time_mean_abs_base_task_error_m=float(np.sum((np.abs(err)[1:]+np.abs(err)[:-1])*.5*np.diff(ts))/ts[-1]) if ts[-1]>0 else None,
        observed_directed_COM_range_m=[min(v['directed_subtree_COM_displacement_m'] for v in series),max(v['directed_subtree_COM_displacement_m'] for v in series)],
        metric_scope='DESCRIPTIVE_1S_EXTERNAL_QUINTIC_BASE_TASK_REFERENCE; evaluator and anchor unchanged')
    return dict(summary=summary,series=series)


def summarize(out=output()):
    if not (out/'RUN_FINISHED.json').exists():raise RuntimeError('wait for numerical finish')
    if (out/'CURRENT_RUN_READBACK.json').exists() or (out/'STEP45_RESULT.json').exists():raise FileExistsError('one current-path readback only')
    rows,records,contexts,decisions,queries=collect(out)
    evidence=readback(out,rows,records,contexts,decisions)
    return emit_results(out,rows,decisions,queries,evidence)

def finalize_saved(out=output()):
    """Metadata repair only: completed readback, no dense-bank reload."""
    if not (out/'CURRENT_RUN_READBACK.json').exists() or (out/'STEP45_RESULT.json').exists():raise FileExistsError('saved finalization precondition')
    rows,records,contexts,decisions,queries=collect(out)
    tasks={v['id']:v['summary'] for v in read(out/'TASK_RESPONSE_ALL.json')}
    for row in rows:
        if row['id'] in tasks:row['task_response']=tasks[row['id']]
    return emit_results(out,rows,decisions,queries,read(out/'CURRENT_RUN_READBACK.json'))

def emit_results(out,rows,decisions,queries,evidence):
    from cavr_wbc.experiments.step45_mechanisms import evaluate
    done=read(out/'RUN_FINISHED.json')['status']=='COMPLETED'
    panel=bool(done and evidence['status']=='VERIFIED' and all(r['result_exists'] for r in rows) and all(d['decision_exists'] for d in decisions))
    conclusions=evaluate(rows,decisions,evidence,panel)
    result=dict(schema='STEP45_MATCHED_CAL_ONLINE_RECOVERY_RESULT_V1',run_id=out.name,
        run=read(out/'RUN_FINISHED.json'),readback=evidence,confirmation=conclusions,methods=conclusions['methods'],
        task_execution_status='COMPLETE' if panel else 'INCOMPLETE',
        CAL=counts([r for r in rows if r['split']=='CAL']),
        direct=counts([r for r in rows if r['split']=='TEST' and not r['branch'].endswith('_ACTUAL')]),
        actual_by_method={m:counts([r for r in rows if r['branch']==m+'_ACTUAL']) for m in METHODS},
        planned_positions=264,method_decisions_planned=96,method_decisions_saved=sum(d['decision_exists'] for d in decisions),
        CAL_physical_snapshots=0,TEST_physical_snapshots=24,reference_episodes=8,health_contexts=120,
        cal_freeze=read(out/'STEP45_METHOD_FREEZE.json'),numerical_launches=1,result_based_retries=0,new_fits=0,new_CAL_planned=0,
        new_acceptance_gates=0,source_acceptance_unchanged=read(out/'SCREEN_IDENTITY_END.json')['acceptance_algorithm_unchanged'])
    outputs={'ALL_PLANNED_RESULTS.json':rows,'ALL_METHOD_DECISIONS.json':decisions,'ALL_CAUSAL_QUERIES.json':queries,
        'CAL_NEIGHBOR_EVIDENCE.json':queries,'SAME_SOURCE_METHOD_PAIRS.json':conclusions['source_pairs'],
        'DIRECTION_LEG_SUPPORT.json':conclusions['direction_leg_support'],'TYPE_II_ONLY.json':conclusions['TypeII']}
    for name,data in outputs.items():write(out/name,data)
    for name,data in [('ALL_BRANCH_RESULTS.csv',rows),('DIRECT_TYPE_II_ALL_PAIRS.csv',conclusions['TypeII']['direct']['pairs'])]:
        if not (out/name).exists():csv_save(out/name,encode(data))
    for m in METHODS:
        for name,data in [(m+'_TASK_USE_PAIRS.csv',conclusions['task_use'][m]),(m+'_ONLINE_TYPE_II_ALL_PAIRS.csv',conclusions['TypeII']['online'][m]['pairs']),
                          (m+'_DECISIONS.csv',[{k:v for k,v in d.items() if k not in ('queries','selected_query')} for d in decisions if d['method']==m])]:
            if not (out/name).exists():csv_save(out/name,encode(data))
    migrations=[]
    qindex={(q['context_id'],q['method'],q['gamma']):q for q in queries}
    for p in severe_plans():
        for gamma in (.5,0.):
            a,b=[qindex[(p['context_id'],m,gamma)] for m in METHODS]
            migrations.append(dict(context_id=p['context_id'],snapshot_id=p['snapshot_id'],episode=p['episode'],gamma=gamma,
                old=a,full=b,comparison_scope='OWN_CAUSAL_QUERY_PER_RESIDENT_OWNER; NOT_FORCED_SAME_PACKET'))
    write(out/'NEIGHBOR_REJECTION_MIGRATIONS.json',migrations)
    wins=read(out/'LATENCY_ALL_WINDOWS.json')
    timing={m:dict(planned=48,preparation_deadline_misses=sum(d['overall_deadline_failure'] for d in decisions if d['method']==m),
        feedback_deadline_misses=sum(w['latency_ms'] is not None and w['latency_ms']>20 for w in wins if w['method']==m and w['window']=='FEEDBACK'),
        saved_preparation_latency_ms=[d['command_ready_ms'] for d in decisions if d['method']==m],
        recognized_feedback_max_ms=max((w['latency_ms'] for w in wins if w['method']==m and w['window']=='FEEDBACK' and w['latency_ms'] is not None),default=None),
        hard_realtime_deployment_verified=False) for m in METHODS}
    write(out/'LATENCY.json',timing);result['realtime']=timing
    write(out/'STEP45_RESULT.json',result)
    print(json.dumps(encode(dict(execution=result['task_execution_status'],confirmation=conclusions['status'],methods=result['methods'],readback=evidence)),ensure_ascii=False))
    return result

if __name__=='__main__':summarize()
