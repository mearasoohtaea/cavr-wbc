"""Exactly two SciPilot figures from STEP45 saved readback tables; no simulation."""
from pathlib import Path
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from PIL import Image
from pypdf import PdfReader
from cavr_wbc.experiments.step45_io import output,read,write,load_numeric
from cavr_wbc.experiments.step45_inputs import METHODS

SCRIPTS=Path('C:/Users/ZhuanZ（无密码）/.codex/skills/scipilot-figure/scripts')
sys.path.insert(0,str(SCRIPTS))
from setup_style import setup_style
from layout_tools import finalize_figure,add_panel_labels
from visual_qa import render_preview,audit_layout
from profile_data import profile_data,render_report
from export_figure import export_figure
from check_figure import check_figure

SHORT=['Old CAL','Full CAL']
COLORS=['#0072B2','#D55E00']
OUTCOME_COLORS={'M':'#0072B2','B':'#56B4E9','F':'#D55E00','P':'#CC79A7','A':'#D9D9D9','L':'#E69F00','?':'#FFFFFF'}
BLOCKS=['task_values','current_physics_contacts_mass_bias_selection_bounds','objective_products_and_CSC',
        'constraints_and_current_metadata','contact_reference_SVD_passive_and_trace']
BLOCK_LABELS=['Task','Physics','Objective','Rows','SVD']

def code(d):
    if not d['decision_exists']:return '?'
    if d['selected_command_sent']:
        if not d['complete_actual']:return 'P'
        if not d['safe_actual_6mm']:return 'F'
        if not d['timing_qualified_actual']:return 'L'
        return 'M' if d['selected_gamma']==.5 else 'B'
    return 'L' if d['overall_deadline_failure'] else 'A'

def coverage(out,r):
    fig,axes=plt.subplots(3,2,figsize=(7.16,7.1),constrained_layout=True)
    matrices=r['confirmation']['direction_leg_support'];pairs=r['confirmation']['source_pairs']
    for k,(direction,leg) in enumerate([(1,'FR'),(1,'RR'),(-1,'FR'),(-1,'RR')]):
        ax=axes[k//2,k%2]
        for j,m in enumerate(METHODS):
            v=next(v for v in matrices[m] if v['direction']==direction and v['fault_leg']==leg)
            values=[v['planned'],v['recognized'],v['complete_safe'],v['contexts']]
            xs=np.arange(4)+(j-.5)*.30
            ax.scatter(xs,values,marker='o' if j==0 else 's',color=COLORS[j],s=27,label=SHORT[j],zorder=3)
            for x,y in zip(xs,values):ax.annotate(str(y),(x,y),xytext=(0,7 if j==0 else -14),textcoords='offset points',ha='center',fontsize=8)
        subset=[p for p in pairs if p['direction']==direction and p['fault_leg']==leg]
        ax.set_title(('Positive' if direction>0 else 'Negative')+' '+leg+f" | {len({p['snapshot_id'] for p in subset})} snapshots / {len({p['episode'] for p in subset})} ep",fontsize=8)
        ax.set_xticks(range(4),['Planned','Sent','Safe','RT Type-II']);ax.set_ylim(-2,15);ax.set_yticks([0,4,8,12])
        ax.set_ylabel('Source contexts');ax.grid(axis='y',alpha=.15)
    axes[0,0].legend(loc='upper right',frameon=False,fontsize=8)
    for j,direction in enumerate((1,-1)):
        ax=axes[2,j];subset=[p for p in pairs if p['direction']==direction]
        for x,p in enumerate(subset):
            for y,key in enumerate(('old','full')):
                d=p[key];c=code(d)
                ax.scatter([x],[y],marker='s',s=135,color=OUTCOME_COLORS[c],edgecolors='#666666',linewidths=.4)
                ax.text(x,y,c,ha='center',va='center',fontsize=8,color='white' if c in ('M','F','P') else 'black')
                if p['online_type_ii'][METHODS[y]]['timing_qualified_mechanism']:
                    ax.plot(x,y-.29,marker='*',color='black',markersize=4)
            state=p['direct_opportunity']
            ax.text(x,2,'D' if state=='OPPORTUNITY' else '?' if state=='UNKNOWN' else '-',ha='center',va='center',fontsize=8)
            if p['direct_opportunity_timely']:ax.plot(x,2-.29,marker='*',color='black',markersize=4)
        ax.set_xticks(range(len(subset)),[str(i+1) for i in range(len(subset))]);ax.tick_params(axis='x',rotation=90)
        ax.set_yticks([0,1,2],['Old','Full','Direct']);ax.set_ylim(2.5,-.6);ax.set_xlim(-.7,len(subset)-.3)
        ax.set_xlabel('Source ordinal (within direction)');ax.set_title(('Positive' if direction>0 else 'Negative')+' | all 24 paired sources',fontsize=8)
    fig.suptitle('Fixed planned coverage and own-ACTUAL transitions',fontsize=9)
    fig.supxlabel('M: safe middle; B: safe backup; F: unsafe; P: partial; A: abstain; L: late; ?: unknown.\nStar: RT-qualified Type-II; D: physical direct opportunity. Source index is saved separately.',fontsize=8)
    return fig

def diagnostic_tables(out):
    wins=read(out/'LATENCY_ALL_WINDOWS.json');raw=read(out/'ASSEMBLY_QP_TIMING.json')
    by={v['path']:v for v in raw}
    failed=[w for w in wins if w['latency_ms'] is not None and w['latency_ms']>20]
    fb=[w for w in failed if w['window']=='FEEDBACK']
    peak=max(fb or failed or [w for w in wins if w['latency_ms'] is not None],key=lambda w:w['latency_ms'])
    evidence=by.get(peak.get('raw_solver_evidence'),{})
    endpoints={}
    if peak['window']=='PREPARATION':
        path=out/'TEST'/peak['context_id']/('DIRECT/PACKET.json' if peak['method']=='DIRECT_PACKET' else peak['method']+'/DECISION.json')
        # Saved packet metadata only, not a trajectory bank or new evaluation.
        packet=load_numeric(path)
        peak['phase_latency_ms']=packet.get('phase_latency_ms',{})
        for name in ('B','C'):
            value=packet.get(name) or {};result=value.get('raw_solver_result') or {}
            index=result.get('step37_global_qp_index',result.get('step35_global_qp_index'))
            linked=by.get(f'raw_qp/QP{int(index):06d}.json',{}) if index is not None else {}
            endpoints[name]=dict(timing=value.get('timing',{}),raw=linked)
        linked=[v['raw'] for v in endpoints.values() if v['raw']]
        evidence=max(linked,key=lambda v:v.get('assembly_ms') or 0.) if linked else {}
        peak['endpoint_timing']=endpoints
    write(out/'MAXIMUM_FAILED_WINDOW_LOCATOR.json',dict(window=peak,raw=evidence,endpoints=endpoints,all_late_windows=len(failed),
        selection_scope='MAXIMUM_FEEDBACK_FAILURE_IF_PRESENT_ELSE_MAXIMUM_FAILURE_OR_WINDOW',
        nested_timings_not_additive=True,wall_not_replaced_by_cpu=True,GC_or_scheduling_causality_not_established=True))
    return wins,raw,peak,evidence

def response(out,r):
    fig,axes=plt.subplots(3,2,figsize=(7.16,8.5),constrained_layout=True)
    wins,raw,peak,evidence=diagnostic_tables(out)
    categories=[('PREPARATION',METHODS[0],'Old\nprep'),('PREPARATION',METHODS[1],'Full\nprep'),
        ('PREPARATION','DIRECT_PACKET','Direct\nprep'),('FEEDBACK',METHODS[0],'Old\nFB'),
        ('FEEDBACK',METHODS[1],'Full\nFB'),('FEEDBACK','DIRECT','Direct\nFB')]
    ax=axes[0,0]
    for j,(window,m,label) in enumerate(categories):
        subset=[w for w in wins if w['window']==window and w['latency_ms'] is not None and
                (w['method'].startswith('DIRECT_') if m=='DIRECT' else w['method']==m)]
        xs=np.linspace(j-.17,j+.17,len(subset)) if subset else []
        color=COLORS[j%3] if j%3<2 else '#666666'
        ax.scatter(xs,[w['latency_ms'] for w in subset],s=10 if window=='PREPARATION' else 2,color=color,alpha=.3,rasterized=True)
        withheld=[(x,w) for x,w in zip(xs,subset) if (not w['applied'] and not w.get('offline_counterfactual') and not w['method'].startswith('DIRECT_'))]
        ax.scatter([x for x,w in withheld],[w['latency_ms'] for x,w in withheld],s=18,marker='x',color=color,linewidths=.7)
        ax.text(j,1.02,str(len(subset)),ha='center',fontsize=8,transform=ax.get_xaxis_transform())
    ax.axhline(20,color='black',linestyle='--',linewidth=.8)
    ax.set_xticks(range(6),[c[2] for c in categories]);ax.set_ylabel('Complete wall latency (ms)')
    ax.set_title('All preparation and feedback windows (n above)',fontsize=8,pad=19)
    ax.set_yscale('symlog',linthresh=2);ax.set_ylim(0,max(30,max(w['latency_ms'] for w in wins if w['latency_ms'] is not None)*1.2))
    ax.legend(handles=[Line2D([0],[0],color='black',ls='--',label='20 ms'),Line2D([0],[0],color='black',marker='x',ls='none',label='withheld own command')],frameon=False,fontsize=8,loc='lower left')
    ax=axes[0,1]
    values=[[v['subblocks'][b]['wall_ms'] for v in raw if b in v['subblocks'] and v['subblocks'][b].get('wall_ms') is not None] for b in BLOCKS]
    ax.boxplot(values,tick_labels=BLOCK_LABELS,showfliers=True,widths=.6,
        flierprops=dict(marker='.',markersize=2,alpha=.2),medianprops=dict(color='#D55E00',linewidth=1),
        boxprops=dict(color='#0072B2'),whiskerprops=dict(color='#0072B2'),capprops=dict(color='#0072B2'))
    ax.set_ylabel('Assembly subblock wall time (ms)');ax.set_yscale('symlog',linthresh=.05)
    ax.set_title('All recorded QP assembly subblocks',fontsize=8);ax.grid(axis='y',alpha=.15)
    ax.set_xlabel('Nested stages (not summed)')
    ax=axes[1,0]
    timing=peak.get('timing') or peak.get('phase_latency_ms') or {}
    names=['complete','assembly','CPU','decode','solve wall','prepare','scratch','commit','copy']
    vals=[peak['latency_ms'],timing.get('assembly_ms'),timing.get('assembly_thread_cpu_ms'),timing.get('decode_ms'),
        timing.get('solve_wall_ms'),timing.get('feedback_prepare_seed_configure_ms'),timing.get('scratch_action_forward_and_check_ms'),
        timing.get('prepared_commit_ms'),timing.get('final_commit_copy_ms')]
    if peak['window']=='PREPARATION':
        ep=peak['endpoint_timing']
        names=['complete','B+contract','C+contract','B assembly','C assembly','B CPU','C CPU']
        vals=[peak['latency_ms'],timing.get('B_QP_and_contract_ms'),timing.get('C_QP_and_contract_ms'),
            ep.get('B',{}).get('raw',{}).get('assembly_ms'),ep.get('C',{}).get('raw',{}).get('assembly_ms'),
            ep.get('B',{}).get('raw',{}).get('thread_cpu_ms'),ep.get('C',{}).get('raw',{}).get('thread_cpu_ms')]
    known=[(i,v) for i,v in enumerate(vals) if v is not None]
    ax.scatter([v for i,v in known],[i for i,v in known],marker='o',s=24,color='#0072B2')
    ax.axvline(20,color='black',ls='--',lw=.7);ax.set_yticks(range(len(names)),names);ax.invert_yaxis()
    ax.set_xlabel('Recorded time (ms), nested—not summed')
    ax.set_title(f"Peak {'late' if peak['latency_ms']>20 else 'measured'} {peak['window'].lower()} | {peak['latency_ms']:.2f} ms",fontsize=8)
    ax.text(.99,.02,peak['context_id'].replace('T45_TEST_','ep')+f" / slot {peak['slot']}\nraw status: {evidence.get('raw_status','not linked')}",ha='right',va='bottom',fontsize=8,transform=ax.transAxes)
    for k,(metric,label,title) in enumerate([
        ('first_action_gain_m','Directed action gain vs B (mm)','0.02–0.04 s action benefit'),
        ('terminal_absolute_task_error_change_m','1 s terminal absolute error change (mm)','Full-horizon terminal tracking'),
        ('full_horizon_abs_task_error_integral_change_m_s','1 s absolute error integral change (mm s)','Full-horizon integrated tracking')]):
        ax=axes.flat[k+3]
        for j,m in enumerate(METHODS):
            known=[p for p in r['confirmation']['task_use'][m] if p[metric] is not None and np.isfinite(p[metric])]
            for i,p in enumerate(known):
                x=j+(.32*(i/max(1,len(known)-1)-.5))
                marker='o' if p['actual_safe'] and p['actual_timely'] else '^' if p['ACTUAL_outcome']=='NUMERICAL_INCOMPLETE' else 'x'
                ax.scatter([x],[p[metric]*1000],color=COLORS[j],marker=marker,s=20,linewidths=.7,alpha=.8)
            ax.text(j,1.02,f'known {len(known)}/48',ha='center',fontsize=8,transform=ax.get_xaxis_transform())
        ax.axhline(0,color='black',lw=.7,ls='--');ax.set_xlim(-.45,1.45);ax.set_xticks([0,1],SHORT)
        ax.set_ylabel(label);ax.set_title(title,fontsize=8,pad=20);ax.grid(axis='y',alpha=.15)
    fig.supxlabel('Direct timing is offline counterfactual, not an online certification. Assembly stages are nested.\nTask: circle = safe timely; cross = unsafe/untimely; triangle = partial. Missing values are not zeros.',fontsize=8)
    return fig

def main(out=output()):
    r=read(out/'STEP45_RESULT.json');folder=out/'figures';folder.mkdir(exist_ok=True)
    setup_style(journal='ieee',lang='en')
    plt.rcParams.update({'font.size':8,'axes.labelsize':8,'axes.titlesize':8,'xtick.labelsize':8,'ytick.labelsize':8,
        'legend.fontsize':8,'font.family':'DejaVu Sans','pdf.fonttype':42,'ps.fonttype':42,'savefig.bbox':None})
    decisions=read(out/'ALL_METHOD_DECISIONS.json');wins=read(out/'LATENCY_ALL_WINDOWS.json')
    profiles={}
    for name,data,groups in [('DECISIONS',decisions,['method','direction','fault_leg']),
                              ('TIMING',wins,['method','window'])]:
        keys=['context_id','method','direction','fault_leg','command_ready_ms','selected_command_sent','complete_actual','safe_actual_6mm'] if name=='DECISIONS' else ['context_id','method','window','latency_ms','applied']
        frame=pd.DataFrame([{k:v.get(k) for k in keys} for v in data]);profiles[name]=profile_data(frame,group_cols=groups)
    assembly=read(out/'ASSEMBLY_QP_TIMING.json')
    profiles['ASSEMBLY']=profile_data(pd.DataFrame([dict(kind=v['kind'],raw_status=v['raw_status'],
        assembly_ms=v['assembly_ms'],thread_cpu_ms=v['thread_cpu_ms'],
        **{b:v['subblocks'].get(b,{}).get('wall_ms') for b in BLOCKS}) for v in assembly]),group_cols=['kind'])
    task_rows=[{k:p.get(k) for k in ('method','direction','fault_leg','selected','actual_safe','actual_timely',
        'first_action_gain_m','terminal_absolute_task_error_change_m','full_horizon_abs_task_error_integral_change_m_s')}
        for m in METHODS for p in r['confirmation']['task_use'][m]]
    profiles['TASK']=profile_data(pd.DataFrame(task_rows),group_cols=['method','direction','fault_leg'])
    write(folder/'DATA_PROFILE.json',profiles)
    (folder/'DATA_PROFILE.md').write_text('\n\n'.join(name+'\n'+render_report(p) for name,p in profiles.items()),encoding='utf-8')
    write(folder/'CHART_DECISIONS.json',dict(objective='Coverage, live timing and task-use separation',
        coverage='Grouped counts without connecting categorical stages; all paired sources remain visible.',
        timing='All observed windows, no downsampling; distribution and nested failure locator; no stacked totals.',
        task='Individual own-ACTUAL/B paired changes; absent values omitted and denominators retained.',
        inference='Fixed 24 snapshots / 8 episodes; no IID error bars or significance tests.',journal='IEEE T-RO',minimum_font_pt=8))
    reviews=[]
    for name,build,size in [('FIG1_COVERAGE_MIGRATION',coverage,(7.16,7.1)),('FIG2_TIMING_TASK_RESPONSE',response,(7.16,8.5))]:
        fig=build(out,r);finalize_figure(fig);add_panel_labels(fig,style='ieee',x_offset_pt=-8,ha='right')
        render_preview(fig,str(folder/(name+'_preview.png')),dpi=180)
        reviews.append(dict(name=name,layout_issues=audit_layout(fig),minimum_text_pt=min(t.get_fontsize() for t in fig.findobj(matplotlib.text.Text) if t.get_text())))
        export_figure(fig,str(folder/name),formats=['pdf','png'],size_inches=size,dpi=600,grayscale_preview=False,tight=False)
        fig.savefig(folder/(name+'.png'),dpi=600,bbox_inches=None)
        Image.open(folder/(name+'.png')).convert('L').save(folder/(name+'_grayscale.png'),dpi=(600,600))
        for ext in ('pdf','png'):
            checks,info=check_figure(str(folder/(name+'.'+ext)),min_dpi=600,target_inches=size)
            reviews[-1][ext+'_checks']=checks;reviews[-1][ext+'_info']=info
        reader=PdfReader(folder/(name+'.pdf'));fonts=[]
        for page in reader.pages:
            for font in page['/Resources']['/Font'].get_object().values():
                font=font.get_object();descendants=font.get('/DescendantFonts')
                for node in ([n.get_object() for n in descendants] if descendants else [font]):
                    descriptor=node.get('/FontDescriptor');descriptor=descriptor.get_object() if descriptor else {}
                    fonts.append(dict(base=str(font.get('/BaseFont')),subtype=str(node.get('/Subtype')),embedded_truetype='/FontFile2' in descriptor,type3=str(node.get('/Subtype'))=='/Type3'))
        reviews[-1]['pdf_descendant_font_verification']=fonts
        reviews[-1]['pdf_font_embedding_verified']=bool(fonts) and all(v['embedded_truetype'] and not v['type3'] for v in fonts)
        reviews[-1]['pdf_dimensions_inches']=[float(reader.pages[0].mediabox.width)/72,float(reader.pages[0].mediabox.height)/72]
        plt.close(fig)
    write(folder/'PROGRAMMATIC_FIGURE_QA.json',reviews)
    write(folder/'FIGURE_SOURCE_INDEX.json',[dict(direction=p['direction'],ordinal=i+1,context_id=p['context_id'],snapshot_id=p['snapshot_id'],episode=p['episode'],fault_leg=p['fault_leg'],tick=p['tick'],displacement_m=p['displacement_m']) for direction in (1,-1) for i,p in enumerate([p for p in r['confirmation']['source_pairs'] if p['direction']==direction])])

if __name__=='__main__':main()
