"""STEP45 paths and streaming evidence utilities; older evidence is read-only."""
from pathlib import Path
import numpy as np
from scipy import sparse
from cavr_wbc.experiments.step30_io import append, sha, encode, relative
import json
import hashlib
import os
from time import sleep

def write(path,value):
    """Metadata-only sharing-lock retry; never repeat numerical work."""
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    pending=path.with_suffix(path.suffix+'.'+str(os.getpid())+'.tmp')
    with pending.open('w',encoding='utf-8',newline='\n') as stream:
        json.dump(encode(value),stream,sort_keys=True,separators=(',',':'),allow_nan=False,ensure_ascii=False)
        stream.write('\n');stream.flush()
    for attempt in range(21):
        try:
            os.replace(pending,path)
            return
        except PermissionError:
            if attempt==20:raise
            sleep(.01)

def _restore(value):
    if isinstance(value, dict):
        if set(value) == {'nonfinite'}:
            return float(value['nonfinite'])
        return {key: _restore(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_restore(item) for item in value]
    return value

def read(path, default=None):
    path = Path(path)
    return _restore(json.loads(path.read_text(encoding='utf-8'))) if path.exists() else default


OUTPUT_ROOT_D = Path(__file__).resolve().parents[2]
SOURCE_ROOT_D = Path('D:/CAVR-WBC/cavr_step44_matched_cal_online_recovery_20261011')
SOURCE39 = OUTPUT_ROOT_D / 'artifacts/step39_matched_screen_20261010/step39-matched-screen-20261010-01'
MODEL_NPZ = SOURCE39 / 'models/step39_frozen_screen.npz'
NATIVE_DLL = OUTPUT_ROOT_D / 'artifacts/step30_injured_governor_20261008/step30-injured-governor-20261008-01/native/step30_prefix.dll'
SOURCE_COMMIT = '3b8896898537886b6ef042f2cb6f40c0eac93721'
PROTOCOL = Path('D:/CAVR-WBC/experiment_handoff_20261010/NEXT_CODEX_INSTRUCTIONS_STEP45_CAL_KEY_ASSEMBLY_CONFIRMATION_20261011.md')
RUN_ID = 'step45-cal-key-assembly-confirmation-20261011-01'
def output(run_id=RUN_ID):
    return OUTPUT_ROOT_D / 'artifacts/step45_cal_key_confirmation_20261011' / run_id
def require_output(path):
    p=Path(path).resolve()
    if not p.is_relative_to(OUTPUT_ROOT_D.resolve()):
        raise ValueError('STEP45 write outside D task')
    return p
_base_write=write
def write(path,value):
    return _base_write(require_output(path),value)


def save_numeric(path, value):
    """Separate all numeric arrays/sparse QP witnesses from JSON indexes."""
    path = Path(path)
    path = require_output(path)
    arrays = {}
    fingerprints = {}

    def split(item):
        if sparse.issparse(item):
            c = item.tocsc()
            return {'sparse_format': 'csc', 'shape': list(c.shape),
                    'data': split(c.data), 'indices': split(c.indices), 'indptr': split(c.indptr)}
        if isinstance(item,(list,tuple)) and item:
            try:
                candidate=np.asarray(item)
                if candidate.dtype.kind in 'biuf' and candidate.ndim>=1:item=candidate
            except (ValueError,TypeError):pass
        if isinstance(item, np.ndarray):
            if item.dtype.kind=='O':raise TypeError('object array forbidden')
            signature=(str(item.dtype),item.shape,hashlib.sha256(np.ascontiguousarray(item).tobytes()).hexdigest())
            key=fingerprints.get(signature)
            if key is None:
                key='a'+str(len(arrays));arrays[key]=item;fingerprints[signature]=key
            return {'npz_key': key, 'shape': list(item.shape), 'dtype': str(item.dtype)}
        if isinstance(item, dict):
            return {str(k): split(v) for k, v in item.items()}
        if isinstance(item, (list, tuple)):
            return [split(v) for v in item]
        return encode(item)

    saved = split(value)
    path.parent.mkdir(parents=True, exist_ok=True)
    npz = path.with_suffix('.npz')
    with npz.open('xb') as stream:
        np.savez_compressed(stream, **arrays)
    write(path, {'numeric_npz': npz.name, 'numeric_sha256': sha(npz), 'record': saved})
    return {'json': str(path), 'npz': str(npz), 'json_sha256': sha(path),
            'npz_sha256': sha(npz), 'numeric_arrays': len(arrays)}


def load_numeric(path):
    """Restore one saved current-batch packet, without another decision/QP."""
    path = Path(path)
    saved = read(path)
    npz = path.parent / saved['numeric_npz']
    if sha(npz) != saved['numeric_sha256']:
        raise ValueError('current STEP45 numeric shard integrity mismatch')
    with np.load(npz, allow_pickle=False) as archive:
        def restore(item):
            if isinstance(item, dict) and 'npz_key' in item:
                return archive[item['npz_key']].copy()
            if isinstance(item, dict) and item.get('sparse_format') == 'csc':
                return sparse.csc_matrix((restore(item['data']), restore(item['indices']),
                    restore(item['indptr'])), shape=tuple(item['shape']))
            if isinstance(item, dict):
                return {key: restore(value) for key, value in item.items()}
            if isinstance(item, list):
                return [restore(value) for value in item]
            return item
        return restore(saved['record'])


SOURCE_DOMAIN = OUTPUT_ROOT_D / 'artifacts/step41_terminal_cal_domain_20261010/step41-terminal-cal-domain-20261010-01'
SOURCE44 = OUTPUT_ROOT_D / 'artifacts/step44_matched_cal_recovery_20261011/step44-matched-cal-online-recovery-20261011-01'
