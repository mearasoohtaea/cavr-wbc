"""One D-space/import/write check and saved-data repair, without numerical work."""
import shutil
import os
from cavr_wbc.experiments.step45_io import *
from cavr_wbc.experiments.step45_calibration import repair_saved_gamma0
def prepare():
    out=output();out.mkdir(parents=True,exist_ok=True)
    if (out/'PREPARATION.json').exists():raise FileExistsError('prepare once')
    import cavr_wbc,osqp,mujoco,scipy
    if not Path(cavr_wbc.__file__).resolve().is_relative_to(OUTPUT_ROOT_D):raise ValueError('package outside new checkout')
    write(out/'PREPARATION.json',dict(cavr_wbc_file=cavr_wbc.__file__,D_free_bytes_before=shutil.disk_usage(OUTPUT_ROOT_D).free,
        TMP=os.environ['TMP'],TEMP=os.environ['TEMP'],D_write_marker=True,new_QP=0,new_steps=0,new_fits=0))
    names=('step42_kernel.py','step42_physical_consensus.py','step39_margin.py','step41_terminal_domain.py')
    source={n:sha(SOURCE_ROOT_D/'cavr_wbc/control'/n) for n in names}
    actual={n:sha(OUTPUT_ROOT_D/'cavr_wbc/control'/n) for n in names}
    if source!=actual:raise ValueError('acceptance source bytes changed')
    write(out/'ACCEPTANCE_IDENTITY_FREEZE.json',dict(source_sha256=source,sha256=actual,byte_exact=True))
    freeze=repair_saved_gamma0(out)
    print(dict(prepared=True,checks=freeze['checks'],new_numeric_actions=0))
if __name__=='__main__':prepare()
