"""Chinese STEP45 report/handoff from saved metadata, without new numerical work."""
from collections import Counter
import numpy as np
from cavr_wbc.experiments.step45_io import *
from cavr_wbc.experiments.step45_inputs import METHODS

def stats(values):
    x=np.asarray([v for v in values if v is not None and np.isfinite(v)],float)
    return dict(n=len(x),p50=float(np.percentile(x,50)) if len(x) else None,
        p95=float(np.percentile(x,95)) if len(x) else None,p99=float(np.percentile(x,99)) if len(x) else None,
        maximum=float(max(x)) if len(x) else None,over_20ms=int(np.sum(x>20)))

def main(out=output()):
    r=read(out/'STEP45_RESULT.json');c=r['confirmation'];m=r['methods'];primary=m[METHODS[1]]
    source=read(out/'SOURCE_PRESERVATION.json',{})
    hist=bool(source.get('HEAD_unchanged') and source.get('index_unchanged') and source.get('result_unchanged'))
    freeze=r['cal_freeze'];checks=freeze['checks'];budget=r['run']['budget']
    protocol=dict(AUTHORIZE_STEP45_SAVED_CAL_REPAIR_AND_FRESH_CONFIRMATION='TRUE',
        STEP44_RESULT_UNCHANGED='NOT_ESTABLISHED',STEP44_GAMMA0_CAL_OMISSION_DISCLOSED='TRUE',
        STEP45_REUSED_STEP44_B_CAL_ROWS=64,STEP45_NEW_CAL_TRAJECTORIES=0,STEP45_NEW_TRAIN=0,STEP45_NEW_FITS=0,
        STEP45_GAMMA0_CAL_FINITE_EXPECTED=80,STEP45_GAMMA0_CAL_PHYSICAL_FAIL_EXPECTED=19,
        STEP45_GAMMA05_CAL_UNCHANGED='TRUE' if checks['unchanged_groups']['0.5:thigh'] else 'FALSE',
        STEP45_DOMAIN_BYTES_UNCHANGED_FROM_STEP44='TRUE' if r['readback']['status']=='VERIFIED' else 'NOT_VERIFIED',
        STEP45_REFERENCE_EPISODES=8,STEP45_TEST_SEVERE_CONTEXTS=48,STEP45_ONLINE_DECISIONS_PLANNED=96,
        STEP45_DIRECT_PLANNED=168,STEP45_MAX_NEW_1S_BRANCHES=264,
        STEP45_SAFETY_ACCEPTANCE=primary['S'],STEP45_ONLINE_TYPE_II=primary['C'],
        STEP45_COMPLETE_WALL_DEADLINE_MS=20,HISTORICAL_RESULTS_UNCHANGED='TRUE' if hist else 'NOT_VERIFIED',
        E3_AUTHORIZED='FALSE',RL_HARDWARE_AUTHORIZED='FALSE')
    (out/'PROTOCOL_STATUS.ini').write_text('\n'.join(f'{k} = {v}' for k,v in protocol.items())+'\n',encoding='utf-8',newline='\n')
    wins=read(out/'LATENCY_ALL_WINDOWS.json');raw=read(out/'ASSEMBLY_QP_TIMING.json')
    timing={}
    for method in (*METHODS,'DIRECT'):
        timing[method]={}
        for window in ('PREPARATION','FEEDBACK'):
            subset=[w for w in wins if w['window']==window and (w['method'].startswith('DIRECT_') if method=='DIRECT' else w['method']==method)]
            timing[method][window]=stats([w['latency_ms'] for w in subset])
    assembly=stats([v['assembly_ms'] for v in raw])
    subblocks={b:stats([v['subblocks'][b].get('wall_ms') for v in raw if b in v['subblocks']])
        for b in sorted({b for v in raw for b in v['subblocks']})}
    write(out/'TIMING_SUMMARY.json',dict(windows=timing,assembly=assembly,subblocks=subblocks,
        all_observed_windows_included=True,units='ms',nested_not_additive=True,
        thread_CPU_not_subtracted_from_wall=True,no_causal_GC_or_scheduling_attribution=True))
    locator=read(out/'MAXIMUM_FAILED_WINDOW_LOCATOR.json',{})
    rows=read(out/'ALL_PLANNED_RESULTS.json')
    lines=['# STEP45：CAL 规范键修复与容量在线恢复确认','',
        f"执行状态：{r['task_execution_status']}；科学端点：{c['status']}。部署端点：硬实时部署未验证。",
        f"主方法 FULL_CAL_CONSENSUS 发送 {primary['recognized']}/48 条 own ACTUAL，完整安全 {primary['complete_safe']}、安全且实时 {primary['complete_safe_timely']}，完整错受 {primary['complete_error_accepts']}、已发送 partial {primary['partial']}。",
        f"实时合格在线 Type-II：{primary['online_type_ii_distribution']['contexts']} 个 severe source / {primary['online_type_ii_distribution']['snapshots']} 个 physical snapshot / {primary['online_type_ii_distribution']['episodes']} 个 reference episode；负向 RR 覆盖 {primary['negative_RR_episodes']} 个 episode。",
        '', '## 方法修复与固定输入','',
        'STEP44 增强版本实际为 middle CAL 已扩充、B CAL 未扩充、两 γ 的域表已扩充；其 NOT_ESTABLISHED 原结论和所有证据保留。规范键由原 group_key(0., thigh) 生成 0:thigh，避免 0.0:thigh 错配。',
        '本轮只在现有增强 bundle 的规范 γ=0/thigh 组追加保存的 64 条 B CAL（50 PASS /14 FAIL），与旧16条合并为80条有限完整记录、19条物理失败、0 UNKNOWN。未重跑CAL、未训练、未拟合、未再追加全局CAL ID。γ=.5完整组、两个calf组、预测器、TRAIN、normalizer、pose和验收常数不变；两域表直接复用STEP44原字节。',
        '两方法使用同一装配优化版本：resident task-map直接复用静态T，owner复用固定A_task/eye；保留原desired/weights、矩阵乘法与两次H加法顺序。M/bias/J/Jdot/health/bounds/SVD/contact均按当前tick计算，独立数值witness不被下一tick覆盖。',
        'OLD_CAL_CONSENSUS = 原旧CAL+原域表；FULL_CAL_CONSENSUS = 修复后完整增强CAL+原增强域表。所有方法采用独立 live owner、B0和packet。每个源先保存两个不可改决定，再推进各自own ACTUAL和direct；共享healthy控制只算一次，不计作额外独立episode。',
        '保持1 s/.002 s/501 dense/21 checkpoint、6 mm local、terminal vx=1 mm/s及原COM/command torque/anchor/task speed/42维raw和sent契约；candidate 1e-7、reference 1e-8、摩擦upper−1e-4 N和torque inset 1e-4 N·m不变。',
        '8条fresh reference的目标依次为 +61.50、−61.50、+63.25、−63.25、+65.75、−65.75、+67.50、−67.50 mm；tick34/37/41，共24 snapshot。每snapshot固定FR/RR severe .15、healthy与同腿mild .30，合计96在线决定、168 direct和最多264个1 s位置。',
        '', '| 方法 | planned | 发送 | 完整安全 | 安全且实时 | 完整错受 | partial | 弃权 | 准备late | RT Type-II |',
        '|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
    for method in METHODS:
        v=m[method];lines.append('| '+method+' | '+' | '.join(str(v[k]) for k in ('planned','recognized','complete_safe','complete_safe_timely','complete_error_accepts','partial','ABSTAIN','late'))+' | '+str(v['online_type_ii_distribution']['contexts'])+' |')
    lines+=['','## S：实际接受可靠性；C：四方容量恢复','',
        'S要求全部已发送ACTUAL完整到达1 s，通过原physical+terminal+6 mm与所有必要完整实时窗口。完整错受为FAIL；已认可partial、无法验证或没有发送不能建立S。C还要求面板完整、S成立，至少3 snapshot/2 reference episode的实时合格Type-II，负向RR至少2 episode。','',
        'Type-II同源四方为healthy B、同腿mild B、severe B和本方法own ACTUAL；severe B实际sent/effective容量≥99%必须严格早于dense physical首次失败，主方法及时发送γ=.5且own ACTUAL完整安全。所有四方必要窗口均计实时资格，包括healthy首包。offline direct物理机会与timely机会分开，离线late的完整轨迹不能认证实时恢复。','']
    for method in METHODS:
        v=m[method];lines.append(f"- {method}：S={v['S']}；C={v['C']}。物理direct机会{v['opportunity_denominator']}、物理闭合{v['physical_closure_in_opportunities']}；timely direct机会{v['timely_opportunity_denominator']}、timely闭合{v['timely_closure_in_opportunities']}；direct未知{v['opportunity_unknown']}。")
    lines+=['','| 方法 | 方向/腿 | planned | 发送 | 完整安全 | RT Type-II | snapshot | episode |','|---|---|---:|---:|---:|---:|---:|---:|']
    for method,vs in c['direction_leg_support'].items():
        for v in vs:lines.append('| '+method+' | '+('+' if v['direction']>0 else '-')+v['fault_leg']+' | '+' | '.join(str(v[k]) for k in ('planned','recognized','complete_safe','contexts','snapshots','episodes'))+' |')
    partials=[v for v in rows if v['branch'].endswith('_ACTUAL') and v['observed'] and not v['complete_501']]
    for v in partials:lines+=['',f"已发送未完成：{v['id']}；状态{v['status']}；原因{v.get('reason')}；最大反馈{v['max_feedback_latency_ms']} ms。该轨迹保留原前缀，迟到动作未应用，不借旧B跑满，不删除、不重派。"]
    pairs=c['source_pairs']
    lines+=['',f"逐源新增安全实时覆盖{sum(p['added_safe_coverage'] for p in pairs)}，失去安全实时覆盖{sum(p['lost_safe_coverage'] for p in pairs)}。所有48对及每γ的邻居、拒收理由、状态迁移均保存在SAME_SOURCE_METHOD_PAIRS.json和NEIGHBOR_REJECTION_MIGRATIONS.json；未施加候选真安全性为UNKNOWN，不代入direct标签。",
        '', '## U：短动作与全任务分开','',
        '分别报告.02–.04 s首动作有向进度相对B、1 s外部任务末绝对误差与有向COM位移、1 s全程绝对误差积分。planned分母每方法48，缺测不是0；全部可测own ACTUAL/B配对保留，不只展示成功者。',
        'STEP44已有11个完整安全middle均首动作获益，11个末任务绝对误差均略变差；该事实不改，本轮不回放历史求解。','']
    for method in METHODS:
        t=m[method]['task_middle_descriptives'];ps=c['task_use'][method]
        lines.append(f"- {method}：安全及时middle完整配对{t['full_pairs']}；首动作正增益{t['short_gain_positive']}；末绝对误差改善{t['terminal_abs_error_improved']}、变差{t['terminal_abs_error_worse']}；积分改善{t['error_integral_improved']}。全部planned首动作可测{sum(p['first_action_gain_m'] is not None for p in ps)}/48、末任务可测{sum(p['terminal_absolute_task_error_change_m'] is not None for p in ps)}/48。")
    lines+=['','## 完整计时与失败定位','',
        '20 ms完整begin→staging检查→commit边界不变，17 ms prepared reserve及B/C/feedback 6/3/6 ms子预算不变。采样开销真实计入，正常、拒收、invalid均保留response.timing；文件flush在就绪后。CPU只作诊断，不扣除停顿，不替代wall。',
        '', '| 方法/窗口 | n | p50 ms | p95 ms | p99 ms | max ms | >20 ms |','|---|---:|---:|---:|---:|---:|---:|']
    for method,windows in timing.items():
        for window,v in windows.items():lines.append('| '+method+'/'+window+' | '+' | '.join(str(v[k]) if v[k] is not None else 'NA' for k in ('n','p50','p95','p99','maximum','over_20ms'))+' |')
    if locator:
        w=locator['window'];rr=locator['raw'];lines+=['',f"定位记录：{w['context_id']} /{w['method']} /{w['window']} /slot {w['slot']}，wall={w['latency_ms']:.4f} ms；raw={rr.get('path')}，status={rr.get('raw_status')}，assembly={rr.get('assembly_ms')} ms、threadCPU={rr.get('thread_cpu_ms')} ms。全部分项和前后GC计数见MAXIMUM_FAILED_WINDOW_LOCATOR.json。"]
    lines+=['',f"所有已记录assembly：n={assembly['n']}、p50={assembly['p50']} ms、p99={assembly['p99']} ms、max={assembly['maximum']} ms。assembly子块、native solve/prepare/decode等可能嵌套，不相加为总时长。Windows thread CPU零/离散值不等于无CPU成本；GC计数和wall/CPU差不建立GC或OS调度因果归因。",
        'STEP44的37.0346 ms迟到伴随约20.0176 ms assembly和已Solved的QP；旧证据不足以判断GC/调度/分配的原因。本轮两臂比较完整CAL/domain整体，不单独量化γ=0键修复效果，也不能把STEP45相对STEP44差异全部归于装配优化。',
        '', '## 资源、验证与证据','',
        f"唯一数值启动：{budget['numerical_started_utc']}。数值墙钟{budget['numerical_elapsed_s']:.1f}/7200 s；QP {budget['total_QP_calls']}/25000，物理步{budget['total_physics_steps']}/250000；新CAL/fit=0，结果驱动重试=0。8条reference的880 QP/8800步、startup/endpoint/prefix/application/feedback均计入。",
        f"必要pure fixture 11/11通过，追加计时断言1/1通过；没有QP或真实物理推进。唯一当前结果读回={r['readback']['status']}，QP START/RETURN/raw={r['readback']['qp_starts']}/{r['readback']['qp_returns']}/{r['readback']['raw_qp_shards']}，UNKNOWN={r['readback']['unknown_qp']}；观察bank {r['readback']['observed_banks_read_once']}，完整500步/501状态/21checkpoint {r['readback']['complete_grids_verified']}。测试通过不替代S/C科学端点。",
        '保存读回验证属于本轮证据一致性检查，不是独立复现；独立复现状态UNVERIFIED。全部264 planned状态、96决定、raw数值/START/RETURN/attempt、dense轨迹、容量四方配对、contact描述、latency与task表一起交付。',
        '', '## 两图','',f"![图1]({(out/'figures/FIG1_COVERAGE_MIGRATION.png').as_posix()})",'',
        '图1：四个direction×leg的分组计数，无分类折线；48个paired source迁移保留弃权/late/partial/未知，星号为实时合格Type-II。共享snapshot/episode不作IID样本。',
        '',f"![图2]({(out/'figures/FIG2_TIMING_TASK_RESPONSE.png').as_posix()})",'',
        '图2：全部准备/反馈窗口和20 ms线；所有QP的assembly子块分布与最大失败窗口定位；首动作、末绝对误差及积分独立面板。嵌套时间不堆叠，不用缺测0。SciPilot数据剖析、图型选择、8 pt字体、600 dpi PNG、嵌字PDF、灰度与视觉检查保存在figures。',
        '', '## 交付与停止','',
        f"源提交{SOURCE_COMMIT}；工作区{OUTPUT_ROOT_D.as_posix()}；分支codex/step45-cal-key-assembly-confirmation-20261011。源HEAD/index/结果不变检查见SOURCE_PRESERVATION.json。所有新文件、Git对象/index、TMP/cache写D；E依赖只读。未访问机器人运控算法项目，未推送。",
        '本轮达到或未达到端点均结束。未授权STEP46、E3、RL或硬件；不追加实验，不继续精确证书或历史审计。协议全部状态：','', '~~~ini',*[f'{k} = {v}' for k,v in protocol.items()],'~~~','']
    (out/'REPORT.md').write_text('\n'.join(lines),encoding='utf-8',newline='\n')
    next_question='测得范围的更长任务闭环与跨故障/外部扰动独立设计' if primary['C']=='ESTABLISHED_IN_MEASURED_SCOPE' else '由保存的拒收迁移和phase定位确定下一项实质改变；不能删除partial或追加至通过'
    handoff=['# STEP45 研究交接','',f"执行={r['task_execution_status']}；科学={c['status']}；部署=HARD_REALTIME_NOT_VERIFIED。",
        f"FULL S={primary['S']}；C={primary['C']}；RT Type-II={primary['online_type_ii_distribution']['contexts']} source /{primary['online_type_ii_distribution']['snapshots']} snapshot /{primary['online_type_ii_distribution']['episodes']} episode；负向RR={primary['negative_RR_episodes']} episode。",
        'STEP44结论NOT_ESTABLISHED不变；γ=0遗漏公开并只读修复64保存B行。新CAL/TRAIN/fit全部0；γ=.5/predictor/TRAIN/threshold和domain原字节保留。',
        '独立owner/packet/B0与全部planned未运行、late、partial、UNKNOWN如实保留。新TEST标签不回流CAL；任务用途的短时/终端/积分不可合并为单一改善结论。',
        '入口：REPORT.md、STEP45_RESULT.json、PROTOCOL_STATUS.ini、STEP44_SCOPE_NOTE.md、STEP45_METHOD_FREEZE.json、SAVED_CAL_REPAIR_MAPPING.json、CURRENT_RUN_READBACK.json、SAME_SOURCE_METHOD_PAIRS.json、TYPE_II_ONLY.json、LATENCY_ALL_WINDOWS.json、MAXIMUM_FAILED_WINDOW_LOCATOR.json、TASK_RESPONSE_ALL.json、两图及完整raw/attempt ledger。',
        f"下一项研究问题（设计建议，不是执行授权）：{next_question}。",'交付后停止；不自动STEP46/E3/RL/硬件，不重跑历史。','',
        f"worktree={OUTPUT_ROOT_D.as_posix()}",f"source_SHA={SOURCE_COMMIT}",f"run_id={out.name}",f"branch=codex/step45-cal-key-assembly-confirmation-20261011",'']
    (out/'HANDOFF.md').write_text('\n'.join(handoff),encoding='utf-8',newline='\n')
    write(out/'MATERIAL_PASSPORT.json',dict(evidence_integrity=r['readback']['status'],independent_reproduction='UNVERIFIED_NOT_RERUN',
        source_SHA=SOURCE_COMMIT,source_unchanged=hist,numeric_launches=1,new_CAL=0,new_TRAIN=0,new_fits=0,
        CAL_TEST_separation='FROZEN_BEFORE_TEST',scope='FIXED_DETERMINISTIC_24_SNAPSHOTS_8_EPISODES',
        deployment='HARD_REALTIME_NOT_VERIFIED',tests='tests/NECESSARY_TESTS.json',readback='CURRENT_RUN_READBACK.json',
        raw_ledger='STEP45_LEDGER.jsonl',attempt_ledger='ATTEMPT_LEDGER.jsonl',visual_qa='figures/VISUAL_REVIEW.json'))

if __name__=='__main__':main()
