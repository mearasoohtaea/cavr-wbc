"""Only the added normal/late/invalid timing assertions; zero numerical calls."""
from unittest import TextTestRunner,TestSuite
from tests.test_step45_protocol import Necessary
from cavr_wbc.experiments.step45_io import write,output
if __name__=='__main__':
    result=TextTestRunner(verbosity=2).run(TestSuite([Necessary('test_plan_budget_order_and_stream')]))
    write(output()/'tests/TIMING_ASSERTION_EXTENSION.json',dict(tests_run=result.testsRun,
        successful=result.wasSuccessful(),real_QP=0,real_steps=0,scope='normal/late/invalid timing field assertions added to plan/stream fixture'))
    raise SystemExit(0 if result.wasSuccessful() else 1)
