"""One saved-only current-batch readback; no numerical reproduction or screening."""
from collections import Counter
from datetime import datetime, timezone
import gc, json
import numpy as np
from cavr_wbc.experiments.step46_io import output, read, write, load_numeric, sha, relative
from cavr_wbc.experiments.step46_inputs import plans, episodes, arm_context
from cavr_wbc.experiments.step46_storage import load_branch
from cavr_wbc.experiments.step39_delivery import flatten, counts, safe, outcome, csv_save
from cavr_wbc.control.step34_margin import labels
from cavr_wbc.experiments.step29_sim import _json_safe
from cavr_wbc.control.step20_task_reference import reference
from cavr_wbc.control.step46_policy import task_reference, VERSION


def numeric_equal(a, b, atol=1e-12):
    return bool(np.shape(a)==np.shape(b) and np.allclose(a,b,rtol=0,atol=atol,equal_nan=True))


def task_metrics(branch, c):
    dense=([branch['initial_fact']] if branch.get('initial_fact') else [])+branch.get('physics_trajectory',[])
    valid=[f for f in dense if 'qpos' in f and 'subtree_com' in f and not f.get('numerical_failure')]
    series=[]
    if valid:
        q0=float(valid[0]['qpos'][0]);com0=float(valid[0]['subtree_com'][0])
        anchor=float(c['backup_anchor_q_init'][0]);task=float(c['nominal_q_init'][0])+float(c['nominal_d_m'])
        for f in valid:
            t=float(f['time_s']);r=reference(float(c['nominal_q_init'][0]),float(c['nominal_d_m']),c['source_tick']*.02+t)
            limited=task_reference(anchor,task,t)
            series.append(dict(time_s=t,base_x_m=float(f['qpos'][0]),vx_m_s=float(f['qvel'][0]),
                external_reference_m=float(r['p_ref_m']),external_error_m=float(f['qpos'][0]-r['p_ref_m']),
                clipped_reference_m=limited['p_ref_m'],clipped_reference_error_m=float(f['qpos'][0]-limited['p_ref_m']),
                directed_base_displacement_m=float(c['direction']*(f['qpos'][0]-q0)),
                directed_COM_displacement_m=float(c['direction']*(f['subtree_com'][0]-com0))))
    complete=bool(branch.get('status')=='COMPLETE' and len(series)==501 and
        numeric_equal([r['time_s'] for r in series],np.arange(501)*.002,1e-9))
    def observed_at(t):
        return next((r for r in series if abs(r['time_s']-t)<1e-9),None)
    first0,first1=observed_at(.02),observed_at(.04)
    summary=dict(available=bool(series),complete_1s=complete,
        observed_end_time_s=series[-1]['time_s'] if series else None,
        first_action_directed_base_m=None if not first0 or not first1 else first1['directed_base_displacement_m']-first0['directed_base_displacement_m'],
        first_action_directed_COM_m=None if not first0 or not first1 else first1['directed_COM_displacement_m']-first0['directed_COM_displacement_m'],
        terminal_abs_external_error_m=None,abs_external_error_integral_m_s=None,
        terminal_directed_base_m=None,terminal_directed_COM_m=None,terminal_vx_m_s=None,
        terminal_clipped_reference_error_m=None,
        partial_1s_labels_not_imputed=True,metric_scope='ORIGINAL_EXTERNAL_REFERENCE_AT_SOURCE_TICK_TIMES_0.02_PLUS_ACTUAL_TIME')
    if complete:
        err=np.abs([r['external_error_m'] for r in series]);ts=np.asarray([r['time_s'] for r in series]);last=series[-1]
        summary.update(terminal_abs_external_error_m=abs(last['external_error_m']),
            abs_external_error_integral_m_s=float(np.sum((err[1:]+err[:-1])*.5*np.diff(ts))),
            terminal_directed_base_m=last['directed_base_displacement_m'],terminal_directed_COM_m=last['directed_COM_displacement_m'],
            terminal_vx_m_s=last['vx_m_s'],terminal_clipped_reference_error_m=last['clipped_reference_error_m'])
    return summary,series


def capacity_controls(row, branch, c):
    ix=c.get('faulted_actuator_index');result=[]
    for r in branch['controls']:
        cap=r.get('capacity_interface',{}).get('effective_capacity_nm')
        def ratio(name):
            value=r.get(name)
            return None if ix is None or value is None or cap is None else abs(float(value[ix]))/float(cap[ix])
        sent,actual=ratio('tau_sent'),ratio('tau_applied')
        result.append(dict(id=row['id'],context_id=row['context_id'],branch=row['branch'],policy=row['policy'],
            slot=r['slot'],time_s=r['slot']*.02,command_applied=r.get('tau_applied') is not None,
            fault_name=c.get('faulted_actuator_name'),effective_capacity_nm=None if ix is None or cap is None else float(cap[ix]),
            sent_capacity_ratio=sent,actual_capacity_ratio=actual,
            sent_99percent=sent is not None and sent>=.99,actual_99percent=actual is not None and actual>=.99,
            source=r.get('source'),integral_updated=(r.get('integral_record') or {}).get('updated')))
    for column,field in [('sent_99percent','first_sent_99percent_s'),('actual_99percent','first_actual_99percent_s')]:
        hit=[r['time_s'] for r in result if r[column] and r['command_applied']]
        row[field]=min(hit) if hit else None
    failure=row.get('first_dense_failure_s')
    row['sent_and_actual_capacity_precede_failure']=bool(failure is not None and
        all(row[f] is not None and row[f]<failure for f in ('first_sent_99percent_s','first_actual_99percent_s')))
    return result


def control_checks(row, branch, c, packet, issues):
    controls=branch['controls'];checks=[];window=[]
    bid=c['backup_id'];anchor=float(c['backup_anchor_q_init'][0]);goal=float(c['nominal_q_init'][0])+float(c['nominal_d_m'])
    for r in controls:
        slot=int(r['slot']);ref=r.get('backup_reference');applied=r.get('tau_applied') is not None
        check=dict(id=row['id'],slot=slot,actual_physical_time_s=slot*.02,applied=applied,
            backup_reference_available=ref is not None,policy=row['policy'],backup_id=bid,
            expected_reference=None,observed_reference=ref,reference_pass=None)
        # Prehold is not a new backup solve. The first solved B0 is physical .02 s.
        if row['policy']=='TASK' and slot>=1 and applied:
            expected=task_reference(anchor,goal,slot*.02)
            good=bool(ref and ref.get('backup_id')==bid and ref.get('policy_version')==VERSION and
                all(numeric_equal(ref.get(k),expected[k],1e-12) for k in
                    ('p_ref_m','v_ref_m_s','a_ref_m_s2','time_s','x_anchor_m','x_task_m','d_task_m')))
            check.update(reference_pass=good,expected_reference=expected)
            if not good:issues.append(row['id']+f':TASK physical reference slot {slot}')
        checks.append(check)
        if slot>=2:
            ms=r.get('command_ready_ms',r.get('latency_ms'));timing=r.get('timing') or {}
            window.append(dict(id=row['id'],episode=row['episode'],branch=row['branch'],policy=row['policy'],
                kind='FEEDBACK',slot=slot,complete_ms=ms,prepared_ms=timing.get('prepared_command_ms',timing.get('prepared_ms')),
                applied=applied,staging_committed=r.get('staging_committed'),within_20ms=ms is not None and ms<=20.,
                rejected_unapplied=not applied,timing=timing))
            if applied and (ms is None or ms>20 or not r.get('staging_committed')):
                issues.append(row['id']+f':late/uncommitted control applied at {slot}')
        if r.get('governor_selected'):issues.append(row['id']+':false governor approval')
    # Stored committed integral is carried into the first post-application solve.
    if len(controls)>2 and controls[2].get('integral_record'):
        before=controls[2]['integral_record'].get('b_used')
        after=(packet.get('step31_backup_memory') or {}).get('integral_b_after')
        if before is not None and after is not None and not numeric_equal(before,after):
            issues.append(row['id']+':first feedback integral discontinuity')
    if row['complete_501'] and not all(f.get('backup_id')==bid for f in
        [branch['initial_fact']]+branch['physics_trajectory']):issues.append(row['id']+':dense backup identity')
    return checks,window


def ledger_readback(out, finished, issues):
    events=[json.loads(s) for s in (out/'STEP46_LEDGER.jsonl').read_text(encoding='utf-8').splitlines()]
    starts=[e for e in events if e['event']=='QP_START'];returns=[e for e in events if e['event']=='QP_RETURN']
    raw=[e for e in events if e['event']=='RAW_QP_SAVED'];n=finished['budget']['total_QP_calls']
    for label,rows in [('START',starts),('RETURN',returns),('RAW',raw)]:
        indices=[e['global_qp_index'] for e in rows]
        if len(indices)!=len(set(indices)) or set(indices)!=set(range(1,n+1)):issues.append('QP '+label+' identity/count')
    hashes=0
    for e in raw:
        path=out/e['path'];meta=read(path)
        if sha(path)!=e['json_sha256'] or sha(path.with_suffix('.npz'))!=e['npz_sha256'] or meta['numeric_sha256']!=e['npz_sha256']:
            issues.append('raw hash '+e['path'])
        hashes+=1
    if n>20000 or finished['budget']['total_physics_steps']>200000 or finished['budget']['numerical_elapsed_s']>5401:
        issues.append('frozen numerical budget exceeded')
    forbidden=sum(e['event'].endswith('FIT') for e in events)
    if forbidden or finished['budget']['multioutput_estimator_fits'] or finished['budget']['physical_risk_head_fits']:
        issues.append('forbidden fit')
    return dict(QP_starts=len(starts),QP_returns=len(returns),raw_banks_hash_checked=hashes,
        unknown_QP_calls=n-len(returns),call_identity_interval=[1,n],QP_by_kind=dict(Counter(e['kind'] for e in starts)),
        physical_steps=finished['budget']['total_physics_steps'],new_fits=0,governor_calls=0,
        raw_arrays_not_re_solved=True,ledger_sha256=sha(out/'STEP46_LEDGER.jsonl'))


def run():
    out=output();receipt=out/'CURRENT_RUN_READBACK.json'
    if receipt.exists():raise FileExistsError('one current-batch readback already exists; do not repeat bank readback')
    finished=read(out/'RUN_FINISHED.json')
    if not finished:raise ValueError('wait for numerical process and children to exit before readback')
    issues=[];rows=[];packets={};latencies=[];checks=[];capacity=[];reference_rows=[]
    contexts={c['context_id']:c for c in load_numeric(out/'DEV_CONTEXTS.json')}
    attempt=[json.loads(s) for s in (out/'ATTEMPT_LEDGER.jsonl').read_text(encoding='utf-8').splitlines()]
    started={(e['context_id'],e['arm']) for e in attempt if e['event']=='START' and e['kind']=='EXPERIMENT_ARM'}
    returned={(e['context_id'],e['arm']) for e in attempt if e['event']=='RETURN' and e['kind']=='EXPERIMENT_ARM'}
    if len(started)!=sum(e['event']=='START' and e['kind']=='EXPERIMENT_ARM' for e in attempt):issues.append('repeated arm START')
    frozen_packets={(e['context_id'],e['arm']):e['packet_sha256'] for e in attempt if e['event']=='EXPERIMENT_PACKET_FROZEN'}
    for ep in episodes():
        path=out/'episodes'/(ep['episode_id']+'.json');r=load_numeric(path) if path.exists() else {}
        reference_rows.append(dict(**ep,status=r.get('status','NOT_RUN'),counts=r.get('counts'),result_path=relative(path,out),
            snapshots=len(r.get('snapshots',[])),snapshot_ids=[s.get('snapshot_id') for s in r.get('snapshots',[])]))
        if r.get('status')=='COMPLETE' and r.get('counts',{}).get('physics_steps',r.get('counts',{}).get('physical_steps'))!=1100:
            issues.append(ep['episode_id']+':reference integration count')
        del r
    for p in plans():
        for arm in p['arms']:
            directory=out/'DEV'/p['context_id']/arm;path=directory/'RESULT.json';rec=read(path,{})
            row=flatten(p,arm,rec,path,out)
            row.update(direction=p['direction'],displacement_m=p['displacement_m'],severe=p['severe'],
                policy='TASK' if arm.endswith('TASK') else 'HOLD',gamma=.5 if arm.startswith('MIDDLE') else 0.,
                experimental_dispatch=bool(rec.get('experimental_dispatch')),experimental_committed=bool(rec.get('experimental_committed')),
                experimental_applied=bool(rec.get('experimental_applied')),governor_selected=bool(rec.get('governor_selected')),
                learner_approved=bool(rec.get('learner_approved')),backup_id=rec.get('backup_id'),
                attempt_started=(p['context_id'],arm) in started,attempt_returned=(p['context_id'],arm) in returned)
            packet=load_numeric(directory/'PACKET.json') if (directory/'PACKET.json').exists() else {}
            expected_sha=frozen_packets.get((p['context_id'],arm))
            if expected_sha and sha(directory/'PACKET.json')!=expected_sha:issues.append(row['id']+':frozen packet hash')
            c=arm_context(contexts[p['context_id']],arm) if p['context_id'] in contexts else None
            packets[row['id']]=dict(first_reference=(packet.get('B') or {}).get('external_reference'),
                tau_sent=(packet.get('selected_action') or {}).get('tau_sent'),
                tau_raw=(packet.get('selected_action') or {}).get('tau_raw'),backup_id=row['backup_id'],
                arm_instance=packet.get('arm_instance'),solver_owners=packet.get('step37_branch_owners'))
            latencies.append(dict(id=row['id'],episode=row['episode'],branch=arm,policy=row['policy'],kind='PREPARATION',slot=1,
                complete_ms=packet.get('command_ready_ms'),prepared_ms=packet.get('prepared_commit_ms'),
                applied=row['experimental_applied'],staging_committed=row['experimental_committed'],
                within_20ms=packet.get('command_ready_ms') is not None and packet['command_ready_ms']<=20.,
                within_17ms_reserve=packet.get('prepared_commit_ms') is not None and packet['prepared_commit_ms']<=17.,
                rejected_unapplied=not row['experimental_applied'],status=packet.get('status','NOT_RUN')))
            if row['selected_command_sent'] or row['governor_selected'] or row['learner_approved'] or row['model_authorized']:
                issues.append(row['id']+':experimental approval conflated')
            if row['experimental_committed'] and (not latencies[-1]['within_20ms'] or not latencies[-1]['within_17ms_reserve']):
                issues.append(row['id']+':first packet late committed')
            if row['observed']:
                if sha(directory/'actual.npz')!=rec['artifact']['sha256']:issues.append(row['id']+':dense hash')
                if sha(directory/'controls.json')!=rec['controls_numeric']['json_sha256']:issues.append(row['id']+':controls JSON hash')
                branch=load_branch(directory);lab=labels(branch,_json_safe(c))
                for k in ('complete','full_501_grid','original_physical','original_terminal','observed_original_physical_failure'):
                    if lab.get(k)!=rec['label'].get(k):issues.append(row['id']+':label '+k)
                for k in ('D_m','Y'):
                    a,b=lab.get(k),rec['label'].get(k)
                    if (a is None)!=(b is None) or a is not None and not numeric_equal(a,b):issues.append(row['id']+':label '+k)
                if row['complete_501'] and (branch['counts']['physical_steps']!=500 or len(branch['physics_trajectory'])+1!=501 or len(branch['checkpoints'])!=21):
                    issues.append(row['id']+':500/501/21 grid')
                summary,series=task_metrics(branch,c);row.update(summary)
                write(directory/'TASK_RESPONSE.json',dict(summary=summary,series=series))
                capacity.extend(capacity_controls(row,branch,c));a,b=control_checks(row,branch,c,packet,issues)
                checks.extend(a);latencies.extend(b)
                if rec.get('application_identity_pass') is False:
                    issues.append(row['id']+':application prediction mismatch')
                del branch,lab,series
            else:
                row.update(complete_1s=False,terminal_abs_external_error_m=None,abs_external_error_integral_m_s=None,
                    first_action_directed_base_m=None,first_action_directed_COM_m=None,terminal_directed_base_m=None,
                    terminal_directed_COM_m=None,terminal_vx_m_s=None,terminal_clipped_reference_error_m=None)
            row['safe_6mm']=safe(row);row['safe_timely']=bool(row['safe_6mm'] and row['timing_qualified']);row['outcome']=outcome(row)
            rows.append(row);del packet,rec;gc.collect()
            if len(rows)%12==0:
                write(out/'READBACK_PROGRESS.json',dict(branches_read=len(rows),planned=168,phase='SAVED_ONLY_DENSE_AND_CONTROL_READBACK',new_QP=0,new_steps=0))
                print('saved-only readback',len(rows),'/168',flush=True)
    ledger=ledger_readback(out,finished,issues)
    runtime=read(out/'RUNTIME_END.json')
    if not runtime.get('runtime_sha256_unchanged'):issues.append('frozen runtime changed during experiment')
    write(out/'BRANCH_ROWS.json',rows);csv_save(out/'BRANCH_RESULTS.csv',rows)
    write(out/'REFERENCE_STATUS.json',reference_rows);csv_save(out/'REFERENCE_STATUS.csv',reference_rows)
    write(out/'FIRST_PACKET_COMMANDS.json',packets)
    write(out/'REFERENCE_CLOCK_CHECKS.json',checks);csv_save(out/'LATENCY.csv',latencies)
    write(out/'CAPACITY_EVENTS.json',capacity);csv_save(out/'CAPACITY_EVENTS.csv',capacity)
    strata=[]
    for direction in (1,-1):
        for kind in ('HEALTHY','FR_THIGH30','RR_THIGH30','FR_THIGH15','RR_THIGH15'):
            for arm in ('B_HOLD','MIDDLE_HOLD','B_TASK','MIDDLE_TASK'):
                selected=[r for r in rows if r['direction']==direction and r['condition']==kind and r['branch']==arm]
                if selected:strata.append(dict(direction=direction,condition=kind,branch=arm,**counts(selected),
                    dispatched=sum(r['experimental_dispatch'] for r in selected),committed=sum(r['experimental_committed'] for r in selected),
                    applied=sum(r['experimental_applied'] for r in selected),safe_timely=sum(r['safe_timely'] for r in selected),
                    episodes=len({r['episode'] for r in selected}),snapshots=len({r['snapshot_id'] for r in selected})))
    csv_save(out/'SUPPORT_MATRIX.csv',strata);write(out/'SUPPORT_MATRIX.json',strata)
    receipt_value=dict(scope='ONE_CURRENT_STEP46_RUN_ONLY',status='VERIFIED' if not issues else 'INVALID_EVIDENCE',
        numerical_reproduction='UNVERIFIED_NOT_REPEATED_BY_PROTOCOL',issues=issues,counts=counts(rows),
        dispatched=sum(r['experimental_dispatch'] for r in rows),committed=sum(r['experimental_committed'] for r in rows),
        applied=sum(r['experimental_applied'] for r in rows),safe_timely=sum(r['safe_timely'] for r in rows),
        reference_count=len(reference_rows),reference_statuses=dict(Counter(r['status'] for r in reference_rows)),
        TASK_applied_reference_checks=sum(c['reference_pass'] is not None for c in checks),
        attempts_started=len(started),attempts_returned=len(returned),QP_ledger=ledger,
        no_solver_no_integration_no_fit=True,timestamp_utc=datetime.now(timezone.utc).isoformat())
    write(receipt,receipt_value)
    print(json.dumps(receipt_value,ensure_ascii=False))


if __name__=='__main__':run()
