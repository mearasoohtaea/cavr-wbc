"""SciPilot paired raw points and same-source mechanism/latency figures; saved-only."""
from pathlib import Path
import sys, argparse, csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from cavr_wbc.experiments.step46_io import output, read, write
from cavr_wbc.experiments.step46_inputs import plans
SKILL=Path('C:/Users/ZhuanZ（无密码）/.codex/skills/scipilot-figure/scripts')
sys.path.insert(0,str(SKILL))
from setup_style import setup_style
from visual_qa import render_preview, audit_layout
from layout_tools import add_panel_labels
from export_figure import export_figure
from check_figure import check_figure
from profile_data import profile_data

BLUE='#0072B2';ORANGE='#D55E00';GREY='#777777'
SIZE1=(7.16,5.4);SIZE2=(7.16,8.6)

def configure():
    setup_style(journal='ieee',lang='en',use_sciplots=False)
    plt.rcParams.update({'font.size':8,'axes.labelsize':8,'axes.titlesize':9,
        'xtick.labelsize':8,'ytick.labelsize':8,'legend.fontsize':8,'pdf.fonttype':42,
        'figure.constrained_layout.use':False,'axes.unicode_minus':False,'axes.linewidth':.6,
        'savefig.bbox':None})

def pdf_font_details(path):
    # SciPilot's root-only check misses embedded Type0 descendant fonts.
    from pypdf import PdfReader
    records=[]
    for page in PdfReader(path).pages:
        fonts=page['/Resources']['/Font'].get_object()
        for name,obj in fonts.items():
            font=obj.get_object();children=font.get('/DescendantFonts')
            concrete=[c.get_object() for c in children] if children else [font]
            for child in concrete:
                descriptor=child.get('/FontDescriptor')
                descriptor=descriptor.get_object() if descriptor else {}
                records.append(dict(name=str(name),base=str(child.get('/BaseFont')),
                    subtype=str(child.get('/Subtype')),embedded=any(k in descriptor for k in
                        ('/FontFile','/FontFile2','/FontFile3'))))
    if not records or not all(r['embedded'] and r['subtype']!='/Type3' for r in records):
        raise ValueError('figure PDF fonts not embedded')
    return records

def figure1(rows):
    fig,axes=plt.subplots(2,3,figsize=SIZE1,sharex=True)
    fig.subplots_adjust(left=.095,right=.985,bottom=.15,top=.88,hspace=.40,wspace=.44)
    by={r['id']:r for r in rows};spec=[('first_action_directed_COM_m','First-action COM progress (mm)'),
        ('terminal_abs_external_error_m','1 s external task error (mm)'),
        ('abs_external_error_integral_m_s','1 s error integral (mm s)')]
    missing={};scenarios=[p for p in plans() if p['severe']]
    for j,(key,label) in enumerate(spec):
        observed=[]
        for i,prefix in enumerate(('B','MIDDLE')):
            ax=axes[i,j];missing[f'{prefix}:{key}']=0
            for p in scenarios:
                ep=int(p['episode'].rsplit('_',1)[1]);x=ep+(-.20 if p['tick']==37 else .20)+(-.06 if p['fault_leg']=='FR' else .06)
                marker='o' if p['fault_leg']=='FR' else 's'
                pair=[by[p['context_id']+':'+prefix+'_'+policy] for policy in ('HOLD','TASK')]
                values=[r.get(key) for r in pair]
                if all(v is not None for v in values):
                    ax.plot([x-.025,x+.025],[v*1000 for v in values],color='#bbbbbb',lw=.6,zorder=1)
                for off,r,color in zip((-.025,.025),pair,(GREY,BLUE)):
                    v=r.get(key)
                    if v is None:
                        missing[f'{prefix}:{key}']+=1
                        ax.plot(x+off,.015,marker='x',color=GREY,ms=3,transform=ax.get_xaxis_transform(),clip_on=False)
                    else:
                        observed.append(v*1000)
                        ax.scatter(x+off,v*1000,s=13,marker=marker,edgecolors=color,
                            facecolors=color if r['policy']=='TASK' else 'white',linewidths=.6,zorder=3)
                        if not r['safe_timely']:ax.plot(x+off,v*1000,marker='+',color=ORANGE,ms=4,mew=.6,zorder=4)
            ax.set_ylabel(label);ax.set_xlim(-.45,5.45);ax.set_title(f'{prefix}: same-source policy pair',pad=6)
            ax.spines[['top','right']].set_visible(False);ax.grid(axis='y',color='#eeeeee',lw=.5)
            ax.set_xticks(range(6),['E0+','E1-','E2+','E3-','E4+','E5-'])
            if i==1:ax.set_xlabel('Fresh reference episode / direction')
        if observed:
            low=min(0.,min(observed));hi=max(observed);pad=max((hi-low)*.09,.00005)
            for ax in axes[:,j]:ax.set_ylim(low-pad,hi+pad)
    handles=[Line2D([],[],marker='o',color=GREY,ls='',mfc='white',label='HOLD (open)'),
        Line2D([],[],marker='o',color=BLUE,ls='',label='TASK (filled)'),
        Line2D([],[],marker='o',color='black',ls='',mfc='white',label='FR (circle)'),
        Line2D([],[],marker='s',color='black',ls='',mfc='white',label='RR (square)')]
    fig.legend(handles=handles,ncol=4,loc='upper center',bbox_to_anchor=(.52,.98),frameon=False)
    fig.text(.5,.025,'24 severe contexts / 6 episodes. Tick 37 left, 41 right within episode.\nPair segments join the same context only; + = not safe/timely, x = unavailable (not zero).',ha='center',fontsize=8)
    add_panel_labels(fig,axes=axes.flat,style='ieee',fontsize=9,x_offset_pt=-22,y_offset_pt=2)
    return fig,missing

def figure2(rows,capacity_pairs,task_pairs,latency):
    fig=plt.figure(figsize=SIZE2)
    gs=fig.add_gridspec(2,3,height_ratios=[3.25,1.25],left=.15,right=.98,bottom=.13,top=.92,wspace=.45,hspace=.31)
    axes=[fig.add_subplot(gs[0,j]) for j in range(3)]
    prep=fig.add_subplot(gs[1,0]);feedback=fig.add_subplot(gs[1,1:]);allaxes=axes+[prep,feedback]
    scenarios=[p for p in plans() if p['severe']];by={r['id']:r for r in rows}
    for j,policy in enumerate(('HOLD','TASK')):
        ax=axes[j]
        for y,p in enumerate(scenarios):
            r=by[p['context_id']+':B_'+policy]
            values=[r.get('first_sent_99percent_s'),r.get('first_actual_99percent_s'),r.get('first_dense_failure_s')]
            for off,v,marker,color in zip((-.19,0,.19),values,('o','s','x'),(BLUE,GREY,ORANGE)):
                ax.scatter(1.10 if v is None else v,y+off,s=12,marker=marker,color=color,linewidths=.65)
            if values[1] is not None and values[2] is not None:
                ax.plot(values[1:], [y,y],color='#bbbbbb',lw=.6,zorder=0)
        ax.set_xlim(-.04,1.16);ax.set_xticks([0,.5,1,1.1],['0','0.5','1','—'])
        ax.set_xlabel('First observed time (s) / absent —');ax.set_title(f'B_{policy}: capacity / failure',pad=8)
    utility=axes[2]
    for y,p in enumerate(scenarios):
        q=next(q for q in task_pairs if q['context_id']==p['context_id'] and q['gamma']==.5)
        v=q['terminal_error_improvement_m']
        if v is None:utility.plot(.03,y,marker='x',color=GREY,transform=utility.get_yaxis_transform(),ms=4)
        else:utility.scatter(v*1000,y,s=16,marker='o' if p['fault_leg']=='FR' else 's',edgecolors=BLUE,
            facecolors=BLUE if q['both_safe_timely'] else 'white',linewidths=.65)
    utility.axvline(0,color=GREY,lw=.6);utility.axvline(.20,color=ORANGE,ls='--',lw=.7)
    utility.set_xlabel('HOLD − TASK error (mm)');utility.set_title('MIDDLE: task-use benefit',pad=8)
    labels=[p['episode'].replace('T46_DEV_','E')+f"/{p['tick']}/{p['fault_leg']}" for p in scenarios]
    for j,ax in enumerate(axes):
        ax.set_ylim(23.7,-.7);ax.set_yticks(range(24),labels if j==0 else ['']*24)
        ax.spines[['top','right']].set_visible(False);ax.grid(axis='y',color='#eeeeee',lw=.5)
    prep_rows=[r for r in latency if r['kind']=='PREPARATION'];fb_rows=[r for r in latency if r['kind']=='FEEDBACK']
    for key,color,marker in [('complete_ms',BLUE,'o'),('prepared_ms',GREY,'x')]:
        prep.scatter([i for i,r in enumerate(prep_rows) if r[key] is not None],
            [r[key] for r in prep_rows if r[key] is not None],s=7,color=color,marker=marker,linewidths=.5)
    prep.axhline(17,color=GREY,ls=':',lw=.7);prep.axhline(20,color=ORANGE,ls='--',lw=.8)
    prep.set_xlabel('All 168 planned preparations');prep.set_ylabel('Wall-clock latency (ms)');prep.set_title('Prepared / complete windows',pad=7)
    feedback.scatter(range(len(fb_rows)),[r['complete_ms'] for r in fb_rows],s=3,color=BLUE,linewidths=0,rasterized=False)
    feedback.axhline(20,color=ORANGE,ls='--',lw=.8);feedback.set_xlabel(f'All {len(fb_rows)} feedback windows (execution order)')
    feedback.set_ylabel('Complete latency (ms)');feedback.set_title('Accepted and rejected feedback',pad=7)
    for ax in (prep,feedback):
        ax.set_ylim(bottom=0);ax.spines[['top','right']].set_visible(False)
    handles=[Line2D([],[],marker='o',color=BLUE,ls='',label='Sent ≥99%'),Line2D([],[],marker='s',color=GREY,ls='',label='Applied ≥99%'),
        Line2D([],[],marker='x',color=ORANGE,ls='',label='Dense physical failure')]
    fig.legend(handles=handles,ncol=3,loc='upper center',bbox_to_anchor=(.54,.985),frameon=False)
    fig.text(.5,.025,'Same-source rows; absent events are symbolic, not 1.1 s measurements. Filled utility: both safe/timely.\nNo 1 s utility for partials; all control windows retained, including rejected proposals.\nPreparation: circle = complete, x = prepared; dotted 17 ms reserve, dashed 20 ms deadline.',ha='center',fontsize=8)
    add_panel_labels(fig,axes=allaxes,style='ieee',fontsize=9,x_offset_pt=-23,y_offset_pt=2)
    return fig

def run(stage):
    out=output();directory=out/'figures';directory.mkdir(exist_ok=True)
    configure();rows=read(out/'BRANCH_ROWS.json');tasks=read(out/'TASK_PAIRS.json');capacity=read(out/'CAPACITY_FOUR_WAY.json')
    with (out/'LATENCY_COMPLETE.csv').open(encoding='utf-8',newline='') as stream:
        latency=list(csv.DictReader(stream))
    for r in latency:
        for key in ('complete_ms','prepared_ms'):r[key]=None if r[key]=='' else float(r[key])
        # The original timing dictionary retains the exact feedback prepare clock.
        if r['prepared_ms'] is None and r.get('timing'):
            import json
            r['prepared_ms']=json.loads(r['timing']).get('prepared_commit_ms')
    if stage=='preview':
        # CSV summaries only: profiling does not read a raw/dense bank again.
        profile=profile_data(str(out/'BRANCH_RESULTS.csv'),['branch','condition'])
        write(directory/'DATA_PROFILE.json',profile)
    first,missing=figure1(rows);second=figure2(rows,capacity,tasks,latency)
    for name,fig,size in [('fig1_paired_task_response',first,SIZE1),('fig2_capacity_task_latency',second,SIZE2)]:
        if stage=='preview':
            render_preview(fig,str(directory/(name+'_preview.png')),dpi=150)
            export_figure(fig,str(directory/(name+'_preview')),formats=['png'],dpi=150,size_inches=size,tight=False,grayscale_preview=True)
            write(directory/(name+'_layout_qa.json'),dict(issues=audit_layout(fig),size_inches=size,
                min_font_pt=8,paired_individual_points=True,no_significance_tests=True))
        else:
            if read(directory/'VISUAL_REVIEW.json',{}).get('status')!='PASS':raise ValueError('visual review precedes final vector export')
            old_qa=directory/(name+'_file_qa.json')
            if old_qa.exists() and not (directory/(name+'_initial_file_qa.json')).exists():
                write(directory/(name+'_initial_file_qa.json'),read(old_qa))
            paths=export_figure(fig,str(directory/name),formats=['pdf','png'],dpi=600,size_inches=size,tight=False,grayscale_preview=False)
            # The skill's grayscale helper re-saves the color PNG with tight
            # cropping. Convert the exact-sized export instead and retain DPI.
            from PIL import Image
            gray_path=str(directory/(name+'_grayscale.png'))
            with Image.open(str(directory/(name+'.png'))) as exported:
                exported.convert('L').save(gray_path,dpi=(600,600))
            paths.append(gray_path)
            findings={p:check_figure(p,min_dpi=600,target_inches=size) for p in paths}
            write(directory/(name+'_file_qa.json'),findings)
            write(directory/(name+'_font_embedding.json'),dict(status='PASS',
                root_only_skill_warning_resolved_by_descendant_descriptors=True,
                fonts=pdf_font_details(str(directory/(name+'.pdf')))))
        plt.close(fig)
    if stage=='preview':write(directory/'FIGURE_SEMANTICS.json',dict(fig1_unavailable_markers=missing,
        scope='ALL_96_SEVERE_ARM_POSITIONS; ALL_168_PREPARATIONS; ALL_OBSERVED_FEEDBACK',
        healthy_mild_controls_in_full_tables=True,no_mean_bars_no_CI_no_pvalues=True,
        figure1='RAW_SAME_SOURCE_PAIRED_POINTS_BY_GAMMA',figure2='SAME_SOURCE_CAPACITY_TIME_UTILITY_AND_ALL_WINDOWS'))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['preview','export']);run(parser.parse_args().stage)
