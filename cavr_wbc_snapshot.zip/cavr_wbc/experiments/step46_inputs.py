"""Exactly six fresh references and 168 independently preassigned arms."""
from copy import deepcopy
import numpy as np
from cavr_wbc.experiments.step35_sprint import add_previous_identity
ARMS=('B_HOLD','MIDDLE_HOLD','B_TASK','MIDDLE_TASK')
TARGETS=(.061875,-.061875,.063875,-.063875,.065875,-.065875)
KINDS=('HEALTHY','FR_THIGH30','RR_THIGH30','FR_THIGH15','RR_THIGH15')
def episodes():
    return [dict(episode_id=f'T46_DEV_{i}',direction=1 if d>0 else -1,
        displacement_m=d,snapshot_ticks=[37,41]) for i,d in enumerate(TARGETS)]
def plans():
    rows=[]; severe=0
    for ep in episodes():
        for tick in ep['snapshot_ticks']:
            snap=ep['episode_id']+f'_T{tick:03d}'
            for kind in KINDS:
                is_severe=kind.endswith('15')
                rotation=severe%4
                arms=ARMS[rotation:]+ARMS[:rotation] if is_severe else ('B_HOLD','B_TASK')
                cid=snap+'_'+kind
                rows.append(dict(**ep,episode=ep['episode_id'],tick=tick,source_tick=tick,
                    snapshot_id=snap,source_snapshot=snap,context_id=cid,case_id=cid,source_state_id=cid,
                    ordinal=len(rows),severe_ordinal=severe if is_severe else None,
                    health_kind=kind,role='healthy' if kind=='HEALTHY' else 'thigh',
                    fault_leg='NONE' if kind=='HEALTHY' else kind[:2],
                    health=1. if kind=='HEALTHY' else .15 if is_severe else .30,
                    split='DEV',source_split='STEP46_FRESH_DEV',gap_m=.006,
                    arms=list(arms),severe=is_severe,governor_planned=False))
                severe+=int(is_severe)
    return rows
def planned_positions():
    return [dict(id=p['context_id']+':'+arm,context=p['context_id'],arm=arm,
        gamma=.5 if arm.startswith('MIDDLE') else 0.,policy='TASK' if arm.endswith('TASK') else 'HOLD')
        for p in plans() for arm in p['arms']]
def context_for(p,episode,mapping):
    snap=next((s for s in episode['snapshots'] if s['source_tick']==p['tick']),None)
    c=deepcopy(snap or {'eligible':False,'eligibility_reason':'REFERENCE_OR_SNAPSHOT_UNAVAILABLE'})
    c.update(deepcopy(p),backup_id='STEP46-'+p['context_id'],runtime_id=p['context_id'],
        group='STEP46_FIXED_DEV',original_direction=p['direction'],
        front_or_rear='NONE' if p['role']=='healthy' else 'front' if p['fault_leg']=='FR' else 'rear')
    h=np.ones(len(mapping));name='NONE';ix=None
    if p['role']!='healthy':
        name=p['fault_leg']+'_thigh';ix=next(r['actuator_index'] for r in mapping if r['actuator_name']==name);h[ix]=p['health']
    c.update(health_vector=h,faulted_actuator_name=name,faulted_actuator_index=ix,
        faulted_health=p['health'],health_effective_from_sample_s=0.,plant_QP_feedback_health_identical=True)
    if snap and episode['status']=='COMPLETE':
        add_previous_identity(c,episode)
        c['previous_command_identity']['source']='NEW_STEP46_REFERENCE_CANDIDATE'
    else:
        c['eligible']=False;c['previous_command_identity']={'available':False,'reason':'REFERENCE_NOT_COMPLETE'}
    return c
def arm_context(c,arm):
    result=deepcopy(c)
    result['backup_id']=c['backup_id']+':'+arm
    result['experimental_arm']=arm
    return result
