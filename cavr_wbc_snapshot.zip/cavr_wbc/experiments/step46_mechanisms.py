"""Three separate frozen development endpoints, computed from current saved rows."""
from collections import Counter
import csv, json
import numpy as np
from cavr_wbc.experiments.step46_io import output, read, write
from cavr_wbc.experiments.step46_inputs import plans
from cavr_wbc.experiments.step39_delivery import safe, csv_save

METRICS=('first_action_directed_base_m','first_action_directed_COM_m',
    'terminal_abs_external_error_m','abs_external_error_integral_m_s',
    'terminal_directed_base_m','terminal_directed_COM_m','terminal_vx_m_s')

def difference(left,right,key):
    a,b=left.get(key),right.get(key)
    return None if a is None or b is None else float(a-b)

def identity(p):
    return {k:p[k] for k in ('context_id','snapshot_id','episode','direction','displacement_m','fault_leg','health_kind','tick')}

def pair_values(p,left,right):
    return dict(**identity(p),left_id=left['id'],right_id=right['id'],
        left_status=left['status'],right_status=right['status'],left_outcome=left['outcome'],right_outcome=right['outcome'],
        complete_pair=left['complete_501'] and right['complete_501'],
        both_safe_timely=left['safe_timely'] and right['safe_timely'],
        left_metrics={k:left.get(k) for k in METRICS},right_metrics={k:right.get(k) for k in METRICS},
        first_base_gain_m=difference(left,right,'first_action_directed_base_m'),
        first_COM_gain_m=difference(left,right,'first_action_directed_COM_m'),
        terminal_error_improvement_m=difference(right,left,'terminal_abs_external_error_m'),
        integral_improvement_m_s=difference(right,left,'abs_external_error_integral_m_s'),
        directed_terminal_base_gain_m=difference(left,right,'terminal_directed_base_m'),
        directed_terminal_COM_gain_m=difference(left,right,'terminal_directed_COM_m'))

def support(rows):
    return dict(contexts=len(rows),physical_snapshots=len({p['snapshot_id'] for p in rows}),
        independent_reference_episodes=len({p['episode'] for p in rows}),ids=[p['context_id'] for p in rows])

def distribution(pairs):
    result=dict(planned_pairs=len(pairs),complete_pairs=sum(p['complete_pair'] for p in pairs),
        both_safe_timely=sum(p['both_safe_timely'] for p in pairs),missing_1s_pairs=sum(p['terminal_error_improvement_m'] is None for p in pairs))
    for key in ('terminal_error_improvement_m','integral_improvement_m_s','first_base_gain_m','first_COM_gain_m'):
        values=[p[key] for p in pairs if p[key] is not None]
        result[key]=dict(available=len(values),improved=sum(v>0 for v in values),worsened=sum(v<0 for v in values),
            equal=sum(v==0 for v in values),min=min(values) if values else None,max=max(values) if values else None)
    result['episode_consistency']=[]
    for episode in sorted({p['episode'] for p in pairs}):
        own=[p for p in pairs if p['episode']==episode];vals=[p['terminal_error_improvement_m'] for p in own if p['terminal_error_improvement_m'] is not None]
        result['episode_consistency'].append(dict(episode=episode,planned_pairs=len(own),available=len(vals),
            all_observed_terminal_improved=bool(vals and all(v>0 for v in vals)),
            all_planned_terminal_improved=bool(len(vals)==len(own) and vals and all(v>0 for v in vals))))
    return result

def type_ii(healthy,mild,failed,middle):
    full=all(r['complete_501'] for r in (healthy,mild,failed,middle))
    physical_failure=bool(failed['complete_501'] and failed['physical_pass'] is False)
    temporal=bool(failed.get('sent_and_actual_capacity_precede_failure'))
    qualified=bool(full and safe(healthy) and safe(mild) and physical_failure and temporal and safe(middle))
    timely=qualified and all(r['timing_qualified'] for r in (healthy,mild,failed,middle))
    return dict(complete_four_way=full,healthy_safe=safe(healthy),mild_safe=safe(mild),
        severe_B_complete_physical_failure=physical_failure,sent_and_actual_capacity_precede_failure=temporal,
        first_sent_99percent_s=failed.get('first_sent_99percent_s'),first_actual_99percent_s=failed.get('first_actual_99percent_s'),
        first_dense_failure_s=failed.get('first_dense_failure_s'),first_failure_reasons=failed.get('first_dense_failure_reasons'),
        MIDDLE_safe=safe(middle),physical_type_ii=qualified,timing_qualified_type_ii=bool(timely),
        required_ids=[r['id'] for r in (healthy,mild,failed,middle)])

def run():
    out=output()
    if (out/'STEP46_RESULT.json').exists():raise FileExistsError('endpoint aggregation already saved')
    rows=read(out/'BRANCH_ROWS.json');by={r['id']:r for r in rows};P=[];F=[];R=[];factorial=[]
    for p in plans():
        cid=p['context_id'];own={arm:by[cid+':'+arm] for arm in p['arms']}
        for gamma,prefix in ((0.,'B'),(.5,'MIDDLE')):
            if prefix+'_TASK' not in own:continue
            item=pair_values(p,own[prefix+'_TASK'],own[prefix+'_HOLD'])
            item.update(comparison='TASK_MINUS_HOLD_SAME_GAMMA',gamma=gamma,severe=p['severe'])
            item['task_use_target_met']=bool(item['both_safe_timely'] and item['terminal_error_improvement_m'] is not None and
                item['terminal_error_improvement_m']>=.0002 and item['integral_improvement_m_s'] is not None and item['integral_improvement_m_s']>=0)
            P.append(item)
        if not p['severe']:continue
        for policy in ('HOLD','TASK'):
            F.append(dict(**pair_values(p,own['MIDDLE_'+policy],own['B_'+policy]),
                policy=policy,comparison='MIDDLE_MINUS_B_WITHIN_SAME_POLICY'))
            H=by[p['snapshot_id']+'_HEALTHY:B_'+policy]
            L=by[p['snapshot_id']+'_'+p['fault_leg']+'_THIGH30:B_'+policy]
            B,M=own['B_'+policy],own['MIDDLE_'+policy]
            R.append(dict(**identity(p),policy=policy,**type_ii(H,L,B,M),
                backup_only_rescue=bool(policy=='TASK' and H['safe_timely'] and L['safe_timely'] and B['safe_timely']),
                MIDDLE_safe_timely=M['safe_timely'],B_safe_timely=B['safe_timely']))
        pb=next(q for q in P if q['context_id']==cid and q['gamma']==0.)
        pm=next(q for q in P if q['context_id']==cid and q['gamma']==.5)
        factorial.append(dict(**identity(p),complete_four_arm=all(r['complete_501'] for r in own.values()),
            endpoint_difference_of_TASK_benefit_MIDDLE_minus_B_m=None if pb['terminal_error_improvement_m'] is None or pm['terminal_error_improvement_m'] is None else pm['terminal_error_improvement_m']-pb['terminal_error_improvement_m'],
            integral_difference_of_TASK_benefit_MIDDLE_minus_B_m_s=None if pb['integral_improvement_m_s'] is None or pm['integral_improvement_m_s'] is None else pm['integral_improvement_m_s']-pb['integral_improvement_m_s'],
            first_base_difference_of_TASK_benefit_MIDDLE_minus_B_m=None if pb['first_base_gain_m'] is None or pm['first_base_gain_m'] is None else pm['first_base_gain_m']-pb['first_base_gain_m']))
    negative=[p for p in P if p['direction']==-1 and p['health_kind']=='RR_THIGH15' and p['gamma']==.5]
    eligible=[p for p in negative if p['task_use_target_met']];P_support=support(eligible)
    P_status='ESTABLISHED_LOCAL_DEV' if P_support['physical_snapshots']>=3 and P_support['independent_reference_episodes']>=2 else 'NOT_ESTABLISHED'
    coexist=[]
    for q in negative:
        hold=next(r for r in R if r['context_id']==q['context_id'] and r['policy']=='HOLD')
        task=next(r for r in R if r['context_id']==q['context_id'] and r['policy']=='TASK')
        coexist.append(dict(**identity(q),task_use_target_met=q['task_use_target_met'],
            HOLD_timing_qualified_type_ii=hold['timing_qualified_type_ii'],MIDDLE_TASK_safe_timely=task['MIDDLE_safe_timely'],
            TASK_policy_type_ii=task['timing_qualified_type_ii'],BACKUP_ONLY_RESCUE=task['backup_only_rescue'],
            coexistence_qualified=bool(q['task_use_target_met'] and hold['timing_qualified_type_ii'] and task['MIDDLE_safe_timely'])))
    R_support=support([r for r in coexist if r['coexistence_qualified']])
    R_status='ESTABLISHED_LOCAL_DEV' if R_support['physical_snapshots']>=3 and R_support['independent_reference_episodes']>=2 else 'NOT_ESTABLISHED'
    stratified=[]
    for direction in (1,-1):
        for leg in ('FR','RR'):
            for gamma in (0.,.5):
                selected=[p for p in P if p['severe'] and p['direction']==direction and p['fault_leg']==leg and p['gamma']==gamma]
                stratified.append(dict(direction=direction,fault_leg=leg,gamma=gamma,**distribution(selected)))
    readback=read(out/'CURRENT_RUN_READBACK.json');finished=read(out/'RUN_FINISHED.json')
    integrity='INVALID' if readback['issues'] else 'FIXED_LIST_COMPLETED_WITH_ORDINARY_FAILURES' if finished['status']=='COMPLETED' else 'INCOMPLETE'
    write(out/'TASK_PAIRS.json',P);csv_save(out/'TASK_PAIRS.csv',P)
    write(out/'CAPACITY_FOUR_WAY.json',R);csv_save(out/'CAPACITY_FOUR_WAY.csv',R)
    write(out/'FIRST_ACTION_PAIRS.json',F);csv_save(out/'FIRST_ACTION_PAIRS.csv',F)
    write(out/'FACTORIAL_DIFFERENCES.json',factorial);csv_save(out/'FACTORIAL_DIFFERENCES.csv',factorial)
    # Metadata-only completion of the feedback reserve column; no bank re-read.
    with (out/'LATENCY_COMPLETE.csv').open(encoding='utf-8',newline='') as stream: windows=list(csv.DictReader(stream))
    for w in windows:
        if w['prepared_ms']=='':w['prepared_ms']=(json.loads(w['timing']) if w.get('timing') else {}).get('prepared_commit_ms')
        else:w['prepared_ms']=float(w['prepared_ms'])
        w['complete_ms']=None if w['complete_ms']=='' else float(w['complete_ms'])
        w['within_17ms_reserve']=w['prepared_ms'] is not None and w['prepared_ms']<=17
    csv_save(out/'LATENCY_WINDOWS.csv',windows)
    write(out/'LATENCY_SUMMARY.json',dict(planned_preparations=168,observed_preparations=sum(w['kind']=='PREPARATION' and w['complete_ms'] is not None for w in windows),
        feedback_windows=sum(w['kind']=='FEEDBACK' for w in windows),
        full_20ms_overruns=sum(w['complete_ms'] is not None and w['complete_ms']>20 for w in windows),
        reserve_17ms_overruns=sum(w['prepared_ms'] is not None and w['prepared_ms']>17 for w in windows),
        late_windows_applied=sum(w['applied']=='True' and ((w['complete_ms'] is not None and w['complete_ms']>20) or (w['prepared_ms'] is not None and w['prepared_ms']>17)) for w in windows),
        exact_prepared_field_source='retained timing.prepared_commit_ms; metadata-only column normalization'))
    command_pairs=[];packets=read(out/'FIRST_PACKET_COMMANDS.json')
    for q in P:
        task,hold=packets[q['left_id']],packets[q['right_id']]
        a,b=task.get('first_reference'),hold.get('first_reference')
        equal=bool(a and b and all(np.allclose(a.get(k),b.get(k),rtol=0,atol=1e-12) for k in ('p_ref_m','v_ref_m_s','a_ref_m_s2')))
        tau_a,tau_b=task.get('tau_sent'),hold.get('tau_sent')
        command_pairs.append(dict(**identity(q),gamma=q['gamma'],slot0_targets_p_v_a_equal=equal,
            target_comparison_available=bool(a and b),TASK_reference=a,HOLD_reference=b,
            command_comparison_available=tau_a is not None and tau_b is not None,
            max_abs_first_tau_sent_difference_nm=None if tau_a is None or tau_b is None else float(np.max(np.abs(np.asarray(tau_a)-np.asarray(tau_b)))),
            separate_backup_id=task.get('backup_id')!=hold.get('backup_id'),
            object_instance_ids_may_be_reused_after_owner_destruction=True))
    write(out/'FIRST_TARGET_COMMAND_PAIRS.json',command_pairs);csv_save(out/'FIRST_TARGET_COMMAND_PAIRS.csv',command_pairs)
    write(out/'NEGATIVE_RR_PRIMARY_ENDPOINT.json',dict(P_pairs=negative,R_coexistence=coexist,
        planned_MIDDLE_positions=[r for r in rows if r['condition']=='RR_THIGH15' and r['direction']==-1 and r['gamma']==.5]))
    result=dict(run_id=finished['run_id'],development_experiment_integrity=integrity,
        current_run_readback_status=readback['status'],counts=readback['counts'],dispatched=readback['dispatched'],
        committed=readback['committed'],applied=readback['applied'],safe_timely=readback['safe_timely'],
        references=readback['reference_statuses'],budget=finished['budget'],
        P_TASK_USE=dict(status=P_status,negative_RR_MIDDLE=distribution(negative),qualified_support=P_support,
            engineering_target_m=.0002,integral_not_increased=True,all_severe_strata=stratified),
        R_CAPACITY_TASK_COEXISTENCE=dict(status=R_status,qualified_support=R_support,
            HOLD_timing_type_ii_support=support([r for r in R if r['policy']=='HOLD' and r['timing_qualified_type_ii']]),
            TASK_timing_type_ii_support=support([r for r in R if r['policy']=='TASK' and r['timing_qualified_type_ii']]),
            BACKUP_ONLY_RESCUE_support=support([r for r in R if r['backup_only_rescue']])),
        F_FIRST_ACTION_CONTRIBUTION=dict(status='MEASURED_COMPONENTWISE',
            HOLD=distribution([p for p in F if p['policy']=='HOLD']),TASK=distribution([p for p in F if p['policy']=='TASK']),
            no_preassumed_terminal_advantage=True),
        old_CAL_certifies_new_policy=False,learned_governor_decisions=0,new_CAL=0,new_TRAIN=0,new_fits=0,
        full_task_completion_established=False,hard_realtime_deployment_established=False,
        branch_policy_development_only=True,numerical_reproduction='UNVERIFIED_NOT_REPEATED',
        pseudo_independent_arm_health_tick_replicates=False,E3_authorized=False,RL_hardware_authorized=False)
    if integrity=='INVALID':result['P_TASK_USE']['status']=result['R_CAPACITY_TASK_COEXISTENCE']['status']='INVALID_EVIDENCE'
    write(out/'STEP46_RESULT.json',result)
    print(result['development_experiment_integrity'],result['P_TASK_USE']['status'],result['R_CAPACITY_TASK_COEXISTENCE']['status'])

if __name__=='__main__':run()
