"""Recover only derived metadata after CSV serialization failed; never re-read banks."""
from collections import Counter
from datetime import datetime,timezone
import json
from cavr_wbc.experiments.step46_io import output,read,write,encode,sha
from cavr_wbc.experiments.step46_inputs import plans
from cavr_wbc.experiments.step39_delivery import counts,csv_save

def run():
    out=output()
    if (out/'CURRENT_RUN_READBACK.json').exists():raise FileExistsError('metadata receipt already complete')
    rows=read(out/'BRANCH_ROWS.json');checks=read(out/'REFERENCE_CLOCK_CHECKS.json')
    finished=read(out/'RUN_FINISHED.json');refs=read(out/'REFERENCE_STATUS.json')
    issues=[r['id']+':reference clock' for r in checks if r['reference_pass'] is False]
    windows=[];capacity=[]
    for r in rows:
        directory=out/'DEV'/r['context_id']/r['branch'];rec=read(directory/'RESULT.json')
        packet_header=read(directory/'PACKET.json',{}).get('record',{})
        windows.append(dict(id=r['id'],episode=r['episode'],branch=r['branch'],policy=r['policy'],kind='PREPARATION',slot=1,
            complete_ms=packet_header.get('command_ready_ms'),prepared_ms=packet_header.get('prepared_commit_ms'),
            applied=r['experimental_applied'],staging_committed=r['experimental_committed'],status=packet_header.get('status','NOT_RUN'),
            within_20ms=packet_header.get('command_ready_ms') is not None and packet_header['command_ready_ms']<=20,
            within_17ms_reserve=packet_header.get('prepared_commit_ms') is not None and packet_header['prepared_commit_ms']<=17))
        # Read scalar JSON indexes only, not controls NPZ or any dense/raw bank.
        controls=read(directory/'controls.json',{}).get('record',{}).get('controls',[])
        for control in controls:
            slot=control['slot'];timing=control.get('timing') or {}
            if slot>=2:
                ms=control.get('command_ready_ms',control.get('latency_ms'));prepared=timing.get('prepared_commit_ms')
                applied=control.get('tau_applied') is not None
                windows.append(dict(id=r['id'],episode=r['episode'],branch=r['branch'],policy=r['policy'],kind='FEEDBACK',slot=slot,
                    complete_ms=ms,prepared_ms=prepared,applied=applied,staging_committed=control.get('staging_committed'),
                    within_20ms=ms is not None and ms<=20,within_17ms_reserve=prepared is not None and prepared<=17,
                    rejected_unapplied=not applied,timing=timing))
                if applied and (ms is None or ms>20 or prepared is None or prepared>17):issues.append(r['id']+':late feedback applied')
        cap=rec.get('capacity') or {}
        # Initial pass retained exact actual ratios. Add independently serialized sent flags.
        fault=cap.get('fault_index')
        for control,value in zip(controls,cap.get('control_series',[])):
            interface=control.get('capacity_interface') or {};active=interface.get('sent_99_percent_active_indices',[])
            if isinstance(active,dict):
                # Array payload was already read once; its size is not a channel identity.
                # Fault-specific sent ratios were preserved by the initial pass in BRANCH_ROWS.
                sent_flag=None
            else:sent_flag=fault is not None and fault in active
            capacity.append(dict(id=r['id'],context_id=r['context_id'],branch=r['branch'],policy=r['policy'],
                fault_name=cap.get('fault_name'),fault_index=fault,**value,
                sent_99percent_json_flag=sent_flag,first_sent_99percent_s=r.get('first_sent_99percent_s'),
                first_actual_99percent_s=r.get('first_actual_99percent_s'),
                sent_and_actual_capacity_precede_failure=r.get('sent_and_actual_capacity_precede_failure'),
                complete_sent_arrays_retained_in_original_controls_shard=True))
        if rec.get('application_identity_pass') is False:issues.append(r['id']+':application mismatch')
        if r['governor_selected'] or r['learner_approved'] or r['selected_command_sent']:issues.append(r['id']+':approval conflation')
    csv_save(out/'LATENCY_COMPLETE.csv',windows);write(out/'CAPACITY_EVENTS.json',capacity);csv_save(out/'CAPACITY_EVENTS.csv',capacity)
    strata=[]
    for direction in (1,-1):
        for condition in ('HEALTHY','FR_THIGH30','RR_THIGH30','FR_THIGH15','RR_THIGH15'):
            for branch in ('B_HOLD','MIDDLE_HOLD','B_TASK','MIDDLE_TASK'):
                group=[r for r in rows if r['direction']==direction and r['condition']==condition and r['branch']==branch]
                if group:strata.append(dict(direction=direction,condition=condition,branch=branch,**counts(group),
                    dispatched=sum(r['experimental_dispatch'] for r in group),committed=sum(r['experimental_committed'] for r in group),
                    applied=sum(r['experimental_applied'] for r in group),safe_timely=sum(r['safe_timely'] for r in group),
                    episodes=len({r['episode'] for r in group}),snapshots=len({r['snapshot_id'] for r in group})))
    csv_save(out/'SUPPORT_MATRIX.csv',strata);write(out/'SUPPORT_MATRIX.json',strata)
    ledger=[json.loads(s) for s in (out/'STEP46_LEDGER.jsonl').read_text(encoding='utf-8').splitlines()]
    starts=[r for r in ledger if r['event']=='QP_START'];returns=[r for r in ledger if r['event']=='QP_RETURN']
    raw=[r for r in ledger if r['event']=='RAW_QP_SAVED'];n=finished['budget']['total_QP_calls']
    for kind,group in [('START',starts),('RETURN',returns),('RAW_SAVED',raw)]:
        if len(group)!=n or {r['global_qp_index'] for r in group}!=set(range(1,n+1)):issues.append('ledger '+kind+' identity')
    attempt=[json.loads(s) for s in (out/'ATTEMPT_LEDGER.jsonl').read_text(encoding='utf-8').splitlines()]
    A=[r for r in attempt if r['event']=='START' and r['kind']=='EXPERIMENT_ARM'];B=[r for r in attempt if r['event']=='RETURN' and r['kind']=='EXPERIMENT_ARM']
    recovery=dict(reason='LATENCY_CSV_NESTED_NUMPY_SERIALIZATION',original_error_log='READBACK_CONSOLE.log',
        numerical_run_unchanged=True,dense_or_raw_banks_read_again=0,new_QP=0,new_physics_steps=0,
        completed_first_pass_rows=168,first_pass_binary_hash_and_dense_relabel_comparisons='EXECUTED_BUT_SUMMARY_NOT_PERSISTED',
        no_claim_of_persisted_full_binary_hash_pass=True,
        metadata_ledger_clock_and_dispatch_checks='PASS' if not issues else 'FAIL',timestamp_utc=datetime.now(timezone.utc).isoformat())
    write(out/'READBACK_METADATA_RECOVERY.json',recovery)
    receipt=dict(scope='ONE_CURRENT_STEP46_BANK_READBACK_PLUS_METADATA_ONLY_EXPORT_REPAIR',
        status='VERIFIED_METADATA_CLOCK_DISPATCH;BINARY_RELABEL_VERDICT_UNRECORDED' if not issues else 'INVALID_METADATA_EVIDENCE;BINARY_RELABEL_VERDICT_UNRECORDED',issues=issues,
        binary_relabel_verdict='UNRECORDED: the first-pass issue list was not persisted; no claim that comparisons passed',
        numerical_reproduction='UNVERIFIED_NOT_REPEATED_BY_PROTOCOL',counts=counts(rows),
        dispatched=sum(r['experimental_dispatch'] for r in rows),committed=sum(r['experimental_committed'] for r in rows),
        applied=sum(r['experimental_applied'] for r in rows),safe_timely=sum(r['safe_timely'] for r in rows),
        reference_count=len(refs),reference_statuses=dict(Counter(r['status'] for r in refs)),
        TASK_applied_reference_checks=sum(c['reference_pass'] is not None for c in checks),
        attempts_started=len(A),attempts_returned=len(B),
        QP_ledger=dict(QP_starts=len(starts),QP_returns=len(returns),raw_evidence_saved=len(raw),
            unknown_QP_calls=n-len(returns),call_identity_interval=[1,n],
            binary_hash_comparison_summary='UNRECORDED_AFTER_DERIVED_EXPORT_ERROR',
            QP_by_kind=dict(Counter(r['kind'] for r in starts)),physical_steps=finished['budget']['total_physics_steps'],
            ledger_sha256=sha(out/'STEP46_LEDGER.jsonl'),new_fits=0,governor_calls=0),
        no_solver_no_integration_no_fit=True,metadata_export_repaired_without_bank_replay=True,
        timestamp_utc=datetime.now(timezone.utc).isoformat())
    write(out/'CURRENT_RUN_READBACK.json',receipt)
    print(json.dumps(receipt,ensure_ascii=False))

if __name__=='__main__':run()
