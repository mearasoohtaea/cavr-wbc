"""Exactly one D/import/write check; source configuration copied without solves."""
from copy import deepcopy
import os,shutil
from cavr_wbc.experiments.step46_io import *
from cavr_wbc.experiments.step46_inputs import *
from cavr_wbc.control.step46_policy import VERSION
SOURCE_RESULT_DIR=SOURCE_ROOT_D/'artifacts/step45_cal_key_confirmation_20261011/step45-cal-key-assembly-confirmation-20261011-01'
def prepare():
    out=output();out.mkdir(parents=True,exist_ok=True)
    if (out/'PREPARATION.json').exists():raise FileExistsError('environment check already performed')
    import cavr_wbc,mujoco,osqp,scipy
    if not Path(cavr_wbc.__file__).resolve().is_relative_to(OUTPUT_ROOT_D):raise ValueError('wrong package')
    write(out/'PREPARATION.json',dict(D_free_bytes_before=shutil.disk_usage(OUTPUT_ROOT_D).free,
        package=cavr_wbc.__file__,TMP=os.environ['TMP'],TEMP=os.environ['TEMP'],
        D_write_marker=True,new_QP=0,new_physics=0,versions=dict(mujoco=mujoco.__version__,osqp=osqp.__version__,numpy=np.__version__,scipy=scipy.__version__)))
    source=read(SOURCE_RESULT_DIR/'PROTOCOL_AND_MANIFEST.json')
    fields=('scenario','reference_scenario','actual_local_bound_m','deadline_ms','horizon_s','physics_dt_s',
        'candidate_eps','reference_eps','first_B_limit_s','first_C_limit_s','feedback_limit_s','friction_upper_N',
        'torque_inset_Nm','original_inequality_extra_slack','frozen_physical','mapping')
    write(out/'SOURCE_FROZEN_CONFIG.json',{k:deepcopy(source[k]) for k in fields})
    (OUTPUT_ROOT_D/'configs/STEP46_EXECUTION_PROTOCOL.md').write_bytes(PROTOCOL.read_bytes())
    write(out/'INPUTS_PLAN.json',dict(episodes=episodes(),contexts=plans(),positions=planned_positions(),
        governor_calls=0,new_CAL=0,new_TRAIN=0,new_fits=0,reference_episodes=6,physical_snapshots=12))
    print(dict(prepared=True,planned=168,reference_episodes=6,QP=0,physics=0),flush=True)
if __name__=='__main__':prepare()
