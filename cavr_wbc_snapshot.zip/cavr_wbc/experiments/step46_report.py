"""Chinese development handoff, from saved-only readback and endpoint tables."""
from cavr_wbc.experiments.step46_io import output, read, write, OUTPUT_ROOT_D, SOURCE_COMMIT

def fmt(value,scale=1.,precision=3):
    return '缺测' if value is None else f'{value*scale:.{precision}f}'

def run():
    out=output();result=read(out/'STEP46_RESULT.json');check=read(out/'CURRENT_RUN_READBACK.json')
    P=result['P_TASK_USE'];R=result['R_CAPACITY_TASK_COEXISTENCE'];F=result['F_FIRST_ACTION_CONTRIBUTION']
    primary=read(out/'NEGATIVE_RR_PRIMARY_ENDPOINT.json');source=read(out/'SOURCE_PRESERVATION.json',{})
    c=result['counts'];budget=result['budget'];test=read(out/'tests/NECESSARY_TESTS.json')
    status=dict(AUTHORIZE_STEP46_TASK_AWARE_BACKUP_DEVELOPMENT_PILOT='TRUE',
        SOURCE_STEP45_RESULT_UNCHANGED='TRUE' if source.get('unchanged') else 'UNVERIFIED',
        SOURCE_STEP45_SCOPE='NEGATIVE_RR_CAPACITY_ONLINE_CLOSURE',STEP46_BACKUP_POLICY='TASK_AWARE_1MM_06S_V1',
        STEP46_TASK_SHIFT_CAP_M='0.001',STEP46_RAMP_DURATION_S='0.60',STEP46_RAMP_PHYSICAL_START_S='0.02',
        STEP46_REFERENCE_EPISODES='6',STEP46_PHYSICAL_SNAPSHOTS='12',STEP46_SEVERE_CONTEXTS='24',
        STEP46_DIRECT_BRANCHES_PLANNED='168',STEP46_LEARNED_GOVERNOR_DECISIONS='0',STEP46_NEW_CAL='0',
        STEP46_NEW_TRAIN='0',STEP46_NEW_FITS='0',STEP46_COMPLETE_WALL_DEADLINE_MS='20',
        STEP46_TERMINAL_ANCHOR_CHANGED='FALSE',STEP46_P_TASK_USE=P['status'],
        STEP46_R_CAPACITY_TASK_COEXISTENCE=R['status'],STEP46_F_FIRST_ACTION_CONTRIBUTION=F['status'],
        STEP46_DEVELOPMENT_EXPERIMENT_INTEGRITY=result['development_experiment_integrity'],
        STEP46_CURRENT_RUN_READBACK=check['status'],STEP46_OLD_CAL_CERTIFIES_NEW_POLICY='FALSE',
        FULL_TASK_COMPLETION_ESTABLISHED='FALSE',HARD_REALTIME_DEPLOYMENT_ESTABLISHED='FALSE',
        HISTORICAL_RESULTS_UNCHANGED='TRUE' if source.get('unchanged') else 'UNVERIFIED',E3_AUTHORIZED='FALSE',RL_HARDWARE_AUTHORIZED='FALSE')
    (out/'PROTOCOL_STATUS.ini').write_text('\n'.join(k+' = '+v for k,v in status.items())+'\n',encoding='utf-8')
    ps=P['qualified_support'];rs=R['qualified_support']
    lines=['# STEP46 受限任务感知 backup：固定开发批次', '',
        f"开发实验完整性：**{result['development_experiment_integrity']}**。P：**{P['status']}**；R：**{R['status']}**；F：**{F['status']}**。",
        f"固定列表保存 {c['result_records']}/168 条，完整 1 s {c['complete_501']}/168 条，完整安全且全部窗口及时 {result['safe_timely']}/168 条。",
        f"负向 RR 主对照达到预冻结用途目标：{ps['contexts']}/6 对，覆盖 {ps['physical_snapshots']} 个 snapshot / {ps['independent_reference_episodes']} 个独立 reference episode。容量恢复与任务用途共存：{rs['contexts']}/6 个同源 context。",'',
        '## 固定设计与完整分母','',
        f"工作树：`{OUTPUT_ROOT_D.as_posix()}`；分支：`codex/step46-task-aware-backup-pilot-20261011`。源提交 `{SOURCE_COMMIT}`。实际运行日期 2026-10-12 韩国时间，目录和协议名保留 20261011。",
        'TASK 只把 backup 的 base-x 参考从原故障采样 anchor 向已知外部任务目标移动最多 1 mm；物理 .02 s 起、.60 s quintic ramp，.62 s 后恒定。原六轴 PID、容量限幅、99% 积分冻结、求解器、native 子预算和独立物理评价器均沿用源配置。terminal 仍相对原 anchor，2 mm / 1 mm/s，local 6 mm。',
        '6 条 fresh reference（±61.875、±63.875、±65.875 mm）各取 tick 37、41；12 snapshot、60 health context、168 个预分配分支。severe 四分支顺序按 ordinal 模 4 轮换。每分支有独立 live/staging owner 和 warm-start 记忆，首包提交后的积分和参考时钟连续。',
        '这是 direct 控制实验：experimental_dispatch 与 prepared/committed/applied 分开，learner/governor approval 全部 FALSE；没有模型筛选、旧 CAL 认证或训练。', '',
        '| 阶段 | 本轮数量 |','|---|---:|',f"| planned | 168 |",f"| experimental dispatched | {result['dispatched']} |",
        f"| committed | {result['committed']} |",f"| actually applied | {result['applied']} |",f"| complete 500/501/21 | {c['complete_501']} |",
        f"| complete physical pass | {c['complete_physical_pass']} |",f"| complete physical + terminal | {c['complete_physical_terminal']} |",
        f"| complete physical + terminal + 6 mm | {c['complete_safe_6mm']} |",f"| complete timely (including unsafe) | {c['timing_qualified']} |",
        f"| complete safe + timely | {result['safe_timely']} |",'',
        f"状态分布：`{c['statuses']}`；结果分类：`{c['outcomes']}`。所有未施加、partial、数值和完整物理失败保留；缺测不记为零，不生成缺失的 1 s 标签。",
        '完整的方向 × 腿 × health × 方法分母见 [SUPPORT_MATRIX.csv](SUPPORT_MATRIX.csv)，全部位置见 [BRANCH_RESULTS.csv](BRANCH_RESULTS.csv)，6 条 reference 单列见 [REFERENCE_STATUS.csv](REFERENCE_STATUS.csv)。健康对照按 snapshot 共享到 FR/RR，不重复计作独立 episode。','',
        '## P：同 γ 的 TASK / HOLD 配对','',
        '以下全部 6 个负向 RR severe MIDDLE 配对覆盖协议要求的 12 个 planned arm 位置。末端改进 = HOLD 外部绝对误差 − TASK 外部绝对误差；积分改进 = HOLD − TASK，正数表示 TASK 更好。达标需要两侧完整、安全、及时，末端至少改善 0.20 mm，1 s 误差积分不增加。', '',
        '| episode / tick | HOLD状态 | TASK状态 | HOLD末误差 mm | TASK末误差 mm | 改进 mm | 积分改进 mm·s | 两侧安全及时 | 用途达标 |',
        '|---|---|---|---:|---:|---:|---:|---|---|']
    for q in primary['P_pairs']:
        lines.append(f"| {q['episode']} / {q['tick']} | {q['right_status']}:{q['right_outcome']} | {q['left_status']}:{q['left_outcome']} | {fmt(q['right_metrics']['terminal_abs_external_error_m'],1000)} | {fmt(q['left_metrics']['terminal_abs_external_error_m'],1000)} | {fmt(q['terminal_error_improvement_m'],1000)} | {fmt(q['integral_improvement_m_s'],1000)} | {q['both_safe_timely']} | {q['task_use_target_met']} |")
    lines+=['','全部 γ=0 / .5、方向和腿以及 healthy/mild 对照见 [TASK_PAIRS.csv](TASK_PAIRS.csv)。[STEP46_RESULT.json](STEP46_RESULT.json) 保存改善/恶化数量、所有 severe 分层和 episode 内一致性。0.20 mm 是冻结的工程幅度目标，未作总体显著性推断；同一 episode 的 tick、health、γ 不视为独立样本。','',
        '## R：容量恢复与任务用途共存','',
        f"HOLD 自身及时 Type-II：{R['HOLD_timing_type_ii_support']['contexts']} 个 context；TASK 自身及时 Type-II：{R['TASK_timing_type_ii_support']['contexts']} 个 context；BACKUP_ONLY_RESCUE：{R['BACKUP_ONLY_RESCUE_support']['contexts']} 个 context。",
        '四方都来自同一 source snapshot，并在同 policy 内使用 healthy B、同腿 mild B、severe B、MIDDLE。完整 severe B 的原物理失败、故障关节的真实 sent/effective 与 applied/effective ≥99% 首次事件必须严格早于首次 dense 物理失败；healthy/mild 自身也须完整安全及时。B_TASK 已安全时单独标记 BACKUP_ONLY_RESCUE，不强行保留 Type-II。',
        f"负向 RR 共存端点：{rs['physical_snapshots']} snapshot / {rs['independent_reference_episodes']} episode，状态 {R['status']}。",
        '逐 context 的容量时序、失败类型、必要四方 IDs 和及时性见 [CAPACITY_FOUR_WAY.csv](CAPACITY_FOUR_WAY.csv)；逐控制窗口 applied 容量比见 [CAPACITY_EVENTS.csv](CAPACITY_EVENTS.csv)，完整 sent/effective 数值保留在各分支 controls.json/.npz 原始 shard。时间顺序支持机制对照，不把相关序列直接写成已证明的因果中介。','',
        '## F：首动作与后续 backup 的分工','',
        '在 HOLD 内、TASK 内分别比较 MIDDLE − B；首动作有向 base/COM、1 s 外部误差、积分、末有向位移及停止速度分别报告。',
        f"HOLD 同 policy 首 COM 进度：改善 {F['HOLD']['first_COM_gain_m']['improved']}、恶化 {F['HOLD']['first_COM_gain_m']['worsened']}；末端误差改善 {F['HOLD']['terminal_error_improvement_m']['improved']}、恶化 {F['HOLD']['terminal_error_improvement_m']['worsened']}。",
        f"TASK 同 policy 首 COM 进度：改善 {F['TASK']['first_COM_gain_m']['improved']}、恶化 {F['TASK']['first_COM_gain_m']['worsened']}；末端误差改善 {F['TASK']['terminal_error_improvement_m']['improved']}、恶化 {F['TASK']['terminal_error_improvement_m']['worsened']}。",
        '具体缺测与不安全分母保留在 [FIRST_ACTION_PAIRS.csv](FIRST_ACTION_PAIRS.csv)，TASK 用途收益的 MIDDLE − B 二阶差异见 [FACTORIAL_DIFFERENCES.csv](FACTORIAL_DIFFERENCES.csv)。首动作收益不自动等于整任务优势。','',
        '## 时限、证据和图','',
        f"本轮真实 QP {budget['total_QP_calls']} 次 / 返回 {budget['QP_returns']} 次 / UNKNOWN {budget['unknown_native_returns']} 次；积分 {budget['total_physics_steps']} 步，数值耗时 {budget['numerical_elapsed_s']/60:.2f} 分钟。预算上限仍为 90 分钟 / 20,000 QP / 200,000 步 / 0 fit。所有 startup、priming、endpoint、reference、prehold prediction 与反馈都已计入。",
        'prepared reserve 17 ms、完整 begin → staging → 检查 → copy → commit 20 ms、native B/C/feedback 6/3/6 ms 不变。迟到不施加，结束当前分支，再继续冻结列表。所有 preparation/feedback（包括拒收）见 [LATENCY_WINDOWS.csv](LATENCY_WINDOWS.csv)。这里的计时是 direct 控制链，不混称旧学习筛选整链时延。',
        f"一次本轮读回：{check['status']}，检查 {check['TASK_applied_reference_checks']} 个真实已施加 TASK 参考点；0 新求解、0 新积分、0 fit。numerical reproduction = UNVERIFIED（按协议不重跑）。",
        '读回已完成全部 dense/control 输入及原始 hash 扫描，但 latency CSV 嵌套 NumPy 序列化在最终导出时失败，二进制 hash 与 dense 重评价比较的比较结果及 issue 列表未持久化，状态明确为 UNRECORDED。保留 READBACK_CONSOLE.log 和部分 LATENCY.csv；随后只从已保存标量/JSON 索引修复导出，不再次加载 dense/raw bank。CURRENT_RUN_READBACK 验证范围为元数据调用身份、真实参考时钟和 dispatch/时限；不冒充完整二进制验证证书。修复说明见 [READBACK_METADATA_RECOVERY.json](READBACK_METADATA_RECOVERY.json)。',
        '5 个必要 pure fixture 的命令和结果见 [tests/NECESSARY_TESTS.json](tests/NECESSARY_TESTS.json)。冻结后无数值代码改动；读回和绘图代码只从保存证据汇总。原始 packet、候选/commit/apply、lossless raw QP、完整 dense 和账本位于本目录，哈希及调用身份见 [CURRENT_RUN_READBACK.json](CURRENT_RUN_READBACK.json)。',
        '[图1：四分支原始配对 PDF](figures/fig1_paired_task_response.pdf) · [PNG](figures/fig1_paired_task_response.png)；[图2：同源容量时序/任务用途/全部控制窗口 PDF](figures/fig2_capacity_task_latency.pdf) · [PNG](figures/fig2_capacity_task_latency.png)。SciPilot 数据剖析、灰度、形式检查和一次视觉检查存于 figures/。图1 是逐 context 原始点，无均值柱、误差条或 p 值。图2 无事件栏为符号，非 1.1 s 时间值。','',
        '## 交接与停止','',
        '本轮结论范围是固定 1 mm 参考修正的局部开发机制。P、R、F 分开，部署状态 NOT_ESTABLISHED；完整 ±60 余 mm 任务持续执行、学习筛选认可及硬实时部署未建立。旧 CAL 不认证新 policy。',
        f"源 HEAD/index/结果未变：{source.get('unchanged','UNVERIFIED')}。本轮 scoped 提交不推送，最终提交号见聊天交付。",
        '固定列表结束后停止；不自动进入新 CAL、STEP47、E3、RL 或硬件。', '', '```ini']
    lines += [k+' = '+v for k,v in status.items()]+['```','']
    (out/'REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
    handoff=['# STEP46 研究交接','',f"Run: {result['run_id']}；工作树：{OUTPUT_ROOT_D.as_posix()}；源：{SOURCE_COMMIT}。",
        f"完整性 {result['development_experiment_integrity']}；P {P['status']}；R {R['status']}；F {F['status']}。",
        f"168 planned / {c['complete_501']} complete / {result['safe_timely']} safe timely；参考状态 {result['references']}。",'',
        '主结果：[REPORT.md](REPORT.md)、[STEP46_RESULT.json](STEP46_RESULT.json)。协议：[configs/STEP46_EXECUTION_PROTOCOL.md](../../../configs/STEP46_EXECUTION_PROTOCOL.md)。冻结：[METHOD_INPUT_FREEZE.json](METHOD_INPUT_FREEZE.json)。',
        '数据入口：BRANCH_RESULTS.csv、TASK_PAIRS.csv、CAPACITY_FOUR_WAY.csv、FIRST_ACTION_PAIRS.csv、FACTORIAL_DIFFERENCES.csv、LATENCY_WINDOWS.csv、CAPACITY_EVENTS.csv。实际 packet 和 raw QP/dense bank 保留原数值及哈希。二进制 hash/dense重评价的比较结果及 issue 列表因派生 CSV 序列化错误未持久化，UNRECORDED；元数据导出修复未重新读取数值 bank。',
        '唯一 numerical run 已结束；CURRENT_RUN_READBACK 已完成，不重读整批 raw bank、不重新求解。5/5 pure fixture 是无真实 QP/MuJoCo 推进的入口测试。',
        '源码新增 step46_policy/kernel 和 prepare/inputs/io/budget/storage/sprint；原三个模块仅增加 policy-aware 参考 hook、版本和最小 experimental adapter。首包/staging/check/copy时限不变；每个分支独立记忆，旧源不覆盖。',
        '不把同一 episode 的 snapshot、health、γ 分支当独立样本。P/R 主门只考察负向 RR severe；其他方向/腿全表保留。TASK-only 已安全的场景标 BACKUP_ONLY_RESCUE；首动作、积分、末端贡献各自判定。',
        '授权在本轮结束，下一轮另需用户协议。新 CAL、E3、RL、硬件均不执行；不得访问“机器人运控算法”项目或聊天。', '',
        '部署：FULL_TASK_COMPLETION_ESTABLISHED = FALSE；HARD_REALTIME_DEPLOYMENT_ESTABLISHED = FALSE；旧 CAL 不认证新 policy。','']
    (out/'HANDOFF.md').write_text('\n'.join(handoff),encoding='utf-8')
    print('REPORT.md / HANDOFF.md / PROTOCOL_STATUS.ini saved')

if __name__=='__main__':run()
