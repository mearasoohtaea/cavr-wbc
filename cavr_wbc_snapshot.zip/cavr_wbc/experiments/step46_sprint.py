"""One frozen direct four-arm batch. Ordinary outcomes never trigger re-tuning."""
from copy import deepcopy
from datetime import datetime,timezone
import gc,os,traceback
from cavr_wbc.experiments.step46_io import *
from cavr_wbc.experiments.step46_inputs import *
from cavr_wbc.experiments.step46_budget import SprintBudget,SprintLimit
from cavr_wbc.experiments.step46_storage import save_branch,not_run
from cavr_wbc.experiments.step35_reference import reference_episode
from cavr_wbc.experiments.step28_sprint import home_context
from cavr_wbc.experiments import step17_formal_panel as frozen,step38_sim as sim
from cavr_wbc.control.step46_kernel import Kernel,experimental_packet
from cavr_wbc.control.step46_policy import VERSION,CAP_M,RAMP_S,START_S

def event(out,name,**values):
    append(out/'ATTEMPT_LEDGER.jsonl',dict(event=name,timestamp_utc=datetime.now(timezone.utc).isoformat(),**values))
def make_owners(model,budget,c,manifest,arm):
    owners={};startup={}
    for name in ('C','MIDDLE','B'):
        k=Kernel(model,'BOUNDED',str(NATIVE_DLL),budget,task=arm.endswith('TASK'))
        home=home_context(model,manifest['scenario'])
        home.update(context_id=c['context_id']+':'+arm+':'+name+':HOME',
            backup_id=c['backup_id']+':'+name+':HOME')
        startup[name]=k.startup(home,budget)
        k.flush_raw_evidence();owners[name]=k
    return owners,startup

def run():
    out=output()
    if (out/'RUN_STARTED.json').exists():raise FileExistsError('unique run already dispatched; do not restart')
    manifest=read(out/'SOURCE_FROZEN_CONFIG.json')
    manifest.update(run_id=RUN_ID,source_commit=SOURCE_COMMIT,protocol_sha256=sha(PROTOCOL),
        max_wall_s=5400,max_QP=20000,max_physics_steps=200000,max_fits=0,
        new_CAL=0,new_TRAIN=0,governor_calls=0,new_branch_positions=168,reference_episodes=6,
        dispatch_reason='PREASSIGNED_EXPERIMENT_ARM',learned_approval=False)
    runtime={relative(p,OUTPUT_ROOT_D):sha(p) for p in OUTPUT_ROOT_D.glob('cavr_wbc/**/*.py')}
    freeze=dict(policy_version=VERSION,shift_cap_m=CAP_M,ramp_s=RAMP_S,physical_start_s=START_S,
        references=episodes(),contexts=plans(),positions=planned_positions(),
        runtime_sha256=runtime,protocol_sha256=sha(PROTOCOL),native_dll_sha256=sha(NATIVE_DLL),
        physical_evaluator_unchanged=True,all_thresholds_in_source_configuration=manifest,
        TEST_labels_not_used_for_selection=True)
    write(out/'METHOD_INPUT_FREEZE.json',freeze);write(out/'PROTOCOL_AND_MANIFEST.json',manifest)
    model=frozen.load_model()
    budget=SprintBudget(out);status='COMPLETED';contexts=[]
    write(out/'RUN_STARTED.json',dict(run_id=RUN_ID,pid=os.getpid(),start_utc=datetime.now(timezone.utc).isoformat(),
        command='cavr_wbc.experiments.step46_sprint',frozen_before_first_reference=True))
    saved_positions=set()
    try:
        budget.event('METHOD_INPUT_FROZEN_BEFORE_REFERENCE',freeze_sha256=sha(out/'METHOD_INPUT_FREEZE.json'))
        for ep in episodes():
            budget.check();event(out,'START',kind='REFERENCE',**ep)
            episode=reference_episode(model,manifest['reference_scenario'],ep['displacement_m'],ep['episode_id'],ep['snapshot_ticks'],budget,evidence_callback=budget.record_raw)
            for control in episode['controls']:control.pop('raw_solver_result',None)
            save_numeric(out/'episodes'/(ep['episode_id']+'.json'),episode)
            event(out,'RETURN',kind='REFERENCE',episode_id=ep['episode_id'],status=episode['status'],counts=episode['counts'])
            for p in (v for v in plans() if v['episode']==ep['episode_id']):
                c=context_for(p,episode,manifest['mapping']);contexts.append(c)
                save_numeric(out/'DEV'/c['context_id']/'SOURCE_IDENTITY.json',dict(plan=p,context=c))
                for arm in p['arms']:
                    budget.check()
                    ac=arm_context(c,arm);gamma=.5 if arm.startswith('MIDDLE') else 0.
                    path=out/'DEV'/c['context_id']/arm;owners={};k=None
                    event(out,'START',kind='EXPERIMENT_ARM',context_id=c['context_id'],arm=arm,gamma=gamma)
                    if c.get('eligible'):
                        owners,startup=make_owners(model,budget,ac,manifest,arm)
                        write(path/'STARTUP.json',startup)
                        k=owners['B' if gamma==0. else 'MIDDLE']
                        packet=experimental_packet(k,ac,budget,owners,gamma,arm)
                        k.flush_raw_evidence()
                    else:
                        packet=dict(context_id=c['context_id'],arm=arm,method=arm,policy_version=VERSION if arm.endswith('TASK') else 'HOLD_ORIGINAL',
                            experimental_dispatch=True,experimental_committed=False,selected_command_sent=False,model_authorized=False,
                            status='SOURCE_INELIGIBLE',selected_gamma=gamma,command_ready_ms=None)
                    save_numeric(path/'PACKET.json',packet)
                    event(out,'EXPERIMENT_PACKET_FROZEN',context_id=c['context_id'],arm=arm,
                        packet_sha256=sha(path/'PACKET.json'),experimental_committed=packet['experimental_committed'],
                        learned_approval=False)
                    branch=(sim.propagate(k,ac,packet,budget,purpose=arm,require_sent=True)
                        if packet['experimental_committed'] else not_run(gamma,packet['status']))
                    record=save_branch(out,path,branch,ac,packet)
                    saved_positions.add(c['context_id']+':'+arm)
                    event(out,'RETURN',kind='EXPERIMENT_ARM',context_id=c['context_id'],arm=arm,
                        status=record['status'],complete=record['complete_501'],
                        experimental_applied=record['experimental_applied'])
                    budget.persist(phase='ARM_SAVED',completed_positions=len(saved_positions),planned_positions=168,
                        context_ordinal=p['ordinal'],arm=arm)
                    del owners,k,branch,packet
                    gc.collect()
                budget.persist(phase='CONTEXT_DONE',contexts_processed=p['ordinal']+1)
                print(dict(phase='CONTEXT_DONE',contexts=p['ordinal']+1,planned_contexts=60,
                    completed_positions=len(saved_positions),budget=budget.snapshot()),flush=True)
        save_numeric(out/'DEV_CONTEXTS.json',contexts)
    except SprintLimit as exc:
        status='INCOMPLETE_BUDGET';write(out/'INTERRUPTION.json',dict(error=str(exc),budget=budget.snapshot()))
    except BaseException as exc:
        status='STOPPED_IMPLEMENTATION_OR_RESOURCE'
        write(out/'INTERRUPTION.json',dict(type=type(exc).__name__,error=str(exc),traceback=traceback.format_exc(),budget=budget.snapshot()))
        raise
    finally:
        # Preserve missing positions explicitly, never repeat STARTed attempts.
        for p in plans():
            for arm in p['arms']:
                key=p['context_id']+':'+arm
                destination=out/'DEV'/p['context_id']/arm/'RESULT.json'
                if key not in saved_positions and not destination.exists():
                    write(destination,dict(status='NOT_RUN',reason=dict(reason=status),
                        complete_501=False,timing_qualified=False,observed=False,
                        experimental_dispatch=False,experimental_committed=False,governor_selected=False,learner_approved=False))
        if not (out/'DEV_CONTEXTS.json').exists():save_numeric(out/'DEV_CONTEXTS.json',contexts)
        unchanged=all(sha(OUTPUT_ROOT_D/p)==value for p,value in runtime.items())
        if not unchanged:status='INVALID_RUNTIME_MUTATION'
        write(out/'RUNTIME_END.json',dict(runtime_sha256_unchanged=unchanged,new_CAL=0,new_TRAIN=0,new_fits=0,governor_calls=0))
        budget.event('NUMERICAL_FINISHED',status=status);budget.close()
        write(out/'RUN_FINISHED.json',dict(status=status,run_id=RUN_ID,finish_utc=datetime.now(timezone.utc).isoformat(),budget=budget.snapshot()))
        print(dict(status=status,budget=budget.snapshot()),flush=True)
if __name__=='__main__':run()
