"""Policy identity is distinct from numerical (gamma, role) lookup identity."""
from copy import deepcopy
from cavr_wbc.experiments.step44_identity import fingerprint
from cavr_wbc.control.step41_terminal_domain import ResidentDomain
from cavr_wbc.control.step46_policy import VERSION,CAP_M,RAMP_S,START_S
from cavr_wbc.experiments.step47_io import OUTPUT_ROOT_D,sha

def contracts(method_hash):
    paths=[OUTPUT_ROOT_D/'cavr_wbc/control'/p for p in ('step46_policy.py','step34_servo.py','step47_kernel.py')]
    source_hash=fingerprint({p.name:sha(p) for p in paths})
    return {m:dict(method=m,policy_version=VERSION if m=='TASK_MATCHED' else 'HOLD_ORIGINAL',
        policy_source_sha256=source_hash,source_anchor='ORIGINAL_SAMPLE_BACKUP_ANCHOR',
        source_goal='NOMINAL_Q_INIT_X_PLUS_NOMINAL_D',CAP_M=CAP_M if m=='TASK_MATCHED' else 0.,
        RAMP_S=RAMP_S if m=='TASK_MATCHED' else 0.,START_S=START_S,
        actual_clock_convention='ACTUAL_RELATIVE_PHYSICAL_TIME',method_freeze_sha256=method_hash)
        for m in ('HOLD_MATCHED','TASK_MATCHED')}
def assert_policy(expected,context,bundle,domain):
    if expected is None or context.get('policy_contract')!=expected or bundle is None or bundle.get('policy_contract')!=expected or domain is None or domain.policy_contract!=expected:
        raise ValueError('CROSS_POLICY_CAL_DOMAIN_CONTEXT_REJECTED_BEFORE_NUMERICS')
    if context.get('method')!=expected['method']:raise ValueError('policy method identity')
def packet_binding(c,contract):
    return dict(contract=deepcopy(contract),backup_id=c['backup_id'],context_id=c['context_id'],
        source_anchor_m=float(c['backup_anchor_q_init'][0]),source_goal_m=float(c['nominal_q_init'][0])+float(c['nominal_d_m']))
class PolicyDomain(ResidentDomain):
    def __init__(self,table,digest):
        super().__init__(table,digest);self.policy_contract=deepcopy(table['policy_contract'])
    def check(self,features,action,context):
        if context.get('policy_contract')!=self.policy_contract:raise ValueError('CROSS_POLICY_DOMAIN')
        return super().check(features,action,context)
