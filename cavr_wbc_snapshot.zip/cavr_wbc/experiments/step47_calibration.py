"""Fresh-only policy CAL replaces all calibration, never TRAIN/predictors."""
from copy import deepcopy
from cavr_wbc.control import step39_margin as margin
from cavr_wbc.control.step41_terminal_domain import build_table
from cavr_wbc.experiments.step44_identity import fingerprint,bundle_identity
from cavr_wbc.experiments.step47_binding import PolicyDomain
from cavr_wbc.experiments.step47_io import *
from cavr_wbc.experiments.step47_inputs import METHODS

def clean(item):
    if isinstance(item,dict):return {k:clean(v) for k,v in item.items() if not k.startswith('_')}
    return deepcopy(item)
def train_identity(bundle):
    return fingerprint(dict(predictor=margin.identity(bundle),groups={margin.group_key(float(k.split(':')[0]),k.split(':')[1]):{n:v for n,v in g.items() if n.startswith('train_') or n.startswith('TRAIN_')} for k,g in bundle['groups'].items()},top={k:v for k,v in bundle.items() if k.startswith('TRAIN_')}))
def skeleton(old):
    b=clean(old);groups={}
    for key,g in b['groups'].items():
        key=margin.group_key(float(key.split(':')[0]),key.split(':')[1])
        if key in groups:raise ValueError('canonical duplicate TRAIN group')
        groups[key]={k:v for k,v in g.items() if not (k.startswith(('cal_','CAL_')) or k in ('distance_threshold','local_calibrated'))}
    b['groups']=groups
    for key in list(b):
        if key.startswith(('cal_','CAL_')) or key in ('calibration_id','TEST_consumed','policy_contract'):b.pop(key)
    return b
def fresh(old,rows,contract):
    if len(rows)!=64 or any(r['split']!='CAL' or r['policy_contract']!=contract for r in rows):raise ValueError('policy CAL planned identities')
    before=train_identity(old)
    b=margin.build_calibration(skeleton(old),rows)
    b.update(policy_contract=deepcopy(contract),calibration_id='STEP47_FRESH_POLICY_MATCHED_CAL_V1',
        TEST_consumed=False,predictor_source_policy='HOLD_ORIGINAL',TASK_TRAIN_policy_matched=False)
    if train_identity(b)!=before:raise ValueError('TRAIN/predictor mutation')
    expected={r['id'] for r in rows}
    if set(b['CAL_ids_all'])!=expected or any(str(i) not in expected for g in b['groups'].values() for i in g['cal_ids']):raise ValueError('historical CAL contamination')
    return b
def freeze(out,old,rows,domain_rows,mapping,contracts):
    bundles={};domains={};assets={};metadata={}
    for m in METHODS:
        own=[r for r in rows if r['policy_contract']['method']==m]
        bundles[m]=fresh(old,own,contracts[m])
        records=[r for r in domain_rows if r['policy_contract']['method']==m]
        if len(records)!=64:raise ValueError('policy domain denominator')
        table=build_table(records,mapping)
        table.update(policy_contract=deepcopy(contracts[m]),TEST_consumed=False,new_CAL_only=True)
        path=out/'models'/(m+'_DOMAIN.json');write(path,table)
        domains[m]=PolicyDomain(table,sha(path))
        assets[m]=dict(bundle=margin.save_bundle(bundles[m],out/'models',m),domain=dict(path=relative(path,out),sha256=sha(path)))
        metadata[m]=dict(identity=bundle_identity(bundles[m]),TRAIN_unchanged=train_identity(old)==train_identity(bundles[m]),
            policy_contract=contracts[m],groups={k:{n:v for n,v in g.items() if n.startswith('CAL_') or n in ('local_calibrated','distance_threshold')} for k,g in bundles[m]['groups'].items()},domain_groups=table['strata'])
    f=dict(status='FROZEN_BEFORE_TEST',planned=128,recorded=len(rows),assets=assets,methods=metadata,
        new_TRAIN=0,new_fits=0,TEST_consumed=False,old_CAL_retained=False,TRAIN_policy='HOLD_ORIGINAL',TASK_TRAIN_policy_matched=False)
    write(out/'STEP47_CAL_FREEZE.json',f)
    return bundles,domains,f
