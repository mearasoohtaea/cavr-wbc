"""One streaming current readback, authoritative receipts, then derived CSV."""
from collections import Counter
from datetime import datetime,timezone
import csv,gc,json
import numpy as np
from cavr_wbc.experiments.step47_io import *
from cavr_wbc.experiments.step47_inputs import *
from cavr_wbc.experiments.step47_receipts import evaluate,numeric_equal
from cavr_wbc.experiments.step46_delivery import task_metrics,capacity_controls
from cavr_wbc.experiments.step39_delivery import flatten,safe,counts,outcome
from cavr_wbc.control.step46_policy import task_reference,VERSION
from cavr_wbc.experiments.step47_calibration import train_identity
from cavr_wbc.experiments.step47_binding import packet_binding
from cavr_wbc.control import step39_margin as margin

def csv_save(path,rows):
    # JSON authority is already durable; a CSV problem cannot erase it.
    try:
        fields=list(dict.fromkeys(k for r in rows for k in r))
        with path.open('x',newline='',encoding='utf-8') as stream:
            writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader()
            for row in rows:
                converted=encode(row)
                writer.writerow({k:json.dumps(v,ensure_ascii=False,allow_nan=False) if isinstance(v,(dict,list)) else v for k,v in converted.items()})
    except Exception as exc:
        append(path.parent/'CSV_EXPORT_ISSUES.jsonl',dict(path=path.name,error=type(exc).__name__+':'+str(exc),scientific_JSON_authority_unchanged=True))
def support(rows):
    return dict(contexts=len(rows),physical_snapshots=len({r['snapshot_id'] for r in rows}),
        independent_episodes=len({r['episode'] for r in rows}),ids=[r['context_id'] for r in rows])
def established(rows):
    s=support(rows);return dict(status='ESTABLISHED_LOCAL_CONFIRMATION' if s['physical_snapshots']>=3 and s['independent_episodes']>=2 else 'NOT_ESTABLISHED',support=s)
def ident(p):return {k:p[k] for k in ('context_id','snapshot_id','episode','direction','displacement_m','fault_leg','health_kind','tick')}
def pair(p,left,right,comparison):
    def gain(key):
        a,b=left.get(key),right.get(key);return None if a is None or b is None else float(b-a)
    terminal=gain('terminal_abs_external_error_m');integral=gain('abs_external_error_integral_m_s')
    good=bool(left['safe_timely'] and right['safe_timely'] and terminal is not None and terminal>=.0002 and integral is not None and integral>=0)
    return dict(**ident(p),comparison=comparison,left_id=left['id'],right_id=right['id'],
        left_gamma=left.get('gamma'),right_gamma=right.get('gamma'),same_gamma=left.get('gamma')==right.get('gamma'),
        both_complete=left['complete_501'] and right['complete_501'],both_safe_timely=left['safe_timely'] and right['safe_timely'],
        left_outcome=left['outcome'],right_outcome=right['outcome'],terminal_error_improvement_m=terminal,
        integral_improvement_m_s=integral,task_use_target_met=good,
        first_base_gain_m=None if left.get('first_action_directed_base_m') is None or right.get('first_action_directed_base_m') is None else left['first_action_directed_base_m']-right['first_action_directed_base_m'],
        first_COM_gain_m=None if left.get('first_action_directed_COM_m') is None or right.get('first_action_directed_COM_m') is None else left['first_action_directed_COM_m']-right['first_action_directed_COM_m'],
        left_terminal_vx_m_s=left.get('terminal_vx_m_s'),right_terminal_vx_m_s=right.get('terminal_vx_m_s'))
def capacity_four(p,healthy,mild,B,M):
    full=all(r['complete_501'] for r in (healthy,mild,B,M))
    physical_failure=bool(B['complete_501'] and B['physical_pass'] is False)
    event=bool(B.get('sent_and_actual_capacity_precede_failure'))
    return dict(**ident(p),complete_four_way=full,healthy_safe_timely=healthy['safe_timely'],mild_safe_timely=mild['safe_timely'],
        severe_B_complete_physical_failure=physical_failure,severe_B_timing_qualified=B['timing_qualified'],
        sent_and_actual_capacity_precede_failure=event,
        first_sent_99percent_s=B.get('first_sent_99percent_s'),first_actual_99percent_s=B.get('first_actual_99percent_s'),
        first_dense_failure_s=B.get('first_dense_failure_s'),first_failure_reasons=B.get('first_dense_failure_reasons'),
        middle_safe_timely=M['safe_timely'],
        timing_type_ii=bool(full and healthy['safe_timely'] and mild['safe_timely'] and physical_failure and event and B['timing_qualified'] and M['safe_timely']),
        required_ids=[r['id'] for r in (healthy,mild,B,M)])
def endpoints(rows):
    by={r['id']:r for r in rows};P=[];F=[];onlineP=[];packages=[];C=[];R=[];backups=[];S={}
    for m in METHODS:
        all_online=[r for r in rows if r['kind']=='ONLINE' and r['method']==m]
        sent=[r for r in all_online if r['selected_command_sent']]
        wrong=[r for r in sent if r['complete_501'] and not r['safe_timely']]
        partial=[r for r in sent if not r['complete_501']]
        S[m]=dict(status='FAIL' if wrong else 'NOT_ESTABLISHED' if not sent or partial else 'ESTABLISHED_FINITE_ACCEPTANCE',
            planned=32,recognized=sum(r['learner_approved'] for r in all_online),sent=len(sent),
            complete_safe_timely=sum(r['safe_timely'] for r in sent),complete_wrong_accepts=len(wrong),
            sent_partial=len(partial),abstain=sum(r['packet_status']=='ABSTAIN' for r in all_online),
            late=sum(r['packet_late'] for r in all_online),rejected_unapplied=32-len(sent),
            wrong_ids=[r['id'] for r in wrong],partial_ids=[r['id'] for r in partial])
    for p in plans('TEST'):
        if not p['severe']:continue
        cid=p['context_id'];own=lambda m,arm:by[cid+':'+m+':'+arm]
        for arm in ('B','MIDDLE'):
            q=pair(p,own('TASK_MATCHED',arm),own('HOLD_MATCHED',arm),'TASK_MINUS_HOLD_SAME_GAMMA_DIRECT');q['arm']=arm;P.append(q)
        for m in METHODS:
            F.append(dict(method=m,**pair(p,own(m,'MIDDLE'),own(m,'B'),'MIDDLE_MINUS_B_WITHIN_POLICY')))
        task=own('TASK_MATCHED','ACTUAL');hold=own('HOLD_MATCHED','ACTUAL')
        g=task.get('gamma');h=own('HOLD_MATCHED','MIDDLE' if g==.5 else 'B')
        q=pair(p,task,h,'TASK_ONLINE_MINUS_SAME_GAMMA_HOLD_DIRECT')
        q['gamma_available']=g in (.5,0.);q['task_use_target_met']=q['task_use_target_met'] and q['gamma_available'];onlineP.append(q)
        package=pair(p,task,hold,'TASK_VS_HOLD_COMPLETE_LEARNED_METHOD_PACKAGE');packages.append(package)
        four={}
        for m in METHODS:
            H=by[p['snapshot_id']+'_HEALTHY:'+m+':B'];L=by[p['snapshot_id']+'_'+p['fault_leg']+'_THIGH30:'+m+':B']
            four[m]=capacity_four(p,H,L,own(m,'B'),own(m,'MIDDLE'))
        tf=four['TASK_MATCHED'];hf=four['HOLD_MATCHED'];B=own('TASK_MATCHED','B');holdB=own('HOLD_MATCHED','B')
        q.update(TASK_four_way=tf)
        C.append(dict(**ident(p),TASK_four_way=tf,
            timely_recognized_sent_middle=bool(task['selected_command_sent'] and g==.5),
            own_actual_safe_timely=task['safe_timely'],own_actual_id=task['id'],
            same_gamma_HOLD_direct_task_use=q['task_use_target_met'],
            qualified=bool(tf['healthy_safe_timely'] and tf['mild_safe_timely'] and tf['severe_B_complete_physical_failure'] and tf['severe_B_timing_qualified'] and tf['sent_and_actual_capacity_precede_failure'] and task['selected_command_sent'] and g==.5 and task['safe_timely'] and q['task_use_target_met'])))
        middleP=next(r for r in P if r['context_id']==cid and r['arm']=='MIDDLE')
        R.append(dict(**ident(p),HOLD_four_way=hf,TASK_middle_safe_timely=own('TASK_MATCHED','MIDDLE')['safe_timely'],
            P_target_met=middleP['task_use_target_met'],qualified=bool(hf['timing_type_ii'] and middleP['task_use_target_met'] and own('TASK_MATCHED','MIDDLE')['safe_timely'])))
        backups.append(dict(**ident(p),TASK_BACKUP_SAFE=bool(tf['healthy_safe_timely'] and tf['mild_safe_timely'] and B['safe_timely']),
            COMPARATIVE_BACKUP_ONLY_RECOVERY=bool(hf['healthy_safe_timely'] and hf['mild_safe_timely'] and holdB['complete_501'] and holdB['physical_pass'] is False and holdB['timing_qualified'] and holdB.get('sent_and_actual_capacity_precede_failure') and B['safe_timely']),
            HOLD_B_outcome=holdB['outcome'],TASK_B_outcome=B['outcome']))
    primary=lambda r:r['direction']==-1 and r['fault_leg']=='RR'
    pres=established([q for q in P if primary(q) and q['arm']=='MIDDLE' and q['task_use_target_met']])
    cres=established([q for q in C if primary(q) and q['qualified']]);rres=established([q for q in R if primary(q) and q['qualified']])
    return dict(S=S,P=pres,C_TASK_ONLINE=cres,R_LEGACY_CROSS_POLICY=rres,
        closure_established=S['TASK_MATCHED']['status']=='ESTABLISHED_FINITE_ACCEPTANCE' and pres['status']=='ESTABLISHED_LOCAL_CONFIRMATION' and cres['status']=='ESTABLISHED_LOCAL_CONFIRMATION'),dict(TASK_PAIRS=P,ONLINE_TASK_PAIRS=onlineP,LEARNED_PACKAGE_PAIRS=packages,F_COMPONENT_PAIRS=F,C_TASK_ONLINE_PAIRS=C,R_LEGACY_PAIRS=R,BACKUP_CLASSIFICATION=backups)

def run():
    out=output()
    if (out/'CURRENT_RUN_READBACK.json').exists() or (out/'READBACK_STARTED.json').exists():raise FileExistsError('one current readback already dispatched')
    finished=read(out/'RUN_FINISHED.json')
    if not finished:raise ValueError('numerical process must have ended')
    write(out/'READBACK_STARTED.json',dict(time_utc=datetime.now(timezone.utc).isoformat(),no_solver_no_integration=True))
    rows=[];latencies=[];clockchecks=[];capacities=[];decisions=[];issues=[];references=[]
    plans_by={p['context_id']:p for s in ('CAL','TEST') for p in plans(s)}
    manifest=read(out/'PROTOCOL_AND_MANIFEST.json');contracts=manifest['policy_contracts']
    attempt=[json.loads(line) for line in (out/'ATTEMPT_LEDGER.jsonl').read_text(encoding='utf-8').splitlines()]
    decisions_frozen={e['context_id']+':'+e['method']:e for e in attempt if e['event']=='DECISION_IMMUTABLE'}
    for ordinal,pos in enumerate(positions('CAL')+positions('TEST')):
        p=plans_by[pos['context_id']];path=out/pos['split']/pos['context_id']/pos['method']/pos['arm'];rec=read(path/'RESULT.json',{})
        row=flatten(p,pos['method']+':'+pos['arm'],rec,path/'RESULT.json',out)
        row.update(direction=p['direction'],displacement_m=p['displacement_m'],severe=p['severe'],method=pos['method'],
            policy='TASK' if pos['method']=='TASK_MATCHED' else 'HOLD',kind=pos['kind'],arm=pos['arm'],
            experimental_dispatch=bool(rec.get('experimental_dispatch')),experimental_committed=bool(rec.get('experimental_committed')),
            experimental_applied=bool(rec.get('experimental_applied')),learner_approved=bool(rec.get('learner_approved')),
            backup_id=rec.get('backup_id'))
        c=load_numeric(path/'POLICY_CONTEXT.json') if (path/'POLICY_CONTEXT.json').exists() else None
        packet=load_numeric(path/'PACKET.json') if (path/'PACKET.json').exists() else {}
        local=[]
        if packet and packet.get('policy_contract')!=contracts[pos['method']]:local.append('POLICY_CONTRACT')
        if c and c.get('policy_contract')!=contracts[pos['method']]:local.append('CONTEXT_CONTRACT')
        if c and c.get('eligible') and packet and packet.get('policy_binding')!=packet_binding(c,contracts[pos['method']]):local.append('PACKET_SOURCE_ANCHOR_GOAL_BINDING')
        freeze_event=decisions_frozen.get(pos['context_id']+':'+pos['method']) if pos['kind']=='ONLINE' else None
        if freeze_event and sha(path/'PACKET.json')!=freeze_event['packet_sha256']:local.append('DECISION_HASH')
        row.update(packet_status=packet.get('status','NOT_RUN'),packet_late=bool(packet.get('overall_deadline_failure')),
            first_prepared_ms=packet.get('prepared_commit_ms'),recognized=bool(packet.get('selected_action')),
            gamma=packet.get('selected_gamma',rec.get('gamma')) if pos['kind']=='ONLINE' else pos['gamma'])
        if pos['kind']=='ONLINE' and packet.get('experimental_dispatch'):local.append('ONLINE_EXPERIMENTAL_CONFLATION')
        if pos['kind']!='ONLINE' and (rec.get('selected_command_sent') or rec.get('model_authorized') or rec.get('learner_approved')):local.append('FALSE_LEARNED_APPROVAL')
        if pos['kind']=='CAL' and (packet.get('experimental_dispatch') or packet.get('experimental_committed')):local.append('CAL_EXPERIMENTAL_CONFLATION')
        feedback_slots=set()
        if rec.get('observed'):
            receipt,branch=evaluate(path,c,rec);local.extend(receipt['issues'])
            summary,series=task_metrics(branch,c);row.update(summary)
            write(path/'TASK_RESPONSE.json',dict(summary=summary,series=series))
            capacities.extend(capacity_controls(row,branch,c))
            for control in branch['controls']:
                slot=int(control['slot']);applied=control.get('tau_applied') is not None
                if row['policy']=='TASK' and slot>=1 and applied:
                    expected=task_reference(float(c['backup_anchor_q_init'][0]),float(c['nominal_q_init'][0])+float(c['nominal_d_m']),slot*.02)
                    ref=control.get('backup_reference');good=bool(ref and ref.get('backup_id')==c['backup_id'] and ref.get('policy_version')==VERSION and all(numeric_equal(ref.get(k),expected[k]) for k in ('p_ref_m','v_ref_m_s','a_ref_m_s2','time_s','x_anchor_m','x_task_m','d_task_m')))
                    clockchecks.append(dict(id=row['id'],slot=slot,physical_time_s=slot*.02,pass_=good,expected=expected,observed=ref))
                    if not good:local.append('TASK_CLOCK:'+str(slot))
                if slot>1:
                    feedback_slots.add(slot)
                    timing=control.get('timing') or {};ms=control.get('command_ready_ms',control.get('latency_ms'));prep=timing.get('prepared_commit_ms')
                    latencies.append(dict(id=row['id'],kind='FEEDBACK',method=row['method'],split=row['split'],slot=slot,
                        complete_ms=ms,prepared_ms=prep,applied=applied,status=control.get('source'),missing=False))
                    if row['split']=='TEST' and applied and (ms is None or ms>20. or prep is None or prep>17. or not control.get('staging_committed')):local.append('LATE_OR_UNCOMMITTED_APPLIED:'+str(slot))
            if row['kind']=='ONLINE' and rec.get('selected_command_sent') and (packet.get('step34_solver_owner') or {}).get('arm_instance')!=packet.get('arm_instance'):local.append('ONLINE_OWNER')
            if any(f.get('backup_id')!=c['backup_id'] for f in ([branch.get('initial_fact')]+branch.get('physics_trajectory',[])) if f):local.append('DENSE_BACKUP_ID')
            del branch,series
        else:
            receipt=dict(binary_status='NOT_APPLICABLE_UNOBSERVED',evaluation_status='NOT_APPLICABLE_UNOBSERVED',issues=[])
            row.update(terminal_abs_external_error_m=None,abs_external_error_integral_m_s=None,terminal_vx_m_s=None,
                first_action_directed_base_m=None,first_action_directed_COM_m=None)
        # Every planned 1 s position has 48 feedback windows. Missing/abstained
        # windows stay missing; never impute their latency as zero or failure.
        for slot in sorted(set(range(2,50))-feedback_slots):
            latencies.append(dict(id=row['id'],kind='FEEDBACK',method=row['method'],split=row['split'],slot=slot,
                complete_ms=None,prepared_ms=None,applied=False,status='NOT_REACHED',missing=True))
        applied=bool(row['observed'] and rec.get('counts',{}).get('physical_steps',0)>10)
        prep=packet.get('prepared_commit_ms');ms=packet.get('command_ready_ms')
        latencies.append(dict(id=row['id'],kind='PREPARATION',method=row['method'],split=row['split'],slot=1,
            complete_ms=ms,prepared_ms=prep,applied=applied,status=packet.get('status','NOT_RUN'),missing=ms is None))
        if row['split']=='TEST' and applied and (ms is None or ms>20. or prep is None or prep>17.):local.append('LATE_FIRST_APPLIED')
        row['safe_6mm']=safe(row);row['safe_timely']=bool(safe(row) and row['timing_qualified']);row['outcome']=outcome(row)
        if row['kind']=='ONLINE':
            queries=[]
            for gamma,e in packet.get('actions',{}).items():
                queries.append(dict(gamma=gamma,evaluation_status=e.get('evaluation_status'),accepted=(e.get('decision') or {}).get('accepted'),
                    rejection_reasons=e.get('rejection_reasons'),domain=e.get('terminal_domain'),consensus=e.get('cal_physical_consensus'),numeric=(e.get('decision') or {}).get('numeric')))
            decisions.append(dict(id=row['id'],**ident(p),method=row['method'],status=row['packet_status'],gamma=row['gamma'],
                selected_command_sent=row['selected_command_sent'],learner_approved=row['learner_approved'],late=row['packet_late'],queries=queries))
        row['evidence_valid']=not local;rows.append(row)
        receipt.update(id=row['id'],status='VERIFIED' if not local else 'INVALID',issues=local)
        write(path/'CURRENT_READBACK_RECEIPT.json',receipt)
        append(out/'CURRENT_SHARD_READBACK.jsonl',receipt)
        issues.extend(row['id']+':'+i for i in local)
        del c,packet,rec;gc.collect()
        if (ordinal+1)%32==0:
            write(out/'READBACK_PROGRESS.json',dict(positions=ordinal+1,planned=416,new_QP=0,new_steps=0));print('readback',ordinal+1,'/416',flush=True)
    for split in ('CAL','TEST'):
        for ep in episodes(split):
            path=out/'episodes'/(ep['episode_id']+'.json');record=load_numeric(path) if path.exists() else {}
            references.append(dict(**ep,split=split,status=record.get('status','NOT_RUN'),counts=record.get('counts'),snapshots=len(record.get('snapshots',[]))))
            del record
    ledger=[json.loads(line) for line in (out/'STEP47_LEDGER.jsonl').read_text(encoding='utf-8').splitlines()]
    n=finished['budget']['total_QP_calls'];indices={}
    for key in ('QP_START','QP_RETURN','RAW_QP_SAVED'):
        own=[e for e in ledger if e['event']==key];ix=[e['global_qp_index'] for e in own];indices[key]=len(ix)
        if len(ix)!=len(set(ix)) or sorted(ix)!=list(range(1,n+1)):issues.append('LEDGER:'+key)
        if key=='RAW_QP_SAVED':
            for e in own:
                path=out/e['path']
                if sha(path)!=e['json_sha256'] or sha(path.with_suffix('.npz'))!=e['npz_sha256']:issues.append('RAW_HASH:'+e['path'])
    if sorted(e['reservation_id'] for e in ledger if e['event']=='PREFIX_NATIVE_START')!=sorted(e['reservation_id'] for e in ledger if e['event']=='PREFIX_NATIVE_RETURN'):issues.append('NATIVE_STEP_RESERVATION_RETURNS')
    if n>35000 or finished['budget']['total_physics_steps']>320000 or finished['budget']['numerical_elapsed_s']>7201:issues.append('BUDGET')
    f=read(out/'STEP47_CAL_FREEZE.json')
    modelidentity={}
    if f:
        original=margin.load_bundle(MODEL_NPZ)
        for m,a in f['assets'].items():
            for ext in ('npz','json'):
                if sha(a['bundle'][ext])!=a['bundle'][ext+'_sha256']:issues.append('FROZEN_BUNDLE:'+m+':'+ext)
            if sha(out/a['domain']['path'])!=a['domain']['sha256']:issues.append('FROZEN_DOMAIN:'+m)
            bundle=margin.load_bundle(a['bundle']['npz']);modelidentity[m]=train_identity(bundle)==train_identity(original) and bundle['policy_contract']==contracts[m]
            if not modelidentity[m]:issues.append('PREDICTOR_TRAIN_POLICY:'+m)
    runtime=read(out/'RUNTIME_END.json')
    if not runtime['runtime_sha256_unchanged']:issues.append('RUNTIME_MUTATION')
    frozen=read(out/'METHOD_INPUT_FREEZE.json')
    for name,digest in frozen['runtime_sha256'].items():
        if sha(OUTPUT_ROOT_D/name)!=digest:issues.append('RUNTIME_HASH:'+name)
    baseline=read(out/'SOURCE_READONLY_BASELINE.json');source=SOURCE_ROOT_D/'artifacts/step46_task_aware_backup_20261011/step46-task-aware-backup-pilot-20261011-01'
    sourceunchanged=sha(SOURCE_ROOT_D/'.git/index')==baseline['source_index_sha256'] and sha(source/'STEP46_RESULT.json')==baseline['source_result_sha256'] and sha(source/'SOURCE_FROZEN_CONFIG.json')==baseline['source_config_sha256']
    if not sourceunchanged:issues.append('SOURCE_READONLY_BASELINE')
    endpoint,paired=endpoints(rows)
    if issues:
        endpoint['closure_established']=False
        for m in METHODS:endpoint['S'][m]['status']='INVALID_EVIDENCE'
        for key in ('P','C_TASK_ONLINE','R_LEGACY_CROSS_POLICY'):endpoint[key]['status']='INVALID_EVIDENCE'
    strata=[]
    for split in ('CAL','TEST'):
        for direction in (1,-1):
            for condition in ('HEALTHY','FR_THIGH30','RR_THIGH30','FR_THIGH15','RR_THIGH15'):
                for m in METHODS:
                    for arm in ('B','MIDDLE','ACTUAL'):
                        own=[r for r in rows if r['split']==split and r['direction']==direction and r['condition']==condition and r['method']==m and r['arm']==arm]
                        if own:strata.append(dict(split=split,direction=direction,condition=condition,method=m,arm=arm,**counts(own),safe_timely=sum(r['safe_timely'] for r in own),snapshots=len({r['snapshot_id'] for r in own}),episodes=len({r['episode'] for r in own})))
    receipt=dict(scope='ONE_CURRENT_STEP47_STREAMING_READBACK',status='VERIFIED' if not issues else 'INVALID_EVIDENCE',
        binary_status='HASH_AND_FULL_NUMERIC_DECODE_VERIFIED' if not issues else 'SEE_PER_SHARD_RECEIPTS',
        evaluation_status='INDEPENDENT_FROZEN_EVALUATION_MATCH' if not issues else 'SEE_PER_SHARD_RECEIPTS',
        issues=issues,planned_positions=416,observed_banks=sum(r['observed'] for r in rows),QP_ledger=indices,
        frozen_predictor_TRAIN_checks=modelidentity,source_readonly_unchanged=sourceunchanged,
        numerical_reproduction='UNVERIFIED_NOT_REPEATED',new_QP=0,new_integration=0,new_fits=0,
        STEP46_binary_eval='UNRECORDED_UNCHANGED',timestamp_utc=datetime.now(timezone.utc).isoformat())
    # Durably save all authority before invoking any CSV exporter.
    write(out/'CURRENT_RUN_READBACK.json',receipt)
    datasets=dict(BRANCH_ROWS=rows,LATENCY=latencies,REFERENCE_CLOCK_CHECKS=clockchecks,CAPACITY_EVENTS=capacities,
        ONLINE_DECISIONS=decisions,REFERENCE_STATUS=references,SUPPORT_MATRIX=strata,**paired)
    for name,data in datasets.items():write(out/(name+'.json'),data)
    result=dict(run_id=RUN_ID,run=finished,readback=receipt,endpoints=endpoint,
        CAL=counts([r for r in rows if r['kind']=='CAL']),TEST_direct=counts([r for r in rows if r['kind']=='DIRECT']),
        TEST_online=counts([r for r in rows if r['kind']=='ONLINE']),new_CAL_planned=128,new_TRAIN=0,new_fits=0,
        fixed_positions=len(rows),TASK_TRAIN_policy_matched=False,predictor_source_policy='HOLD_ORIGINAL',
        complete_method_package_comparison=True,full_task_completion_established=False,hard_realtime_deployment_established=False,
        E3_authorized=False,RL_hardware_authorized=False,
        late_TEST_windows_applied=sum(w['split']=='TEST' and w['applied'] and (w['complete_ms'] is None or w['complete_ms']>20 or w['prepared_ms'] is None or w['prepared_ms']>17) for w in latencies),
        TASK_clock_checks=len(clockchecks),TASK_clock_failures=sum(not c['pass_'] for c in clockchecks),
        integrity='INVALID_EVIDENCE' if issues else 'FIXED_LIST_COMPLETED_WITH_ORDINARY_OUTCOMES' if finished['status']=='COMPLETED' else 'INCOMPLETE',
        research_status='LOCAL_CLOSURE_ESTABLISHED' if endpoint['closure_established'] else 'NOT_ESTABLISHED')
    write(out/'STEP47_RESULT.json',result)
    for name,data in datasets.items():csv_save(out/(name+'.csv'),data)
    print(json.dumps(encode(dict(integrity=result['integrity'],research_status=result['research_status'],endpoints=endpoint,CAL=result['CAL'],TEST_direct=result['TEST_direct'],TEST_online=result['TEST_online'],readback=receipt)),ensure_ascii=False),flush=True)
if __name__=='__main__':run()
