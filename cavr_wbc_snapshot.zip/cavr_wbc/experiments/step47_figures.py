"""SciPilot postprocessing only: no owners, solvers, integration, or bank replay."""
from pathlib import Path
import argparse,sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from PIL import Image
from cavr_wbc.experiments.step47_io import output,read,write,sha

SKILL=Path('C:/Users/ZhuanZ（无密码）/.codex/skills/scipilot-figure/scripts')
sys.path.insert(0,str(SKILL))
from setup_style import setup_style
from profile_data import profile_data,render_report
from visual_qa import audit_layout,render_preview
from export_figure import export_figure
from check_figure import check_figure

COLORS={'HOLD_MATCHED':'#0072B2','TASK_MATCHED':'#D55E00'}
MARKERS={'HOLD_MATCHED':'o','TASK_MATCHED':'s'}
METHODS=tuple(COLORS)
def primary(r):return r.get('direction')==-1 and r.get('fault_leg')=='RR'
def label(ax,letter,title):
    ax.set_title(title,loc='left',pad=8)
    ax.text(-.14,1.05,letter,transform=ax.transAxes,fontweight='bold',fontsize=11)
def empty(ax,text):ax.text(.5,.5,text,ha='center',va='center',transform=ax.transAxes,fontsize=9)

def figure1(out,result):
    rows=read(out/'BRANCH_ROWS.json');pairs=read(out/'TASK_PAIRS.json');online=read(out/'ONLINE_TASK_PAIRS.json')
    C=read(out/'C_TASK_ONLINE_PAIRS.json')
    fig=plt.figure(figsize=(7.16,6.5));gs=fig.add_gridspec(2,2,height_ratios=[1,1.25])
    ax=fig.add_subplot(gs[0,:]);categories=['Planned','Recognized','Sent','Safe + timely','Capacity closure']
    plotted=[]
    for j,m in enumerate(METHODS):
        s=result['endpoints']['S'][m]
        closure=sum(r['qualified'] for r in C) if m=='TASK_MATCHED' else None
        values=[32,s['recognized'],s['sent'],s['complete_safe_timely'],closure]
        for i,v in enumerate(values):
            x=i+(j-.5)*.20
            if v is None:ax.text(x,1.3,'n/a',ha='center',va='bottom',fontsize=8,color=COLORS[m])
            else:
                ax.scatter(x,v,s=34,marker=MARKERS[m],color=COLORS[m],zorder=3)
                ax.annotate(str(v),(x,v),xytext=(0,6 if j else -12),textcoords='offset points',ha='center',fontsize=8)
            plotted.append(dict(method=m,stage=categories[i],count=v,denominator=32))
    ax.set_xticks(range(5),categories);ax.set_ylim(-3,38);ax.set_yticks([0,8,16,24,32]);ax.set_ylabel('Online sources (n / 32)')
    handles=[Line2D([],[],color=COLORS[m],marker=MARKERS[m],ls='',label=m.replace('_MATCHED','')) for m in METHODS]
    ax.legend(handles=handles,loc='upper right',frameon=False,ncol=2)
    label(ax,'a','Matched-policy online acceptance chain')
    ax.text(.24,.80,'Closure: TASK definition; HOLD is not relabeled',transform=ax.transAxes,va='top',fontsize=8)
    groups=[[r for r in pairs if primary(r) and r['arm']=='B'],[r for r in pairs if primary(r) and r['arm']=='MIDDLE'],[r for r in online if primary(r)]]
    names=['Direct B','Direct middle','Own actual']
    for panel,(field,ytitle,letter) in enumerate([('terminal_error_improvement_m','HOLD - TASK end error (mm)','b'),('integral_improvement_m_s','HOLD - TASK error integral (mm s)','c')]):
        bx=fig.add_subplot(gs[1,panel]);missing=[]
        for i,group in enumerate(groups):
            valid=[r for r in group if r.get(field) is not None];missing.append(8-len(valid))
            for k,r in enumerate(valid):
                good=r['both_safe_timely'];xx=i+(k-(len(valid)-1)/2)*.045
                bx.scatter(xx,r[field]*1000,s=25,marker='o' if good else 'x',color='#D55E00' if good else '#777777',zorder=3)
        bx.axhline(0,color='#777777',lw=.7)
        if panel==0:bx.axhline(.2,color='#009E73',ls='--',lw=1,label='0.20 mm target')
        bx.set_xticks(range(3),names);bx.set_xlim(-.45,2.45);bx.set_ylabel(ytitle)
        label(bx,letter,'Negative RR: same-gamma task use' if panel==0 else 'Integral does not increase')
        bx.text(.03,.97,'8 snapshots / 4 episodes\nMissing: '+', '.join(map(str,missing)),transform=bx.transAxes,va='top',fontsize=8)
        bx.margins(y=.30)
        if panel==0:bx.legend(loc='lower left',frameon=False)
    fig.suptitle('STEP47 | Fresh CAL, independent online TEST',fontsize=11)
    fig.text(.5,.015,'Filled circles: both complete, safe and timely; crosses: observed but unqualified. Missing is not zero.',ha='center',fontsize=8)
    fig.set_layout_engine('constrained',h_pad=.11,w_pad=.09,rect=(0,.045,1,.97))
    write(out/'figures/FIG1_DATA.json',dict(chain=plotted,task_pairs=groups))
    return fig

def ecdf(ax,data,color,ls,label_,marker=None):
    a=np.sort(np.asarray(data,float));a=a[np.isfinite(a)]
    if len(a):ax.step(a,np.arange(1,len(a)+1)/len(a),where='post',color=color,ls=ls,lw=1.15,label=label_,marker=marker,markersize=3,markevery=max(1,len(a)//8))
    return len(a)

def figure2(out,result):
    rows=read(out/'BRANCH_ROWS.json');capacity=read(out/'CAPACITY_EVENTS.json');latency=read(out/'LATENCY.json')
    by={r['id']:r for r in rows};contexts=[r for r in read(out/'C_TASK_ONLINE_PAIRS.json') if primary(r)]
    # Predetermined first negative RR source, not chosen for a successful result.
    p=contexts[0];snap=p['snapshot_id'];cid=p['context_id'];tline=[]
    fig,axs=plt.subplots(3,2,figsize=(7.16,9.2));letters='abcdef'
    for j,m in enumerate(METHODS):
        ax=axs[0,j];arms=[(snap+'_HEALTHY:'+m+':B','Healthy B'),(snap+'_RR_THIGH30:'+m+':B','Mild B'),(cid+':'+m+':B','Severe B'),(cid+':'+m+':ACTUAL','Own actual')]
        for i,(rid,title) in enumerate(arms):
            r=by[rid];cc=[a for a in capacity if a['id']==rid]
            applied=[a['time_s'] for a in cc if a['command_applied']]
            if applied:ax.plot([min(applied),max(applied)],[i,i],color='#999999',lw=2)
            else:ax.text(.02,i,'not applied',va='center',fontsize=8,color='#777777')
            sent=[a['time_s'] for a in cc if a['sent_99percent'] and a['command_applied']]
            actual=[a['time_s'] for a in cc if a['actual_99percent'] and a['command_applied']]
            if sent:ax.scatter(min(sent),i+.1,marker='^',color=COLORS[m],s=30,zorder=3)
            if actual:ax.scatter(min(actual),i-.1,marker='o',color=COLORS[m],s=25,zorder=3)
            failure=r.get('first_dense_failure_s')
            if failure is not None:ax.scatter(failure,i,marker='x',color='#111111',s=35,zorder=4)
            tline.append(dict(id=rid,applied_first=min(applied) if applied else None,applied_last=max(applied) if applied else None,sent99=min(sent) if sent else None,actual99=min(actual) if actual else None,first_dense_failure=failure,outcome=r['outcome']))
        ax.set_yticks(range(4),[a[1] for a in arms]);ax.set_ylim(3.4,-.4);ax.set_xlim(-.02,1.06);ax.set_xlabel('Physical time (s)')
        label(ax,letters[j],m.replace('_MATCHED','')+' capacity / failure timeline')
        ax.text(.02,.98,'Fixed source: '+snap,transform=ax.transAxes,fontsize=7,va='top')
    axs[0,1].legend(handles=[Line2D([],[],marker='^',ls='',color='#777777',label='Sent / effective >=99%'),Line2D([],[],marker='o',ls='',color='#777777',label='Applied / effective >=99%'),Line2D([],[],marker='x',ls='',color='#111111',label='First dense failure')],loc='upper center',bbox_to_anchor=(.5,-.26),frameon=False,fontsize=7)
    ax=axs[1,0];pre=[r for r in latency if r['kind']=='PREPARATION' and r['split']=='TEST'];missing=0
    for m in METHODS:
        own=[r for r in pre if r['method']==m];missing+=sum(r.get('complete_ms') is None or r.get('prepared_ms') is None for r in own)
        for applied in (True,False):
            rr=[r for r in own if r['applied']==applied and r.get('complete_ms') is not None and r.get('prepared_ms') is not None]
            ax.scatter([r['prepared_ms'] for r in rr],[r['complete_ms'] for r in rr],s=14,marker=MARKERS[m] if applied else 'x',color=COLORS[m],alpha=.7)
    ax.axvline(17,color='#777777',ls='--',lw=.8);ax.axhline(20,color='#777777',ls=':',lw=.8)
    ax.set_xlabel('Prepared first command (ms)');ax.set_ylabel('Complete first command (ms)');ax.set_xlim(left=0);ax.set_ylim(bottom=0)
    label(ax,'c','All TEST first-command windows')
    ax.text(.03,.97,f'n={len(pre)}; missing={missing}\nShapes: applied; x: unapplied\nReserve 17 / complete 20 ms',transform=ax.transAxes,va='top',fontsize=8)
    stats=[]
    for ax,kind,split,letter,title in [(axs[1,1],'FEEDBACK','TEST','d','All TEST feedback windows'),(axs[2,0],'PREPARATION','CAL','e','CAL first commands: offline only'),(axs[2,1],'FEEDBACK','CAL','f','CAL feedback: offline only')]:
        own=[r for r in latency if r['kind']==kind and r['split']==split]
        for m in METHODS:
            ss=[r for r in own if r['method']==m]
            for field,ls,short in [('complete_ms','-','complete'),('prepared_ms','--','prepared')]:
                data=[r[field] for r in ss if r.get(field) is not None]
                n=ecdf(ax,data,COLORS[m],ls,m.replace('_MATCHED','')+' '+short,MARKERS[m])
                stats.append(dict(split=split,kind=kind,method=m,measure=field,planned_saved_windows=len(ss),observed=n,missing=len(ss)-n))
        ax.axvline(17,color='#777777',ls='--',lw=.7);ax.axvline(20,color='#777777',ls=':',lw=.7)
        ax.set_ylim(0,1.04);ax.set_xlabel('Measured latency (ms)');ax.set_ylabel('Empirical cumulative fraction')
        ax.set_xscale('log');ax.set_xlim(left=.1)
        label(ax,letter,title)
        missing_complete=sum(r.get('complete_ms') is None for r in own)
        missing_prepared=sum(r.get('prepared_ms') is None for r in own)
        ax.text(.02,.97,f'Planned n={len(own)}\nMissing C/P: {missing_complete} / {missing_prepared}',transform=ax.transAxes,va='top',fontsize=8)
        if letter=='f':ax.legend(loc='lower right',frameon=False,fontsize=7)
    fig.suptitle('STEP47 | Capacity chronology and every saved timing window',fontsize=11)
    fig.text(.5,.012,'No rejected command is counted as applied. Missing windows are disclosed; offline CAL is not online evidence.',ha='center',fontsize=8)
    fig.set_layout_engine('constrained',h_pad=.12,w_pad=.09,rect=(0,.035,1,.97))
    write(out/'figures/FIG2_DATA.json',dict(fixed_source=cid,timelines=tline,latency_profiles=stats))
    return fig

def embedded_fonts(pdf):
    try:from pypdf import PdfReader
    except ImportError:from PyPDF2 import PdfReader
    found=[]
    for page in PdfReader(pdf).pages:
        for f in page['/Resources']['/Font'].get_object().values():
            obj=f.get_object();children=obj.get('/DescendantFonts',[])
            for font in [obj]+[c.get_object() for c in children]:
                descriptor=font.get('/FontDescriptor');embedded=False
                if descriptor:embedded=any(k in descriptor.get_object() for k in ('/FontFile','/FontFile2','/FontFile3'))
                found.append(dict(base=str(font.get('/BaseFont')),subtype=str(font.get('/Subtype')),embedded=embedded,composite_parent=bool(children)))
    return found

def run(export=False):
    out=output();folder=out/'figures';folder.mkdir(exist_ok=True);result=read(out/'STEP47_RESULT.json')
    style=setup_style('ieee',lang='en',use_sciplots=False)
    plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],'font.size':8,'xtick.labelsize':8,'ytick.labelsize':8,'legend.fontsize':8,'axes.titlesize':9,'axes.spines.top':False,'axes.spines.right':False})
    profiles={}
    for name,cols,groups in [('BRANCH_ROWS',['split','method','kind','arm','complete_501','timing_qualified','terminal_abs_external_error_m','abs_external_error_integral_m_s'],['split','method','kind']),('LATENCY',['split','method','kind','complete_ms','prepared_ms','applied'],['split','method','kind'])]:
        frame=pd.DataFrame(read(out/(name+'.json')))[cols]
        profile=profile_data(frame,groups);profiles[name]=profile
        (folder/(name+'_PROFILE.md')).write_text(render_report(profile),encoding='utf-8')
    write(folder/'DATA_PROFILES.json',profiles)
    figs=[('FIG1_ACCEPTANCE_TASK_USE',figure1(out,result),(7.16,6.5)),('FIG2_CAPACITY_TIMING',figure2(out,result),(7.16,9.2))]
    qa=[]
    for name,fig,size in figs:
        layout=audit_layout(fig);preview=render_preview(fig,str(folder/(name+'_preview.png')),dpi=165)
        entry=dict(name=name,layout=layout,preview=preview,style=style,publication_size_inches=size)
        if export:
            if any(severity=='FAIL' for severity,_ in layout):raise ValueError('figure layout failed')
            paths=export_figure(fig,str(folder/name),formats=['pdf','png'],dpi=600,size_inches=size,grayscale_preview=False,tight=False)
            png=folder/(name+'.png')
            with Image.open(png) as im:im.convert('L').save(folder/(name+'_grayscale.png'),dpi=(600,600))
            entry['files']={str(Path(p).name):sha(p) for p in paths}
            entry['compliance']=[dict(path=p,issues=check_figure(p,min_dpi=600,target_inches=size)[0],info=check_figure(p,min_dpi=600,target_inches=size)[1]) for p in paths]
            entry['PDF_font_descendants']=embedded_fonts(folder/(name+'.pdf'))
        qa.append(entry);plt.close(fig)
    write(folder/('EXPORT_QA.json' if export else 'PREVIEW_QA.json'),qa)
    print(dict(figures=2,exported=export,layout_issues=[q['layout'] for q in qa]),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--export',action='store_true');run(parser.parse_args().export)
