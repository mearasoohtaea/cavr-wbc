"""Chinese STEP47 delivery derived exclusively from current durable results."""
from collections import Counter
from datetime import datetime,timezone
import numpy as np
from cavr_wbc.experiments.step47_io import *
from cavr_wbc.experiments.step47_inputs import METHODS

def table(headers,rows):
    return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+['| '+' | '.join(str(v) for v in r)+' |' for r in rows])
def text_file(path,body):
    path=require_output(path);path.write_text(body.rstrip()+'\n',encoding='utf-8',newline='\n')
def span(values,scale=1):
    a=[float(v)*scale for v in values if v is not None and np.isfinite(v)]
    return '无完整配对数值' if not a else f'{min(a):.6g}–{max(a):.6g}'
def primary(r):return r.get('direction')==-1 and r.get('fault_leg')=='RR'

def run():
    out=output();r=read(out/'STEP47_RESULT.json');e=r['endpoints'];budget=r['run']['budget'];rows=read(out/'BRANCH_ROWS.json')
    dec=read(out/'ONLINE_DECISIONS.json');cal=read(out/'STEP47_CAL_FREEZE.json');lat=read(out/'LATENCY.json')
    tests=read(out/'tests/NECESSARY_TESTS.json');qa=read(out/'figures/EXPORT_QA.json')
    P=read(out/'TASK_PAIRS.json');online=read(out/'ONLINE_TASK_PAIRS.json');packages=read(out/'LEARNED_PACKAGE_PAIRS.json')
    C=read(out/'C_TASK_ONLINE_PAIRS.json');R=read(out/'R_LEGACY_PAIRS.json');backup=read(out/'BACKUP_CLASSIFICATION.json');F=read(out/'F_COMPONENT_PAIRS.json')
    verification=read(out/'FINAL_VERIFICATION.json',{})
    lines=dict(AUTHORIZE_STEP47_POLICY_MATCHED_CAL_AND_FRESH_ONLINE_TEST='TRUE',SOURCE_STEP46_P='ESTABLISHED_LOCAL_DEV',
        SOURCE_STEP46_R='NOT_ESTABLISHED',SOURCE_STEP46_BINARY_VERDICT='UNRECORDED_UNCHANGED',
        STEP47_BACKUP_POLICY_UNCHANGED='TASK_AWARE_1MM_06S_V1',STEP47_METHODS='HOLD_MATCHED,TASK_MATCHED',
        STEP47_NEW_CAL_PLANNED=128,STEP47_CAL_ROWS_PER_POLICY_GAMMA=32,STEP47_NEW_TRAIN=0,STEP47_NEW_MODEL_FITS=0,
        STEP47_OLD_CAL_LABELS_USED=0,STEP47_CAL_REFERENCE_EPISODES=8,STEP47_TEST_REFERENCE_EPISODES=8,
        STEP47_TEST_SEVERE_CONTEXTS=32,STEP47_ONLINE_DECISIONS_PLANNED=64,STEP47_DIRECT_BRANCHES_PLANNED=224,
        STEP47_MAX_NEW_1S_BRANCHES=416,STEP47_COMPLETE_WALL_DEADLINE_MS=20,STEP47_PREPARED_RESERVE_MS=17,
        STEP47_S_ACCEPTANCE=e['S']['TASK_MATCHED']['status'],STEP47_S_HOLD_ACCEPTANCE=e['S']['HOLD_MATCHED']['status'],
        STEP47_P_LOCAL_TASK_USE=e['P']['status'],STEP47_C_TASK_ONLINE_CAPACITY=e['C_TASK_ONLINE']['status'],
        STEP47_R_LEGACY_CROSS_POLICY=e['R_LEGACY_CROSS_POLICY']['status'],
        STEP47_RESEARCH_CLOSURE=r['research_status'],STEP47_EXECUTION_INTEGRITY=r['integrity'],
        STEP47_BINARY_VERDICT=r['readback']['binary_status'],STEP47_EVALUATION_VERDICT=r['readback']['evaluation_status'],
        STEP47_INDEPENDENT_NUMERICAL_REPRODUCTION='UNVERIFIED_NOT_REPEATED',
        FULL_TASK_COMPLETION_ESTABLISHED='FALSE',HARD_REALTIME_DEPLOYMENT_ESTABLISHED='FALSE',
        HISTORICAL_RESULTS_UNCHANGED='TRUE' if r['readback']['source_readonly_unchanged'] else 'FALSE',E3_AUTHORIZED='FALSE',RL_HARDWARE_AUTHORIZED='FALSE')
    ini='\n'.join(k+' = '+str(v) for k,v in lines.items());text_file(out/'PROTOCOL_STATUS.ini',ini)
    online_summary=[]
    for m in METHODS:
        s=e['S'][m];online_summary.append([m,32,s['recognized'],s['sent'],s['complete_safe_timely'],s['complete_wrong_accepts'],s['sent_partial'],s['abstain'],s['late'],s['status']])
    coverage=[]
    for name in ('CAL','TEST_direct','TEST_online'):
        a=r[name];coverage.append([name,a['planned'],a['attempted'],a['complete_501'],a['complete_physical_pass'],a['complete_physical_terminal'],a['complete_safe_6mm'],a['timing_qualified']])
    cal_groups=[];domain=[]
    for m,record in cal['methods'].items():
        for key,g in record['groups'].items():
            cal_groups.append([m,key,g.get('CAL_planned'),g.get('CAL_finite'),g.get('CAL_complete'),g.get('CAL_complete_distinct_snapshots'),g.get('CAL_complete_episodes'),g.get('CAL_complete_physical_failures'),g.get('local_calibrated')])
        for key,g in record['domain_groups'].items():domain.append([m,key,g.get('planned'),g.get('finite'),g.get('complete'),g.get('ready')])
    endpoints=[]
    for key in ('P','C_TASK_ONLINE','R_LEGACY_CROSS_POLICY'):
        support=e[key]['support'];endpoints.append([key,e[key]['status'],support['contexts'],support['physical_snapshots'],support['independent_episodes']])
    firsttime=datetime.fromisoformat(budget['numerical_started_utc']);finish=datetime.fromisoformat(r['run']['finish_utc'])
    timing=[]
    for split in ('CAL','TEST'):
        for kind in ('PREPARATION','FEEDBACK'):
            for m in METHODS:
                own=[x for x in lat if x['split']==split and x['kind']==kind and x['method']==m]
                values=[x['complete_ms'] for x in own if x.get('complete_ms') is not None]
                prepared=[x['prepared_ms'] for x in own if x.get('prepared_ms') is not None]
                timing.append([split,kind,m,len(own),len(values),len(own)-len(values),sum(x>20 for x in values),sum(x>17 for x in prepared),span(values)])
    failures=Counter(str(q.get('rejection_reasons')) for d in dec for q in d['queries'] if q.get('rejection_reasons'))
    query_status=Counter(q.get('evaluation_status') for d in dec for q in d['queries'])
    false_gates=Counter(k for d in dec for q in d['queries'] for k,v in (q.get('numeric') or {}).items() if k.endswith('_gate') and v is False)
    late=sum(d['late'] for d in dec);wrong=e['S']['TASK_MATCHED']['complete_wrong_accepts'];partial=e['S']['TASK_MATCHED']['sent_partial']
    if e['closure_established']:
        conclusion='学习筛选—真实同 owner 执行链在预定局部范围内建立 S、P 与 C_TASK_ONLINE；旧 R 定义独立列示。'
        next_design='恢复终端与继续原外部任务阶段的衔接，采用更长时域的阶段式任务参考；本轮不启动。'
    elif r['integrity']=='INVALID_EVIDENCE':
        conclusion='固定批次证据存在实现或持久化一致性问题，不能建立本轮研究闭合。具体 issue 原样保留。'
        next_design='只修复本轮已保存 issue 指向的语义或持久化接口，再另行冻结新的确认协议；本轮不重派任何位置。'
    elif wrong or partial:
        conclusion='本轮未建立接收链闭合：真实发送后的错受或不完整执行使有限接受可靠性未达到。'
        next_design='将故障后完整反馈执行约束纳入接受预测，先解决已保存错受/partial 对应的执行一致性问题；不放宽阈值。'
    elif e['S']['TASK_MATCHED']['sent']==0:
        conclusion='固定 TEST 已保留真实认可、拒收与未发送结果；TASK 无发送或支持/筛选未通过，不能建立 S 与在线容量恢复。'
        next_design='围绕本轮保存的原接受门拒收，为 TASK 建立预冻结的匹配 proposal/TRAIN 支持，而非仅替换 CAL；不追加本轮 CAL 追求过门。' if late<sum(d['status']=='ABSTAIN' for d in dec) else '将首包预准备与真实 commit/apply 链做持久化接口整合，保留 17/20 ms 原门和拒收语义，再单独冻结确认。'
    else:
        conclusion='本轮有限接收链未全部成立；任务用途、容量失效证据及在线时延按各自端点分别判断。'
        primary_task=[d for d in dec if d['method']=='TASK_MATCHED' and primary(d)]
        if sum(d['status']=='ABSTAIN' for d in primary_task)>sum(d['late'] for d in primary_task):
            next_design='建立 TASK policy 匹配的冻结 proposal/TRAIN 与终端预测支持，针对已保存的负向 RR 候选接受门验证，而非继续追加本轮 CAL；随后另行独立确认。'
        else:
            next_design='围绕容量四方及时共存链设计持久化首包预准备接口；保留同 policy、原物理门和 17/20 ms 拒收语义，随后另行冻结确认。'
    task_middle=[q for q in P if primary(q) and q['arm']=='MIDDLE'];goodP=[q for q in task_middle if q['task_use_target_met']]
    goodOwn=[q for q in online if primary(q) and q['task_use_target_met']]
    packageGamma=Counter(str((q['left_gamma'],q['right_gamma'])) for q in packages)
    ftable=[]
    for m in METHODS:
        own=[q for q in F if q['method']==m and primary(q)]
        ftable.append([m,len(own),sum(q['both_complete'] for q in own),sum(q['both_safe_timely'] for q in own),span([q['first_base_gain_m'] for q in own],1000),span([q['terminal_error_improvement_m'] for q in own],1000),span([q['integral_improvement_m_s'] for q in own],1000),span([q['left_terminal_vx_m_s'] for q in own],1000)])
    report=f'''# STEP47：策略匹配 CAL 与 fresh 在线确认

{conclusion}

研究状态：`{r['research_status']}`；执行状态：`{r['integrity']}`。这两个状态分别表示研究端点和固定批次执行完整性，不能互相替代。

## 范围与冻结方法

Material Passport：experiment-agent / academic-research-suite（ARS）；2026-10-12，韩国时间；目标 T-RO。执行依据为 [完整协议](../../../configs/STEP47_EXECUTION_PROTOCOL.md)。独立数值复现未运行，verification=`UNVERIFIED_NOT_REPEATED`；本轮二进制解码与独立冻结评价比较见下文。

工作树：`{OUTPUT_ROOT_D.as_posix()}`。分支：`codex/step47-policy-matched-online-confirmation-20261012`。源提交：`{SOURCE_COMMIT}`。本轮 run_id：`{RUN_ID}`。

HOLD_MATCHED 使用原 HOLD，TASK_MATCHED 使用不变的 TASK_AWARE_1MM_06S_V1：1 mm cap、0.60 s ramp、physical .02 s 起、.62 s 后停止。两侧均使用原 28 维预测器、normalizer 与全部 TRAIN；各自采用 64 行 fresh-only CAL 与独立冻结 domain，gamma=.5/0 每侧各 32 行。TASK 的 TRAIN 仍来源 HOLD，本轮比较匹配后的完整方法包，不将全部差异单独归因于参考或 CAL。

TEST 决定在各自 source 的 direct 标签之前不可变保存，两份决定都保存后才推进 own ACTUAL。TASK reset 同时绑定 live/staging/backup 的同一 source、goal、clock 与 backup ID；nominal 任务和原评价 anchor 不变。CALL 前拒绝跨 policy bundle/domain，0 新 TRAIN、0 模型 fit、0 旧 CAL 标签、0 旧实验重跑。

## 完整分母与实际覆盖

{table(['位置','计划','观察到轨迹','501点完整','physical','physical+terminal','safe 6mm','在线全部及时'],coverage)}

CAL 为 OFFLINE_PHYSICS_ORACLE，`timing_qualified=False`；其完整标签不能计为在线恢复。TEST 首包和 feedback 迟到均拒绝施加。未发送、partial、数值失败、物理失败、ABSTAIN 全部保留，未将缺测补成失败或成功。CAL 8 / TEST 8 独立 reference episode 分开记录；同 source 跨 policy/gamma 不增加独立样本数。完整支持矩阵见 [SUPPORT_MATRIX.csv](SUPPORT_MATRIX.csv)。

{table(['方法','计划','认可','发送','完整安全及时','完整错受','已发送partial','ABSTAIN','late','S'],online_summary)}

## 本轮 CAL 与 domain

{table(['方法','group','计划','有限特征','完整','独立snapshot','episode','完整物理失败','local calibrated'],cal_groups)}

{table(['方法','domain stratum','计划','finite','complete','ready'],domain)}

完整状态/失败及参数身份见 [STEP47_CAL_FREEZE.json](STEP47_CAL_FREEZE.json)、[CAL_ROWS.json](CAL_ROWS.json)、[CAL_DOMAIN_ROWS.json](CAL_DOMAIN_ROWS.json)。未使用角色无本轮支持；readiness 仅约束原对应组，无新增全局 veto。TEST 未更新这些 CAL/domain/model 文件。

## P、C_TASK_ONLINE 与旧 R 的独立判定

{table(['端点','状态','合格context','physical snapshot','whole episode'],endpoints)}

负向 RR severe MIDDLE 同 gamma 配对共有 8 个计划 snapshot / 4 episode，其中用途门合格 {len(goodP)} 个。完整末外部任务误差改善范围 {span([q['terminal_error_improvement_m'] for q in task_middle],1000)} mm，误差积分改善 {span([q['integral_improvement_m_s'] for q in task_middle],1000)} mm·s；只有两侧完整安全及时且改善 ≥0.20 mm、积分不增才计端点。

TASK own ACTUAL 对同 source、同 gamma HOLD direct 的负向 RR 用途配对合格 {len(goodOwn)} 个，独立保存在 [ONLINE_TASK_PAIRS.csv](ONLINE_TASK_PAIRS.csv)。两 learned 包的实际对照见 [LEARNED_PACKAGE_PAIRS.csv](LEARNED_PACKAGE_PAIRS.csv)；gamma 对分布 `{dict(packageGamma)}`，不同 gamma 明确为方法包比较。

C 要求 TASK 自身 healthy/mild B 完整安全及时、severe B 完整物理失败且 sent/effective 和 applied/effective ≥99% 事件均严格早于首个 dense 失败，并要求 timely gamma=.5 own ACTUAL 安全及同 gamma HOLD 用途配对。本轮其他腿/方向亦完整保存在 [C_TASK_ONLINE_PAIRS.csv](C_TASK_ONLINE_PAIRS.csv)。R_LEGACY_CROSS_POLICY 采用 HOLD 自身 Type-II 加 TASK MIDDLE/P 共存门，未回写 STEP46 旧 R。

TASK_BACKUP_SAFE 共 {sum(x['TASK_BACKUP_SAFE'] for x in backup)} 个 source；COMPARATIVE_BACKUP_ONLY_RECOVERY 共 {sum(x['COMPARATIVE_BACKUP_ONLY_RECOVERY'] for x in backup)} 个。后者必须有 HOLD 真实完整物理失败及容量先发生，不能用 HOLD 迟到/缺测替代。详见 [BACKUP_CLASSIFICATION.csv](BACKUP_CLASSIFICATION.csv)。

## F：首动作与末任务分量

{table(['policy','负向RR计划','两侧完整','两侧safe timely','middle-B首base mm','B-middle末误差 mm','B-middle积分 mm s','middle末vx mm/s'],ftable)}

首动作、末外部任务误差、误差积分及停止速度分别给出。没有预设 middle 全任务更优，B 的物理失败亦不能作为安全替代。完整 F 分量在 [F_COMPONENT_PAIRS.csv](F_COMPONENT_PAIRS.csv)；clipped 参考跟踪误差仅另列，不替代原外部任务指标。

## 时延与容量时序

{table(['split','窗口','方法','保存窗口','有完整时延','缺完整时延','完整>20 ms','prepared>17 ms','完整时延范围ms'],timing)}

TEST late 认可/决定 {late} 条；晚于冻结门而实际施加的 TEST 窗口 {r['late_TEST_windows_applied']} 个。TASK physical clock 数值检查 {r['TASK_clock_checks']} 条，失败 {r['TASK_clock_failures']} 条。所有保存时延见 [LATENCY.csv](LATENCY.csv)，容量 sent/actual 事件见 [CAPACITY_EVENTS.csv](CAPACITY_EVENTS.csv)。拒收不是失控，未施加不是物理失败。

在线候选评价状态计数：`{dict(query_status)}`。保存的拒收原因计数：`{dict(failures)}`。独立 numeric gate 为 FALSE 的计数：`{dict(false_gates)}`。这些用于区分未到达候选评价、CAL/域支持、原接受门和时延；未评价候选不猜测其结果。

## 预算、测试与本轮证据读回

数值起点 `{firsttime.isoformat()}`，结束 `{finish.isoformat()}`；实际数值墙钟 {budget['numerical_elapsed_s']:.3f} s / 7200 s。QP {budget['total_QP_calls']} / 35000；积分 {budget['total_physics_steps']} / 320000，包含 reference、startup、endpoint、application、prefix 与 feedback。0 新 fit。所有 QP START/RETURN/raw 序号和哈希见 [STEP47_LEDGER.jsonl](STEP47_LEDGER.jsonl) 与本轮 readback。

一次必要 pure group 共 {tests['tests_run']} fixture；初次的一项 metadata 命名错误已保留记录并只重跑受影响 fixture，最终 {tests['failures']} failures / {tests['errors']} errors；0 QP / 0 积分。命令和初始结果在 [tests/COMMANDS.json](tests/COMMANDS.json)、[tests/INITIAL_TEST_RESULTS.json](tests/INITIAL_TEST_RESULTS.json)、[tests/NECESSARY_TESTS.json](tests/NECESSARY_TESTS.json)。

逐 shard 立即 hash/完整数值解码/冻结独立评价比较，先保存 JSON issues 与 receipt，CSV 后导。随后执行一次当前 streaming readback：`{r['readback']['status']}`；binary=`{r['readback']['binary_status']}`；evaluation=`{r['readback']['evaluation_status']}`；issues={len(r['readback']['issues'])}。读回 0 新 QP、0 积分、0 fit，未重跑数值。完整结果见 [CURRENT_RUN_READBACK.json](CURRENT_RUN_READBACK.json)、[CURRENT_SHARD_READBACK.jsonl](CURRENT_SHARD_READBACK.jsonl) 和 [STEP47_RESULT.json](STEP47_RESULT.json)。

当前 issues：`{r['readback']['issues']}`。原 STEP46 P=ESTABLISHED_LOCAL_DEV、R=NOT_ESTABLISHED、binary/eval=UNRECORDED_UNCHANGED，未追加历史复审。源 HEAD/index/证据限定比较见 [FINAL_VERIFICATION.json](FINAL_VERIFICATION.json)。

## SciPilot 两图

数据先 profile，按 episode/snapshot 分组。图 1 采用计数点图和全部原始配对点；不画小样本均值柱，不将 snapshot 当独立 episode。图 2 采用固定首个负向 RR source 的四方时间线及所有窗口散点/ECDF，不按结果选择代表 source，CAL 离线时延独立展示。600 dpi、IEEE 7.16 in、TrueType PDF、灰度冗余 marker/linestyle；程序和视觉检查见 figures 中的 QA。

![图1：认可链及同gamma任务用途](figures/FIG1_ACCEPTANCE_TASK_USE.png)

![图2：容量四方时序与全体时延](figures/FIG2_CAPACITY_TIMING.png)

[图1 PDF](figures/FIG1_ACCEPTANCE_TASK_USE.pdf)；[图2 PDF](figures/FIG2_CAPACITY_TIMING.pdf)。数值与缺测原表保存在图数据 JSON，不追加求解补图。

## 交接与停止

下一项设计：{next_design}

本轮结束，不自动开始后续批次。±60余 mm 完整任务、长期持续运行、全故障泛化及硬实时部署未建立；E3、RL、硬件未授权。未推送，提交仅本轮新实现/协议/测试/工件，提交号见最终交付消息。

```ini
{ini}
```
'''
    text_file(out/'REPORT.md',report)
    handoff=f'''# STEP47 研究交接

{conclusion}

唯一当前结果：[STEP47_RESULT.json](STEP47_RESULT.json)；中文报告：[REPORT.md](REPORT.md)；协议状态：[PROTOCOL_STATUS.ini](PROTOCOL_STATUS.ini)。

工作树 `{OUTPUT_ROOT_D.as_posix()}`，分支 `codex/step47-policy-matched-online-confirmation-20261012`，源 `{SOURCE_COMMIT}`；run_id `{RUN_ID}`。本轮源码/输入/方法 freeze 和两独立 CAL/domain 已冻结。数值批次 `{r['run']['status']}`，科学端点 `{r['research_status']}`。不得将研究未成立当作准许补跑。

两方法 S 分别为 HOLD `{e['S']['HOLD_MATCHED']['status']}` / TASK `{e['S']['TASK_MATCHED']['status']}`；P `{e['P']['status']}`；C `{e['C_TASK_ONLINE']['status']}`；旧定义 R `{e['R_LEGACY_CROSS_POLICY']['status']}`。原 STEP46 P/R/binary 判定保持不变。

下一项设计仅建议：{next_design}

不要重跑已派发 CAL/TEST、旧 STEP46 或历史证书；不要扩大支持、改变门槛或混用两策略 CAL/domain。当前 readback 已完成一次，不再遍历原始 bank 复验；派生图表只读本轮已保存 JSON。未开展独立数值复现（UNVERIFIED）。本轮所有 ordinary FAIL/partial/late/ABSTAIN 与 ledger 保留。

Material Passport：experiment-agent / ARS；2026-10-12 KST；SciPilot 两图。全部验证命令/修正 pure fixture/实际修改清单及 Git 状态在 tests/ 与 FINAL_VERIFICATION.json。仅提交本轮范围，不 push。E3=FALSE、RL/hardware=FALSE。
'''
    text_file(out/'HANDOFF.md',handoff)
    write(out/'PACKAGE_RECEIPT.json',dict(timestamp_utc=datetime.now(timezone.utc).isoformat(),research_status=r['research_status'],report_sha256=sha(out/'REPORT.md'),handoff_sha256=sha(out/'HANDOFF.md'),protocol_status_sha256=sha(out/'PROTOCOL_STATUS.ini'),new_QP=0,new_steps=0,new_fits=0))
    print(dict(research_status=r['research_status'],integrity=r['integrity'],report=str(out/'REPORT.md')),flush=True)
if __name__=='__main__':run()
