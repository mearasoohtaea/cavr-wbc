"""One non-numerical D/import/write check and source-config snapshot."""
from copy import deepcopy
import os,shutil
from cavr_wbc.experiments.step47_io import *
from cavr_wbc.experiments.step47_inputs import *
from cavr_wbc.control import step39_margin as margin
def prepare():
    out=output();out.mkdir(parents=True,exist_ok=True)
    if (out/'PREPARATION.json').exists():raise FileExistsError('one environment check only')
    import cavr_wbc,mujoco,osqp,scipy,threadpoolctl
    if not Path(cavr_wbc.__file__).resolve().is_relative_to(OUTPUT_ROOT_D):raise ValueError('wrong package')
    write(out/'PREPARATION.json',dict(package=cavr_wbc.__file__,D_free_bytes=shutil.disk_usage(OUTPUT_ROOT_D).free,
        D_write_marker=True,TMP=os.environ['TMP'],TEMP=os.environ['TEMP'],MPLCONFIGDIR=os.environ['MPLCONFIGDIR'],
        new_QP=0,new_physics=0,versions=dict(mujoco=mujoco.__version__,osqp=osqp.__version__,numpy=np.__version__,scipy=scipy.__version__),threadpools=threadpoolctl.threadpool_info()))
    source=SOURCE_ROOT_D/'artifacts/step46_task_aware_backup_20261011/step46-task-aware-backup-pilot-20261011-01'
    config=read(source/'SOURCE_FROZEN_CONFIG.json')
    config.update(feature_names=list(margin.FEATURE_NAMES),feature_dimension=28)
    write(out/'SOURCE_FROZEN_CONFIG.json',config)
    write(out/'SOURCE_READONLY_BASELINE.json',dict(source_commit=SOURCE_COMMIT,source_worktree=str(SOURCE_ROOT_D),
        source_result_sha256=sha(source/'STEP46_RESULT.json'),source_index_sha256=sha(SOURCE_ROOT_D/'.git/index'),
        source_config_sha256=sha(source/'SOURCE_FROZEN_CONFIG.json'),source_history_not_reaudited=True,
        STEP46_P='ESTABLISHED_LOCAL_DEV',STEP46_R='NOT_ESTABLISHED',STEP46_binary_eval='UNRECORDED'))
    write(out/'INPUTS_PLAN.json',dict(CAL_episodes=episodes('CAL'),TEST_episodes=episodes('TEST'),
        CAL_contexts=plans('CAL'),TEST_contexts=plans('TEST'),positions=positions('CAL')+positions('TEST'),
        CAL_planned=128,TEST_contexts_planned=80,decisions_planned=64,direct_planned=224,online_actual_max=64,
        branch_max=416,reference_episodes=16,new_TRAIN=0,new_fits=0,max_wall_s=7200,max_QP=35000,max_steps=320000))
    print(dict(prepared=True,CAL=128,decisions=64,direct=224,QP=0,physics=0),flush=True)
if __name__=='__main__':prepare()
