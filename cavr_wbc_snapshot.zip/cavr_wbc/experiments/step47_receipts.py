"""Authoritative binary/independent-frozen-evaluation receipts before export."""
import numpy as np
from cavr_wbc.experiments.step47_io import *
from cavr_wbc.control.step34_margin import labels
from cavr_wbc.experiments.step29_sim import _json_safe

def numeric_equal(a,b,atol=1e-12):
    return bool(np.shape(a)==np.shape(b) and np.allclose(a,b,rtol=0,atol=atol,equal_nan=True))
def compare_labels(saved,calculated):
    issues=[]
    for key in ('complete','full_501_grid','original_physical','original_terminal','observed_original_physical_failure'):
        if saved.get(key)!=calculated.get(key):issues.append('LABEL:'+key)
    for key in ('D_m','Y'):
        a,b=saved.get(key),calculated.get(key)
        if (a is None)!=(b is None) or a is not None and not numeric_equal(a,b):issues.append('LABEL:'+key)
    return issues
def evaluate(path,c,rec):
    from cavr_wbc.experiments.step47_storage import load_branch
    issues=[];binary='NOT_APPLICABLE_UNOBSERVED';ev='NOT_APPLICABLE_UNOBSERVED';branch=None
    if rec['observed']:
        binary='INVALID';ev='UNVERIFIED'
        for p,expected in ((path/'actual.npz',rec['artifact']['sha256']),
            (path/'controls.json',rec['controls_numeric']['json_sha256']),
            (path/'controls.npz',rec['controls_numeric']['npz_sha256'])):
            if sha(p)!=expected:issues.append('HASH:'+p.name)
        try:
            branch=load_branch(path);binary='HASH_AND_COMPLETE_NUMERIC_DECODE_VERIFIED' if not issues else 'INVALID'
            calculated=labels(branch,_json_safe(c));evaluation_issues=compare_labels(rec['label'],calculated)
            issues.extend(evaluation_issues);ev='INDEPENDENT_FROZEN_EVALUATION_MATCH' if not evaluation_issues else 'INVALID'
            if rec['complete_501'] and (branch.get('counts',{}).get('physical_steps')!=500 or len(branch.get('physics_trajectory',[]))!=500 or len(branch.get('checkpoints',[]))!=21):issues.append('GRID_500_501_21')
        except Exception as exc:issues.append(type(exc).__name__+':'+str(exc))
    receipt=dict(status='VERIFIED' if not issues else 'INVALID',binary_status=binary,evaluation_status=ev,
        issues=issues,no_solver=True,no_integration=True,numerical_reproduction='UNVERIFIED_NOT_REPEATED',
        result_sha256=sha(path/'RESULT.json'),observed=rec['observed'])
    return receipt,branch
def immediate(out,path,c,rec):
    receipt,branch=evaluate(path,c,rec)
    write(path/'SHARD_RECEIPT.json',receipt)
    append(out/'SHARD_RECEIPTS.jsonl',dict(path=relative(path,out),**receipt))
    if receipt['issues']:raise ValueError('saved scientific shard evidence mismatch: '+str(receipt['issues']))
