"""One fixed fresh policy-matched CAL/freeze/independent TEST run."""
from copy import deepcopy
from datetime import datetime,timezone
import gc,os,traceback
from cavr_wbc.experiments.step47_io import *
from cavr_wbc.experiments.step47_inputs import *
from cavr_wbc.experiments.step47_budget import SprintBudget,SprintLimit
from cavr_wbc.experiments.step47_storage import save_branch,not_run
from cavr_wbc.experiments.step47_binding import contracts
from cavr_wbc.experiments.step47_calibration import freeze,train_identity
from cavr_wbc.experiments.step35_reference import reference_episode
from cavr_wbc.experiments.step28_sprint import home_context
from cavr_wbc.experiments.step39_training import forward_entry,record
from cavr_wbc.experiments.step44_calibration import domain_record
from cavr_wbc.experiments.step44_identity import bundle_identity
from cavr_wbc.experiments import step17_formal_panel as frozen,step38_sim as sim
from cavr_wbc.control.step47_kernel import Kernel
from cavr_wbc.control.step46_kernel import experimental_packet
from cavr_wbc.control.step38_kernel import direct_packet
from cavr_wbc.control import step39_margin as margin

def event(out,name,**values):
    append(out/'ATTEMPT_LEDGER.jsonl',dict(event=name,timestamp_utc=datetime.now(timezone.utc).isoformat(),**values))
def make_owner(model,budget,c,manifest,contract,domain=None):
    k=Kernel(model,'BOUNDED',str(NATIVE_DLL),budget,task=contract['method']=='TASK_MATCHED',domain=domain,contract=contract)
    home=home_context(model,manifest['scenario'])
    home.update(context_id=c['context_id']+':'+contract['method']+':HOME',backup_id=c['backup_id']+':HOME')
    startup=k.startup(home,budget);k.flush_raw_evidence()
    return k,startup
def make_owners(model,budget,c,manifest,contract):
    owners={};startup={}
    for arm in ('C','MIDDLE','B'):owners[arm],startup[arm]=make_owner(model,budget,c,manifest,contract)
    return owners,startup
def source_contexts(out,split,model,manifest,budget):
    for ep in episodes(split):
        budget.check();event(out,'START',kind='REFERENCE',**ep)
        episode=reference_episode(model,manifest['reference_scenario'],ep['displacement_m'],ep['episode_id'],ep['snapshot_ticks'],budget,evidence_callback=budget.record_raw)
        for control in episode['controls']:control.pop('raw_solver_result',None)
        save_numeric(out/'episodes'/(ep['episode_id']+'.json'),episode)
        event(out,'RETURN',kind='REFERENCE',episode_id=ep['episode_id'],status=episode['status'],counts=episode['counts'])
        for p in (v for v in plans(split) if v['episode']==ep['episode_id']):
            c=context_for(p,episode,manifest['mapping'])
            save_numeric(out/split/c['context_id']/'SOURCE_IDENTITY.json',dict(plan=p,context=c))
            yield p,c
        del episode;gc.collect()
def missing_packet(c,m,gamma=None):
    return dict(context_id=c['context_id'],method=m,policy_contract=c['policy_contract'],policy_binding=None,
        selected_command_sent=False,model_authorized=False,experimental_dispatch=False,experimental_committed=False,
        status='SOURCE_INELIGIBLE',actions={},selected_gamma=gamma,command_ready_ms=None)
def record_position(out,path,p,c,packet,branch,kind,method,arm,saved,budget):
    result=save_branch(out,path,branch,c,packet,kind=='ONLINE')
    id=p['context_id']+':'+method+':'+arm;saved.add(id)
    append(out/'POSITION_INDEX.jsonl',dict(id=id,kind=kind,method=method,arm=arm,split=p['split'],
        context_id=p['context_id'],source_path=relative(out/p['split']/p['context_id']/'SOURCE_IDENTITY.json',out),
        policy_source_path=relative(path/'POLICY_CONTEXT.json',out),packet_path=relative(path/'PACKET.json',out),
        result_path=relative(path/'RESULT.json',out)))
    event(out,'RETURN',kind=kind,id=id,status=result['status'],complete=result['complete_501'])
    budget.persist(phase=kind+'_SAVED',completed_positions=len(saved),planned_positions=416,context_ordinal=p['ordinal'],method=method)
    return result
def run():
    out=output()
    if (out/'RUN_STARTED.json').exists():raise FileExistsError('unique run already dispatched; no numerical restart')
    tests=read(out/'tests/NECESSARY_TESTS.json')
    if tests is None or tests['errors'] or tests['failures']:raise ValueError('necessary pure tests not passed')
    manifest=read(out/'SOURCE_FROZEN_CONFIG.json')
    runtime={relative(p,OUTPUT_ROOT_D):sha(p) for p in OUTPUT_ROOT_D.glob('cavr_wbc/**/*.py')}
    method=dict(runtime_sha256=runtime,protocol_sha256=sha(PROTOCOL),scenario=manifest,
        CAL=plans('CAL'),TEST=plans('TEST'),deadline_ms=20.,prepared_ms=17.,new_fit=0)
    write(out/'METHOD_INPUT_FREEZE.json',method);binding=contracts(sha(out/'METHOD_INPUT_FREEZE.json'))
    old=margin.load_bundle(MODEL_NPZ);old_train=train_identity(old)
    manifest.update(run_id=RUN_ID,source_commit=SOURCE_COMMIT,policy_contracts=binding,
        max_wall_s=7200,max_QP=35000,max_physics_steps=320000,max_fits=0,new_TRAIN=0,new_CAL_planned=128,
        online_gamma_order=[.5,0.],source_model_sha256=sha(MODEL_NPZ),source_meta_sha256=sha(MODEL_NPZ.with_suffix('.json')),
        source_train_identity=old_train,source_predictor_identity=margin.identity(old),
        native_dll_sha256=sha(NATIVE_DLL),TASK_TRAIN_policy_matched=False,
        acceptance_algorithm_unchanged=True,old_CAL_removed=True,global_readiness_veto=False)
    write(out/'PROTOCOL_AND_MANIFEST.json',manifest)
    model=frozen.load_model();budget=SprintBudget(out);status='COMPLETED';saved=set();calrows=[];domains=[];start_pair=None
    write(out/'RUN_STARTED.json',dict(run_id=RUN_ID,pid=os.getpid(),start_utc=datetime.now(timezone.utc).isoformat(),
        command='cavr_wbc.experiments.step47_sprint',frozen_before_first_reference=True))
    try:
        for p,c in source_contexts(out,'CAL',model,manifest,budget):
            for m in METHODS:
                for arm,gamma in (('B',0.),('MIDDLE',.5)):
                    budget.check();ac=policy_context(c,m,binding[m],arm)
                    path=out/'CAL'/c['context_id']/m/arm
                    save_numeric(path/'POLICY_CONTEXT.json',ac)
                    event(out,'START',kind='CAL',context_id=c['context_id'],method=m,arm=arm)
                    owners={};k=None;entry=dict(features28=None,prefix=None,prehold=None,action={})
                    if c.get('eligible'):
                        owners,startup=make_owners(model,budget,ac,manifest,binding[m]);write(path/'STARTUP.json',startup)
                        k=owners['B' if gamma==0. else 'MIDDLE']
                        # Offline oracle: preserve real latency, never experimental commit.
                        packet=direct_packet(owners['B'],ac,budget,owners)
                        packet.update(method=m,policy_contract=binding[m],offline_CAL=True,
                            experimental_dispatch=False,experimental_committed=False,model_authorized=False,
                            selected_command_sent=False,dispatch_reason='OFFLINE_PHYSICS_ORACLE')
                        action=(packet['actions'].get(str(gamma)) or {}).get('action') or {}
                        valid=bool(action.get('command_valid') and action.get('execution_eligible'))
                        if valid:_,entry=forward_entry(k,packet,gamma,budget,'CAL')
                        owners['B'].flush_raw_evidence();k.flush_raw_evidence()
                    else:packet=missing_packet(ac,m,gamma);action={};valid=False
                    save_numeric(path/'PACKET.json',packet);save_numeric(path/'CAUSAL_PREFIX.json',entry)
                    event(out,'CAL_CAUSAL_INPUT_FROZEN',context_id=c['context_id'],method=m,arm=arm,future_not_started=True)
                    if valid:
                        budget.cal_attempted=getattr(budget,'cal_attempted',0)+1
                        branch=sim.propagate(k,ac,packet,budget,purpose='CAL_'+arm,action=action,require_sent=False)
                    else:branch=not_run(gamma,'CURRENT_PACKET_OR_SOURCE_UNAVAILABLE')
                    result=record_position(out,path,p,ac,packet,branch,'CAL',m,arm,saved,budget)
                    row=record(p,entry,result['label'],gamma,'CAL')
                    row.update(id='CAL:'+p['context_id']+':'+m+':'+arm,source_split='STEP47_FRESH_CAL',
                        source_method='STEP47_OFFLINE_PHYSICS_ORACLE',policy_contract=binding[m],offline_CAL=True)
                    save_numeric(path/'CAL_ROW.json',row);calrows.append(row)
                    hashes={relative(f,out):sha(f) for f in (path/'POLICY_CONTEXT.json',path/'PACKET.json',path/'CAUSAL_PREFIX.json',path/'RESULT.json')}
                    d=domain_record(p,row,entry,packet,result,manifest['mapping'],hashes);d['policy_contract']=binding[m];domains.append(d)
                    del owners,k,packet,branch,entry;gc.collect()
            print(dict(phase='CAL_CONTEXT_DONE',contexts=p['ordinal']+1,planned=32,positions=len(saved),budget=budget.snapshot()),flush=True)
        save_numeric(out/'CAL_ROWS.json',calrows);save_numeric(out/'CAL_DOMAIN_ROWS.json',domains)
        bundles,domain_by_method,calfreeze=freeze(out,old,calrows,domains,manifest['mapping'],binding)
        start_pair={m:bundle_identity(bundles[m]) for m in METHODS}
        budget.event('CAL_FROZEN_BEFORE_TEST',sha256=sha(out/'STEP47_CAL_FREEZE.json'),TEST_consumed=False)
        budget.persist(phase='CAL_FROZEN')
        for p,c in source_contexts(out,'TEST',model,manifest,budget):
            order=METHODS if (p['severe_ordinal'] or 0)%2==0 else METHODS[::-1]
            online={}
            if p['severe']:
                # Both matched decisions immutable before either future or direct.
                for m in order:
                    budget.check();ac=policy_context(c,m,binding[m],'ONLINE');path=out/'TEST'/c['context_id']/m/'ACTUAL'
                    save_numeric(path/'POLICY_CONTEXT.json',ac);event(out,'START',kind='DECISION',context_id=c['context_id'],method=m)
                    live=None
                    if c.get('eligible'):
                        live,startup=make_owner(model,budget,ac,manifest,binding[m],domain_by_method[m]);write(path/'STARTUP.json',startup)
                        decision=live.governor(ac,bundles[m],.006,budget);live.flush_raw_evidence()
                    else:decision=missing_packet(ac,m)
                    save_numeric(path/'PACKET.json',decision)
                    event(out,'DECISION_IMMUTABLE',context_id=c['context_id'],method=m,packet_sha256=sha(path/'PACKET.json'),
                        selected_command_sent=decision['selected_command_sent'],selected_gamma=decision.get('selected_gamma'),future_not_started=True)
                    online[m]=(live,ac,decision,path)
                event(out,'BOTH_DECISIONS_IMMUTABLE',context_id=c['context_id'],order=list(order))
                for m in order:
                    live,ac,decision,path=online[m];event(out,'START',kind='ONLINE',context_id=c['context_id'],method=m)
                    branch=sim.propagate(live,ac,decision,budget,purpose=m+'_ACTUAL',require_sent=True) if decision['selected_command_sent'] else not_run(decision.get('selected_gamma'),'ABSTAIN_OR_LATE_UNAPPLIED')
                    record_position(out,path,p,ac,decision,branch,'ONLINE',m,'ACTUAL',saved,budget)
                del online,live,decision,branch;gc.collect()
            for m in order:
                for arm,gamma in (('B',0.),('MIDDLE',.5)) if p['severe'] else (('B',0.),):
                    budget.check();ac=policy_context(c,m,binding[m],arm);path=out/'TEST'/c['context_id']/m/arm
                    save_numeric(path/'POLICY_CONTEXT.json',ac);event(out,'START',kind='DIRECT',context_id=c['context_id'],method=m,arm=arm)
                    owners={};k=None
                    if c.get('eligible'):
                        owners,startup=make_owners(model,budget,ac,manifest,binding[m]);write(path/'STARTUP.json',startup)
                        k=owners['B' if gamma==0. else 'MIDDLE']
                        packet=experimental_packet(k,ac,budget,owners,gamma,m+'_'+arm);k.flush_raw_evidence()
                    else:packet=missing_packet(ac,m,gamma)
                    save_numeric(path/'PACKET.json',packet)
                    branch=sim.propagate(k,ac,packet,budget,purpose=m+'_'+arm,require_sent=True) if packet['experimental_committed'] else not_run(gamma,packet['status'])
                    record_position(out,path,p,ac,packet,branch,'DIRECT',m,arm,saved,budget)
                    del owners,k,packet,branch;gc.collect()
            print(dict(phase='TEST_CONTEXT_DONE',contexts=p['ordinal']+1,planned=80,positions=len(saved),budget=budget.snapshot()),flush=True)
        if start_pair!={m:bundle_identity(bundles[m]) for m in METHODS}:raise ValueError('TEST mutated frozen policy models')
    except SprintLimit as exc:
        status='INCOMPLETE_BUDGET';write(out/'INTERRUPTION.json',dict(error=str(exc),budget=budget.snapshot()))
    except BaseException as exc:
        status='STOPPED_IMPLEMENTATION_OR_RESOURCE'
        write(out/'INTERRUPTION.json',dict(type=type(exc).__name__,error=str(exc),traceback=traceback.format_exc(),budget=budget.snapshot()))
        raise
    finally:
        for pos in positions('CAL')+positions('TEST'):
            path=out/pos['split']/pos['context_id']/pos['method']/pos['arm']/'RESULT.json'
            if not path.exists():write(path,dict(status='NOT_RUN',reason={'reason':status},label={},observed=False,
                complete_501=False,timing_qualified=False,selected_command_sent=False,model_authorized=False))
        unchanged=all(sha(OUTPUT_ROOT_D/p)==v for p,v in runtime.items())
        if not unchanged:status='INVALID_RUNTIME_MUTATION'
        write(out/'RUNTIME_END.json',dict(runtime_sha256_unchanged=unchanged,new_TRAIN=0,new_fits=0,
            predictor_TRAIN_unchanged=train_identity(old)==old_train,policy_pair_frozen_before_TEST=start_pair is not None))
        budget.event('NUMERICAL_FINISHED',status=status);budget.close()
        write(out/'RUN_FINISHED.json',dict(status=status,run_id=RUN_ID,finish_utc=datetime.now(timezone.utc).isoformat(),
            saved_positions=len(saved),budget=budget.snapshot()))
        print(dict(status=status,budget=budget.snapshot()),flush=True)
if __name__=='__main__':run()
