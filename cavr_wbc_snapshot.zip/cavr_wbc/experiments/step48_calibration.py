"""Fresh phase-only CAL; same actual TASK contract, untouched old bytes."""
from copy import deepcopy
from cavr_wbc.experiments.step48_io import *
from cavr_wbc.experiments.step48_inputs import ARMS
from cavr_wbc.experiments.step47_calibration import fresh,train_identity
from cavr_wbc.experiments.step47_binding import PolicyDomain
from cavr_wbc.experiments.step44_identity import bundle_identity
from cavr_wbc.control import step39_margin as margin
from cavr_wbc.control.step41_terminal_domain import build_table
def freeze(out,old,rows,domain_rows,mapping,contract,freeze_sha):
    if len(rows)!=64 or len(domain_rows)!=64:raise ValueError('new phase CAL denominator')
    if any(r['source_split']!='STEP48_FRESH_CAL' for r in rows):raise ValueError('phase CAL old contamination')
    bundles={ARMS[0]:old};tables={ARMS[0]:read(out/'models/PHASE_SHIFTED_TASK/TASK_MATCHED_DOMAIN.json')}
    new=fresh(old,rows,contract)
    new.update(calibration_id='STEP48_PHASE_MATCHED_TASK_CAL_V1',
        STEP48_CAL=dict(comparison_arm=ARMS[1],ticks=[37,41],protocol_freeze_sha256=freeze_sha))
    bundles[ARMS[1]]=new;tables[ARMS[1]]=build_table(domain_rows,mapping)
    tables[ARMS[1]].update(policy_contract=deepcopy(contract),TEST_consumed=False,new_CAL_only=True,
        STEP48_CAL=dict(comparison_arm=ARMS[1],ticks=[37,41],protocol_freeze_sha256=freeze_sha))
    domains={};assets={};metadata={}
    for m in ARMS:
        if m==ARMS[0]:
            paths={ext:out/'models/PHASE_SHIFTED_TASK'/('TASK_MATCHED.'+ext) for ext in ('json','npz')}
            bundle_asset={**{ext:str(p) for ext,p in paths.items()},**{ext+'_sha256':sha(p) for ext,p in paths.items()}}
            path=out/'models/PHASE_SHIFTED_TASK/TASK_MATCHED_DOMAIN.json'
        else:
            bundle_asset=margin.save_bundle(new,out/'models',m);path=out/'models'/(m+'_DOMAIN.json');write(path,tables[m])
        domains[m]=PolicyDomain(tables[m],sha(path))
        assets[m]=dict(bundle=bundle_asset,domain=dict(path=relative(path,out),sha256=sha(path)))
        metadata[m]=dict(comparison_arm=m,identity=bundle_identity(bundles[m]),TRAIN_unchanged=train_identity(old)==train_identity(bundles[m]),
            policy_contract=contract,CAL_ticks=[36,40] if m==ARMS[0] else [37,41],CAL_rows=64,
            source='STEP47_FROZEN_SUPPORT' if m==ARMS[0] else 'STEP48_FRESH_CAL',
            groups={k:{n:v for n,v in g.items() if n.startswith('CAL_') or n in ('local_calibrated','distance_threshold')} for k,g in bundles[m]['groups'].items()},
            domain_groups=tables[m]['strata'])
    f=dict(status='FROZEN_BEFORE_TEST',planned_new=64,recorded_new=len(rows),baseline_reused_rows=64,
        assets=assets,methods=metadata,new_TRAIN=0,new_fits=0,TEST_consumed=False,
        old_new_CAL_merged=False,TRAIN_policy='HOLD_ORIGINAL',TASK_TRAIN_policy_matched=False)
    write(out/'STEP48_CAL_FREEZE.json',f);return bundles,domains,f
