"""Interpret already recorded gates after ready; no candidate reevaluation."""
import re
from copy import deepcopy
def phase(snapshot):
    match=re.search(r'_T(\d{3})(?:_|$)',str(snapshot))
    return int(match.group(1)) if match else None
def diagnostic(packet):
    queries=[]
    for gamma in ('0.5','0.0'):
        entry=packet.get('actions',{}).get(gamma,{})
        consensus=deepcopy(entry.get('cal_physical_consensus'))
        if consensus:
            for neighbor in consensus.get('neighbors',[]):neighbor['request_tick']=phase(neighbor.get('snapshot'))
        queries.append(dict(gamma=gamma,evaluation_status=entry.get('evaluation_status'),
            accepted=(entry.get('decision') or {}).get('accepted'),numeric=(entry.get('decision') or {}).get('numeric'),
            local4=consensus,domain=entry.get('terminal_domain'),rejection_reasons=entry.get('rejection_reasons'),
            complete_at_ms=entry.get('complete_at_ms')))
    return dict(comparison_arm=packet.get('comparison_arm'),queries=queries,
        gamma0_requested=0. in packet.get('on_demand_prefix_order',[]),
        prefix_order=packet.get('on_demand_prefix_order'),phase_latency_ms=packet.get('phase_latency_ms'),
        prepared_ms=packet.get('prepared_commit_ms'),complete_ms=packet.get('command_ready_ms'),
        ready_boundary_unchanged=True,diagnostic_resolution_after_ready=True,
        no_new_QP_prefix_inference_or_gate_evaluation=True)
