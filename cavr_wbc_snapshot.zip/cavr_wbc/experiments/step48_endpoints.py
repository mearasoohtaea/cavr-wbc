"""Frozen STEP47 endpoint definitions applied to two same-TASK arms."""
import numpy as np
from cavr_wbc.experiments.step48_inputs import ARMS,DIRECT_METHODS,plans
from cavr_wbc.experiments.step47_delivery import established,ident,pair,capacity_four
def endpoints(rows):
    by={r['id']:r for r in rows};P=[];F=[];onlineP=[];packages=[];C=[];R=[];backups=[];S={}
    for m in ARMS:
        all_online=[r for r in rows if r['kind']=='ONLINE' and r['method']==m]
        sent=[r for r in all_online if r['selected_command_sent']]
        wrong=[r for r in sent if r['complete_501'] and not r['safe_timely']]
        partial=[r for r in sent if not r['complete_501']]
        S[m]=dict(status='FAIL' if wrong else 'NOT_ESTABLISHED' if not sent or partial else 'ESTABLISHED_FINITE_ACCEPTANCE',
            planned=32,recognized=sum(r['learner_approved'] for r in all_online),sent=len(sent),
            complete_safe_timely=sum(r['safe_timely'] for r in sent),complete_wrong_accepts=len(wrong),sent_partial=len(partial),
            abstain=sum(r['packet_status']=='ABSTAIN' for r in all_online),late=sum(r['packet_late'] for r in all_online),
            rejected_unapplied=32-len(sent),wrong_ids=[r['id'] for r in wrong],partial_ids=[r['id'] for r in partial])
    for p in plans('TEST'):
        if not p['severe']:continue
        cid=p['context_id'];own=lambda m,a:by[cid+':'+m+':'+a]
        for arm in ('B','MIDDLE'):
            q=pair(p,own('TASK_MATCHED',arm),own('HOLD_MATCHED',arm),'TASK_MINUS_HOLD_SAME_GAMMA_SHARED_DIRECT');q['arm']=arm;P.append(q)
        for m in DIRECT_METHODS:F.append(dict(method=m,**pair(p,own(m,'MIDDLE'),own(m,'B'),'MIDDLE_MINUS_B_WITHIN_POLICY')))
        four={}
        for m in DIRECT_METHODS:
            H=by[p['snapshot_id']+'_HEALTHY:'+m+':B'];L=by[p['snapshot_id']+'_'+p['fault_leg']+'_THIGH30:'+m+':B']
            four[m]=capacity_four(p,H,L,own(m,'B'),own(m,'MIDDLE'))
        tf=four['TASK_MATCHED'];hf=four['HOLD_MATCHED'];B=own('TASK_MATCHED','B');holdB=own('HOLD_MATCHED','B')
        for m in ARMS:
            task=own(m,'ACTUAL');g=task.get('gamma');h=own('HOLD_MATCHED','MIDDLE' if g==.5 else 'B')
            q=pair(p,task,h,'TASK_PHASE_ARM_ONLINE_MINUS_SAME_GAMMA_HOLD_DIRECT')
            q.update(comparison_arm=m,gamma_available=g in (.5,0.));q['task_use_target_met'] &= q['gamma_available'];onlineP.append(q)
            C.append(dict(**ident(p),comparison_arm=m,TASK_four_way=tf,
                timely_recognized_sent_middle=bool(task['selected_command_sent'] and g==.5),
                own_actual_safe_timely=task['safe_timely'],own_actual_id=task['id'],same_gamma_HOLD_direct_task_use=q['task_use_target_met'],
                qualified=bool(tf['healthy_safe_timely'] and tf['mild_safe_timely'] and tf['severe_B_complete_physical_failure'] and tf['severe_B_timing_qualified'] and tf['sent_and_actual_capacity_precede_failure'] and task['selected_command_sent'] and g==.5 and task['safe_timely'] and q['task_use_target_met'])))
        packages.append(pair(p,own(ARMS[1],'ACTUAL'),own(ARMS[0],'ACTUAL'),'PHASE_MATCHED_VS_SHIFTED_TASK_LEARNED_PACKAGE'))
        middleP=next(r for r in P if r['context_id']==cid and r['arm']=='MIDDLE')
        R.append(dict(**ident(p),HOLD_four_way=hf,TASK_middle_safe_timely=own('TASK_MATCHED','MIDDLE')['safe_timely'],
            P_target_met=middleP['task_use_target_met'],qualified=bool(hf['timing_type_ii'] and middleP['task_use_target_met'] and own('TASK_MATCHED','MIDDLE')['safe_timely'])))
        backups.append(dict(**ident(p),TASK_BACKUP_SAFE=bool(tf['healthy_safe_timely'] and tf['mild_safe_timely'] and B['safe_timely']),
            COMPARATIVE_BACKUP_ONLY_RECOVERY=bool(hf['healthy_safe_timely'] and hf['mild_safe_timely'] and holdB['complete_501'] and holdB['physical_pass'] is False and holdB['timing_qualified'] and holdB.get('sent_and_actual_capacity_precede_failure') and B['safe_timely']),
            HOLD_B_outcome=holdB['outcome'],TASK_B_outcome=B['outcome']))
    primary=lambda r:r['direction']==-1 and r['fault_leg']=='RR'
    pres=established([q for q in P if primary(q) and q['arm']=='MIDDLE' and q['task_use_target_met']])
    cres={m:established([q for q in C if primary(q) and q['comparison_arm']==m and q['qualified']]) for m in ARMS}
    rres=established([q for q in R if primary(q) and q['qualified']])
    return dict(S=S,P=pres,C_TASK_ONLINE=cres,R_LEGACY_CROSS_POLICY=rres,
        closure_established=S[ARMS[1]]['status']=='ESTABLISHED_FINITE_ACCEPTANCE' and pres['status']=='ESTABLISHED_LOCAL_CONFIRMATION' and cres[ARMS[1]]['status']=='ESTABLISHED_LOCAL_CONFIRMATION'),dict(TASK_PAIRS=P,ONLINE_TASK_PAIRS=onlineP,LEARNED_PACKAGE_PAIRS=packages,F_COMPONENT_PAIRS=F,C_TASK_ONLINE_PAIRS=C,R_LEGACY_PAIRS=R,BACKUP_CLASSIFICATION=backups)
def opportunity_chain(rows,decisions,paired):
    by={r['id']:r for r in rows};db={d['id']:d for d in decisions};result=[]
    for c in paired['C_TASK_ONLINE_PAIRS']:
        p=next(p for p in plans('TEST') if p['context_id']==c['context_id']);m=c['comparison_arm'];own=by[c['own_actual_id']];d=db.get(own['id'],{})
        q=next((q for q in d.get('queries',[]) if q['gamma']=='0.5'),{})
        tf=c['TASK_four_way'];capacity=bool(tf['healthy_safe_timely'] and tf['mild_safe_timely'] and tf['severe_B_complete_physical_failure'] and tf['severe_B_timing_qualified'] and tf['sent_and_actual_capacity_precede_failure'])
        middle=next(q for q in paired['TASK_PAIRS'] if q['context_id']==p['context_id'] and q['arm']=='MIDDLE')
        result.append(dict(**ident(p),comparison_arm=m,direct_capacity_opportunity=capacity,
            direct_middle_task_use=middle['task_use_target_met'],direct_C_opportunity=capacity and middle['task_use_target_met'],
            candidate_evaluated=q.get('evaluation_status')=='EVALUATED',numeric_original_gates_pass=q.get('original_accepted_same_candidate'),
            local4_pass=(q.get('local4') or {}).get('accepted'),domain_pass=(q.get('domain') or {}).get('accepted'),
            physical_and_domain_accepted=q.get('accepted'),prepared_timely=own.get('first_prepared_ms') is not None and own['first_prepared_ms']<=17.,
            recognized_sent_gamma_half=c['timely_recognized_sent_middle'],own_actual_complete=own['complete_501'],own_actual_safe_timely=own['safe_timely'],
            qualified_C=c['qualified'],late=d.get('late'),gamma0_requested=d.get('gamma0_requested'),rejection_reasons=q.get('rejection_reasons'),
            rejection_reasons_overlap_not_mutually_exclusive=True,unobserved_not_imputed=True))
    return result
