"""Two SciPilot figures from current derived JSON only, never bank replay."""
import argparse,sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle,Patch
from PIL import Image
from cavr_wbc.experiments.step48_io import output,read,write,sha,Path
from cavr_wbc.experiments.step48_inputs import ARMS,DIRECT_METHODS,plans
sys.path.insert(0,'C:/Users/ZhuanZ（无密码）/.codex/skills/scipilot-figure/scripts')
from profile_data import profile_data,render_report
from setup_style import setup_style
from layout_tools import add_panel_labels,finalize_figure
from visual_qa import audit_layout,render_preview
from export_figure import export_figure
from check_figure import check_figure
from cavr_wbc.experiments.step47_figures import embedded_fonts
COLORS={ARMS[0]:'#0072B2',ARMS[1]:'#D55E00','HOLD_MATCHED':'#999999','TASK_MATCHED':'#555555'}
MARKERS={ARMS[0]:'o',ARMS[1]:'s','HOLD_MATCHED':'^','TASK_MATCHED':'d'}
NAMES={ARMS[0]:'Shifted',ARMS[1]:'Matched','HOLD_MATCHED':'Direct HOLD','TASK_MATCHED':'Direct TASK'}
def primary(r):return r.get('direction')==-1 and r.get('fault_leg')=='RR'
def title(ax,text):ax.set_title(text,loc='left',pad=10)
def finish(fig,axes,heading,footer):
    fig.suptitle(heading,fontsize=11);fig.text(.5,.013,footer,ha='center',fontsize=7)
    finalize_figure(fig);fig.set_layout_engine('constrained',h_pad=.12,w_pad=.10,rect=(0,.045,1,.97))
    add_panel_labels(fig,axes=axes,style='ieee',fontsize=10,x_offset_pt=-12,y_offset_pt=7)
def scalar(v):return None if v is None or not np.isfinite(v) else float(v)
def query_half(d):return next((q for q in d['queries'] if q['gamma']=='0.5'),{})
def figure1(out,result):
    rows=read(out/'BRANCH_ROWS.json');by={r['id']:r for r in rows};dec=read(out/'ONLINE_DECISIONS.json');db={d['id']:d for d in dec}
    severe=[p for p in plans('TEST') if p['severe']]
    fig=plt.figure(figsize=(7.16,7.4));gs=fig.add_gridspec(3,2,height_ratios=[1,.65,1.15])
    a=fig.add_subplot(gs[0,:]);b=fig.add_subplot(gs[1,:]);c=fig.add_subplot(gs[2,0]);d=fig.add_subplot(gs[2,1])
    stage_names=['Planned','Recognized','Prepared\ntimely','Sent','Complete\nsafe timely','C: negative RR'];chain=[]
    for j,m in enumerate(ARMS):
        own=[q for q in dec if q['method']==m];s=result['endpoints']['S'][m]
        values=[32,s['recognized'],sum(q['learner_approved'] and q.get('prepared_ms') is not None and q['prepared_ms']<=17 for q in own),s['sent'],s['complete_safe_timely'],result['endpoints']['C_TASK_ONLINE'][m]['support']['physical_snapshots']]
        for i,v in enumerate(values):
            x=i+(j-.5)*.18;a.scatter(x,v,s=30,marker=MARKERS[m],color=COLORS[m]);a.annotate(str(v),(x,v),xytext=(0,7 if j or i==5 else -12),textcoords='offset points',ha='center',fontsize=8)
            chain.append(dict(comparison_arm=m,stage=stage_names[i],n=v,planned=32))
    a.set_xticks(range(6),stage_names);a.set_ylim(-3,39);a.set_yticks([0,8,16,24,32]);a.set_ylabel('Sources (n / 32)')
    a.legend(handles=[Line2D([],[],color=COLORS[m],marker=MARKERS[m],ls='',label=NAMES[m]) for m in ARMS],ncol=2,loc='upper right',frameon=False)
    title(a,'Same TASK policy: planned-to-online closure')
    categories={'N':('#FFFFFF','Not run'),'A':('#DDDDDD','ABSTAIN'),'L':('#F0E442','Valid late'),'S':('#56B4E9','Safe sent'),'F':('#D55E00','Wrong sent'),'P':('#CC79A7','Sent partial')};states=[]
    for j,m in enumerate(ARMS):
        for i,p in enumerate(severe):
            r=by[p['context_id']+':'+m+':ACTUAL']
            code='P' if r['selected_command_sent'] and not r['complete_501'] else 'F' if r['selected_command_sent'] and not r['safe_timely'] else 'S' if r['selected_command_sent'] else 'L' if r.get('recognized') else 'A' if r['packet_status']=='ABSTAIN' else 'N'
            b.add_patch(Rectangle((i-.49,j-.4),.98,.8,facecolor=categories[code][0],edgecolor='#888888',lw=.3));b.text(i,j,code,ha='center',va='center',fontsize=7)
            states.append(dict(source_ordinal=i,comparison_arm=m,context_id=p['context_id'],code=code))
    b.set_xlim(-.5,31.5);b.set_ylim(1.5,-.5);b.set_yticks([0,1],[NAMES[m] for m in ARMS]);b.set_xticks(np.arange(1.5,32,4),[f'E{i}' for i in range(8)]);b.set_xlabel('Each episode: FR37, RR37, FR41, RR41')
    b.legend(handles=[Patch(facecolor=v[0],edgecolor='#888888',label=k+': '+v[1]) for k,v in categories.items()],loc='upper center',bbox_to_anchor=(.5,-.38),ncol=3,fontsize=7,frameon=False)
    title(b,'Every severe source, not only the primary successes')
    domain_points=[];neighbors=[];missing_local={};missing_domain={}
    for j,m in enumerate(ARMS):
        ml=md=0
        for i,p in enumerate(severe):
            q=query_half(db.get(p['context_id']+':'+m+':ACTUAL',{'queries':[]}));con=q.get('local4') or {};failed=con.get('failed_neighbor_count')
            if failed is None:ml+=1
            else:c.scatter(i+(j-.5)*.18,failed,s=18,marker=MARKERS[m],color=COLORS[m])
            neighbors.append(dict(source_ordinal=i,comparison_arm=m,context_id=p['context_id'],local4=con or None))
            dom=q.get('domain') or {};x=dom.get('axes');lo=dom.get('lo');hi=dom.get('hi');eps=dom.get('epsilon')
            if any(v is None for v in (x,lo,hi,eps)):md+=1;continue
            for k in range(3):
                width=hi[k]-lo[k]+2*eps[k];position=(x[k]-lo[k]+eps[k])/width
                yy=k+(j-.5)*.16+(i-15.5)*.006
                d.scatter(position,yy,s=14,marker=MARKERS[m],color=COLORS[m],alpha=.7)
                domain_points.append(dict(source_ordinal=i,comparison_arm=m,axis=k,raw_query=x[k],lo=lo[k],hi=hi[k],epsilon=eps[k],display_position=position,axis_pass=dom['axis_pass'][k]))
        missing_local[m]=ml;missing_domain[m]=md
    c.set_xlabel('Source ordinal (0..31)');c.set_ylabel('Failed neighbors (n / 4)');c.set_yticks(range(5));c.set_ylim(-.4,5.4);c.set_xlim(-1,32);c.set_xticks([0,8,16,24,31]);title(c,'Original local4: no failure removed')
    c.text(.02,.98,'Not evaluated: '+str([missing_local[m] for m in ARMS]),transform=c.transAxes,va='top',fontsize=7)
    d.axvspan(0,1,color='#EEEEEE',zorder=0);d.axvline(0,color='#777777',lw=.7);d.axvline(1,color='#777777',lw=.7)
    d.set_xscale('symlog',linthresh=1);d.set_yticks(range(3),['v now','v prefix end','u sent max']);d.set_ylim(-.5,3.1);d.set_xlabel('Box position (symlog; inside = 0..1)');title(d,'All three saved raw-domain axes')
    d.text(.02,.98,'Missing queries: '+str([missing_domain[m] for m in ARMS]),transform=d.transAxes,va='top',fontsize=7)
    finish(fig,[a,b,c,d],'STEP48 | Phase support and unchanged online gates','Two arms share TASK control and TRAIN; differences belong to the complete CAL/domain phase-support package.\nMissing queries are not filled with a passing value; [Shifted, Matched] missing counts shown.')
    write(out/'figures/FIG1_DATA.json',dict(chain=chain,all_source_states=states,local4=neighbors,domain_axes=domain_points,missing_local4=missing_local,missing_domain=missing_domain))
    return fig
def ecdf(ax,data,m,ls='-',label=None):
    a=np.sort(np.asarray(data,float));a=a[np.isfinite(a)]
    if len(a):ax.step(a,np.arange(1,len(a)+1)/len(a),where='post',color=COLORS[m],ls=ls,lw=1,marker=MARKERS[m],markersize=3,markevery=max(1,len(a)//9),label=label or NAMES[m])
def figure2(out,result):
    rows=read(out/'BRANCH_ROWS.json');lat=read(out/'LATENCY.json');dec=read(out/'ONLINE_DECISIONS.json');capacity=read(out/'CAPACITY_EVENTS.json');by={r['id']:r for r in rows}
    fig,axs=plt.subplots(3,2,figsize=(7.16,9.2));a,b,c,d,e,f=axs.flat
    prep=[w for w in lat if w['split']=='TEST' and w['kind']=='PREPARATION'];missing_first=0
    for m in ARMS+DIRECT_METHODS:
        own=[w for w in prep if w['method']==m];good=[w for w in own if scalar(w['complete_ms']) is not None and scalar(w['prepared_ms']) is not None];missing_first+=len(own)-len(good)
        for applied in (True,False):
            ss=[w for w in good if w['applied']==applied]
            a.scatter([w['prepared_ms'] for w in ss],[w['complete_ms'] for w in ss],marker=MARKERS[m] if applied else 'x',color=COLORS[m],s=13,alpha=.7)
    a.axvline(17,color='#777777',ls='--',lw=.8);a.axhline(20,color='#777777',ls=':',lw=.8);a.set_xlabel('Prepared first command (ms)');a.set_ylabel('Complete first command (ms)');a.set_xlim(left=0);a.set_ylim(bottom=0);title(a,'All TEST first commands')
    a.text(.03,.86,f'Planned n={len(prep)}; missing={missing_first}\nShape: applied; x: unapplied',transform=a.transAxes,va='top',fontsize=7)
    fb=[w for w in lat if w['split']=='TEST' and w['kind']=='FEEDBACK']
    for m in ARMS+DIRECT_METHODS:ecdf(b,[w['complete_ms'] for w in fb if w['method']==m and w['complete_ms'] is not None],m,ls='-' if m in ARMS else '--')
    b.axvline(20,color='#777777',ls=':',lw=.8);b.set_ylim(0,1.04);b.set_xlabel('Complete feedback latency (ms, log)');b.set_ylabel('Empirical cumulative fraction');b.set_xscale('log');b.set_xlim(left=.1);title(b,'All planned TEST feedback windows')
    b.text(.02,.97,f'Planned n={len(fb)}\nNot run/reached: {sum(w.get("missing_kind","") in ("PLANNED_NOT_RUN","PLANNED_NOT_REACHED_AFTER_PARTIAL") for w in fb)}\nActual value missing: {sum(w.get("missing_kind")=="ACTUAL_WINDOW_VALUE_MISSING" for w in fb)}',transform=b.transAxes,va='top',fontsize=7)
    b.legend(loc='lower right',frameon=False,fontsize=7)
    severe=[p for p in plans('TEST') if p['severe']];order={p['context_id']:i for i,p in enumerate(severe)}
    for j,m in enumerate(ARMS):
        own=[q for q in dec if q['method']==m];g0=sum(q['gamma0_requested'] for q in own)
        for q in own:
            if scalar(q.get('prepared_ms')) is not None:c.scatter(order[q['context_id']]+(j-.5)*.2,q['prepared_ms'],s=22,marker=MARKERS[m],edgecolors=COLORS[m],facecolors=COLORS[m] if q['gamma0_requested'] else 'none')
        c.text(.02,.24-j*.08,f'{NAMES[m]} gamma0 requests: {g0}/{len(own)}',transform=c.transAxes,va='top',fontsize=7,color=COLORS[m])
    c.axhline(17,color='#777777',ls='--',lw=.8);c.set_xlim(-1,32);c.set_ylim(bottom=0);c.set_xlabel('Source ordinal (0..31)');c.set_ylabel('Total prepared wall time (ms)');title(c,'Gamma0 requests, measured not assumed')
    fixed=next(p for p in severe if primary(p));cid=fixed['context_id'];snap=fixed['snapshot_id']
    timeline=[(snap+'_HEALTHY:TASK_MATCHED:B','Healthy B'),(snap+'_RR_THIGH30:TASK_MATCHED:B','Mild B'),(cid+':TASK_MATCHED:B','Severe B'),(cid+':'+ARMS[0]+':ACTUAL','Shifted own'),(cid+':'+ARMS[1]+':ACTUAL','Matched own')]
    for i,(rid,name) in enumerate(timeline):
        ss=[w for w in capacity if w['id']==rid];applied=[w['time_s'] for w in ss if w['command_applied']]
        if applied:d.plot([min(applied),max(applied)],[i,i],color='#999999',lw=2)
        else:d.text(.02,i,'not applied',va='center',fontsize=7,color='#777777')
        for field,marker,dy in [('sent_99percent','^',.08),('actual_99percent','o',-.08)]:
            times=[w['time_s'] for w in ss if w[field] and w['command_applied']]
            if times:d.scatter(min(times),i+dy,s=24,marker=marker,color='#0072B2')
        failure=by[rid].get('first_dense_failure_s')
        if failure is not None:d.scatter(failure,i,marker='x',color='black',s=28)
    d.set_yticks(range(5),[name for _,name in timeline]);d.set_ylim(4.4,-.5);d.set_xlim(-.02,1.06);d.set_xlabel('Physical time (s)');title(d,'Fixed first negative RR four-way source')
    d.text(.02,.98,snap,transform=d.transAxes,va='top',fontsize=7)
    taskpairs=[q for q in read(out/'TASK_PAIRS.json') if primary(q) and q['arm']=='MIDDLE'];onlinepairs=read(out/'ONLINE_TASK_PAIRS.json');groups=[taskpairs]+[[q for q in onlinepairs if primary(q) and q['comparison_arm']==m] for m in ARMS];missing=[]
    for i,group in enumerate(groups):
        values=[q for q in group if q['terminal_error_improvement_m'] is not None];missing.append(8-len(values))
        for j,q in enumerate(values):e.scatter(i+(j-(len(values)-1)/2)*.05,q['terminal_error_improvement_m']*1000,marker='o' if q['both_safe_timely'] else 'x',color='#D55E00' if q['both_safe_timely'] else '#777777',s=20)
    e.axhline(0,color='#777777',lw=.7);e.axhline(.2,color='#009E73',ls='--',lw=.8);e.set_xticks(range(3),['Direct','Shifted own','Matched own']);e.set_ylabel('HOLD - TASK end error (mm)');e.set_xlim(-.4,2.4);e.margins(y=.35);title(e,'Negative RR: all same-gamma raw pairs')
    e.text(.02,.97,'8 snapshots / 4 episodes\nMissing: '+str(missing),transform=e.transAxes,va='top',fontsize=7)
    fields=['B_QP_and_contract_ms','C_QP_and_contract_ms','G0.5_prefix_feature_ms','G0.0_prefix_feature_ms'];costdata=[]
    for i,field in enumerate(fields):
        for j,m in enumerate(ARMS):
            own=[q for q in dec if q['method']==m];values=[q['phase_latency_ms'].get(field) for q in own if q.get('phase_latency_ms') and scalar(q['phase_latency_ms'].get(field)) is not None]
            for k,v in enumerate(values):f.scatter(i+(j-.5)*.18+(k-(len(values)-1)/2)*.004,v,marker=MARKERS[m],color=COLORS[m],s=12,alpha=.6)
            costdata.append(dict(comparison_arm=m,phase=field,observed=len(values),planned=len(own),missing=len(own)-len(values),values_ms=values))
    f.set_xticks(range(4),['B + check','C + check','G.5 prefix','G0 prefix']);f.set_ylim(bottom=0);f.set_ylabel('Recorded nested phase (ms)');title(f,'Segments shown separately, not summed')
    finish(fig,list(axs.flat),'STEP48 | Timing paths, real application, and local task use','Filled marker in (c): gamma0 queried; open: not queried. (d) shared TASK direct controls; triangle/circle = sent/applied >=99%, x = failure.\n(e) all observed raw pairs; crosses unqualified, missing not zero. All windows and nested timing fields remain in saved tables.')
    write(out/'figures/FIG2_DATA.json',dict(first_windows=prep,feedback_windows=fb,decisions=dec,fixed_source=cid,timeline_ids=timeline,task_pair_groups=groups,nested_costs=costdata))
    return fig
def run(export=False):
    out=output();folder=out/'figures';folder.mkdir(exist_ok=True);result=read(out/'STEP48_RESULT.json')
    style=setup_style('ieee',lang='en',use_sciplots=False)
    plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],'font.size':8,'axes.labelsize':8,'axes.titlesize':9,'xtick.labelsize':7,'ytick.labelsize':7,'axes.spines.top':False,'axes.spines.right':False})
    profiles={}
    for name,cols,groups in [('BRANCH_ROWS',['split','method','kind','arm','complete_501','timing_qualified','terminal_abs_external_error_m'],['split','method','kind']),('LATENCY',['split','method','kind','complete_ms','prepared_ms','applied','missing'],['split','method','kind'])]:
        frame=pd.DataFrame(read(out/(name+'.json')))[cols];profiles[name]=profile_data(frame,groups)
        (folder/(name+'_PROFILE.md')).write_text(render_report(profiles[name]),encoding='utf-8')
    write(folder/'DATA_PROFILES.json',profiles)
    qa=[]
    for name,fig,size in [('FIG1_PHASE_SUPPORT',figure1(out,result),(7.16,7.4)),('FIG2_TIMING_CAPACITY_TASK',figure2(out,result),(7.16,9.2))]:
        layout=audit_layout(fig);preview=render_preview(fig,str(folder/(name+'_preview.png')),dpi=165)
        q=dict(name=name,layout=layout,preview=preview,publication_size_inches=size,style=style)
        if export:
            if any(s=='FAIL' for s,_ in layout):raise ValueError('figure layout failure')
            paths=export_figure(fig,str(folder/name),formats=['pdf','png'],dpi=600,size_inches=size,grayscale_preview=False,tight=False)
            with Image.open(folder/(name+'.png')) as im:im.convert('L').save(folder/(name+'_grayscale.png'),dpi=(600,600))
            q.update(files={Path(p).name:sha(p) for p in paths},compliance=[dict(path=p,issues=check_figure(p,min_dpi=600,target_inches=size)[0],info=check_figure(p,min_dpi=600,target_inches=size)[1]) for p in paths],PDF_font_descendants=embedded_fonts(folder/(name+'.pdf')))
        qa.append(q);plt.close(fig)
    write(folder/('EXPORT_QA.json' if export else 'PREVIEW_QA.json'),qa)
    print(dict(figures=2,exported=export,layout_issues=[q['layout'] for q in qa]),flush=True)
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--export',action='store_true');run(parser.parse_args().export)
