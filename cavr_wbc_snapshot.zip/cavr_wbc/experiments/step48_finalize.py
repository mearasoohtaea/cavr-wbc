"""Current metadata and scoped Git snapshot only; no bank reinspection."""
from datetime import datetime,timezone
import ast,os,subprocess
from cavr_wbc.experiments.step48_io import *
def git(root,*args):
    env=os.environ.copy()
    for key in ('GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_COMMON_DIR'):env.pop(key,None)
    env['GIT_OPTIONAL_LOCKS']='0'
    p=subprocess.run(['git','-C',str(root),*args],capture_output=True,text=True,encoding='utf-8',env=env)
    if p.returncode:raise RuntimeError(p.stderr)
    return p.stdout.strip()
def run():
    out=output();baseline=read(out/'SOURCE_READONLY_BASELINE.json');r=read(out/'STEP48_RESULT.json')
    source_head=git(SOURCE_ROOT_D,'rev-parse','HEAD');source_status=git(SOURCE_ROOT_D,'status','--porcelain=v1','--untracked-files=no')
    status=git(OUTPUT_ROOT_D,'status','--porcelain=v1','--untracked-files=all');diff=git(OUTPUT_ROOT_D,'diff','--name-only');staged=git(OUTPUT_ROOT_D,'diff','--cached','--name-only');branch=git(OUTPUT_ROOT_D,'branch','--show-current')
    syntax=[]
    for path in list((OUTPUT_ROOT_D/'cavr_wbc/experiments').glob('step48_*.py'))+[OUTPUT_ROOT_D/'cavr_wbc/control/step48_kernel.py',OUTPUT_ROOT_D/'tests/test_step48_protocol.py']:
        ast.parse(path.read_text(encoding='utf-8'),filename=str(path));syntax.append(relative(path,OUTPUT_ROOT_D))
    source_index=sha(SOURCE_ROOT_D/'.git/index')
    source_ok=source_head==SOURCE_COMMIT and source_index==baseline['source_index_sha256'] and r['readback']['source_readonly_unchanged'] and source_status==''
    result=dict(timestamp_utc=datetime.now(timezone.utc).isoformat(),scope='FINAL_CURRENT_METADATA_AND_SCOPED_GIT_SNAPSHOT_NOT_A_BANK_AUDIT',source_HEAD=source_head,source_index_sha256=source_index,source_tracked_status=source_status,source_unchanged=source_ok,
        worktree=str(OUTPUT_ROOT_D),branch=branch,base_HEAD=git(OUTPUT_ROOT_D,'rev-parse','HEAD'),git_status_before_scoped_commit=status.splitlines(),tracked_diff_names=diff.splitlines(),staged_names_at_snapshot=staged.splitlines(),implementation_and_postprocessing_files=syntax,
        postprocessing_added_after_numerical_freeze=['step48_delivery.py','step48_endpoints.py','step48_figures.py','step48_package.py','step48_finalize.py'],
        pure_test_result=read(out/'tests/NECESSARY_TESTS.json'),current_readback_status=r['readback']['status'],figure_program_QA=read(out/'figures/EXPORT_QA.json'),figure_visual_review=read(out/'figures/VISUAL_REVIEW.json'),
        commands=dict(numerical='python -B -X utf8 -m cavr_wbc.experiments.step48_sprint',current_readback='python -B -X utf8 -m cavr_wbc.experiments.step48_delivery',figures_preview='python -B -X utf8 -m cavr_wbc.experiments.step48_figures',figures_export='python -B -X utf8 -m cavr_wbc.experiments.step48_figures --export',package='python -B -X utf8 -m cavr_wbc.experiments.step48_package',metadata_finalization='python -B -X utf8 -m cavr_wbc.experiments.step48_finalize',interpreter='E:/CAVR-WBC/_runtime_step30/python311/python.exe',dependency_environment=read(out/'PREPARATION.json'),syntax='ast.parse each new STEP48 source without executing it'),
        solver_or_integration_invoked=False,numerical_reproduction='UNVERIFIED_NOT_REPEATED',push=False)
    write(out/'FINAL_VERIFICATION.json',result)
    print(dict(source_unchanged=source_ok,branch=branch,new_python_files=len(syntax),changed_paths=len(status.splitlines())),flush=True)
    if not source_ok or diff or branch!='codex/step48-phase-matched-cal-confirmation-20261012':raise ValueError('final source or scope invariant')
if __name__=='__main__':run()
