"""Frozen comparison identity distinct from actual backup-policy method."""
from copy import deepcopy
from cavr_wbc.experiments.step46_inputs import context_for as source_context
ARMS=('PHASE_SHIFTED_TASK','PHASE_MATCHED_TASK')
DIRECT_METHODS=('HOLD_MATCHED','TASK_MATCHED')
CAL_TARGETS=(.062125,-.062125,.064375,-.064375,.066625,-.066625,.068875,-.068875)
TEST_TARGETS=(.0625,-.0625,.0645,-.0645,.0665,-.0665,.06825,-.06825)
def episodes(split):
    if split not in ('CAL','TEST'): raise ValueError('fixed split')
    return [dict(episode_id=f'T48_{split}_{i}',direction=1 if d>0 else -1,
        displacement_m=d,snapshot_ticks=[37,41]) for i,d in enumerate(CAL_TARGETS if split=='CAL' else TEST_TARGETS)]
def plans(split):
    rows=[];severe=0
    for ep in episodes(split):
        for tick in ep['snapshot_ticks']:
            snap=ep['episode_id']+f'_T{tick:03d}'
            kinds=('FR_THIGH15','RR_THIGH15') if split=='CAL' else ('FR_THIGH15','RR_THIGH15','HEALTHY','FR_THIGH30','RR_THIGH30')
            for kind in kinds:
                sev=kind.endswith('15');cid=snap+'_'+kind
                rows.append(dict(**ep,episode=ep['episode_id'],tick=tick,source_tick=tick,
                    snapshot_id=snap,source_snapshot=snap,context_id=cid,case_id=cid,source_state_id=cid,
                    ordinal=len(rows),severe_ordinal=severe if sev else None,health_kind=kind,
                    role='healthy' if kind=='HEALTHY' else 'thigh',fault_leg='NONE' if kind=='HEALTHY' else kind[:2],
                    health=1. if kind=='HEALTHY' else .15 if sev else .30,split=split,
                    source_split='STEP48_FRESH_'+split,gap_m=.006,severe=sev,governor_planned=split=='TEST' and sev))
                severe+=int(sev)
    return rows
def positions(split):
    rows=[]
    for p in plans(split):
        if p['governor_planned']:
            for m in ARMS:
                rows.append(dict(id=p['context_id']+':'+m+':ACTUAL',context_id=p['context_id'],method=m,comparison_arm=m,kind='ONLINE',arm='ACTUAL',split=split))
        for m in (('PHASE_MATCHED_TASK',) if split=='CAL' else DIRECT_METHODS):
            for arm,g in (('B',0.),('MIDDLE',.5)) if p['severe'] else (('B',0.),):
                rows.append(dict(id=p['context_id']+':'+m+':'+arm,context_id=p['context_id'],method=m,comparison_arm=m,kind='CAL' if split=='CAL' else 'DIRECT',arm=arm,gamma=g,split=split))
    return rows
def context_for(p,episode,mapping):
    c=source_context(p,episode,mapping)
    c.update(backup_id='STEP48-'+p['context_id'],group='STEP48_FIXED_'+p['split'])
    if c.get('previous_command_identity',{}).get('available'):
        c['previous_command_identity']['source']='NEW_STEP48_REFERENCE_CANDIDATE'
    return c
def policy_context(c,comparison_arm,contract,arm,freeze_sha):
    value=deepcopy(c);value.update(policy_contract=deepcopy(contract),method=contract['method'],
        comparison_arm=comparison_arm,step48_method_freeze_sha256=freeze_sha,
        backup_id=c['backup_id']+':'+comparison_arm+':'+arm)
    value['policy_anchor_goal']=dict(source_anchor_m=float(c['backup_anchor_q_init'][0]),
        source_goal_m=float(c['nominal_q_init'][0])+float(c['nominal_d_m'])) if c.get('eligible') else None
    return value
