"""STEP48 D-only output; original STEP47 assets remain byte-identical."""
from cavr_wbc.experiments.step47_io import (
    Path, np, sha, encode, append, relative, write, read, save_numeric,
    load_numeric, require_output, OUTPUT_ROOT_D, MODEL_NPZ, NATIVE_DLL)

SOURCE_ROOT_D = Path('D:/CAVR-WBC/cavr_step47_policy_matched_online_confirmation_20261012')
SOURCE_COMMIT = 'bf7105984389a40e5e36e945f28f29dcaa4d4f9b'
SOURCE_RUN = SOURCE_ROOT_D/'artifacts/step47_policy_matched_confirmation_20261012/step47-policy-matched-online-confirmation-20261012-01'
PROTOCOL = OUTPUT_ROOT_D/'configs/STEP48_EXECUTION_PROTOCOL.md'
RUN_ID = 'step48-phase-matched-cal-confirmation-20261012-01'
BASELINE_HASHES = {
    'TASK_MATCHED.json': '771deec0d5e2cf5985cca00b3c7efb657e69e08630570fc97068545c2c18ba9b',
    'TASK_MATCHED.npz': '3fb48f1079a7d2e81f8584d40cfbf246a8c0cd413ab6b1847963f5694ab6609b',
    'TASK_MATCHED_DOMAIN.json': '3f508b47084b1a647cf08a411560d1c50a806df8df1e4a046086c0b886dbabcc'}
def output():
    return OUTPUT_ROOT_D/'artifacts/step48_phase_matched_confirmation_20261012'/RUN_ID
def baseline_model():
    return output()/'models/PHASE_SHIFTED_TASK/TASK_MATCHED.npz'
