"""Chinese handoff from durable STEP48 authority; zero numerical operations."""
from collections import Counter
from datetime import datetime,timezone
import numpy as np
from cavr_wbc.experiments.step48_io import *
from cavr_wbc.experiments.step48_inputs import ARMS,DIRECT_METHODS
from cavr_wbc.experiments.step47_package import table,span
def text_file(path,body):require_output(path).write_text(body.rstrip()+'\n',encoding='utf-8',newline='\n')
def primary(r):return r['direction']==-1 and r['fault_leg']=='RR'
def run():
    out=output();r=read(out/'STEP48_RESULT.json');e=r['endpoints'];rows=read(out/'BRANCH_ROWS.json');dec=read(out/'ONLINE_DECISIONS.json');chain=read(out/'OPPORTUNITY_CHAIN.json');lat=read(out/'LATENCY.json');cal=read(out/'STEP48_CAL_FREEZE.json');tests=read(out/'tests/NECESSARY_TESTS.json');budget=r['run']['budget']
    P=read(out/'TASK_PAIRS.json');F=read(out/'F_COMPONENT_PAIRS.json');backups=read(out/'BACKUP_CLASSIFICATION.json');online=read(out/'ONLINE_TASK_PAIRS.json')
    status=dict(AUTHORIZE_STEP48_PHASE_MATCHED_CAL_AND_FRESH_CONFIRMATION='TRUE',SOURCE_STEP47_RESULT_UNCHANGED='NOT_ESTABLISHED',SOURCE_STEP47_P_R_LOCAL_CONFIRMATION_UNCHANGED='TRUE',
        STEP48_POLICY='TASK_AWARE_1MM_06S_V1',STEP48_COMPARISON_ARMS=','.join(ARMS),STEP48_BASELINE_CAL_REUSED_ROWS=64,STEP48_NEW_CAL_PLANNED=64,STEP48_BASELINE_CAL_TICKS='36,40',STEP48_NEW_CAL_TICKS='37,41',STEP48_TEST_TICKS='37,41',
        STEP48_NEW_TRAIN=0,STEP48_NEW_FITS=0,STEP48_CAL_REFERENCE_EPISODES=8,STEP48_TEST_REFERENCE_EPISODES=8,STEP48_TEST_SEVERE_CONTEXTS=32,STEP48_ONLINE_DECISIONS_PLANNED=64,STEP48_DIRECT_PLANNED=224,STEP48_MAX_NEW_1S_BRANCHES=352,
        STEP48_COMPLETE_WALL_DEADLINE_MS=20,STEP48_PREPARED_RESERVE_MS=17,STEP48_MAIN_S=e['S'][ARMS[1]]['status'],STEP48_SHIFTED_S=e['S'][ARMS[0]]['status'],STEP48_MAIN_P=e['P']['status'],STEP48_MAIN_C_TASK_ONLINE=e['C_TASK_ONLINE'][ARMS[1]]['status'],STEP48_SHIFTED_C_TASK_ONLINE=e['C_TASK_ONLINE'][ARMS[0]]['status'],STEP48_R_LEGACY=e['R_LEGACY_CROSS_POLICY']['status'],
        STEP48_EXECUTION_INTEGRITY=r['integrity'],STEP48_RESEARCH_CLOSURE=r['research_status'],STEP48_BINARY_VERDICT=r['readback']['binary_status'],STEP48_EVALUATION_VERDICT=r['readback']['evaluation_status'],STEP48_INDEPENDENT_NUMERICAL_REPRODUCTION='UNVERIFIED_NOT_REPEATED',
        FULL_TASK_COMPLETION_ESTABLISHED='FALSE',HARD_REALTIME_DEPLOYMENT_ESTABLISHED='FALSE',HISTORICAL_RESULTS_UNCHANGED='TRUE' if r['readback']['source_readonly_unchanged'] else 'FALSE',E3_AUTHORIZED='FALSE',RL_HARDWARE_AUTHORIZED='FALSE')
    ini='\n'.join(k+' = '+str(v) for k,v in status.items());text_file(out/'PROTOCOL_STATUS.ini',ini)
    coverage=[]
    for kind in ('CAL','TEST_direct','TEST_online'):
        a=r[kind];coverage.append([kind,a['planned'],a['attempted'],a['complete_501'],a['complete_physical_pass'],a['complete_physical_terminal'],a['complete_safe_6mm'],a['timing_qualified']])
    accept=[]
    for m in ARMS:
        s=e['S'][m];accept.append([m,s['planned'],s['recognized'],s['sent'],s['complete_safe_timely'],s['complete_wrong_accepts'],s['sent_partial'],s['abstain'],s['late'],s['status']])
    endpoints=[]
    for name,endpoint in [('P',e['P']),*[(m+' C',e['C_TASK_ONLINE'][m]) for m in ARMS],('R_LEGACY',e['R_LEGACY_CROSS_POLICY'])]:
        s=endpoint['support'];endpoints.append([name,endpoint['status'],s['physical_snapshots'],s['independent_episodes'],s['ids']])
    group_rows=[];domain_rows=[]
    for m,q in cal['methods'].items():
        for key,g in q['groups'].items():group_rows.append([m,key,g.get('CAL_planned'),g.get('CAL_complete'),g.get('CAL_complete_physical_failures'),g.get('CAL_complete_distinct_snapshots'),g.get('CAL_complete_episodes'),g.get('local_calibrated'),g.get('distance_threshold')])
        for key,g in q['domain_groups'].items():domain_rows.append([m,key,g['planned'],g['finite'],g['complete'],g['ready'],g['lo'],g['hi'],g['epsilon']])
    timing=[]
    for split in ('CAL','TEST'):
        for kind in ('PREPARATION','FEEDBACK'):
            for m in ARMS+DIRECT_METHODS:
                own=[w for w in lat if w['split']==split and w['kind']==kind and w['method']==m]
                if not own:continue
                full=[w['complete_ms'] for w in own if w['complete_ms'] is not None];pre=[w['prepared_ms'] for w in own if w['prepared_ms'] is not None]
                timing.append([split,kind,m,len(own),len(full),sum(w.get('missing_kind')=='PLANNED_NOT_RUN' for w in own),sum(w.get('missing_kind')=='PLANNED_NOT_REACHED_AFTER_PARTIAL' for w in own),sum(w.get('missing_kind')=='ACTUAL_WINDOW_VALUE_MISSING' for w in own),len(own)-len(full),len(own)-len(pre),sum(v>20 for v in full),sum(v>17 for v in pre),span(full)])
    chain_rows=[];cost=[]
    for m in ARMS:
        for subgroup,name in [(lambda q:True,'全部 severe'),(primary,'负向 RR')]:
            qq=[q for q in chain if q['comparison_arm']==m and subgroup(q)];opp=[q for q in qq if q['direct_C_opportunity']]
            chain_rows.append([m,name,len(qq),sum(q['direct_capacity_opportunity'] for q in qq),len(opp),sum(q['candidate_evaluated'] for q in opp),sum(q['numeric_original_gates_pass'] is True for q in opp),sum(q['physical_and_domain_accepted'] is True for q in opp),sum(q['recognized_sent_gamma_half'] for q in opp),sum(q['own_actual_safe_timely'] for q in opp),sum(q['qualified_C'] for q in qq)])
        own=[d for d in dec if d['method']==m];g0=[d for d in own if d['gamma0_requested']]
        for field in sorted({k for d in own for k in (d.get('phase_latency_ms') or {})}):
            values=[d['phase_latency_ms'][field] for d in own if d.get('phase_latency_ms') and d['phase_latency_ms'].get(field) is not None]
            cost.append([m,field,len(values),len(own)-len(values),span(values)])
    reject=Counter(reason for d in dec for q in d['queries'] for reason in q.get('rejection_reasons') or [])
    frows=[]
    for m in DIRECT_METHODS:
        qq=[q for q in F if q['method']==m and primary(q)]
        frows.append([m,len(qq),sum(q['both_complete'] for q in qq),sum(q['both_safe_timely'] for q in qq),span([q['first_base_gain_m'] for q in qq],1000),span([q['first_COM_gain_m'] for q in qq],1000),span([q['terminal_error_improvement_m'] for q in qq],1000),span([q['integral_improvement_m_s'] for q in qq],1000),span([q['left_terminal_vx_m_s'] for q in qq],1000),span([q['right_terminal_vx_m_s'] for q in qq],1000)])
    main=[q for q in chain if q['comparison_arm']==ARMS[1] and primary(q) and q['direct_C_opportunity']]
    support_reject=sum(q['local4_pass'] is False or q['domain_pass'] is False for q in main);late=sum(q['late'] for q in main)
    if e['closure_established']:
        lead='时相匹配主臂在本轮 fresh TEST 中建立 S、P 与 C_TASK_ONLINE 的有限局部闭合。'
        next_design='研究恢复终端到继续原任务阶段的衔接，并在更长时域评估阶段式任务收益。'
    elif r['integrity']=='INVALID_EVIDENCE':
        lead='本轮持久化或实现一致性问题使端点无法验证，issue 原样保留。';next_design='针对已保存 issue 修复执行/持久化语义，再单独冻结确认；不重派本轮位置。'
    elif e['S'][ARMS[1]]['complete_wrong_accepts'] or e['S'][ARMS[1]]['sent_partial']:
        lead='主臂真实发送后的错受或不完整执行使有限接收链未成立。';next_design='将故障后反馈执行可行性与恢复终端支持统一建模，针对真实错受/partial 设计独立确认。'
    else:
        lead='本轮时相 CAL/domain 支持对照已完成，学习端到端接收链未全部成立，各端点独立列示。'
        if support_reject>late:next_design='建立接触状态感知、时相条件化的恢复可行性表示与匹配 proposal 支持，保留真实失败标签，不再循环同规模 CAL 扩框追求过门。'
        elif late:next_design='研究将候选预测与原物理验证融合的一阶段在线决策结构；保留实际 begin→commit 的 17/20 ms 门，不外移动态检查。'
        else:next_design='明确备份本身安全与容量失效后的在线恢复责任分界，预冻结具有可识别容量机会的独立任务阶段协议。'
    write(out/'DELIVERY_SUMMARY.json',dict(lead=lead,next_design_only=next_design,primary_direct_C_opportunities=len(main),support_rejections_overlap=support_reject,late_overlap=late,reject_counts_overlap=dict(reject),new_QP=0,new_steps=0,new_fits=0))
    body(out,r,e,budget,cal,tests,ini,coverage,accept,endpoints,group_rows,domain_rows,timing,chain_rows,cost,reject,frows,P,online,backups,lead,next_design)
def body(out,r,e,budget,cal,tests,ini,coverage,accept,endpoints,group_rows,domain_rows,timing,chain_rows,cost,reject,frows,P,online,backups,lead,next_design):
    middle=[q for q in P if primary(q) and q['arm']=='MIDDLE']
    decisions=read(out/'ONLINE_DECISIONS.json');measured=[]
    for cid in ('T48_TEST_1_T041_RR_THIGH15','T48_TEST_3_T041_RR_THIGH15'):
        pairdec=[next(d for d in decisions if d['context_id']==cid and d['method']==m) for m in ARMS]
        for m,q in zip(ARMS,pairdec):
            half=next(a for a in q['queries'] if a['gamma']=='0.5')
            measured.append([cid,m,half['original_accepted_same_candidate'],(half.get('local4') or {}).get('accepted'),(half.get('domain') or {}).get('accepted'),q['gamma0_requested'],q['prepared_ms'],q['complete_ms'],q['selected_command_sent']])
    report=f'''# STEP48：CAL 请求时相对齐与 fresh 容量在线确认

{lead}

研究状态 `{r['research_status']}`；固定批次执行完整性 `{r['integrity']}`。完成固定清单与建立科学端点分别判断。

## Material Passport

- Origin Skill: experiment-agent / academic-research-suite（ARS）
- Origin Mode: run
- Origin Date: 2026-10-12 KST
- Verification Status: UNVERIFIED（未开展独立数值复现）
- Version Label: exp_result_step48_v1

目标 T-RO。当前工件的完整数值解码与冻结独立评价比较在下文另列，不升级为数值重现实验。

## 执行范围与身份

[完整执行协议](../../../configs/STEP48_EXECUTION_PROTOCOL.md)。工作树 `{OUTPUT_ROOT_D.as_posix()}`，分支 `codex/step48-phase-matched-cal-confirmation-20261012`；源 `{SOURCE_COMMIT}`；run_id `{RUN_ID}`。

两臂都安装同一 TASK_AWARE_1MM_06S_V1 live/backup/staging servo：1 mm cap、0.60 s ramp、physical .02 s 起、.62 s 停止。HOLD 来源的原 predictor/normalizer/全部 TRAIN 不变，0 新 TRAIN、0 fit。`policy_contract.method` 保持 TASK_MATCHED，外部 comparison_arm 和 STEP48 freeze hash 单独绑定 context、packet、receipt 与 purpose。own ACTUAL 使用产生 DECISION 的同一 live owner，各分支 owner/B0/积分/warm-start/backup ID 独立；nominal task、原 anchor 与物理时钟不变。

PHASE_SHIFTED_TASK 原字节复制 STEP47 的三资产和完整 policy_contract、64 行成功/失败 CAL，phase36/40；它们是旧冻结支持，不是本轮 fresh CAL。PHASE_MATCHED_TASK 仅使用新 64 行 phase37/41，未合并旧新支持。精确 SHA256 见 [BASELINE_ASSET_BINDING.json](BASELINE_ASSET_BINDING.json)。两臂差异归因限于整套 CAL/domain 请求时相支持布局；按原公式变化的 box、残差、距离、风险统计和邻居均属于该方法包，不能归因于单一 box 或预设消除 late。

新 CAL 8 episode、16 snapshot、32 severe context，每 gamma32；幅度 ±62.125/64.375/66.625/68.875 mm。fresh TEST 8 独立 episode，目标 ±62.500/64.500/66.500/68.250 mm，tick37/41；TEST whole episode、目标和标签不复用 STEP47。两份 DECISION 均先不可变保存，之后才推进各 own ACTUAL，再执行共享 direct HOLD/TASK；每个物理对照只传播一次，没有复制 direct 为在线结果。

## 全部计划位与覆盖

{table(['位置','计划','有轨迹','501点完整','physical','physical+terminal','safe6mm','全部在线及时'],coverage)}

352 条 1 s 计划上限与 16 reference 分开列示。未发送位置及预算 NOT_RUN 保留，不补成物理失败或成功。CAL 是 OFFLINE_PHYSICS_ORACLE：有效 wall-late 命令可生成理想施加物理标签，online qualification 为 FALSE；TEST 首包和 feedback 保留严格 prepared17 / complete20 ms 门及 native B/C/feedback6/3/6 ms。原 500步/501dense、21精确 checkpoint、42维 raw/sent、6 mm local、2 mm terminal、1 mm/s 停止、精度/摩擦/torque inset 与独立评价器保持。

{table(['比较臂','计划','模型认可','发送','完整安全及时','完整错受','已发送partial','ABSTAIN','late','S'],accept)}

## 两臂 CAL/domain 支持

{table(['臂','group','计划','完整','完整物理失败','snapshot','episode','local ready','原公式 distance threshold'],group_rows)}

{table(['臂','stratum','计划','finite','complete','ready','raw lo','raw hi','原epsilon'],domain_rows)}

原三轴 v_now/v_prefix_end/u_sent_max；所有有限行，包括完整失败，均参与 min/max，relative epsilon=1e-12，readiness4snapshot/2episode。CAL local4 按原 label-blind 距离与去重/episode规则，不跳过失败邻居，不从 TEST 扩界。未使用角色保持无支持，无全局 readiness veto。完整状态见 [STEP48_CAL_FREEZE.json](STEP48_CAL_FREEZE.json)、[CAL_ROWS.json](CAL_ROWS.json)、[CAL_DOMAIN_ROWS.json](CAL_DOMAIN_ROWS.json)。

## S、P、两臂 C 与旧定义 R

{table(['端点','判定','physical snapshot','whole episode','合格来源ID'],endpoints)}

P 负向 RR severe MIDDLE 的八个计划 snapshot / 四个 episode 均发布：同 gamma TASK 相对 HOLD 的完整末外部误差改善范围 {span([q['terminal_error_improvement_m'] for q in middle],1000)} mm，积分改善 {span([q['integral_improvement_m_s'] for q in middle],1000)} mm·s；只有两侧完整安全及时、末误差改善≥0.20 mm且积分不增才计支持。各臂 own ACTUAL 对同 source/gamma HOLD direct 的用途配对另见 [ONLINE_TASK_PAIRS.csv](ONLINE_TASK_PAIRS.csv)，两臂 learned 包比较见 [LEARNED_PACKAGE_PAIRS.csv](LEARNED_PACKAGE_PAIRS.csv)。选不同 gamma 明示为完整方法包比较。

C 要求本臂 timely gamma=.5 实际发送、安全完整 own ACTUAL；同 TASK healthy/mild B 安全及时、severe B 完整物理失败，sent/effective 和 applied/effective≥99%事件均严格早于首次 dense 失败，并满足同 gamma HOLD 用途目标；仍要求3snapshot/2独立负向 RR episode。R_LEGACY_CROSS_POLICY 采用 HOLD 自身 timely Type-II＋TASK MIDDLE/P共存，独立列示，不回写 STEP47 已确认 R。

TASK_BACKUP_SAFE={sum(q['TASK_BACKUP_SAFE'] for q in backups)}；COMPARATIVE_BACKUP_ONLY_RECOVERY={sum(q['COMPARATIVE_BACKUP_ONLY_RECOVERY'] for q in backups)}。TASK B 本身安全不是 Type-II 机会；HOLD late/缺测不冒充真实失败。

## 机会与拒因分层

{table(['臂','层','计划','direct容量机会','direct容量+middle用途','候选已评价','原数值门通过','物理/域认可','实际gamma.5发送','own安全及时','最终C'],chain_rows)}

direct容量机会只依 healthy/mild/severe B、容量先于失败和 timely 真实对照；direct容量+middle用途是额外诊断层，不增加科学 C 的门。后续列在该诊断机会子集计数，最终 C 按原定义对全体来源独立计算，不因诊断子集缺测剪掉科学支持。prepared、完整、local4、domain、late 可重叠；不把 late 再加到互斥机会分母。

拒因出现次数（可重叠、每候选计）：`{dict(reject)}`。逐source/gamma全部 numeric gates、local4四个邻居 ID/request phase/真实物理标签、domain raw query/lo/hi/epsilon/pass 和是否进入 gamma0，见 [REQUEST_SUPPORT_DIAGNOSTICS.json](REQUEST_SUPPORT_DIAGNOSTICS.json)、[OPPORTUNITY_CHAIN.csv](OPPORTUNITY_CHAIN.csv)。未评价候选的门保持空值，不猜测。

以下两项是本轮新旧臂都已评价 gamma=.5 的已测路径差异，完整来源仍在全体表中发布：

{table(['source','臂','原数值门','local4','domain','gamma0请求','prepared ms','complete ms','实际发送'],measured)}

旧臂在这两项域拒收后进入 gamma0 且最终准备迟到；新臂原门和域认可后早选 gamma=.5、未请求 gamma0，成为新增 C 支持。归因仍是整套时相支持布局，不把所有时延差异归于 gamma0。负向 RR 的真实失败 local4 邻居在新旧臂均保留，未因本轮 C 成立把失败标签称为错误。

## 全体时延与路径成本

{table(['split','窗口','方法','planned','有complete','计划未运行','partial未到达','actual值缺失','缺complete','缺prepared','complete>20','prepared>17','complete范围ms'],timing)}

TEST 实际施加的 late 窗口 {r['late_TEST_windows_applied']} 个。TASK clock检查 {r['TASK_clock_checks']} 条 / 失败 {r['TASK_clock_failures']}。只记录 wall time，不扣除 OS/GC 停顿、不换 CPU计时；两 online 臂是同一实现及诊断开销。

{table(['臂','嵌套计时字段','observed','missing','范围ms'],cost)}

B/C/G.5/G0各段仅独立列示，不能把嵌套分项相加。gamma0 未请求与请求后未评价分别保留；prepared/feedback planned-not-run占位和 actual值缺失分开，缺测不填0。完整表见 [LATENCY.csv](LATENCY.csv)、[ONLINE_DECISIONS.json](ONLINE_DECISIONS.json)。

## F：任务分量不预设优势

{table(['policy','负向RR计划','两侧完整','两侧safe timely','middle-B首base mm','middle-B首COM mm','B-middle末误差 mm','B-middle积分 mm s','middle末vx mm/s','B末vx mm/s'],frows)}

首动作、1 s末外部任务误差、积分、停止速度各自报告；clipped参考误差不替代原任务误差，middle全任务更优没有预设 PASS。完整原始配对见 [F_COMPONENT_PAIRS.csv](F_COMPONENT_PAIRS.csv)，所有方向/腿在 [SUPPORT_MATRIX.csv](SUPPORT_MATRIX.csv) 和 [BRANCH_ROWS.csv](BRANCH_ROWS.csv) 发布。

## 执行预算、测试与唯一当前读回

数值起点 `{budget['numerical_started_utc']}`；结束 `{r['run']['finish_utc']}`；实际墙钟 {budget['numerical_elapsed_s']:.3f}/5400 s，QP {budget['total_QP_calls']}/30000，积分 {budget['total_physics_steps']}/280000。reference/startup/priming/endpoint/application/prefix/feedback全部计入。0fit、0旧故障轨迹重算；QP START/RETURN/raw与积分预约账本见 [STEP48_LEDGER.jsonl](STEP48_LEDGER.jsonl)。

一次环境检查；一组必要 pure fixture 共 {tests['tests_run']} 项，{tests['failures']} failures / {tests['errors']} errors，0 QP /0积分。命令及结果见 [tests/COMMANDS.json](tests/COMMANDS.json)、[tests/NECESSARY_TESTS.json](tests/NECESSARY_TESTS.json)。第一条 reference 前冻结方法/输入，不做真实 canary 或旧套件复跑。

每 shard先保存JSON verdict/issues再导CSV。一次本轮 streaming读回状态 `{r['readback']['status']}`；binary=`{r['readback']['binary_status']}`；evaluation=`{r['readback']['evaluation_status']}`；issues=`{r['readback']['issues']}`。实际恢复 physical/control完整数值再与同一冻结独立评价比较；QP raw文件核对hash与序号，不作历史求解审计。读回0新求解/0积分，独立数值复现未执行（UNVERIFIED_NOT_REPEATED）。

源 STEP47结果/P/R不变，旧bank不重遍历；STEP46 UNRECORDED不改。源HEAD/index/当前源元数据限定核对和实际新文件/Git状态见 [FINAL_VERIFICATION.json](FINAL_VERIFICATION.json)。

## SciPilot 两图

图1：全体两臂 planned→认可→prepared及时→实际完整→C，所有32源逐格状态、原local4失败数和三轴域支持；图2：全体TEST first/feedback时延、gamma0请求与独立分段、预定首个负向RR四方source及原始末任务配对。原始点、失败/缺测、17/20 ms门均保留，无小样本均值柱/显著性猜测。data profile、程序QA、视觉检查留存 figures/；IEEE双栏7.16 in、600dpi PNG与TrueType PDF，灰度冗余编码。

![图1](figures/FIG1_PHASE_SUPPORT.png)

![图2](figures/FIG2_TIMING_CAPACITY_TASK.png)

[图1 PDF](figures/FIG1_PHASE_SUPPORT.pdf)；[图2 PDF](figures/FIG2_TIMING_CAPACITY_TASK.pdf)。图仅使用本轮已保存派生表，不追加求解或重读旧bank补图。

## 交接与停止

下一项实质设计（仅建议）：{next_design}

本轮收尾停止，不循环追加同规模CAL直到过门，不启动新TRAIN、下一批、E3、RL或硬件。局部端点不推广为完整±60余mm任务、全故障泛化、长期持续或硬实时部署。一次scoped本地提交，不push；提交号见最终交付消息。

```ini
{ini}
```
'''
    text_file(out/'REPORT.md',report)
    handoff=f'''# STEP48 研究交接

{lead}

[中文报告](REPORT.md)；[完整协议状态](PROTOCOL_STATUS.ini)；[唯一当前结果](STEP48_RESULT.json)。

工作树 `{OUTPUT_ROOT_D.as_posix()}`，分支 `codex/step48-phase-matched-cal-confirmation-20261012`，源 `{SOURCE_COMMIT}`；run_id `{RUN_ID}`。固定清单 `{r['run']['status']}`，研究端点 `{r['research_status']}`。

主S `{e['S'][ARMS[1]]['status']}`、P `{e['P']['status']}`、主C `{e['C_TASK_ONLINE'][ARMS[1]]['status']}`，旧臂S/C及本轮R单列；STEP47科学判定不变。

改动仅CAL/domain时相支持整套布局；两TASK控制律/原TRAIN/接受/物理/时限门保持。旧64行支持是旧冻结资产，新64行独立whole-episode phase37/41 CAL；不合并、不过滤失败、不从TEST扩域。

下一设计仅建议：{next_design}

本轮读回已执行一次，不再重派完成位置、不重新遍历STEP47 raw bank。未知调用不重派，普通失败和未施加完整保留。没有独立数值复现，UNVERIFIED_NOT_REPEATED。验证命令/Git范围与一次提交见 tests/、FINAL_VERIFICATION.json。

Material Passport: experiment-agent / ARS，run，2026-10-12 KST，UNVERIFIED，exp_result_step48_v1。E3/RL/hardware=FALSE；不得自行启动后续研究。
'''
    text_file(out/'HANDOFF.md',handoff)
    write(out/'PACKAGE_RECEIPT.json',dict(timestamp_utc=datetime.now(timezone.utc).isoformat(),research_status=r['research_status'],report_sha256=sha(out/'REPORT.md'),handoff_sha256=sha(out/'HANDOFF.md'),protocol_status_sha256=sha(out/'PROTOCOL_STATUS.ini'),new_QP=0,new_steps=0,new_fits=0))
    print(dict(research_status=r['research_status'],integrity=r['integrity'],report=str(out/'REPORT.md')),flush=True)
if __name__=='__main__':run()
