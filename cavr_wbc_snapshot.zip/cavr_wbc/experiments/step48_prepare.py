"""One D-space/write/import confirmation and exact source-asset binding."""
import os,shutil
from cavr_wbc.experiments.step48_io import *
from cavr_wbc.experiments.step48_inputs import *
from cavr_wbc.control import step39_margin as margin
def prepare():
    out=output();out.mkdir(parents=True,exist_ok=True)
    if (out/'PREPARATION.json').exists():raise FileExistsError('one environment check only')
    import cavr_wbc,mujoco,osqp,scipy,threadpoolctl
    if not Path(cavr_wbc.__file__).resolve().is_relative_to(OUTPUT_ROOT_D):raise ValueError('wrong package')
    free=shutil.disk_usage(OUTPUT_ROOT_D).free
    if free<8_000_000_000:raise OSError('insufficient D space for bounded output and Git objects')
    write(out/'PREPARATION.json',dict(package=cavr_wbc.__file__,D_free_bytes=free,D_write_marker=True,
        TMP=os.environ['TMP'],TEMP=os.environ['TEMP'],MPLCONFIGDIR=os.environ['MPLCONFIGDIR'],new_QP=0,new_physics=0,
        versions=dict(mujoco=mujoco.__version__,osqp=osqp.__version__,numpy=np.__version__,scipy=scipy.__version__),threadpools=threadpoolctl.threadpool_info()))
    assets={};folder=out/'models/PHASE_SHIFTED_TASK';folder.mkdir(parents=True,exist_ok=True)
    for name,digest in BASELINE_HASHES.items():
        source=SOURCE_RUN/'models'/name
        if sha(source)!=digest:raise ValueError('source STEP47 asset hash: '+name)
        destination=folder/name
        if destination.exists():raise FileExistsError('old asset copy cannot overwrite')
        shutil.copyfile(source,destination)
        if sha(destination)!=digest:raise ValueError('baseline copy changed')
        assets[name]=dict(source=str(source),copied=str(destination),sha256=digest)
    config=read(SOURCE_RUN/'SOURCE_FROZEN_CONFIG.json')
    config.update(feature_names=list(margin.FEATURE_NAMES),feature_dimension=28)
    write(out/'SOURCE_FROZEN_CONFIG.json',config)
    old_manifest=read(SOURCE_RUN/'PROTOCOL_AND_MANIFEST.json')
    write(out/'ACTUAL_POLICY_CONTRACTS.json',old_manifest['policy_contracts'])
    write(out/'BASELINE_ASSET_BINDING.json',dict(assets=assets,baseline_reused_rows=64,baseline_phase=[36,40],
        entire_policy_contract_unchanged=True,no_old_fault_replay=True,old_failed_neighbors_retained=True))
    write(out/'SOURCE_READONLY_BASELINE.json',dict(source_commit=SOURCE_COMMIT,source_worktree=str(SOURCE_ROOT_D),
        source_result_sha256=sha(SOURCE_RUN/'STEP47_RESULT.json'),source_index_sha256=sha(SOURCE_ROOT_D/'.git/index'),
        source_config_sha256=sha(SOURCE_RUN/'SOURCE_FROZEN_CONFIG.json'),source_history_not_reaudited=True,
        STEP47_result='NOT_ESTABLISHED',STEP47_P_R='ESTABLISHED_LOCAL_CONFIRMATION',STEP46_binary_eval='UNRECORDED_UNCHANGED'))
    write(out/'INPUTS_PLAN.json',dict(CAL_episodes=episodes('CAL'),TEST_episodes=episodes('TEST'),CAL_contexts=plans('CAL'),TEST_contexts=plans('TEST'),
        positions=positions('CAL')+positions('TEST'),CAL_planned=64,TEST_contexts_planned=80,decisions_planned=64,direct_planned=224,
        online_actual_max=64,branch_max=352,reference_episodes=16,new_TRAIN=0,new_fits=0,max_wall_s=5400,max_QP=30000,max_steps=280000))
    print(dict(prepared=True,new_CAL=64,decisions=64,direct=224,new_QP=0,new_physics=0),flush=True)
if __name__=='__main__':prepare()
