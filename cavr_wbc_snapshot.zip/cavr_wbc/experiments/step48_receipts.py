"""Same frozen evaluator; comparison identity persisted before CSV."""
from cavr_wbc.experiments.step47_receipts import evaluate,numeric_equal,compare_labels
from cavr_wbc.experiments.step48_io import write,append,relative
def immediate(out,path,c,rec):
    receipt,branch=evaluate(path,c,rec)
    receipt.update(comparison_arm=c['comparison_arm'],step48_method_freeze_sha256=c['step48_method_freeze_sha256'])
    write(path/'SHARD_RECEIPT.json',receipt)
    append(out/'SHARD_RECEIPTS.jsonl',dict(path=relative(path,out),**receipt))
    if receipt['issues']:raise ValueError('current scientific shard mismatch: '+str(receipt['issues']))
