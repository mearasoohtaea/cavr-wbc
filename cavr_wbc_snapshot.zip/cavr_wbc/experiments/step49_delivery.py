"""One current-run numeric readback; JSON verdict precedes CSV, no solve."""
from datetime import datetime,timezone
from collections import Counter
from pathlib import Path
import csv,json
import numpy as np
from cavr_wbc.experiments.step49_io import *
from cavr_wbc.experiments.step49_inputs import positions,episodes
from cavr_wbc.experiments.step49_storage import load_branch
from cavr_wbc.evaluation.step49_actual import evaluate
from cavr_wbc.control.step49_policy import mission_reference
def same(a,b):return json.dumps(encode(a),sort_keys=True)==json.dumps(encode(b),sort_keys=True)
def endpoints(rows):
    main=[r for r in rows if r['arm']=='MIDDLE_RECOVER_RESUME'];goals=[r for r in main if r.get('mission_success')]
    paired=[]
    by={(r['snapshot_id'],r['health_kind'],r['arm']):r for r in rows}
    for r in main:
        others={a:by[(r['snapshot_id'],'RR_THIGH15',a)] for a in ('IMMEDIATE_MISSION','B_RECOVER_RESUME','MIDDLE_RECOVER_HOLD')}
        entry=dict(snapshot_id=r['snapshot_id'],episode=r['episode'],main_mission_success=r['mission_success'],planned_pair=True)
        for arm,o in others.items():
            both=bool(r.get('complete_2001') and o.get('complete_2001'))
            entry[arm]=dict(mission_success=o['mission_success'],physical_failure=o.get('physical_failure_count',0)>0,
                late=o.get('late',False),both_complete=both,
                goal_error_difference_m=abs(o['final_goal_error_m'])-abs(r['final_goal_error_m']) if both else None,
                external_integral_difference_m_s=o['external_reference_error_integral_0to4_available_m_s']-r['external_reference_error_integral_0to4_available_m_s'] if both else None)
        entry['recovery_physical_safety_advantage']=bool(r['mission_success'] and entry['IMMEDIATE_MISSION']['physical_failure'] and not entry['IMMEDIATE_MISSION']['late'])
        entry['recovery_goal_advantage']=bool(r['mission_success'] and not others['IMMEDIATE_MISSION']['mission_success'] and not others['IMMEDIATE_MISSION'].get('late'))
        paired.append(entry)
    adv=[p for p in paired if p['recovery_physical_safety_advantage']]
    transition=[r for r in main if r.get('handoff_committed') and r.get('continuity_pass')]
    def support(items):
        return dict(snapshots=len({r['snapshot_id'] for r in items}),episodes=len({r['episode'] for r in items}))
    m=support(goals);v=support(adv);g=support(transition)
    groups={}
    for kind,arm in [(k,a) for k in ('RR_THIGH15','HEALTHY','RR_THIGH30') for a in
        (('MIDDLE_RECOVER_RESUME','MIDDLE_RECOVER_HOLD','IMMEDIATE_MISSION','B_RECOVER_RESUME') if k=='RR_THIGH15' else ('IMMEDIATE_MISSION',))]:
        rs=[r for r in rows if r['arm']==arm and r['health_kind']==kind]
        groups[kind+':'+arm]=dict(planned=len(rs),applied=sum(r['experimental_applied'] for r in rs),
            complete_phase1=sum(r.get('phase1_complete',False) for r in rs),
            recovery_gate_pass=sum(r.get('phase1_gate_pass',False) for r in rs),
            forced_gate_count=sum(r.get('forced_recovery_gate',False) for r in rs),
            actual_handoff_committed=sum(r.get('handoff_committed',False) for r in rs),
            complete_4s=sum(r['complete_2001'] for r in rs),physical_safe_timely=sum(r.get('physical_safe',False) and r.get('timing_qualified',False) for r in rs),
            mission_success=sum(r['mission_success'] for r in rs),physical_failure=sum(r.get('physical_failure_count',0)>0 for r in rs),
            late=sum(r.get('late',False) for r in rs),gate_rejected=sum(r['status']=='PHASE1_GATE_FAILED' for r in rs),
            classifications=dict(Counter(r.get('final_classification',r['status']) for r in rs)))
    return dict(G=dict(status='ESTABLISHED_LOCAL_HANDOFF' if g['snapshots'] else 'NOT_ESTABLISHED',**g),
        M=dict(status='ESTABLISHED_LOCAL_PILOT' if m['snapshots']>=3 and m['episodes']>=2 else 'NOT_ESTABLISHED',**m),
        V=dict(status='ESTABLISHED_STAGE_SAFETY_OBSERVATION' if v['snapshots']>=2 and v['episodes']>=2 else 'NOT_ESTABLISHED',**v),
        groups=groups,paired=paired,no_population_significance_claim=True)
def deliver():
    out=output()
    if not (out/'RUN_FINISHED.json').exists():raise ValueError('numerical process not finished')
    if (out/'READBACK_VERDICT.json').exists():raise FileExistsError('one readback already completed')
    write(out/'READBACK_STARTED.json',dict(start_utc=datetime.now(timezone.utc).isoformat(),scope='CURRENT_STEP49_ONLY',new_QP=0,new_steps=0))
    rows=[];latency=[];issues=[];series=[]
    for pos in positions():
        path=out/'branches'/pos['context_id']/pos['arm'];r=read(path/'RESULT.json')
        local=[];row={**pos,**{k:v for k,v in r.items() if k not in ('capacity','contact_statistics','artifact','controls_numeric','evaluation')}}
        row.update(r.get('evaluation',{}));row['phase1_complete']=row.get('phase1',{}).get('complete',False)
        row['phase1_gate_pass']=row.get('phase1',{}).get('pass',False)
        row['forced_recovery_gate']=pos['arm']!='IMMEDIATE_MISSION'
        row['handoff_committed']=bool(r.get('handoff') and r['handoff'].get('staging_committed'))
        row['continuity_pass']=bool(r.get('continuity_start')==r.get('continuity_end') and r.get('continuity_start') is not None)
        reason=(r.get('reason') or {}).get('reason','')
        row['late']=bool('DEADLINE'in reason or 'LATE'in reason)
        row['capacity_first_99_s']=r.get('capacity',{}).get('first_actual_99percent_s')
        if r.get('observed'):
            c=load_numeric(path/'POLICY_CONTEXT.json');packet=load_numeric(path/'PACKET.json');branch=load_branch(path)
            lab=evaluate(branch,c,packet)
            if not same(lab,r['evaluation']):local.append('frozen evaluation mismatch')
            if sha(path/'actual.npz')!=r['artifact']['sha256']:local.append('fact bank SHA mismatch')
            if not same(branch['phase1_online_summary'],lab['phase1']):local.append('online phase1 gate mismatch')
            if branch['continuity_start']!=branch['continuity_end']:local.append('owner/plant/PID continuity mismatch')
            if not branch.get('application_identity_pass'):local.append('application state identity mismatch')
            h=r.get('handoff')
            if h:
                if h['logical_slot']!=49 or abs(h['physical_time_s']-1.)>1e-9 or abs(h['physical_time_after_transaction_s']-1.)>1e-9:local.append('handoff physical/logical clock mismatch')
                if h.get('gate') and not same(h['gate'],lab['phase1']):local.append('handoff prefix gate mismatch')
                if (not h['gate_accepted'] or h['late']) and (h['new_feedback_QP_calls']!=0 or h['staging_committed']):local.append('gate rejected/late but numerical dispatch occurred')
            dense=([branch['initial_fact']] if branch.get('initial_fact') else [])+branch['physics_trajectory']
            continuous=[]
            goal=float(c['nominal_q_init'][0])+float(c['nominal_d_m']);anchor=float(c['backup_anchor_q_init'][0])
            for f in dense:
                if 'qpos'in f:continuous.append(dict(time_s=f['time_s'],physics_step=f['physics_step'],
                    base_x_m=f['qpos'][0],vx_m_s=f['qvel'][0],goal_m=goal,anchor_m=anchor,
                    signed_D_m=c['direction']*(f['qpos'][0]-anchor),goal_error_m=f['qpos'][0]-goal))
            series.append(dict(id=pos['id'],snapshot_id=pos['snapshot_id'],episode=pos['episode'],tick=pos['tick'],
                health_kind=pos['health_kind'],arm=pos['arm'],status=r['status'],complete=r['complete_2001'],goal_m=goal,anchor_m=anchor,series=continuous))
            if len(branch['checkpoints'])!=(len(dense)+24)//25:local.append('long/partial landmark grid mismatch')
            latency.append(dict(id=pos['id'],arm=pos['arm'],health_kind=pos['health_kind'],slot=1,kind='FIRST',
                complete_ms=packet['command_ready_ms'],prepared_ms=packet['prepared_commit_ms'],applied=r['experimental_applied'],callback_ms=None))
            for ctrl in branch['controls']:
                if ctrl['slot']<=1:continue
                t=ctrl.get('timing',{});ref=ctrl.get('backup_reference')
                applied=ctrl.get('tau_applied') is not None
                prep=(ctrl.get('prepare_callback') or {})
                physical_time=ctrl['slot']*.02
                if applied:
                    active=(pos['arm']=='IMMEDIATE_MISSION' and physical_time>=.04) or (pos['arm']in ('MIDDLE_RECOVER_RESUME','B_RECOVER_RESUME') and physical_time>=1.)
                    expected=mission_reference(anchor,goal,pos['arm'],physical_time,active)
                    if ref is None or any(abs(float(ref[k])-float(expected[k]))>1e-12 for k in ('p_ref_m','v_ref_m_s','a_ref_m_s2')):local.append('actual reference mismatch slot '+str(ctrl['slot']))
                    if ctrl['slot']-1!=ctrl['backup_feedback_logical_slot']:local.append('feedback logical slot reset')
                    if physical_time>=1. and expected['phase_policy_id']!='TASK_AWARE_1MM_06S_V1' and ctrl.get('phase_policy_id')!=expected['phase_policy_id']:local.append('phase2 mislabelled old policy')
                latency.append(dict(id=pos['id'],arm=pos['arm'],health_kind=pos['health_kind'],slot=ctrl['slot'],
                    kind='HANDOFF' if ctrl['slot']==50 else 'FEEDBACK',complete_ms=ctrl['command_ready_ms'],
                    prepared_ms=t.get('prepared_commit_ms'),applied=applied,callback_ms=prep.get('callback_ms'),
                    native_QP_limit_s=ctrl.get('native_QP_limit_s')))
            del branch,packet,c,dense
        else:
            row['late']=row['late'] or reason=='EXPERIMENT_LATE_UNAPPLIED'
            latency.append(dict(id=pos['id'],arm=pos['arm'],health_kind=pos['health_kind'],slot=1,kind='FIRST',
                complete_ms=r.get('first_packet_ready_ms'),prepared_ms=r.get('first_packet_prepared_ms'),applied=False,callback_ms=None))
        row['last_available_is_not_filled']=True;rows.append(row)
        write(path/'READBACK_RECEIPT.json',dict(status='MATCH' if not local else 'MISMATCH',issues=local,
            verdict_before_CSV=True,current_bank_only=True,new_QP=0,new_steps=0))
        issues.extend([pos['id']+': '+q for q in local])
    # All current raw numerical shards are decoded exactly once; never solved.
    ledger=[json.loads(s) for s in (out/'STEP49_LEDGER.jsonl').read_text(encoding='utf-8').splitlines()]
    starts={r['global_qp_index'] for r in ledger if r['event']=='QP_START'}
    returns={r['global_qp_index'] for r in ledger if r['event']=='QP_RETURN'}
    raw=[];return_rows={r['global_qp_index']:r for r in ledger if r['event']=='QP_RETURN'}
    for event in (r for r in ledger if r['event']=='RAW_QP_SAVED'):
        p=out/event['path']
        if sha(p)!=event['json_sha256'] or sha(p.with_suffix('.npz'))!=event['npz_sha256']:issues.append('raw hash mismatch '+event['path'])
        record=load_numeric(p);ix=record['global_qp_index'];q=record['raw_result'];raw.append(ix)
        if ix not in returns or q.get('solver_owner_id')!=return_rows[ix].get('solver_owner_id'):issues.append('raw ledger identity '+str(ix))
    finish=read(out/'RUN_FINISHED.json');baseline=read(out/'SOURCE_READONLY_BASELINE.json')
    source_ok=sha(SOURCE_ROOT_D/'.git/index')==baseline['source_index_sha256'] and sha(SOURCE_RUN/'STEP48_RESULT.json')==baseline['source_result_sha256'] and sha(SOURCE_RUN/'SOURCE_FROZEN_CONFIG.json')==baseline['source_config_sha256']
    if not source_ok:issues.append('source metadata changed')
    if starts!=returns or starts!=set(raw) or len(raw)!=len(starts):issues.append('START/RETURN/raw ledger completeness')
    if not read(out/'RUNTIME_END.json')['runtime_sha256_unchanged']:issues.append('frozen runtime mutation')
    refs=[]
    for ep in episodes():
        p=out/'episodes'/(ep['episode_id']+'.json')
        if p.exists():
            v=load_numeric(p);refs.append(dict(episode_id=ep['episode_id'],status=v['status'],counts=v['counts'],missing_snapshot_ticks=v['missing_snapshot_ticks']))
        else:refs.append(dict(episode_id=ep['episode_id'],status='NOT_RUN'))
    result=dict(run_id=RUN_ID,run_status=finish['status'],planned_positions=48,rows=len(rows),references=refs,
        observed=sum(r.get('observed',False) for r in rows),complete_4s=sum(r['complete_2001'] for r in rows),
        mission_success=sum(r['mission_success'] for r in rows),endpoints=endpoints(rows),
        budget=finish['budget'],source_unchanged=source_ok,issues=issues,
        status='INVALID_READBACK' if issues else 'DIRECT_MISSION_PILOT_COMPLETED' if finish['status']=='COMPLETED' else 'INCOMPLETE',
        no_new_CAL_TRAIN_fits_governor=True,independent_numerical_reproduction=False)
    write(out/'BRANCH_ROWS.json',rows);write(out/'LATENCY.json',latency);write(out/'TRAJECTORY_SERIES.json',series)
    write(out/'STEP49_RESULT.json',result)
    write(out/'READBACK_VERDICT.json',dict(status='MATCH' if not issues else 'MISMATCH',issues=issues,
        branches=len(rows),decoded_fact_banks=sum(r.get('observed',False) for r in rows),decoded_raw_QP=len(raw),
        actual_evaluation_frozen=True,new_QP=0,new_steps=0,independent_numerical_reproduction=False,
        timestamp_utc=datetime.now(timezone.utc).isoformat()))
    # Only scalar table columns; JSON adjudication is already durable.
    fields=['id','episode','snapshot_id','tick','health_kind','arm','status','experimental_applied','complete_2001',
        'phase1_complete','phase1_gate_pass','forced_recovery_gate','handoff_committed','continuity_pass','mission_success',
        'physical_safe','timing_qualified','late','final_goal_error_m','final_vx_m_s','final_half_second_vx_RMS_m_s',
        'D_0to1_m','D_0to4_available_m','external_reference_error_integral_0to4_available_m_s',
        'external_reference_error_integral_1to4_available_m_s','sustained_goal_stop_time_s','capacity_first_99_s',
        'min_friction_margin_n','min_command_torque_margin_nm','min_applied_torque_margin_nm','physical_failure_count']
    with (out/'BRANCH_ROWS.csv').open('w',encoding='utf-8',newline='') as stream:
        w=csv.DictWriter(stream,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)
    print(dict(status=result['status'],complete_4s=result['complete_4s'],mission_success=result['mission_success'],issues=len(issues),endpoints={k:result['endpoints'][k] for k in ('G','M','V')}),flush=True)
if __name__=='__main__':deliver()
