"""SciPilot current decoded tables only: two figures, no QP or bank replay."""
from pathlib import Path
import argparse,sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from PIL import Image
from cavr_wbc.experiments.step49_io import output,read,write,sha
from cavr_wbc.control.step49_policy import ARMS
from cavr_wbc.experiments.step47_figures import embedded_fonts
SKILL=Path('C:/Users/ZhuanZ（无密码）/.codex/skills/scipilot-figure/scripts')
sys.path.insert(0,str(SKILL))
from setup_style import setup_style
from profile_data import profile_data,render_report
from visual_qa import audit_layout,render_preview
from export_figure import export_figure
from check_figure import check_figure
from layout_tools import add_panel_labels
COLORS=dict(zip(ARMS,('#0072B2','#777777','#D55E00','#009E73')))
STYLES=dict(zip(ARMS,('-','--','-.',':')))
MARKERS=dict(zip(ARMS,('o','s','^','D')))
SHORT=dict(zip(ARMS,('Recover + resume','Recover + hold','Immediate mission','B + resume')))
GROUPS=[('RR_THIGH15',a) for a in ARMS]+[('HEALTHY','IMMEDIATE_MISSION'),('RR_THIGH30','IMMEDIATE_MISSION')]
GNAMES=[SHORT[a] for a in ARMS]+['Healthy immediate','Mild RR immediate']
def title(ax,t):ax.set_title(t,loc='left',pad=12,fontsize=8)
def finish(fig,axs,headline,note,label_y=5):
    fig.suptitle(headline,fontsize=11)
    fig.text(.5,.015,note,ha='center',fontsize=7)
    fig.set_layout_engine('constrained',h_pad=.12,w_pad=.10,rect=(.015,.065,.98,.91))
    fig.canvas.draw()
    add_panel_labels(fig,axes=axs,style='ieee',fontsize=9,x_offset_pt=-10,y_offset_pt=label_y)
def figure1(out,rows,series):
    severe=[s for s in series if s['health_kind']=='RR_THIGH15']
    snaps=sorted({r['snapshot_id'] for r in rows if r['health_kind']=='RR_THIGH15'})
    fig,axs=plt.subplots(5,2,figsize=(7.16,9.65));flat=list(axs.flat)
    by={s['id']:s for s in severe};rs={r['id']:r for r in rows}
    y=[v['base_x_m']*1000 for s in severe for v in s['series']]+[s['goal_m']*1000 for s in severe]
    ylim=(min(y)-2,max(y)+2) if y else (-70,0)
    for ax,snap in zip(flat[:8],snaps):
        available=[s for s in severe if s['snapshot_id']==snap]
        for arm in ARMS:
            s=next((s for s in available if s['arm']==arm),None)
            if not s or not s['series']:continue
            t=[v['time_s'] for v in s['series']];x=[v['base_x_m']*1000 for v in s['series']]
            ax.plot(t,x,color=COLORS[arm],ls=STYLES[arm],lw=1.,label=SHORT[arm])
            ax.scatter(t[-1],x[-1],color=COLORS[arm],marker=MARKERS[arm] if s['complete'] else 'x',s=18,zorder=4)
        fixed=next((r.get('source_goal') for r in rows if r['snapshot_id']==snap and r['health_kind']=='RR_THIGH15' and r.get('source_goal')),None)
        if fixed:ax.axhline(fixed['x_goal_m']*1000,color='black',lw=.7,ls=(0,(4,4)))
        if not available:ax.text(.5,.6,'4 planned / no arm applied',transform=ax.transAxes,ha='center',fontsize=8)
        for t in (1.,3.,4.):ax.axvline(t,color='#bbbbbb',lw=.5)
        ax.set_xlim(-.03,4.08);ax.set_ylim(*ylim);ax.set_xticks([0,1,2,3,4])
        ax.set_xlabel('Physical time (s)');ax.set_ylabel('Absolute base x (mm)')
        title(ax,snap.replace('T49_DEV_','Episode ').replace('_T',' / tick '))
    ax,bx=flat[8:]
    for i,arm in enumerate(ARMS):
        own=[r for r in rows if r['health_kind']=='RR_THIGH15' and r['arm']==arm]
        for j,r in enumerate(own):
            x=i+(j-3.5)*.055;e=r.get('final_goal_error_m')
            if e is not None:ax.scatter(x,abs(e)*1000,color=COLORS[arm],marker=MARKERS[arm] if r['complete_2001'] else 'x',s=20)
            if r['complete_2001']:
                bx.scatter(x,abs(r['final_vx_m_s'])*1000,color=COLORS[arm],marker=MARKERS[arm],s=20)
                bx.scatter(x,r['final_half_second_vx_RMS_m_s']*1000,facecolors='none',edgecolors=COLORS[arm],marker=MARKERS[arm],s=32)
        missing=sum(not r['complete_2001'] for r in own)
        bx.text(i,.96,f'n={8-missing}/8',transform=bx.get_xaxis_transform(),ha='center',va='top',fontsize=7)
    for a in (ax,bx):
        a.set_xticks(range(4),['Resume','Hold','Immediate','B resume']);a.set_xlim(-.5,3.5);a.margins(y=.2)
    ax.axhline(2,color='black',ls='--',lw=.7);ax.set_ylim(bottom=0);ax.set_ylabel('Absolute last goal error (mm)')
    title(ax,'Original goal; cross = partial endpoint')
    bx.axhline(1,color='black',ls='--',lw=.7);bx.set_ylim(bottom=0);bx.set_ylabel('Stop metric (mm/s)')
    title(bx,'4 s |vx| (filled) / last 0.5 s RMS (open)')
    fig.legend(handles=[Line2D([],[],color=COLORS[a],ls=STYLES[a],marker=MARKERS[a],label=SHORT[a]) for a in ARMS],
        loc='upper center',bbox_to_anchor=(.53,.96),ncol=2,frameon=False,fontsize=8)
    finish(fig,flat,'STEP49 | Recovery to the frozen original mission',
        'All 8 severe sources / 4 episodes. Dashed black = original goal; gray vertical lines = 1 / 3 / 4 s.\n'
        'Each point is one allocated branch; cross = actual partial endpoint, not a 4 s result. No uncertainty or significance estimate.')
    return fig
def figure2(out,rows,latency,result):
    fig,axs=plt.subplots(3,2,figsize=(7.16,8.2));a,b,c,d,e,f=list(axs.flat)
    outcomes=['Mission success','True physical failure','Late','Gate refused','Other task / unavailable']
    palette=['#0072B2','#D55E00','#CC79A7','#777777','#dddddd']
    bars=[]
    for i,(kind,arm) in enumerate(GROUPS):
        own=[r for r in rows if r['health_kind']==kind and r['arm']==arm];count=[0]*5
        for r in own:
            k=0 if r['mission_success'] else 2 if r.get('late') else 1 if r.get('physical_failure_count',0)>0 else 3 if r['status']=='PHASE1_GATE_FAILED' else 4
            count[k]+=1
        left=0
        for k,n in enumerate(count):
            a.barh(i,n,left=left,color=palette[k],height=.65,hatch=['','///','...','xx',''][k],edgecolor='white',lw=.4)
            if n:a.text(left+n/2,i,str(n),ha='center',va='center',fontsize=7)
            left+=n
        bars.append(dict(kind=kind,arm=arm,outcomes=dict(zip(outcomes,count)),planned=len(own)))
    a.set_yticks(range(6),GNAMES);a.invert_yaxis();a.set_xlim(0,8);a.set_xlabel('Allocated branches (n / 8)')
    title(a,'All planned outcomes; late kept separate')
    a.legend(handles=[plt.Rectangle((0,0),1,1,color=palette[k],hatch=['','///','...','xx',''][k],label=outcomes[k]) for k in range(5)],
        loc='upper center',bbox_to_anchor=(.8,-.2),ncol=2,frameon=False,fontsize=7)
    event_times=[]
    for i,arm in enumerate(ARMS):
        own=[r for r in rows if r['health_kind']=='RR_THIGH15' and r['arm']==arm]
        for j,r in enumerate(own):
            y=i+(j-3.5)*.055;t=r.get('capacity_first_99_s');fail=r.get('first_physical_failure')
            if t is not None:b.scatter(t,y,marker=MARKERS[arm],color=COLORS[arm],s=20);event_times.append(t)
            if fail:b.scatter(fail['time_s'],y,marker='x',color='black',s=25);event_times.append(fail['time_s'])
    b.set_yticks(range(4),['Resume','Hold','Immediate','B resume']);b.invert_yaxis();b.set_xlim(-.005,max(event_times,default=.10)*1.20+.005);b.set_xlabel('Physical time (s; early-event zoom)')
    title(b,'First >=99% capacity / physical failure (x)')
    for i,(kind,arm) in enumerate(GROUPS):
        own=[r for r in rows if r['health_kind']==kind and r['arm']==arm]
        for j,r in enumerate(own):
            value=r.get('min_friction_margin_n')
            if value is not None:c.scatter(i+(j-3.5)*.055,value,color=COLORS[arm],marker='o' if r['complete_2001'] else 'x',s=18)
            value=r.get('min_applied_torque_margin_nm')
            if value is not None:d.scatter(i+(j-3.5)*.055,value,color=COLORS[arm],marker='o' if r['complete_2001'] else 'x',s=18)
    for ax in (c,d):
        ax.axhline(0,color='black',lw=.6);ax.set_xticks(range(6),['Resume','Hold','Imm.','B res.','Healthy','Mild'],rotation=20);ax.set_xlim(-.5,5.5);ax.margins(y=.15)
    c.set_ylabel('Minimum friction margin (N)');title(c,'All observed prefixes; cross = partial')
    d.set_ylabel('Minimum applied-torque margin (Nm)');title(d,'Original health / capacity bounds')
    for ax,window,kinds in [(e,'complete_ms',['FIRST','FEEDBACK','HANDOFF']),(f,'prepared_ms',['FIRST','FEEDBACK','HANDOFF'])]:
        for i,kind in enumerate(kinds):
            own=[v for v in latency if v['kind']==kind and v.get(window) is not None]
            for j,r in enumerate(own):
                jitter=((j*37)%101/100-.5)*.5
                ax.scatter(i+jitter,r[window],color=COLORS[r['arm']],marker='o' if r['applied'] else 'x',s=7,alpha=.35)
            missing=sum(v['kind']==kind and v.get(window) is None for v in latency)
            ax.text(i,.98,f'n={len(own)}\nNA={missing}',transform=ax.get_xaxis_transform(),ha='center',va='top',fontsize=7)
        threshold=20 if window=='complete_ms' else 17
        ax.axhline(threshold,color='black',ls='--',lw=.8);ax.set_xticks(range(3),['First','Feedback','1 s handoff'])
        ax.set_ylabel('Complete ready (ms)' if window=='complete_ms' else 'Prepared commit (ms)');ax.set_ylim(bottom=0);ax.margins(y=.2)
        title(ax,'Every saved 20 ms window' if window=='complete_ms' else 'Every saved 17 ms window (gate included)')
    write(out/'figures/FIG2_OUTCOME_DATA.json',bars)
    finish(fig,list(axs.flat),'STEP49 | Planned outcomes and physical / timing contracts',
        'Outcome priority: success > late > physical failure > gate refused > other. Overlaps remain in JSON tables.\n'
        'Capacity: colored = first >=99% applied command; black x = first true physical failure. No missing value is filled with zero.',label_y=24)
    return fig
def run(export=False):
    out=output();folder=out/'figures';folder.mkdir(exist_ok=True)
    rows=read(out/'BRANCH_ROWS.json');latency=read(out/'LATENCY.json');series=read(out/'TRAJECTORY_SERIES.json');result=read(out/'STEP49_RESULT.json')
    style=setup_style('ieee',lang='en',use_sciplots=False)
    plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],'font.size':8,'axes.labelsize':8,
        'axes.titlesize':8,'xtick.labelsize':7,'ytick.labelsize':7,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
    profiles={}
    for name,frame,groups in [('BRANCH_ROWS',pd.DataFrame(rows)[['health_kind','arm','status','complete_2001','mission_success','final_goal_error_m','final_vx_m_s']],['health_kind','arm']),
        ('LATENCY',pd.DataFrame(latency)[['kind','arm','complete_ms','prepared_ms','applied']],['kind','arm'])]:
        profiles[name]=profile_data(frame,groups)
    write(folder/'DATA_PROFILES.json',profiles)
    write(folder/'CHART_SELECTION.json',dict(objectives=['all-source original-goal trajectories','planned outcome and physical/timing contract'],
        choice='small multiples plus raw point panels',reason='eight paired sources, partials and actual timing remain visible',
        alternatives=['separate single-source pages','paired dot tables'],population_inference=False,mean_bars=False,double_y=False))
    qa=[]
    for name,fig,size in [('FIG1_RECOVERY_TO_MISSION',figure1(out,rows,series),(7.16,9.65)),
        ('FIG2_OUTCOMES_PHYSICS_TIMING',figure2(out,rows,latency,result),(7.16,8.2))]:
        layout=audit_layout(fig);preview=render_preview(fig,str(folder/(name+'_preview.png')),dpi=165)
        q=dict(name=name,layout=layout,preview=preview,publication_size_inches=size,style=style)
        if export:
            if any(s=='FAIL' for s,_ in layout):raise ValueError('figure layout failure')
            paths=export_figure(fig,str(folder/name),formats=['pdf','png'],dpi=600,size_inches=size,grayscale_preview=False,tight=False)
            with Image.open(folder/(name+'.png')) as im:im.convert('L').save(folder/(name+'_grayscale.png'),dpi=(600,600))
            q.update(files={Path(p).name:sha(p) for p in paths},compliance=[dict(path=p,issues=check_figure(p,min_dpi=600,target_inches=size)[0],info=check_figure(p,min_dpi=600,target_inches=size)[1]) for p in paths],
                PDF_font_descendants=embedded_fonts(folder/(name+'.pdf')))
        qa.append(q);plt.close(fig)
    write(folder/('EXPORT_QA.json' if export else 'PREVIEW_QA.json'),qa)
    print(dict(figures=2,exported=export,layout_issues=[q['layout'] for q in qa]),flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--export',action='store_true');run(p.parse_args().export)
