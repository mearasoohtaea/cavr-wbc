"""Static delivery receipt and Git/source identity, no numeric bank rerun."""
import ast,os,subprocess
from cavr_wbc.experiments.step49_io import *
def git(root,*args):
    env=dict(os.environ)
    for key in ('GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_COMMON_DIR'):env.pop(key,None)
    env['GIT_OPTIONAL_LOCKS']='0'
    return subprocess.run(['git','-C',str(root),*args],env=env,capture_output=True,text=True,encoding='utf-8',check=True).stdout.strip()
def run():
    out=output();base=read(out/'SOURCE_READONLY_BASELINE.json')
    files=sorted(OUTPUT_ROOT_D.glob('cavr_wbc/**/step49*.py'))+[OUTPUT_ROOT_D/'tests/test_step49_contract.py']
    for p in files:ast.parse(p.read_text(encoding='utf-8'))
    source_head=git(SOURCE_ROOT_D,'rev-parse','HEAD')
    source_index=sha(SOURCE_ROOT_D/'.git/index')
    source_clean=git(SOURCE_ROOT_D,'status','--porcelain=v1')
    if source_head!=SOURCE_COMMIT or source_index!=base['source_index_sha256'] or source_clean:raise ValueError('readonly source Git changed')
    readback=read(out/'READBACK_VERDICT.json')
    qa=read(out/'figures/EXPORT_QA.json');visual=read(out/'figures/VISUAL_REVIEW.json')
    if readback['issues'] or not visual['passed']:raise ValueError('delivery verification/figure review not passed')
    outputs=[dict(path=relative(p,out),size_bytes=p.stat().st_size) for p in out.rglob('*') if p.is_file()]
    commands=[
        dict(command='python -B -X utf8 -m cavr_wbc.experiments.step49_prepare',result='completed after startup metadata import repair',QP=0,steps=0),
        dict(command='python -B -X utf8 -m cavr_wbc.experiments.step49_tests',result='4/5 first pass; initial error retained',QP=0,steps=0),
        dict(command='python -B -X utf8 -m cavr_wbc.experiments.step49_tests --repair-4',result='affected fixture PASS; aggregate5/5',QP=0,steps=0),
        dict(command='python -B -X utf8 -m cavr_wbc.experiments.step49_sprint',result=read(out/'RUN_FINISHED.json')['status']),
        dict(command='python -B -X utf8 -m cavr_wbc.experiments.step49_delivery',result=readback['status'],QP=0,steps=0),
        dict(command='python -B -X utf8 -m cavr_wbc.experiments.step49_figures [--export]',result='SciPilot two figures with machine/visual/gray review',QP=0,steps=0),
        dict(command='python -B -X utf8 -m cavr_wbc.experiments.step49_package',result='Chinese report/handoff/status saved',QP=0,steps=0)]
    write(out/'DELIVERY_MANIFEST.json',dict(branch=git(OUTPUT_ROOT_D,'branch','--show-current'),parent_commit=git(OUTPUT_ROOT_D,'rev-parse','HEAD'),
        source_head=source_head,source_index_sha256=source_index,source_status=source_clean,source_unchanged=True,
        actual_modified_existing_files=['cavr_wbc/control/step38_kernel.py','cavr_wbc/experiments/step26_features_storage.py'],
        new_code_files=[relative(p,OUTPUT_ROOT_D) for p in files],protocol='configs/validation/STEP49_PROTOCOL.md',
        Git_before_commit=git(OUTPUT_ROOT_D,'status','--porcelain=v1'),static_ast_files=len(files),test_commands=commands,
        actual_interpreter='E:/CAVR-WBC/_runtime_step30/python311/python.exe',
        tests=read(out/'tests/NECESSARY_TESTS.json'),readback=readback,figure_export_QA=qa,visual_review=visual,
        output_files=outputs,output_size_bytes=sum(p['size_bytes'] for p in outputs),push=False,
        robot_motion_algorithm_project_accessed=False))
    print(dict(static_files=len(files),output_files=len(outputs),source_unchanged=True,readback=readback['status'],ready_to_scoped_commit=True),flush=True)
if __name__=='__main__':run()
