"""Four fresh references, eight sources, exactly forty-eight allocated arms."""
from copy import deepcopy
from cavr_wbc.control.step49_policy import ARMS
from cavr_wbc.experiments.step46_inputs import context_for as source_context
TARGETS=(-.062750,-.064750,-.066750,-.068500)
def episodes():
    return [dict(episode_id=f'T49_DEV_{i}',displacement_m=d,direction=-1,snapshot_ticks=[37,41]) for i,d in enumerate(TARGETS)]
def plans():
    rows=[]
    for ep in episodes():
        for tick in (37,41):
            n=len(rows)//3;snap=ep['episode_id']+f'_T{tick:03d}'
            order=ARMS[n%4:]+ARMS[:n%4]
            for kind in ('RR_THIGH15','HEALTHY','RR_THIGH30'):
                rows.append(dict(**ep,episode=ep['episode_id'],tick=tick,source_tick=tick,
                    snapshot_id=snap,source_snapshot=snap,context_id=snap+'_'+kind,
                    case_id=snap+'_'+kind,source_state_id=snap+'_'+kind,ordinal=len(rows),source_ordinal=n,
                    health_kind=kind,role='healthy' if kind=='HEALTHY' else 'thigh',
                    fault_leg='NONE' if kind=='HEALTHY' else 'RR',health=1. if kind=='HEALTHY' else .15 if kind.endswith('15') else .30,
                    split='DEV',source_split='STEP49_FRESH_DEV',gap_m=.006,severe=kind.endswith('15'),
                    arms=list(order) if kind.endswith('15') else ['IMMEDIATE_MISSION'],governor_planned=False))
    return rows
def positions():
    return [dict(id=p['context_id']+':'+a,context_id=p['context_id'],snapshot_id=p['snapshot_id'],
        episode=p['episode'],tick=p['tick'],health_kind=p['health_kind'],arm=a,
        severe=p['severe'],gamma=0. if a=='B_RECOVER_RESUME' else .5) for p in plans() for a in p['arms']]
def context_for(p,ep,mapping):
    c=source_context(p,ep,mapping)
    c.update(backup_id='STEP49-'+p['context_id'],group='STEP49_FIXED_DEV')
    if c.get('previous_command_identity',{}).get('available'):c['previous_command_identity']['source']='NEW_STEP49_REFERENCE'
    return c
def arm_context(c,arm):
    v=deepcopy(c);v.update(backup_id=c['backup_id']+':'+arm,experimental_arm=arm)
    return v
