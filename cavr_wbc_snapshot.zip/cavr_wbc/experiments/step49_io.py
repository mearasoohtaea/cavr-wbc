"""STEP49-only output and unchanged lossless numeric utilities."""
from cavr_wbc.experiments.step47_io import write,read,append,sha,encode,relative,save_numeric,load_numeric,OUTPUT_ROOT_D,NATIVE_DLL
from pathlib import Path
SOURCE_ROOT_D=Path('D:/CAVR-WBC/cavr_step48_phase_matched_cal_confirmation_20261012')
SOURCE_COMMIT='ad2f4000933af3137e2ce78b6398ff7b5894ff78'
SOURCE_RUN=SOURCE_ROOT_D/'artifacts/step48_phase_matched_confirmation_20261012/step48-phase-matched-cal-confirmation-20261012-01'
PROTOCOL=Path('D:/CAVR-WBC/experiment_handoff_20261010/NEXT_CODEX_INSTRUCTIONS_STEP49_RECOVERY_TO_MISSION_PILOT_20261012.md')
RUN_ID='step49-recovery-to-mission-pilot-20261012-01'
def output():return OUTPUT_ROOT_D/'artifacts/step49_recovery_to_mission_20261012'/RUN_ID
