"""Chinese protocol/result/handoff package from the single current readback."""
from datetime import datetime,timezone
import json
from cavr_wbc.experiments.step49_io import *
def text_file(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(value,encoding='utf-8',newline='\n')
def package():
    out=output();r=read(out/'STEP49_RESULT.json');rows=read(out/'BRANCH_ROWS.json');latency=read(out/'LATENCY.json')
    endpoint=r['endpoints'];G,M,V=[endpoint[k] for k in ('G','M','V')]
    budget=r['budget'];verification=read(out/'READBACK_VERDICT.json')
    main=[v for v in rows if v['arm']=='MIDDLE_RECOVER_RESUME']
    goals=[v for v in main if v['mission_success']]
    pairs=endpoint['paired'];immediate_success=sum(p['IMMEDIATE_MISSION']['mission_success'] for p in pairs)
    main_success=len(goals);hold_success=sum(p['MIDDLE_RECOVER_HOLD']['mission_success'] for p in pairs)
    B_success=sum(p['B_RECOVER_RESUME']['mission_success'] for p in pairs)
    lines=['| 方法 / health | planned | applied | 完整1s | 恢复诊断通过 | 完整4s | 安全及时 | 原目标成功 | late | 真实物理失败 |',
        '|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
    for key,s in endpoint['groups'].items():
        lines.append('| '+key+' | '+' | '.join(str(s[k]) for k in ('planned','applied','complete_phase1','recovery_gate_pass','complete_4s','physical_safe_timely','mission_success','late','physical_failure'))+' |')
    table='\n'.join(lines)
    refs='\n'.join('- '+v['episode_id']+': '+v['status']+'；'+str(v.get('counts',{}).get('physical_steps',0))+' 积分步。' for v in r['references'])
    summary=(f'主臂 {main_success}/8 个 planned source 完成原目标（{M["snapshots"]} snapshot / {M["episodes"]} episode）；'
        f'IMMEDIATE {immediate_success}/8，B_RESUME {B_success}/8，HOLD {hold_success}/8。'
        f' M = {M["status"]}；V = {V["status"]}。')
    if immediate_success>=main_success:
        interpretation='本轮不支持“先恢复是原任务完成的必要条件”。立即任务臂至少达到相同数量的成功；恢复阶段的用途应由逐 source 的真实失败与全时限配对判断，不能由改变参考后位移更多推出。'
    else:interpretation='主臂的 planned 成功数高于立即任务臂，但额外安全用途只按预冻结 V 的真实物理失败配对计数；late、未施加和任务未完成另列。'
    report=f"""# STEP49：恢复后继续原绝对任务目标

## Material Passport

- Origin Skill: experiment-agent / academic-research-suite
- Origin Mode: run
- Origin Date: {datetime.now(timezone.utc).isoformat()}
- Verification Status: UNVERIFIED
- Version Label: step49_recovery_to_mission_pilot_v1
- Upstream Dependencies: STEP48 {SOURCE_COMMIT}

## 本轮结果

{summary}

固定列表已处理 {r['rows']}/48 个位置，{r['observed']} 条实际轨迹，{r['complete_4s']} 条完整4s，合计 {r['mission_success']} 条满足任务成功条件。运行状态 {r['run_status']}；交付状态 {r['status']}。全部失败、partial 和未施加位置留在分母内，没有补跑、替换或结果后调参。

{interpretation}

## 固定阶段契约

0–1s 恢复臂保留原物理检查、17/20ms、单向 D≤6mm、原 anchor 的2mm/1mm/s严格 terminal。1–4s 保留固定 world workspace 与所有原物理/数值契约，不将6mm恢复预算作为任务进度上限。4s 评价原 nominal 绝对 goal，误差≤2mm、|vx|≤1mm/s、最后.5s dense索引1750..2000 的 vx RMS≤1mm/s，并保留原 vy/姿态/端点物理要求。

原 anchor 全程未移动。IMMEDIATE 从.04s首feedback生效，mission clock=.02；恢复臂固定1s检查前缀门，resume从已命令的 anchor+clipped1mm参考以2s quintic继续，3s到参考goal、hold至4s。HOLD使用同一门并继续恒定恢复参考，未到原goal只记任务未完成。

复合策略 ID 为 STEP49_RECOVERY_TO_ORIGINAL_MISSION_4S_V1。trace中的 TASK_AWARE_1MM_06S_V1 是原恢复**组件** ID，HOLD 后3秒仍复用其恒定参考；不是4s策略认证。所有4s输出均标明 old_CAL_certifies_mission=FALSE、learner/governor approval=FALSE。没有调用CAL、DOMAIN、predictor或训练。

## 全分母链

{table}

“恢复诊断通过”对 IMMEDIATE 仅为诊断，不是强制恢复门；健康/mild controls 只改变health，使命目标/参考/solver相同。late 和物理失败可能同时出现在已观察前缀，表中不以互斥计数掩盖重叠。逐位置 planned→applied→phase1→gate→phase2→完整4s→安全及时→goal 链见 [BRANCH_ROWS.csv](BRANCH_ROWS.csv) 与 [BRANCH_ROWS.json](BRANCH_ROWS.json)。

## G / M / V / F

- G = {G['status']}；主臂实际连续handoff {G['snapshots']} snapshot / {G['episodes']} episode。全部恢复臂门拒绝、接续失败和实际handoff分别保存在每位置 RESULT、phase1_online_summary、handoff及continuity_start/end。
- M = {M['status']}；支持数 {M['snapshots']} snapshot / {M['episodes']} episode，门槛为至少3/2，不追加位置寻求通过。
- V = {V['status']}；主臂成功且 IMMEDIATE 真实物理失败的安全阶段配对 {V['snapshots']} snapshot / {V['episodes']} episode，门槛2/2。late不冒充物理失败。
- F：主臂与B_RESUME为首动作gamma效应对照；与HOLD为持续原目标参考对照。各配对同时保留任务误差和外部reference绝对误差积分，双方完整可测时才给连续差值，缺测不填0。详见 STEP49_RESULT.json 的 endpoints.paired。

只有4个独立episode；healthy/mild共享source不算新的独立episode。没有显著性或总体泛化推断，没有长期安全、全故障、硬实时部署或viability证明。

## 四个新 reference

{refs}

目标为 −62.750/−64.750/−66.750/−68.500mm，均为本轮新110tick/1100step whole episode；取37、41，没有加载STEP48成功末态。

## 执行与预算

数值开始 {budget['numerical_started_utc']}；数值墙钟 {budget['numerical_elapsed_s']:.3f}s / 3600s。
所有启动/priming/reference/endpoint/application/feedback计入：QP {budget['total_QP_calls']}/15000，returns {budget['QP_returns']}，UNKNOWN {budget['unknown_native_returns']}；积分 {budget['total_physics_steps']}/140000，未完成预留 {budget['uncompleted_native_step_reservations']}。0 CAL / 0 TRAIN / 0 fit / 0 learned governor decision。

一次环境确认完成前修复了环境记录的 NumPy 导入遗漏。必要pure group共5类：首轮4类通过，第4类误差积分因NumPy trapz移除而报错；启动真实数值前改为trapezoid，仅定点重跑第4类并通过。初始失败和修复收据全部保留；pure 0 QP / 0 MuJoCo步。真实批次后冻结代码未变。

1s门只消费采样循环累计的 physical/D/command/timing/terminal摘要；callback在原begin之后，拒绝/准备late则零新QP、零ctrl、零积分。续程在同一循环/plant/live+staging/PID/native owner上推进，slot50用logical49，不加载理想状态、不重置health/anchor/PID/warm start或时间。

## 一次本轮读回

{verification['status']}；解码 {verification['decoded_fact_banks']} 个实际事实bank及 {verification['decoded_raw_QP']} 个raw QP shard；issues={len(verification['issues'])}。每shard先保存JSON verdict/issues，再导CSV。检查的是当前保存事实与冻结双阶段评价的一致性，不是独立数值复现，因此 Material Passport 保持 UNVERIFIED。

源STEP48结果/config/index hash未变；源HEAD在最终Git收据另核对。旧证据未重审、未覆盖；“机器人运控算法”项目和聊天未访问。一次scoped本地提交，不推送。

## 图和研究交接

SciPilot按8个source的small multiples与raw dots呈现，未使用小样本均值柱或双Y轴；partial不补到4s。图1含所有受损episode/tick四臂base-x、原goal、1/3/4s阶段线和终点/停止指标；图2含全部planned结果、capacity/最小余量以及所有17/20ms与handoff窗口。PDF/600dpi PNG、灰度及视觉QA见 figures/。

[HANDOFF.md](HANDOFF.md)；[PROTOCOL_STATUS.ini](PROTOCOL_STATUS.ini)；[READBACK_VERDICT.json](READBACK_VERDICT.json)；[LATENCY.json](LATENCY.json)。E3 / RL / 硬件未授权，交付后停止，不启动新CAL/TRAIN。
"""
    text_file(out/'REPORT.md',report)
    text_file(out/'HANDOFF.md',f"""# STEP49 研究交接

{summary}

{interpretation}

当前树 {OUTPUT_ROOT_D}，分支 codex/step49-recovery-to-mission-pilot-20261012，父提交 {SOURCE_COMMIT}。固定新4reference＋48位置已按协议执行，旧证据只读保留。

主产物：REPORT.md、PROTOCOL_STATUS.ini、STEP49_RESULT.json、BRANCH_ROWS.json/CSV、LATENCY.json、TRAJECTORY_SERIES.json、METHOD_INPUT_FREEZE.json、INPUTS_PLAN.json、SOURCE_FROZEN_CONFIG.json；每branches位置包含独立source/policy goal、packet/startup、actual bank、controls/raw links、phase1 gate与handoff、RESULT及读回receipt。raw_qp及STEP49_LEDGER覆盖全部真实调用/积分预算，ATTEMPT_LEDGER保留计划位START/RETURN，4reference另存。

M门槛3snapshot/2episode，V安全用途门槛2/2；本轮只支持上述测得状态，不将任务进度变大当创新，不将立即任务成功隐藏。只有双方完整可测的数值差值供后续研究；不填缺测，不把共享健康对照当独立episode。原anchor/绝对goal全程固定。

必要纯测试初始第4类失败及启动前定点修复保留。一次当前数值读回 {verification['status']}、issues={len(verification['issues'])}，不是独立重现。数值代码 METHOD_INPUT_FREEZE 与 RUNTIME_END一致，任何未来策略需新授权，不从旧1sCAL推导4s认证。

本轮结束：不自动CAL/TRAIN/E3/RL/硬件、不重跑历史、不推送；“机器人运控算法”项目和聊天仍为禁区。
""")
    status=dict(AUTHORIZE_STEP49_RECOVERY_TO_MISSION_DIRECT_PILOT=True,SOURCE_STEP48_RESULT_UNCHANGED='LOCAL_CLOSURE_ESTABLISHED',
        STEP49_REFERENCE_EPISODES=4,STEP49_FAULT_SOURCE_SNAPSHOTS=8,STEP49_SEVERE_RR_CONTEXTS=8,
        STEP49_SEVERE_FOUR_ARM_BRANCHES=32,STEP49_HEALTHY_MILD_CONTROLS=16,STEP49_MISSION_BRANCHES_PLANNED=48,
        STEP49_MISSION_HORIZON_S=4,STEP49_RECOVERY_GATE_TIME_S=1,STEP49_RESUME_RAMP_S=2,
        STEP49_RECOVERY_LOCAL_LIMIT_M=.006,STEP49_RECOVERY_ANCHOR_CHANGED=False,STEP49_MISSION_GOAL='ORIGINAL_NOMINAL_ABSOLUTE_BASE_X',
        STEP49_FINAL_POSITION_TOL_M=.002,STEP49_FINAL_SPEED_TOL_M_S=.001,STEP49_FINAL_HALF_SECOND_VX_RMS_TOL_M_S=.001,
        STEP49_NEW_CAL=0,STEP49_NEW_TRAIN=0,STEP49_NEW_FITS=0,STEP49_LEARNED_GOVERNOR_DECISIONS=0,
        STEP49_OLD_CAL_CERTIFIES_MISSION=False,STEP49_G_CONTINUOUS_HANDOFF=G['status'],
        STEP49_M_ORIGINAL_GOAL_COMPLETION=M['status'],STEP49_V_RECOVERY_ADDED_VALUE=V['status'],
        HARD_REALTIME_DEPLOYMENT_ESTABLISHED=False,HISTORICAL_RESULTS_UNCHANGED=r['source_unchanged'],
        E3_AUTHORIZED=False,RL_HARDWARE_AUTHORIZED=False,STEP49_RUN_STATUS=r['run_status'],
        STEP49_DELIVERY_STATUS=r['status'],STEP49_CURRENT_READBACK=verification['status'])
    render=lambda v:'TRUE' if v is True else 'FALSE' if v is False else str(v)
    text_file(out/'PROTOCOL_STATUS.ini','\n'.join(k+' = '+render(v) for k,v in status.items())+'\n')
    print(summary,flush=True)
if __name__=='__main__':package()
