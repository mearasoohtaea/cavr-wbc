"""The single environment confirmation; no install, compile or numerical probe."""
import os,shutil
import numpy as np
from cavr_wbc.experiments.step49_io import *
from cavr_wbc.experiments.step49_inputs import episodes,plans,positions
def prepare():
    out=output();out.mkdir(parents=True,exist_ok=True)
    if (out/'PREPARATION.json').exists():raise FileExistsError('one environment confirmation only')
    import cavr_wbc,mujoco,osqp,scipy,threadpoolctl
    if not Path(cavr_wbc.__file__).resolve().is_relative_to(OUTPUT_ROOT_D):raise ValueError('wrong package root')
    free=shutil.disk_usage(OUTPUT_ROOT_D).free
    if free<8_000_000_000:raise OSError('D space insufficient')
    write(out/'PREPARATION.json',dict(package=cavr_wbc.__file__,D_free_bytes=free,TMP=os.environ['TMP'],TEMP=os.environ['TEMP'],
        MPLCONFIGDIR=os.environ['MPLCONFIGDIR'],versions=dict(mujoco=mujoco.__version__,osqp=osqp.__version__,numpy=np.__version__,scipy=scipy.__version__),
        threadpools=threadpoolctl.threadpool_info(),new_QP=0,new_steps=0))
    config=read(SOURCE_RUN/'SOURCE_FROZEN_CONFIG.json');write(out/'SOURCE_FROZEN_CONFIG.json',config)
    write(out/'SOURCE_READONLY_BASELINE.json',dict(source_commit=SOURCE_COMMIT,source_worktree=str(SOURCE_ROOT_D),
        source_index_sha256=sha(SOURCE_ROOT_D/'.git/index'),source_result_sha256=sha(SOURCE_RUN/'STEP48_RESULT.json'),
        source_config_sha256=sha(SOURCE_RUN/'SOURCE_FROZEN_CONFIG.json'),source_result='LOCAL_CLOSURE_ESTABLISHED',historical_bank_read=False))
    write(out/'INPUTS_PLAN.json',dict(episodes=episodes(),contexts=plans(),positions=positions(),
        max_wall_s=3600,max_QP=15000,max_steps=140000,fits=0,CAL=0,TRAIN=0))
    print(dict(prepared=True,references=4,positions=len(positions()),new_QP=0,new_steps=0),flush=True)
if __name__=='__main__':prepare()
