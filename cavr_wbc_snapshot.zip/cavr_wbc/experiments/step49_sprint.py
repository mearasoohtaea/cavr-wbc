"""One fixed direct pilot; failed positions are retained without redispatch."""
from copy import deepcopy
from datetime import datetime,timezone
import os,gc,traceback
import numpy as np
from cavr_wbc.experiments.step49_io import *
from cavr_wbc.experiments.step49_inputs import *
from cavr_wbc.experiments.step49_budget import SprintBudget,SprintLimit
from cavr_wbc.experiments.step49_storage import save_branch,not_run
from cavr_wbc.experiments.step35_reference import reference_episode
from cavr_wbc.experiments.step28_sprint import home_context
from cavr_wbc.experiments import step17_formal_panel as frozen,step49_sim as sim
from cavr_wbc.control.step49_kernel import Kernel
from cavr_wbc.control.step49_policy import VERSION
from cavr_wbc.control.step46_kernel import experimental_packet
def event(out,name,**values):
    append(out/'ATTEMPT_LEDGER.jsonl',dict(event=name,timestamp_utc=datetime.now(timezone.utc).isoformat(),**values))
def owners_for(model,budget,c,manifest):
    owners={};startup={}
    for name in ('C','MIDDLE','B'):
        k=Kernel(model,'BOUNDED',str(NATIVE_DLL),budget)
        home=home_context(model,manifest['scenario'])
        home.update(context_id=c['context_id']+':'+c['experimental_arm']+':'+name+':HOME',
            backup_id=c['backup_id']+':'+name+':HOME',experimental_arm=c['experimental_arm'])
        startup[name]=k.startup(home,budget);k.flush_raw_evidence();owners[name]=k
    return owners,startup
def missing_packet(c,gamma):
    return dict(status='SOURCE_INELIGIBLE',context_id=c['context_id'],method=c['experimental_arm'],
        selected_command_sent=False,model_authorized=False,experimental_dispatch=True,
        experimental_committed=False,selected_gamma=gamma,policy_version=VERSION,actions={},
        prepared_commit_ms=None,command_ready_ms=None)
def run():
    out=output()
    if (out/'RUN_STARTED.json').exists():raise FileExistsError('unique pilot already started; no numerical rerun')
    tests=read(out/'tests/NECESSARY_TESTS.json')
    if tests is None or tests['errors'] or tests['failures'] or tests['tests_run']!=5:raise ValueError('five pure topics must pass')
    manifest=read(out/'SOURCE_FROZEN_CONFIG.json')
    runtime={relative(p,OUTPUT_ROOT_D):sha(p) for p in OUTPUT_ROOT_D.glob('cavr_wbc/**/*.py')}
    freeze=dict(runtime_sha256=runtime,protocol_sha256=sha(PROTOCOL),config=manifest,
        episodes=episodes(),plans=plans(),positions=positions(),new_CAL=0,new_TRAIN=0,new_fit=0,learned_governor_decisions=0,
        policy=VERSION,physical_dt_s=.002,control_dt_s=.02,physical_horizon_s=4.,phase1_gate_s=1.,
        phase1_D_limit_m=.006,phase1_anchor_tol_m=.002,final_goal_tol_m=.002,final_speed_tol_m_s=.001,
        final_RMS_indices=[1750,2000],final_RMS_tol_m_s=.001,mission_ramp_s=2.,
        mission_resume_start_s=1.,immediate_mission_clock_start_s=.02,immediate_first_feedback_s=.04,
        deadline_ms=20.,prepared_ms=17.,native_B_C_feedback_limits_s=[.006,.003,.006],
        max_wall_s=3600,max_QP=15000,max_steps=140000,native_sha256=sha(NATIVE_DLL),old_CAL_certifies_mission=False)
    write(out/'METHOD_INPUT_FREEZE.json',freeze)
    model=frozen.load_model();budget=SprintBudget(out);saved=set();status='COMPLETED';active_id=None
    write(out/'RUN_STARTED.json',dict(run_id=RUN_ID,pid=os.getpid(),start_utc=datetime.now(timezone.utc).isoformat(),
        command='cavr_wbc.experiments.step49_sprint',frozen_before_first_reference=True,source_commit=SOURCE_COMMIT))
    try:
        for ep in episodes():
            budget.check();event(out,'START',kind='REFERENCE',**ep)
            episode=reference_episode(model,manifest['reference_scenario'],ep['displacement_m'],ep['episode_id'],ep['snapshot_ticks'],budget,evidence_callback=budget.record_raw)
            for ctl in episode['controls']:ctl.pop('raw_solver_result',None)
            save_numeric(out/'episodes'/(ep['episode_id']+'.json'),episode)
            event(out,'RETURN',kind='REFERENCE',episode_id=ep['episode_id'],status=episode['status'],counts=episode['counts'])
            for p in (v for v in plans() if v['episode']==ep['episode_id']):
                c=context_for(p,episode,manifest['mapping'])
                save_numeric(out/'sources'/c['context_id']/'SOURCE_IDENTITY.json',dict(plan=p,context=c))
                for arm in p['arms']:
                    budget.check();ac=arm_context(c,arm);gamma=0. if arm=='B_RECOVER_RESUME' else .5
                    path=out/'branches'/c['context_id']/arm;active_id=c['context_id']+':'+arm
                    if ac.get('eligible'):
                        ac['policy_anchor_goal']=dict(x_anchor_m=float(ac['backup_anchor_q_init'][0]),
                            x_goal_m=float(ac['nominal_q_init'][0])+float(ac['nominal_d_m']),
                            d_task_m=float(np.clip(float(ac['nominal_q_init'][0])+float(ac['nominal_d_m'])-float(ac['backup_anchor_q_init'][0]),-.001,.001)))
                    save_numeric(path/'POLICY_CONTEXT.json',ac)
                    event(out,'START',kind='MISSION',id=active_id,arm=arm,health_kind=p['health_kind'])
                    owners={};k=None
                    if ac.get('eligible'):
                        owners,startup=owners_for(model,budget,ac,manifest);write(path/'STARTUP.json',startup)
                        k=owners['B' if gamma==0. else 'MIDDLE']
                        packet=experimental_packet(k,ac,budget,owners,gamma,arm);k.flush_raw_evidence()
                        packet.update(policy_version=VERSION,composite_policy_id=VERSION,old_CAL_certifies_mission=False)
                    else:packet=missing_packet(ac,gamma)
                    save_numeric(path/'PACKET.json',packet)
                    branch=sim.propagate(k,ac,packet,budget,purpose=arm,require_sent=True) if packet['experimental_committed'] else not_run(gamma,packet['status'])
                    result=save_branch(out,path,branch,ac,packet);saved.add(active_id)
                    append(out/'POSITION_INDEX.jsonl',dict(id=active_id,path=relative(path,out),context_id=c['context_id'],
                        arm=arm,episode=p['episode'],snapshot_id=p['snapshot_id'],health_kind=p['health_kind']))
                    event(out,'RETURN',kind='MISSION',id=active_id,status=result['status'],complete=result['complete_2001'],mission_success=result['mission_success'])
                    budget.persist(phase='BRANCH_SAVED',completed_positions=len(saved),planned_positions=48,id=active_id)
                    print(dict(positions=len(saved),planned=48,id=active_id,status=result['status'],
                        phase1=result.get('evaluation',{}).get('phase1'),mission_success=result['mission_success'],
                        budget=budget.snapshot()),flush=True)
                    active_id=None
                    del owners,k,packet,branch;gc.collect()
                    if result['status']=='FAILED_BUDGET':raise SprintLimit('partial saved at cap')
            del episode;gc.collect()
    except SprintLimit as exc:
        status='INCOMPLETE_BUDGET';write(out/'INTERRUPTION.json',dict(error=str(exc),budget=budget.snapshot()))
    except BaseException as exc:
        status='STOPPED_IMPLEMENTATION_OR_RESOURCE'
        write(out/'INTERRUPTION.json',dict(type=type(exc).__name__,error=str(exc),active_id=active_id,
            traceback=traceback.format_exc(),budget=budget.snapshot()))
        raise
    finally:
        for pos in positions():
            path=out/'branches'/pos['context_id']/pos['arm']/'RESULT.json'
            if not path.exists():write(path,dict(status='UNKNOWN' if pos['id']==active_id else 'NOT_RUN',
                reason={'reason':status},observed=False,evaluation={},complete_2001=False,mission_success=False,
                experimental_applied=False,**pos))
        for ep in episodes():
            if not (out/'episodes'/(ep['episode_id']+'.json')).exists():
                write(out/'episodes'/(ep['episode_id']+'_NOT_RUN.json'),dict(status='NOT_RUN',reason=status,**ep))
        unchanged=all(sha(OUTPUT_ROOT_D/p)==v for p,v in runtime.items())
        if not unchanged:status='INVALID_RUNTIME_MUTATION'
        write(out/'RUNTIME_END.json',dict(runtime_sha256_unchanged=unchanged,CAL=0,TRAIN=0,fits=0,learned_governor_decisions=0))
        budget.event('NUMERICAL_FINISHED',status=status);budget.close()
        write(out/'RUN_FINISHED.json',dict(status=status,run_id=RUN_ID,finish_utc=datetime.now(timezone.utc).isoformat(),saved_positions=len(saved),budget=budget.snapshot()))
        print(dict(status=status,budget=budget.snapshot()),flush=True)
if __name__=='__main__':run()
