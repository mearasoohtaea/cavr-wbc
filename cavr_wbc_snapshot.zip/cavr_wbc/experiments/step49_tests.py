"""One necessary pure group, with a saved result and no numerical experiment."""
import unittest,io
from cavr_wbc.experiments.step49_io import *
def run(repair=False):
    from tests.test_step49_contract import Step49Contract
    out=output()
    if (out/'tests/NECESSARY_TESTS.json').exists() and not repair:raise FileExistsError('pure group already recorded')
    suite=unittest.TestSuite([Step49Contract('test_4_phase1_and_whole_indices_terminal_RMS_boundary')]) if repair else unittest.defaultTestLoader.loadTestsFromTestCase(Step49Contract)
    stream=io.StringIO();result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    document=dict(tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),output=stream.getvalue(),
        failure_details=[text for _,text in result.failures+result.errors],real_QP_calls=0,MuJoCo_steps=0)
    if repair:
        old=read(out/'tests/NECESSARY_TESTS.json')
        write(out/'tests/INITIAL_GROUP_RESULT.json',old)
        write(out/'tests/AFFECTED_FIXTURE_4_REPAIR.json',document)
        if result.wasSuccessful():
            write(out/'tests/NECESSARY_TESTS.json',dict(tests_run=5,errors=0,failures=0,original_four_topics_passed=True,
                affected_topic_4_repaired=True,real_QP_calls=0,MuJoCo_steps=0,
                initial='INITIAL_GROUP_RESULT.json',repair='AFFECTED_FIXTURE_4_REPAIR.json'))
    else:write(out/'tests/NECESSARY_TESTS.json',document)
    print(stream.getvalue(),flush=True)
    if not result.wasSuccessful():raise SystemExit(1)
if __name__=='__main__':
    import sys
    run('--repair-4' in sys.argv)
