"""Predeclared S, M and V endpoints, fixed planned denominators and pairs."""
from collections import Counter
from cavr_wbc.control.step50_policy import ARMS
def true_physical_failure(r):
    first=r.get('first_physical_failure') or {}
    return bool(r.get('physical_failure_count',0)>0 and any(
        reason!='NUMERICAL_OR_INCOMPLETE_STATE' for reason in first.get('reasons',[])))
def support(rows):
    return dict(snapshots=len({r['snapshot_id'] for r in rows}),episodes=len({r['episode'] for r in rows}))
def endpoints(rows):
    main=[r for r in rows if r['arm']==ARMS[0]]
    sent=[r for r in main if r.get('selected_command_sent')]
    applied=[r for r in sent if r.get('experimental_applied')]
    recovered=[r for r in applied if r.get('phase1_gate_pass')]
    false=[r for r in applied if r.get('D_0to1_m',0)>.006 or
        (true_physical_failure(r) and r['first_physical_failure']['time_s']<=1.) or
        (r.get('phase1_complete') and (not r['phase1']['terminal'] or r.get('D_0to1_m',0)>.006))]
    successes=[r for r in recovered if r['mission_success'] and r.get('handoff_committed') and r.get('continuity_pass')]
    m=support(successes)
    groups={}
    for kind,arms in [('RR_THIGH15',ARMS),('HEALTHY',('NOMINAL_IMMEDIATE',)),('RR_THIGH30',('NOMINAL_IMMEDIATE',))]:
        for arm in arms:
            own=[r for r in rows if r['health_kind']==kind and r['arm']==arm]
            groups[kind+':'+arm]=dict(planned=len(own),applied=sum(r.get('experimental_applied',False) for r in own),
                complete_phase1=sum(r.get('phase1_complete',False) for r in own),
                recovery_gate_pass=sum(r.get('phase1_gate_pass',False) for r in own),
                complete_4s=sum(r['complete_2001'] for r in own),
                mission_success=sum(r['mission_success'] for r in own),
                physical_failure=sum(r.get('physical_failure_count',0)>0 for r in own),
                numerical_partial=sum(r.get('observed',False) and not r['complete_2001'] and not r.get('late') and r['status']!='PHASE1_GATE_FAILED' for r in own),
                late=sum(r.get('late',False) for r in own),gate_refused=sum(r['status']=='PHASE1_GATE_FAILED' for r in own),
                full_task_not_completed=sum(r['complete_2001'] and not r['mission_success'] and not r.get('late') and not r.get('physical_failure_count',0) for r in own),
                unavailable=sum(not r.get('experimental_applied') for r in own),
                classifications=dict(Counter(r.get('final_classification',r['status']) for r in own)))
    by={(r['snapshot_id'],r['health_kind'],r['arm']):r for r in rows};pairs=[];adv=[]
    metrics=['final_goal_error_m','sustained_goal_stop_time_s','external_reference_error_integral_0to4_available_m_s',
        'external_reference_error_integral_1to4_available_m_s','final_half_second_vx_RMS_m_s']
    for source in main:
        snap=source['snapshot_id']
        for a,b in [(ARMS[0],ARMS[1]),(ARMS[0],ARMS[3]),(ARMS[1],ARMS[2]),(ARMS[0],ARMS[4])]:
            ra=by[snap,'RR_THIGH15',a];rb=by[snap,'RR_THIGH15',b]
            qualified=all(r.get('complete_2001') and r.get('physical_safe') and r.get('timing_qualified') for r in (ra,rb))
            physical_adv=bool(ra['mission_success'] and ra.get('experimental_applied') and rb.get('experimental_applied')
                and rb.get('observed') and true_physical_failure(rb))
            p=dict(snapshot_id=snap,episode=source['episode'],a=a,b=b,a_status=ra['status'],b_status=rb['status'],
                a_success=ra['mission_success'],b_success=rb['mission_success'],both_complete_safe_timely=qualified,
                continuous={key:{'a':ra.get(key),'b':rb.get(key),'b_minus_a':None if ra.get(key) is None or rb.get(key) is None else rb[key]-ra[key]}
                    for key in metrics} if qualified else None,physical_safety_advantage=physical_adv,
                missing_or_partial_not_zero_imputed=True)
            pairs.append(p)
            if physical_adv:adv.append(p)
    v=support(adv)
    rejects=Counter(r.get('packet_status','NOT_RUN') for r in main if not r.get('selected_command_sent'))
    action_rejects=Counter()
    for r in main:
        for g,e in r.get('governor_action_rejections',{}).items():
            for reason in e.get('rejection_reasons') or []:action_rejects[reason]+=1
            domain=e.get('terminal_domain') or {}
            if domain.get('accepted') is False:action_rejects['DOMAIN:'+str(domain.get('reason'))]+=1
    return dict(S_RECOVERY=dict(planned_decisions=16,actual_decisions=sum(r.get('actual_governor_call',False) for r in main),
        recognized=sum(r.get('learner_approved',False) for r in main),timely_sent=len(sent),applied=len(applied),
        selected_gamma_distribution=dict(Counter(str(r.get('gamma')) for r in main if r.get('learner_approved'))),
        applied_1s_complete=sum(r.get('phase1_complete',False) for r in applied),
        complete_safe_timely_recovery=len(recovered),false_acceptance=len(false),false_acceptance_ids=[r['id'] for r in false],
        unresolved_1s_partial=sum(not r.get('phase1_complete') and r not in false for r in applied),rejections=dict(rejects),
        causal_action_rejection_counts=dict(action_rejects),actual_first_late=sum(r.get('late',False) and not r.get('selected_command_sent') for r in main)),
        M_ONLINE=dict(status='ONLINE_MISSION_LOCAL_PILOT_OBSERVED' if m['snapshots']>=3 and m['episodes']>=2 else 'NOT_ESTABLISHED',
            **m,successes=len(successes),planned_denominator=16,timely_sent_denominator=len(sent),
            success_planned_fraction=f'{len(successes)}/16',success_conditional_sent_fraction=f'{len(successes)}/{len(sent)}',
            first_second_approval_then_later_mission_failure=sum(r.get('phase1_gate_pass') and not r['mission_success'] for r in applied)),
        V=dict(status='LOCAL_PHYSICAL_SAFETY_OBSERVATION' if v['snapshots']>=3 and v['episodes']>=2 else 'NOT_ESTABLISHED',**v,instances=adv),
        groups=groups,paired=pairs,no_population_significance_claim=True,independent_episode_sources=8,TypeII_matched_chain_retested=False)
