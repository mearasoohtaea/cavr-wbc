"""SciPilot stage outcomes and task/latency raw points; no bank replay."""
from pathlib import Path
import argparse,sys
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from PIL import Image
from cavr_wbc.experiments.step50_io import *
from cavr_wbc.control.step50_policy import ARMS
from cavr_wbc.experiments.step47_figures import embedded_fonts
SKILL=Path('C:/Users/ZhuanZ（无密码）/.codex/skills/scipilot-figure/scripts')
sys.path.insert(0,str(SKILL))
from setup_style import setup_style
from profile_data import profile_data
from visual_qa import audit_layout,render_preview
from export_figure import export_figure
from check_figure import check_figure
from layout_tools import add_panel_labels
COLORS=dict(zip(ARMS,('#0072B2','#E69F00','#D55E00','#009E73','#777777')))
MARKERS=dict(zip(ARMS,('o','s','^','D','v')))
SHORT=['Governor','Middle res.','Middle imm.','B resume','Nominal']
GROUPS=[('RR_THIGH15',a) for a in ARMS]+[('HEALTHY',ARMS[-1]),('RR_THIGH30',ARMS[-1])]
NAMES=SHORT+['Healthy C','Mild C']
OUTCOMES=['Success','Physical','Late','Gate / task','Numerical','ABSTAIN','Unsent / NA']
PALETTE=['#0072B2','#D55E00','#CC79A7','#E69F00','#009E73','#777777','#eeeeee']
HATCH=['','///','...','xx','++','--','']
def outcome(r):
    if r['mission_success']:return 0
    if r.get('physical_failure_count',0)>0:return 1
    if r.get('late'):return 2
    if r['status']=='PHASE1_GATE_FAILED' or r.get('complete_2001'):return 3
    if r.get('observed'):return 4
    if r.get('packet_status')=='ABSTAIN':return 5
    return 6
def finish(fig,axs,headline,note):
    fig.suptitle(headline,fontsize=11);fig.text(.5,.012,note,ha='center',fontsize=7)
    fig.set_layout_engine('constrained',h_pad=.12,w_pad=.10,rect=(.015,.065,.98,.91))
    fig.canvas.draw();add_panel_labels(fig,axes=axs,style='ieee',fontsize=9,x_offset_pt=-10,y_offset_pt=12)
def figure1(rows):
    fig,axs=plt.subplots(2,1,figsize=(7.16,9.),gridspec_kw={'height_ratios':[1.45,1.]})
    a,b=axs
    main=sorted([r for r in rows if r['arm']==ARMS[0]],key=lambda r:(r['episode'],r['tick']))
    for i,r in enumerate(main):
        selected=r.get('learner_approved');sent=r.get('selected_command_sent');ph=r.get('phase1',{})
        choice=str(r['gamma']) if selected else 'ABSTAIN' if r.get('packet_status')=='ABSTAIN' else 'NA'
        one='NA' if not r.get('observed') else 'PASS' if r.get('phase1_gate_pass') else 'PHYS' if ph and not ph.get('physical') else 'TASK' if ph.get('complete') and not ph.get('terminal') else 'LATE' if r.get('late') and not ph.get('complete') else 'PART'
        codes=[choice,'SENT' if sent else 'LATE' if r.get('late') else 'NO',one,OUTCOMES[outcome(r)]]
        for j,code in enumerate(codes):
            good=(j==0 and selected) or (j==1 and sent) or (j==2 and code=='PASS') or (j==3 and code=='Success')
            color='#dceef6' if good else '#f7e6df' if code in ('PHYS','Physical','TASK','Gate / task') else '#eeeeee'
            a.add_patch(plt.Rectangle((j-.48,i-.44),.96,.88,facecolor=color,edgecolor='white'))
            a.text(j,i,code,ha='center',va='center',fontsize=8)
        if i%2==1:a.axhline(i+.5,color='#bbbbbb',lw=.5)
    a.set_xlim(-.5,3.5);a.set_ylim(15.6,-.6);a.set_xticks(range(4),['Own choice','Timely first send','Observed 1 s','Same branch 4 s'])
    a.xaxis.tick_top();a.set_yticks(range(16),[f"E{r['episode'].split('_')[-1]} / T{r['tick']}" for r in main])
    a.set_ylabel('8 fresh episodes / 16 snapshots')
    a.set_title('Frozen governor: recognition, dispatch, recovery and mission',loc='left',pad=28,fontsize=9)
    data=[]
    for i,(kind,arm) in enumerate(GROUPS):
        own=[r for r in rows if r['arm']==arm and r['health_kind']==kind];counts=[sum(outcome(r)==j for r in own) for j in range(7)];left=0
        for j,n in enumerate(counts):
            b.barh(i,n,left=left,color=PALETTE[j],hatch=HATCH[j],edgecolor='white',height=.7,lw=.5)
            if n:b.text(left+n/2,i,str(n),ha='center',va='center',fontsize=8)
            left+=n
        data.append(dict(kind=kind,arm=arm,counts=dict(zip(OUTCOMES,counts)),planned=len(own)))
    b.set_yticks(range(7),NAMES);b.set_xlim(0,16);b.set_xticks([0,4,8,12,16]);b.invert_yaxis()
    b.set_xlabel('Allocated positions (n / 16 per arm / health group)')
    b.set_title('All 112 positions; failed and unavailable branches retained',loc='left',pad=12,fontsize=9)
    b.legend(handles=[plt.Rectangle((0,0),1,1,facecolor=PALETTE[j],hatch=HATCH[j],label=OUTCOMES[j]) for j in range(7)],
        loc='upper center',bbox_to_anchor=(.5,-.20),ncol=4,frameon=False,fontsize=8)
    finish(fig,axs,'STEP50 | Frozen governor to original mission',
        'NA = unobserved; PART = incomplete prefix. Late is not physical failure. Overlaps retained in JSON.\n'
        'Outcome priority: success > physical > late > gate/task > numerical > ABSTAIN > unsent.')
    write(output()/'figures/FIG1_OUTCOMES.json',data)
    return fig
def figure2(rows,latency,result):
    fig,axs=plt.subplots(3,2,figsize=(7.16,9.))
    metrics=[(axs[0,0],'final_goal_error_m',1000,2.,'Last observed original-goal error','Absolute error (mm)'),
        (axs[0,1],'sustained_goal_stop_time_s',1,None,'Sustained goal + stop (full trajectory)','Time (s)'),
        (axs[1,0],'final_half_second_vx_RMS_m_s',1000,1.,'Final 0.5 s vx RMS (1750..2000)','vx RMS (mm/s)')]
    for ax,key,scale,threshold,title,ylabel in metrics:
        for i,(kind,arm) in enumerate(GROUPS):
            own=sorted([r for r in rows if r['health_kind']==kind and r['arm']==arm],key=lambda r:(r['episode'],r['tick']));available=0
            for j,r in enumerate(own):
                value=r.get(key)
                if value is None:continue
                available+=1;full=r.get('complete_2001');qualified=full and r.get('physical_safe') and r.get('timing_qualified')
                ax.scatter(i+(j-7.5)*.029,abs(value)*scale,color=COLORS[arm] if qualified or not full else 'none',
                    edgecolors=COLORS[arm] if full else None,marker=MARKERS[arm] if full else 'x',s=18,linewidths=.65)
            ax.text(i,.98,f'{available}/16',transform=ax.get_xaxis_transform(),ha='center',va='top',fontsize=7)
        if threshold is not None:ax.axhline(threshold,color='black',ls='--',lw=.8)
        values=[abs(r[key])*scale for r in rows if r.get(key) is not None]
        upper=max(values+[threshold or 0.,.01])*1.25
        ax.set_ylim(0,upper);ax.set_xticks(range(7),['Gov.','M res.','M imm.','B res.','C','H C','m C'],rotation=20)
        ax.set_title(title,loc='left',pad=12,fontsize=8);ax.set_ylabel(ylabel)
    p=axs[1,1];pairs=result['endpoints']['paired']
    for i,(a,b) in enumerate([(ARMS[0],ARMS[1]),(ARMS[0],ARMS[3]),(ARMS[1],ARMS[2]),(ARMS[0],ARMS[4])]):
        own=[r for r in pairs if r['a']==a and r['b']==b];valid=0
        for j,r in enumerate(own):
            if not r['both_complete_safe_timely']:continue
            v=r['continuous']['final_goal_error_m'];valid+=1
            p.scatter(i+(j-7.5)*.029,(abs(v['b'])-abs(v['a']))*1000,color=COLORS[a],marker='o',s=18)
        p.text(i,.98,f'{valid}/16',transform=p.get_xaxis_transform(),ha='center',va='top',fontsize=7)
    p.axhline(0,color='black',lw=.7);p.set_xticks(range(4),['Gov-M','Gov-B','M res-imm','Gov-C'],rotation=20);p.margins(y=.25)
    p.set_ylabel('|error B| - |error A| (mm)');p.set_title('Pairs: both complete, safe, timely',loc='left',pad=12,fontsize=8)
    for ax,key,threshold in [(axs[2,0],'complete_ms',20),(axs[2,1],'prepared_ms',17)]:
        for i,kind in enumerate(('FIRST','FEEDBACK','HANDOFF')):
            own=[r for r in latency if r['kind']==kind];available=0;batches={}
            for j,r in enumerate(own):
                val=r.get(key)
                if val is None:continue
                available+=1;jitter=((j*37)%101/100-.5)*.55
                batch=batches.setdefault((r['arm'],bool(r['applied'])),[[],[]])
                batch[0].append(i+jitter);batch[1].append(val)
            for (arm,applied),(xs,ys) in batches.items():
                ax.scatter(xs,ys,color=COLORS[arm],marker='o' if applied else 'x',s=7,alpha=.35)
            ax.text(i,.98,f'n={available}\nNA={len(own)-available}',transform=ax.get_xaxis_transform(),ha='center',va='top',fontsize=7)
        ax.axhline(threshold,color='black',ls='--',lw=.8)
        ax.set_ylim(0,max([r[key] for r in latency if r.get(key) is not None]+[threshold])*1.25)
        ax.set_xticks(range(3),['First','Feedback','1 s handoff'])
        ax.set_ylabel('Complete ready (ms)' if key=='complete_ms' else 'Prepared commit (ms)')
        ax.set_title('Every recorded window; uncommitted = x',loc='left',pad=12,fontsize=8)
    fig.legend(handles=[Line2D([],[],color=COLORS[a],marker=MARKERS[a],ls='',label=SHORT[i]) for i,a in enumerate(ARMS)],
        loc='upper center',bbox_to_anchor=(.5,.965),ncol=5,frameon=False,fontsize=7)
    finish(fig,list(axs.flat),'STEP50 | Task metrics, matched pairs and real latency',
        'All 8 episodes retained. Filled = full safe/timely; open = other full; x = partial endpoint. Counts = available / planned.\n'
        'Missing values remain missing. Conditional paired points are descriptive; no population significance test.')
    return fig
def run(export=False):
    out=output();folder=out/'figures';folder.mkdir(exist_ok=True)
    rows=read(out/'BRANCH_ROWS.json');latency=read(out/'LATENCY.json');result=read(out/'RESULT.json')
    style=setup_style('ieee',lang='en')
    plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],'font.size':8,
        'axes.labelsize':8,'xtick.labelsize':7,'ytick.labelsize':7,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
    profiles={}
    for name,frame,groups in [('BRANCH_ROWS',pd.DataFrame(rows)[['health_kind','arm','status','mission_success','final_goal_error_m','final_half_second_vx_RMS_m_s']],['health_kind','arm']),
        ('LATENCY',pd.DataFrame(latency)[['kind','arm','complete_ms','prepared_ms','applied']],['kind','arm'])]:
        profiles[name]=profile_data(frame,groups)
    write(folder/'DATA_PROFILES.json',profiles)
    write(folder/'CHART_SELECTION.json',dict(objectives=['all-planned recognition/send/recovery/mission','same-source task metrics and all latency'],
        choice='per-source stage matrix and outcome counts; raw point and matched-pair panels',
        reason='16 paired snapshots from only 8 independent episodes; missing and partial explicit',
        alternatives=['per-episode outcome pages','paired numeric tables'],mean_bars=False,pvalues=False,double_y=False))
    qa=[]
    for name,fig in [('FIG1_GOVERNOR_TO_MISSION',figure1(rows)),('FIG2_TASK_PAIRS_LATENCY',figure2(rows,latency,result))]:
        size=(7.16,9.);layout=audit_layout(fig);preview=render_preview(fig,str(folder/(name+'_preview.png')),dpi=165)
        q=dict(name=name,layout=layout,preview=preview,publication_size_inches=size,style=style)
        if export:
            if any(s=='FAIL' for s,_ in layout):raise ValueError('figure layout failure')
            paths=export_figure(fig,str(folder/name),formats=['pdf','png'],dpi=600,size_inches=size,grayscale_preview=False,tight=False)
            with Image.open(folder/(name+'.png')) as im:im.convert('L').save(folder/(name+'_grayscale.png'),dpi=(600,600))
            q.update(files={Path(p).name:sha(p) for p in paths},
                compliance=[dict(path=p,issues=check_figure(p,min_dpi=600,target_inches=size)[0],info=check_figure(p,min_dpi=600,target_inches=size)[1]) for p in paths],
                PDF_font_descendants=embedded_fonts(folder/(name+'.pdf')))
        else:
            with Image.open(folder/(name+'_preview.png')) as im:im.convert('L').save(folder/(name+'_gray_preview.png'))
        qa.append(q);plt.close(fig)
    write(folder/('EXPORT_QA.json' if export else 'PREVIEW_QA.json'),qa)
    print(dict(figures=2,exported=export,layout_issues=[q['layout'] for q in qa]),flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--export',action='store_true');run(p.parse_args().export)
