"""All 112 fixed positions, rotated severe arms and parity-ordered controls."""
from copy import deepcopy
from cavr_wbc.control.step50_policy import ARMS,internal_plan
from cavr_wbc.experiments.step46_inputs import context_for as source_context
from cavr_wbc.experiments.step50_io import OLD_METHOD_SHA
TARGETS=(-.0623125,-.0631875,-.0640625,-.0649375,-.0658125,-.0666875,-.0675625,-.0684375)
def episodes():
    return [dict(episode_id=f'T50_DEV_{i}',episode_ordinal=i,displacement_m=d,direction=-1,snapshot_ticks=[37,41]) for i,d in enumerate(TARGETS)]
def plans():
    rows=[]
    for ep in episodes():
        for j,tick in enumerate((37,41)):
            n=ep['episode_ordinal']*2+j;snap=ep['episode_id']+f'_T{tick:03d}'
            controls=('HEALTHY','RR_THIGH30') if ep['episode_ordinal']%2==0 else ('RR_THIGH30','HEALTHY')
            for kind in ('RR_THIGH15',)+controls:
                severe=kind=='RR_THIGH15'
                rows.append(dict(**ep,episode=ep['episode_id'],tick=tick,source_tick=tick,
                    snapshot_id=snap,source_snapshot=snap,context_id=snap+'_'+kind,
                    case_id=snap+'_'+kind,source_state_id=snap+'_'+kind,ordinal=len(rows),source_ordinal=n,
                    health_kind=kind,role='healthy' if kind=='HEALTHY' else 'thigh',
                    fault_leg='NONE' if kind=='HEALTHY' else 'RR',
                    health=1. if kind=='HEALTHY' else .15 if severe else .30,
                    split='DEV',source_split='STEP50_FRESH_DEV',gap_m=.006,severe=severe,
                    arms=list(ARMS[n%5:]+ARMS[:n%5]) if severe else ['NOMINAL_IMMEDIATE'],governor_planned=severe))
    return rows
def gamma_for(arm):return None if arm==ARMS[0] else 0. if arm=='B_RECOVER_RESUME' else 1. if arm=='NOMINAL_IMMEDIATE' else .5
def positions():
    return [dict(id=p['context_id']+':'+a,context_id=p['context_id'],snapshot_id=p['snapshot_id'],
        episode=p['episode'],tick=p['tick'],health_kind=p['health_kind'],arm=a,
        severe=p['severe'],gamma=gamma_for(a)) for p in plans() for a in p['arms']]
def context_for(p,ep,mapping):
    c=source_context(p,ep,mapping);c.update(backup_id='STEP50-'+p['context_id'],group='STEP50_FIXED_DEV')
    if c.get('previous_command_identity',{}).get('available'):c['previous_command_identity']['source']='NEW_STEP50_REFERENCE'
    return c
def arm_context(c,arm,contract,new_sha):
    v=deepcopy(c)
    v.update(backup_id=c['backup_id']+':'+arm,external_arm=arm,experimental_arm=internal_plan(arm),
        method='TASK_MATCHED',comparison_arm='PHASE_MATCHED_TASK',policy_contract=deepcopy(contract),
        step48_method_freeze_sha256=OLD_METHOD_SHA,step50_method_freeze_sha256=new_sha,
        authorization_scope='RECOVERY_1S_ONLY',old_CAL_certifies_mission=False)
    return v
