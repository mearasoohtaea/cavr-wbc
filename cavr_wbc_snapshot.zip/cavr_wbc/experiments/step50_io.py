"""New D-only scope; historical scientific banks remain read-only."""
from cavr_wbc.experiments.step47_io import write,read,append,sha,encode,relative,save_numeric,load_numeric,OUTPUT_ROOT_D,NATIVE_DLL
from pathlib import Path
SOURCE_ROOT_D=Path('D:/CAVR-WBC/cavr_step49_recovery_to_mission_pilot_20261012')
SOURCE_COMMIT='ceeb96d344b8f2028f9a8dda3f94732ec046143d'
CAL_RUN=Path('D:/CAVR-WBC/cavr_step48_phase_matched_cal_confirmation_20261012/artifacts/step48_phase_matched_confirmation_20261012/step48-phase-matched-cal-confirmation-20261012-01')
PROTOCOL=Path('D:/CAVR-WBC/experiment_handoff_20261010/NEXT_CODEX_INSTRUCTIONS_STEP50_FROZEN_GOVERNOR_TO_MISSION_20261012.md')
RUN_ID='step50-frozen-governor-to-mission-20261012-01'
OLD_METHOD_SHA='d22f69f51da86dd77828664b2d0a8a81b61c014d159120a222a8903f05f7d72e'
ASSET_HASHES={'models/PHASE_MATCHED_TASK.npz':'f73e83cf1eff21a495cbd44c6b3c9f3d6a05aec33971a07a836405ec28b34993',
    'models/PHASE_MATCHED_TASK.json':'65868d21a0e5a29d7847f9eff3d9ae691066319e393bcc8c8542b3efa55bfe97',
    'models/PHASE_MATCHED_TASK_DOMAIN.json':'6898d6104eaae503b3c49832e9100c68e8f3f2878ced761f73e69546db7ca25e'}
def output():return OUTPUT_ROOT_D/'artifacts/step50_frozen_governor_to_mission_20261012'/RUN_ID
