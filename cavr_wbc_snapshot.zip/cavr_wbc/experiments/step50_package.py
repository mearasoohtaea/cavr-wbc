"""Evidence-led Chinese report, full protocol states and next-user handoff."""
from collections import Counter
from cavr_wbc.experiments.step50_io import *
from cavr_wbc.control.step50_policy import ARMS
def run():
    out=output();result=read(out/'RESULT.json');ep=result['endpoints'];s=ep['S_RECOVERY'];m=ep['M_ONLINE'];v=ep['V']
    rows=read(out/'BRANCH_ROWS.json');budget=result['budget']
    status=PROTOCOL.read_text(encoding='utf-8').split('```ini')[1].split('```')[0].strip()
    status+='\nSTEP50_RUN_STATUS = '+result['run_status']+'\nSTEP50_READBACK_STATUS = '+read(out/'READBACK_VERDICT.json')['status']
    status+='\nSTEP50_M_ONLINE = '+m['status']+'\nSTEP50_V = '+v['status']+'\nINDEPENDENT_NUMERICAL_REPRODUCTION = UNVERIFIED\n'
    (out/'PROTOCOL_STATUS.ini').write_text(status,encoding='utf-8')
    table=['|健康 / 方法|计划|首包施加|完整 4 s|任务成功|物理失败|late|gate / task 拒收|未发送 / 不可用|',
        '|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    for key,g in ep['groups'].items():
        table.append(f"|{key}|{g['planned']}|{g['applied']}|{g['complete_4s']}|{g['mission_success']}|{g['physical_failure']}|{g['late']}|{g['gate_refused']+g['full_task_not_completed']}|{g['unavailable']}|")
    main=[r for r in rows if r['arm']==ARMS[0]]
    ledger=['|source / episode|γ|认可|发送|1 s 完整|恢复通过|handoff commit|4 s 完整|任务成功|结果|',
        '|---|---:|---|---|---|---|---|---|---|---|']
    for r in main:
        ledger.append('|'+str(r['snapshot_id'])+' / '+r['episode']+'|'+str(r.get('gamma'))+'|'+
            '|'.join(str(bool(r.get(k))) for k in ('learner_approved','selected_command_sent','phase1_complete','phase1_gate_pass','handoff_committed','complete_2001','mission_success'))+
            '|'+str(r.get('final_classification',r.get('packet_status',r['status'])))+'|')
    pairs=[]
    for a,b in [(ARMS[0],ARMS[1]),(ARMS[0],ARMS[3]),(ARMS[1],ARMS[2]),(ARMS[0],ARMS[4])]:
        own=[p for p in ep['paired'] if p['a']==a and p['b']==b]
        valid=[p for p in own if p['both_complete_safe_timely']]
        pairs.append(f"- {a} 对 {b}：计划16对，双方完整、安全、及时的连续指标可用 {len(valid)} 对。逐对值与缺测见 RESULT.json / endpoints.paired。")
    report=f"""# STEP50：冻结 governor 到原绝对任务

## 实测终点

S_RECOVERY：16 个计划 governor 位置，实际调用 {s['actual_decisions']} 次；认可 {s['recognized']}，及时发送 {s['timely_sent']}，实际首包施加 {s['applied']}。
其中实际 1 s 完整 {s['applied_1s_complete']}，完整、安全、及时且满足原恢复终端 {s['complete_safe_timely_recovery']}；
已观察 false acceptance {s['false_acceptance']}，尚未完整观察的 1 s partial {s['unresolved_1s_partial']}。
认可 γ 分布：{s['selected_gamma_distribution']}；未发送状态：{s['rejections']}。
因果候选拒收（可重叠、不用作成功分母）：{s['causal_action_rejection_counts']}；未发送且首包late {s['actual_first_late']}。

M_ONLINE = {m['status']}。同一真实学习首包、原 1 s gate、同 owner 连续 4 s 任务成功为 {m['successes']}/16 个计划位，
条件发送分母为 {m['success_conditional_sent_fraction']}；来自 {m['snapshots']} 个不同物理 snapshot、{m['episodes']} 个不同 reference episode。
1 s 恢复通过后任务仍失败 {m['first_second_approval_then_later_mission_failure']} 条，单列保存。
V = {v['status']}：物理安全区分支持 {v['snapshots']} snapshot / {v['episodes']} episode；late、ABSTAIN、任务未完成不充当物理失败。

本轮固定批次状态 {result['run_status']}；112 个位置全部在结果表占位，其中真实轨迹 {result['observed']}，完整4 s {result['complete_4s']}。
全体方法合计任务成功 {result['mission_success']} 仅为批次描述，不作为主策略成功率。

## 全部固定分母

"""+'\n'.join(table)+"""

列可重叠：late 与物理失败按原事实各自记数，图1另给互斥显示优先级。未发送位置未补样；partial 未填充到4 s。

## 主臂逐条学习链

"""+'\n'.join(ledger)+"""

## 配对、容量和独立来源

"""+'\n'.join(pairs)+f"""

每臂16个 severe位置；healthy、mild nominal各16。8个独立 reference episode，每episode两snapshot。
goal error、settled time、外部原reference误差积分0–4/1–4与末0.5 s RMS的条件配对值保存于 JSON，不零填充。
不将 dense、QP 或同episode snapshot视为独立样本，不做后选终点p值。
实际99%容量与anti-windup冻结事件见逐分支 RESULT.capacity.control_series；
healthy/mild C不是TASK B的匹配容量反事实，本轮未重证完整Type-II链。

## 冻结和连续执行

主臂使用自身真实 PHASE_MATCHED_TASK governor，并逐包保留 model_authorized、learner_approved、governor_selected、selected_command_sent。
固定γ实验、nominal C不获得模型认可。nominal第一包由自身C owner、原容量约束与原candidate证明生成，无无关B0成功依赖。
恢复主臂前1 s使用原TASK_AWARE_1MM_06S_V1；旧 method-freeze={OLD_METHOD_SHA} 不变。
组合策略 STEP50_FROZEN_GOVERNOR_RECOVERY_TO_MISSION_4S_V1 另设本轮freeze，旧CAL授权仅 RECOVERY_1S_ONLY，不认证4 s任务。

所有臂相同物理、PID、预测、native B/C/feedback预算6/3/6 ms、prepared17/complete20 ms。
固定γ0/.5和学习臂保留自身B0、PID/native历史；nominal记录自身零PID初始seed。
t=1 s不reset plant/controller/backup/PID/health/warmstart；gate与switch在原feedback墙钟内。
外部方法显式映射内部MISSION计划；恢复后1–3 s、immediate .02–2.02 s使用原2 s quintic回到 nominal_q_init_x+nominal_d_m，后续保持。
4 s成功需2000步/2001dense/200控制/81checkpoint、全物理安全与及时、原目标2mm、末vx和RMS1mm/s及原其他terminal门。
RMS固定1750..2000含端点；恢复6mm门不强加到任务阶段，原世界workspace全程有效。

## 执行和验证

数值开始 {budget['numerical_started_utc']}，累计 {budget['numerical_elapsed_s']:.2f} s。
QP START {budget['total_QP_calls']}、RETURN {budget['QP_returns']}、UNKNOWN {budget['unknown_native_returns']}；
积分 {budget['total_physics_steps']}，CAL/TRAIN/fit=0。上限120 min/35000QP/320000步未增加，数值结果重试0。
首次五类纯测试4/5通过，仅浮点等值断言修复后重测类别3，最终5/5；所有记录在tests。
没有数值smoke、历史实验、额外审计门或独立数值复现。
一次本轮 streaming 读回 {read(out/'READBACK_VERDICT.json')['status']}，issues={result['issues']}，新QP/积分=0。
源STEP49 Git/index、源CAL配置/model资产与native hash保持；文件读回不是独立复现，MaterialPassport=UNVERIFIED。

SciPilot先做数据剖析，采用全部16主臂阶段矩阵、112位置结果构成、原始指标/配对点和全部延迟分布；
两张IEEE双栏7.16in PDF/600dpi PNG、灰度和机器/视觉复核见figures。无均值柱、双Y或缺测零填。
首轮视觉复核修正了未发送分支的1 s“未观察”标注及计数文字覆盖；原科学数据未改变。
旧通用传播头中的 independent_baseline_decision_latency_measured=False 是遗留标签，
不用于本轮首包时延结论；本轮每臂自己的 PACKET prepared/complete 墙钟及 owner 是实际时延证据。
该标签原样保留在银行，展示解释见 REPORT_ERRATA.json；不重算、不覆盖轨迹。
V的物理失败按原2 ms逐状态门判定，不自动等同持续摔倒；失败类型及持续网格点数见对应RESULT.contact_statistics。

## 研究交接

本轮定位为 capacity- and backup-aware action governance for recovery-to-mission execution under actuator degradation。
实测链条连接了冻结筛选、决策时当前容量/可行性与自身反馈恢复到原任务；局部pilot不等同全域安全定理或硬实时部署证明。
下一研究重点是跨状态/健康/扰动来源的预声明外部泛化和独立数值复现；仅作为研究建议，未授权、未启动。
IEEE T-RO目标不变。本轮停止，不进入STEP51、E3、RL或硬件。

## 实际文件和命令

工作副本：{OUTPUT_ROOT_D}
原提交：{SOURCE_COMMIT}
唯一输出：{out}
源解释器只读：E:/CAVR-WBC/_runtime_step30/python311/python.exe；当前包、TMP/TEMP、图缓存、Git对象均在上述D副本。
可原样命令与全部执行环境见 EXECUTION_COMMANDS.ps1 / DELIVERY_MANIFEST.json。
本轮仅新增 step50 模块、必要测试、协议和本轮工件；旧代码/native/model无改动。
当前副本 .gitattributes 仅追加STEP50专用字节保留规则，保障跨checkout证据hash不被换行转换改变。
scoped commit与Git最终状态见工作树 .git/STEP50_COMMIT_RECEIPT.json；不推送。

## 全部协议状态

```ini
{status}```
"""
    (out/'REPORT.md').write_text(report,encoding='utf-8')
    handoff=f"""# STEP50研究交接

真实主链 M_ONLINE={m['status']}，计划 {m['successes']}/16，发送条件 {m['success_conditional_sent_fraction']}，
不同snapshot/episode={m['snapshots']}/{m['episodes']}。S_RECOVERY认可/及时发送/完整安全恢复={s['recognized']}/{s['timely_sent']}/{s['complete_safe_timely_recovery']}，
已观察false acceptance={s['false_acceptance']}，partial未补齐；V={v['status']}。

完整 evidence、逐主臂结果、全部112分母、固定配置与范围见 REPORT.md、RESULT.json、BRANCH_ROWS.csv。
本轮停止。历史结果不改，禁区项目不接触；STEP51/E3/RL/硬件未执行。下一轮需要用户新协议。
工作副本 {OUTPUT_ROOT_D}；输出 {out}；commit回执见 .git/STEP50_COMMIT_RECEIPT.json。
独立数值复现UNVERIFIED；文件读回MATCH不代替独立复现。
"""
    (out/'HANDOFF.md').write_text(handoff,encoding='utf-8')
    command=f"""# Historical prepare/run commands are receipts, not authorization to redispatch.
Set-Location -LiteralPath '{OUTPUT_ROOT_D}'
$env:TMP='{OUTPUT_ROOT_D}/.runtime'
$env:TEMP=$env:TMP
$env:MPLCONFIGDIR=$env:TMP
$env:PYTHONNOUSERSITE='1'
$env:PYTHONPATH='E:/CAVR-WBC/_deps_step26;E:/CAVR-WBC/cavr_step02h_exact_primal_certificate_20260918/.venv-step02h/Lib/site-packages'
$env:OMP_NUM_THREADS='1'; $env:OPENBLAS_NUM_THREADS='1'; $env:MKL_NUM_THREADS='1'
# Already executed once; run guard rejects a second numerical dispatch.
& 'E:/CAVR-WBC/_runtime_step30/python311/python.exe' -B -X utf8 -m cavr_wbc.experiments.step50_prepare
& 'E:/CAVR-WBC/_runtime_step30/python311/python.exe' -B -X utf8 -m cavr_wbc.experiments.step50_tests
& 'E:/CAVR-WBC/_runtime_step30/python311/python.exe' -B -X utf8 -m cavr_wbc.experiments.step50_tests 3
& 'E:/CAVR-WBC/_runtime_step30/python311/python.exe' -B -X utf8 -m cavr_wbc.experiments.step50_sprint
& 'E:/CAVR-WBC/_runtime_step30/python311/python.exe' -B -X utf8 -m cavr_wbc.experiments.step50_delivery
& 'E:/CAVR-WBC/_runtime_step30/python311/python.exe' -B -X utf8 -m cavr_wbc.experiments.step50_figures
& 'E:/CAVR-WBC/_runtime_step30/python311/python.exe' -B -X utf8 -m cavr_wbc.experiments.step50_figures --export
& 'E:/CAVR-WBC/_runtime_step30/python311/python.exe' -B -X utf8 -m cavr_wbc.experiments.step50_package
& 'E:/CAVR-WBC/_runtime_step30/python311/python.exe' -B -X utf8 -m cavr_wbc.experiments.step50_finalize
"""
    (out/'EXECUTION_COMMANDS.ps1').write_text(command,encoding='utf-8')
    print(dict(S=s,M=m,V=v['status'],report=str(out/'REPORT.md')),flush=True)
if __name__=='__main__':run()
