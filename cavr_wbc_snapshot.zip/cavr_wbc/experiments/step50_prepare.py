"""One environment confirmation and exact frozen PHASE_MATCHED_TASK copy."""
import os,shutil
import numpy as np
from cavr_wbc.experiments.step50_io import *
from cavr_wbc.experiments.step50_inputs import episodes,plans,positions
def prepare():
    out=output();out.mkdir(parents=True,exist_ok=True)
    if (out/'PREPARATION.json').exists():raise FileExistsError('one environment confirmation only')
    import cavr_wbc,mujoco,osqp,scipy,threadpoolctl
    if not Path(cavr_wbc.__file__).resolve().is_relative_to(OUTPUT_ROOT_D):raise ValueError('wrong package root')
    free=shutil.disk_usage(OUTPUT_ROOT_D).free
    if free<8_000_000_000 or not NATIVE_DLL.is_file():raise OSError('D space/native prerequisite')
    write(out/'PREPARATION.json',dict(package=cavr_wbc.__file__,D_free_bytes=free,TMP=os.environ['TMP'],TEMP=os.environ['TEMP'],
        MPLCONFIGDIR=os.environ['MPLCONFIGDIR'],native=str(NATIVE_DLL),native_sha256=sha(NATIVE_DLL),
        versions=dict(mujoco=mujoco.__version__,osqp=osqp.__version__,numpy=np.__version__,scipy=scipy.__version__),
        threadpools=threadpoolctl.threadpool_info(),new_QP=0,new_steps=0))
    files=list(ASSET_HASHES)+['STEP48_CAL_FREEZE.json','ACTUAL_POLICY_CONTRACTS.json','SOURCE_FROZEN_CONFIG.json']
    hashes={}
    for rel in files:
        src=CAL_RUN/rel;dst=out/rel
        if dst.exists():raise FileExistsError(str(dst))
        digest=sha(src)
        if rel in ASSET_HASHES and digest!=ASSET_HASHES[rel]:raise ValueError('frozen asset hash '+rel)
        dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
        if sha(dst)!=digest:raise ValueError('copy identity')
        hashes[rel]=digest
    freeze=read(out/'STEP48_CAL_FREEZE.json')
    contract=freeze['methods']['PHASE_MATCHED_TASK']['policy_contract']
    if contract!=read(out/'ACTUAL_POLICY_CONTRACTS.json')['TASK_MATCHED'] or contract['method_freeze_sha256']!=OLD_METHOD_SHA:raise ValueError('frozen policy binding')
    write(out/'SOURCE_READONLY_BASELINE.json',dict(source_commit=SOURCE_COMMIT,source_worktree=str(SOURCE_ROOT_D),
        source_index_sha256=sha(SOURCE_ROOT_D/'.git/index'),assets=hashes,native_sha256=sha(NATIVE_DLL),historical_bank_read=False))
    write(out/'INPUTS_PLAN.json',dict(episodes=episodes(),contexts=plans(),positions=positions(),
        max_wall_s=7200,max_QP=35000,max_steps=320000,fits=0,CAL=0,TRAIN=0))
    print(dict(prepared=True,references=8,positions=len(positions()),new_QP=0,new_steps=0),flush=True)
if __name__=='__main__':prepare()
