"""New four-second fact storage with actual partial lengths and gate receipt."""
from copy import deepcopy
from cavr_wbc.experiments.step50_io import *
from cavr_wbc.experiments.step26_features_storage import save_bank,load_bank
from cavr_wbc.experiments.step47_storage import capacity_series,contact_statistics
from cavr_wbc.evaluation.step50_actual import evaluate
def not_run(gamma,reason):return dict(status='NOT_RUN',gamma=gamma,reason={'reason':reason})
def save_branch(out,path,branch,c,packet):
    path.mkdir(parents=True,exist_ok=True)
    result=dict(status=branch['status'],reason=branch.get('reason'),observed=branch['status']!='NOT_RUN',
        gamma=branch.get('gamma'),health_kind=c['health_kind'],arm=c['external_arm'],
        context_id=c['context_id'],episode=c['episode'],snapshot_id=c['snapshot_id'],tick=c['source_tick'],
        backup_id=c['backup_id'],experimental_dispatch=bool(packet.get('experimental_dispatch')),
        experimental_applied=branch.get('counts',{}).get('physical_steps',0)>10,
        experimental_committed=bool(packet.get('experimental_committed')),model_authorized=bool(packet.get('model_authorized')),
        learner_approved=bool(packet.get('learner_approved')),governor_selected=bool(packet.get('governor_selected')),
        dispatch_kind=packet.get('dispatch_kind'),nominal_sent=bool(packet.get('nominal_sent')),
        selected_command_sent=bool(packet.get('selected_command_sent')),packet_status=packet['status'],
        counts=branch.get('counts'),composite_policy_id=packet.get('composite_policy_id'),
        policy_version=packet.get('policy_version'),policy_contract=packet.get('policy_contract'),
        authorization_scope='RECOVERY_1S_ONLY',
        first_packet_ready_ms=packet.get('command_ready_ms'),first_packet_prepared_ms=packet.get('prepared_commit_ms'),
        old_CAL_certifies_mission=False,original_anchor_changed=False,source_goal=c.get('policy_anchor_goal'),
        result_path=relative(path/'RESULT.json',out))
    if result['observed']:
        light={k:v for k,v in branch.items() if k not in ('controls','solver_ledger')}
        light.update(controls=[],solver_ledger=[])
        result['artifact']=save_bank(path/'actual.npz',light,landmark_steps=range(0,2001,25))
        rows=[]
        for r in branch['controls']:
            raw=r.get('raw_solver_result') or {};ix=raw.get('step37_global_qp_index',raw.get('step35_global_qp_index'))
            rows.append({**{k:v for k,v in r.items() if k!='raw_solver_result'},
                'raw_solver_evidence':None if ix is None else f'raw_qp/QP{int(ix):06d}.json'})
        result['controls_numeric']=save_numeric(path/'controls.json',dict(controls=rows,solver_ledger=branch['solver_ledger']))
        result['evaluation']=evaluate(branch,c,packet)
        result.update(capacity=capacity_series(branch,c),contact_statistics=contact_statistics(branch),
            handoff=branch.get('handoff'),phase1_online_summary=branch.get('phase1_online_summary'),
            continuity_start=branch.get('continuity_start'),continuity_end=branch.get('continuity_end'),
            application_identity_pass=branch.get('application_identity_pass'),
            complete_2001=result['evaluation']['whole_complete'],mission_success=result['evaluation']['mission_success'])
        if result['application_identity_pass'] is False:raise ValueError('application scientific identity mismatch')
        if result['phase1_online_summary']!=result['evaluation']['phase1']:raise ValueError('online gate/offline phase1 mismatch')
    else:result.update(evaluation={},complete_2001=False,mission_success=False)
    write(path/'RESULT.json',result)
    write(path/'INCREMENTAL_RECEIPT.json',dict(result_sha256=sha(path/'RESULT.json'),observed=result['observed'],
        actual_lengths=branch.get('counts'),numeric_redecode_not_yet_performed=True,new_QP=0,new_steps=0))
    return result
def load_branch(path):
    b=load_bank(path/'actual.npz');b.update(load_numeric(path/'controls.json'));return b
