"""One necessary pure group, with a saved result and no numerical experiment."""
import unittest,io
from cavr_wbc.experiments.step50_io import *
def run(repair=None):
    from tests.test_step50_contract import Step50Contract
    out=output()
    if (out/'tests/NECESSARY_TESTS.json').exists() and not repair:raise FileExistsError('pure group already recorded')
    names=unittest.defaultTestLoader.getTestCaseNames(Step50Contract)
    suite=unittest.TestSuite([Step50Contract(n) for n in names if not repair or n.startswith('test_'+str(repair)+'_')])
    stream=io.StringIO();result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    document=dict(tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),output=stream.getvalue(),
        failure_details=[text for _,text in result.failures+result.errors],real_QP_calls=0,MuJoCo_steps=0)
    if repair:
        old=read(out/'tests/NECESSARY_TESTS.json')
        if not (out/'tests/INITIAL_GROUP_RESULT.json').exists():write(out/'tests/INITIAL_GROUP_RESULT.json',old)
        write(out/('tests/AFFECTED_FIXTURE_'+str(repair)+'_REPAIR.json'),document)
        if result.wasSuccessful():
            write(out/'tests/NECESSARY_TESTS.json',dict(tests_run=5,errors=0,failures=0,affected_topic_repaired=repair,
                real_QP_calls=0,MuJoCo_steps=0,initial='INITIAL_GROUP_RESULT.json'))
    else:write(out/'tests/NECESSARY_TESTS.json',document)
    print(stream.getvalue(),flush=True)
    if not result.wasSuccessful():raise SystemExit(1)
if __name__=='__main__':
    import sys
    run(int(sys.argv[1]) if len(sys.argv)>1 else None)
