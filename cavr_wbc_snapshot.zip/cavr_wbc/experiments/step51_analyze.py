"""Fixed S/M_NEG/M_POS endpoints and complete paired denominators."""
from collections import Counter
from cavr_wbc.control.step50_policy import ARMS

def support(rows):return dict(snapshots=len({r['snapshot_id'] for r in rows}),episodes=len({r['episode'] for r in rows}))
def physical_failure(r):
    return bool(r.get('physical_failure_count',0)>0 and any(x!='NUMERICAL_OR_INCOMPLETE_STATE'
        for x in (r.get('first_physical_failure') or {}).get('reasons',[])))
def recovery(rows):
    main=[r for r in rows if r['arm']==ARMS[0]]
    sent=[r for r in main if r.get('selected_command_sent')]
    applied=[r for r in sent if r.get('experimental_applied')]
    complete=[r for r in applied if r.get('phase1_complete')]
    false=[r for r in applied if (r.get('D_0to1_m') or 0)>.006 or
        (physical_failure(r) and (r['first_physical_failure']['time_s']<=1.)) or
        (r.get('phase1_complete') and not r.get('phase1',{}).get('terminal'))]
    unknown=[r for r in main if r.get('dispatched_unknown') or r['status'].startswith('UNKNOWN')]
    partial=[r for r in applied if not r.get('phase1_complete') and r not in false]
    partial+= [r for r in unknown if r not in partial and r not in false]
    successes=[r for r in applied if r.get('phase1_gate_pass') and r.get('mission_success') and r.get('handoff_committed') and r.get('continuity_pass')]
    rejects=Counter(r.get('packet_status','NOT_RUN') for r in main if r.get('actual_governor_call') and not r.get('learner_approved'))
    actions=Counter()
    for r in main:
        for act in r.get('governor_action_rejections',{}).values():
            actions.update(act.get('rejection_reasons') or [])
            dom=act.get('terminal_domain') or {}
            if dom.get('accepted') is False:actions['DOMAIN:'+str(dom.get('reason'))]+=1
    return dict(planned=len(main),actual_decisions=sum(r.get('actual_governor_call',False) for r in main),
        governor_not_dispatched=sum(not r.get('actual_governor_call') for r in main),
        recognized=sum(r.get('learner_approved',False) for r in main),timely_sent=len(sent),applied=len(applied),
        gamma=dict(Counter(str(r.get('gamma')) for r in main if r.get('learner_approved'))),
        complete_1s=len(complete),recovery=sum(r.get('phase1_gate_pass',False) for r in applied),
        false_acceptance=len(false),false_acceptance_ids=[r['id'] for r in false],
        false_acceptance_evaluable_denominator=len(complete),unresolved_1s_partial=len(partial),
        partial_ids=[r['id'] for r in partial],unknown_decision_or_application=len(unknown),model_domain_feasibility_rejections=dict(rejects),action_reasons=dict(actions),
        recognized_late=sum(r.get('learner_approved',False) and r.get('late',False) and not r.get('selected_command_sent') for r in main),
        unrecognized_computation_late=sum(not r.get('learner_approved') and r.get('late',False) for r in main),
        rejected_and_late_overlap_allowed=True,mission_successes=len(successes),mission_support=support(successes),
        mission_ids=[r['id'] for r in successes],all_applied_recoveries_safe_complete=bool(len(applied)==sum(r.get('phase1_gate_pass',False) for r in applied) and not false and not partial))
def group(rows):
    applied=[r for r in rows if r.get('experimental_applied')]
    successes=sum(r.get('mission_success',False) for r in rows)
    return dict(planned=len(rows),applied=len(applied),complete_phase1=sum(r.get('phase1_complete',False) for r in rows),
        recovery_gate_pass=sum(r.get('phase1_gate_pass',False) for r in rows),complete_4s=sum(r.get('complete_2001',False) for r in rows),
        mission_success=successes,success_planned_fraction=f'{successes}/{len(rows)}',success_applied_fraction=f'{successes}/{len(applied)}',
        physical_failure=sum(physical_failure(r) for r in rows),late=sum(r.get('late',False) for r in rows),
        numerical_partial=sum(bool(r.get('dispatched_unknown') or r['status'].startswith('UNKNOWN') or
            (r.get('observed',False) and not r.get('complete_2001') and not r.get('late') and r['status']!='PHASE1_GATE_FAILED')) for r in rows),
        unknown_positions=sum(r.get('dispatched_unknown',False) or r['status'].startswith('UNKNOWN') for r in rows),
        gate_refused=sum(r['status']=='PHASE1_GATE_FAILED' for r in rows),
        full_task_not_completed=sum(bool(r.get('complete_2001') and not r.get('mission_success') and not r.get('late') and not physical_failure(r)) for r in rows),
        unavailable=sum(not r.get('experimental_applied') and not r.get('dispatched_unknown') and not r['status'].startswith('UNKNOWN') for r in rows),
        classifications=dict(Counter(r.get('final_classification',r['status']) for r in rows)))
def endpoints(rows, references=None):
    severe=[r for r in rows if r['health_kind']=='RR_THIGH15']
    neg=[r for r in severe if r['block']=='NEG_CONFIRM'];pos=[r for r in severe if r['block']=='POS_TRANSFER']
    ss={k:recovery(v) for k,v in [('NEG_CONFIRM',neg),('POS_TRANSFER',pos)]}
    missions={}
    for block,label,min_snap,min_ep in [('NEG_CONFIRM','FROZEN_NEGATIVE_CONFIRMATION_OBSERVED',6,4),('POS_TRANSFER','POSITIVE_RR_TRANSFER_OBSERVED',3,2)]:
        s=ss[block];n=s['mission_support']
        missions[block]=dict(status=label if n['snapshots']>=min_snap and n['episodes']>=min_ep and s['all_applied_recoveries_safe_complete'] else 'NOT_ESTABLISHED',
            **n,successes=s['mission_successes'],planned_denominator=s['planned'],timely_sent_denominator=s['timely_sent'],
            success_planned_fraction=f"{s['mission_successes']}/{s['planned']}",ids=s['mission_ids'],
            no_false_or_unresolved_partial=s['false_acceptance']==s['unresolved_1s_partial']==0)
    groups={}
    for block in ('ALL','NEG_CONFIRM','POS_TRANSFER'):
        for arm in ARMS:
            own=[r for r in severe if r['arm']==arm and (block=='ALL' or r['block']==block)]
            groups[block+':RR_THIGH15:'+arm]=group(own)
    for health in ('HEALTHY','RR_THIGH30'):groups['CONTROL:'+health+':NOMINAL_IMMEDIATE']=group([r for r in rows if r['health_kind']==health])
    chain={}
    for direction in (-1,1):
        for tick in (37,39,41):
            own=[r for r in severe if r['direction']==direction and r['tick']==tick and r['arm']==ARMS[0]]
            chain[f'{direction}:T{tick}']=recovery(own)
    by={(r['snapshot_id'],r['arm']):r for r in severe};pairs=[];advantages=[]
    comparisons=[(ARMS[0],ARMS[i]) for i in (1,3,2,4)]+[(ARMS[1],ARMS[2])]
    metrics=['final_goal_error_m','sustained_goal_stop_time_s','external_reference_error_integral_0to4_available_m_s',
        'external_reference_error_integral_1to4_available_m_s','final_half_second_vx_RMS_m_s']
    for source in (r for r in severe if r['arm']==ARMS[0]):
        for a,b in comparisons:
            ra,rb=by[source['snapshot_id'],a],by[source['snapshot_id'],b]
            qualified=all(r.get('complete_2001') and r.get('physical_safe') and r.get('timing_qualified') for r in (ra,rb))
            adv=bool(a==ARMS[0] and ra.get('mission_success') and rb.get('experimental_applied') and rb.get('complete_2001') and rb.get('timing_qualified') and physical_failure(rb))
            p=dict(snapshot_id=source['snapshot_id'],episode=source['episode'],block=source['block'],direction=source['direction'],tick=source['tick'],
                a=a,b=b,a_status=ra['status'],b_status=rb['status'],a_success=ra.get('mission_success'),b_success=rb.get('mission_success'),
                both_complete_safe_timely=qualified,continuous={key:dict(a=ra.get(key),b=rb.get(key),b_minus_a=None if ra.get(key) is None or rb.get(key) is None else rb[key]-ra[key]) for key in metrics} if qualified else None,
                same_gamma=ra.get('gamma')==rb.get('gamma'),physical_safety_advantage=adv,conditional_description_only=True)
            pairs.append(p)
            if adv:
                p={**p,'failure':rb.get('first_physical_failure'),'contact_statistics':rb.get('contact_statistics')};advantages.append(p)
    vg={}
    for direction in (-1,1):
        for comparison in ARMS[1:]:
            own=[p for p in advantages if p['direction']==direction and p['b']==comparison]
            vg[f'{direction}:{comparison}']=dict(**support(own),instances=own,count=len(own),status='OBSERVED' if own else 'NOT_ESTABLISHED')
    return dict(S_RECOVERY=ss,M_NEG=missions['NEG_CONFIRM'],M_POS=missions['POS_TRANSFER'],chains=chain,groups=groups,paired=pairs,
        V=dict(**support(advantages),instances=advantages,by_direction_comparator=vg,union_deduplicated=True),
        planned_independent_episode_sources=12,independent_episode_sources=sum(r['status']=='COMPLETE' for r in references) if references is not None else None,source_generation_incomplete=references is None or sum(r['status']=='COMPLETE' for r in references)<12,no_population_significance_claim=True,deterministic_episodes_not_random_IID=True,
        general_health_fault_disturbance_guarantee='NOT_ESTABLISHED',TypeII_matched_chain_retested=False)
