"""All native, reference, startup, prediction, actual and replay work."""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter
import json
import os
from cavr_wbc.experiments.step47_budget import SprintBudget as SourceBudget, SprintLimit
from cavr_wbc.experiments.step51_io import write, MAX_QP, MAX_STEPS, MAX_WALL_S, MAX_REPLAY_STEPS

class SprintBudget(SourceBudget):
    def __init__(self, out):
        self.out = Path(out)
        self.path = self.out / 'STEP51_LEDGER.jsonl'
        self.stream = self.path.open('x', encoding='utf-8', newline='\n')
        self.buffer = []
        self.qp_calls = self.returned = self.physics_steps = self.reserved = 0
        self.started = self.start_utc = None
        self.qp_kinds = Counter()
        self.step_kinds = Counter()
        self.fit_count = self.dev_recomputations = self.reservation_id = self.risk_fit_count = 0
        self.tokens = {}
        self.persisted_qp_calls = self.persisted_returns = 0
        self.replay_physics_steps = 0

    def start(self):
        if self.started is None:
            self.started = perf_counter()
            self.start_utc = datetime.now(timezone.utc).isoformat()
            self.event('NUMERICAL_STARTED', hard_wall_s=MAX_WALL_S, QP_limit=MAX_QP,
                       step_limit=MAX_STEPS, fit_limit=0, replay_step_limit=MAX_REPLAY_STEPS)

    def check(self):
        if self.started is not None and perf_counter() - self.started >= MAX_WALL_S:
            raise SprintLimit('150-minute numerical hard cap')
        if self.qp_calls >= MAX_QP:
            raise SprintLimit('45000 real QP hard cap')
        if self.physics_steps + self.reserved >= MAX_STEPS:
            raise SprintLimit('500000 integration cap including reservations')

    def reserve_steps(self, kind, owner, n):
        self.start()
        self.check()
        if int(n) != n or n < 0 or self.physics_steps + self.reserved + n > MAX_STEPS:
            raise SprintLimit('prediction/replay reservation exceeds integration cap')
        if kind == 'FROZEN_CONTROL_REPLAY' and n > MAX_REPLAY_STEPS:
            raise SprintLimit('8000 replay integration cap')
        self.reservation_id += 1
        token = self.reservation_id
        self.tokens[token] = (kind, owner, int(n))
        self.reserved += int(n)
        self.event('PREFIX_NATIVE_START', reservation_id=token, kind=kind, owner=owner, reserved_steps=int(n))
        return token

    def finish_steps(self, token, actual_steps):
        kind = self.tokens[token][0]
        super().finish_steps(token, actual_steps)
        if kind == 'FROZEN_CONTROL_REPLAY':
            self.replay_physics_steps += int(actual_steps)
            if self.replay_physics_steps > MAX_REPLAY_STEPS:
                raise ValueError('replay scientific step identity exceeds frozen cap')

    def persist(self, **extra):
        for row in self.buffer:
            self.stream.write(json.dumps(row, sort_keys=True, allow_nan=False) + '\n')
        self.stream.flush()
        os.fsync(self.stream.fileno())
        self.buffer.clear()
        self.persisted_qp_calls = self.qp_calls
        self.persisted_returns = self.returned
        write(self.out / 'PROGRESS.json', {**self.snapshot(), **extra})

    def snapshot(self):
        return {**super().snapshot(), 'hard_wall_s': MAX_WALL_S, 'QP_limit': MAX_QP,
                'physics_step_limit': MAX_STEPS, 'frozen_control_replay_steps': self.replay_physics_steps,
                'new_batch_physics_steps': self.physics_steps - self.replay_physics_steps,
                'frozen_control_replay_QP_calls': 0, 'replay_step_limit': MAX_REPLAY_STEPS}
