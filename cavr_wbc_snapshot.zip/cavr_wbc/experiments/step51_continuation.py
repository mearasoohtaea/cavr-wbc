"""One storage/DLL lifetime continuation of only undispatched STEP51 slots.

The original numerical runtime remains byte-for-byte frozen. This adapter
changes persistence and post-save resource lifetime only; it uses the original
controller, dispatcher, simulator, input order, and inherited budget clock.
"""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter
import argparse
import gc
import importlib
import json
import os
import subprocess
import sys
import traceback
import numpy as np
from cavr_wbc.experiments.step51_io import *
from cavr_wbc.experiments.step51_inputs import episodes, plans, positions, context_for, arm_context, gamma_for
from cavr_wbc.experiments.step51_budget import SprintBudget, SprintLimit
from cavr_wbc.experiments.step51_storage import save_branch, not_run
from cavr_wbc.experiments.step50_sprint import owners_for, missing_packet
from cavr_wbc.experiments.step35_reference import reference_episode
from cavr_wbc.experiments import step17_formal_panel as frozen, step50_sim as sim
from cavr_wbc.control.step50_kernel import nominal_packet, experimental_packet
from cavr_wbc.control.step50_dispatch import first_sent
from cavr_wbc.control.step39_margin import load_bundle
from cavr_wbc.experiments.step47_binding import PolicyDomain
from cavr_wbc.experiments.step51_sprint import exception_result

FIRST_PENDING_ORDINAL = 44
UNKNOWN_ORDINAL = 43

def equivalent(a, b):
    return json.dumps(encode(a), sort_keys=True) == json.dumps(encode(b), sort_keys=True)

def pending_positions(freeze):
    fixed = freeze['positions']
    if not equivalent(fixed, positions()) or not equivalent(freeze['plans'], plans()) or not equivalent(freeze['episodes'], episodes()):
        raise ValueError('continuation cannot change frozen input/order')
    return [p for p in fixed if p['position_ordinal'] >= FIRST_PENDING_ORDINAL]

class ContinuationBudget(SprintBudget):
    @classmethod
    def restore(cls, out, saved):
        if saved['unknown_native_returns'] or saved['uncompleted_native_step_reservations']:
            raise ValueError('cannot conceal unknown native work in continuation')
        if saved['multioutput_estimator_fits'] or saved.get('physical_risk_head_fits', 0):
            raise ValueError('forbidden prior fit')
        self = cls.__new__(cls)
        self.out = Path(out)
        self.path = self.out / 'STEP51_LEDGER.jsonl'
        self.stream = self.path.open('a', encoding='utf-8', newline='\n')
        self.buffer = []
        self.qp_calls = saved['total_QP_calls']; self.returned = saved['QP_returns']
        self.physics_steps = saved['total_physics_steps']; self.reserved = 0
        self.start_utc = saved['numerical_started_utc']
        elapsed = (datetime.now(timezone.utc) - datetime.fromisoformat(self.start_utc)).total_seconds()
        self.started = perf_counter() - elapsed
        self.qp_kinds = Counter(saved['QP_by_kind']); self.step_kinds = Counter(saved['physics_by_kind'])
        self.fit_count = self.dev_recomputations = self.risk_fit_count = 0
        self.tokens = {}; self.reservation_id = 0
        with self.path.open(encoding='utf-8') as stream:
            for line in stream:
                self.reservation_id = max(self.reservation_id, json.loads(line).get('reservation_id', 0))
        self.persisted_qp_calls = self.qp_calls; self.persisted_returns = self.returned
        self.replay_physics_steps = saved.get('frozen_control_replay_steps', 0)
        self.check()
        return self

    def persist(self, **extra):
        for row in self.buffer:
            self.stream.write(json.dumps(row, sort_keys=True, allow_nan=False) + '\n')
        self.stream.flush(); os.fsync(self.stream.fileno()); self.buffer.clear()
        self.persisted_qp_calls = self.qp_calls; self.persisted_returns = self.returned
        write(self.out / 'continuation/PROGRESS.json', {**self.snapshot(), **extra})

def release_owners(owners, evidence_persisted):
    """Close private native caches only after complete branch evidence save."""
    if not evidence_persisted:
        raise ValueError('cannot discard live numerical evidence before persistence')
    seen = set(); solvers = set(); closed = controllers = prefixes = 0
    for owner in owners.values():
        candidates = [getattr(owner, name, None) for name in ('nominal_controller', 'backup_controller')]
        candidates += list(getattr(owner, '_shadow_controllers', {}).values())
        for controller in candidates:
            if controller is None or id(controller) in seen: continue
            seen.add(id(controller)); controllers += 1
            cache = getattr(controller, '_solver_cache', {})
            for row in cache.values():
                solver = row.get('solver')
                if solver is not None and id(solver) not in solvers:
                    solvers.add(id(solver))
                    close = getattr(solver, 'close', None)
                    if callable(close): close(); closed += 1
            cache.clear()
            for name in ('pending_raw_evidence', 'unavailable_evidence', 'solver_ledger'):
                values = getattr(controller, name, None)
                if hasattr(values, 'clear'): values.clear()
            if hasattr(controller, 'solve_callback'): controller.solve_callback = None
        prefix = getattr(owner, 'native_prefix', None)
        if prefix is not None:
            prefix.buffers.clear()
            for handle in getattr(prefix, '_dll_dirs', []): handle.close()
            prefix._dll_dirs = []
            prefixes += 1
        getattr(owner, '_shadow_controllers', {}).clear()
    owners.clear()
    return dict(private_controllers_released=controllers, native_OSQP_closed=closed,
                native_prefix_buffers_released=prefixes, release_after_evidence_persisted=True,
                within_branch_timing_or_controller_semantics_changed=False)

def attempt(out, event, **values):
    append(out / 'continuation/ATTEMPT_LEDGER.jsonl', dict(event=event,
        timestamp_utc=datetime.now(timezone.utc).isoformat(), **values))

def replay_pending(out, budget, module, report_path):
    token = budget.reserve_steps('FROZEN_CONTROL_REPLAY', 'STEP50_UNDISPATCHED_SAVED_CONTROLS', 6000)
    budget.persist(phase='CONTINUATION_REPLAY_START')
    command = [sys.executable, '-B', '-X', 'utf8', '-m', module, '--out', str(out)]
    with (out / 'continuation/replay_process.log').open('x', encoding='utf-8') as stream:
        child = subprocess.Popen(command, cwd=OUTPUT_ROOT_D, stdout=stream, stderr=subprocess.STDOUT)
        try:
            child.wait(timeout=max(.01, MAX_WALL_S - (perf_counter() - budget.started)))
        except subprocess.TimeoutExpired:
            child.kill(); child.wait(); raise SprintLimit('original 150-minute cap during pending replay')
    report = read(out / report_path)
    if report is None:
        budget.event('CONTINUATION_REPLAY_UNKNOWN', unknown_reserved_steps=6000, no_retry=True)
        budget.persist(phase='CONTINUATION_REPLAY_UNKNOWN')
        return
    if report['new_QP_calls'] != 0 or not 0 <= report['actual_steps'] <= 6000:
        raise ValueError('pending replay budget identity')
    budget.finish_steps(token, report['actual_steps'])
    budget.persist(phase='CONTINUATION_REPLAY_SAVED')

def run(persistence_module, replay_module, replay_report):
    out = output(); cont = out / 'continuation'; cont.mkdir(exist_ok=True)
    if (out / 'CONTINUATION_STARTED.json').exists(): raise FileExistsError('single engineering continuation already dispatched')
    test = read(out / 'tests/CONTINUATION_ENGINEERING_TOPIC.json')
    if not test or test['failures'] or test['errors'] or test['tests_run'] != 1:
        raise ValueError('affected pure engineering fixture must pass before continuation')
    freeze = read(out / 'METHOD_INPUT_FREEZE.json')
    pending = pending_positions(freeze)
    old_finish = read(out / 'RUN_FINISHED.json'); old_runtime = read(out / 'RUNTIME_END.json')
    saved_budget = old_finish['budget']
    if len(pending) != 132 or old_finish['saved_positions'] != 43 or old_runtime['branch_positions'] != 44:
        raise ValueError('original position boundary changed')
    if saved_budget['total_QP_calls'] != 5942 or saved_budget['QP_returns'] != 5942 or saved_budget['total_physics_steps'] != 57980:
        raise ValueError('original budget boundary changed')
    for p in freeze['positions']:
        root = out / 'branches' / p['context_id'] / p['arm'] / 'RESULT.json'
        result = read(root)
        if p['position_ordinal'] == UNKNOWN_ORDINAL and result['status'] != 'UNKNOWN':
            raise ValueError('original dispatched UNKNOWN must remain excluded')
        if p['position_ordinal'] >= FIRST_PENDING_ORDINAL and result['status'] != 'NOT_RUN':
            raise ValueError('pending position has already been dispatched')
    if not all(sha(OUTPUT_ROOT_D / p) == digest for p, digest in freeze['runtime_sha256'].items()):
        raise ValueError('original frozen runtime mutated')
    original_receipts = {name: sha(out / name) for name in ('RUN_FINISHED.json', 'INTERRUPTION.json', 'RUNTIME_END.json', 'METHOD_INPUT_FREEZE.json')}
    repairs = [persistence_module.replace('.', '/') + '.py', 'cavr_wbc/experiments/step51_continuation.py', replay_module.replace('.', '/') + '.py']
    transition = dict(original_runtime_sha256=freeze['runtime_sha256'], engineering_modules={p: sha(OUTPUT_ROOT_D / p) for p in repairs},
        original_receipts_sha256=original_receipts, pending_ids=[p['id'] for p in pending],
        excluded_unknown_id=freeze['positions'][UNKNOWN_ORDINAL]['id'], original_clock_utc=saved_budget['numerical_started_utc'],
        original_budget=saved_budget, one_storage_DLL_resource_repair=True, scientific_inputs_policy_evaluation_health_unchanged=True,
        completed_positions_not_recomputed=True, retries=0,
        combined_engineering_repair_components=['saved_control_storage_field_adapter_for_undispatched_replay',
            'SHA256_streaming_identical_bytes', 'private_native_owner_release_after_durable_branch_save'])
    # Digest implementation changes only the allocation strategy, preserving
    # every persisted byte and hash algorithm; implementation supplied by parent.
    importlib.import_module(persistence_module).install()
    write_new(out / 'ONE_ENGINEERING_RESOURCE_CONTINUATION_FREEZE.json', transition)
    contract = read(out / 'STEP48_CAL_FREEZE.json')['methods']['PHASE_MATCHED_TASK']['policy_contract']
    bundle = load_bundle(out / 'models/PHASE_MATCHED_TASK.npz')
    domain = PolicyDomain(read(out / 'models/PHASE_MATCHED_TASK_DOMAIN.json'), sha(out / 'models/PHASE_MATCHED_TASK_DOMAIN.json'))
    if bundle['policy_contract'] != contract or domain.policy_contract != contract: raise ValueError('source policy binding')
    model = frozen.load_model(); budget = ContinuationBudget.restore(out, saved_budget)
    method_sha = sha(out / 'METHOD_INPUT_FREEZE.json'); source_sha = freeze['step50_method_freeze_sha256']
    manifest = freeze['config']; governor_calls = old_runtime['learned_governor_decisions']; reference_calls = old_runtime['reference_attempts']
    branch_calls = old_runtime['branch_positions']; saved = []; active_id = None; status = 'COMPLETED_WITH_PRIOR_UNKNOWN'
    write_new(out / 'CONTINUATION_STARTED.json', dict(pid=os.getpid(), start_utc=datetime.now(timezone.utc).isoformat(),
        numerical_clock_not_reset=True, original_start_utc=budget.start_utc, pending_positions=132, original_UNKNOWN_not_retried=True))
    budget.event('ENGINEERING_CONTINUATION_START', prior_QP=budget.qp_calls, prior_steps=budget.physics_steps)
    budget.persist(phase='CONTINUATION_STARTED')
    try:
        replay_pending(out, budget, replay_module, replay_report)
        pending_ids = {p['id'] for p in pending}
        for ep in freeze['episodes']:
            own = [p for p in freeze['plans'] if p['episode'] == ep['episode_id'] and any(p['context_id'] + ':' + a in pending_ids for a in p['arms'])]
            if not own: continue
            budget.check(); ep_path = out / 'episodes' / (ep['episode_id'] + '.json')
            if ep_path.exists():
                episode = load_numeric(ep_path)
                attempt(out, 'REFERENCE_REUSED_SAVED_FACTS', episode_id=ep['episode_id'], new_QP=0, new_steps=0)
            else:
                if reference_calls >= 12: raise SprintLimit('12 original reference cap')
                reference_calls += 1; attempt(out, 'START', kind='REFERENCE', **ep)
                try:
                    episode = reference_episode(model, manifest['reference_scenario'], ep['displacement_m'], ep['episode_id'],
                        ep['snapshot_ticks'], budget, evidence_callback=budget.record_raw)
                except (FloatingPointError, np.linalg.LinAlgError, RuntimeError) as exc:
                    if isinstance(exc, SprintLimit): raise
                    episode = dict(episode_id=ep['episode_id'], status='UNKNOWN_NUMERICAL_EXCEPTION', snapshots=[], controls=[],
                        reason=dict(type=type(exc).__name__, error=str(exc)), counts=None, no_retry=True,
                        missing_snapshot_ticks=list(ep['snapshot_ticks']))
                for ctrl in episode['controls']: ctrl.pop('raw_solver_result', None)
                save_numeric(ep_path, episode)
                attempt(out, 'RETURN', kind='REFERENCE', episode_id=ep['episode_id'], status=episode['status'], counts=episode['counts'])
            for p in own:
                c = context_for(p, episode, manifest['mapping'])
                save_numeric(cont / 'sources' / c['context_id'] / 'SOURCE_IDENTITY.json', dict(plan=p, context=c))
                for arm in p['arms']:
                    pid = p['context_id'] + ':' + arm
                    if pid not in pending_ids: continue
                    budget.check(); branch_calls += 1
                    if branch_calls > 176: raise ValueError('original branch cap identity')
                    ac = arm_context(c, arm, contract, method_sha, source_sha); gamma = gamma_for(arm)
                    path = cont / 'branches' / c['context_id'] / arm; active_id = pid
                    if ac.get('eligible'):
                        ac['policy_anchor_goal'] = dict(x_anchor_m=float(ac['backup_anchor_q_init'][0]),
                            x_goal_m=float(ac['nominal_q_init'][0]) + float(ac['nominal_d_m']),
                            d_task_m=float(np.clip(float(ac['nominal_q_init'][0]) + float(ac['nominal_d_m']) - float(ac['backup_anchor_q_init'][0]), -.001, .001)))
                    save_numeric(path / 'POLICY_CONTEXT.json', ac)
                    attempt(out, 'START', kind='MISSION', id=pid, arm=arm, health_kind=p['health_kind'], block=p['block'])
                    owners = {}; k = packet = branch = startup = None; persisted = False
                    try:
                        if ac.get('eligible'):
                            owners, startup = owners_for(model, budget, ac, manifest, contract, domain)
                            write_new(path / 'STARTUP.json', startup)
                            if arm == 'GOVERNED_RECOVER_RESUME':
                                if governor_calls >= 32: raise SprintLimit('32 original governor cap')
                                governor_calls += 1; budget.event('GOVERNOR_DECISION_START', id=pid, ordinal=governor_calls)
                                k = owners['GOVERNOR']; packet = k.governor(ac, bundle, .006, budget)
                                budget.event('GOVERNOR_DECISION_RETURN', id=pid, status=packet['status'])
                            elif arm == 'NOMINAL_IMMEDIATE':
                                k = owners['C']; packet = nominal_packet(k, ac, budget)
                            else:
                                k = owners['B' if gamma == 0. else 'MIDDLE']; packet = experimental_packet(k, ac, budget, owners, gamma, arm)
                            k.flush_raw_evidence()
                        else: packet = missing_packet(ac, gamma)
                        save_numeric(path / 'PACKET.json', packet)
                        branch = sim.propagate(k, ac, packet, budget, purpose=arm, require_sent=True) if first_sent(packet, ac) else not_run(packet.get('selected_gamma', gamma), packet['status'])
                        result = save_branch(out, path, branch, ac, packet); persisted = True
                        saved.append(pid)
                        append(cont / 'POSITION_INDEX.jsonl', dict(id=pid, path=relative(path, out), context_id=c['context_id'],
                            arm=arm, episode=p['episode'], snapshot_id=p['snapshot_id'], health_kind=p['health_kind'], block=p['block'], direction=p['direction']))
                        attempt(out, 'RETURN', kind='MISSION', id=pid, status=result['status'], complete=result['complete_2001'], mission_success=result['mission_success'])
                        release = release_owners(owners, persisted)
                        budget.event('POST_PERSISTENCE_OWNER_RELEASE', id=pid, **release)
                        budget.persist(phase='CONTINUATION_BRANCH_SAVED', completed_positions=43 + len(saved), continuation_saved=len(saved),
                            original_UNKNOWN_positions=1, planned_positions=176, id=pid, governor_calls=governor_calls,
                            reference_calls=reference_calls, branch_calls=branch_calls)
                        print(dict(saved=43 + len(saved), prior_UNKNOWN=1, planned=176, id=pid, status=result['status'], mission_success=result['mission_success'], budget=budget.snapshot()), flush=True)
                        active_id = None
                        if result['status'] == 'FAILED_BUDGET': raise SprintLimit('saved partial at original cap')
                    except (FloatingPointError, np.linalg.LinAlgError, RuntimeError) as exc:
                        if isinstance(exc, SprintLimit): raise
                        if persisted: raise
                        result = exception_result(out, path, p, arm, ac, exc)
                        persisted = True; saved.append(pid)
                        attempt(out, 'RETURN', kind='MISSION', id=pid, status=result['status'], complete=False, mission_success=False)
                        release = release_owners(owners, persisted)
                        budget.event('POST_PERSISTENCE_OWNER_RELEASE', id=pid, **release)
                        budget.persist(phase='CONTINUATION_NUMERICAL_EXCEPTION_SAVED', completed_positions=43 + len(saved),
                            continuation_saved=len(saved), original_UNKNOWN_positions=1, planned_positions=176,
                            id=pid, governor_calls=governor_calls, reference_calls=reference_calls, branch_calls=branch_calls)
                        active_id = None
                    finally:
                        # On storage/resource failure stop; no second engineering
                        # continuation and no retry of this dispatched position.
                        if not persisted: owners.clear()
                        k = packet = branch = startup = None
                        gc.collect()
            episode = None; gc.collect()
    except SprintLimit as exc:
        status = 'INCOMPLETE_BUDGET'; write_new(cont / 'INTERRUPTION.json', dict(error=str(exc), active_id=active_id, budget=budget.snapshot()))
    except BaseException as exc:
        status = 'INCOMPLETE_SECOND_RESOURCE_OR_INVALID_SEMANTIC_FAILURE'
        write_new(cont / 'INTERRUPTION.json', dict(type=type(exc).__name__, error=str(exc), active_id=active_id,
            traceback=traceback.format_exc(), budget=budget.snapshot()))
        raise
    finally:
        for p in pending:
            path = cont / 'branches' / p['context_id'] / p['arm'] / 'RESULT.json'
            if not path.exists(): write_new(path, dict(status='UNKNOWN' if p['id'] == active_id else 'NOT_RUN', reason={'reason': status},
                observed=False, evaluation={}, complete_2001=False, mission_success=False, experimental_applied=False, **p))
        unchanged = all(sha(OUTPUT_ROOT_D / p) == digest for p, digest in freeze['runtime_sha256'].items())
        originals = all(sha(out / name) == digest for name, digest in original_receipts.items())
        if not unchanged or not originals: status = 'INVALID_ORIGINAL_RUNTIME_OR_RECEIPT_MUTATION'
        budget.event('CONTINUATION_NUMERICAL_FINISHED', status=status); budget.close()
        write_new(out / 'CONTINUATION_RUNTIME_END.json', dict(original_runtime_sha256_unchanged=unchanged,
            original_receipts_sha256_unchanged=originals, reference_attempts=reference_calls,
            learned_governor_decisions=governor_calls, branch_positions=branch_calls, CAL=0, TRAIN=0, fits=0))
        write_new(out / 'CONTINUATION_FINISHED.json', dict(status=status, saved_positions=43 + len(saved),
            continuation_saved_positions=len(saved), original_UNKNOWN_positions=1, budget=budget.snapshot(),
            finish_utc=datetime.now(timezone.utc).isoformat(), active_id=active_id))

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--persistence-module', required=True)
    p.add_argument('--replay-module', required=True)
    p.add_argument('--replay-report', required=True)
    args = p.parse_args(); run(args.persistence_module, args.replay_module, args.replay_report)
