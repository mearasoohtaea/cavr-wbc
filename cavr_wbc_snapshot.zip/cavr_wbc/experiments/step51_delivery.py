"""One current-run numeric readback; JSON verdict precedes CSV, no solve."""
from datetime import datetime,timezone
from collections import Counter
from pathlib import Path
import csv,json
import numpy as np
from cavr_wbc.experiments.step51_io import *
from cavr_wbc.experiments.step51_persistence import streaming_sha as sha,install
from cavr_wbc.experiments.step51_inputs import positions,episodes
from cavr_wbc.experiments.step50_storage import load_branch
from cavr_wbc.evaluation.step50_actual import evaluate
from cavr_wbc.control.step50_policy import mission_reference
from cavr_wbc.control.step50_policy import internal_plan
from cavr_wbc.control.step50_dispatch import first_sent
def same(a,b):return json.dumps(encode(a),sort_keys=True)==json.dumps(encode(b),sort_keys=True)
def deliver():
    install()
    out=output()
    if not (out/'RUN_FINISHED.json').exists():raise ValueError('numerical process not finished')
    if (out/'READBACK_VERDICT.json').exists():raise FileExistsError('one readback already completed')
    write(out/'READBACK_STARTED.json',dict(start_utc=datetime.now(timezone.utc).isoformat(),scope='CURRENT_STEP51_ONLY',new_QP=0,new_steps=0))
    from cavr_wbc.experiments.step51_analyze import endpoints
    rows=[];latency=[];issues=[];series=[];used_raw=set()
    for pos in positions():
        path=out/'branches'/pos['context_id']/pos['arm']
        continued=out/'continuation/branches'/pos['context_id']/pos['arm']
        if (continued/'RESULT.json').exists():path=continued
        r=read(path/'RESULT.json')
        local=[];row={**pos,**{k:v for k,v in r.items() if k not in ('capacity','artifact','controls_numeric','evaluation')}}
        row.update(r.get('evaluation',{}));row['phase1_complete']=row.get('phase1',{}).get('complete',False)
        if r['status'].startswith('UNKNOWN'):
            row['dispatched_unknown']=True;row['experimental_applied']=None
            row['orphan_evidence_preserved']={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in path.glob('*') if p.name in ('actual.npz','controls.json','controls.npz')}
        row['phase1_gate_pass']=row.get('phase1',{}).get('pass',False)
        row['forced_recovery_gate']=internal_plan(pos['arm'])!='IMMEDIATE_MISSION'
        row['handoff_committed']=bool(r.get('handoff') and r['handoff'].get('staging_committed'))
        row['continuity_pass']=bool(r.get('continuity_start')==r.get('continuity_end') and r.get('continuity_start') is not None)
        reason=(r.get('reason') or {}).get('reason','')
        row['late']=bool('DEADLINE'in reason or 'LATE'in reason or
            (r.get('first_packet_prepared_ms') is not None and r['first_packet_prepared_ms']>17) or
            (r.get('first_packet_ready_ms') is not None and r['first_packet_ready_ms']>20))
        row['capacity_first_99_s']=r.get('capacity',{}).get('first_actual_99percent_s')
        packet_path=path/'PACKET.json'
        if packet_path.exists():
            packet=load_numeric(packet_path);c=load_numeric(path/'POLICY_CONTEXT.json')
            sent=first_sent(packet,c)
            row['actual_governor_call']=packet.get('dispatch_kind')=='LEARNED_GOVERNOR' and packet['status']!='SOURCE_INELIGIBLE'
            row['governor_action_rejections']={g:{k:e.get(k) for k in ('evaluation_status','rejection_reasons','terminal_domain','cal_physical_consensus')}
                for g,e in packet.get('actions',{}).items()}
            for key in ('model_authorized','learner_approved','governor_selected','selected_command_sent','nominal_sent'):
                if row.get('dispatched_unknown'):
                    row[key]=bool(packet.get(key))
                elif bool(r.get(key))!=bool(packet.get(key)):local.append('actual authorization field '+key)
            if row.get('dispatched_unknown'):
                row['first_packet_ready_ms']=packet.get('command_ready_ms')
                row['first_packet_prepared_ms']=packet.get('prepared_commit_ms')
            if r.get('observed') and not sent:local.append('uncommitted first packet propagated')
            if c['step48_method_freeze_sha256']!=OLD_METHOD_SHA or c['policy_contract']!=read(out/'STEP48_CAL_FREEZE.json')['methods']['PHASE_MATCHED_TASK']['policy_contract']:
                local.append('frozen TASK binding changed')
            if packet['policy_version']!='TASK_AWARE_1MM_06S_V1':local.append('source policy version replaced by composite')
        if r.get('observed'):
            c=load_numeric(path/'POLICY_CONTEXT.json');packet=load_numeric(path/'PACKET.json');branch=load_branch(path)
            lab=evaluate(branch,c,packet)
            if not same(lab,r['evaluation']):local.append('frozen evaluation mismatch')
            if sha(path/'actual.npz')!=r['artifact']['sha256']:local.append('fact bank SHA mismatch')
            if not same(branch['phase1_online_summary'],lab['phase1']):local.append('online phase1 gate mismatch')
            if branch['continuity_start']!=branch['continuity_end']:local.append('owner/plant/PID continuity mismatch')
            if not branch.get('application_identity_pass'):local.append('application state identity mismatch')
            h=r.get('handoff')
            if h:
                if h['logical_slot']!=49 or abs(h['physical_time_s']-1.)>1e-9 or abs(h['physical_time_after_transaction_s']-1.)>1e-9:local.append('handoff physical/logical clock mismatch')
                if h.get('gate') and not same(h['gate'],lab['phase1']):local.append('handoff prefix gate mismatch')
                if (not h['gate_accepted'] or h['late']) and (h['new_feedback_QP_calls']!=0 or h['staging_committed']):local.append('gate rejected/late but numerical dispatch occurred')
            dense=([branch['initial_fact']] if branch.get('initial_fact') else [])+branch['physics_trajectory']
            continuous=[]
            goal=float(c['nominal_q_init'][0])+float(c['nominal_d_m']);anchor=float(c['backup_anchor_q_init'][0])
            for f in dense:
                if 'qpos'in f:continuous.append(dict(time_s=f['time_s'],physics_step=f['physics_step'],
                    base_x_m=f['qpos'][0],vx_m_s=f['qvel'][0],goal_m=goal,anchor_m=anchor,
                    signed_D_m=c['direction']*(f['qpos'][0]-anchor),goal_error_m=f['qpos'][0]-goal))
            series.append(dict(id=pos['id'],snapshot_id=pos['snapshot_id'],episode=pos['episode'],tick=pos['tick'],
                health_kind=pos['health_kind'],arm=pos['arm'],status=r['status'],complete=r['complete_2001'],goal_m=goal,anchor_m=anchor,series=continuous))
            if len(branch['checkpoints'])!=(len(dense)+24)//25:local.append('long/partial landmark grid mismatch')
            latency.append(dict(id=pos['id'],arm=pos['arm'],health_kind=pos['health_kind'],slot=1,kind='FIRST',
                complete_ms=packet['command_ready_ms'],prepared_ms=packet['prepared_commit_ms'],applied=r['experimental_applied'],callback_ms=None))
            for ctrl in branch['controls']:
                if ctrl['slot']<=1:continue
                t=ctrl.get('timing',{});ref=ctrl.get('backup_reference')
                applied=ctrl.get('tau_applied') is not None
                prep=(ctrl.get('prepare_callback') or {})
                physical_time=ctrl['slot']*.02
                if applied:
                    plan=internal_plan(pos['arm'])
                    active=(plan=='IMMEDIATE_MISSION' and physical_time>=.04) or (plan in ('MIDDLE_RECOVER_RESUME','B_RECOVER_RESUME') and physical_time>=1.)
                    expected=mission_reference(anchor,goal,plan,physical_time,active)
                    if ref is None or any(abs(float(ref[k])-float(expected[k]))>1e-12 for k in ('p_ref_m','v_ref_m_s','a_ref_m_s2')):local.append('actual reference mismatch slot '+str(ctrl['slot']))
                    if ctrl['slot']-1!=ctrl['backup_feedback_logical_slot']:local.append('feedback logical slot reset')
                    if physical_time>=1. and expected['phase_policy_id']!='TASK_AWARE_1MM_06S_V1' and ctrl.get('phase_policy_id')!=expected['phase_policy_id']:local.append('phase2 mislabelled old policy')
                latency.append(dict(id=pos['id'],arm=pos['arm'],health_kind=pos['health_kind'],slot=ctrl['slot'],
                    kind='HANDOFF' if ctrl['slot']==50 else 'FEEDBACK',complete_ms=ctrl['command_ready_ms'],
                    prepared_ms=t.get('prepared_commit_ms'),applied=applied,callback_ms=prep.get('callback_ms'),
                    native_QP_limit_s=ctrl.get('native_QP_limit_s')))
                if ctrl.get('raw_solver_evidence'):used_raw.add(ctrl['raw_solver_evidence'])
            del branch,packet,c,dense
        else:
            row['late']=row['late'] or reason=='EXPERIMENT_LATE_UNAPPLIED'
            latency.append(dict(id=pos['id'],arm=pos['arm'],health_kind=pos['health_kind'],slot=1,kind='FIRST',
                complete_ms=r.get('first_packet_ready_ms'),prepared_ms=r.get('first_packet_prepared_ms'),applied=False,callback_ms=None))
        row['last_available_is_not_filled']=True;rows.append(row)
        write(path/'READBACK_RECEIPT.json',dict(status='MATCH' if not local else 'MISMATCH',issues=local,
            verdict_before_CSV=True,current_bank_only=True,new_QP=0,new_steps=0))
        issues.extend([pos['id']+': '+q for q in local])
    # All current raw numerical shards are decoded exactly once; never solved.
    starts=set();returns=set();return_rows={}
    with (out/'STEP51_LEDGER.jsonl').open(encoding='utf-8') as stream:
        for line in stream:
            r=json.loads(line)
            if r['event']=='QP_START':starts.add(r['global_qp_index'])
            elif r['event']=='QP_RETURN':
                returns.add(r['global_qp_index']);return_rows[r['global_qp_index']]={'solver_owner_id':r.get('solver_owner_id')}
    raw=[]
    def raw_events():
        with (out/'STEP51_LEDGER.jsonl').open(encoding='utf-8') as stream:
            for line in stream:
                event=json.loads(line)
                if event['event']=='RAW_QP_SAVED':yield event
    for event in raw_events():
        p=out/event['path']
        if sha(p)!=event['json_sha256'] or sha(p.with_suffix('.npz'))!=event['npz_sha256']:issues.append('raw hash mismatch '+event['path'])
        record=load_numeric(p);ix=record['global_qp_index'];q=record['raw_result'];raw.append(ix)
        if ix not in returns or q.get('solver_owner_id')!=return_rows[ix].get('solver_owner_id'):issues.append('raw ledger identity '+str(ix))
    finish=read(out/'NUMERICAL_COMPLETION_WITH_CONTINUATION.json',read(out/'RUN_FINISHED.json'));baseline=read(out/'SOURCE_READONLY_BASELINE.json')
    source_ok=sha(SOURCE_ROOT_D/'.git/index')==baseline['source_index_sha256'] and all(
        sha(SOURCE_RUN/rel)==value and sha(out/('source_step50/'+rel if rel in ('METHOD_INPUT_FREEZE.json','PROTOCOL_AND_MANIFEST.json') else rel))==value
        for rel,value in baseline['assets'].items())
    if not source_ok:issues.append('source metadata changed')
    if starts!=returns or starts!=set(raw) or len(raw)!=len(starts):issues.append('START/RETURN/raw ledger completeness')
    if any(not (out/rel).exists() for rel in used_raw):issues.append('actual control raw reference missing')
    if len(rows)!=176 or len({r['id'] for r in rows})!=176:issues.append('planned position completeness')
    if finish['budget']['total_QP_calls']>45000 or finish['budget']['total_physics_steps']>500000:issues.append('hard budget exceeded')
    if not read(out/'RUNTIME_END.json')['runtime_sha256_unchanged']:issues.append('frozen runtime mutation')
    refs=[]
    for ep in episodes():
        p=out/'episodes'/(ep['episode_id']+'.json')
        if p.exists():
            v=load_numeric(p);refs.append(dict(episode_id=ep['episode_id'],status=v['status'],counts=v.get('counts'),missing_snapshot_ticks=v.get('missing_snapshot_ticks',ep['snapshot_ticks'])))
        else:refs.append(dict(episode_id=ep['episode_id'],status='NOT_RUN'))
    result=dict(run_id=RUN_ID,run_status=finish['status'],planned_positions=176,rows=len(rows),references=refs,
        observed=sum(r.get('observed',False) for r in rows),complete_4s=sum(r['complete_2001'] for r in rows),
        mission_success=sum(r['mission_success'] for r in rows),endpoints=endpoints(rows,refs),
        budget=finish['budget'],source_unchanged=source_ok,issues=issues,
        status='INVALID_READBACK' if issues else 'FROZEN_BIDIRECTIONAL_CONFIRMATION_COMPLETED' if finish['status']=='COMPLETED' else 'INCOMPLETE',
        no_new_CAL_TRAIN_fits=True,independent_numerical_reproduction=False,replay=read(out/'replay_continuation/REPLAY_RESULT.json',read(out/'replay/REPLAY_RESULT.json')),MaterialPassport='UNVERIFIED',
        authorization_scope='RECOVERY_1S_ONLY',old_CAL_certifies_mission=False)
    replay_rows=(result.get('replay') or {}).get('rows',[])
    result['frozen_control_replay_complete']=len(replay_rows)==4 and all(r['status'] not in ('UNKNOWN','NOT_RUN') for r in replay_rows)
    if not issues and finish['status']=='COMPLETED' and not result['frozen_control_replay_complete']:
        result['status']='MAIN_BATCH_COMPLETED_REPLAY_INCOMPLETE'
    write(out/'BRANCH_ROWS.json',rows);write(out/'LATENCY.json',latency);write(out/'TRAJECTORY_SERIES.json',series)
    write(out/'STEP51_RESULT.json',result)
    write(out/'RESULT.json',result)
    write(out/'READBACK_VERDICT.json',dict(status='MATCH' if not issues else 'MISMATCH',issues=issues,
        branches=len(rows),decoded_fact_banks=sum(r.get('observed',False) for r in rows),decoded_raw_QP=len(raw),
        actual_evaluation_frozen=True,new_QP=0,new_steps=0,independent_numerical_reproduction=False,
        preserved_UNKNOWN_positions=sum(r.get('dispatched_unknown',False) for r in rows),
        timestamp_utc=datetime.now(timezone.utc).isoformat()))
    # Only scalar table columns; JSON adjudication is already durable.
    fields=['id','block','direction','episode','snapshot_id','tick','health_kind','arm','status','experimental_applied','complete_2001',
        'phase1_complete','phase1_gate_pass','forced_recovery_gate','handoff_committed','continuity_pass','mission_success',
        'physical_safe','timing_qualified','late','final_goal_error_m','final_vx_m_s','final_half_second_vx_RMS_m_s',
        'D_0to1_m','D_0to4_available_m','external_reference_error_integral_0to4_available_m_s',
        'external_reference_error_integral_1to4_available_m_s','sustained_goal_stop_time_s','capacity_first_99_s',
        'min_friction_margin_n','min_command_torque_margin_nm','min_applied_torque_margin_nm','physical_failure_count']
    with (out/'BRANCH_ROWS.csv').open('w',encoding='utf-8',newline='') as stream:
        w=csv.DictWriter(stream,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)
    print(dict(status=result['status'],complete_4s=result['complete_4s'],mission_success=result['mission_success'],issues=len(issues),endpoints={k:result['endpoints'][k] for k in ('S_RECOVERY','M_NEG','M_POS','V')}),flush=True)
if __name__=='__main__':deliver()


