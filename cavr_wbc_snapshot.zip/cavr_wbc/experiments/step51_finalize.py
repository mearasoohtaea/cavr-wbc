"""Static delivery/provenance and byte manifest; no second scientific readback."""
import ast,json,os,subprocess
from cavr_wbc.experiments.step51_io import *
from cavr_wbc.experiments.step51_persistence import streaming_sha as sha

def git(root,*args):
    env=dict(os.environ)
    for key in ('GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_COMMON_DIR'):env.pop(key,None)
    env['GIT_OPTIONAL_LOCKS']='0'
    return subprocess.check_output(['git','-C',str(root),*args],env=env,text=True,encoding='utf-8').strip()

def include_evidence(p,out):
    rel=p.relative_to(out);parts=rel.parts
    if len(parts)==1:return p.name not in ('EVIDENCE_MANIFEST.json','DELIVERY_MANIFEST.json')
    if parts[0] in ('figures','models','source_step50','tests','summary_before_corrections'):return True
    if parts[0] in ('replay','replay_continuation'):
        return p.suffix=='.json' and not (p.stem.endswith('_DENSE') or p.stem.endswith('_INPUT'))
    if 'branches' in parts:
        return p.name in ('RESULT.json','READBACK_RECEIPT.json','INCREMENTAL_RECEIPT.json','BRANCH_STARTED.json','STARTUP.json','ATTEMPT.json','STARTED.json')
    if parts[0]=='continuation' and len(parts)==2:return p.suffix in ('.json','.jsonl','.log')
    return False

def run():
    out=output();base=read(out/'SOURCE_READONLY_BASELINE.json');issues=[]
    files=sorted(OUTPUT_ROOT_D.glob('cavr_wbc/experiments/step51*.py'))+sorted(OUTPUT_ROOT_D.glob('tests/test_step51*.py'))
    for p in files:ast.parse(p.read_text(encoding='utf-8-sig'))
    source_head=git(SOURCE_ROOT_D,'rev-parse','HEAD');source_index=sha(SOURCE_ROOT_D/'.git/index')
    source_status=git(SOURCE_ROOT_D,'status','--porcelain=v1')
    if source_head!=SOURCE_COMMIT or source_index!=base['source_index_sha256'] or source_status:issues.append('source Git/index changed')
    if sha(NATIVE_DLL)!=base['native_sha256']:issues.append('native changed')
    for rel,digest in base['assets'].items():
        dst=out/('source_step50/'+rel if rel in ('METHOD_INPUT_FREEZE.json','PROTOCOL_AND_MANIFEST.json') else rel)
        if sha(SOURCE_RUN/rel)!=digest or sha(dst)!=digest:issues.append('source/copy asset '+rel)
    for rel,digest in base['plant_asset_hashes'].items():
        if sha(OUTPUT_ROOT_D/rel)!=digest:issues.append('plant asset '+rel)
    end=read(out/'CONTINUATION_RUNTIME_END.json');original=read(out/'RUNTIME_END.json')
    if not all((original['runtime_sha256_unchanged'],end['original_runtime_sha256_unchanged'],end['original_receipts_sha256_unchanged'])):issues.append('frozen runtime/receipts changed')
    freeze=read(out/'METHOD_INPUT_FREEZE.json');continuation=read(out/'ONE_ENGINEERING_RESOURCE_CONTINUATION_FREEZE.json')
    runtime_checks={rel:sha(OUTPUT_ROOT_D/rel)==digest for rel,digest in freeze['runtime_sha256'].items()}
    engineering_checks={rel:sha(OUTPUT_ROOT_D/rel)==digest for rel,digest in continuation['engineering_modules'].items()}
    if not all(runtime_checks.values()) or not all(engineering_checks.values()):issues.append('current frozen code SHA mismatch')
    result=read(out/'RESULT.json');rows=read(out/'BRANCH_ROWS.json');finish=read(out/'NUMERICAL_COMPLETION_WITH_CONTINUATION.json')
    if len(rows)!=176 or len({r['id'] for r in rows})!=176:issues.append('position summaries incomplete')
    if sum(r['status']=='COMPLETE' for r in result['references'])!=result['endpoints']['independent_episode_sources']:issues.append('actual reference count mismatch')
    if not finish['no_further_numeric_work_authorized_in_this_run'] or finish['engineering_continuations_used']!=1:issues.append('stop scope mismatch')
    branches=[]
    for r in rows:
        p=out/'continuation/branches'/r['context_id']/r['arm']/'RESULT.json'
        if not p.exists():p=out/'branches'/r['context_id']/r['arm']/'RESULT.json'
        saved=read(p);branches.append(dict(id=r['id'],selected_result=relative(p,out),status=saved['status'],
            dispatched_unknown=bool(r.get('dispatched_unknown')),artifact=saved.get('artifact'),
            controls_numeric=saved.get('controls_numeric'),orphan_evidence=r.get('orphan_evidence_preserved')))
    # Reuse durable raw hashes; no decoding or re-solving these shards.
    raw=[];known={}
    with (out/'STEP51_LEDGER.jsonl').open(encoding='utf-8') as stream:
        for line in stream:
            q=json.loads(line)
            if q['event']=='RAW_QP_SAVED':
                raw.append({k:q[k] for k in ('global_qp_index','path','json_sha256','npz_sha256') if k in q})
                known[q['path']]=q['json_sha256'];known[str(Path(q['path']).with_suffix('.npz')).replace('\\','/')]=q['npz_sha256']
    if len(raw)!=finish['budget']['total_QP_calls']:issues.append('raw ledger count mismatch')
    qa=read(out/'figures/EXPORT_QA.json');visual=read(out/'figures/VISUAL_REVIEW.json');readback=read(out/'READBACK_VERDICT.json')
    if not visual or not visual.get('passed'):issues.append('figure visual QA incomplete')
    if not qa or len(qa)!=2 or any(any(e[0]=='FAIL' for e in c['issues']) for q in qa for c in q['compliance']) or any(not q.get('font_embedding_verified') for q in (qa or [])):issues.append('figure export QA missing/failed')
    entries=[]
    for p in sorted(out.rglob('*')):
        if not p.is_file() or p.name in ('EVIDENCE_MANIFEST.json','DELIVERY_MANIFEST.json'):continue
        rel=relative(p,out).replace('\\','/')
        entries.append(dict(path=rel,size_bytes=p.stat().st_size,sha256=known.get(rel) or sha(p),
            hash_source='durable_raw_ledger' if rel in known else 'streaming_byte_manifest',
            commit_scope='SCOPED_COMMIT' if include_evidence(p,out) else 'LOCAL_LARGE_EVIDENCE'))
    excluded=[q for q in entries if q['commit_scope']=='LOCAL_LARGE_EVIDENCE']
    write(out/'EVIDENCE_MANIFEST.json',dict(output_root=str(out),source_commit=SOURCE_COMMIT,
        selected_branches=branches,raw_QP=raw,files=entries,full_large_evidence_preserved=True,
        locally_preserved_large_files=len(excluded),locally_preserved_large_bytes=sum(q['size_bytes'] for q in excluded),
        committed_summaries_and_figures_only=True,numeric_readback='READBACK_VERDICT.json',
        replay='replay_continuation/REPLAY_RESULT.json',original_replay='replay/REPLAY_RESULT.json',
        new_QP=0,new_steps=0,numeric_bank_decodes=0,readback_repetitions=0))
    outputs=[dict(path=relative(p,out),size_bytes=p.stat().st_size) for p in out.rglob('*') if p.is_file() and p.name!='DELIVERY_MANIFEST.json']
    write(out/'DELIVERY_MANIFEST.json',dict(branch=git(OUTPUT_ROOT_D,'branch','--show-current'),parent_commit=git(OUTPUT_ROOT_D,'rev-parse','HEAD'),
        source_head=source_head,source_index_sha256=source_index,source_status=source_status,source_unchanged=not source_status and source_index==base['source_index_sha256'],
        runtime_unchanged=end,current_frozen_code_SHA_matches=runtime_checks,engineering_code_SHA_matches=engineering_checks,new_code_files=[relative(p,OUTPUT_ROOT_D) for p in files],protocol='configs/validation/STEP51_PROTOCOL.md',
        static_AST_files=len(files),readback=readback,tests=read(out/'tests/NECESSARY_TESTS.json'),
        interpreter='E:/CAVR-WBC/_runtime_step30/python311/python.exe',figure_export_QA=qa,visual_review=visual,
        output_files=outputs,output_size_bytes=sum(p['size_bytes'] for p in outputs),issues=issues,
        numerical_status=result['status'],completion=finish,local_scoped_commit_only=True,push=False,
        large_evidence_policy='Preserved locally by explicit paths/SHA; no whole artifact recursive git add',
        robot_motion_algorithm_project_accessed=False,new_QP=0,new_steps=0,numeric_bank_decodes=0))
    print(dict(static_files=len(files),output_files=len(outputs),bytes=sum(p['size_bytes'] for p in outputs),source_unchanged=not issues,issues=issues),flush=True)
    if issues:raise ValueError(str(issues))
if __name__=='__main__':run()
