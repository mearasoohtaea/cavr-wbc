"""Fixed bidirectional episodes, severe rotations, and tick41 controls."""
from copy import deepcopy
from cavr_wbc.control.step50_policy import ARMS, internal_plan
from cavr_wbc.experiments.step46_inputs import context_for as source_context
from cavr_wbc.experiments.step51_io import OLD_METHOD_SHA

NEG_TARGETS_M = (-.0621875, -.0630625, -.0639375, -.0648125,
                 -.0656875, -.0665625, -.0674375, -.0683125)
POS_TARGETS_M = (.062625, .064375, .066125, .067875)
NEG_TICKS = (37, 39, 41)
POS_TICKS = (39, 41)

def episodes():
    return [dict(episode_id=f'T51_{short}_{i}', episode_ordinal=n,
                 block_episode_ordinal=i, block=block, displacement_m=d,
                 direction=1 if d > 0 else -1, snapshot_ticks=list(ticks))
            for block, short, ds, ticks, start in (
                ('NEG_CONFIRM', 'NEG', NEG_TARGETS_M, NEG_TICKS, 0),
                ('POS_TRANSFER', 'POS', POS_TARGETS_M, POS_TICKS, 8))
            for i, d in enumerate(ds) for n in (start + i,)]

def plans():
    rows = []
    severe_ordinal = 0
    for ep in episodes():
        for tick in ep['snapshot_ticks']:
            snap = ep['episode_id'] + f'_T{tick:03d}'
            controls = ('HEALTHY', 'RR_THIGH30') if ep['episode_ordinal'] % 2 == 0 else ('RR_THIGH30', 'HEALTHY')
            kinds = ('RR_THIGH15',) + (controls if ep['block'] == 'NEG_CONFIRM' and tick == 41 else ())
            for kind in kinds:
                severe = kind == 'RR_THIGH15'
                rotation = severe_ordinal % len(ARMS)
                cid = snap + '_' + kind
                rows.append(dict(**ep, episode=ep['episode_id'], tick=tick, source_tick=tick,
                    snapshot_id=snap, source_snapshot=snap, context_id=cid, case_id=cid,
                    source_state_id=cid, ordinal=len(rows), source_ordinal=severe_ordinal,
                    severe_ordinal=severe_ordinal if severe else None,
                    health_kind=kind, role='healthy' if kind == 'HEALTHY' else 'thigh',
                    fault_leg='NONE' if kind == 'HEALTHY' else 'RR',
                    health=1. if kind == 'HEALTHY' else .15 if severe else .30,
                    split='DEV', source_split='STEP51_FRESH_' + ep['block'], gap_m=.006,
                    severe=severe, arms=list(ARMS[rotation:] + ARMS[:rotation]) if severe else ['NOMINAL_IMMEDIATE'],
                    governor_planned=severe))
                severe_ordinal += int(severe)
    return rows

def gamma_for(arm):
    return None if arm == ARMS[0] else 0. if arm == 'B_RECOVER_RESUME' else 1. if arm == 'NOMINAL_IMMEDIATE' else .5

def positions():
    return [dict(id=p['context_id'] + ':' + a, context_id=p['context_id'], snapshot_id=p['snapshot_id'],
                 episode=p['episode'], block=p['block'], direction=p['direction'], tick=p['tick'],
                 health_kind=p['health_kind'], arm=a, severe=p['severe'], gamma=gamma_for(a),
                 position_ordinal=i)
            for i, (p, a) in enumerate((p, a) for p in plans() for a in p['arms'])]

def context_for(p, ep, mapping):
    c = source_context(p, ep, mapping)
    c.update(backup_id='STEP51-' + p['context_id'], group='STEP51_FIXED_' + p['block'])
    if c.get('previous_command_identity', {}).get('available'):
        c['previous_command_identity']['source'] = 'NEW_STEP51_REFERENCE'
    if c['direction'] != (1 if c['displacement_m'] > 0 else -1):
        raise ValueError('STEP51 direction must follow signed displacement')
    return c

def arm_context(c, arm, contract, new_sha, source_step50_sha):
    v = deepcopy(c)
    v.update(backup_id=c['backup_id'] + ':' + arm, external_arm=arm,
        experimental_arm=internal_plan(arm), method='TASK_MATCHED', comparison_arm='PHASE_MATCHED_TASK',
        policy_contract=deepcopy(contract), step48_method_freeze_sha256=OLD_METHOD_SHA,
        step50_method_freeze_sha256=source_step50_sha, step51_method_freeze_sha256=new_sha,
        authorization_scope='RECOVERY_1S_ONLY', old_CAL_certifies_mission=False)
    return v
