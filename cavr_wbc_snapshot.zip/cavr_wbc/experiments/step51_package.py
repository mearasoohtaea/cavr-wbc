"""Evidence-led Chinese report, protocol states and T-RO claim table."""
from cavr_wbc.experiments.step51_io import *
from cavr_wbc.control.step50_policy import ARMS

def run():
    out=output();result=read(out/'RESULT.json');ep=result['endpoints'];rows=read(out/'BRANCH_ROWS.json');budget=result['budget']
    finish=read(out/'NUMERICAL_COMPLETION_WITH_CONTINUATION.json');actual_refs=sum(r['status']=='COMPLETE' for r in result['references'])
    replay=result.get('replay') or dict(status='UNKNOWN',rows=[],actual_steps=None)
    status=PROTOCOL.read_text(encoding='utf-8').split('```ini')[1].split('```')[0].strip()
    status+='\nSTEP51_RUN_STATUS = '+result['run_status']+'\nSTEP51_READBACK_STATUS = '+read(out/'READBACK_VERDICT.json')['status']
    status+='\nSTEP51_M_NEG = '+ep['M_NEG']['status']+'\nSTEP51_M_POS = '+ep['M_POS']['status']
    status+='\nSTEP51_REFERENCE_EPISODES_GENERATED = '+str(actual_refs)+'\nSTEP51_SAVED_POSITIONS = 52\nSTEP51_OBSERVED_TRAJECTORIES = 40\nSTEP51_UNKNOWN_POSITIONS = 2\nSTEP51_UNDISPATCHED_POSITIONS = 122\nSTEP51_ENGINEERING_CONTINUATIONS_USED = 1\nSTEP51_NUMERICAL_WORK_STOPPED = TRUE\nSTEP51_POSITIVE_TRANSFER_TESTED = FALSE'
    status+='\nSTEP51_FROZEN_CONTROL_REPLAY = '+replay['status']+'\n'
    (out/'PROTOCOL_STATUS.ini').write_text(status,encoding='utf-8')
    summary=[]
    for block,key in [('NEG_CONFIRM','M_NEG'),('POS_TRANSFER','M_POS')]:
        s=ep['S_RECOVERY'][block];m=ep[key]
        summary.append(f"- {block}：认可 {s['recognized']}/{s['planned']}（实际决定 {s['actual_decisions']}、未派发 {s['governor_not_dispatched']}），及时发送 {s['timely_sent']}，实际施加 {s['applied']}，完整 1 s {s['complete_1s']}，恢复通过 {s['recovery']}；4 s 任务成功 {m['success_planned_fraction']}，来源 {m['snapshots']} snapshot / {m['episodes']} episode；终点 `{m['status']}`。错受 {s['false_acceptance']}，完整可评价认可恢复分母 {s['false_acceptance_evaluable_denominator']}；未决 partial {s['unresolved_1s_partial']}。")
    table=['|分组 / 方法|计划|实际首包|完整4s|任务成功|物理失败|late|partial/UNKNOWN|gate拒收|任务未达|无动作|',
        '|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
    for k,g in ep['groups'].items():
        table.append('|'+k+'|'+ '|'.join(str(g[x]) for x in ('planned','applied','complete_4s','mission_success','physical_failure','late','numerical_partial','gate_refused','full_task_not_completed','unavailable'))+'|')
    main_table=['|source|方向/tick|γ|实际决定|认可|发送|1s完整|恢复|handoff|4s完整|任务成功|status|',
        '|---|---|---:|---|---|---|---|---|---|---|---|']
    for r in rows:
        if r['arm']==ARMS[0]:main_table.append('|'+r['snapshot_id']+f"|{r['direction']:+d}/{r['tick']}|"+str(r.get('gamma'))+'|'+('YES' if r.get('actual_governor_call') else 'NOT_DISPATCHED')+'|'+
            '|'.join('UNKNOWN' if r.get('dispatched_unknown') else '—' if not r.get('actual_governor_call') else str(bool(r.get(k))) for k in ('learner_approved','selected_command_sent','phase1_complete','phase1_gate_pass','handoff_committed','complete_2001','mission_success'))+'|'+r['status']+'|')
    replay_table=['|保存控制位置|数值status|新积分|首个差异|物理gate同分类|首次contact同事件|',
        '|---|---|---:|---|---|---|']
    for r in replay['rows']:
        replay_table.append('|'+r['context_id']+'/'+r['arm']+'|'+r['status']+'|'+str(r['actual_steps'])+'|'+str(r.get('first_difference',r.get('missing_fields',r.get('error'))))+'|'+str(r.get('physical_gate_classification_match'))+'|'+str(r.get('first_contact_event_match'))+'|')
    claims=['|T-RO evidence / claim|真实status / 计数|证据定位|允许的边界|','|---|---|---|---|']
    for block,s in ep['S_RECOVERY'].items():claims.append(f"|S {block}|认可/发送/恢复={s['recognized']}/{s['timely_sent']}/{s['recovery']}；错受={s['false_acceptance']}/{s['false_acceptance_evaluable_denominator']}|RESULT.json endpoints.S_RECOVERY.{block}|{'全组未执行；无可评价认可恢复' if not s['actual_decisions'] else '认可恢复的已观察质量；不声称零风险'}|")
    for key in ('M_NEG','M_POS'):
        m=ep[key];claims.append(f"|{key}|{m['status']}；{m['success_planned_fraction']}；{m['snapshots']}/{m['episodes']}来源|RESULT.json endpoints.{key}|{'全组未执行；方向迁移未测' if key=='M_POS' else '工程中止，固定确认门未达到；不构成总体显著性'}|")
    for d in (-1,1):
        s=ep['chains'][f'{d}:T39'];claims.append(f"|tick39 方向{d:+d}|计划/认可/发送/恢复/任务={s['planned']}/{s['recognized']}/{s['timely_sent']}/{s['recovery']}/{s['mission_successes']}|RESULT.json endpoints.chains.{d}:T39|{'正向未派发，未观察状态覆盖' if d==1 else '负向实际时相；不隐藏其他tick'}|")
    for k,v in ep['V']['by_direction_comparator'].items():claims.append(f"|V {k}|{v['status']}；snapshot/episode={v['snapshots']}/{v['episodes']}|RESULT.json endpoints.V.by_direction_comparator.{k}|{'正向未执行；无可评价反事实' if k.startswith('1:') else '同源完整及时物理失败；单个2ms点不称持续摔倒'}|")
    for r in replay['rows']:claims.append(f"|replay {r['context_id']}/{r['arm']}|{r['status']}；gate={r.get('physical_gate_classification_match')}；contact={r.get('first_contact_event_match')}|replay_continuation/REPLAY_RESULT.json；原首位 replay/REPLAY_RESULT.json|仅已存控制物理重积分；不验证governor/重求解/PID/时延|")
    claims_text='\n'.join(claims)+'\n';(out/'TRO_EVIDENCE_CLAIMS.md').write_text(claims_text,encoding='utf-8')
    fallacies=[
        ('Simpson paradox','NEG/POS及tick分开提供全计划链和方法分母；整体不替代分组。'),
        ('Ecological fallacy','计划12个确定性episode，实际生成4个，任务链成功来自1个；不将dense/QP/snapshot当独立总体样本。'),
        ('Berkson selection','双方完整安全及时的配对指标为条件描述，选择条件可能影响分布。'),
        ('Collider bias','条件配对不用于推断全体策略效用优越或learner的单独因果效应。'),
        ('Base rate neglect','176固定位置、24/8主臂、32/24/8对照与发送条件分母并报。'),
        ('Regression to mean','新确定性reference独立生成，固定输入不后选；保留五个同源对照。'),
        ('Survivorship bias','失败/拒收/late/NOT_RUN/partial保留；不将完整者作为唯一分母。'),
        ('Look elsewhere','仅预声明S/M_NEG/M_POS/tick39/V/replay，无后选p值。'),
        ('Forking paths','输入/runtime/终点在第一次数值调用前冻结；普通失败不调参/补跑。'),
        ('Correlation causation','同gamma选择/认可贡献与控制轨迹区分；冻结方法包的差异不单归因learner。'),
        ('Reverse causality','学习认可先于本臂真实轨迹；未读取固定臂未来结果进行选择。')]
    write(out/'DESCRIPTIVE_VALIDATION.json',dict(verification_status='ANALYZED',fallacy_types_checked=11,
        checks=[dict(type=k,status='CHECKED',scope_note=v) for k,v in fallacies],
        inferential_tests=0,pvalues_generated=0,population_guarantee=False,zero_risk_claim=False))
    pairs=[]
    for a,b in [(ARMS[0],ARMS[i]) for i in (1,3,2,4)]+[(ARMS[1],ARMS[2])]:
        own=[p for p in ep['paired'] if p['a']==a and p['b']==b];valid=[p for p in own if p['both_complete_safe_timely']]
        pairs.append(f"- {a} 对 {b}：计划 {len(own)} 对，双方完整、安全、及时 {len(valid)} 对。末绝对goal误差、settled time、原reference误差积分0–4/1–4和末RMS逐对保存在 RESULT.json；这些是条件描述。")
    gov=ep['groups']['ALL:RR_THIGH15:'+ARMS[0]];imm=ep['groups']['ALL:RR_THIGH15:'+ARMS[2]]
    late=[]
    for block,s in ep['S_RECOVERY'].items():late.append(f"- {block}：已认可但首包late={s['recognized_late']}；未认可计算也late={s['unrecognized_computation_late']}。模型/域/可行性拒收={s['model_domain_feasibility_rejections']}，动作拒收原因={s['action_reasons']}；拒收与late可重叠。")
    report=f"""# STEP51 冻结双向确认结果

## Material Passport

- Origin Skill: experiment-agent / academic-research-suite / SciPilot
- Origin Mode: run + descriptive validation
- Origin Date: 2026-10-12
- Delivery Date: 2026-10-13
- Verification Status: UNVERIFIED（全算法独立数值复现）；当前文件读回 {read(out/'READBACK_VERDICT.json')['status']}
- Version Label: step51_frozen_bidirectional_confirmation_v1
- Status: {result['status']} / {result['run_status']}
- 来源提交: {SOURCE_COMMIT}

## 执行结局

本批 `INCOMPLETE`：已存52个位置（40条有轨迹、12次未发送），另2个已派发UNKNOWN、122个因第二次资源失败未派发，合计176。40条轨迹中31条完整4 s，28条满足任务成功；这些计数包含各方法，主臂成功为2条。
reference计划12个、实际完整生成{actual_refs}个（NEG_0..3）；NEG主臂计划24、实际10次决定，POS主臂计划8、实际0次。未派发属于工程中止造成的缺测，不能记成模型拒收、物理失败或正向迁移失败。
一次工程修复已用完。原第44位在保存 controls.json 的SHA读取时 MemoryError，已有孤立actual/controls证据保留，记UNKNOWN；单次续行只派发原剩余位置，新增保存9位。第54位 MIDDLE_RECOVER_RESUME 在首包之前创建 MuJoCo home MjData 时 `Could not allocate memory`，形成第二个UNKNOWN并停止所有数值工作。没有重试UNKNOWN、重算已存结果、扩预算或更改科学门。
工程修复包括已有tau字段路径适配、等价分块SHA256和落盘后native资源释放。原runtime/回执保持不变，修复前后hash、原时钟与固定续行位置见两份 ENGINEERING_CONTINUATION_FREEZE / ONE_ENGINEERING_RESOURCE_CONTINUATION_FREEZE 及 CONTINUATION_RUNTIME_END.json。

## 预声明科学终点

"""+'\n'.join(summary)+f"""

M_NEG 门固定为至少6新snapshot/4新episode，M_POS至少3/2；还需自身真实及时首包、原1s安全恢复、连续4s任务成功、无已施加认可恢复错误或未决partial。旧STEP50成功不进入门限。
计划12个分别生成的确定性episode作为来源单元，实际完整生成4个、任务链成功来自1个；多个snapshot、dense点和QP不是独立样本，也不假设这些episode从真实机器人总体IID随机抽样。
正向RR恢复类别已在源CAL/domain注册；本轮是已有恢复类别下的新source方向任务链和tick39实际状态覆盖，不称未见过正向的zero-shot、新fault类别或外扰泛化。

M_NEG 的 NOT_ESTABLISHED 表示当前观察尚未达到确认门且批次工程中止，不能据此否定完整负向复验。M_POS 的 NOT_ESTABLISHED 对应全组未执行，表示未测。计划分母2/24仍保留，但14个NEG主臂未派发不能全归为模型coverage loss，也不与旧STEP50成功率直接解释为内在能力下降。

## 全计划分母与效率

"""+'\n'.join(table)+f"""

176位置=NEG severe120+NEG健康/mild16+POS severe40。每个severe方法32位（NEG24/POS8），健康/mild各8。
拒收、late、partial、NOT_RUN均占原计划位置，未补跑。BRANCH_ROWS中134个NOT_RUN包含7个ABSTAIN、1个主臂认可但late、4个固定臂late及122个未派发，原因分开报告；另2个UNKNOWN不能算成成功或失败。表中错误类别允许重叠；互斥图示优先级在FIG1图注。
主臂planned成功 {gov['mission_success']}/32，MIDDLE_IMMEDIATE {imm['mission_success']}/32。
NEG计划分母24下，学习2成功、固定MiddleRecover6、MiddleImmediate8、nominal6、B0；健康与mild各3/8，POS全部未测。MiddleRecover另有2个UNKNOWN，不能将6条可评价成功写成全部已执行均成功。10次实际学习决定中3认可、2及时，真实筛选与首包迟到分别记录；未派发缺测另列。
主臂与固定MIDDLE的相同gamma并未让学习器改变相同控制策略；可用于核查选择/认可。首包/PID seed保持冻结差异，所有差异不能单独归因learner。
主臂ABSTAIN/late/unavailable不发送新动作、不启动mission；B与nominal是独立反事实。未发送仅有source前健康reference或包内prehold事实，不称安全运行4s。它不是始终出令的部署试验。

## 主臂32个计划链与拒收

"""+'\n'.join(main_table)+'\n\n'+'\n'.join(late)+f"""

主臂8次late均违反prepared≤17 ms，而complete均在17.282–19.769 ms、未超过20 ms；拒收和late可重叠。负向tick39为计划8→实际3决定→认可2→及时1→恢复1→任务1（NEG_2）；tick41为8→3→1→1→1→1；tick37为8→4→0→0→0→0。正向全链未执行。

完整可评价且实际施加认可1s轨迹才进入错受分母。未发送不计物理成功或false acceptance；未认可计算超时不称合法动作被丢失。没有依据少量/零错受宣称零风险。

## 配对任务效用与V

"""+'\n'.join(pairs)+f"""

两个学习成功与MiddleImmediate共同完整安全及时配对中，immediate分别早0.978/0.970 s达到稳定目标；末abs误差0.197/0.163 mm，对学习0.772/0.741 mm。学习末RMS为0.219/0.214 mm/s，immediate为0.618/0.626 mm/s，均满足1 mm/s门。这是条件配对描述，不能推成学习整体更有效率。NEG_2_T041主臂γ=.5与固定MiddleRecover五项连续汇总指标完全相同，贡献定位于选择与认可。

V并集去重后snapshot/episode={ep['V']['snapshots']}/{ep['V']['episodes']}；每个方向、每个对照的实例、失败类型、时间和最长连续点数见 RESULT.json endpoints.V 与逐分支contact_statistics。不同对照单独计数不借用并集总数。未发送、late或未完整数值轨迹不充当物理失败反事实。
严格原物理门保留单个2ms contact loss为不合格点；另报点数、最长连续点数、grid-supported duration、point span、首次/末次与normal/friction margin。单点grid支持2ms而point span为0，不扩写成持续摔倒，也不增grace period。
本轮V仅NEG_2_T041相对NOMINAL成立：FR CONTACT_LOSS首时刻0.084 s，1点、grid支持2 ms、point span0；其余对照为NOT_ESTABLISHED。B的1 s门拒轨迹虽有单点接触失效，但未完整4 s且不满足及时条件，不能计入V。
健康nominal不是TASK B的匹配Type-II反事实，本轮未重证完整Type-II链。

## 四条独立保存控制物理重积分

"""+'\n'.join(replay_table)+f"""

实际重积分步数={replay.get('actual_steps')}，新QP=0。读取完整mjSTATE_INTEGRATION与所有具名seed字段，验证source asset/health和实际tau_applied槽；独立推进循环执行原.002s mj_forward/mj_step时序。缺字段会明确NOT_REPRODUCIBLE_FROM_SAVED_SEED。
逐步bitwise检查保存的物理字段、contact数值和完整最终integration seed；首个差异和逐字段最大绝对误差独立保存。未采用事后宽松容差改标MATCH。
首位保存控制读取因紧凑capacity_interface未嵌套tau_raw而报KeyError，在0新积分时保留UNKNOWN。一轮存储字段适配从原控制记录根部读取已有tau_raw，受影响纯测试通过；仅续行原未派发3位，未重试UNKNOWN首位。原代码和原replay/REPLAY_RESULT.json保持，前后代码SHA、字段映射、固定未派发列表和原预算时钟见ENGINEERING_CONTINUATION_FREEZE.json；续行证据见replay_continuation。该修复不改变输入、策略、health、plant或评价门。
bitwise与原物理gate分类/首次contact是否一致分别报告。若BITWISE_MISMATCH或事件分类改变，旧单点V的精确数值可复现性受相应限制；旧STEP50 verdict原样保留，不能将文件读回MATCH当作这条数值证据。
该子实验不增加176位任务分母、不增加独立episode，不验证学习决策、控制器重求解、PID或真实时延；全算法独立数值复现仍UNVERIFIED。

## 冻结、实际时钟与预算

source合同TASK_MATCHED；TASK_AWARE_1MM_06S_V1，CAP=.001m，RAMP=.6s，START=.02s，原anchor/goal和source method hash `{OLD_METHOD_SHA}` 均不变。
模型APPLICATION_LINEAR_28仍来自HOLD TRAIN，TASK匹配CAL/认可合同，TASK_TRAIN_policy_matched=False；本轮输入/runtime hash另存METHOD_INPUT_FREEZE.json。
physical .002s/control .02s，4s完整2000步/2001dense/200control/81checkpoint；恢复1s完整501dense/50control/21checkpoint。RMS固定1750..2000含端点。
恢复门D<=6mm、原anchor±2mm、|vx|<=1mm/s及其余原terminal/物理门；t=1s causal gate/switch在feedback墙钟内，同一owner/plant/PID/health/warmstart不中断。恢复后1–3s quintic到原goal，immediate .02–2.02s，从.04s反馈开始任务，随后hold至4s。
4s成功还需全物理安全、全部prepared<=17ms/complete<=20ms、goal误差<=2mm、末|vx|和末RMS<=1mm/s及原其他terminal条件。恢复6mm局部门不强加到后续任务；全程世界boundary、command/applied torque、contact/friction等原门保留。
native B/C/feedback预算6/3/6ms、精度与迭代限制、PID/reference均未调参；完整时延包含copy/check/staging/commit。

数值启动UTC={finish.get('source_start_utc')}；耗时 {budget.get('numerical_elapsed_s')}s；QP START/RETURN={budget.get('total_QP_calls')}/{budget.get('QP_returns')}，UNKNOWN={budget.get('unknown_native_returns')}；总积分={budget.get('total_physics_steps')}（含replay）。上限45000QP/500000步/150min，CAL/TRAIN/fit=0，数值结果重试0。
五类必要纯测试见tests/NECESSARY_TESTS.json；没有数值canary/smoke或历史测试运行。普通失败继续冻结位置。
一次当前streaming读回={read(out/'READBACK_VERDICT.json')['status']}；issues={result['issues']}；新QP/积分=0。之后仅修复已存scalar汇总的计划/实际reference计数及UNKNOWN首包已知时延，原汇总副本和更正SHA见DERIVED_SUMMARY_CORRECTIONS.json；S/M/V评价与唯一读回回执未改。源Git/index/config/native/model受保护。Git准备时完整checkout因历史单blob约2.94GB内存分配失败，改为稀疏checkout并在D保留可读Git对象，发生于第一次数值调用之前。
两张SciPilot图保留全部计划结局、拒收/缺测/partial、原始任务点、条件配对、每个首包/feedback时延与接触持续诊断；PDF/PNG/灰度和机器/视觉QA见figures。
描述性验证覆盖11/11类常见统计/方法谬误，逐项边界见DESCRIPTIVE_VALIDATION.json；未生成总体推断检验或p值。

## T-RO evidence/claim表

"""+claims_text+f"""

研究主线继续是容量与backup感知的动作选择，连接实际反馈恢复与原任务用途。任务成功、安全差异和方向覆盖以本轮真实终点为准；不继承其他安全过滤文献的理论保证，不声称硬实时部署已经验证。
输出={out}；工作副本={OUTPUT_ROOT_D}；本地scoped commit回执=.git/STEP51_COMMIT_RECEIPT.json。大证据路径与hash见EVIDENCE_MANIFEST.json；未自动推送。
完成后停止，不扩CAL、不加扰动、不进入STEP52/E3/RL或硬件。

## 全部状态

```ini
{status}```
"""
    (out/'REPORT.md').write_text(report,encoding='utf-8')
    handoff=f"""# STEP51 研究交接

## Material Passport
- Origin Skill: experiment-agent / ARS
- Origin Date: 2026-10-12
- Delivery Date: 2026-10-13
- Verification Status: UNVERIFIED（全算法独立数值复现）
- Version Label: step51_handoff_v1

执行结局：INCOMPLETE；52个已存位置=40条轨迹+12次未发送，2 UNKNOWN，122未派发；reference实际4/计划12，POS全组未测。一次工程修复已用完，第二次MuJoCo资源分配失败后已停止数值。收尾仅报告/图/本地提交。

M_NEG={ep['M_NEG']['status']}，{ep['M_NEG']['success_planned_fraction']}，来源snapshot/episode={ep['M_NEG']['snapshots']}/{ep['M_NEG']['episodes']}。
M_POS={ep['M_POS']['status']}，{ep['M_POS']['success_planned_fraction']}，来源snapshot/episode={ep['M_POS']['snapshots']}/{ep['M_POS']['episodes']}。
重积分4位status={[r['status'] for r in replay['rows']]}，实际步数={replay.get('actual_steps')}，0QP。
完整176分母、S、tick39、V各对照、效率tradeoff与replay首差异见 REPORT.md / RESULT.json / BRANCH_ROWS.csv / TRO_EVIDENCE_CLAIMS.md。
文件读回={read(out/'READBACK_VERDICT.json')['status']}。所有旧结果未改，本轮结束；STEP52/E3/RL/硬件未授权也未执行。
工作副本 {OUTPUT_ROOT_D}；输出 {out}；scoped commit回执见 .git/STEP51_COMMIT_RECEIPT.json。
"""
    (out/'HANDOFF.md').write_text(handoff,encoding='utf-8')
    print(dict(report=str(out/'REPORT.md'),M_NEG=ep['M_NEG'],M_POS=ep['M_POS'],replay=replay['status']),flush=True)
if __name__=='__main__':run()
