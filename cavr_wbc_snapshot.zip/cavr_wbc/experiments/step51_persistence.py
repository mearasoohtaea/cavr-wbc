"""Storage-only bounded SHA256 memory; all hashes retain exact byte identity."""
import hashlib
from pathlib import Path

def streaming_sha(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):digest.update(block)
    return digest.hexdigest()

def install():
    # save_numeric uses its module-global sha only after commands are ready.
    # This patches no solver, PID, plant, timing transaction or evaluator.
    from cavr_wbc.experiments import step47_io,step50_storage,step51_storage,step51_io
    for module in (step47_io,step50_storage,step51_storage,step51_io):module.sha=streaming_sha
    return dict(algorithm='SHA256',chunk_bytes=1024*1024,scientific_behavior_changed=False)
