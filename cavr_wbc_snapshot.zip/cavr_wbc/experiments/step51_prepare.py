"""One D preparation confirmation; no native solve or integration."""
import os
import shutil
import subprocess
import numpy as np
from cavr_wbc.experiments.step51_io import *
from cavr_wbc.experiments.step51_inputs import episodes, plans, positions

def prepare():
    out = output()
    out.mkdir(parents=True, exist_ok=True)
    if (out / 'PREPARATION.json').exists():
        raise FileExistsError('one environment confirmation already recorded')
    import cavr_wbc, mujoco, osqp, scipy, threadpoolctl
    package = Path(cavr_wbc.__file__).resolve()
    if not package.is_relative_to(OUTPUT_ROOT_D.resolve()):
        raise ValueError('wrong package root')
    free = shutil.disk_usage(OUTPUT_ROOT_D).free
    if free < 8_000_000_000 or not NATIVE_DLL.is_file():
        raise OSError('D space/native prerequisite')
    for name in ('TMP', 'TEMP', 'MPLCONFIGDIR'):
        if Path(os.environ[name]).resolve().drive.upper() != 'D:':
            raise ValueError(name + ' must be on D')
    commit = subprocess.check_output(['git', '-C', str(SOURCE_ROOT_D), 'rev-parse', 'HEAD'], text=True).strip()
    if commit != SOURCE_COMMIT:
        raise ValueError('STEP50 source commit changed')
    subprocess.check_call(['git', '-C', str(OUTPUT_ROOT_D), 'cat-file', '-e', SOURCE_COMMIT + '^{commit}'])
    native_source = SOURCE_ROOT_D / NATIVE_DLL.relative_to(OUTPUT_ROOT_D)
    if sha(NATIVE_DLL) != sha(native_source):
        raise ValueError('source native DLL identity changed')
    files = list(ASSET_HASHES) + ['STEP48_CAL_FREEZE.json', 'ACTUAL_POLICY_CONTRACTS.json',
                               'SOURCE_FROZEN_CONFIG.json', 'METHOD_INPUT_FREEZE.json', 'PROTOCOL_AND_MANIFEST.json']
    hashes = {}
    for rel in files:
        src = SOURCE_RUN / rel
        dst = out / ('source_step50/' + rel if rel in ('METHOD_INPUT_FREEZE.json', 'PROTOCOL_AND_MANIFEST.json') else rel)
        if dst.exists():
            raise FileExistsError(str(dst))
        digest = sha(src)
        if rel in ASSET_HASHES and digest != ASSET_HASHES[rel]:
            raise ValueError('frozen asset hash: ' + rel)
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)
        if sha(dst) != digest:
            raise ValueError('copy identity')
        hashes[rel] = digest
    contract = read(out / 'STEP48_CAL_FREEZE.json')['methods']['PHASE_MATCHED_TASK']['policy_contract']
    if contract != read(out / 'ACTUAL_POLICY_CONTRACTS.json')['TASK_MATCHED'] or contract['method_freeze_sha256'] != OLD_METHOD_SHA:
        raise ValueError('source policy binding')
    manifest = read(out / 'SOURCE_FROZEN_CONFIG.json')
    model_hashes = manifest['frozen_physical']['model_files_sha256']
    for rel, digest in model_hashes.items():
        if sha(OUTPUT_ROOT_D / rel) != digest:
            raise ValueError('source plant asset: ' + rel)
    write_new(out / 'SOURCE_READONLY_BASELINE.json', dict(source_commit=SOURCE_COMMIT,
        source_worktree=str(SOURCE_ROOT_D), source_run=str(SOURCE_RUN),
        source_index_sha256=sha(SOURCE_ROOT_D / '.git/index'), assets=hashes,
        native_sha256=sha(NATIVE_DLL), plant_asset_hashes=model_hashes,
        historical_bank_read=False, exact_STEP50_full_source_config_reused=True))
    write_new(out / 'INPUTS_PLAN.json', dict(episodes=episodes(), contexts=plans(), positions=positions(),
        max_wall_s=MAX_WALL_S, max_QP=MAX_QP, max_steps=MAX_STEPS,
        replay_max_steps=MAX_REPLAY_STEPS, fits=0, CAL=0, TRAIN=0))
    write_new(out / 'PREPARATION.json', dict(package=str(package), D_free_bytes=free,
        TMP=os.environ['TMP'], TEMP=os.environ['TEMP'], MPLCONFIGDIR=os.environ['MPLCONFIGDIR'],
        native=str(NATIVE_DLL), native_sha256=sha(NATIVE_DLL), source_commit=commit,
        versions=dict(mujoco=mujoco.__version__, osqp=osqp.__version__, numpy=np.__version__, scipy=scipy.__version__),
        threadpools=threadpoolctl.threadpool_info(), new_QP=0, new_steps=0))
    print(dict(prepared=True, references=12, severe_contexts=32, positions=len(positions()), new_QP=0, new_steps=0), flush=True)

if __name__ == '__main__':
    prepare()
