"""Four frozen-control physics re-integrations; no controller/solver calls."""
from pathlib import Path
import argparse
import numpy as np

REPLAY_POSITIONS=tuple((f'T50_DEV_{i}_T041_RR_THIGH15',a) for i in (0,2)
    for a in ('GOVERNED_RECOVER_RESUME','NOMINAL_IMMEDIATE'))
MAX_REPLAY_STEPS=8000
_FIELDS=('time_s','integration_state_signature','integration_state','qpos','qvel','act','ctrl',
    'qacc_warmstart','qfrc_applied','xfrc_applied','mocap_pos','mocap_quat','userdata','plugin_state')
def required_seed_fields():return _FIELDS
def seed_missing(seed):return [k for k in _FIELDS if k not in seed]
def bitwise_difference(a,b):
    av,bv=np.asarray(a),np.asarray(b)
    eq=av.shape==bv.shape and av.dtype==bv.dtype and av.tobytes()==bv.tobytes()
    delta=float(np.max(np.abs(av.astype(float)-bv.astype(float)))) if av.size and av.shape==bv.shape else 0. if av.shape==bv.shape else None
    return eq,delta
def control_for_step(controls,step):
    if not isinstance(step,int) or not 0<=step<2000:raise ValueError('replay step 0..1999')
    slot=step//10
    if len(controls)!=200 or controls[slot]['slot']!=slot:raise ValueError('200 immutable control slots required')
    tau=np.asarray(controls[slot].get('tau_applied'),dtype=float)
    if tau.shape!=(12,) or not np.isfinite(tau).all():raise ValueError('saved actual applied tau missing')
    return tau.copy()

def run(out):
    import mujoco
    from datetime import datetime,timezone
    from cavr_wbc.experiments.step51_io import SOURCE_RUN,OUTPUT_ROOT_D,read,write,sha,load_numeric,save_numeric
    from cavr_wbc.experiments.step50_storage import load_branch
    from cavr_wbc.experiments.step26_sim import compact_fact,restore_snapshot
    from cavr_wbc.evaluation.step23_actual import actual_reasons
    from cavr_wbc.experiments.step47_storage import contact_statistics
    folder=Path(out)/'replay';folder.mkdir(parents=True,exist_ok=True)
    if (folder/'REPLAY_STARTED.json').exists():raise FileExistsError('no replay retries')
    write(folder/'REPLAY_STARTED.json',dict(start_utc=datetime.now(timezone.utc).isoformat(),positions=REPLAY_POSITIONS,new_QP_calls=0))
    manifest=read(SOURCE_RUN/'SOURCE_FROZEN_CONFIG.json')
    hashes=manifest['frozen_physical']['model_files_sha256']
    if any(sha(OUTPUT_ROOT_D/p)!=h for p,h in hashes.items()):raise ValueError('replay source plant asset changed')
    model=mujoco.MjModel.from_xml_path(str(OUTPUT_ROOT_D/'third_party/unitree_mujoco_snapshot/unitree_robots/go2/scene.xml'))
    rows=[];steps=0;error=None;receipt=None
    try:
        for context_id,arm in REPLAY_POSITIONS:
            base=SOURCE_RUN/'branches'/context_id/arm
            receipt=dict(context_id=context_id,arm=arm,actual_steps=0,new_QP_calls=0,
                source_actual_sha256=sha(base/'actual.npz'),source_controls_sha256=sha(base/'controls.npz'),
                source_asset_hashes=hashes,platform_mujoco_version=mujoco.__version__,
                scope='FROZEN_CONTROL_PHYSICS_ONLY',controller_recomputed=False)
            b=load_branch(base);seed=b.get('initial_state') or {};missing=seed_missing(seed)
            if missing:
                receipt.update(status='NOT_REPRODUCIBLE_FROM_SAVED_SEED',missing_fields=missing)
                rows.append(receipt);write(folder/(context_id+'_'+arm+'.json'),receipt);continue
            controls=b['controls'];dense=[b['initial_fact']]+b['physics_trajectory']
            if len(dense)!=2001 or len(controls)!=200:raise ValueError('specified source branch not complete 4s')
            receipt.update(source_model_sha256=sha(SOURCE_RUN/'models/PHASE_MATCHED_TASK.npz'),
                source_domain_sha256=sha(SOURCE_RUN/'models/PHASE_MATCHED_TASK_DOMAIN.json'),health_vector=b['health_vector'])
            save_numeric(folder/(context_id+'_'+arm+'_INPUT.json'),dict(seed=seed,
                health_vector=b['health_vector'],controls=[dict(slot=r['slot'],tau_applied=r['tau_applied']) for r in controls]))
            # Unit-gain, stateless joint motors: applied torque maps directly to ctrl.
            mapping=manifest['mapping']
            if any(r['gain_parameters'][0]!=1 or any(r['bias_parameters']) or r['activation_dimension']!=0
                or r['dynamic_type']!='mjDYN_NONE' for r in mapping):raise ValueError('unsupported applied-torque ctrl mapping')
            data=restore_snapshot(model,seed)
            health=np.asarray(b['health_vector']);limits=np.asarray(dense[0]['actuator_limits'])
            fresh=[];first_difference=None;maxdiff={};gate_diffs=[];state_diffs=[]
            def compare(f,old):
                nonlocal first_difference
                fields=['qpos','qvel','actual_mujoco_qacc','tau_applied','subtree_com','base_joint_height_m',
                    'subtree_com_height_m','tau_cmd','tau_sent','actuator_limits','command_torque_margin_nm',
                    'applied_torque_margin_nm','joint_limit_margins','friction_coeff','roll','pitch',
                    'boundary_margin_m','health_vector']
                def contact_arrays(row):
                    return {f'contacts:{foot}:{key}':value for foot,contact in row['contacts'].items()
                        for key,value in contact.items() if np.asarray(value).dtype.kind in 'biuf'}
                f={**f,**contact_arrays(f)};old={**old,**contact_arrays(old)}
                fields+=sorted(contact_arrays(fresh[-1]))
                for field in fields:
                    eq,delta=bitwise_difference(f[field],old[field])
                    maxdiff[field]=max(maxdiff.get(field,0.),delta) if delta is not None else None
                    if not eq:
                        if first_difference is None:first_difference=dict(physics_step=f['physics_step'],field=field,max_abs_difference=delta)
                        state_diffs.append(dict(physics_step=f['physics_step'],field=field,max_abs_difference=delta))
                aa=actual_reasons(f);bb=actual_reasons(old)
                if aa!=bb:gate_diffs.append(dict(physics_step=f['physics_step'],replay=aa,source=bb))
            for slot,ctrl in enumerate(controls):
                tau=control_for_step(controls,slot*10);data.ctrl[:]=tau
                mujoco.mj_forward(model,data)
                if not np.array_equal(data.actuator_force,tau):raise ValueError('actual torque ctrl mapping mismatch')
                interface=ctrl['capacity_interface'];meta={k:dense[0][k] for k in ('health_vector','context_id','faulted_actuator_name','faulted_actuator_index','faulted_health') if k in dense[0]}
                if slot==0:
                    f=compact_fact(model,data,health,limits,tau,ctrl.get('action',0.),ctrl.get('latency_ms',0.),0,slot,b['backup_id'],b['branch_id'],interface,meta)
                    fresh.append(f);compare(f,dense[0])
                for local in range(10):
                    mujoco.mj_step(model,data);steps+=1;receipt['actual_steps']+=1
                    mujoco.mj_forward(model,data)
                    step=slot*10+local+1
                    if abs(data.time-step*.002)>1e-9:raise ValueError('replay physical clock reset')
                    f=compact_fact(model,data,health,limits,tau,ctrl.get('action',0.),ctrl.get('latency_ms',0.),step,slot,b['backup_id'],b['branch_id'],interface,meta)
                    fresh.append(f);compare(f,dense[step])
            final=[]
            final_vector=np.empty(mujoco.mj_stateSize(model,int(seed['integration_state_signature'])))
            mujoco.mj_getState(model,data,final_vector,int(seed['integration_state_signature']))
            if final_vector.tobytes()!=np.asarray(b['final_state']['integration_state'],dtype=float).tobytes():final.append('integration_state')
            for field in _FIELDS:
                if field in ('integration_state_signature','integration_state'):continue
                av=np.asarray(data.time if field=='time_s' else getattr(data,field));bv=np.asarray(b['final_state'][field])
                if av.size!=bv.size or av.ravel().tobytes()!=bv.ravel().tobytes():final.append(field)
            replay_contacts=contact_statistics(dict(initial_fact=fresh[0],physics_trajectory=fresh[1:]))
            source_contacts=contact_statistics(b)
            receipt.update(status='MATCH' if first_difference is None and not final else 'BITWISE_MISMATCH',
                stepwise_comparison='BITWISE_SAVED_DENSE_FIELDS',first_difference=first_difference,max_abs_difference=maxdiff,
                differing_step_fields=len(state_diffs),final_seed_field_differences=final,
                physical_gate_classification_match=not gate_diffs,physical_gate_differences=gate_diffs,
                contact_statistics=replay_contacts,source_contact_statistics=source_contacts,
                first_contact_event_match=all(replay_contacts['contacts'][k]['CONTACT_LOSS']['first_s']==v['CONTACT_LOSS']['first_s'] for k,v in source_contacts['contacts'].items()),
                original_step50_verdict_unchanged=True)
            save_numeric(folder/(context_id+'_'+arm+'_DENSE.json'),dict(dense=fresh,state_differences=state_diffs))
            rows.append(receipt);write(folder/(context_id+'_'+arm+'.json'),receipt)
            del b,data,fresh
    except Exception as exc:
        error=dict(type=type(exc).__name__,message=str(exc))
        if receipt is not None and not any(r['context_id']==receipt['context_id'] and r['arm']==receipt['arm'] for r in rows):
            receipt.update(status='UNKNOWN',error=error);rows.append(receipt)
    finally:
        saved={(r['context_id'],r['arm']) for r in rows}
        for context_id,arm in REPLAY_POSITIONS:
            if (context_id,arm) not in saved:rows.append(dict(context_id=context_id,arm=arm,status='NOT_RUN',actual_steps=0,new_QP_calls=0,reason=error))
        write(folder/'REPLAY_RESULT.json',dict(status='COMPLETED' if error is None else 'INCOMPLETE',rows=rows,error=error,
            actual_steps=steps,new_QP_calls=0,max_steps=MAX_REPLAY_STEPS,
            independent_full_method_numerical_reproduction='UNVERIFIED',new_independent_episodes=0))
    print(dict(replay_status=[r['status'] for r in rows],actual_steps=steps,new_QP_calls=0),flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);run(p.parse_args().out)
