"""Exactly one frozen bidirectional batch and four saved-control replays."""
from datetime import datetime, timezone
import gc
import os
import subprocess
import sys
import traceback
from time import perf_counter
import numpy as np
from cavr_wbc.experiments.step51_io import *
from cavr_wbc.experiments.step51_inputs import *
from cavr_wbc.experiments.step51_budget import SprintBudget, SprintLimit
from cavr_wbc.experiments.step51_storage import save_branch, not_run
from cavr_wbc.experiments.step35_reference import reference_episode
from cavr_wbc.experiments.step50_sprint import owners_for as source_owners_for, missing_packet
from cavr_wbc.experiments import step17_formal_panel as frozen, step50_sim as sim
from cavr_wbc.control.step50_policy import VERSION
from cavr_wbc.control.step50_kernel import experimental_packet, nominal_packet
from cavr_wbc.control.step50_dispatch import first_sent
from cavr_wbc.control.step39_margin import load_bundle
from cavr_wbc.experiments.step47_binding import PolicyDomain

def event(out, name, **values):
    append(out / 'ATTEMPT_LEDGER.jsonl', dict(event=name,
        timestamp_utc=datetime.now(timezone.utc).isoformat(), **values))

def run_replay(out, budget):
    token = budget.reserve_steps('FROZEN_CONTROL_REPLAY', 'STEP50_SAVED_CONTROLS', MAX_REPLAY_STEPS)
    budget.persist(phase='REPLAY_PROCESS_START')
    event(out, 'START', kind='FROZEN_CONTROL_REPLAY', positions=4)
    command = [sys.executable, '-B', '-X', 'utf8', '-m', 'cavr_wbc.experiments.step51_replay', '--out', str(out)]
    with (out / 'replay_process.log').open('x', encoding='utf-8') as stream:
        child = subprocess.Popen(command, cwd=OUTPUT_ROOT_D, stdout=stream, stderr=subprocess.STDOUT)
        try:
            remaining = MAX_WALL_S - (perf_counter() - budget.started)
            exit_code = child.wait(timeout=max(.01, remaining))
        except subprocess.TimeoutExpired:
            child.kill()
            child.wait()
            event(out, 'RETURN', kind='FROZEN_CONTROL_REPLAY', status='HARD_TIMEOUT_UNKNOWN', reserved_steps=MAX_REPLAY_STEPS)
            raise SprintLimit('150-minute hard cap during replay')
    report = read(out / 'replay/REPLAY_RESULT.json')
    if report is None:
        # Retain all 8000 as unknown reserved work; never retry the child.
        event(out, 'RETURN', kind='FROZEN_CONTROL_REPLAY', status='UNKNOWN_PROCESS_FAILURE', exit_code=exit_code,
              unknown_reserved_steps=MAX_REPLAY_STEPS)
        budget.persist(phase='REPLAY_PROCESS_UNKNOWN')
        return
    if report['new_QP_calls'] != 0 or not 0 <= report['actual_steps'] <= MAX_REPLAY_STEPS or len(report['rows']) != 4:
        raise ValueError('replay count/protocol identity mismatch')
    budget.finish_steps(token, report['actual_steps'])
    event(out, 'RETURN', kind='FROZEN_CONTROL_REPLAY', status=report['status'], exit_code=exit_code,
          actual_steps=report['actual_steps'], new_QP_calls=0)
    budget.persist(phase='REPLAY_PROCESS_SAVED')
    print(dict(replay_status=report['status'], replay_steps=report['actual_steps'], budget=budget.snapshot()), flush=True)

def frozen_manifest(out):
    manifest = read(out / 'SOURCE_FROZEN_CONFIG.json')
    # Postprocessing has no input to the numerical chain.
    post = {'step51_delivery.py', 'step51_analyze.py', 'step51_figures.py', 'step51_finalize.py', 'step51_package.py'}
    runtime = {relative(p, OUTPUT_ROOT_D): sha(p) for p in OUTPUT_ROOT_D.glob('cavr_wbc/**/*.py') if p.name not in post}
    source_sha = sha(out / 'source_step50/METHOD_INPUT_FREEZE.json')
    freeze = dict(runtime_sha256=runtime, protocol_sha256=sha(PROTOCOL), config=manifest,
        episodes=episodes(), plans=plans(), positions=positions(), new_CAL=0, new_TRAIN=0, new_fit=0,
        learned_governor_decisions_planned=32, references_planned=12, severe_contexts=32, control_contexts=16,
        policy=VERSION, physical_dt_s=.002, control_dt_s=.02, physical_horizon_s=4., phase1_gate_s=1.,
        phase1_D_limit_m=.006, phase1_anchor_tol_m=.002, final_goal_tol_m=.002, final_speed_tol_m_s=.001,
        final_RMS_indices=[1750, 2000], final_RMS_tol_m_s=.001, mission_ramp_s=2.,
        mission_resume_start_s=1., immediate_mission_clock_start_s=.02, immediate_first_feedback_s=.04,
        deadline_ms=20., prepared_ms=17., native_B_C_feedback_limits_s=[.006, .003, .006],
        max_wall_s=MAX_WALL_S, max_QP=MAX_QP, max_steps=MAX_STEPS, replay_max_steps=MAX_REPLAY_STEPS,
        native_sha256=sha(NATIVE_DLL), old_CAL_certifies_mission=False,
        step48_method_freeze_sha256=OLD_METHOD_SHA, step50_method_freeze_sha256=source_sha,
        authorization_scope='RECOVERY_1S_ONLY', always_output_deployment_test=False,
        numerical_result_retries=0, source_control_and_simulator_modules_unmodified=True,
        optional_double_copy_optimization='NOT_ADOPTED_ORIGINAL_TIMED_COPIES_RETAINED')
    from cavr_wbc.experiments.step51_replay import REPLAY_POSITIONS
    freeze['replay_positions'] = [dict(context_id=c, arm=a) for c, a in REPLAY_POSITIONS]
    write_new(out / 'METHOD_INPUT_FREEZE.json', freeze)
    method_sha = sha(out / 'METHOD_INPUT_FREEZE.json')
    contract = read(out / 'STEP48_CAL_FREEZE.json')['methods']['PHASE_MATCHED_TASK']['policy_contract']
    bundle = load_bundle(out / 'models/PHASE_MATCHED_TASK.npz')
    domain = PolicyDomain(read(out / 'models/PHASE_MATCHED_TASK_DOMAIN.json'), sha(out / 'models/PHASE_MATCHED_TASK_DOMAIN.json'))
    if bundle['policy_contract'] != contract or domain.policy_contract != contract:
        raise ValueError('exact source policy binding')
    write_new(out / 'PROTOCOL_AND_MANIFEST.json', dict(**freeze, run_id=RUN_ID, source_commit=SOURCE_COMMIT,
        policy_contract=contract, step51_method_freeze_sha256=method_sha, asset_hashes=ASSET_HASHES,
        TASK_TRAIN_policy_matched=False, predictor_TRAIN_policy='HOLD', MaterialPassport='UNVERIFIED'))
    return manifest, runtime, source_sha, method_sha, contract, bundle, domain

def exception_result(out, path, p, arm, ac, exc):
    result = dict(status='UNKNOWN_NUMERICAL_EXCEPTION', reason=dict(type=type(exc).__name__, error=str(exc)),
        observed=False, evaluation={}, complete_2001=False, mission_success=False, experimental_applied=False,
        id=p['context_id'] + ':' + arm, context_id=p['context_id'], arm=arm, episode=p['episode'],
        snapshot_id=p['snapshot_id'], health_kind=p['health_kind'], block=p['block'], direction=p['direction'],
        severe=p['severe'], tick=p['tick'], step51_method_freeze_sha256=ac['step51_method_freeze_sha256'],
        numerical_exception_no_retry=True, dispatched_unknown=True)
    write_new(path / 'RESULT.json', result)
    write_new(path / 'NUMERICAL_EXCEPTION.json', dict(traceback=traceback.format_exc(), **result['reason']))
    return result

def run():
    out = output()
    if (out / 'RUN_STARTED.json').exists():
        raise FileExistsError('unique fixed batch already started; no numerical rerun')
    tests = read(out / 'tests/NECESSARY_TESTS.json')
    if not read(out / 'PREPARATION.json') or tests is None or tests['errors'] or tests['failures'] or tests['tests_run'] != 5:
        raise ValueError('one preparation and five pure topics must pass')
    manifest, runtime, source_sha, method_sha, contract, bundle, domain = frozen_manifest(out)
    model = frozen.load_model()
    budget = SprintBudget(out)
    saved = set()
    status = 'COMPLETED'
    active_id = None
    governor_calls = reference_calls = branch_calls = 0
    write_new(out / 'RUN_STARTED.json', dict(run_id=RUN_ID, pid=os.getpid(),
        start_utc=datetime.now(timezone.utc).isoformat(), command='cavr_wbc.experiments.step51_sprint',
        frozen_before_first_numerical_action=True, source_commit=SOURCE_COMMIT))
    budget.start()
    budget.persist(phase='NUMERICAL_STARTED_ALL_INPUTS_FROZEN')
    try:
        run_replay(out, budget)
        for ep in episodes():
            budget.check()
            if reference_calls >= 12:
                raise SprintLimit('12 reference cap')
            reference_calls += 1
            event(out, 'START', kind='REFERENCE', **ep)
            try:
                episode = reference_episode(model, manifest['reference_scenario'], ep['displacement_m'],
                    ep['episode_id'], ep['snapshot_ticks'], budget, evidence_callback=budget.record_raw)
            except (FloatingPointError, np.linalg.LinAlgError, RuntimeError) as exc:
                if isinstance(exc, SprintLimit):
                    raise
                episode = dict(episode_id=ep['episode_id'], status='UNKNOWN_NUMERICAL_EXCEPTION', snapshots=[], controls=[],
                    reason=dict(type=type(exc).__name__, error=str(exc)), counts=None, no_retry=True,
                    missing_snapshot_ticks=list(ep['snapshot_ticks']))
            for ctl in episode['controls']:
                ctl.pop('raw_solver_result', None)
            save_numeric(out / 'episodes' / (ep['episode_id'] + '.json'), episode)
            event(out, 'RETURN', kind='REFERENCE', episode_id=ep['episode_id'], status=episode['status'], counts=episode['counts'])
            for p in (v for v in plans() if v['episode'] == ep['episode_id']):
                c = context_for(p, episode, manifest['mapping'])
                save_numeric(out / 'sources' / c['context_id'] / 'SOURCE_IDENTITY.json', dict(plan=p, context=c))
                for arm in p['arms']:
                    budget.check()
                    if branch_calls >= 176:
                        raise SprintLimit('176 planned task position cap')
                    branch_calls += 1
                    ac = arm_context(c, arm, contract, method_sha, source_sha)
                    gamma = gamma_for(arm)
                    path = out / 'branches' / c['context_id'] / arm
                    active_id = c['context_id'] + ':' + arm
                    if ac.get('eligible'):
                        ac['policy_anchor_goal'] = dict(x_anchor_m=float(ac['backup_anchor_q_init'][0]),
                            x_goal_m=float(ac['nominal_q_init'][0]) + float(ac['nominal_d_m']),
                            d_task_m=float(np.clip(float(ac['nominal_q_init'][0]) + float(ac['nominal_d_m']) - float(ac['backup_anchor_q_init'][0]), -.001, .001)))
                    save_numeric(path / 'POLICY_CONTEXT.json', ac)
                    event(out, 'START', kind='MISSION', id=active_id, arm=arm, health_kind=p['health_kind'], block=p['block'])
                    owners = {}
                    k = packet = branch = None
                    try:
                        if ac.get('eligible'):
                            owners, startup = source_owners_for(model, budget, ac, manifest, contract, domain)
                            write_new(path / 'STARTUP.json', startup)
                            if arm == 'GOVERNED_RECOVER_RESUME':
                                if governor_calls >= 32:
                                    raise SprintLimit('32 governor decision cap')
                                governor_calls += 1
                                budget.event('GOVERNOR_DECISION_START', id=active_id, ordinal=governor_calls)
                                k = owners['GOVERNOR']
                                packet = k.governor(ac, bundle, .006, budget)
                                budget.event('GOVERNOR_DECISION_RETURN', id=active_id, status=packet['status'])
                            elif arm == 'NOMINAL_IMMEDIATE':
                                k = owners['C']
                                packet = nominal_packet(k, ac, budget)
                            else:
                                k = owners['B' if gamma == 0. else 'MIDDLE']
                                packet = experimental_packet(k, ac, budget, owners, gamma, arm)
                            k.flush_raw_evidence()
                        else:
                            packet = missing_packet(ac, gamma)
                        save_numeric(path / 'PACKET.json', packet)
                        branch = sim.propagate(k, ac, packet, budget, purpose=arm, require_sent=True) if first_sent(packet, ac) else not_run(packet.get('selected_gamma', gamma), packet['status'])
                        result = save_branch(out, path, branch, ac, packet)
                    except (FloatingPointError, np.linalg.LinAlgError, RuntimeError) as exc:
                        if isinstance(exc, SprintLimit):
                            raise
                        # Numerical exceptions stop only this frozen position. A dispatched unknown is never retried.
                        result = exception_result(out, path, p, arm, ac, exc)
                    saved.add(active_id)
                    append(out / 'POSITION_INDEX.jsonl', dict(id=active_id, path=relative(path, out), context_id=c['context_id'],
                        arm=arm, episode=p['episode'], snapshot_id=p['snapshot_id'], health_kind=p['health_kind'],
                        block=p['block'], direction=p['direction']))
                    event(out, 'RETURN', kind='MISSION', id=active_id, status=result['status'],
                        complete=result['complete_2001'], mission_success=result['mission_success'])
                    budget.persist(phase='BRANCH_SAVED', completed_positions=len(saved), planned_positions=176, id=active_id,
                        governor_calls=governor_calls, reference_calls=reference_calls, branch_calls=branch_calls)
                    print(dict(positions=len(saved), planned=176, id=active_id, status=result['status'],
                        phase1=result.get('evaluation', {}).get('phase1'), mission_success=result['mission_success'],
                        budget=budget.snapshot()), flush=True)
                    active_id = None
                    del owners, k, packet, branch
                    gc.collect()
                    if result['status'] == 'FAILED_BUDGET':
                        raise SprintLimit('partial saved at cap')
            del episode
            gc.collect()
    except SprintLimit as exc:
        status = 'INCOMPLETE_BUDGET'
        write_new(out / 'INTERRUPTION.json', dict(error=str(exc), active_id=active_id, budget=budget.snapshot()))
    except BaseException as exc:
        status = 'INVALID_INCOMPLETE_IMPLEMENTATION_OR_RESOURCE'
        write_new(out / 'INTERRUPTION.json', dict(type=type(exc).__name__, error=str(exc), active_id=active_id,
            traceback=traceback.format_exc(), budget=budget.snapshot()))
        raise
    finally:
        for pos in positions():
            path = out / 'branches' / pos['context_id'] / pos['arm'] / 'RESULT.json'
            if not path.exists():
                write_new(path, dict(status='UNKNOWN' if pos['id'] == active_id else 'NOT_RUN',
                    reason={'reason': status}, observed=False, evaluation={}, complete_2001=False,
                    mission_success=False, experimental_applied=False, **pos))
        for ep in episodes():
            if not (out / 'episodes' / (ep['episode_id'] + '.json')).exists():
                write_new(out / 'episodes' / (ep['episode_id'] + '_NOT_RUN.json'), dict(status='NOT_RUN', reason=status, **ep))
        unchanged = all(sha(OUTPUT_ROOT_D / p) == v for p, v in runtime.items())
        if not unchanged:
            status = 'INVALID_RUNTIME_MUTATION'
        write_new(out / 'RUNTIME_END.json', dict(runtime_sha256_unchanged=unchanged, CAL=0, TRAIN=0, fits=0,
            learned_governor_decisions=governor_calls, reference_attempts=reference_calls, branch_positions=branch_calls))
        budget.event('NUMERICAL_FINISHED', status=status)
        budget.close()
        write_new(out / 'RUN_FINISHED.json', dict(status=status, run_id=RUN_ID,
            finish_utc=datetime.now(timezone.utc).isoformat(), saved_positions=len(saved), budget=budget.snapshot()))
        print(dict(status=status, budget=budget.snapshot()), flush=True)

if __name__ == '__main__':
    run()
