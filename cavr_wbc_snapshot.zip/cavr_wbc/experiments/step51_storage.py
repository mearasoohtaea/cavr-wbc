"""Reuse frozen STEP50 evaluator and retain STEP51 block identities."""
from cavr_wbc.experiments.step50_storage import save_branch as source_save_branch, load_branch, not_run
from cavr_wbc.experiments.step51_io import write, sha

def save_branch(out, path, branch, c, packet):
    if (path / 'RESULT.json').exists():
        raise FileExistsError('current branch result cannot be overwritten')
    result = source_save_branch(out, path, branch, c, packet)
    result.update(block=c['block'], direction=c['direction'], severe=c['severe'],
                  step50_method_freeze_sha256=c['step50_method_freeze_sha256'],
                  step51_method_freeze_sha256=c['step51_method_freeze_sha256'],
                  source_split=c['source_split'])
    write(path / 'RESULT.json', result)
    receipt = dict(result_sha256=sha(path / 'RESULT.json'), observed=result['observed'],
                   actual_lengths=branch.get('counts'), numeric_redecode_not_yet_performed=True,
                   new_QP=0, new_steps=0)
    write(path / 'INCREMENTAL_RECEIPT.json', receipt)
    return result
