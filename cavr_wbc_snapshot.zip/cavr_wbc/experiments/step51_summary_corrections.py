"""One metadata correction from cached rows; no second readback or numerical work."""
from datetime import datetime,timezone
from shutil import copyfile
from cavr_wbc.experiments.step51_io import *
from cavr_wbc.experiments.step51_persistence import streaming_sha as sha

def run():
    out=output();receipt=out/'DERIVED_SUMMARY_CORRECTIONS.json'
    if receipt.exists():raise FileExistsError('summary correction already applied')
    rows=read(out/'BRANCH_ROWS.json');changes=[]
    folder=out/'summary_before_corrections';folder.mkdir(exist_ok=True)
    for name in ('RESULT.json','STEP51_RESULT.json'):
        p=out/name;r=read(p);before=sha(p);copyfile(p,folder/name)
        actual=sum(q['status']=='COMPLETE' for q in r['references'])
        old=r['endpoints']['independent_episode_sources']
        r['endpoints'].update(planned_independent_episode_sources=12,independent_episode_sources=actual,source_generation_incomplete=actual<12)
        r['summary_correction_receipt']='DERIVED_SUMMARY_CORRECTIONS.json'
        write(p,r);changes.append(dict(path=name,before_sha256=before,after_sha256=sha(p),old_independent_episode_sources=old,actual=actual,planned=12))
    p=out/'LATENCY.json';latency=read(p);copyfile(p,folder/p.name);before=sha(p);updated=[]
    by={r['id']:r for r in rows}
    for q in latency:
        r=by[q['id']]
        if q['kind']=='FIRST' and r.get('dispatched_unknown'):
            for key,source in (('complete_ms','first_packet_ready_ms'),('prepared_ms','first_packet_prepared_ms')):
                if q.get(key) is None and r.get(source) is not None:
                    q[key]=r[source];updated.append(dict(id=q['id'],field=key,value=q[key]))
            q['applied']=None
    write(p,latency);changes.append(dict(path=p.name,before_sha256=before,after_sha256=sha(p),updates=updated,UNKNOWN_application_preserved=True))
    write(receipt,dict(timestamp_utc=datetime.now(timezone.utc).isoformat(),changes=changes,
        scope='cached scalar summaries only; planned versus actual references and known UNKNOWN first-packet timing',
        original_summaries_preserved='summary_before_corrections',READBACK_VERDICT_unchanged=True,
        classification_S_M_V_unchanged=True,new_QP=0,new_steps=0,bank_decodes=0,readback_repetitions=0))
    print(dict(actual_references=actual,planned_references=12,known_UNKNOWN_timing_updates=len(updated),new_QP=0,new_steps=0))
if __name__=='__main__':run()
