"""Only the five new pure topics, with scoped repair receipts."""
import io
import sys
import unittest
from cavr_wbc.experiments.step51_io import *

def run(repair=None):
    from tests.test_step51_contract import Step51Contract
    out = output()
    receipt = out / 'tests/NECESSARY_TESTS.json'
    if receipt.exists() and not repair:
        raise FileExistsError('pure group already recorded')
    names = unittest.defaultTestLoader.getTestCaseNames(Step51Contract)
    suite = unittest.TestSuite(Step51Contract(n) for n in names if not repair or n.startswith('test_' + str(repair) + '_'))
    stream = io.StringIO()
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    document = dict(tests_run=result.testsRun, failures=len(result.failures), errors=len(result.errors),
        output=stream.getvalue(), failure_details=[text for _, text in result.failures + result.errors],
        real_QP_calls=0, MuJoCo_steps=0)
    if repair:
        old = read(receipt)
        if not (out / 'tests/INITIAL_GROUP_RESULT.json').exists():
            write_new(out / 'tests/INITIAL_GROUP_RESULT.json', old)
        write_new(out / ('tests/AFFECTED_TOPIC_' + str(repair) + '_REPAIR.json'), document)
        if result.wasSuccessful():
            # Preserve any other initially failed topics until they too pass.
            failures = old.get('failed_topics', [])
            remaining = [n for n in failures if n != repair]
            write(receipt, dict(tests_run=5, errors=len(remaining), failures=0, failed_topics=remaining,
                affected_topic_repaired=repair, real_QP_calls=0, MuJoCo_steps=0, initial='INITIAL_GROUP_RESULT.json'))
    else:
        document['failed_topics'] = sorted({int(case._testMethodName.split('_')[1]) for case, _ in result.failures + result.errors})
        write_new(receipt, document)
    print(stream.getvalue(), flush=True)
    if not result.wasSuccessful():
        raise SystemExit(1)

if __name__ == '__main__':
    run(int(sys.argv[1]) if len(sys.argv) > 1 else None)
