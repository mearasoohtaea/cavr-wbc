"""Job-local increments, global QP identity, and durable unknown-work bounds.

No numerical library is imported by this accounting module. Coordinator time
is supplied as one absolute active-segment deadline; a worker never renews it.
"""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import json
import math
import numbers
import time

def scalar_encode(value):
    if isinstance(value,dict): return {str(k):scalar_encode(v) for k,v in value.items()}
    if isinstance(value,(tuple,list)): return [scalar_encode(v) for v in value]
    if isinstance(value,Path): return str(value)
    if hasattr(value,'tolist'):
        if getattr(value,'size',0)>512:
            return dict(large_numeric_witness_in_raw_bank=True,shape=list(value.shape),dtype=str(value.dtype))
        return scalar_encode(value.tolist())
    if isinstance(value,numbers.Real) and not math.isfinite(float(value)): return {'nonfinite':str(value)}
    return value

class SprintLimit(RuntimeError):
    pass

QP_FIELDS = ('status','status_val','iterations','real_optimizer_called','primal_residual','dual_residual',
    'setup_time_s','update_time_s','update_settings_time_s','warm_start_wall_time_s','solve_time_s',
    'solve_wall_time_s','polish_time_s','polish_status','invoke_total_wall_time_s','warm_started',
    'workspace_reused','kernel_variant','osqp_time_limit_s','configured_native_time_limit_s',
    'solver_owner_id','solver_owner_scope','owner_pid','solve_wall_includes_polish',
    'end_to_end_hard_wall_cap_claim','candidate_valid','strict_candidate_mask','optimizer_converged',
    'candidate_certificate','configured_eps_abs','configured_eps_rel','actual_setup_eps_abs','actual_setup_eps_rel')

class WorkerBudget:
    def __init__(self, job, *, wall_clock=time.time, monotonic=time.perf_counter):
        self.out = Path(job['job_out']); self.out.mkdir(parents=True,exist_ok=True)
        self.job_id = job['job_id']; self.attempt_id = job['attempt_id']
        self.qp_offset = int(job['qp_offset'])
        self.qp_limit = int(job['remaining_QP']); self.step_limit = int(job['remaining_steps'])
        self.deadline_epoch_s = float(job['deadline_epoch_s'])
        if min(self.qp_offset,self.qp_limit,self.step_limit) < 0: raise ValueError('negative job quota')
        self._wall = wall_clock; self._monotonic = monotonic
        self.started = monotonic(); self.start_utc = datetime.now(timezone.utc).isoformat()
        self.local_qp_starts = self.returned = self.physics_steps = self.reserved = 0
        self.known_steps = self.reservation_id = self.unavailable_count = self.governor_started = 0
        self.qp_kinds = Counter(); self.step_kinds = Counter()
        self.tokens = {}; self._pending_direct = set()
        self.fit_count = self.dev_recomputations = self.risk_fit_count = 0
        self.path = self.out / 'WORKER_LEDGER.jsonl'
        self.stream = self.path.open('x',encoding='utf-8',newline='\n')
        self.event('WORKER_ACCOUNTING_STARTED', qp_offset=self.qp_offset, QP_limit=self.qp_limit,
                   integration_limit=self.step_limit, deadline_epoch_s=self.deadline_epoch_s)

    @property
    def qp_calls(self):
        # Frozen STEP35/37 controllers read this directly into raw QP identity.
        return self.qp_offset + self.local_qp_starts

    def start(self):
        return None  # One process clock already started at accounting creation.

    def event(self,event,**values):
        if event=='GOVERNOR_DECISION_START': self.governor_started+=1
        row = scalar_encode(dict(event=event,job_id=self.job_id,attempt_id=self.attempt_id,
            timestamp_utc=datetime.now(timezone.utc).isoformat(),**values))
        self.stream.write(json.dumps(row,sort_keys=True,allow_nan=False)+'\n')
        self.stream.flush()  # Durable process-exit boundary; no per-event fsync.

    def check(self):
        if self._wall() >= self.deadline_epoch_s: raise SprintLimit('global active-segment deadline')
        if self.local_qp_starts >= self.qp_limit: raise SprintLimit('job assigned QP remainder exhausted')
        if self.physics_steps + self.reserved >= self.step_limit: raise SprintLimit('job assigned integration remainder exhausted')

    def qp_callback(self,kind,owner,first_mode=None):
        active = {}
        def callback(stage,payload,solve):
            if stage == 'before':
                self.check(); self.local_qp_starts += 1; self.qp_kinds[kind] += 1
                active.clear(); active.update(global_qp_index=self.qp_calls,
                    local_qp_index=self.local_qp_starts,solver_local_qp_index=payload['solver_call_index'],
                    kind=kind,owner=owner,first_mode=first_mode)
                self.event('QP_START',**active)
                return solve()
            if stage != 'after' or not active: raise ValueError('QP callback START/RETURN identity')
            result = payload['result']; self.returned += 1
            result['step35_global_qp_index'] = active['global_qp_index']
            result['step37_global_qp_index'] = active['global_qp_index']
            self.event('QP_RETURN',**active,**{k:result.get(k) for k in QP_FIELDS})
        return callback

    def step_observer(self,kind,owner):
        key = (kind,owner)
        def before():
            self.check()
            if key in self._pending_direct: self.known_steps += 1
            self._pending_direct.add(key)
            self.physics_steps += 1; self.step_kinds[kind] += 1
            self.event('PHYSICS_STEP_PRECHARGED',kind=kind,owner=owner,
                charged_steps=self.physics_steps,known_min_steps=self.known_steps,
                integration_upper_bound=self.physics_steps+self.reserved)
        return before

    def reserve_steps(self,kind,owner,n):
        self.check()
        if int(n) != n or n < 0 or self.physics_steps+self.reserved+n > self.step_limit:
            raise SprintLimit('native reservation exceeds job assigned remainder')
        self.reservation_id += 1; token = self.reservation_id
        self.tokens[token]=(kind,owner,int(n)); self.reserved += int(n)
        self.event('PREFIX_NATIVE_START',reservation_id=token,kind=kind,owner=owner,reserved_steps=int(n))
        return token

    def finish_steps(self,token,actual_steps):
        if token not in self.tokens: raise ValueError('unknown native reservation identity')
        kind,owner,n=self.tokens[token]
        if int(actual_steps)!=actual_steps or not 0<=actual_steps<=n: raise ValueError('native step count identity')
        self.tokens.pop(token); self.reserved-=n
        self.physics_steps+=int(actual_steps); self.known_steps+=int(actual_steps)
        self.step_kinds[kind]+=int(actual_steps)
        self.event('PREFIX_NATIVE_RETURN',reservation_id=token,kind=kind,owner=owner,actual_steps=int(actual_steps),
                   charged_steps=self.physics_steps,known_min_steps=self.known_steps,
                   integration_upper_bound=self.physics_steps+self.reserved)

    def confirm_normal_return(self):
        # A complete return from the frozen numerical operation confirms its
        # final direct before-step charge. Exceptions retain the unknown bound.
        self.known_steps += len(self._pending_direct); self._pending_direct.clear()
        if self.known_steps != self.physics_steps: raise ValueError('integration counter identity')
        self.event('NUMERICAL_OPERATION_RETURNED',known_steps=self.known_steps,
                   unresolved_reserved_steps=self.reserved)

    def snapshot(self):
        return dict(new_QP_calls=self.local_qp_starts,QP_returns=self.returned,
            new_integration_steps=self.physics_steps,new_physics_steps=self.physics_steps,
            unknown_native_returns=self.local_qp_starts-self.returned,reserved_steps=self.reserved,
            known_min_integration_steps=self.known_steps,
            integration_upper_bound=self.physics_steps+self.reserved,
            pending_direct_steps=len(self._pending_direct),steps_precharged_before_call=True,
            qp_offset=self.qp_offset,global_QP_last=self.qp_calls,
            QP_by_kind=dict(self.qp_kinds),physics_by_kind=dict(self.step_kinds),
            worker_elapsed_s=self._monotonic()-self.started,deadline_epoch_s=self.deadline_epoch_s,
            governor_decisions_started=self.governor_started,fits=0,CAL=0,TRAIN=0)

    def persist(self,**extra):
        from cavr_wbc.experiments.step52_io import write
        self.stream.flush(); write(self.out/'PROGRESS.json',{**self.snapshot(),**extra})

    def record_raw(self,raw,kind,owner):
        from cavr_wbc.experiments.step47_io import save_numeric,relative
        if not raw.get('real_optimizer_called',True):
            self.unavailable_count += 1
            path=self.out/'unavailable_qp'/f'U{self.unavailable_count:06d}.json'
            result=save_numeric(path,dict(kind=kind,owner=owner,raw_result=raw,real_optimizer_called=False,new_QP_calls=0))
            self.event('REDUCTION_OR_WORKING_UNAVAILABLE',kind=kind,owner=owner,path=relative(path,self.out),new_QP_calls=0)
            return result
        ix=int(raw.get('step37_global_qp_index',raw.get('step35_global_qp_index',self.qp_calls)))
        if not self.qp_offset < ix <= self.qp_calls: raise ValueError('raw/global job QP identity')
        path=self.out/'raw_qp'/f'QP{ix:06d}.json'
        if path.exists(): raise FileExistsError('raw QP evidence cannot be overwritten')
        result=save_numeric(path,dict(global_qp_index=ix,local_qp_index=ix-self.qp_offset,
            kind=kind,owner=owner,raw_result=raw,captured_after_ready=True,new_QP_calls=0))
        self.event('RAW_QP_SAVED',global_qp_index=ix,path=relative(path,self.out),kind=kind,owner=owner,
                   json_sha256=result['json_sha256'],npz_sha256=result['npz_sha256'])
        self.persist(phase='RAW_QP_SAVED')
        return result

    def record_unavailable(self,raw,kind,owner):
        if raw.get('real_optimizer_called'): raise ValueError('real solve cannot be unavailable')
        return self.record_raw(dict(raw,real_optimizer_called=False),kind,owner)

    def register_fit(self,kind):
        raise ValueError('STEP52 forbids every CAL/TRAIN/fit')

    def close(self):
        self.persist(); self.stream.close()

def journal_bounds(path):
    """Recover conservative worker increments after a crash, without a bank."""
    starts=set(); returns=set(); reservations={}; charged=known=0; returned_native=0; header=False; torn=False
    if not Path(path).exists():
        return dict(zero_work_proven=False,unknown_consumption=True,new_QP_calls=None,
                    integration_upper_bound=None,reserved_steps=None)
    with Path(path).open(encoding='utf-8') as stream:
      for line in stream:
        try: r=json.loads(line)
        except json.JSONDecodeError:
            torn=True; continue  # Last torn line is not a zero-work proof.
        if r['event']=='WORKER_ACCOUNTING_STARTED': header=True
        if r['event']=='QP_START': starts.add(r['global_qp_index'])
        elif r['event']=='QP_RETURN': returns.add(r['global_qp_index'])
        elif r['event']=='PHYSICS_STEP_PRECHARGED':
            charged=max(charged,r['charged_steps']); known=max(known,r['known_min_steps'])
        elif r['event']=='PREFIX_NATIVE_START': reservations[r['reservation_id']]=r['reserved_steps']
        elif r['event']=='PREFIX_NATIVE_RETURN':
            reservations.pop(r['reservation_id'],None); returned_native+=r['actual_steps']
            charged=max(charged,r.get('charged_steps',returned_native))
            known=max(known,r.get('known_min_steps',returned_native))
        elif r['event']=='NUMERICAL_OPERATION_RETURNED': known=max(known,r['known_steps'])
    # charged values include already-returned native steps as the original
    # observer counter moves; add only native work not represented by charged.
    lower=max(known,returned_native); upper=max(charged,returned_native)+sum(reservations.values())
    return dict(new_QP_calls=len(starts),QP_returns=len(returns),unknown_native_returns=len(starts-returns),
                known_min_integration_steps=lower,integration_upper_bound=upper,
                reserved_steps=sum(reservations.values()),zero_work_proven=header and not torn and not starts and upper==0,
                journal_torn_line=torn,unknown_consumption=not header or torn)
