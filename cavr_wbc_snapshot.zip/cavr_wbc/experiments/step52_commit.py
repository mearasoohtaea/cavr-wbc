"""Explicit local STEP52 commit; large evidence remains locally with SHA paths."""
import json,os,subprocess
from datetime import datetime,timezone
from cavr_wbc.experiments.step52_io import *
OUTPUT_ROOT_D=ROOT
def output():return OUT


def invoke(*args):
    env=dict(os.environ)
    for k in ('GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_COMMON_DIR'):env.pop(k,None)
    return subprocess.check_output(['git','-C',str(OUTPUT_ROOT_D),*args],env=env,text=True,encoding='utf-8').strip()

def run():
    out=output();gd=OUTPUT_ROOT_D/'.git';receipt=gd/'STEP52_COMMIT_RECEIPT.json'
    if receipt.exists():raise FileExistsError('scoped commit receipt already exists')
    delivery=read(out/'DELIVERY_MANIFEST.json');manifest=read(out/'EVIDENCE_MANIFEST.json')
    if delivery['issues']:raise ValueError('delivery has issues')
    parent=invoke('rev-parse','HEAD');branch=invoke('branch','--show-current')
    if parent!=SOURCE_COMMIT or branch!='codex/step52-resource-isolated-step51-completion-20261013':raise ValueError('unexpected parent/branch')
    if invoke('diff','--cached','--name-only'):raise ValueError('existing staged changes must be preserved')
    paths=[OUTPUT_ROOT_D/'.gitattributes',OUTPUT_ROOT_D/'configs/validation/STEP52_PROTOCOL.md',OUTPUT_ROOT_D/'validation/EXECUTION_COMMANDS_STEP52.ps1']
    paths+=list(OUTPUT_ROOT_D.glob('cavr_wbc/experiments/step52*.py'))+list(OUTPUT_ROOT_D.glob('tests/test_step52*.py'))
    paths += [out/q['path'] for q in manifest['files'] if q['commit_scope']=='SCOPED_COMMIT']
    paths += [out/'EVIDENCE_MANIFEST.json',out/'DELIVERY_MANIFEST.json']
    names=sorted({str(p.relative_to(OUTPUT_ROOT_D)).replace('\\','/') for p in paths})
    if any(not (OUTPUT_ROOT_D/n).is_file() for n in names):raise ValueError('missing scoped file')
    for n in names:
        if not (n=='.gitattributes' or n.startswith(('cavr_wbc/experiments/step52','tests/test_step52','configs/validation/STEP52_PROTOCOL.md','validation/EXECUTION_COMMANDS_STEP52.ps1','artifacts/step52_step51_completion_20261013/'))):raise ValueError('out of scope '+n)
    scope=gd/'STEP52_SCOPE.paths';scope.write_bytes(b''.join(n.encode('utf-8')+b'\0' for n in names))
    invoke('add','--sparse','--pathspec-from-file='+str(scope),'--pathspec-file-nul')
    staged=invoke('diff','--cached','--name-only').splitlines()
    if set(staged)!=set(names):raise ValueError('staged scope differs from explicit plan')
    # No filters may change as-run bytes; compare staged blobs with disk once.
    raw=invoke('diff','--cached','--raw','--no-abbrev').splitlines()
    staged_ids={line.split('\t',1)[1]:line.split('\t',1)[0].split()[3] for line in raw}
    identity={}
    for start in range(0,len(names),40):
        batch=names[start:start+40];hashes=invoke('hash-object','--no-filters','--',*batch).splitlines()
        for name,digest in zip(batch,hashes):identity[name]=digest==staged_ids.get(name)
    if not all(identity.values()) or len(identity)!=len(names):raise ValueError('staged byte identity mismatch')
    result=invoke('-c','gc.auto=0','-c','maintenance.auto=false','commit','-m','STEP52 complete frozen STEP51 positions through serial process isolation')
    commit=invoke('rev-parse','HEAD')
    if invoke('rev-parse','HEAD^')!=parent:raise ValueError('unexpected commit parent')
    tracked_status=invoke('status','--porcelain=v1','--untracked-files=no')
    true_status=invoke('status','--porcelain=v1','--untracked-files=normal')
    large=[q for q in manifest['files'] if q['commit_scope']=='LOCAL_LARGE_EVIDENCE']
    value=dict(commit=commit,parent=parent,branch=branch,timestamp_utc=datetime.now(timezone.utc).isoformat(),
        scoped_paths=names,scoped_file_count=len(names),scoped_bytes=sum((OUTPUT_ROOT_D/n).stat().st_size for n in names),
        staged_blob_disk_identity_all=True,staged_blob_disk_identity=identity,
        tracked_git_status=tracked_status,real_git_status=true_status,
        large_evidence_committed=False,large_evidence_preserved=True,large_evidence_manifest=str(out/'EVIDENCE_MANIFEST.json'),
        evidence_manifest_sha256=sha(out/'EVIDENCE_MANIFEST.json'),locally_preserved_large_files=len(large),
        locally_preserved_large_bytes=sum(q['size_bytes'] for q in large),
        source_head=delivery['source_head'],source_index_sha256=delivery['source_index_sha256'],source_unchanged=True,
        numerical_status=delivery['completion']['status'],numerical_work_stopped=True,new_QP=0,new_steps=0,push=False,
        remotes=invoke('remote'),source_git_alternate=delivery['source_git_object_alternate'],source_object_dependency_declared=True,new_git_objects_in_D=True)
    receipt.write_text(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
    print(dict(commit=commit,scoped_files=len(names),tracked_status=tracked_status,large_files=len(large),large_bytes=value['locally_preserved_large_bytes'],receipt=str(receipt),push=False),flush=True)
    if tracked_status:raise ValueError('tracked files changed after commit; receipt preserves true state')
if __name__=='__main__':run()
