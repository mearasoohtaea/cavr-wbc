"""Serial fresh interpreter coordinator; no NumPy/MuJoCo/bank imports."""
import argparse,os,subprocess,sys,time,traceback
from cavr_wbc.experiments.step52_io import *
def journal(event,**v):append(OUT/'COORDINATOR_LEDGER.jsonl',dict(event=event,timestamp_utc=utc(),**v))
def freeze_execution():
    files=sorted(ROOT.glob('cavr_wbc/experiments/step52*.py'))+sorted(ROOT.glob('tests/test_step52*.py'))
    post={'step52_delivery.py','step52_report.py','step52_figures.py','step52_finalize.py','step52_commit.py'}
    hashes={str(p.relative_to(ROOT)).replace('\\','/'):sha(p) for p in files if p.name not in post}
    obj=dict(protocol_sha256=sha(PROTOCOL),source_commit=SOURCE_COMMIT,source_method_sha256=sha(SOURCE_RUN/'METHOD_INPUT_FREEZE.json'),
        source_step50_sha256=read(SOURCE_RUN/'METHOD_INPUT_FREEZE.json')['step50_method_freeze_sha256'],
        execution_code_sha256=hashes,scientific_contract_unchanged=True,active_clock_authorized_explicitly=True,
        cumulative_limits=dict(QP=QP_LIMIT,steps=STEP_LIMIT,replay=REPLAY_LIMIT,active_seconds=ACTIVE_LIMIT),
        old_consumption=dict(QP=OLD_QP,steps=OLD_STEPS,replay=OLD_REPLAY,active_seconds=OLD_ACTIVE),
        one_job_one_process=True,numerical_workers_concurrent=1,at_most_two_zero_numerical_startup_restarts=True)
    write_new(OUT/'EXECUTION_FREEZE.json',obj);return obj
def missing_delta(folder,job):
    if job['kind']=='RECOVERY':return dict(new_QP_calls=0,QP_returns=0,new_integration_steps=0,reserved_steps=0,integration_upper_bound=0,zero_numerical_proven=True,scope='RECOVERY_EVALUATOR_HAS_NO_NUMERICAL_DISPATCH')
    ledger=Path(folder)/'WORKER_LEDGER.jsonl';started=set();returned=set();direct=0;tokens={};completed=0;torn=False
    if ledger.exists():
        with ledger.open(encoding='utf-8') as f:
            for line in f:
                try:q=__import__('json').loads(line)
                except ValueError:torn=True;continue
                event=q['event']
                if event=='QP_START':started.add(q['global_qp_index'])
                elif event=='QP_RETURN':returned.add(q['global_qp_index'])
                elif event=='PREFIX_NATIVE_START':tokens[q['reservation_id']]=q['reserved_steps']
                elif event=='PREFIX_NATIVE_RETURN':tokens.pop(q['reservation_id'],None);completed+=q['actual_steps'];direct=max(direct,int(q.get('charged_steps',0)))
                elif event=='PHYSICS_STEP_PRECHARGED':direct=max(direct,int(q['charged_steps']))
    replay=Path(folder)/'REPLAY_STEPS.jsonl'
    if replay.exists():
        with replay.open(encoding='utf-8') as f:
            for line in f:
                try:q=__import__('json').loads(line)
                except ValueError:torn=True;continue
                if q['event']=='STEP_START':direct+=1
    progress=read(Path(folder)/'PROGRESS.json',{})
    qps=max(len(started),progress.get('new_QP_calls',0));steps=max(direct,completed,progress.get('new_integration_steps',0));reserved=max(sum(tokens.values()),progress.get('reserved_steps',0))
    # Every numerical call is journaled before entry. A missing ledger alone
    # cannot prove zero when numeric-body entry is unconfirmed.
    provable_zero=(Path(folder)/'WORKER_STARTED.json').exists() and not torn and qps==0 and steps==0 and reserved==0
    if torn or (not ledger.exists() and not replay.exists() and not provable_zero):
        qps=job['remaining_QP'];steps=job['remaining_steps'];reserved=0
    return dict(new_QP_calls=qps,QP_returns=len(returned),new_integration_steps=steps,reserved_steps=reserved,
        integration_upper_bound=steps+reserved,unknown_native_returns=qps-len(returned),reconstructed_from_flushed_journal=True,zero_numerical_proven=provable_zero,journal_torn_line=torn)
def run():
    if (OUT/'RUN_STARTED.json').exists():raise FileExistsError('coordinator segment already dispatched; no duplicate authorization')
    test=read(OUT/'tests/NECESSARY_TESTS.json')
    if not test or test.get('errors') or test.get('failures') or test.get('tests_run')!=4:raise ValueError('four pure topics must pass')
    plan=read(OUT/'COMPLETION_PLAN.json');f=freeze_execution();fsha=sha(OUT/'EXECUTION_FREEZE.json');started=time.perf_counter();epoch=time.time();deadline=epoch+(ACTIVE_LIMIT-OLD_ACTIVE)
    state=dict(new_QP=0,new_steps=0,new_replay_steps=0,QP_returns=0,unknown_QP=0,startup_restarts=0,numeric_resource_failures=0,governor_decisions=0,new_task_attempts=0,new_references=0)
    index={s['canonical_id']:dict(canonical_id=s['canonical_id'],position=s['position'],action=s['action'],
        origin_run=s['origin_run'],historical_UNKNOWN=s['historical_UNKNOWN'],old_result_path=s['old_result_path'],old_result_sha256=s['old_result_sha256'],
        result_path=s['old_result_path'] if s['action']=='REUSE_KNOWN' else None,
        canonical_status='REUSED_KNOWN' if s['action']=='REUSE_KNOWN' else 'UNKNOWN' if s['historical_UNKNOWN'] else 'NOT_DISPATCHED',
        segment='STEP51' if s['action']=='REUSE_KNOWN' else None,attempt_id='OLD_ATTEMPT1' if s['action']=='REUSE_KNOWN' else None) for s in plan['slots']}
    refs={r['episode_id']:dict(**r,origin='STEP51_REUSED') for r in plan['reference_sources']};attempts=[];status='PROCESSED_COMPLETE';stop_reason=None;active_job=None
    write_new(OUT/'RUN_STARTED.json',dict(pid=os.getpid(),timestamp_utc=utc(),segment_started_epoch=epoch,
        active_clock='OLD_ACTIVE + continuous elapsed from before first worker dispatch including zero-numerical recovery',
        OLD_ACTIVE=OLD_ACTIVE,remaining_seconds=ACTIVE_LIMIT-OLD_ACTIVE,deadline_epoch_s=deadline,resource=resource_snapshot()))
    def persist():
        elapsed=time.perf_counter()-started
        budget=dict(old_QP=OLD_QP,new_QP=state['new_QP'],total_QP_calls=OLD_QP+state['new_QP'],QP_returns=OLD_QP+state['QP_returns'],
            unknown_native_returns=state['unknown_QP'],old_steps=OLD_STEPS,new_total_integration_steps=state['new_steps'],total_physics_steps=OLD_STEPS+state['new_steps'],
            old_replay_steps=OLD_REPLAY,new_replay_steps=state['new_replay_steps'],total_replay_steps=OLD_REPLAY+state['new_replay_steps'],
            old_active_seconds=OLD_ACTIVE,resume_active_seconds=elapsed,total_active_seconds=OLD_ACTIVE+elapsed,
            QP_limit=QP_LIMIT,step_limit=STEP_LIMIT,replay_limit=REPLAY_LIMIT,active_seconds_limit=ACTIVE_LIMIT,
            global_clock_not_per_worker=True,new_CAL=0,new_TRAIN=0,new_fit=0,consumption_unknown_is_charged_conservatively=True)
        write(OUT/'PROGRESS.json',dict(**state,budget=budget,active_job=active_job,canonical_known=sum(v['result_path'] is not None for v in index.values()),
            canonical_UNKNOWN=sum(v['canonical_status']=='UNKNOWN' for v in index.values()),undispatched=sum(v['canonical_status']=='NOT_DISPATCHED' for v in index.values()),resource=resource_snapshot()))
        write(OUT/'COMPLETION_INDEX.json',list(index.values()));write(OUT/'REFERENCE_INDEX.json',list(refs.values()));write(OUT/'ATTEMPT_INDEX.json',attempts)
        return budget
    def guard():
        if time.perf_counter()-started>=ACTIVE_LIMIT-OLD_ACTIVE or state['new_QP']+OLD_QP>=QP_LIMIT or state['new_steps']+OLD_STEPS>=STEP_LIMIT:raise RuntimeError('CUMULATIVE_BUDGET_STOP')
    def dispatch(kind,job_id,extra,module='cavr_wbc.experiments.step52_worker'):
        nonlocal active_job
        infra=0
        while True:
            guard();name=job_id+(f'_INFRA{infra}' if infra else '');folder=OUT/'jobs'/name
            active_job=name;folder.mkdir(parents=True,exist_ok=True)
            job=dict(job_id=name,kind=kind,job_out=str(folder),qp_offset=OLD_QP+state['new_QP'],remaining_QP=QP_LIMIT-OLD_QP-state['new_QP'],
                remaining_steps=STEP_LIMIT-OLD_STEPS-state['new_steps'],deadline_epoch_s=deadline,
                source_config_path=str(OUT/'source_metadata/SOURCE_FROZEN_CONFIG.json'),source_freeze_path=str(OUT/'source_metadata/METHOD_INPUT_FREEZE.json'),
                contract_path=str(OUT/'source_metadata/STEP48_CAL_FREEZE.json'),bundle_path=str(OUT/'models/PHASE_MATCHED_TASK.npz'),
                domain_path=str(OUT/'models/PHASE_MATCHED_TASK_DOMAIN.json'),source_method_sha=f['source_method_sha256'],source_step50_sha=f['source_step50_sha256'],
                execution_freeze_sha=fsha,**extra)
            write_new(folder/'JOB.json',job);before=resource_snapshot()
            if kind=='BRANCH' and infra==0:
                state['new_task_attempts']+=1
                if state['new_task_attempts']>124:raise ValueError('max new task attempts')
                index[extra['canonical_id']].update(canonical_status='UNKNOWN',result_path=None,segment='STEP52_RESOURCE_ISOLATED',attempt_id=extra['attempt_id'],origin_run=str(OUT),job_id=name)
            journal('WORKER_DISPATCH',job_id=name,kind=kind,resource_before=before)
            with (folder/'PROCESS.log').open('x',encoding='utf-8') as stream:
                child=subprocess.Popen([sys.executable,'-B','-X','utf8','-m',module,'--job',str(folder/'JOB.json')],cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT)
                pid=child.pid
                try:code=child.wait(timeout=max(.01,ACTIVE_LIMIT-OLD_ACTIVE-(time.perf_counter()-started)))
                except subprocess.TimeoutExpired:
                    journal('HARD_TIMEOUT_KILL',job_id=name,pid=pid);child.kill();code=child.wait()
                finally:
                    # wait() completed; close OS process handle before next spawn.
                    if getattr(child,'_handle',None) is not None:child._handle.Close()
            after=resource_snapshot();receipt=read(folder/'WORKER_RECEIPT.json')
            if receipt is None:receipt=dict(status='RESOURCE_FAILURE' if code else 'UNKNOWN',budget=missing_delta(folder,job),missing_worker_receipt=True)
            delta=receipt['budget'];q=int(delta['new_QP_calls']);steps=int(delta.get('integration_upper_bound',delta['new_integration_steps']+delta.get('reserved_steps',0)))
            if not 0<=q<=job['remaining_QP'] or not 0<=steps<=job['remaining_steps']:raise ValueError('worker increment exceeds delegated budget')
            state['new_QP']+=q;state['QP_returns']+=int(delta.get('QP_returns',0));state['unknown_QP']+=int(delta.get('unknown_native_returns',q-delta.get('QP_returns',0)));state['new_steps']+=steps
            if kind=='REPLAY':state['new_replay_steps']+=steps
            if kind=='BRANCH':state['governor_decisions']+=int(receipt.get('actual_governor_call',False))
            attempt=dict(job_id=name,kind=kind,pid=pid,exit_code=code,receipt_path=str(folder/'WORKER_RECEIPT.json') if (folder/'WORKER_RECEIPT.json').exists() else None,
                status=receipt['status'],budget_increment=delta,resource_before=before,resource_after_exit=after,process_exited=True,handles_closed=True,
                canonical_id=extra.get('canonical_id'),attempt_id=extra.get('attempt_id'),segment='STEP52_RESOURCE_ISOLATED')
            attempts.append(attempt);journal('WORKER_EXIT',**attempt);persist()
            bad=receipt['status'] in ('RESOURCE_FAILURE','STARTUP_FAILURE')
            if bad and q==0 and steps==0 and state['startup_restarts']<2:
                state['startup_restarts']+=1;infra+=1;journal('ZERO_NUMERICAL_STARTUP_RESTART',job_id=name,persistent_restart_count=state['startup_restarts'],proved_QP=0,proved_steps=0,worker_exited=True,resource_after_exit=after);persist();continue
            if bad:
                if q or steps:state['numeric_resource_failures']+=1
                if state['numeric_resource_failures']>=2 or (q==0 and steps==0):raise RuntimeError('RESOURCE_STOP_SECOND_NUMERICAL_JOB_OR_SINGLE_CASE_INITIALIZATION')
            if receipt['status'] in ('IDENTITY_ERROR','IDENTITY_OR_INTERFACE_ERROR'):raise ValueError('SCIENTIFIC_IDENTITY_OR_EVALUATION_ERROR')
            if receipt['status']=='BUDGET_STOP':raise RuntimeError('CUMULATIVE_BUDGET_STOP')
            active_job=None
            print(dict(job=name,status=receipt['status'],new_QP=state['new_QP'],new_steps=state['new_steps'],active_s=round(time.perf_counter()-started,2)),flush=True)
            return receipt
    def branch(slot,attempt_id):
        p=slot['position'];episode=refs.get(p['episode'])
        if episode is None:raise ValueError('reference must exist before branch')
        context=next(c for c in read(OUT/'source_metadata/METHOD_INPUT_FREEZE.json')['plans'] if c['context_id']==p['context_id'])
        r=dispatch('BRANCH',slot['canonical_id']+'_'+attempt_id,dict(position=p,context_plan=context,canonical_id=slot['canonical_id'],attempt_id=attempt_id,
            episode_path=episode['path'],episode_sha256=episode['json_sha256'],episode_npz_sha256=episode['npz_sha256']))
        entry=index[slot['canonical_id']];entry.update(result_path=r.get('result_path'),canonical_status='KNOWN_ATTEMPT_RESULT' if r.get('result_path') and not read(r['result_path'])['status'].startswith('UNKNOWN') else 'UNKNOWN',
            segment='STEP52_RESOURCE_ISOLATED',attempt_id=attempt_id,origin_run=str(OUT),job_id=r.get('job_id'))
        persist()
    try:
        unknown43=next(s for s in plan['unknown'] if s['position']['position_ordinal']==43);old=read(SOURCE_RUN/'BRANCH_ROWS.json');row=next(r for r in old if r['id']==unknown43['position']['id'])
        path=Path(unknown43['old_result_path']).parent;expected={n:v['sha256'] for n,v in row['orphan_evidence_preserved'].items()}
        # PACKET/context are metadata/typed indexes; orphan bank expected hashes
        # come from the already recorded source manifest rather than a guess.
        source_hashes={q['path']:q['sha256'] for q in read(SOURCE_RUN/'EVIDENCE_MANIFEST.json')['files']}
        for n in ('PACKET.json','POLICY_CONTEXT.json'):expected[n]=source_hashes[str((path/n).relative_to(SOURCE_RUN)).replace('\\','/')]
        recovered=dispatch('RECOVERY','SLOT0044_RECOVERY',dict(position=unknown43['position'],canonical_id='SLOT0044',attempt_id='DERIVED_OLD_ATTEMPT1',source_result_path=unknown43['old_result_path'],orphan_sha256=expected),module='cavr_wbc.experiments.step52_recovery')
        if recovered['status']=='RECOVERED_FROM_SAVED_EVIDENCE':index['SLOT0044'].update(result_path=recovered['result_path'],canonical_status='RECOVERED_FROM_SAVED_EVIDENCE',segment='STEP51_DERIVED_RECOVERY',attempt_id='DERIVED_OLD_ATTEMPT1',origin_run=str(SOURCE_RUN))
        else:branch(unknown43,'ATTEMPT2')
        persist()
        if state['new_replay_steps']+OLD_REPLAY+2000>REPLAY_LIMIT:raise RuntimeError('REPLAY_BUDGET_STOP')
        replay=dispatch('REPLAY','REPLAY_DEV0_GOV_ATTEMPT2',dict(attempt_id='REPLAY_ATTEMPT2'),module='cavr_wbc.experiments.step52_replay')
        write_new(OUT/'REPLAY_COMPLETION.json',dict(new_result_path=replay.get('replay_path'),old_results_path=str(SOURCE_RUN/'replay_continuation/REPLAY_RESULT.json'),old_UNKNOWN_preserved=True,three_MATCH_not_repeated=True))
        branch(next(s for s in plan['unknown'] if s['position']['position_ordinal']==53),'ATTEMPT2')
        for ep in read(OUT/'source_metadata/METHOD_INPUT_FREEZE.json')['episodes'][3:]:
            if ep['episode_id'] not in refs:
                state['new_references']+=1
                r=dispatch('REFERENCE','REF_'+ep['episode_id']+'_ATTEMPT1',dict(episode=ep,attempt_id='REFERENCE_ATTEMPT1'))
                if not r.get('episode_path'):raise RuntimeError('REFERENCE_RESULT_UNKNOWN')
                p=Path(r['episode_path']);refs[ep['episode_id']]=dict(episode_id=ep['episode_id'],path=str(p),json_sha256=sha(p),npz_sha256=sha(p.with_suffix('.npz')),origin='STEP52_REFERENCE')
            for slot in plan['pending']:
                if slot['position']['episode']==ep['episode_id']:branch(slot,'ATTEMPT1')
        if state['governor_decisions']>22:raise ValueError('more than 22 new governor calls')
        if any(v['canonical_status']=='NOT_DISPATCHED' for v in index.values()):status='INCOMPLETE_UNDISPATCHED'
        elif any(v['canonical_status']=='UNKNOWN' for v in index.values()):status='PROCESSED_WITH_UNKNOWN'
    except BaseException as e:
        status='INVALID_IDENTITY' if isinstance(e,ValueError) else 'INCOMPLETE_STOP';stop_reason=dict(type=type(e).__name__,error=str(e),traceback=traceback.format_exc(),active_job=active_job);write_new(OUT/'INTERRUPTION.json',stop_reason)
    finally:
        budget=persist();unchanged=all(sha(ROOT/p)==h for p,h in f['execution_code_sha256'].items())
        journal('NUMERICAL_FINISHED',status=status,budget=budget,execution_frozen_unchanged=unchanged)
        write_new(OUT/'RUN_FINISHED.json',dict(status=status,budget=budget,state=state,stop_reason=stop_reason,execution_frozen_unchanged=unchanged,
            canonical_known=sum(v['result_path'] is not None and v['canonical_status']!='UNKNOWN' for v in index.values()),
            UNKNOWN=sum(v['canonical_status']=='UNKNOWN' for v in index.values()),undispatched=sum(v['canonical_status']=='NOT_DISPATCHED' for v in index.values()),
            finish_utc=utc(),history_STEP51_unchanged=True))
    print(dict(final_status=status,new_QP=state['new_QP'],new_steps=state['new_steps'],stop_reason=stop_reason),flush=True)
if __name__=='__main__':run()
