"""One final streaming STEP52 readback, one current bank at a time, zero solve."""
import argparse,csv,json,os,subprocess,sys
from pathlib import Path
from cavr_wbc.experiments.step52_io import ROOT,OUT,SOURCE_RUN,SOURCE_ROOT,read as metadata_read,sha,write_new,utc,install_streaming
from cavr_wbc.experiments.step47_io import read,write,encode,load_numeric
from cavr_wbc.experiments.step50_storage import load_branch
from cavr_wbc.evaluation.step50_actual import evaluate
from cavr_wbc.control.step50_policy import mission_reference,internal_plan
from cavr_wbc.control.step50_dispatch import first_sent
def typed_write_new(path,value):
    if Path(path).exists():raise FileExistsError('do not overwrite readback evidence '+str(path))
    write(path,value)
def same(a,b):return json.dumps(encode(a),sort_keys=True)==json.dumps(encode(b),sort_keys=True)
def inspect_task(entry,dest):
    pos=entry['position'];out=OUT;local=[];rows=[];latency=[];series=[];used_raw=set()
    if entry.get('result_path'):
        r=read(entry['result_path']);path=Path(r.get('source_branch_path') or str(Path(entry['result_path']).parent))
    else:
        path=OUT/'jobs'/entry['job_id'] if entry.get('job_id') else None
        r=dict(status='UNKNOWN' if entry['canonical_status']=='UNKNOWN' else 'NOT_RUN',observed=False,experimental_applied=None if entry['canonical_status']=='UNKNOWN' else False,
            evaluation={},complete_2001=False,mission_success=False,reason=dict(reason=entry['canonical_status']))
    row={**pos,**{k:v for k,v in r.items() if k not in ('capacity','artifact','controls_numeric','evaluation')}}
    if entry.get('job_id'):row['actual_governor_call']=bool(read(OUT/'jobs'/entry['job_id']/'WORKER_RECEIPT.json',{}).get('actual_governor_call'))
    raw_root=SOURCE_RUN if entry['segment']=='STEP51_DERIVED_RECOVERY' else path
    if path is None:
        row.update(observed=False,phase1_complete=False,phase1_gate_pass=False,experimental_applied=False,learner_approved=False,selected_command_sent=False,
            handoff_committed=False,continuity_pass=False,late=False,actual_governor_call=False,last_available_is_not_filled=True)
        latency.append(dict(id=pos['id'],arm=pos['arm'],health_kind=pos['health_kind'],slot=1,kind='FIRST',complete_ms=None,prepared_ms=None,applied=False,callback_ms=None))
        rows.append(row)
    else:
        row.update(r.get('evaluation',{}));row['phase1_complete']=row.get('phase1',{}).get('complete',False)
        if r['status'].startswith('UNKNOWN'):
            row['dispatched_unknown']=True;row['experimental_applied']=None
            row['orphan_evidence_preserved']={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in path.glob('*') if p.name in ('actual.npz','controls.json','controls.npz')}
        row['phase1_gate_pass']=row.get('phase1',{}).get('pass',False)
        row['forced_recovery_gate']=internal_plan(pos['arm'])!='IMMEDIATE_MISSION'
        row['handoff_committed']=bool(r.get('handoff') and r['handoff'].get('staging_committed'))
        row['continuity_pass']=bool(r.get('continuity_start')==r.get('continuity_end') and r.get('continuity_start') is not None)
        reason=(r.get('reason') or {}).get('reason','')
        row['late']=bool('DEADLINE'in reason or 'LATE'in reason or
            (r.get('first_packet_prepared_ms') is not None and r['first_packet_prepared_ms']>17) or
            (r.get('first_packet_ready_ms') is not None and r['first_packet_ready_ms']>20))
        row['capacity_first_99_s']=r.get('capacity',{}).get('first_actual_99percent_s')
        packet_path=path/'PACKET.json'
        if packet_path.exists():
            packet=load_numeric(packet_path);c=load_numeric(path/'POLICY_CONTEXT.json')
            sent=first_sent(packet,c)
            row['actual_governor_call']=packet.get('dispatch_kind')=='LEARNED_GOVERNOR' and packet['status']!='SOURCE_INELIGIBLE'
            row['governor_action_rejections']={g:{k:e.get(k) for k in ('evaluation_status','rejection_reasons','terminal_domain','cal_physical_consensus')}
                for g,e in packet.get('actions',{}).items()}
            for key in ('model_authorized','learner_approved','governor_selected','selected_command_sent','nominal_sent'):
                if row.get('dispatched_unknown'):
                    row[key]=bool(packet.get(key))
                elif bool(r.get(key))!=bool(packet.get(key)):local.append('actual authorization field '+key)
            if row.get('dispatched_unknown'):
                row['first_packet_ready_ms']=packet.get('command_ready_ms')
                row['first_packet_prepared_ms']=packet.get('prepared_commit_ms')
            if r.get('observed') and not sent:local.append('uncommitted first packet propagated')
            if c['step48_method_freeze_sha256']!=read(OUT/'source_metadata/METHOD_INPUT_FREEZE.json')['step48_method_freeze_sha256'] or c['policy_contract']!=read(OUT/'source_metadata/STEP48_CAL_FREEZE.json')['methods']['PHASE_MATCHED_TASK']['policy_contract']:
                local.append('frozen TASK binding changed')
            if packet['policy_version']!='TASK_AWARE_1MM_06S_V1':local.append('source policy version replaced by composite')
        if r.get('observed'):
            c=load_numeric(path/'POLICY_CONTEXT.json');packet=load_numeric(path/'PACKET.json');branch=load_branch(path)
            lab=evaluate(branch,c,packet)
            if not same(lab,r['evaluation']):local.append('frozen evaluation mismatch')
            expected_fact_sha=(r.get('artifact') or {}).get('sha256') or r.get('source_hashes',{}).get('actual.npz')
            if expected_fact_sha is None or sha(path/'actual.npz')!=expected_fact_sha:local.append('fact bank SHA mismatch')
            for filename,digest in r.get('source_hashes',{}).items():
                if sha(path/filename)!=digest:local.append('derived source SHA mismatch '+filename)
            if not same(branch['phase1_online_summary'],lab['phase1']):local.append('online phase1 gate mismatch')
            if branch['continuity_start']!=branch['continuity_end']:local.append('owner/plant/PID continuity mismatch')
            if not branch.get('application_identity_pass'):local.append('application state identity mismatch')
            h=r.get('handoff')
            if h:
                if h['logical_slot']!=49 or abs(h['physical_time_s']-1.)>1e-9 or abs(h['physical_time_after_transaction_s']-1.)>1e-9:local.append('handoff physical/logical clock mismatch')
                if h.get('gate') and not same(h['gate'],lab['phase1']):local.append('handoff prefix gate mismatch')
                if (not h['gate_accepted'] or h['late']) and (h['new_feedback_QP_calls']!=0 or h['staging_committed']):local.append('gate rejected/late but numerical dispatch occurred')
            dense=([branch['initial_fact']] if branch.get('initial_fact') else [])+branch['physics_trajectory']
            continuous=[]
            goal=float(c['nominal_q_init'][0])+float(c['nominal_d_m']);anchor=float(c['backup_anchor_q_init'][0])
            for f in dense:
                if 'qpos'in f:continuous.append(dict(time_s=f['time_s'],physics_step=f['physics_step'],
                    base_x_m=f['qpos'][0],vx_m_s=f['qvel'][0],goal_m=goal,anchor_m=anchor,
                    signed_D_m=c['direction']*(f['qpos'][0]-anchor),goal_error_m=f['qpos'][0]-goal))
            series.append(dict(id=pos['id'],snapshot_id=pos['snapshot_id'],episode=pos['episode'],tick=pos['tick'],
                health_kind=pos['health_kind'],arm=pos['arm'],status=r['status'],complete=r['complete_2001'],goal_m=goal,anchor_m=anchor,series=continuous))
            if len(branch['checkpoints'])!=sum('qpos' in f and not f.get('numerical_failure') and f['physics_step'] in range(0,2001,25) for f in dense):local.append('long/partial landmark grid mismatch')
            latency.append(dict(id=pos['id'],arm=pos['arm'],health_kind=pos['health_kind'],slot=1,kind='FIRST',
                complete_ms=packet['command_ready_ms'],prepared_ms=packet['prepared_commit_ms'],applied=r['experimental_applied'],callback_ms=None))
            for ctrl in branch['controls']:
                if ctrl['slot']<=1:continue
                t=ctrl.get('timing',{});ref=ctrl.get('backup_reference')
                applied=ctrl.get('tau_applied') is not None
                prep=(ctrl.get('prepare_callback') or {})
                physical_time=ctrl['slot']*.02
                if applied:
                    plan=internal_plan(pos['arm'])
                    active=(plan=='IMMEDIATE_MISSION' and physical_time>=.04) or (plan in ('MIDDLE_RECOVER_RESUME','B_RECOVER_RESUME') and physical_time>=1.)
                    expected=mission_reference(anchor,goal,plan,physical_time,active)
                    if ref is None or any(abs(float(ref[k])-float(expected[k]))>1e-12 for k in ('p_ref_m','v_ref_m_s','a_ref_m_s2')):local.append('actual reference mismatch slot '+str(ctrl['slot']))
                    if ctrl['slot']-1!=ctrl['backup_feedback_logical_slot']:local.append('feedback logical slot reset')
                    if physical_time>=1. and expected['phase_policy_id']!='TASK_AWARE_1MM_06S_V1' and ctrl.get('phase_policy_id')!=expected['phase_policy_id']:local.append('phase2 mislabelled old policy')
                latency.append(dict(id=pos['id'],arm=pos['arm'],health_kind=pos['health_kind'],slot=ctrl['slot'],
                    kind='HANDOFF' if ctrl['slot']==50 else 'FEEDBACK',complete_ms=ctrl['command_ready_ms'],
                    prepared_ms=t.get('prepared_commit_ms'),applied=applied,callback_ms=prep.get('callback_ms'),
                    native_QP_limit_s=ctrl.get('native_QP_limit_s')))
                if ctrl.get('raw_solver_evidence'):used_raw.add(str(raw_root/ctrl['raw_solver_evidence']))
            del branch,packet,c,dense
        else:
            row['late']=row['late'] or reason=='EXPERIMENT_LATE_UNAPPLIED'
            latency.append(dict(id=pos['id'],arm=pos['arm'],health_kind=pos['health_kind'],slot=1,kind='FIRST',
                complete_ms=row.get('first_packet_ready_ms'),prepared_ms=row.get('first_packet_prepared_ms'),applied=False,callback_ms=None))
        row['last_available_is_not_filled']=True;rows.append(row)
    row.update(canonical_id=entry['canonical_id'],canonical_status=entry['canonical_status'],origin_run=entry['origin_run'],segment=entry.get('segment') or 'UNOBSERVED',attempt_id=entry.get('attempt_id'),historical_UNKNOWN=entry['historical_UNKNOWN'])
    if row['status'].startswith('UNKNOWN'):row['experimental_applied']=None
    for q in latency:q['segment']=row['segment']
    for q in series:q['segment']=row['segment']
    for p in used_raw:
        if not Path(p).exists():local.append('control raw reference missing '+p)
    typed_write_new(dest/'ROW.json',row);typed_write_new(dest/'LATENCY.json',latency);typed_write_new(dest/'SERIES.json',series)
    write_new(dest/'RECEIPT.json',dict(status='MATCH' if not local else 'MISMATCH',issues=local,id=pos['id'],new_QP=0,new_steps=0,bank_decoded=int(bool(r.get('observed'))),used_raw_paths=list(used_raw)))
def inspect_raw(job_path,dest):
    job=read(job_path);path=Path(job['job_out']);ledger=path/'WORKER_LEDGER.jsonl';issues=[];starts=set();returns=set();raw=[];owners={};events=[]
    if ledger.exists():
        with ledger.open(encoding='utf-8') as stream:
            for line in stream:
                try:q=json.loads(line)
                except ValueError:issues.append('torn ledger line');continue
                if q['event']=='QP_START':starts.add(q['global_qp_index'])
                elif q['event']=='QP_RETURN':returns.add(q['global_qp_index']);owners[q['global_qp_index']]=q.get('solver_owner_id')
                elif q['event']=='RAW_QP_SAVED':events.append(q)
        for q in events:
            p=path/q['path']
            if sha(p)!=q['json_sha256'] or sha(p.with_suffix('.npz'))!=q['npz_sha256']:issues.append('raw SHA '+q['path'])
            r=load_numeric(p);ix=r['global_qp_index'];raw.append(ix)
            if ix not in returns or r['raw_result'].get('solver_owner_id')!=owners[ix]:issues.append('raw owner/index '+str(ix))
            del r
    worker=read(path/'WORKER_RECEIPT.json',{});known=worker.get('status')=='KNOWN'
    if known and (starts!=returns or set(raw)!=starts or len(raw)!=len(starts)):issues.append('known START/RETURN/raw counts')
    if len(starts)!=worker.get('budget',{}).get('new_QP_calls',len(starts)):issues.append('QP receipt increment')
    if job['kind']=='REPLAY':
        for p in path.glob('*_DENSE.json'):
            value=load_numeric(p)
            if len(value['dense'])!=2001 or any(r['physics_step']!=i for i,r in enumerate(value['dense'])):issues.append('replay 2001 dense/grid')
            del value
        for p in path.glob('*_INPUT.json'):
            value=load_numeric(p)
            if len(value.get('controls',[]))!=200:issues.append('replay controls200')
            del value
    if job['kind']=='REFERENCE' and worker.get('episode_path'):
        ep=load_numeric(worker['episode_path']);requested=job['episode']['snapshot_ticks']
        actual=[s['source_tick'] for s in ep['snapshots']]
        if ep['episode_id']!=job['episode']['episode_id'] or any(t not in requested for t in actual):issues.append('reference identity/tick')
        if ep['status']=='COMPLETE' and (ep['counts']['physical_steps']!=1100 or len(ep['controls'])!=110 or actual!=requested):issues.append('complete reference count')
        del ep
    write_new(dest/'RAW_RECEIPT.json',dict(status='MATCH' if not issues else 'MISMATCH',issues=issues,job_id=job['job_id'],started=sorted(starts),returned=sorted(returns),decoded_raw=raw,known_outcome=known,new_QP=0,new_steps=0))
def child(entry_path=None,job_path=None,dest=None):
    install_streaming();dest=Path(dest);dest.mkdir(parents=True,exist_ok=True)
    if entry_path:inspect_task(read(entry_path),dest)
    else:inspect_raw(job_path,dest)
def run(resume=False):
    if (OUT/'READBACK_VERDICT.json').exists():raise FileExistsError('unique readback already finalized')
    if (OUT/'READBACK_STARTED.json').exists() and not resume:raise FileExistsError('use documented resume for the same interrupted readback')
    if resume and not (OUT/'READBACK_REPAIR.json').exists():raise ValueError('postprocessing repair receipt required')
    finish=read(OUT/'RUN_FINISHED.json');index=read(OUT/'COMPLETION_INDEX.json');attempts=read(OUT/'ATTEMPT_INDEX.json')
    if not resume:write_new(OUT/'READBACK_STARTED.json',dict(timestamp_utc=utc(),new_QP=0,new_steps=0,source_known_banks_reused_by_frozen_hash=True,short_process_each_new_task=True))
    else:
        marker=OUT/'READBACK_RESUMED.json'
        if marker.exists():
            n=2
            while (OUT/f'READBACK_RESUMED_{n}.json').exists():n+=1
            if not (OUT/f'READBACK_REPAIR_{n+1}.json').exists():raise ValueError('additional documented postprocessing repair required')
            marker=OUT/f'READBACK_RESUMED_{n}.json'
        write_new(marker,dict(timestamp_utc=utc(),same_readback_session=True,successful_receipts_reused=True,new_QP=0,new_steps=0))
    folder=OUT/'readback';folder.mkdir(exist_ok=True);issues=[];rows=[];latency=[];series=[];raw_ids=[];raw_decoded_known=0;fact_banks=0;old_hashes_checked=0
    oldrows={r['id']:r for r in read(SOURCE_RUN/'BRANCH_ROWS.json')};oldlatency=read(SOURCE_RUN/'LATENCY.json')
    for entry in index:
        dest=folder/entry['canonical_id'];dest.mkdir(exist_ok=True)
        if entry['canonical_status']=='REUSED_KNOWN' and (dest/'RECEIPT.json').exists():
            r=read(entry['old_result_path']);old_hashes_checked+=int(bool(r.get('artifact')))+2*int(bool(r.get('controls_numeric')))
            rows.append({**oldrows[entry['position']['id']],**{k:entry[k] for k in ('canonical_id','canonical_status','origin_run','segment','attempt_id','historical_UNKNOWN')}})
            latency.extend({**q,'segment':'STEP51'} for q in oldlatency if q['id']==entry['position']['id'])
            continue
        if entry['canonical_status']!='REUSED_KNOWN' and (dest/'RECEIPT.json').exists():
            receipt=read(dest/'RECEIPT.json');rows.append(read(dest/'ROW.json'));latency.extend(read(dest/'LATENCY.json'));series.extend(read(dest/'SERIES.json'));issues.extend(entry['canonical_id']+': '+v for v in receipt['issues']);fact_banks+=receipt['bank_decoded'];continue
        if entry['canonical_status']=='REUSED_KNOWN':
            if sha(entry['old_result_path'])!=entry['old_result_sha256']:issues.append('old result SHA '+entry['canonical_id'])
            r=read(entry['old_result_path']);path=Path(entry['old_result_path']).parent
            for key in ('artifact','controls_numeric'):
                value=r.get(key)
                if not value:continue
                if key=='artifact':
                    if sha(path/'actual.npz')!=value['sha256']:issues.append('old fact SHA '+entry['canonical_id'])
                    old_hashes_checked+=1
                else:
                    if sha(path/'controls.json')!=value['json_sha256'] or sha(path/'controls.npz')!=value['npz_sha256']:issues.append('old control SHA '+entry['canonical_id'])
                    old_hashes_checked+=2
            row={**oldrows[entry['position']['id']],**{k:entry[k] for k in ('canonical_id','canonical_status','origin_run','segment','attempt_id','historical_UNKNOWN')}}
            rows.append(row);latency.extend({**q,'segment':'STEP51'} for q in oldlatency if q['id']==row['id'])
            write_new(dest/'RECEIPT.json',dict(status='MATCH',scope='SOURCE_REUSED_KNOWN_FROZEN_HASH_AND_PRIOR_READBACK',old_result_sha256=entry['old_result_sha256'],new_QP=0,new_steps=0,bank_decoded=0))
        else:
            e=dest/'ENTRY.json'
            if not e.exists():write_new(e,entry)
            log=dest/('PROCESS_RESUMED.log' if (dest/'PROCESS.log').exists() else 'PROCESS.log')
            with log.open('x',encoding='utf-8') as stream:
                process=subprocess.Popen([sys.executable,'-B','-X','utf8','-m','cavr_wbc.experiments.step52_delivery','--entry',str(e),'--dest',str(dest)],cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT);code=process.wait()
                if getattr(process,'_handle',None) is not None:process._handle.Close()
            receipt=read(dest/'RECEIPT.json')
            if receipt is None:raise RuntimeError('readback task failed '+entry['canonical_id']+' code '+str(code))
            rows.append(read(dest/'ROW.json'));latency.extend(read(dest/'LATENCY.json'));series.extend(read(dest/'SERIES.json'));issues.extend(entry['canonical_id']+': '+s for s in receipt['issues']);fact_banks+=receipt['bank_decoded']
        if len(rows)%16==0:print(dict(readback_positions=len(rows),planned=176,new_QP=0,new_steps=0),flush=True)
    for a in attempts:
        job=OUT/'jobs'/a['job_id']/'JOB.json'
        if a['kind'] not in ('REFERENCE','BRANCH','REPLAY'):continue
        dest=folder/('RAW_'+a['job_id']);dest.mkdir(exist_ok=True)
        if (dest/'RAW_RECEIPT.json').exists():
            q=read(dest/'RAW_RECEIPT.json');issues.extend(a['job_id']+': '+s for s in q['issues']);raw_ids.extend(q.get('verified_raw',q['decoded_raw']));raw_decoded_known+=len(q['decoded_raw']);continue
        log=dest/('PROCESS_RESUMED_HEADER.log' if (dest/'PROCESS.log').exists() else 'PROCESS.log')
        with log.open('x',encoding='utf-8') as stream:
            process=subprocess.Popen([sys.executable,'-B','-X','utf8','-m','cavr_wbc.experiments.step52_raw_headers','--job',str(job),'--dest',str(dest)],cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT);code=process.wait()
            if getattr(process,'_handle',None) is not None:process._handle.Close()
        q=read(dest/'RAW_RECEIPT.json')
        if q is None:raise RuntimeError('raw readback failed '+a['job_id']+' code '+str(code))
        issues.extend(a['job_id']+': '+s for s in q['issues']);raw_ids.extend(q.get('verified_raw',q['decoded_raw']));raw_decoded_known+=len(q['decoded_raw'])
    identity_checks=[]
    original=read(OUT/'source_metadata/METHOD_INPUT_FREEZE.json');source_sha=sha(SOURCE_RUN/'METHOD_INPUT_FREEZE.json')
    for entry in index:
        if not entry.get('result_path'):continue
        rr=read(entry['result_path']);base=Path(rr.get('source_branch_path') or str(Path(entry['result_path']).parent));header=read(base/'POLICY_CONTEXT.json')
        if not header:continue
        c=header['record'];pos=entry['position'];checks={k:c.get(k)==v for k,v in dict(context_id=pos['context_id'],external_arm=pos['arm'],episode=pos['episode'],snapshot_id=pos['snapshot_id'],source_snapshot=pos['snapshot_id'],source_tick=pos['tick'],step51_method_freeze_sha256=source_sha,step50_method_freeze_sha256=original['step50_method_freeze_sha256']).items()}
        identity_checks.append(dict(canonical_id=entry['canonical_id'],checks=checks))
        if not all(checks.values()):issues.append('frozen scalar context identity '+entry['canonical_id']+': '+str([k for k,v in checks.items() if not v]))
    identity_path=OUT/'CONTEXT_IDENTITY_CHECKS.json'
    if not identity_path.exists():write_new(identity_path,dict(checks=identity_checks,scalar_header_only=True,new_QP=0,new_steps=0,additional_fact_bank_decodes=0))
    if len(rows)!=176 or len({r['id'] for r in rows})!=176:issues.append('canonical176 unique')
    if len(raw_ids)!=len(set(raw_ids)):issues.append('new raw global ID collision')
    if len(raw_ids)>finish['budget']['new_QP']:issues.append('raw larger than charged newQP')
    prep=read(OUT/'PREPARATION.json')
    if any(sha(SOURCE_ROOT/p)!=h for p,h in prep['source_files_sha256'].items()):issues.append('old history changed')
    freeze=read(OUT/'EXECUTION_FREEZE.json')
    if any(sha(ROOT/p)!=h for p,h in freeze['execution_code_sha256'].items()):issues.append('execution freeze changed')
    if finish['budget']['total_QP_calls']>45000 or finish['budget']['total_physics_steps']>500000 or finish['budget']['total_replay_steps']>8000 or finish['budget']['total_active_seconds']>9000.25:issues.append('cumulative cap')
    refs=[];ri={r['episode_id']:r for r in read(OUT/'REFERENCE_INDEX.json')}
    for ep in read(OUT/'source_metadata/METHOD_INPUT_FREEZE.json')['episodes']:
        if ep['episode_id'] in ri:
            q=ri[ep['episode_id']];p=Path(q['path']);h=read(p)
            if sha(p)!=q['json_sha256'] or sha(p.with_suffix('.npz'))!=q['npz_sha256']:issues.append('reference SHA '+ep['episode_id'])
            r=h['record'];refs.append(dict(episode_id=ep['episode_id'],status=r['status'],counts=r.get('counts'),origin=q['origin'],missing_snapshot_ticks=r.get('missing_snapshot_ticks')))
        else:refs.append(dict(episode_id=ep['episode_id'],status='NOT_RUN'))
    old_replay=read(SOURCE_RUN/'replay_continuation/REPLAY_RESULT.json');old_unknown=[r for r in old_replay['rows'] if r['status']=='UNKNOWN'];replay_rows=[r for r in old_replay['rows'] if r['status']=='MATCH']
    completed=read(OUT/'REPLAY_COMPLETION.json',{})
    new_replay=read(completed.get('new_result_path'),{}) if completed.get('new_result_path') else {}
    replay_rows+=new_replay.get('rows',[]);replay=dict(status='ALL4_MATCH' if len(replay_rows)==4 and all(r['status']=='MATCH' for r in replay_rows) else 'INCOMPLETE_OR_MISMATCH',rows=replay_rows,old_UNKNOWN_history=old_unknown,
        new_steps=finish['budget']['new_replay_steps'],cumulative_steps=finish['budget']['total_replay_steps'],new_QP=0,scope='FROZEN_CONTROL_PHYSICS_ONLY',independent_full_method_numerical_reproduction='UNVERIFIED')
    from cavr_wbc.experiments.step51_analyze import endpoints
    result=dict(status='INVALID_READBACK' if issues else 'COMPLETION_BATCH_PROCESSED' if finish['undispatched']==0 else 'INCOMPLETE',run_status=finish['status'],source_STEP51_status='INCOMPLETE',
        planned_positions=176,rows=176,processed=176-finish['undispatched'],canonical_known=finish['canonical_known'],UNKNOWN=finish['UNKNOWN'],undispatched=finish['undispatched'],
        observed=sum(bool(r.get('observed')) for r in rows),complete_4s=sum(bool(r.get('complete_2001')) for r in rows),mission_success=sum(bool(r.get('mission_success')) for r in rows),
        endpoints=endpoints(rows,refs),references=refs,budget=finish['budget'],state=finish['state'],replay=replay,issues=issues,
        source_unchanged=not any('old history' in i for i in issues),no_new_CAL_TRAIN_fits=True,independent_numerical_reproduction=False,
        completion_index='COMPLETION_INDEX.json',attempt_index='ATTEMPT_INDEX.json',authorization_scope='RECOVERY_1S_ONLY',old_CAL_certifies_mission=False)
    typed_write_new(OUT/'BRANCH_ROWS.json',rows);typed_write_new(OUT/'LATENCY.json',latency);typed_write_new(OUT/'TRAJECTORY_SERIES.json',series);typed_write_new(OUT/'RESULT.json',result)
    write_new(OUT/'READBACK_VERDICT.json',dict(status='MATCH' if not issues else 'MISMATCH',issues=issues,branches=176,current_task_fact_banks_decoded=fact_banks,
        referenced_old_known_banks_decoded=0,referenced_old_bank_hashes_checked=old_hashes_checked,verified_new_raw_QP=len(raw_ids),
        decoded_new_raw_QP_known=raw_decoded_known,failed_raw_partial_decodes_unknown_bounds=[0,206],
        raw_checks='FULL_BYTE_SHA_OWNER_INDEX_START_RETURN; saved array-decoded receipts reused; remaining typed scalar headers equivalent',
        actual_evaluation_frozen=True,new_QP=0,new_steps=0,timestamp_utc=utc()))
    fields=['canonical_id','id','block','direction','episode','snapshot_id','tick','health_kind','arm','status','canonical_status','origin_run','segment','attempt_id','historical_UNKNOWN','experimental_applied','complete_2001','phase1_complete','phase1_gate_pass','handoff_committed','continuity_pass','mission_success','physical_safe','timing_qualified','late','final_goal_error_m','final_vx_m_s','final_half_second_vx_RMS_m_s','D_0to1_m','external_reference_error_integral_0to4_available_m_s','external_reference_error_integral_1to4_available_m_s','sustained_goal_stop_time_s']
    with (OUT/'BRANCH_ROWS.csv').open('x',encoding='utf-8',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=fields,extrasaction='ignore');writer.writeheader();writer.writerows(rows)
    print(dict(readback='MATCH' if not issues else 'MISMATCH',issues=issues,processed=result['processed'],complete_4s=result['complete_4s'],mission_success=result['mission_success'],M_NEG=result['endpoints']['M_NEG'],M_POS=result['endpoints']['M_POS'],replay=replay['status']),flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--entry');p.add_argument('--raw-job');p.add_argument('--dest');p.add_argument('--resume',action='store_true');args=p.parse_args()
    if args.entry or args.raw_job:child(args.entry,args.raw_job,args.dest)
    else:run(args.resume)
