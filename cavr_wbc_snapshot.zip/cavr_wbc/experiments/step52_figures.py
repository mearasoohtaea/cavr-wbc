"""Two SciPilot figures from the final merged scalar STEP52 summaries only."""
from pathlib import Path
import argparse
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from PIL import Image
from cavr_wbc.experiments.step52_io import OUT,read,write as metadata_write,sha
from cavr_wbc.experiments.step47_io import encode
from cavr_wbc.experiments.step52_report import counts,nref,unknown,undispatched
from cavr_wbc.experiments.step51_figures import (setup_style,profile_data,audit_layout,render_preview,
    export_figure,check_figure,add_panel_labels,embedded_fonts,COLORS,ARMS,SHORT,GROUPS,NAMES)
from cavr_wbc.experiments.step51_analyze import physical_failure

OUTCOMES=('Success','Physical','Late','Gate/task','Partial','ABSTAIN','Unsent','Unknown','Not dispatched')
COLS=('#0072B2','#D55E00','#CC79A7','#E69F00','#009E73','#777777','#eeeeee','#bbbbbb','#ffffff')
HATCH=('','///','...','xx','++','--','','oo','\\\\')
ORIGINS=('O','N','D','U','NA')
ORIGIN_COLORS=('#888888','#c7c7c7','#444444','#dedede','#ffffff')
ORIGIN_HATCH=('...','///','xx','oo','')
ORIGIN_NAMES=('Old known','New worker','Derived old','Unknown','Not dispatched')
SEGMENTS=('STEP51','STEP52_RESOURCE_ISOLATED','STEP51_DERIVED_RECOVERY')
SEGMENT_NAMES=('Old','New','Derived')
SEGMENT_MARKERS=('o','^','D')

def write(path,value):
    # SciPilot profiles include NaN and NumPy booleans for small/empty groups.
    metadata_write(path,encode(value))

def origin(row):
    if unknown(row):return 'U'
    if undispatched(row):return 'NA'
    if row.get('segment')=='STEP51_DERIVED_RECOVERY':return 'D'
    if row.get('segment')=='STEP52_RESOURCE_ISOLATED':return 'N'
    return 'O'

def outcome(row):
    if unknown(row):return 7
    if undispatched(row):return 8
    if row.get('mission_success'):return 0
    if physical_failure(row):return 1
    if row.get('late'):return 2
    if row.get('status')=='PHASE1_GATE_FAILED' or row.get('complete_2001'):return 3
    if row.get('observed'):return 4
    if row.get('packet_status')=='ABSTAIN':return 5
    return 6

def finishing(fig,axes,title,note,rect=(.015,.08,.97,.85)):
    fig.suptitle(title,fontsize=11,y=.995)
    fig.text(.5,.012,note,ha='center',va='bottom',fontsize=7)
    fig.set_layout_engine('constrained',h_pad=.12,w_pad=.12,rect=rect)
    fig.canvas.draw()
    add_panel_labels(fig,axes=axes,style='ieee',fontsize=9,x_offset_pt=-10,y_offset_pt=12)

def figure1(rows,result):
    fig=plt.figure(figsize=(7.16,9.7))
    gs=fig.add_gridspec(2,2,height_ratios=(2.6,1.),width_ratios=(1.15,1.))
    matrix=fig.add_subplot(gs[0,:]);bars=fig.add_subplot(gs[1,0]);sources=fig.add_subplot(gs[1,1])
    main=sorted((r for r in rows if r['arm']==ARMS[0]),key=lambda r:(r['direction']>0,int(r['episode'].split('_')[-1]),r['tick']))
    for i,row in enumerate(main):
        missing=undispatched(row);uncertain=unknown(row);approved=row.get('learner_approved');sent=row.get('selected_command_sent');phase=row.get('phase1') or {}
        choice='NA' if missing else 'UNK' if uncertain else str(row.get('gamma')) if approved else 'ABST' if row.get('packet_status')=='ABSTAIN' else 'NO'
        dispatch='NA' if missing else 'UNK' if uncertain else 'SENT' if sent else 'LATE' if row.get('late') else 'NO'
        recover='NA' if not row.get('observed') else 'PASS' if row.get('phase1_gate_pass') else 'PHYS' if physical_failure(row) and (row.get('first_physical_failure') or {}).get('time_s',99)<=1 else 'FAIL' if phase.get('complete') else 'PART'
        codes=(origin(row),choice,dispatch,recover,OUTCOMES[outcome(row)])
        for j,code in enumerate(codes):
            good=(j==1 and approved) or (j==2 and sent) or (j==3 and code=='PASS') or (j==4 and code=='Success')
            color='#dceef6' if good else '#f7e6df' if code in ('PHYS','Physical','FAIL','Gate/task') else '#f0f0f0'
            if code in ('NA','Not dispatched'):color='#ffffff'
            matrix.add_patch(plt.Rectangle((j-.48,i-.44),.96,.88,facecolor=color,edgecolor='#dddddd',linewidth=.35))
            matrix.text(j,i,code,ha='center',va='center',fontsize=7.8)
        if i==len(main)-1 or main[i+1]['episode']!=row['episode']:matrix.axhline(i+.5,color='#888888',lw=.5)
    matrix.set_xlim(-.5,4.5);matrix.set_ylim(len(main)-.4,-.6)
    matrix.set_xticks(range(5),('Origin','Own recognition','Timely first send','Observed 1 s','Same branch 4 s'));matrix.xaxis.tick_top()
    matrix.set_yticks(range(len(main)),[f"{r['direction']:+d} E{r['episode'].split('_')[-1]} / T{r['tick']}" for r in main])
    matrix.set_title(f"Governor chain: 12 planned episodes / {nref(result)} complete references",loc='left',pad=28,fontsize=9)
    records=[]
    for i,(health,arm) in enumerate(GROUPS):
        own=[r for r in rows if r['arm']==arm and r['health_kind']==health]
        ns=[sum(outcome(r)==j for r in own) for j in range(len(OUTCOMES))];left=0
        for j,n in enumerate(ns):
            bars.barh(i,n,left=left,color=COLS[j],hatch=HATCH[j],edgecolor='#999999',height=.7,lw=.35)
            if n:bars.text(left+n/2,i,str(n),ha='center',va='center',fontsize=7.5)
            left+=n
        os=[sum(origin(r)==code for r in own) for code in ORIGINS];left=0
        for j,n in enumerate(os):
            sources.barh(i,n,left=left,color=ORIGIN_COLORS[j],hatch=ORIGIN_HATCH[j],edgecolor='black',height=.7,lw=.3)
            if n:sources.text(left+n/2,i,str(n),ha='center',va='center',fontsize=7.5,color='white' if j==2 else 'black')
            left+=n
        records.append(dict(health=health,arm=arm,planned=len(own),outcomes=dict(zip(OUTCOMES,ns)),origins=dict(zip(ORIGINS,os))))
    bars.set_yticks(range(len(GROUPS)),NAMES);sources.set_yticks(range(len(GROUPS)),['']*len(GROUPS))
    for ax in (bars,sources):
        ax.set_xlim(0,32);ax.set_xticks((0,8,16,24,32));ax.invert_yaxis();ax.set_xlabel('Planned positions')
    bars.set_title('All 176 canonical outcomes',loc='left',pad=13,fontsize=9)
    sources.set_title('Origin / unresolved status',loc='left',pad=13,fontsize=9)
    fig.legend(handles=[plt.Rectangle((0,0),1,1,facecolor=COLS[j],hatch=HATCH[j],edgecolor='grey',label=OUTCOMES[j]) for j in range(len(OUTCOMES))],
        loc='upper center',bbox_to_anchor=(.51,.965),ncol=5,frameon=False,fontsize=7)
    sources.legend(handles=[plt.Rectangle((0,0),1,1,facecolor=ORIGIN_COLORS[j],hatch=ORIGIN_HATCH[j],edgecolor='black',label=ORIGINS[j]) for j in range(len(ORIGINS))],
        loc='upper center',bbox_to_anchor=(.5,-.20),ncol=5,frameon=False,fontsize=7)
    c=counts(rows)
    finishing(fig,[matrix,bars,sources],'STEP52 | Completion of the frozen STEP51 batch',
        f"Known processed {c['processed']}/176; UNKNOWN {c['UNKNOWN']}; not dispatched {c['undispatched']}. NA remains unobserved.\n"
        'O: old known; N: new worker; D: derived old evidence; U: unresolved. Outcome overlaps remain in JSON.',rect=(.015,.10,.97,.81))
    write(OUT/'figures/FIG1_CANONICAL_OUTCOMES.json',records)
    return fig

def metric_marker(row):
    try:return SEGMENT_MARKERS[SEGMENTS.index(row.get('segment'))]
    except ValueError:return 'x'

def figure2(rows,latency,result):
    fig,axs=plt.subplots(4,2,figsize=(7.16,9.7))
    metrics=((axs[0,0],'final_goal_error_m',1000.,2.,'Available original-goal error','Absolute error (mm)'),
        (axs[0,1],'sustained_goal_stop_time_s',1.,None,'Sustained goal + stop','Time (s)'),
        (axs[1,0],'final_half_second_vx_RMS_m_s',1000.,1.,'Final vx RMS: steps 1750..2000','vx RMS (mm/s)'))
    for ax,key,scale,limit,title,ylabel in metrics:
        for i,(health,arm) in enumerate(GROUPS):
            own=sorted((r for r in rows if r['health_kind']==health and r['arm']==arm),key=lambda r:(r['episode'],r['tick']))
            available=0
            for j,row in enumerate(own):
                value=row.get(key)
                if value is None:continue
                available+=1;full=bool(row.get('complete_2001'));qualified=full and row.get('physical_safe') and row.get('timing_qualified')
                x=i+(j-(len(own)-1)/2)*.017
                if not full:ax.scatter(x,abs(value)*scale,color=COLORS[arm],marker='x',s=15,linewidths=.6)
                else:ax.scatter(x,abs(value)*scale,facecolors=COLORS[arm] if qualified else 'none',edgecolors=COLORS[arm],marker=metric_marker(row),s=18,linewidths=.6)
            ax.text(i,.98,f'{available}/{len(own)}',transform=ax.get_xaxis_transform(),ha='center',va='top',fontsize=7)
        if limit is not None:ax.axhline(limit,color='black',ls='--',lw=.7)
        values=[abs(r[key])*scale for r in rows if r.get(key) is not None]
        ax.set_ylim(0,max(values+[limit or .01])*1.25)
        ax.set_xticks(range(len(GROUPS)),('Gov','M res','M imm','B','C','H C','m C'),rotation=20)
        ax.set_ylabel(ylabel);ax.set_title(title,loc='left',pad=12,fontsize=8)
    pair_ax=axs[1,1];pairs=result['endpoints']['paired']
    comparisons=[(ARMS[0],ARMS[i]) for i in (1,3,2,4)]+[(ARMS[1],ARMS[2])]
    for i,(a,b) in enumerate(comparisons):
        own=[p for p in pairs if p['a']==a and p['b']==b];valid=[p for p in own if p['both_complete_safe_timely']]
        for j,p in enumerate(valid):
            v=p['continuous']['final_goal_error_m']
            if v['a'] is None or v['b'] is None:continue
            pair_ax.scatter(i+(j-(len(valid)-1)/2)*.025,(abs(v['b'])-abs(v['a']))*1000,color=COLORS[a],s=16)
        pair_ax.text(i,.98,f'{len(valid)}/{len(own)}',transform=pair_ax.get_xaxis_transform(),ha='center',va='top',fontsize=7)
    pair_ax.axhline(0,color='black',lw=.7);pair_ax.margins(y=.25)
    pair_ax.set_xticks(range(5),('G-M res','G-B','G-M imm','G-C','M res-imm'),rotation=25)
    pair_ax.set_ylabel('|error B| - |error A| (mm)');pair_ax.set_title('Conditional same-source pairs',loc='left',pad=12,fontsize=8)
    for ax,key,limit,title in ((axs[2,0],'complete_ms',20.,'Complete ready: old / new windows'),(axs[2,1],'prepared_ms',17.,'Prepared commit: old / new windows')):
        categories=[(kind,seg) for kind in ('FIRST','FEEDBACK','HANDOFF') for seg in SEGMENTS]
        for i,(kind,seg) in enumerate(categories):
            own=[p for p in latency if p['kind']==kind and p.get('segment')==seg];available=0;batches={}
            for j,p in enumerate(own):
                value=p.get(key)
                if value is None:continue
                available+=1;arm=p['arm'];applied=bool(p.get('applied'))
                group=batches.setdefault((arm,applied),[[],[]]);group[0].append(i+(((j*37)%101)/100-.5)*.48);group[1].append(value)
            for (arm,applied),(xs,ys) in batches.items():
                ax.scatter(xs,ys,color=COLORS[arm],marker=SEGMENT_MARKERS[SEGMENTS.index(seg)] if applied else 'x',s=6,alpha=.30,rasterized=False)
            ax.text(i,.98,f'{available}',transform=ax.get_xaxis_transform(),ha='center',va='top',fontsize=6.5)
        ax.axhline(limit,color='black',ls='--',lw=.7)
        ax.set_ylim(0,max([p[key] for p in latency if p.get(key) is not None]+[limit])*1.25)
        ax.set_xticks(range(9),[('O','N','D')[i%3]+'\n'+('First','FB','1s')[i//3] for i in range(9)])
        ax.set_ylabel('Complete (ms)' if key=='complete_ms' else 'Prepared (ms)');ax.set_title(title,loc='left',pad=12,fontsize=8)
    contact=axs[3,0];events=[]
    for row in rows:
        for foot,stats in (row.get('contact_statistics') or {}).get('contacts',{}).items():
            for reason in ('CONTACT_LOSS','NEGATIVE_NORMAL_FORCE','FRICTION_VIOLATION'):
                item=stats[reason]
                if not item['unqualified_points']:continue
                event=dict(id=row['id'],foot=foot,reason=reason,segment=row.get('segment'),**item);events.append(event)
                i=ARMS.index(row['arm']);x=i+(((len(events)*37)%101)/100-.5)*.5
                contact.scatter(x,item['longest_grid_supported_duration_s']*1000,color=COLORS[row['arm']],marker=metric_marker(row),s=17)
                contact.scatter(x,item['longest_observed_point_span_s']*1000,facecolors='none',edgecolors=COLORS[row['arm']],marker=metric_marker(row),s=17,linewidths=.6)
    contact.set_xticks(range(5),('Gov','M res','M imm','B','C'))
    contact.set_ylim(-.15,max([e['longest_grid_supported_duration_s']*1000 for e in events]+[2.])*1.4)
    contact.set_ylabel('Longest contact event (ms)');contact.set_title('Grid support and observed point span',loc='left',pad=12,fontsize=8)
    contact.text(.5,.94,'Filled: grid duration; open: point span',transform=contact.transAxes,ha='center',va='top',fontsize=6.8)
    if not events:contact.text(.5,.5,'No contact violations observed',transform=contact.transAxes,ha='center',fontsize=8)
    write(OUT/'figures/CONTACT_EVENT_POINTS.json',events)
    integral=axs[3,1]
    for i,(a,b) in enumerate(comparisons):
        valid=[p for p in pairs if p['a']==a and p['b']==b and p['both_complete_safe_timely']]
        for j,p in enumerate(valid):
            for shift,key,marker in ((-.10,'external_reference_error_integral_0to4_available_m_s','o'),(.10,'external_reference_error_integral_1to4_available_m_s','x')):
                value=p['continuous'][key]['b_minus_a']
                if value is not None:integral.scatter(i+shift+(j-(len(valid)-1)/2)*.01,value*1000,color=COLORS[a],marker=marker,s=13)
    integral.axhline(0,color='black',lw=.7);integral.margins(y=.25)
    integral.set_xticks(range(5),('G-M res','G-B','G-M imm','G-C','M res-imm'),rotation=25)
    integral.set_ylabel('Reference integral B - A (mm s)');integral.set_title('Both complete, safe, timely',loc='left',pad=12,fontsize=8)
    integral.text(.5,.94,'o: 0-4 s; x: 1-4 s',transform=integral.transAxes,ha='center',va='top',fontsize=6.8)
    fig.legend(handles=[Line2D([],[],color=COLORS[a],marker='o',ls='',label=SHORT[i]) for i,a in enumerate(ARMS)],
        loc='upper center',bbox_to_anchor=(.5,.967),ncol=5,frameon=False,fontsize=7)
    finishing(fig,list(axs.flat),'STEP52 | Task utility, paired points and segment latency',
        f"12 planned episodes; {nref(result)} complete references. O: old; N: resource-isolated; D: derived old timing.\n"
        'Metric markers o / triangle / diamond = O / N / D; open = other full; x = partial or unapplied latency.\n'
        'Every available point retained; missing is not zero. One 2 ms contact point has zero observed point span.')
    return fig

def run(export=False):
    if not (OUT/'RUN_FINISHED.json').exists() or not (OUT/'READBACK_VERDICT.json').exists():
        raise ValueError('closed numeric segment and unique final readback required')
    if export:
        visual=read(OUT/'figures/VISUAL_REVIEW.json')
        if not visual or not visual.get('passed'):raise ValueError('root visual preview review must pass before export')
    folder=OUT/'figures';folder.mkdir(exist_ok=True)
    rows=read(OUT/'BRANCH_ROWS.json');latency=read(OUT/'LATENCY.json');result=read(OUT/'RESULT.json')
    style=setup_style('ieee',lang='en')
    plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],'font.size':8,
        'axes.labelsize':8,'xtick.labelsize':7,'ytick.labelsize':7,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
    branch_frame=pd.DataFrame(rows).reindex(columns=['health_kind','arm','status','segment','mission_success','final_goal_error_m','final_half_second_vx_RMS_m_s'])
    latency_frame=pd.DataFrame(latency).reindex(columns=['kind','arm','segment','complete_ms','prepared_ms','applied'])
    profiles=dict(BRANCH_ROWS=profile_data(branch_frame,['health_kind','arm','segment']),LATENCY=profile_data(latency_frame,['kind','arm','segment']))
    write(folder/'DATA_PROFILES.json',profiles)
    write(folder/'CHART_SELECTION.json',dict(objectives=['all176 original canonical outcomes and source segments','conditional task utility and all old/new latency windows'],
        choice='per-source stage matrix, outcome and origin counts; raw and paired points; segmented latency; contact duration',
        reason='fixed nested deterministic episodes/snapshots with explicit censored or unavailable branches; process boundary changes cache/scheduling context',
        alternatives=['episode pages','paired numeric tables'],mean_bars=False,pvalues=False,double_y=False,missing_zero_fill=False))
    qa=[]
    for name,fig in (('FIG1_FROZEN_BATCH_COMPLETION',figure1(rows,result)),('FIG2_UTILITY_SEGMENT_LATENCY',figure2(rows,latency,result))):
        size=fig.get_size_inches().tolist();layout=audit_layout(fig)
        preview=render_preview(fig,str(folder/(name+'_preview.png')),dpi=165)
        record=dict(name=name,layout=layout,preview=preview,publication_size_inches=size,style=style)
        if export:
            if any(s=='FAIL' for s,_ in layout):raise ValueError('figure layout failure')
            paths=export_figure(fig,str(folder/name),formats=['pdf','png'],dpi=600,size_inches=size,grayscale_preview=False,tight=False)
            with Image.open(folder/(name+'.png')) as im:im.convert('L').save(folder/(name+'_grayscale.png'),dpi=(600,600))
            compliance=[]
            for p in paths:
                issue,info=check_figure(p,min_dpi=600,target_inches=size)
                compliance.append(dict(path=p,issues=issue,info=info))
            fonts=embedded_fonts(folder/(name+'.pdf'))
            record.update(files={Path(p).name:sha(p) for p in paths},compliance=compliance,PDF_font_descendants=fonts,
                font_embedding_verified=all(f['embedded'] for f in fonts if f['subtype'].startswith('/CIDFont')))
        else:
            with Image.open(folder/(name+'_preview.png')) as im:im.convert('L').save(folder/(name+'_gray_preview.png'))
        qa.append(record);plt.close(fig)
    write(folder/('EXPORT_QA.json' if export else 'PREVIEW_QA.json'),qa)
    (folder/'FIGURE_CAPTIONS.md').write_text('''# Figure captions

FIG1. 原176位冻结批次的主臂阶段、全方法结局及来源构成。O为STEP51已知结果，N为STEP52新worker，D为旧证据零数值派生恢复，U为未知，NA为未派发或相应阶段未观察。构成图是计数而非均值；结局显示优先级为unknown→not dispatched→success→physical→late→gate/task→partial→ABSTAIN→unsent，原可重叠事实保留在JSON。episode内snapshot不作为独立随机样本。

FIG2. 原始任务指标、双方完整安全及时的条件配对、每个已记录首包/反馈/handoff时延，以及逐事件接触持续诊断。所有可用点保留；未观察不填零。时延按旧、新进程隔离与旧证据派生分开，prepared17ms及complete20ms门未改；启动/import/load/startup不在packet窗口，但计入全局active。接触实心点为网格支持时长，空心点为实际点span；单点2ms不表示持续摔倒。没有误差棒、总体统计检验或p值。
''',encoding='utf-8')
    print(dict(figures=2,export=export,layout=[q['layout'] for q in qa]),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--export',action='store_true');run(p.parse_args().export)
