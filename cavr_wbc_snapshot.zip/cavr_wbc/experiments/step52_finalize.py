"""Final metadata/provenance and scoped artifact manifest; no bank re-evaluation."""
import ast,os,subprocess
from cavr_wbc.experiments.step52_io import *
def git(*args,root=ROOT):
    env=dict(os.environ)
    for k in ('GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_COMMON_DIR'):env.pop(k,None)
    env['GIT_OPTIONAL_LOCKS']='0'
    return subprocess.check_output(['git','-C',str(root),*args],env=env,text=True,encoding='utf-8').strip()
def include(p):
    rel=p.relative_to(OUT);parts=rel.parts
    if len(parts)==1:return p.name not in ('EVIDENCE_MANIFEST.json','DELIVERY_MANIFEST.json','TRAJECTORY_SERIES.json')
    if parts[0] in ('tests','figures','models','source_metadata'):return True
    if parts[0]=='readback':return p.name in ('ENTRY.json','ROW.json','LATENCY.json','RECEIPT.json','RAW_RECEIPT.json') or (p.name.startswith('PROCESS') and p.suffix=='.log')
    if parts[0]=='jobs':return p.name in ('JOB.json','WORKER_STARTED.json','WORKER_RECEIPT.json','WORKER_EXCEPTION.json','WORKER_LEDGER.jsonl','PROGRESS.json','PROCESS.log','RESULT.json','INCREMENTAL_RECEIPT.json','STARTUP.json','REPLAY_RESULT.json','REPLAY_STARTED.json','REPLAY_STEPS.jsonl')
    return False
def run():
    prep=read(OUT/'PREPARATION.json');freeze=read(OUT/'EXECUTION_FREEZE.json');issues=[]
    for name in ('REPORT.md','HANDOFF.md','TRO_EVIDENCE_CLAIMS.md','PROTOCOL_STATUS.ini','REPORT_POSTPROCESSING_CORRECTIONS.json'):
        if not (OUT/name).exists():issues.append('required delivery missing '+name)
    files=list(ROOT.glob('cavr_wbc/experiments/step52*.py'))+list(ROOT.glob('tests/test_step52*.py'))
    for p in files:ast.parse(p.read_text(encoding='utf-8-sig'))
    if git('rev-parse','HEAD',root=SOURCE_ROOT)!=SOURCE_COMMIT:issues.append('source HEAD changed')
    if git('status','--porcelain=v1','--untracked-files=no',root=SOURCE_ROOT):issues.append('source tracked state dirty')
    if any(sha(SOURCE_ROOT/p)!=h for p,h in prep['source_files_sha256'].items()):issues.append('source history/index changed')
    if any(sha(ROOT/p)!=h for p,h in freeze['execution_code_sha256'].items()):issues.append('execution code changed')
    old_freeze=read(OUT/'source_metadata/METHOD_INPUT_FREEZE.json')
    if any(sha(ROOT/p)!=h for p,h in old_freeze['runtime_sha256'].items()):issues.append('old scientific runtime changed')
    for p,h in prep['copied_small_assets_sha256'].items():
        path=OUT/p if p.startswith('models/') else OUT/'source_metadata'/p
        if sha(path)!=h:issues.append('copied source asset changed '+p)
    if any(sha(ROOT/p)!=h for p,h in prep['plant_asset_hashes'].items()):issues.append('plant changed')
    native=ROOT/'artifacts/step30_injured_governor_20261008/step30-injured-governor-20261008-01/native/step30_prefix.dll'
    if sha(native)!=prep['native_sha256']:issues.append('native changed')
    verdict=read(OUT/'READBACK_VERDICT.json');qa=read(OUT/'figures/EXPORT_QA.json');visual=read(OUT/'figures/VISUAL_REVIEW.json')
    if not verdict or verdict['status']!='MATCH':issues.append('unique readback not MATCH')
    if not qa or len(qa)!=2:issues.append('figure export QA missing')
    for item in qa or []:
        if any(s=='FAIL' for s,_ in item.get('layout',[])):issues.append('figure layout FAIL '+item['name'])
        if any(s=='FAIL' for q in item.get('compliance',[]) for s,_ in q.get('issues',[])):issues.append('figure compliance FAIL '+item['name'])
        if not item.get('font_embedding_verified'):issues.append('figure embedded-font verification missing '+item['name'])
    if not visual or not visual.get('passed'):issues.append('visual QA missing')
    if visual and visual.get('final_input_binding_required'):
        binding=read(OUT/'figures/FINAL_INPUT_BINDING.json',{})
        if binding.get('status')!='MATCH':issues.append('preview/final scalar input binding not MATCH')
    known={}
    for ledger in OUT.glob('jobs/*/WORKER_LEDGER.jsonl'):
        with ledger.open(encoding='utf-8') as stream:
            for line in stream:
                try:q=__import__('json').loads(line)
                except ValueError:continue
                if q['event']=='RAW_QP_SAVED':
                    p=ledger.parent/q['path'];known[p]=q['json_sha256'];known[p.with_suffix('.npz')]=q['npz_sha256']
    entries=[]
    for p in sorted(OUT.rglob('*')):
        if p.is_file() and p.name not in ('EVIDENCE_MANIFEST.json','DELIVERY_MANIFEST.json'):
            entries.append(dict(path=str(p.relative_to(OUT)).replace('\\','/'),size_bytes=p.stat().st_size,
                sha256=known.get(p) or sha(p),hash_source='durable_raw_ledger' if p in known else 'streaming_current_byte_manifest',
                commit_scope='SCOPED_COMMIT' if include(p) else 'LOCAL_LARGE_EVIDENCE'))
    large=[r for r in entries if r['commit_scope']=='LOCAL_LARGE_EVIDENCE']
    write(OUT/'EVIDENCE_MANIFEST.json',dict(output_root=str(OUT),source_root=str(SOURCE_ROOT),source_commit=SOURCE_COMMIT,
        files=entries,source_references=read(OUT/'COMPLETION_INDEX.json'),reference_sources=read(OUT/'REFERENCE_INDEX.json'),
        complete_large_evidence_preserved=True,large_files=len(large),large_bytes=sum(r['size_bytes'] for r in large),
        source_evidence_referenced_without_recursive_copy=True,new_QP=0,new_steps=0,bank_decodes=0,
        source_old_UNKNOWN_preserved=True,numeric_readback='READBACK_VERDICT.json'))
    alternates=ROOT/'.git/objects/info/alternates';alternate=alternates.read_text(encoding='utf-8').strip() if alternates.exists() else None
    write(OUT/'DELIVERY_MANIFEST.json',dict(source_head=SOURCE_COMMIT,source_unchanged=True if not issues else not any('source' in i for i in issues),
        source_index_sha256=prep['source_files_sha256']['.git/index'],branch=git('branch','--show-current'),parent_commit=git('rev-parse','HEAD'),
        source_git_object_alternate=alternate,new_git_objects_in_D=True,source_object_storage_dependency_declared=True,
        static_AST_files=len(files),readback=verdict,tests=read(OUT/'tests/NECESSARY_TESTS.json'),figure_export_QA=qa,visual_review=visual,
        completion=read(OUT/'RUN_FINISHED.json'),outputs=len(entries),current_bytes=sum(r['size_bytes'] for r in entries),issues=issues,
        local_scoped_commit_only=True,push=False,new_QP=0,new_steps=0,robot_motion_algorithm_project_accessed=False))
    print(dict(static_files=len(files),files=len(entries),large_files=len(large),large_bytes=sum(r['size_bytes'] for r in large),issues=issues),flush=True)
    if issues:raise ValueError(str(issues))
if __name__=='__main__':run()
