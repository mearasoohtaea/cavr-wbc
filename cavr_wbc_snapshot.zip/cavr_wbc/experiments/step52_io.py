"""STEP52 lightweight D-only scope; coordinator never imports numerical banks."""
from pathlib import Path
import ctypes,hashlib,json,os
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[2]
SOURCE_ROOT=Path('D:/CAVR-WBC/cavr_step51_frozen_bidirectional_confirmation_20261012')
SOURCE_COMMIT='cafad5d855de5754c2249d2bdf3eae3e11497055'
SOURCE_RUN=SOURCE_ROOT/'artifacts/step51_bidirectional_confirmation_20261012/step51-frozen-bidirectional-confirmation-20261012-01'
PROTOCOL=Path('D:/CAVR-WBC/experiment_handoff_20261010/NEXT_CODEX_INSTRUCTIONS_STEP52_RESOURCE_ISOLATED_STEP51_COMPLETION_20261013.md')
OUT=ROOT/'artifacts/step52_step51_completion_20261013/step52-resource-isolated-completion-20261013-01'
OLD_QP=7532;OLD_STEPS=79700;OLD_REPLAY=6000;OLD_ACTIVE=1616.5278986999765
QP_LIMIT=45000;STEP_LIMIT=500000;REPLAY_LIMIT=8000;ACTIVE_LIMIT=9000.
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def read(p,default=None):
    p=Path(p);return json.loads(p.read_text(encoding='utf-8')) if p.exists() else default
def write(p,v):
    p=Path(p)
    if not p.resolve().is_relative_to(ROOT.resolve()):raise ValueError('STEP52 write outside new D checkout')
    p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(p.suffix+'.'+str(os.getpid())+'.tmp')
    tmp.write_text(json.dumps(v,ensure_ascii=False,allow_nan=False,sort_keys=True,separators=(',',':'))+'\n',encoding='utf-8',newline='\n');os.replace(tmp,p)
def write_new(p,v):
    if Path(p).exists():raise FileExistsError('do not overwrite evidence '+str(p))
    write(p,v)
def append(p,v):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(json.dumps(v,sort_keys=True,allow_nan=False,separators=(',',':'))+'\n');f.flush()
def utc():return datetime.now(timezone.utc).isoformat()
def install_streaming():
    import importlib
    for name in ('step30_io','step47_io','step50_io','step51_io','step26_features_storage','step47_storage','step50_storage','step51_storage'):
        m=importlib.import_module('cavr_wbc.experiments.'+name)
        if hasattr(m,'sha'):m.sha=sha
    return dict(algorithm='SHA256',chunk_bytes=1024*1024,scientific_behavior_changed=False)
def resource_snapshot():
    v=dict(pid=os.getpid(),timestamp_utc=utc())
    try:
        class Memory(ctypes.Structure):
            _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(n,ctypes.c_ulonglong) for n in ('total_phys','avail_phys','total_pagefile','avail_pagefile','total_virtual','avail_virtual','avail_extended')]
        m=Memory();m.length=ctypes.sizeof(m)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):v.update(system_physical_free_bytes=m.avail_phys,system_commit_free_bytes=m.avail_pagefile,system_memory_load_percent=m.load)
        class ProcessMemory(ctypes.Structure):
            _fields_=[('cb',ctypes.c_ulong),('PageFaultCount',ctypes.c_ulong)]+[(n,ctypes.c_size_t) for n in ('PeakWorkingSetSize','WorkingSetSize','QuotaPeakPagedPoolUsage','QuotaPagedPoolUsage','QuotaPeakNonPagedPoolUsage','QuotaNonPagedPoolUsage','PagefileUsage','PeakPagefileUsage','PrivateUsage')]
        p=ProcessMemory();p.cb=ctypes.sizeof(p)
        handle=ctypes.windll.kernel32.GetCurrentProcess();ctypes.windll.psapi.GetProcessMemoryInfo.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_ulong]
        if ctypes.windll.psapi.GetProcessMemoryInfo(handle,ctypes.byref(p),p.cb):v.update(process_RSS_bytes=p.WorkingSetSize,process_private_bytes=p.PrivateUsage,process_peak_RSS_bytes=p.PeakWorkingSetSize)
    except Exception as e:v['resource_error']=str(e)
    return v
