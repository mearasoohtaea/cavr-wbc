"""Exact canonical selection; NOT_RUN alone never means undispatched."""
from cavr_wbc.experiments.step52_io import *
UNKNOWN_IDS={43:'T51_NEG_2_T039_RR_THIGH15:MIDDLE_RECOVER_RESUME',53:'T51_NEG_3_T037_RR_THIGH15:MIDDLE_RECOVER_RESUME'}
def build_plan(freeze,rows):
    positions=freeze['positions'];by={r['id']:r for r in rows}
    if len(positions)!=176 or len(rows)!=176 or len(by)!=176:raise ValueError('176 unique positions required')
    slots=[]
    for p in positions:
        n=p['position_ordinal'];r=by[p['id']]
        if n in UNKNOWN_IDS:
            if p['id']!=UNKNOWN_IDS[n] or not r.get('dispatched_unknown'):raise ValueError('exact old UNKNOWN identity')
            action='RECOVER_SAVED_FIRST' if n==43 else 'ATTEMPT2'
        elif n<54:action='REUSE_KNOWN'
        else:
            if r.get('actual_governor_call') or r.get('observed') or r.get('dispatched_unknown'):raise ValueError('undispatched boundary changed')
            action='NEW_ATTEMPT1'
        slots.append(dict(canonical_id=f'SLOT{n+1:04d}',position=p,action=action,old_status=r['status'],origin_run=str(SOURCE_RUN),historical_UNKNOWN=n in UNKNOWN_IDS))
    known=[s for s in slots if s['action']=='REUSE_KNOWN'];pending=[s for s in slots if s['action']=='NEW_ATTEMPT1'];unknown=[s for s in slots if s['historical_UNKNOWN']]
    if (len(known),len(pending),len(unknown))!=(52,122,2):raise ValueError('fixed52/122/2')
    for s in known:
        if s['old_status'].startswith('UNKNOWN'):raise ValueError('cannot reuse UNKNOWN as known')
    reused=freeze['episodes'][:4];new=freeze['episodes'][4:]
    if [e['episode_id'] for e in reused]!=[f'T51_NEG_{i}' for i in range(4)] or len(new)!=8:raise ValueError('reference4/8')
    return dict(slots=slots,known=known,pending=pending,unknown=unknown,references_reused=reused,episodes_to_generate=new,
        planned_positions=176,max_new_task_attempts=124,NOT_RUN_string_selection_forbidden=True)
def old_result_path(p):
    continued=SOURCE_RUN/'continuation/branches'/p['context_id']/p['arm']/'RESULT.json'
    return continued if continued.exists() else SOURCE_RUN/'branches'/p['context_id']/p['arm']/'RESULT.json'
