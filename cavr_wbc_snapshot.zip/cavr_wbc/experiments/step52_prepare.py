"""One combined preparation: small assets, frozen source and actual resources."""
import os,shutil,struct,subprocess,sys
from cavr_wbc.experiments.step52_io import *
from cavr_wbc.experiments.step52_plan import build_plan,old_result_path
def git(root,*args):
    env=dict(os.environ)
    for k in ('GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_COMMON_DIR'):env.pop(k,None)
    env['GIT_OPTIONAL_LOCKS']='0'
    return subprocess.check_output(['git','-C',str(root),*args],env=env,text=True,encoding='utf-8').strip()
def run():
    if (OUT/'PREPARATION.json').exists():raise FileExistsError('preparation already saved')
    if git(SOURCE_ROOT,'rev-parse','HEAD')!=SOURCE_COMMIT:raise ValueError('source head mismatch')
    if git(SOURCE_ROOT,'status','--porcelain=v1','--untracked-files=no'):raise ValueError('source tracked state dirty')
    if git(ROOT,'rev-parse','HEAD')!=SOURCE_COMMIT:raise ValueError('target parent mismatch')
    OUT.mkdir(parents=True,exist_ok=True);probe=ROOT/'.runtime/STEP52_WRITE_PROBE.tmp';probe.write_bytes(b'STEP52');probe.unlink()
    copied={}
    for name in ('SOURCE_FROZEN_CONFIG.json','METHOD_INPUT_FREEZE.json','INPUTS_PLAN.json','STEP48_CAL_FREEZE.json','PROTOCOL_AND_MANIFEST.json','NUMERICAL_COMPLETION_WITH_CONTINUATION.json','RESULT.json','BRANCH_ROWS.json','READBACK_VERDICT.json'):
        p=OUT/'source_metadata'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(SOURCE_RUN/name,p);copied[name]=sha(p)
    for name in ('PHASE_MATCHED_TASK.npz','PHASE_MATCHED_TASK.json','PHASE_MATCHED_TASK_DOMAIN.json'):
        p=OUT/'models'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(SOURCE_RUN/'models'/name,p)
        if sha(p)!=sha(SOURCE_RUN/'models'/name):raise ValueError('model copy mismatch')
        copied['models/'+name]=sha(p)
    dst=ROOT/'configs/validation/STEP52_PROTOCOL.md';shutil.copyfile(PROTOCOL,dst)
    freeze=read(OUT/'source_metadata/METHOD_INPUT_FREEZE.json');rows=read(OUT/'source_metadata/BRANCH_ROWS.json');plan=build_plan(freeze,rows)
    old_manifest=read(SOURCE_RUN/'EVIDENCE_MANIFEST.json');hashes={q['path']:q['sha256'] for q in old_manifest['files']}
    for s in plan['slots']:
        p=old_result_path(s['position']);s['old_result_path']=str(p);s['old_result_sha256']=hashes[str(p.relative_to(SOURCE_RUN)).replace('\\','/')]
    refs=[]
    for e in plan['references_reused']:
        p=SOURCE_RUN/'episodes'/(e['episode_id']+'.json')
        refs.append(dict(episode_id=e['episode_id'],path=str(p),json_sha256=hashes[str(p.relative_to(SOURCE_RUN)).replace('\\','/')],npz_sha256=hashes[str(p.with_suffix('.npz').relative_to(SOURCE_RUN)).replace('\\','/')],new_QP=0,new_steps=0))
    plan['reference_sources']=refs;write_new(OUT/'COMPLETION_PLAN.json',plan)
    source_files={str(p.relative_to(SOURCE_ROOT)).replace('\\','/'):sha(p) for p in (SOURCE_ROOT/'.git/index',SOURCE_RUN/'RESULT.json',SOURCE_RUN/'REPORT.md',SOURCE_RUN/'HANDOFF.md',SOURCE_RUN/'READBACK_VERDICT.json',SOURCE_RUN/'METHOD_INPUT_FREEZE.json')}
    config=read(OUT/'source_metadata/SOURCE_FROZEN_CONFIG.json');physical=config['frozen_physical']['model_files_sha256']
    if any(sha(ROOT/p)!=h for p,h in physical.items()):raise ValueError('source plant assets changed')
    for p,h in freeze['runtime_sha256'].items():
        if sha(ROOT/p)!=h:raise ValueError('source runtime differs '+p)
    native=ROOT/'artifacts/step30_injured_governor_20261008/step30-injured-governor-20261008-01/native/step30_prefix.dll'
    if sha(native)!=freeze['native_sha256']:raise ValueError('native differs')
    import numpy,mujoco,cavr_wbc
    if not str(Path(cavr_wbc.__file__).resolve()).startswith(str(ROOT.resolve())):raise ValueError('wrong package')
    if struct.calcsize('P')!=8:raise ValueError('64bit required')
    status=dict(pid=os.getpid(),timestamp_utc=utc(),source_commit=SOURCE_COMMIT,source_files_sha256=source_files,source_head=SOURCE_COMMIT,
        source_tracked_status='',copied_small_assets_sha256=copied,native_sha256=sha(native),plant_asset_hashes=physical,
        D_disk_free_bytes=shutil.disk_usage(ROOT).free,resource=resource_snapshot(),interpreter=sys.executable,interpreter_bits=64,
        package_path=cavr_wbc.__file__,numpy_version=numpy.__version__,mujoco_version=mujoco.__version__,
        old_QP=OLD_QP,old_steps=OLD_STEPS,old_active_seconds=OLD_ACTIVE,known_positions=52,pending_positions=122,
        unknown_positions=2,references_reused=4,references_new=8,new_QP=0,new_steps=0,
        git_object_storage='new objects in D; D-only read-only source alternate',no_large_bank_recursive_copy=True)
    write_new(OUT/'PREPARATION.json',status);print(dict(preparation='PASS',D_free_GB=status['D_disk_free_bytes']/1e9,resource=status['resource'],positions='52/122/2',references='4/8'),flush=True)
if __name__=='__main__':run()
