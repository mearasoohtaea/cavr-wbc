"""Memory-bounded raw readback: identical scalar checks without array rebuilding."""
import argparse,hashlib,json
from pathlib import Path
from cavr_wbc.experiments.step52_io import read,write_new

def stream_sha(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(65536),b''):digest.update(block)
    return digest.hexdigest()

def inspect(job_path,dest):
    job=read(job_path);path=Path(job['job_out']);issues=[];starts=set();returns=set();owners={};events=[];verified=[]
    ledger=path/'WORKER_LEDGER.jsonl'
    if ledger.exists():
        with ledger.open(encoding='utf-8') as stream:
            for line in stream:
                try:q=json.loads(line)
                except ValueError:issues.append('torn ledger line');continue
                if q['event']=='QP_START':starts.add(q['global_qp_index'])
                elif q['event']=='QP_RETURN':returns.add(q['global_qp_index']);owners[q['global_qp_index']]=q.get('solver_owner_id')
                elif q['event']=='RAW_QP_SAVED':events.append(q)
        for q in events:
            p=path/q['path'];h=read(p);r=h['record'];ix=r['global_qp_index']
            if not isinstance(ix,int) or isinstance(r['raw_result'].get('solver_owner_id'),dict):raise ValueError('owner/index not scalar typed metadata')
            if stream_sha(p)!=q['json_sha256'] or stream_sha(p.with_suffix('.npz'))!=q['npz_sha256']:issues.append('raw SHA '+q['path'])
            if h['numeric_sha256']!=q['npz_sha256'] or h['numeric_npz']!=p.with_suffix('.npz').name:issues.append('typed numeric header binding '+q['path'])
            if ix not in returns or r['raw_result'].get('solver_owner_id')!=owners[ix]:issues.append('raw owner/index '+str(ix))
            verified.append(ix)
    worker=read(path/'WORKER_RECEIPT.json',{});known=worker.get('status')=='KNOWN'
    if known and (starts!=returns or set(verified)!=starts or len(verified)!=len(starts)):issues.append('known START/RETURN/raw counts')
    if len(starts)!=worker.get('budget',{}).get('new_QP_calls',len(starts)):issues.append('QP receipt increment')
    grid_checks=[]
    if job['kind']=='REPLAY':
        for p in sorted(path.glob('*_DENSE.json')):
            h=read(p);r=h['record'];dense=r['dense']
            ok=len(dense)==2001 and all(f['physics_step']==i for i,f in enumerate(dense))
            if not ok:issues.append('replay 2001 dense/grid')
            if stream_sha(p.with_suffix('.npz'))!=h['numeric_sha256']:issues.append('replay dense numeric SHA')
            grid_checks.append(dict(path=p.name,dense_count=len(dense),grid_pass=ok))
        for p in sorted(path.glob('*_INPUT.json')):
            h=read(p);r=h['record'];ok=len(r.get('controls',[]))==200
            if not ok:issues.append('replay controls200')
            if stream_sha(p.with_suffix('.npz'))!=h['numeric_sha256']:issues.append('replay input numeric SHA')
            grid_checks.append(dict(path=p.name,controls_count=len(r.get('controls',[])),grid_pass=ok))
    if job['kind']=='REFERENCE' and worker.get('episode_path'):
        p=Path(worker['episode_path']);h=read(p);ep=h['record'];requested=job['episode']['snapshot_ticks']
        actual=[s['source_tick'] for s in ep['snapshots']]
        if ep['episode_id']!=job['episode']['episode_id'] or any(t not in requested for t in actual):issues.append('reference identity/tick')
        if ep['status']=='COMPLETE' and (ep['counts']['physical_steps']!=1100 or len(ep['controls'])!=110 or actual!=requested):issues.append('complete reference count')
        if stream_sha(p.with_suffix('.npz'))!=h['numeric_sha256']:issues.append('reference numeric SHA')
        grid_checks.append(dict(path=p.name,status=ep['status'],snapshot_ticks=actual,requested_ticks=requested,physical_steps=ep['counts']['physical_steps']))
    write_new(Path(dest)/'RAW_RECEIPT.json',dict(status='MATCH' if not issues else 'MISMATCH',issues=issues,job_id=job['job_id'],
        started=sorted(starts),returned=sorted(returns),verified_raw=verified,decoded_raw=[],known_outcome=known,
        verification_scope='FULL_JSON_NPZ_STREAMING_SHA_AND_SCALAR_OWNER_INDEX_START_RETURN',equivalent_owner_index_checks=True,
        numeric_array_reconstruction=0,stream_chunk_bytes=65536,replay_grid_checks=grid_checks,new_QP=0,new_steps=0))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--job',required=True);p.add_argument('--dest',required=True);a=p.parse_args();inspect(a.job,a.dest)
