"""Single-process zero-numerical recovery of only ordinal43 orphan facts."""
from cavr_wbc.experiments.step52_io import *
def recoverable_saved_identity(position):return position['position_ordinal']==43 and position['id']=='T51_NEG_2_T039_RR_THIGH15:MIDDLE_RECOVER_RESUME'
def recovery_missing(branch):
    return [k for k in ('initial_fact','physics_trajectory','controls','counts','continuity_start','continuity_end','phase1_online_summary','health_vector','application_identity_pass') if k not in branch]
def run(job_path):
    from time import perf_counter
    job=read(job_path);out=Path(job['job_out']);out.mkdir(parents=True,exist_ok=True);start=perf_counter();errors=[];status='NOT_RECOVERABLE'
    write_new(out/'WORKER_STARTED.json',dict(pid=os.getpid(),kind='RECOVERY',job_id=job['job_id'],resource=resource_snapshot(),new_QP=0,new_steps=0))
    try:
        if not recoverable_saved_identity(job['position']):raise ValueError('only exact ordinal43 authorized')
        install_streaming()
        from cavr_wbc.experiments.step47_io import load_numeric
        from cavr_wbc.experiments.step50_storage import load_branch,capacity_series,contact_statistics
        from cavr_wbc.evaluation.step50_actual import evaluate
        from cavr_wbc.control.step50_dispatch import first_sent
        source=Path(job['source_result_path']).parent
        expected=job['orphan_sha256'];hashes={n:sha(source/n) for n in ('actual.npz','controls.json','controls.npz','PACKET.json','POLICY_CONTEXT.json')}
        if any(hashes[k]!=v for k,v in expected.items()):raise ValueError('orphan source SHA mismatch')
        b=load_branch(source);missing=recovery_missing(b)
        if missing:raise KeyError('missing branch fields '+str(missing))
        c=load_numeric(source/'POLICY_CONTEXT.json');packet=load_numeric(source/'PACKET.json')
        p=job['position']
        if c['context_id']!=p['context_id'] or c['external_arm']!=p['arm'] or c['step51_method_freeze_sha256']!=job['source_method_sha']:raise ValueError('source frozen identity')
        if not first_sent(packet,c):raise ValueError('orphan branch has no sent first packet')
        if b['continuity_start']!=b['continuity_end'] or not b['application_identity_pass']:raise ValueError('owner/plant/PID/application identity')
        dense=([b['initial_fact']] if b.get('initial_fact') else [])+b['physics_trajectory']
        if len(dense)!=b['counts']['physical_steps']+int(b.get('initial_fact') is not None) or any(abs(f['time_s']-f['physics_step']*.002)>1e-9 for f in dense):raise ValueError('orphan actual grid')
        for ctrl in b['controls']:
            ref=ctrl.get('raw_solver_evidence')
            if ref and not (SOURCE_RUN/ref).exists():raise ValueError('orphan raw reference missing')
        ev=evaluate(b,c,packet)
        if ev['phase1']!=b['phase1_online_summary']:raise ValueError('original gate/evaluation identity')
        from cavr_wbc.experiments.step51_storage import save_branch
        # Use source scalar result construction, preserving original bank/raw paths.
        result=dict(status=b['status'],reason=b.get('reason'),observed=True,gamma=b['gamma'],
            **{k:p[k] for k in ('id','context_id','arm','episode','snapshot_id','tick','health_kind','block','direction','severe')},
            backup_id=c['backup_id'],experimental_applied=b['counts']['physical_steps']>10,counts=b['counts'],
            experimental_dispatch=bool(packet.get('experimental_dispatch')),experimental_committed=bool(packet.get('experimental_committed')),
            model_authorized=bool(packet.get('model_authorized')),learner_approved=bool(packet.get('learner_approved')),
            governor_selected=bool(packet.get('governor_selected')),selected_command_sent=bool(packet.get('selected_command_sent')),
            nominal_sent=bool(packet.get('nominal_sent')),dispatch_kind=packet.get('dispatch_kind'),packet_status=packet['status'],
            first_packet_ready_ms=packet.get('command_ready_ms'),first_packet_prepared_ms=packet.get('prepared_commit_ms'),
            policy_version=packet.get('policy_version'),policy_contract=packet.get('policy_contract'),
            composite_policy_id=packet.get('composite_policy_id'),authorization_scope='RECOVERY_1S_ONLY',old_CAL_certifies_mission=False,
            source_goal=c.get('policy_anchor_goal'),original_anchor_changed=False,
            evaluation=ev,capacity=capacity_series(b,c),contact_statistics=contact_statistics(b),handoff=b.get('handoff'),
            phase1_online_summary=b['phase1_online_summary'],continuity_start=b['continuity_start'],continuity_end=b['continuity_end'],
            application_identity_pass=b['application_identity_pass'],complete_2001=ev['whole_complete'],mission_success=ev['mission_success'],
            step51_method_freeze_sha256=job['source_method_sha'],step50_method_freeze_sha256=job['source_step50_sha'],
            derived_recovery='RECOVERED_FROM_SAVED_EVIDENCE',source_branch_path=str(source),source_hashes=hashes,
            history_UNKNOWN_preserved=True,new_QP=0,new_steps=0,attempt_id=job['attempt_id'],canonical_id=job['canonical_id'])
        from cavr_wbc.experiments.step47_io import encode
        write_new(out/'RESULT.json',encode(result));status='RECOVERED_FROM_SAVED_EVIDENCE'
    except (KeyError,FileNotFoundError) as e:errors.append(dict(type=type(e).__name__,message=str(e)))
    except BaseException as e:
        errors.append(dict(type=type(e).__name__,message=str(e)));status='RESOURCE_FAILURE' if isinstance(e,MemoryError) else 'IDENTITY_ERROR'
    receipt=dict(job_id=job['job_id'],kind='RECOVERY',status=status,pid=os.getpid(),errors=errors,
        result_path=str(out/'RESULT.json') if (out/'RESULT.json').exists() else None,
        budget=dict(new_QP_calls=0,QP_returns=0,new_integration_steps=0,reserved_steps=0,integration_upper_bound=0),
        duration_s=perf_counter()-start,resource=resource_snapshot(),new_numerical_reproduction=False)
    write_new(out/'WORKER_RECEIPT.json',receipt);print(dict(status=status,new_QP=0,new_steps=0),flush=True)
if __name__=='__main__':
    import argparse
    a=argparse.ArgumentParser();a.add_argument('--job',required=True);run(a.parse_args().job)
