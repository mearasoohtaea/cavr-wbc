"""One authorized new physics attempt for missing DEV0 governor replay only."""
from pathlib import Path
import argparse
np=None

REPLAY_POSITIONS=(('T50_DEV_0_T041_RR_THIGH15','GOVERNED_RECOVER_RESUME'),)
MAX_REPLAY_STEPS=2000
_FIELDS=('time_s','integration_state_signature','integration_state','qpos','qvel','act','ctrl',
    'qacc_warmstart','qfrc_applied','xfrc_applied','mocap_pos','mocap_quat','userdata','plugin_state')
def required_seed_fields():return _FIELDS
def seed_missing(seed):return [k for k in _FIELDS if k not in seed]
def stored_interface(ctrl):
    """Recover the raw torque field stored alongside the slim interface."""
    return {**ctrl['capacity_interface'],'tau_raw':ctrl['tau_raw']}
def bitwise_difference(a,b):
    import numpy as np
    av,bv=np.asarray(a),np.asarray(b)
    eq=av.shape==bv.shape and av.dtype==bv.dtype and av.tobytes()==bv.tobytes()
    delta=float(np.max(np.abs(av.astype(float)-bv.astype(float)))) if av.size and av.shape==bv.shape else 0. if av.shape==bv.shape else None
    return eq,delta
def control_for_step(controls,step):
    import numpy as np
    if not isinstance(step,int) or not 0<=step<2000:raise ValueError('replay step 0..1999')
    slot=step//10
    if len(controls)!=200 or controls[slot]['slot']!=slot:raise ValueError('200 immutable control slots required')
    tau=np.asarray(controls[slot].get('tau_applied'),dtype=float)
    if tau.shape!=(12,) or not np.isfinite(tau).all():raise ValueError('saved actual applied tau missing')
    return tau.copy()

def _physics_run(job_path):
    global np
    import numpy as np
    from cavr_wbc.experiments.step52_io import read as read_job,write_new,resource_snapshot,utc
    import time,os
    job=read_job(job_path);out=Path(job['job_out']);start_wall=time.perf_counter()
    from cavr_wbc.experiments.step52_io import install_streaming
    install_streaming()
    import mujoco
    from datetime import datetime,timezone
    from cavr_wbc.experiments.step51_io import SOURCE_RUN,OUTPUT_ROOT_D,read,write,sha,load_numeric,save_numeric
    from cavr_wbc.experiments.step50_storage import load_branch
    from cavr_wbc.experiments.step26_sim import compact_fact,restore_snapshot
    from cavr_wbc.evaluation.step23_actual import actual_reasons
    from cavr_wbc.experiments.step47_storage import contact_statistics
    folder=Path(out); folder.mkdir(parents=True,exist_ok=True)
    if (folder/'REPLAY_STARTED.json').exists():raise FileExistsError('no replay retries')
    write(folder/'REPLAY_STARTED.json',dict(start_utc=datetime.now(timezone.utc).isoformat(),positions=REPLAY_POSITIONS,new_QP_calls=0))
    manifest=read(SOURCE_RUN/'SOURCE_FROZEN_CONFIG.json')
    hashes=manifest['frozen_physical']['model_files_sha256']
    if any(sha(OUTPUT_ROOT_D/p)!=h for p,h in hashes.items()):raise ValueError('replay source plant asset changed')
    model=mujoco.MjModel.from_xml_path(str(OUTPUT_ROOT_D/'third_party/unitree_mujoco_snapshot/unitree_robots/go2/scene.xml'))
    rows=[];steps=0;error=None;receipt=None
    start=datetime.now(timezone.utc)
    progress=folder/'REPLAY_STEPS.jsonl'
    def record_step(event):
        with progress.open('a',encoding='utf-8') as f:f.write(__import__('json').dumps(dict(event=event,steps=steps,job_id=job['job_id']))+'\n');f.flush()
    def cap():
        if time.time()>=job['deadline_epoch_s'] or steps>=min(2000,job['remaining_steps']):raise RuntimeError('STEP52 active/replay budget cap')
    if job['remaining_steps']<2000:raise RuntimeError('2000 replay reservation exceeds remainder')
    try:
        for context_id,arm in REPLAY_POSITIONS:
            if any(r['context_id']==context_id and r['arm']==arm for r in rows):continue
            cap()
            base=SOURCE_RUN/'branches'/context_id/arm
            receipt=dict(context_id=context_id,arm=arm,actual_steps=0,new_QP_calls=0,
                source_actual_sha256=sha(base/'actual.npz'),source_controls_sha256=sha(base/'controls.npz'),
                source_asset_hashes=hashes,platform_mujoco_version=mujoco.__version__,
                scope='FROZEN_CONTROL_PHYSICS_ONLY',controller_recomputed=False)
            b=load_branch(base);seed=b.get('initial_state') or {};missing=seed_missing(seed)
            if missing:
                receipt.update(status='NOT_REPRODUCIBLE_FROM_SAVED_SEED',missing_fields=missing)
                rows.append(receipt);write(folder/(context_id+'_'+arm+'.json'),receipt);continue
            controls=b['controls'];dense=[b['initial_fact']]+b['physics_trajectory']
            if len(dense)!=2001 or len(controls)!=200:raise ValueError('specified source branch not complete 4s')
            receipt.update(source_model_sha256=sha(SOURCE_RUN/'models/PHASE_MATCHED_TASK.npz'),
                source_domain_sha256=sha(SOURCE_RUN/'models/PHASE_MATCHED_TASK_DOMAIN.json'),health_vector=b['health_vector'])
            save_numeric(folder/(context_id+'_'+arm+'_INPUT.json'),dict(seed=seed,
                health_vector=b['health_vector'],controls=[dict(slot=r['slot'],tau_applied=r['tau_applied']) for r in controls]))
            # Unit-gain, stateless joint motors: applied torque maps directly to ctrl.
            mapping=manifest['mapping']
            if any(r['gain_parameters'][0]!=1 or any(r['bias_parameters']) or r['activation_dimension']!=0
                or r['dynamic_type']!='mjDYN_NONE' for r in mapping):raise ValueError('unsupported applied-torque ctrl mapping')
            data=restore_snapshot(model,seed)
            health=np.asarray(b['health_vector']);limits=np.asarray(dense[0]['actuator_limits'])
            fresh=[];first_difference=None;maxdiff={};gate_diffs=[];state_diffs=[]
            def compare(f,old):
                nonlocal first_difference
                fields=['qpos','qvel','actual_mujoco_qacc','tau_applied','subtree_com','base_joint_height_m',
                    'subtree_com_height_m','tau_cmd','tau_sent','actuator_limits','command_torque_margin_nm',
                    'applied_torque_margin_nm','joint_limit_margins','friction_coeff','roll','pitch',
                    'boundary_margin_m','health_vector']
                def contact_arrays(row):
                    return {f'contacts:{foot}:{key}':value for foot,contact in row['contacts'].items()
                        for key,value in contact.items() if np.asarray(value).dtype.kind in 'biuf'}
                f={**f,**contact_arrays(f)};old={**old,**contact_arrays(old)}
                fields+=sorted(contact_arrays(fresh[-1]))
                for field in fields:
                    eq,delta=bitwise_difference(f[field],old[field])
                    maxdiff[field]=max(maxdiff.get(field,0.),delta) if delta is not None else None
                    if not eq:
                        if first_difference is None:first_difference=dict(physics_step=f['physics_step'],field=field,max_abs_difference=delta)
                        state_diffs.append(dict(physics_step=f['physics_step'],field=field,max_abs_difference=delta))
                aa=actual_reasons(f);bb=actual_reasons(old)
                if aa!=bb:gate_diffs.append(dict(physics_step=f['physics_step'],replay=aa,source=bb))
            for slot,ctrl in enumerate(controls):
                tau=control_for_step(controls,slot*10);data.ctrl[:]=tau
                mujoco.mj_forward(model,data)
                if not np.array_equal(data.actuator_force,tau):raise ValueError('actual torque ctrl mapping mismatch')
                interface=stored_interface(ctrl);meta={k:dense[0][k] for k in ('health_vector','context_id','faulted_actuator_name','faulted_actuator_index','faulted_health') if k in dense[0]}
                if slot==0:
                    f=compact_fact(model,data,health,limits,tau,ctrl.get('action',0.),ctrl.get('latency_ms',0.),0,slot,b['backup_id'],b['branch_id'],interface,meta)
                    fresh.append(f);compare(f,dense[0])
                for local in range(10):
                    cap();record_step('STEP_START');mujoco.mj_step(model,data);steps+=1;receipt['actual_steps']+=1;record_step('STEP_RETURN')
                    mujoco.mj_forward(model,data)
                    step=slot*10+local+1
                    if abs(data.time-step*.002)>1e-9:raise ValueError('replay physical clock reset')
                    f=compact_fact(model,data,health,limits,tau,ctrl.get('action',0.),ctrl.get('latency_ms',0.),step,slot,b['backup_id'],b['branch_id'],interface,meta)
                    fresh.append(f);compare(f,dense[step])
            final=[]
            final_vector=np.empty(mujoco.mj_stateSize(model,int(seed['integration_state_signature'])))
            mujoco.mj_getState(model,data,final_vector,int(seed['integration_state_signature']))
            if final_vector.tobytes()!=np.asarray(b['final_state']['integration_state'],dtype=float).tobytes():final.append('integration_state')
            for field in _FIELDS:
                if field in ('integration_state_signature','integration_state'):continue
                av=np.asarray(data.time if field=='time_s' else getattr(data,field));bv=np.asarray(b['final_state'][field])
                if av.size!=bv.size or av.ravel().tobytes()!=bv.ravel().tobytes():final.append(field)
            replay_contacts=contact_statistics(dict(initial_fact=fresh[0],physics_trajectory=fresh[1:]))
            source_contacts=contact_statistics(b)
            receipt.update(status='MATCH' if first_difference is None and not final else 'BITWISE_MISMATCH',
                stepwise_comparison='BITWISE_SAVED_DENSE_FIELDS',first_difference=first_difference,max_abs_difference=maxdiff,
                differing_step_fields=len(state_diffs),final_seed_field_differences=final,
                physical_gate_classification_match=not gate_diffs,physical_gate_differences=gate_diffs,
                contact_statistics=replay_contacts,source_contact_statistics=source_contacts,
                first_contact_event_match=all(replay_contacts['contacts'][k]['CONTACT_LOSS']['first_s']==v['CONTACT_LOSS']['first_s'] for k,v in source_contacts['contacts'].items()),
                original_step50_verdict_unchanged=True)
            save_numeric(folder/(context_id+'_'+arm+'_DENSE.json'),dict(dense=fresh,state_differences=state_diffs))
            rows.append(receipt);write(folder/(context_id+'_'+arm+'.json'),receipt)
            del b,data,fresh
    except Exception as exc:
        error=dict(type=type(exc).__name__,message=str(exc))
        if receipt is not None and not any(r['context_id']==receipt['context_id'] and r['arm']==receipt['arm'] for r in rows):
            receipt.update(status='UNKNOWN',error=error);rows.append(receipt)
    finally:
        saved={(r['context_id'],r['arm']) for r in rows}
        for context_id,arm in REPLAY_POSITIONS:
            if (context_id,arm) not in saved:rows.append(dict(context_id=context_id,arm=arm,status='NOT_RUN',actual_steps=0,new_QP_calls=0,reason=error))
        write(folder/'REPLAY_RESULT.json',dict(status='COMPLETED_WITH_PRIOR_UNKNOWN' if error is None else 'INCOMPLETE',rows=rows,error=error,
            actual_steps=steps,new_QP_calls=0,max_steps=MAX_REPLAY_STEPS,
            original_UNKNOWN_preserved=True,numerical_elapsed_s=(datetime.now(timezone.utc)-start).total_seconds(),
            original_numerical_started_utc=start.isoformat(),storage_fix_only=False,
            independent_full_method_numerical_reproduction='UNVERIFIED',new_independent_episodes=0))
    worker_status='SAVED' if error is None else 'RESOURCE_FAILURE' if error['type'] in ('MemoryError','FatalError') else 'UNKNOWN'
    write_new(folder/'WORKER_RECEIPT.json',dict(job_id=job['job_id'],kind='REPLAY',status=worker_status,pid=os.getpid(),replay_path=str(folder/'REPLAY_RESULT.json'),budget=dict(new_QP_calls=0,QP_returns=0,new_integration_steps=steps,reserved_steps=sum(1 for line in progress.open(encoding='utf-8') if __import__('json').loads(line)['event']=='STEP_START')-steps if progress.exists() else 0,integration_upper_bound=sum(1 for line in progress.open(encoding='utf-8') if __import__('json').loads(line)['event']=='STEP_START') if progress.exists() else steps),duration_s=time.perf_counter()-start_wall,resource=resource_snapshot()))
    print(dict(replay_status=[r['status'] for r in rows],actual_steps=steps,new_QP_calls=0),flush=True)
def run(job_path):
    from cavr_wbc.experiments.step52_io import read,write_new,resource_snapshot
    import os,json
    job=read(job_path);out=Path(job['job_out']);out.mkdir(parents=True,exist_ok=True)
    write_new(out/'WORKER_STARTED.json',dict(pid=os.getpid(),kind='REPLAY',job_id=job['job_id'],resource=resource_snapshot(),new_QP=0,new_steps=0))
    try:_physics_run(job_path)
    except BaseException as e:
        starts=returns=0;p=out/'REPLAY_STEPS.jsonl'
        if p.exists():
            with p.open(encoding='utf-8') as f:
                for line in f:
                    q=json.loads(line);starts+=q['event']=='STEP_START';returns+=q['event']=='STEP_RETURN'
        status='RESOURCE_FAILURE' if isinstance(e,MemoryError) or any(k in str(e).lower() for k in ('allocate memory','out of memory')) else 'IDENTITY_OR_INTERFACE_ERROR'
        write_new(out/'WORKER_RECEIPT.json',dict(job_id=job['job_id'],kind='REPLAY',status=status,pid=os.getpid(),error=dict(type=type(e).__name__,message=str(e)),budget=dict(new_QP_calls=0,QP_returns=0,new_integration_steps=returns,reserved_steps=starts-returns,integration_upper_bound=starts),resource=resource_snapshot()))
def replay_position():return REPLAY_POSITIONS[0]
def excluded_matches(prior):return [r for r in prior['rows'] if r['status']=='MATCH']
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--job',type=Path,required=True);run(p.parse_args().job)
