"""Chinese completion report from final scalar summaries; no numerical work."""
from collections import Counter
from datetime import datetime
import json
import math
from statistics import median
from cavr_wbc.experiments.step52_io import OUT,ROOT,SOURCE_RUN,SOURCE_COMMIT,PROTOCOL,read,write

ARMS=('GOVERNED_RECOVER_RESUME','MIDDLE_RECOVER_RESUME','MIDDLE_IMMEDIATE_MISSION','B_RECOVER_RESUME','NOMINAL_IMMEDIATE')
SEGMENTS=('STEP51','STEP52_RESOURCE_ISOLATED','STEP51_DERIVED_RECOVERY')

def unknown(row):
    return row.get('canonical_status')=='UNKNOWN' or str(row.get('status','')).startswith('UNKNOWN')

def undispatched(row):
    return row.get('canonical_status') in ('NOT_DISPATCHED','NOT_RUN_REFERENCE_UNAVAILABLE')

def counts(rows):
    u=sum(unknown(r) for r in rows); missing=sum(undispatched(r) for r in rows)
    return dict(planned=len(rows),processed=len(rows)-u-missing,UNKNOWN=u,undispatched=missing,
        observed=sum(bool(r.get('observed')) for r in rows),complete_4s=sum(bool(r.get('complete_2001')) for r in rows),
        mission_success=sum(bool(r.get('mission_success')) for r in rows),
        known_unsent=sum(not unknown(r) and not undispatched(r) and not r.get('observed') for r in rows),
        segments=dict(Counter(r.get('segment') or 'NOT_DISPATCHED' for r in rows)))

def nref(result):
    refs=result.get('references',[])
    return sum(r.get('reference_status',r.get('status'))=='COMPLETE' for r in refs)

def replay_rows(result):
    replay=result.get('replay') or {}
    # Only scalar replay receipts, never stored controls/dense arrays.
    old=read(SOURCE_RUN/'replay_continuation/REPLAY_RESULT.json',{}).get('rows',[])
    completion=read(OUT/'REPLAY_COMPLETION.json',{})
    new=read(completion.get('new_result_path','__missing__'),{}).get('rows',[])
    by={(r['context_id'],r['arm']):r for r in old}
    by.update({(r['context_id'],r['arm']):r for r in new})
    authoritative=replay if isinstance(replay,list) else replay.get('rows',[])
    by.update({(r['context_id'],r['arm']):r for r in authoritative})
    return list(by.values())

def table_groups(rows):
    lines=['|方向/健康/方法|计划|已知处理|首包已知施加|完整4s|任务成功|UNKNOWN|未派发|',
           '|---|---:|---:|---:|---:|---:|---:|---:|']
    for block in ('NEG_CONFIRM','POS_TRANSFER'):
        for arm in ARMS:
            own=[r for r in rows if r['block']==block and r['health_kind']=='RR_THIGH15' and r['arm']==arm]
            c=counts(own)
            lines.append(f"|{block}/{arm}|{len(own)}|{c['processed']}|{sum(bool(r.get('experimental_applied')) for r in own)}|{c['complete_4s']}|{c['mission_success']}|{c['UNKNOWN']}|{c['undispatched']}|")
    for health in ('HEALTHY','RR_THIGH30'):
        own=[r for r in rows if r['health_kind']==health];c=counts(own)
        lines.append(f"|{health}/NOMINAL|{len(own)}|{c['processed']}|{sum(bool(r.get('experimental_applied')) for r in own)}|{c['complete_4s']}|{c['mission_success']}|{c['UNKNOWN']}|{c['undispatched']}|")
    return '\n'.join(lines)

def paired_description(pairs):
    summaries=[]
    for key,scale,label in (('final_goal_error_m',1000.,'绝对goal误差(mm)'),
        ('sustained_goal_stop_time_s',1.,'settled time(s)'),
        ('external_reference_error_integral_0to4_available_m_s',1000.,'0–4s误差积分(mm s)'),
        ('external_reference_error_integral_1to4_available_m_s',1000.,'1–4s误差积分(mm s)'),
        ('final_half_second_vx_RMS_m_s',1000.,'末vx RMS(mm/s)')):
        values=[]
        for p in pairs:
            v=p['continuous'][key];a,b=v['a'],v['b']
            if not isinstance(a,(int,float)) or not isinstance(b,(int,float)) or not math.isfinite(a) or not math.isfinite(b):continue
            values.append(((abs(b)-abs(a)) if key=='final_goal_error_m' else b-a)*scale)
        summaries.append(f"{label}：B−A中位数{median(values):.6g}（n={len(values)}）" if values else f"{label}：未取得双边可用值（n=0）")
    return '；'.join(summaries)

def claims(ep,replays):
    lines=['|证据/claim|真实结局|定位|解释范围|','|---|---|---|---|']
    for block in ('NEG_CONFIRM','POS_TRANSFER'):
        s=ep['S_RECOVERY'][block]
        scope='主臂没有实际governor决定，恢复质量未测' if not s['actual_decisions'] else '没有可评价认可恢复，不估计错受率' if not s['false_acceptance_evaluable_denominator'] else '仅实际施加且完整可评价的认可恢复；少量零错受不表示零风险'
        lines.append(f"|S {block}|决定{s['actual_decisions']}，认可/发送/恢复={s['recognized']}/{s['timely_sent']}/{s['recovery']}；错受{s['false_acceptance']}/{s['false_acceptance_evaluable_denominator']}|RESULT.endpoints.S_RECOVERY.{block}|{scope}|")
    for key,block in (('M_NEG','NEG_CONFIRM'),('M_POS','POS_TRANSFER')):
        m=ep[key];scope='主臂任务质量未测' if not ep['S_RECOVERY'][block]['actual_decisions'] else '原有限确认门；不是总体显著性或全域保证'
        lines.append(f"|{key}|{m['status']}；{m['successes']}/{m['planned_denominator']}；snapshot/episode={m['snapshots']}/{m['episodes']}|RESULT.endpoints.{key}|{scope}|")
    for direction in (-1,1):
        s=ep['chains'][f'{direction}:T39'];scope='该方向tick39未测' if not s['actual_decisions'] else '同一冻结批次的新状态时相覆盖'
        lines.append(f"|tick39方向{direction:+d}|计划/实际/认可/发送/恢复/任务={s['planned']}/{s['actual_decisions']}/{s['recognized']}/{s['timely_sent']}/{s['recovery']}/{s['mission_successes']}|RESULT.endpoints.chains.{direction}:T39|{scope}|")
        for arm in ARMS[1:]:
            v=ep['V']['by_direction_comparator'][f'{direction}:{arm}']
            scope='完整及时同源对照；单个2ms接触点不表示持续摔倒'
            if not ep['S_RECOVERY']['NEG_CONFIRM' if direction<0 else 'POS_TRANSFER']['actual_decisions']:scope='该方向没有实际governor决定，缺少主臂发送结局，V不可评价'
            lines.append(f"|V {direction:+d}/{arm}|{v['status']}；snapshot/episode={v['snapshots']}/{v['episodes']}|RESULT.endpoints.V.by_direction_comparator.{direction}:{arm}|{scope}|")
    for r in replays:
        lines.append(f"|replay {r['context_id']}/{r['arm']}|{r['status']}；steps={r.get('actual_steps',0)}；gate={r.get('physical_gate_classification_match')}|RESULT.replay / REPLAY_COMPLETION|仅保存命令物理重积分，不验证决策、重求解、PID或时延|")
    return '\n'.join(lines)

def validate_summaries(result,rows,finish,replays):
    """Check only already saved scalar summaries, never numeric bank contents."""
    c=counts(rows);b=result['budget'];ep=result['endpoints']
    if len(rows)!=176 or len({r.get('canonical_id',r['id']) for r in rows})!=176:
        raise ValueError('canonical 176 summary identity')
    for key,actual in (('canonical_known',c['processed']),('UNKNOWN',c['UNKNOWN']),('undispatched',c['undispatched']),
        ('observed',c['observed']),('complete_4s',c['complete_4s']),('mission_success',c['mission_success'])):
        if result.get(key)!=actual:raise ValueError('scalar summary mismatch: '+key)
    if result['planned_positions']!=176 or result['rows']!=176:raise ValueError('planned 176 summary schema')
    if result['budget']!=finish['budget']:raise ValueError('result/finish budget mismatch')
    for total,old,new,cap in (('total_QP_calls','old_QP','new_QP',45000),
        ('total_physics_steps','old_steps','new_total_integration_steps',500000),
        ('total_replay_steps','old_replay_steps','new_replay_steps',8000),
        ('total_active_seconds','old_active_seconds','resume_active_seconds',9000.25)):
        if abs(b[total]-b[old]-b[new])>1e-6 or b[total]>cap:raise ValueError('scalar budget '+total)
    if b['QP_returns']+b['unknown_native_returns']!=b['total_QP_calls']:raise ValueError('scalar QP START/RETURN')
    refs=result['references']
    if len(refs)!=12 or len({r['episode_id'] for r in refs})!=12:raise ValueError('12 reference summary identities')
    for block,mkey in (('NEG_CONFIRM','M_NEG'),('POS_TRANSFER','M_POS')):
        own=[r for r in rows if r['block']==block and r['health_kind']=='RR_THIGH15' and r['arm']==ARMS[0]]
        s=ep['S_RECOVERY'][block];m=ep[mkey]
        for key,actual in (('planned',len(own)),('actual_decisions',sum(bool(r.get('actual_governor_call')) for r in own)),
            ('recognized',sum(bool(r.get('learner_approved')) for r in own)),
            ('timely_sent',sum(bool(r.get('selected_command_sent')) for r in own))):
            if s[key]!=actual:raise ValueError('scalar S '+block+'/'+key)
        if m['successes']!=s['mission_successes'] or m['planned_denominator']!=len(own):raise ValueError('scalar M denominator')
        if m['snapshots']!=s['mission_support']['snapshots'] or m['episodes']!=s['mission_support']['episodes']:raise ValueError('scalar M support')
    if len(replays)!=4 or len({(r['context_id'],r['arm']) for r in replays})!=4:raise ValueError('four replay receipt identities')
    return dict(status='MATCH',scope='SAVED_SCALAR_SUMMARIES_ONLY',counts=c,references_complete=nref(result),
        budget_same_as_RUN_FINISHED=True,S_and_M_denominators_match=True,replay_identities=4,new_QP=0,new_steps=0)

def run():
    if not (OUT/'RUN_FINISHED.json').exists() or not (OUT/'READBACK_VERDICT.json').exists():
        raise ValueError('coordinator and unique final readback must finish before report')
    verdict=read(OUT/'READBACK_VERDICT.json')
    if verdict.get('status')!='MATCH':raise ValueError('unique final readback must be MATCH before report')
    result=read(OUT/'RESULT.json');rows=read(OUT/'BRANCH_ROWS.json');ep=result['endpoints'];c=counts(rows)
    budget=result.get('budget') or read(OUT/'RUN_FINISHED.json')['budget']
    replays=replay_rows(result);rf=nref(result);today=datetime.now().strftime('%Y-%m-%d')
    finish=read(OUT/'RUN_FINISHED.json');state=result.get('state') or finish['state']
    scalar_checks=validate_summaries(result,rows,finish,replays)
    repair=read(OUT/'READBACK_REPAIR.json',{});resumed=read(OUT/'READBACK_RESUMED.json',{})
    repair_receipts={p.name:read(p) for p in sorted(OUT.glob('READBACK_REPAIR*.json'))}
    resume_receipts={p.name:read(p) for p in sorted(OUT.glob('READBACK_RESUMED*.json'))}
    raw_verified=verdict.get('verified_new_raw_QP',verdict.get('decoded_new_raw_QP'))
    raw_decoded_known=verdict.get('decoded_new_raw_QP_known',verdict.get('decoded_new_raw_QP'))
    decode_unknown=verdict.get('failed_raw_partial_decodes_unknown_bounds',[0,0])
    if raw_verified!=budget['new_QP'] or not 0<=raw_decoded_known<=raw_verified:raise ValueError('saved scalar raw verification counts')
    old_unknowns=[r for r in rows if r.get('historical_UNKNOWN')]
    resolution='；'.join(f"{r['canonical_id']}：{r['canonical_status']}，attempt={r.get('attempt_id')}，结局={r['status']}" for r in old_unknowns)
    ref_status=dict(Counter(r.get('status',r.get('reference_status')) for r in result['references']))
    refs_processed=sum(r.get('status',r.get('reference_status')) not in ('NOT_RUN','UNKNOWN') for r in result['references'])
    noncomplete_refs=[f"{r['episode_id']}={r.get('status',r.get('reference_status'))}（physical_steps={(r.get('counts') or {}).get('physical_steps')}，control_QP_calls={(r.get('counts') or {}).get('control_qp_calls')}）" for r in result['references'] if r.get('status',r.get('reference_status'))!='COMPLETE']
    source_unavailable=[r for r in rows if r.get('packet_status')=='SOURCE_INELIGIBLE' and not unknown(r) and not undispatched(r)]
    unavailable_groups=dict(Counter(f"{r['episode']}/T{r['tick']:03d}" for r in source_unavailable))
    paragraphs=[f'''# STEP52：进程隔离下完成冻结 STEP51 批次

## Material Passport

- Origin Skill: experiment-agent / ARS / SciPilot
- Origin Date: 2026-10-13；Delivery Date: {today}
- 来源提交: {SOURCE_COMMIT}
- Status: {result['status']} / {result.get('run_status','UNKNOWN')}
- Verification: 当前文件读回 {read(OUT/'READBACK_VERDICT.json')['status']}；全算法独立数值复现 UNVERIFIED

## 当前批次结局

原176个唯一位置中，已知处理 {c['processed']}，完整4 s {c['complete_4s']}，任务成功 {c['mission_success']}；另有 {c['UNKNOWN']} 个UNKNOWN、{c['undispatched']} 个未派发。已知处理包含 {c['observed']} 条可读取轨迹及 {c['known_unsent']} 次已知未发送，不能把处理完成当作全部轨迹完整或科学确认通过。
reference实际已处理 {refs_processed}/12、完整 {rf}/12，状态构成为{ref_status}；本轮新生成{state.get('new_references')}个reference，实际新task attempts={state.get('new_task_attempts')}、新governor决定={state.get('governor_decisions')}。生成reference与reference完整分开计数。原52个已知结果（40条轨迹、12次ABSTAIN/late等未发送）原样复用；两个旧UNKNOWN的历史记录保留，当前选择结果为{resolution}。第44位按协议先尝试已保存事实的零QP/零积分派生恢复；第54位与122个未派发位置保持原identity。每个canonical slot使用预定选择规则，无best-of选择。
旧STEP51仍是INCOMPLETE，原报告、结果和UNKNOWN不回写。STEP52的新结果只补齐同一冻结176位，不新增输入，也不把STEP50成功加入本批分母。处理来源构成：{c['segments']}。

## 学习恢复与有限任务确认
''']
    paragraphs.append(f"reference非完整结局：{noncomplete_refs or '无'}。FAILED_NUMERICAL是原reference的普通数值失败结局，与资源故障分开记录，并按原规则不重试；不把partial reference补写成完整。来源未提供可用snapshot的{len(source_unavailable)}个位置为已知SOURCE_INELIGIBLE/未发送，按episode/tick计数{unavailable_groups}；这属于已处理但没有可运行来源，不是governor拒绝或未派发。原176位和方向24/8的计划分母保持不变，S的实际决定数另按真实governor调用统计，不能把POS计划8位当成8次真实governor决定。")
    for block,mkey in (('NEG_CONFIRM','M_NEG'),('POS_TRANSFER','M_POS')):
        s=ep['S_RECOVERY'][block];m=ep[mkey]
        main=[r for r in rows if r['block']==block and r['health_kind']=='RR_THIGH15' and r['arm']==ARMS[0]]
        unrun=sum(undispatched(r) for r in main);uncertain=sum(unknown(r) for r in main)
        paragraphs.append(f"{block}：计划{s['planned']}，实际决定{s['actual_decisions']}，canonical未派发{unrun}、UNKNOWN{uncertain}；认可{s['recognized']}，认可γ分布{s['gamma']}，及时发送{s['timely_sent']}，实际施加{s['applied']}，1s完整{s['complete_1s']}，原恢复门通过{s['recovery']}。已观察错受{s['false_acceptance']}，可评价认可恢复分母{s['false_acceptance_evaluable_denominator']}，未决1s partial{s['unresolved_1s_partial']}。{mkey}={m['status']}，任务成功{m['successes']}/{m['planned_denominator']}，覆盖{m['snapshots']} snapshot/{m['episodes']} episode。已认可late={s['recognized_late']}，未认可计算late={s['unrecognized_computation_late']}；拒收原因{s['model_domain_feasibility_rejections']}，动作原因{s['action_reasons']}。")
        if not s['actual_decisions']:paragraphs.append(f"{block}没有实际governor决定；该组的0成功和0错受缺乏恢复质量观察，不能称方向迁移失败或恢复质量得到验证。")
    paragraphs.append('''M_NEG仍要求至少6个相对STEP50新的snapshot/4个episode；M_POS要求至少3/2。两门都要求自身真实及时首包、原1s安全恢复、同owner连续4s安全及时任务成功，以及所有本批已施加认可恢复无错受或未决partial。STEP51已存两次成功属于这一批，可合并；STEP50历史成功不能用来补门。

恢复与任务合同未改变：原TASK_MATCHED、APPLICATION_LINEAR_28/HOLD TRAIN、TASK_TRAIN_policy_matched=False；认可仅RECOVERY_1S_ONLY。physics=.002s、control=.02s；完整任务2000步/2001 dense/200控制/81 checkpoint，恢复501 dense/50控制/21 checkpoint。恢复D≤6mm、原anchor±2mm、|vx|≤1mm/s及原其他门；恢复后1–3s quintic到原绝对goal，immediate .02–2.02s，从.04s反馈开始任务。4s成功另需全物理安全、prepared≤17ms/complete≤20ms、末goal误差≤2mm、末|vx|和1750..2000末RMS≤1mm/s及原其他terminal门。没有重设plant/PID/health/warm-start，也没有调参或额外warm-up。

## 原计划分母与状态覆盖

'''+table_groups(rows))
    chain=['|方向/tick|计划|实际决定|认可|及时|恢复|任务成功|','|---|---:|---:|---:|---:|---:|---:|']
    for direction in (-1,1):
        for tick in (37,39,41):
            s=ep['chains'][f'{direction}:T{tick}']
            chain.append(f"|{direction:+d}/{tick}|{s['planned']}|{s['actual_decisions']}|{s['recognized']}|{s['timely_sent']}|{s['recovery']}|{s['mission_successes']}|")
    paragraphs.append('\n'.join(chain)+'\n\nNOT_RUN中的已派发未发送与尚未派发缺测分开；UNKNOWN不判成功或失败。主臂ABSTAIN/late不发送新动作、不启动mission；B和nominal是独立反事实，未发送不称安全运行4s。episode是分别生成的确定性来源，同episode的snapshot、dense点与QP不是独立样本，不作IID总体推断或后选p值。')
    paragraphs.append('## 强对照、配对效用与V')
    utility=[]
    for arm in ARMS:
        own=[r for r in rows if r['health_kind']=='RR_THIGH15' and r['arm']==arm]
        utility.append(f"{arm}={sum(bool(r.get('mission_success')) for r in own)}/{len(own)}（完整4s {sum(bool(r.get('complete_2001')) for r in own)}/{len(own)}）")
    paragraphs.append('原32 severe位置的全计划任务效用：'+'；'.join(utility)+'。每种方法均保留source unavailable、未发送、late和partial，没有只以成功发送子集计算策略效用。')
    comparisons=[(ARMS[0],ARMS[i]) for i in (1,3,2,4)]+[(ARMS[1],ARMS[2])]
    for a,b in comparisons:
        own=[p for p in ep['paired'] if p['a']==a and p['b']==b];valid=[p for p in own if p['both_complete_safe_timely']]
        paragraphs.append(f"{a} 对 {b}：原32对，双方完整、安全、及时的连续指标可用{len(valid)}对；abs goal误差、settled time、两段原reference误差积分及末RMS逐对见RESULT.endpoints.paired。该子集是条件描述，不能代替所有planned位置的策略效用。")
        paragraphs.append(paired_description(valid)+'。每个指标单列可用n；中位数只作条件配对描述，不作独立样本总体推断。')
    same=[p for p in ep['paired'] if p['a']==ARMS[0] and p['b']==ARMS[1] and p['both_complete_safe_timely'] and p['same_gamma']]
    equal=sum(all(v['a']==v['b'] for v in p['continuous'].values()) for p in same)
    paragraphs.append(f"学习臂与固定MiddleRecover同γ、共同完整安全及时的{len(same)}对中，{equal}对全部已列连续汇总指标完全一致。相同控制策略下贡献定位为动作选择与认可，不声称学习器改变同控制器轨迹。MiddleImmediate的任务成功数量、较快settled time、误差及末RMS代价均保留，不能因学习认可较少而隐藏强对照。")
    for direction in (-1,1):
        for arm in ARMS[1:]:
            v=ep['V']['by_direction_comparator'][f'{direction}:{arm}']
            paragraphs.append(f"V方向{direction:+d}相对{arm}：{v['status']}，{v['snapshots']} snapshot/{v['episodes']} episode。")
    paragraphs.append(f"V并集去重为{ep['V']['snapshots']} snapshot/{ep['V']['episodes']} episode。只使用同源完整及时对照的严格物理失败；未发送、late、未完整任务、UNKNOWN不扩充V。每个事件的source/leg/类型/时刻与点数见结果；1个2ms不合格点的grid support为2ms、point span为0，不能扩写持续摔倒，也未增加grace period。健康nominal不是TASK B匹配的Type-II反事实。")
    for v in ep['V']['instances']:
        event=v['failure'];paragraphs.append(f"V原始位置：{v['snapshot_id']}/{v['b']}，首次物理不合格time={event['time_s']}s、reasons={event['reasons']}。接触统计保留逐leg/type的first/last、点数、grid support与point span。")
    replay_table=['## 保存控制的独立物理重积分\n','|位置|结局|本条真实积分|物理gate分类同原|首次接触同原|','|---|---|---:|---|---|']
    for r in replays:replay_table.append(f"|{r['context_id']}/{r['arm']}|{r['status']}|{r.get('actual_steps',0)}|{r.get('physical_gate_classification_match')}|{r.get('first_contact_event_match')}|")
    paragraphs.append('\n'.join(replay_table))
    paragraphs.append('原三个MATCH未重跑；唯一旧UNKNOWN identity获得这次明确授权的真实2000步上限重积分，历史UNKNOWN仍保留。使用原tau_raw/tau_applied字段、完整seed、固定控制槽映射及独立推进循环；bitwise数值是否MATCH与物理gate/首次contact是否同分类分别报告，不改变容差或历史STEP50 verdict。该scope仅FROZEN_CONTROL_PHYSICS_ONLY，不验证governor、controller重求解、PID或时延，不加入176任务分母或独立episode；全算法独立数值复现仍UNVERIFIED。')
    paragraphs.append(f'''## 进程边界、分segment计时与预算

每个新reference或完整branch使用一个64bit独立进程，串行且最多一个numerical worker；整个4s中保持自己的plant/controller/PID/native历史。协调器只接收路径和scalar receipt，wait/退出并关句柄后再发下一job。可关闭的实际对象尽力关闭，未把未使用的NativeOSQP.close或gc.collect当作完整释放证明；进程退出是资源生命周期边界。
worker启动/import/model和source加载/startup均在原packet交易窗口之外，但全部包含在STEP52连续active segment中。原17/20ms perf_counter、检查/copy/staging/commit窗口保留，journal callback的实际IO开销没有剔除。时延按STEP51、STEP52_RESOURCE_ISOLATED及STEP51_DERIVED_RECOVERY分开；派生恢复的命令时延仍是源STEP51记录，不能把旧/新运行视为相同cache与OS调度条件，也不声称进程启动到部署≤20ms或硬实时已验证。
累计预算：QP START={budget.get('total_QP_calls')}（旧{budget.get('old_QP')}+新{budget.get('new_QP')}），RETURN={budget.get('QP_returns')}，未知RETURN={budget.get('unknown_native_returns',0)}；积分（含保守未知上界）={budget.get('total_physics_steps')}（旧{budget.get('old_steps')}+新{budget.get('new_total_integration_steps')}），replay={budget.get('total_replay_steps')}（本轮新增{budget.get('new_replay_steps')}）。旧active={budget.get('old_active_seconds',1616.5278986999765)}s，新连续active={budget.get('resume_active_seconds')}s，累计active={budget.get('total_active_seconds')}s；上限45000QP/500000总积分/8000replay/9000active秒。本轮资源失败={state.get('numeric_resource_failures')}、startup restart={state.get('startup_restarts')}，新增CAL/TRAIN/fit={budget.get('new_CAL')}/{budget.get('new_TRAIN')}/{budget.get('new_fit')}。
新的active-clock由STEP52文件明确授权：旧已用时间加本轮从首个dispatch前至数值收尾的连续elapsed，包含启动、import、IO、等待、清理与退出；旧停机、交付和跨日间隔不算本轮新active。没有每worker重新领取150min，也没有把累计snapshot重复相加。崩溃前已flush START/RETURN、积分precharge和native reservation保留，未知消耗不记0。
最多两个已证明0新QP/0积分的基础设施startup restart由协调器持久计数；已发生数值的资源失败不重算job。第二条数值job资源失败、单case仍无法初始化、budget或scientific identity错误均按协议停止。是否完成所有处理由当前真实结局决定，不把资源中止当科学否定。
''')
    first_window=[]
    for segment in SEGMENTS:
        own=[r for r in rows if r['arm']==ARMS[0] and r.get('actual_governor_call') and r.get('segment')==segment]
        available=[r for r in own if isinstance(r.get('first_packet_ready_ms'),(int,float)) and isinstance(r.get('first_packet_prepared_ms'),(int,float))]
        prepared_only=[r for r in available if r['first_packet_prepared_ms']>17 and r['first_packet_ready_ms']<=20]
        over20=[r for r in available if r['first_packet_ready_ms']>20]
        first_window.append(f"{segment}:实际决定{len(own)}，双时延可用{len(available)}，prepared>17且complete≤20为{len(prepared_only)}（其中认可{sum(bool(r.get('learner_approved')) for r in prepared_only)}），complete>20为{len(over20)}")
    paragraphs.append('主臂真实首包的分segment deadline诊断：'+'；'.join(first_window)+'。prepared late与complete late分开，前者即使complete≤20仍不满足原17ms发送门；没有用complete≤20覆盖prepared违规。')
    repair_text=f"同一次唯一读回在第57位（SLOT0057）的JSON ndarray序列化处修复；该条observed=False，失败时没有解码事实bank。READBACK_REPAIR.json保留错误、修复前后源码SHA、{repair.get('successful_receipts_retained',56)}个已完成回执和原READBACK_STARTED；READBACK_RESUMED.json记录同一会话续接。{repair.get('successful_receipts_retained',56)}个完成回执复用，已完成bank不重新解码，修复仅限后处理序列化与metadata检查。repair/resume分别记录新增QP={repair.get('new_QP')}/{resumed.get('new_QP')}、新增积分={repair.get('new_steps')}/{resumed.get('new_steps')}；数值执行freeze保持不变。"
    raw_repair=repair_receipts.get('READBACK_REPAIR_3.json',{});ref_repair=repair_receipts.get('READBACK_REPAIR_4.json',{})
    resource_text=f"READBACK_REPAIR_2记录父汇总的同类typed JSON接口修复。RAW_SLOT0149_ATTEMPT1在1MiB SHA read处出现后处理MemoryError，原PROCESS.log保留；READBACK_REPAIR_3/READBACK_RESUMED_2复用{raw_repair.get('preserved_task_receipts')}份task和{raw_repair.get('preserved_raw_receipts')}份raw完成回执。剩余shard使用64KiB全JSON/NPZ流式SHA及typed JSON scalar global_qp_index/solver_owner_id对照START/RETURN，不重建剩余矩阵。明确已解码raw数组为{raw_decoded_known}个；失败job缺乏durable逐item计数，额外解码数量未知区间{decode_unknown}，不能把最终核验{raw_verified}个raw QP说成全部数组已解码。READBACK_REPAIR_4/READBACK_RESUMED_3再复用{ref_repair.get('saved_raw_receipts_reused')}份raw回执，补齐后段交错REFERENCE的episode/tick、COMPLETE时110control/1100physics的scalar schema与NPZ SHA检查；replay2001dense/200control网格依既有完成回执核验。最终132个raw job检查完成，没有额外事实bank或raw数组重解码。四份修复和各续接均为同一唯一读回的纯后处理资源/接口修复，新增QP=0、积分=0，执行freeze不变。最终MATCH的current task fact banks={verdict.get('current_task_fact_banks_decoded')}、source已知fact bank解码={verdict.get('referenced_old_known_banks_decoded')}、旧bank hash检查={verdict.get('referenced_old_bank_hashes_checked')}；全算法独立数值复现仍UNVERIFIED。"
    paragraphs.append('## 数据、图与交接\n\n四类必要纯测试及affected-only修复见tests；旧必要测试未重跑，没有数值smoke。一次最终streaming读回复核新增证据和所引用旧hash、attempt/identity/grid/预算，不新增QP或积分。'+repair_text+'\n\n'+resource_text+'\n\n最终REPORT的计数、S/M分母、预算和reference/replay身份只与已保存scalar汇总核对，见REPORT_POSTPROCESSING_CORRECTIONS.json。两张SciPilot图采用全176位阶段/结局/来源、条件配对原始点、分segment全部17/20ms窗口及接触持续诊断，保留失败、partial、UNKNOWN和缺测；PNG/PDF、灰度与QA见figures。\n\n'+claims(ep,replays))
    paragraphs.append(f"工作副本：{ROOT}；输出：{OUT}。源STEP51报告保持INCOMPLETE，旧head/index/native/model/历史结果不改。scoped本地提交与大证据路径/hash见交付manifest和.git/STEP52_COMMIT_RECEIPT.json，不推送。完成本轮后停止，不扩CAL、不加扰动、不进入STEP53/E3/RL/硬件；IEEE T-RO目标保持。")
    report='\n\n'.join(paragraphs)+'\n';(OUT/'REPORT.md').write_text(report,encoding='utf-8')
    claim_text=claims(ep,replays)+'\n';(OUT/'TRO_EVIDENCE_CLAIMS.md').write_text(claim_text,encoding='utf-8')
    handoff=f'''# STEP52研究交接

## Material Passport

Origin: experiment-agent / ARS；源提交{SOURCE_COMMIT}。当前文件读回{read(OUT/'READBACK_VERDICT.json')['status']}；全算法独立数值复现UNVERIFIED。

原176位：已知处理{c['processed']}，完整4s{c['complete_4s']}，任务成功{c['mission_success']}，UNKNOWN{c['UNKNOWN']}，未派发{c['undispatched']}。reference完整{rf}/12。处理完成不等于任务全部成功或科学确认通过。
reference已处理{refs_processed}/12、非完整结局{noncomplete_refs or '无'}；SOURCE_INELIGIBLE的{len(source_unavailable)}个已知未发送位置来源分布{unavailable_groups}。缺少来源可用snapshot不归入governor拒绝或未派发，不重试reference。
M_NEG={ep['M_NEG']['status']}，成功{ep['M_NEG']['successes']}/24，snapshot/episode={ep['M_NEG']['snapshots']}/{ep['M_NEG']['episodes']}；M_POS={ep['M_POS']['status']}，成功{ep['M_POS']['successes']}/8，snapshot/episode={ep['M_POS']['snapshots']}/{ep['M_POS']['episodes']}。
旧52个已知结果（含12个已派发未发送）保留；两UNKNOWN历史与新canonical选择独立记录。三条既有replay MATCH未重跑，唯一缺项的新真实重积分与原结果合并，仍仅验证保存控制物理重积分。
{repair_text}
{resource_text}
旧STEP51继续INCOMPLETE。本轮计时另按新授权active segment记录，旧/新交易窗口与cache/调度环境分开展示。完整176分母、S、tick39、各V对照和强MiddleImmediate效用见REPORT/RESULT/BRANCH_ROWS/TRO_EVIDENCE_CLAIMS。
输出{OUT}。本地提交回执.git/STEP52_COMMIT_RECEIPT.json；大证据路径/hash由manifest明确。收尾后停止，无新CAL/STEP53/E3/RL/硬件授权，不推送。
'''
    (OUT/'HANDOFF.md').write_text(handoff,encoding='utf-8')
    proto=PROTOCOL.read_text(encoding='utf-8').split('~~~ini')[1].split('~~~')[0].strip()
    proto+=f"\nSTEP52_RUN_STATUS = {result.get('run_status')}\nSTEP52_READBACK_STATUS = {read(OUT/'READBACK_VERDICT.json')['status']}\nSTEP52_PROCESSED_KNOWN = {c['processed']}\nSTEP52_COMPLETE_FOUR_SECONDS = {c['complete_4s']}\nSTEP52_MISSION_SUCCESSES_ALL_ARMS = {c['mission_success']}\nSTEP52_UNKNOWN_CANONICAL = {c['UNKNOWN']}\nSTEP52_UNDISPATCHED_CANONICAL = {c['undispatched']}\nSTEP52_REFERENCE_EPISODES_COMPLETE = {rf}\nSTEP52_M_NEG = {ep['M_NEG']['status']}\nSTEP52_M_POS = {ep['M_POS']['status']}\nSTEP52_NUMERICAL_SCOPE_CLOSED = TRUE\n"
    (OUT/'PROTOCOL_STATUS.ini').write_text(proto,encoding='utf-8')
    write(OUT/'REPORT_SUMMARY.json',dict(**c,references_complete=rf,references_processed=refs_processed,reference_statuses=ref_status,
        source_ineligible_known_unsent=len(source_unavailable),source_unavailable_episode_ticks=unavailable_groups,
        S=ep['S_RECOVERY'],M_NEG=ep['M_NEG'],M_POS=ep['M_POS'],replay_statuses=[r['status'] for r in replays],new_QP=0,new_steps=0))
    write(OUT/'REPORT_POSTPROCESSING_CORRECTIONS.json',dict(scalar_checks=scalar_checks,
        corrections=['canonical undispatched separated from absence of actual governor call',
            'historical UNKNOWN selection shown by saved canonical status and attempt',
            'unique readback SLOT0057 ndarray serialization repair and 56 prior receipts retained/resumed',
            'replay header and four data rows joined as one GFM table paragraph',
            'HANDOFF old52 wording clarifies twelve known unsent are included, not additional'],
        readback_repairs=repair_receipts,readback_resumptions=resume_receipts,
        raw_arrays_decoded_known=raw_decoded_known,failed_job_partial_decodes_unknown_bounds=decode_unknown,
        raw_QP_verified_total=raw_verified,raw_verification_scope=verdict.get('raw_checks'),
        execution_code_changed=False,new_QP=0,new_steps=0))
    print(json.dumps(dict(report=str(OUT/'REPORT.md'),counts=c,M_NEG=ep['M_NEG']['status'],M_POS=ep['M_POS']['status']),ensure_ascii=False),flush=True)

if __name__=='__main__':run()
