"""Only four STEP52 pure adaptation topics, with scoped repair receipts."""
import io
import sys
import unittest
from cavr_wbc.experiments.step52_io import OUT,read,write,write_new

def run(repair=None):
    from tests.test_step52_contract import Step52Contract
    path=OUT/'tests/NECESSARY_TESTS.json'
    if path.exists() and repair is None: raise FileExistsError('four pure topics already recorded')
    names=unittest.defaultTestLoader.getTestCaseNames(Step52Contract)
    suite=unittest.TestSuite(Step52Contract(n) for n in names if repair is None or n.startswith('test_'+str(repair)+'_'))
    stream=io.StringIO(); result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    failed=sorted({int(case._testMethodName.split('_')[1]) for case,_ in result.failures+result.errors})
    document=dict(tests_run=result.testsRun,errors=len(result.errors),failures=len(result.failures),failed_topics=failed,
        output=stream.getvalue(),real_QP_calls=0,MuJoCo_steps=0,old_tests_run=0)
    if repair is None: write_new(path,document)
    else:
        initial=OUT/'tests/INITIAL_GROUP_RESULT.json'
        if not initial.exists(): write_new(initial,read(path))
        receipt=OUT/f'tests/AFFECTED_TOPIC_{repair}_REPAIR.json'
        if receipt.exists(): receipt=OUT/f'tests/AFFECTED_TOPIC_{repair}_REPAIR_{__import__("time").time_ns()}.json'
        write_new(receipt,document)
        old=read(path); remaining=[n for n in old.get('failed_topics',[]) if n!=repair]
        remaining+=failed
        write(path,dict(tests_run=4,errors=len(remaining),failures=0,failed_topics=sorted(set(remaining)),
            real_QP_calls=0,MuJoCo_steps=0,old_tests_run=0,initial='INITIAL_GROUP_RESULT.json'))
    print(stream.getvalue(),flush=True)
    if not result.wasSuccessful(): raise SystemExit(1)

if __name__=='__main__': run(int(sys.argv[1]) if len(sys.argv)>1 else None)
