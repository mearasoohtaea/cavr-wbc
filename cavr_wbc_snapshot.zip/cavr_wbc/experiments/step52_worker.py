"""One frozen reference or whole branch in one short-lived process.

Only file paths and scalar receipts cross the process boundary. Startup/import
is outside the source packet clock and inside coordinator active elapsed time.
"""
from pathlib import Path
from datetime import datetime,timezone
import argparse
import gc
import json
import os
import sys
import time
import traceback
from cavr_wbc.experiments.step52_io import ROOT,read,write,write_new,sha,resource_snapshot,install_streaming
from cavr_wbc.experiments.step52_budget import WorkerBudget,SprintLimit,scalar_encode

REQUIRED=('job_id','attempt_id','kind','job_out','qp_offset','remaining_QP','remaining_steps',
    'deadline_epoch_s','source_method_sha','source_step50_sha','source_config_path',
    'contract_path','bundle_path','domain_path','execution_freeze_sha')

def validate_job(job):
    missing=[k for k in REQUIRED if k not in job]
    if missing: raise ValueError('missing JOB fields: '+','.join(missing))
    if job['kind'] not in ('REFERENCE','BRANCH','SYNTHETIC'): raise ValueError('worker kind')
    if not Path(job['job_out']).resolve().is_relative_to(ROOT.resolve()): raise ValueError('job_out outside new D workspace')
    if job['kind']=='REFERENCE' and 'episode' not in job: raise ValueError('reference episode missing')
    if job['kind']=='BRANCH' and not all(k in job for k in ('position','episode_path','canonical_id')):
        raise ValueError('branch frozen position/episode missing')
    if int(job['qp_offset']) != job['qp_offset'] or int(job['remaining_QP']) != job['remaining_QP']:
        raise ValueError('integer QP quota/offset required')

def verify_episode(job):
    path=Path(job['episode_path'])
    if job.get('episode_sha256') and sha(path)!=job['episode_sha256']: raise ValueError('episode JSON identity')
    header=read(path); npz=path.parent/header['numeric_npz']
    if job.get('episode_npz_sha256') and sha(npz)!=job['episode_npz_sha256']: raise ValueError('episode NPZ identity')

def cleanup_owners(owners):
    """Best effort on actual used objects; process exit is the release boundary."""
    seen=set(); solver_seen=set(); actual_closed=[]; cache_entries=0; errors=[]
    for owner in list(owners.values()):
        controllers=[getattr(owner,n,None) for n in ('nominal_controller','backup_controller')]
        controllers+=list(getattr(owner,'_shadow_controllers',{}).values())
        for controller in controllers:
            if controller is None or id(controller) in seen: continue
            seen.add(id(controller)); cache=getattr(controller,'_solver_cache',{})
            if not hasattr(cache,'values'):
                errors.append('unexpected cache container '+type(cache).__name__); continue
            cache_entries+=len(cache)
            for row in cache.values():
                if not isinstance(row,dict):
                    errors.append('unexpected cache entry '+type(row).__name__); continue
                solver=row.get('solver')
                if solver is None or id(solver) in solver_seen: continue
                solver_seen.add(id(solver)); close=getattr(solver,'close',None)
                if callable(close):
                    try: close(); actual_closed.append(type(solver).__module__+'.'+type(solver).__name__)
                    except Exception as exc: errors.append(type(exc).__name__+': '+str(exc))
            cache.clear()
            # Evidence queues are deliberately not cleared here: unknown jobs
            # retain journal boundaries and exit without claiming full release.
            if hasattr(controller,'solve_callback'): controller.solve_callback=None
    owners.clear(); gc.collect()
    return dict(actual_used_solver_close_classes=actual_closed,private_cache_entries_dropped=cache_entries,
        best_effort_errors=errors,all_native_resources_explicitly_closed=False,
        resource_recovery_boundary='WORKER_PROCESS_EXIT_OBSERVED_BY_COORDINATOR')

def packet_only_scalars(packet):
    return {k:packet.get(k) for k in ('status','selected_gamma','learner_approved','selected_command_sent',
        'model_authorized','governor_selected','experimental_committed','nominal_sent',
        'prepared_commit_ms','command_ready_ms','dispatch_kind')}

def write_startup(path,startup):
    # Preserve the original writer's NumPy metadata encoding. This storage is
    # after startup and outside the frozen packet transaction window.
    from cavr_wbc.experiments.step47_io import write as original_write
    if Path(path).exists(): raise FileExistsError('startup evidence cannot be overwritten')
    original_write(path,startup)

def execute_reference(job,budget):
    from cavr_wbc.experiments import step17_formal_panel as frozen
    from cavr_wbc.experiments.step35_reference import reference_episode
    from cavr_wbc.experiments.step47_io import save_numeric
    model=frozen.load_model(); manifest=read(job['source_config_path']); ep=job['episode']
    episode=reference_episode(model,manifest['reference_scenario'],ep['displacement_m'],ep['episode_id'],
        ep['snapshot_ticks'],budget,evidence_callback=budget.record_raw)
    budget.confirm_normal_return()
    for row in episode['controls']: row.pop('raw_solver_result',None)
    path=Path(job['job_out'])/'episode.json'; record=save_numeric(path,episode)
    return dict(outcome='REFERENCE_RETURNED',reference_status=episode['status'],episode_path=str(path),
        episode_sha256=record['json_sha256'],episode_npz_sha256=record['npz_sha256'],
        episode_id=ep['episode_id'],reference_physical_steps=episode['counts']['physical_steps'])

def execute_branch(job,budget,owners):
    import numpy as np
    from cavr_wbc.experiments import step17_formal_panel as frozen,step50_sim as sim
    from cavr_wbc.experiments.step47_io import save_numeric,load_numeric
    from cavr_wbc.experiments.step51_inputs import context_for,arm_context,gamma_for
    from cavr_wbc.experiments.step50_sprint import owners_for,missing_packet
    from cavr_wbc.experiments.step51_storage import save_branch,not_run
    from cavr_wbc.control.step50_kernel import nominal_packet,experimental_packet
    from cavr_wbc.control.step50_dispatch import first_sent
    from cavr_wbc.control.step39_margin import load_bundle
    from cavr_wbc.experiments.step47_binding import PolicyDomain
    out=Path(job['job_out']); pos=job['position']; manifest=read(job['source_config_path'])
    verify_episode(job); episode=load_numeric(job['episode_path'])
    if 'context_plan' in job: p=job['context_plan']
    else:
        frozen_input=read(job['source_freeze_path'])
        p=next(x for x in frozen_input['plans'] if x['context_id']==pos['context_id'])
    if p['context_id']!=pos['context_id'] or p['episode']!=pos['episode'] or pos['arm'] not in p['arms']:
        raise ValueError('frozen branch position/context identity')
    if episode['episode_id']!=pos['episode']: raise ValueError('branch/episode identity')
    contract_file=read(job['contract_path'])
    contract=contract_file.get('policy_contract') or contract_file.get('methods',{}).get('PHASE_MATCHED_TASK',{}).get('policy_contract')
    if contract is None: raise ValueError('frozen contract missing')
    bundle=load_bundle(job['bundle_path']); domain=PolicyDomain(read(job['domain_path']),sha(job['domain_path']))
    if bundle['policy_contract']!=contract or domain.policy_contract!=contract: raise ValueError('source model/domain contract identity')
    c=context_for(p,episode,manifest['mapping'])
    arm=pos['arm']; gamma=gamma_for(arm)
    # Keep old science identity. STEP52 records an execution-only freeze.
    ac=arm_context(c,arm,contract,job['source_method_sha'],job['source_step50_sha'])
    ac['step52_execution_freeze_sha256']=job['execution_freeze_sha']
    ac['step52_job_id']=job['job_id']; ac['step52_attempt_id']=job['attempt_id']
    if ac.get('eligible'):
        ac['policy_anchor_goal']=dict(x_anchor_m=float(ac['backup_anchor_q_init'][0]),
            x_goal_m=float(ac['nominal_q_init'][0])+float(ac['nominal_d_m']),
            d_task_m=float(np.clip(float(ac['nominal_q_init'][0])+float(ac['nominal_d_m'])-float(ac['backup_anchor_q_init'][0]),-.001,.001)))
    save_numeric(out/'SOURCE_IDENTITY.json',dict(plan=p,context=c))
    save_numeric(out/'POLICY_CONTEXT.json',ac)
    model=frozen.load_model(); kernel=None
    if ac.get('eligible'):
        loaded,startup=owners_for(model,budget,ac,manifest,contract,domain); owners.update(loaded)
        write_startup(out/'STARTUP.json',startup)
        if arm=='GOVERNED_RECOVER_RESUME':
            kernel=owners['GOVERNOR']; budget.event('GOVERNOR_DECISION_START',canonical_id=pos['id'])
            packet=kernel.governor(ac,bundle,.006,budget)
            budget.event('GOVERNOR_DECISION_RETURN',status=packet['status'])
        elif arm=='NOMINAL_IMMEDIATE':
            kernel=owners['C']; packet=nominal_packet(kernel,ac,budget)
        else:
            kernel=owners['B' if gamma==0. else 'MIDDLE']; packet=experimental_packet(kernel,ac,budget,owners,gamma,arm)
        kernel.flush_raw_evidence()
    else: packet=missing_packet(ac,gamma)
    save_numeric(out/'PACKET.json',packet)
    branch=sim.propagate(kernel,ac,packet,budget,purpose=arm,require_sent=True) if first_sent(packet,ac) else not_run(packet.get('selected_gamma',gamma),packet['status'])
    budget.confirm_normal_return()
    result=save_branch(out,out,branch,ac,packet)
    return dict(outcome='BRANCH_RETURNED',canonical_id=job['canonical_id'],position_id=pos['id'],result_path=str(out/'RESULT.json'),
        result_sha256=sha(out/'RESULT.json'),branch_status=result['status'],complete_4s=result['complete_2001'],
        mission_success=result['mission_success'],packet=packet_only_scalars(packet),
        physical_steps=(branch.get('counts') or {}).get('physical_steps',0),actual_governor_call=arm=='GOVERNED_RECOVER_RESUME' and ac.get('eligible',False))

def execute_synthetic(job,budget):
    # Pure lifecycle fixture only; this path never imports MuJoCo or a solver.
    if job.get('synthetic_crash'): os._exit(9)
    payload=dict(outcome='SYNTHETIC_'+job.get('synthetic_outcome','RETURNED'),token=job.get('synthetic_token','test'))
    write_new(Path(job['job_out'])/'SYNTHETIC_RESULT.json',payload)
    return payload

def run(job_path):
    process_begin=time.perf_counter(); job=read(job_path); validate_job(job)
    out=Path(job['job_out']); out.mkdir(parents=True,exist_ok=True)
    if (out/'WORKER_STARTED.json').exists(): raise FileExistsError('attempt worker cannot overwrite/start twice')
    write_new(out/'WORKER_STARTED.json',dict(job_id=job['job_id'],attempt_id=job['attempt_id'],kind=job['kind'],
        pid=os.getpid(),resource=resource_snapshot(),start_utc=datetime.now(timezone.utc).isoformat(),
        new_QP_calls=0,new_integration_steps=0,process_start_imports_counted_in_coordinator_active_clock=True))
    budget=WorkerBudget(job); owners={}; result={}; error=None; error_tb=''; status='KNOWN'; stage='IMPORT_LOAD'
    try:
        if job['kind']!='SYNTHETIC': install_streaming()
        budget.check(); stage='NUMERICAL_OPERATION'
        if job['kind']=='REFERENCE': result=execute_reference(job,budget)
        elif job['kind']=='BRANCH': result=execute_branch(job,budget,owners)
        else: result=execute_synthetic(job,budget)
    except SprintLimit as exc:
        status='BUDGET_STOP'; error=dict(type=type(exc).__name__,message=str(exc)); error_tb=traceback.format_exc()
    except ImportError as exc:
        status='BASE_STARTUP_FAILURE'; error=dict(type=type(exc).__name__,message=str(exc)); error_tb=traceback.format_exc()
    except (MemoryError,OSError) as exc:
        status='RESOURCE_FAILURE'; error=dict(type=type(exc).__name__,message=str(exc)); error_tb=traceback.format_exc()
    except (ValueError,KeyError,TypeError,AssertionError) as exc:
        status='IDENTITY_OR_INTERFACE_ERROR'; error=dict(type=type(exc).__name__,message=str(exc)); error_tb=traceback.format_exc()
    except Exception as exc:
        # Ordinary numerical failures with no returned trajectory remain UNKNOWN.
        # MuJoCo's explicit allocator errors are resource outcomes.
        status='RESOURCE_FAILURE' if any(s in str(exc).lower() for s in ('allocate memory','out of memory','bad allocation')) else 'NUMERICAL_EXCEPTION'
        error=dict(type=type(exc).__name__,message=str(exc)); error_tb=traceback.format_exc()
    finally:
        if error:
            write_new(out/'WORKER_EXCEPTION.json',scalar_encode(dict(**error,stage=stage,traceback=error_tb)))
        try: cleanup=cleanup_owners(owners)
        except Exception as exc:
            cleanup=dict(best_effort_errors=[type(exc).__name__+': '+str(exc)],all_native_resources_explicitly_closed=False,
                resource_recovery_boundary='WORKER_PROCESS_EXIT_OBSERVED_BY_COORDINATOR')
        budget.event('WORKER_NUMERICAL_FINISHED',status=status)
        budget.close()
        snap=budget.snapshot()
        receipt=dict(job_id=job['job_id'],attempt_id=job['attempt_id'],kind=job['kind'],status=status,
            stage=stage,PID=os.getpid(),budget=snap,error=error,job_out=str(out),ledger_path=str(budget.path),
            startup_zero_work_proven=snap['new_QP_calls']==0 and snap['integration_upper_bound']==0,
            resource_before=read(out/'WORKER_STARTED.json')['resource'],resource_after_cleanup=resource_snapshot(),
            cleanup=cleanup,worker_total_elapsed_s=time.perf_counter()-process_begin,
            process_exit_is_release_boundary=True,**result)
        receipt.setdefault('actual_governor_call',snap['governor_decisions_started']>0)
        write_new(out/'WORKER_RECEIPT.json',receipt)
        print(json.dumps(dict(receipt_path=str(out/'WORKER_RECEIPT.json'),status=status,job_id=job['job_id'])),flush=True)
    return 0 if status=='KNOWN' else 2

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--job',type=Path,required=True)
    raise SystemExit(run(p.parse_args().job))
