"""Side-effect-isolated schema for STEP-01 per-control-step logs."""

from __future__ import annotations

from dataclasses import dataclass
import json
import math
from pathlib import Path
from typing import Mapping


UNAVAILABLE = "unavailable"
Diagnostic = float | str
REQUIRED_TIMING_KEYS = (
    "state_read",
    "constraint_construction",
    "solve",
    "validation",
    "actuator_application",
    "total_control_latency",
)


def _finite_tuple(name: str, values: tuple[float, ...]) -> tuple[float, ...]:
    converted = tuple(float(value) for value in values)
    if not all(math.isfinite(value) for value in converted):
        raise ValueError(f"{name} must contain only finite values")
    return converted


def _diagnostic(name: str, value: Diagnostic) -> Diagnostic:
    if value == UNAVAILABLE:
        return value
    converted = float(value)
    if not math.isfinite(converted):
        raise ValueError(f"{name} must be finite or '{UNAVAILABLE}'")
    return converted


@dataclass(frozen=True)
class ControlStepRecord:
    time_s: float
    q: tuple[float, ...]
    v: tuple[float, ...]
    u_cmd: tuple[float, ...]
    tau_applied: tuple[float, ...]
    rho: tuple[float, ...]
    actuator_saturation_mask: tuple[bool, ...]
    contact_state: object
    solver_status: str
    solver_primal_residual: Diagnostic
    solver_dual_residual: Diagnostic
    task_residual: Diagnostic
    simulation_step: int
    controller_step: int
    timings_s: Mapping[str, Diagnostic]

    def __post_init__(self) -> None:
        if not math.isfinite(float(self.time_s)) or self.time_s < 0.0:
            raise ValueError("time_s must be finite and non-negative")
        if self.simulation_step < 0 or self.controller_step < 0:
            raise ValueError("step indices must be non-negative")

        _finite_tuple("q", self.q)
        _finite_tuple("v", self.v)
        u_cmd = _finite_tuple("u_cmd", self.u_cmd)
        tau_applied = _finite_tuple("tau_applied", self.tau_applied)
        rho = _finite_tuple("rho", self.rho)
        if len({len(u_cmd), len(tau_applied), len(rho), len(self.actuator_saturation_mask)}) != 1:
            raise ValueError("actuator-space log fields must have matching lengths")
        if not all(0.0 <= value <= 1.0 for value in rho):
            raise ValueError("logged rho values must lie in [0, 1]")

        _diagnostic("solver_primal_residual", self.solver_primal_residual)
        _diagnostic("solver_dual_residual", self.solver_dual_residual)
        _diagnostic("task_residual", self.task_residual)

        missing = set(REQUIRED_TIMING_KEYS) - set(self.timings_s)
        extra = set(self.timings_s) - set(REQUIRED_TIMING_KEYS)
        if missing or extra:
            raise ValueError(
                f"timings_s keys mismatch; missing={sorted(missing)}, extra={sorted(extra)}"
            )
        for key, value in self.timings_s.items():
            checked = _diagnostic(f"timings_s.{key}", value)
            if checked != UNAVAILABLE and checked < 0.0:
                raise ValueError(f"timings_s.{key} must be non-negative")

    def as_dict(self) -> dict[str, object]:
        return {
            "time": self.time_s,
            "q": list(self.q),
            "v": list(self.v),
            "u_cmd": list(self.u_cmd),
            "tau_applied": list(self.tau_applied),
            "rho": list(self.rho),
            "actuator_saturation_mask": list(self.actuator_saturation_mask),
            "contact_state": self.contact_state,
            "solver_status": self.solver_status,
            "solver_primal_residual": self.solver_primal_residual,
            "solver_dual_residual": self.solver_dual_residual,
            "task_residual": self.task_residual,
            "simulation_step": self.simulation_step,
            "controller_step": self.controller_step,
            "timings_s": dict(self.timings_s),
        }


def append_control_step_jsonl(path: str | Path, record: ControlStepRecord) -> None:
    """Append one already-validated record without touching control state."""

    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(record.as_dict(), allow_nan=False, sort_keys=True))
        handle.write("\n")

