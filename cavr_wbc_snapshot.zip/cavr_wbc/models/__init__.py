"""Robot and actuator model interfaces."""

from .actuator_health import (
    ActuatorHealthModel,
    ActuatorHealthResult,
    apply_physical_actuator_bounds,
)
from .actuator_mapping import ActuatorJointMapEntry, validate_actuator_joint_map

__all__ = [
    "ActuatorHealthModel",
    "ActuatorHealthResult",
    "ActuatorJointMapEntry",
    "apply_physical_actuator_bounds",
    "validate_actuator_joint_map",
]

