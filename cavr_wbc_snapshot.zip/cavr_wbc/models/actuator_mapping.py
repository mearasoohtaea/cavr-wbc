"""Explicit actuator-to-joint mapping schema.

The schema intentionally keeps actuator, joint, and degree-of-freedom indices
separate.  It makes no numerical-identity assumption between those namespaces.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Iterable


def _optional_finite(name: str, value: float | None) -> float | None:
    if value is None:
        return None
    converted = float(value)
    if not math.isfinite(converted):
        raise ValueError(f"{name} must be finite or None")
    return converted


@dataclass(frozen=True)
class ActuatorJointMapEntry:
    actuator_index: int
    actuator_name: str
    joint_name: str
    joint_id: int
    dof_index: int
    gear: tuple[float, ...] | None
    ctrl_min: float | None
    ctrl_max: float | None
    force_min: float | None
    force_max: float | None
    joint_torque_limit: float | None
    unit: str | None

    def __post_init__(self) -> None:
        if self.actuator_index < 0:
            raise ValueError("actuator_index must be non-negative")
        if self.joint_id < 0:
            raise ValueError("joint_id must be non-negative")
        if self.dof_index < 0:
            raise ValueError("dof_index must be non-negative")
        if not self.actuator_name:
            raise ValueError("actuator_name must not be empty")
        if not self.joint_name:
            raise ValueError("joint_name must not be empty")

        if self.gear is not None:
            if not self.gear:
                raise ValueError("gear must be None or a non-empty vector")
            if not all(math.isfinite(float(value)) for value in self.gear):
                raise ValueError("gear must contain only finite values")

        ctrl_min = _optional_finite("ctrl_min", self.ctrl_min)
        ctrl_max = _optional_finite("ctrl_max", self.ctrl_max)
        force_min = _optional_finite("force_min", self.force_min)
        force_max = _optional_finite("force_max", self.force_max)
        torque_limit = _optional_finite(
            "joint_torque_limit", self.joint_torque_limit
        )
        if ctrl_min is not None and ctrl_max is not None and ctrl_min > ctrl_max:
            raise ValueError("ctrl_min must not exceed ctrl_max")
        if force_min is not None and force_max is not None and force_min > force_max:
            raise ValueError("force_min must not exceed force_max")
        if torque_limit is not None and torque_limit <= 0.0:
            raise ValueError("joint_torque_limit must be positive or None")

    def as_dict(self) -> dict[str, object]:
        return {
            "actuator_index": self.actuator_index,
            "actuator_name": self.actuator_name,
            "joint_name": self.joint_name,
            "joint_id": self.joint_id,
            "dof_index": self.dof_index,
            "gear": None if self.gear is None else list(self.gear),
            "ctrl_min": self.ctrl_min,
            "ctrl_max": self.ctrl_max,
            "force_min": self.force_min,
            "force_max": self.force_max,
            "joint_torque_limit": self.joint_torque_limit,
            "unit": self.unit,
        }


def validate_actuator_joint_map(
    entries: Iterable[ActuatorJointMapEntry], expected_count: int | None = None
) -> tuple[ActuatorJointMapEntry, ...]:
    """Validate map completeness without conflating index namespaces."""

    mapping = tuple(entries)
    if expected_count is not None and expected_count < 0:
        raise ValueError("expected_count must be non-negative")
    if expected_count is not None and len(mapping) != expected_count:
        raise ValueError("mapping length does not match expected actuator count")

    indices = [entry.actuator_index for entry in mapping]
    if len(set(indices)) != len(indices):
        raise ValueError("actuator_index values must be unique")
    if sorted(indices) != list(range(len(mapping))):
        raise ValueError("actuator_index values must be contiguous from zero")

    names = [entry.actuator_name for entry in mapping]
    if len(set(names)) != len(names):
        raise ValueError("actuator_name values must be unique")

    return mapping

