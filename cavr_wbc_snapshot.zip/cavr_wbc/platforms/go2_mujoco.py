"""Audited Unitree Go2 / MuJoCo platform adapter for STEP-01B."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import mujoco
import numpy as np

from cavr_wbc.models.actuator_mapping import (
    ActuatorJointMapEntry,
    validate_actuator_joint_map,
)


DEFAULT_GO2_MODEL_PATH = Path(
    "third_party/unitree_mujoco_snapshot/unitree_robots/go2/scene.xml"
)
FOOT_NAMES = ("FL", "FR", "RL", "RR")


def load_go2_model(path: str | Path = DEFAULT_GO2_MODEL_PATH) -> mujoco.MjModel:
    """Load the untouched pinned Go2 scene.

    A relative path is intentional.  MuJoCo 3.13.0 on this Windows host fails
    when its native XML loader receives the workspace's non-ASCII absolute path,
    while the equivalent relative path compiles correctly.
    """

    model_path = Path(path)
    if model_path.is_absolute():
        raise ValueError(
            "Use a path relative to the repository root on this Windows host"
        )
    return mujoco.MjModel.from_xml_path(model_path.as_posix())


def _name(model: mujoco.MjModel, object_type: mujoco.mjtObj, index: int) -> str | None:
    return mujoco.mj_id2name(model, object_type, int(index))


def extract_actuator_audit(model: mujoco.MjModel) -> list[dict[str, Any]]:
    """Extract actuator semantics from the compiled MjModel, not XML text."""

    result: list[dict[str, Any]] = []
    for actuator_index in range(model.nu):
        joint_id = int(model.actuator_trnid[actuator_index, 0])
        ctrl_limited = bool(model.actuator_ctrllimited[actuator_index])
        force_limited = bool(model.actuator_forcelimited[actuator_index])
        joint_force_limited = bool(model.jnt_actfrclimited[joint_id])
        entry = {
            "actuator_index": actuator_index,
            "actuator_name": _name(
                model, mujoco.mjtObj.mjOBJ_ACTUATOR, actuator_index
            ),
            "transmission_type": mujoco.mjtTrn(
                int(model.actuator_trntype[actuator_index])
            ).name,
            "target_joint": _name(model, mujoco.mjtObj.mjOBJ_JOINT, joint_id),
            "joint_id": joint_id,
            "qpos_address": int(model.jnt_qposadr[joint_id]),
            "dof_index": int(model.jnt_dofadr[joint_id]),
            "gear": model.actuator_gear[actuator_index].astype(float).tolist(),
            "ctrl_limited": ctrl_limited,
            "ctrl_range": (
                model.actuator_ctrlrange[actuator_index].astype(float).tolist()
                if ctrl_limited
                else None
            ),
            "force_limited": force_limited,
            "force_range": (
                model.actuator_forcerange[actuator_index].astype(float).tolist()
                if force_limited
                else None
            ),
            "joint_actuator_force_limited": joint_force_limited,
            "joint_actuator_force_range": (
                model.jnt_actfrcrange[joint_id].astype(float).tolist()
                if joint_force_limited
                else None
            ),
            "gain_type": mujoco.mjtGain(
                int(model.actuator_gaintype[actuator_index])
            ).name,
            "gain_parameters": model.actuator_gainprm[actuator_index]
            .astype(float)
            .tolist(),
            "bias_type": mujoco.mjtBias(
                int(model.actuator_biastype[actuator_index])
            ).name,
            "bias_parameters": model.actuator_biasprm[actuator_index]
            .astype(float)
            .tolist(),
            "dynamic_type": mujoco.mjtDyn(
                int(model.actuator_dyntype[actuator_index])
            ).name,
            "dynamic_parameters": model.actuator_dynprm[actuator_index]
            .astype(float)
            .tolist(),
            "activation_address": int(model.actuator_actadr[actuator_index]),
            "activation_dimension": int(model.actuator_actnum[actuator_index]),
            "unit": "N*m",
        }
        result.append(entry)
    return result


def extract_healthy_torque_limits(model: mujoco.MjModel) -> np.ndarray:
    """Return audited symmetric direct-motor limits from active ctrlrange.

    This is valid for this pinned model only after checking joint transmission,
    unit gear, fixed unit gain, no bias, no actuator dynamics, and symmetric
    enabled control ranges.
    """

    audit = extract_actuator_audit(model)
    limits: list[float] = []
    for entry in audit:
        gear = entry["gear"]
        ctrl_range = entry["ctrl_range"]
        direct = (
            entry["transmission_type"] == "mjTRN_JOINT"
            and np.isclose(gear[0], 1.0)
            and np.allclose(gear[1:], 0.0)
            and entry["gain_type"] == "mjGAIN_FIXED"
            and np.isclose(entry["gain_parameters"][0], 1.0)
            and entry["bias_type"] == "mjBIAS_NONE"
            and entry["dynamic_type"] == "mjDYN_NONE"
            and entry["ctrl_limited"]
        )
        if not direct or ctrl_range is None:
            raise ValueError(
                f"Actuator {entry['actuator_name']} is not an audited direct unit motor"
            )
        lower, upper = (float(value) for value in ctrl_range)
        if not np.isclose(lower, -upper) or upper <= 0.0:
            raise ValueError(
                f"Actuator {entry['actuator_name']} lacks a positive symmetric ctrlrange"
            )
        limits.append(upper)
    return np.asarray(limits, dtype=float)


def extract_actuator_joint_map(
    model: mujoco.MjModel,
) -> tuple[ActuatorJointMapEntry, ...]:
    """Generate and validate the explicit mapping from the compiled model."""

    audit = extract_actuator_audit(model)
    limits = extract_healthy_torque_limits(model)
    entries = []
    for item, torque_limit in zip(audit, limits):
        ctrl_range = item["ctrl_range"]
        force_range = item["force_range"]
        entries.append(
            ActuatorJointMapEntry(
                actuator_index=int(item["actuator_index"]),
                actuator_name=str(item["actuator_name"]),
                joint_name=str(item["target_joint"]),
                joint_id=int(item["joint_id"]),
                dof_index=int(item["dof_index"]),
                gear=tuple(float(value) for value in item["gear"]),
                ctrl_min=None if ctrl_range is None else float(ctrl_range[0]),
                ctrl_max=None if ctrl_range is None else float(ctrl_range[1]),
                force_min=None if force_range is None else float(force_range[0]),
                force_max=None if force_range is None else float(force_range[1]),
                joint_torque_limit=float(torque_limit),
                unit="N*m",
            )
        )
    return validate_actuator_joint_map(entries, expected_count=model.nu)


def joint_tau_from_qfrc(
    model: mujoco.MjModel, data: mujoco.MjData
) -> np.ndarray:
    """Read each mapped joint contribution from MuJoCo qfrc_actuator."""

    mapping = extract_actuator_joint_map(model)
    return np.asarray(
        [float(data.qfrc_actuator[entry.dof_index]) for entry in mapping],
        dtype=float,
    )


def contact_diagnostics(
    model: mujoco.MjModel, data: mujoco.MjData
) -> dict[str, dict[str, float | bool | int]]:
    """Return simulator-truth contact and foot slip diagnostics."""

    geom_ids = {
        name: mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_GEOM, name)
        for name in FOOT_NAMES
    }
    diagnostics: dict[str, dict[str, float | bool | int]] = {}
    for name, geom_id in geom_ids.items():
        velocity = np.zeros(6, dtype=float)
        mujoco.mj_objectVelocity(
            model, data, mujoco.mjtObj.mjOBJ_GEOM, geom_id, velocity, 0
        )
        diagnostics[name] = {
            "present": False,
            "contact_count": 0,
            "normal_force_n": 0.0,
            "tangential_speed_m_s": float(np.linalg.norm(velocity[3:5])),
        }

    for contact_index in range(data.ncon):
        contact = data.contact[contact_index]
        for name, geom_id in geom_ids.items():
            if int(contact.geom1) == geom_id or int(contact.geom2) == geom_id:
                wrench = np.zeros(6, dtype=float)
                mujoco.mj_contactForce(model, data, contact_index, wrench)
                diagnostics[name]["present"] = True
                diagnostics[name]["contact_count"] = int(
                    diagnostics[name]["contact_count"]
                ) + 1
                diagnostics[name]["normal_force_n"] = float(
                    diagnostics[name]["normal_force_n"]
                ) + float(wrench[0])
    return diagnostics

